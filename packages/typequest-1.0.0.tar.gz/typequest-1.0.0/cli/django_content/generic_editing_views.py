"""
Django Generic Editing Views lesson content  
"""

DJANGO_GENERIC_EDITING_LESSON = {
    "id": 11,
    "chapter": 11,
    "title": "Form Handling with Generic Editing Views", 
    "slug": "generic-editing-views",
    "content": '''
# Form Handling with Generic Editing Views: CRUD Made Simple

Think of generic editing views as having a smart assistant who specializes in paperwork. Instead of handling every form manually, your assistant knows exactly how to create new records, update existing ones, and safely delete what's no longer needed - all while following your organization's rules and procedures.

## The CRUD Trinity: Create, Update, Delete

Most web applications revolve around CRUD operations (Create, Read, Update, Delete). Django's generic editing views handle the CUD part beautifully, while display views handle the R (Read).

**Real-world analogy:** 
- **CreateView** = Hospital admissions desk (registering new patients)
- **UpdateView** = Patient records office (updating existing information)  
- **DeleteView** = Archive department (safely removing outdated records)

## CreateView: Birth Certificate for Your Data

`CreateView` is like having a specialized form processor who knows exactly how to create new database records from user input.

### Basic CreateView Magic
```python
from django.views.generic import CreateView
from django.urls import reverse_lazy
from .models import Book

class BookCreateView(CreateView):
    model = Book
    fields = ['title', 'author', 'isbn', 'publication_date', 'price']
    template_name = 'books/create.html'
    success_url = reverse_lazy('book-list')
```

**That's it!** This view automatically:
- Creates a Django form based on your model fields
- Handles GET requests (shows empty form)
- Handles POST requests (validates and saves data)
- Redirects on success
- Shows errors if validation fails

### Advanced CreateView Customization

#### Using a Custom Form
```python
from django import forms
from django.views.generic import CreateView

class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'isbn', 'publication_date', 'price']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter book title...'
            }),
            'publication_date': forms.DateInput(attrs={
                'type': 'date',
                'class': 'form-control'
            }),
            'price': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0',
                'step': '0.01'
            })
        }
    
    def clean_isbn(self):
        isbn = self.cleaned_data['isbn']
        if Book.objects.filter(isbn=isbn).exists():
            raise forms.ValidationError("A book with this ISBN already exists.")
        return isbn

class BookCreateView(CreateView):
    model = Book
    form_class = BookForm
    template_name = 'books/create.html'
    success_url = reverse_lazy('book-list')
    
    def form_valid(self, form):
        # Add custom logic before saving
        book = form.save(commit=False)
        book.added_by = self.request.user
        book.save()
        
        messages.success(self.request, f'Book "{book.title}" was created successfully!')
        return super().form_valid(form)
```

### Real-World CreateView Example: Blog Post Creation

```python
class PostCreateView(CreateView):
    model = Post
    fields = ['title', 'content', 'category', 'tags']
    template_name = 'blog/post_create.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['categories'] = Category.objects.all()
        context['page_title'] = 'Create New Post'
        return context
    
    def form_valid(self, form):
        form.instance.author = self.request.user
        form.instance.slug = slugify(form.instance.title)
        return super().form_valid(form)
    
    def get_success_url(self):
        return reverse_lazy('post-detail', kwargs={'pk': self.object.pk})
```

**Template (blog/post_create.html):**
```html
<div class="create-post-container">
    <h1>{{ page_title }}</h1>
    
    <form method="post" class="post-form">
        {% csrf_token %}
        
        <div class="form-group">
            <label for="{{ form.title.id_for_label }}">Title</label>
            {{ form.title }}
            {% if form.title.errors %}
                <div class="error-message">{{ form.title.errors }}</div>
            {% endif %}
        </div>
        
        <div class="form-group">
            <label for="{{ form.content.id_for_label }}">Content</label>
            {{ form.content }}
            {% if form.content.errors %}
                <div class="error-message">{{ form.content.errors }}</div>
            {% endif %}
        </div>
        
        <div class="form-group">
            <label for="{{ form.category.id_for_label }}">Category</label>
            {{ form.category }}
        </div>
        
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Create Post</button>
            <a href="{% url 'post-list' %}" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
```

## UpdateView: The Editor's Desk

`UpdateView` is like having a professional editor who can take existing content and help you refine it perfectly.

### Basic UpdateView Setup
```python
class BookUpdateView(UpdateView):
    model = Book
    fields = ['title', 'author', 'isbn', 'publication_date', 'price']
    template_name = 'books/update.html'
    success_url = reverse_lazy('book-list')
```

**Auto-magic features:**
- Automatically finds the object to edit by primary key
- Pre-populates form with current data
- Validates changes and updates database
- Handles all HTTP methods appropriately

### Advanced UpdateView with Permissions

```python
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin

class PostUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Post
    fields = ['title', 'content', 'category', 'tags']
    template_name = 'blog/post_update.html'
    
    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author
    
    def form_valid(self, form):
        form.instance.updated_at = timezone.now()
        messages.success(self.request, 'Post updated successfully!')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f'Edit: {self.object.title}'
        context['is_editing'] = True
        return context
```

**Restaurant analogy:** The UpdateView is like a restaurant where you can modify your order after placing it, but only if you're the one who originally ordered it (permission check).

### Smart UpdateView with Partial Updates

```python
class ProfileUpdateView(UpdateView):
    model = UserProfile  
    fields = ['bio', 'location', 'website', 'avatar']
    template_name = 'accounts/profile_update.html'
    
    def get_object(self):
        # Always edit the current user's profile
        return self.request.user.profile
    
    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        
        # Customize form based on user type
        if not self.request.user.is_premium:
            # Free users can't update certain fields
            del form.fields['website']
            
        return form
    
    def form_valid(self, form):
        # Track when profile was last updated
        form.instance.last_updated = timezone.now()
        form.instance.updated_by = self.request.user
        return super().form_valid(form)
```

## DeleteView: The Safe Disposal Expert

`DeleteView` is like having a security expert who ensures nothing important gets deleted accidentally and keeps detailed records of what was removed.

### Basic DeleteView Implementation
```python
class BookDeleteView(DeleteView):
    model = Book
    template_name = 'books/delete.html'
    success_url = reverse_lazy('book-list')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f'Delete "{self.object.title}"'
        return context
```

### Secure DeleteView with Confirmation

```python
class PostDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Post
    template_name = 'blog/post_delete.html'
    
    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author or self.request.user.is_superuser
    
    def delete(self, request, *args, **kwargs):
        post = self.get_object()
        post_title = post.title
        
        # Log the deletion
        logger.info(f'Post "{post_title}" deleted by {request.user}')
        
        # Send notification to author if deleted by admin
        if request.user != post.author:
            send_deletion_notification(post.author, post_title)
        
        messages.success(request, f'Post "{post_title}" was deleted successfully.')
        return super().delete(request, *args, **kwargs)
    
    def get_success_url(self):
        return reverse_lazy('user-posts', kwargs={'user_id': self.request.user.id})
```

**Template (blog/post_delete.html):**
```html
<div class="delete-confirmation">
    <h1>Delete Post</h1>
    
    <div class="warning-box">
        <h2>⚠️ Are you absolutely sure?</h2>
        <p>You are about to delete:</p>
        
        <div class="post-preview">
            <h3>"{{ object.title }}"</h3>
            <p>Published: {{ object.created_at|date:"F j, Y" }}</p>
            <p>Views: {{ object.view_count }}</p>
            <p>Comments: {{ object.comments.count }}</p>
        </div>
        
        <p><strong>This action cannot be undone.</strong> All comments and related data will also be removed.</p>
    </div>
    
    <form method="post" class="delete-form">
        {% csrf_token %}
        <div class="form-actions">
            <button type="submit" class="btn btn-danger">Yes, Delete Permanently</button>
            <a href="{% url 'post-detail' object.pk %}" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
```

## FormView: The Swiss Army Knife

`FormView` handles forms that don't directly map to model creation/editing - like contact forms, search forms, or multi-step wizards.

### Contact Form Example
```python
from django.core.mail import send_mail

class ContactForm(forms.Form):
    name = forms.CharField(max_length=100)
    email = forms.EmailField()
    subject = forms.CharField(max_length=200)
    message = forms.CharField(widget=forms.Textarea)
    
    def send_email(self):
        send_mail(
            subject=f"Contact Form: {self.cleaned_data['subject']}",
            message=self.cleaned_data['message'],
            from_email=self.cleaned_data['email'],
            recipient_list=['contact@example.com'],
            fail_silently=False,
        )

class ContactView(FormView):
    template_name = 'contact.html'
    form_class = ContactForm
    success_url = reverse_lazy('contact-success')
    
    def form_valid(self, form):
        # Send the email
        form.send_email()
        
        # Log the contact attempt
        ContactLog.objects.create(
            name=form.cleaned_data['name'],
            email=form.cleaned_data['email'],
            subject=form.cleaned_data['subject'],
            ip_address=self.request.META.get('REMOTE_ADDR')
        )
        
        messages.success(self.request, 'Thank you! Your message has been sent.')
        return super().form_valid(form)
```

## Advanced Patterns and Best Practices

### Pattern 1: AJAX Form Handling
```python
from django.http import JsonResponse

class AjaxBookCreateView(CreateView):
    model = Book
    form_class = BookForm
    
    def form_valid(self, form):
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            book = form.save()
            return JsonResponse({
                'success': True,
                'message': f'Book "{book.title}" created successfully!',
                'book_id': book.pk,
                'redirect_url': book.get_absolute_url()
            })
        return super().form_valid(form)
    
    def form_invalid(self, form):
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': False,
                'errors': form.errors
            })
        return super().form_invalid(form)
```

### Pattern 2: Multi-Step Form Wizard
```python
from django.contrib.formtools.wizard.views import SessionWizardView

class BookWizardView(SessionWizardView):
    template_name = 'books/wizard.html'
    form_list = [
        ('basic', BookBasicInfoForm),
        ('details', BookDetailsForm),
        ('publication', BookPublicationForm)
    ]
    
    def done(self, form_list, form_dict, **kwargs):
        # Combine all form data and create book
        book_data = {}
        for form in form_list:
            book_data.update(form.cleaned_data)
        
        book = Book.objects.create(**book_data)
        return redirect('book-detail', pk=book.pk)
    
    def get_context_data(self, form, **kwargs):
        context = super().get_context_data(form=form, **kwargs)
        context['step_titles'] = {
            'basic': 'Basic Information',
            'details': 'Book Details', 
            'publication': 'Publication Info'
        }
        return context
```

### Pattern 3: Bulk Operations
```python
class BulkBookUpdateView(FormView):
    template_name = 'books/bulk_update.html'
    form_class = BulkBookForm
    
    def form_valid(self, form):
        book_ids = form.cleaned_data['book_ids']
        action = form.cleaned_data['action']
        
        books = Book.objects.filter(id__in=book_ids)
        
        if action == 'mark_featured':
            books.update(is_featured=True)
            message = f'{books.count()} books marked as featured'
        elif action == 'change_category':
            category = form.cleaned_data['new_category']
            for book in books:
                book.categories.add(category)
            message = f'{books.count()} books updated'
        
        messages.success(self.request, message)
        return super().form_valid(form)
```

## Performance and Security Best Practices

### 1. Always Use CSRF Protection
```html
<!-- ✅ Always include CSRF token -->
<form method="post">
    {% csrf_token %}
    <!-- form fields -->
</form>
```

### 2. Validate User Permissions
```python
class SecureUpdateView(UserPassesTestMixin, UpdateView):
    def test_func(self):
        obj = self.get_object()
        return self.request.user == obj.owner or self.request.user.is_staff
```

### 3. Optimize Database Queries
```python
def get_queryset(self):
    return Book.objects.select_related('author', 'publisher').prefetch_related('categories')
```

### 4. Handle File Uploads Securely
```python
class BookCoverUpdateView(UpdateView):
    fields = ['cover_image']
    
    def form_valid(self, form):
        # Validate file type and size
        cover = form.cleaned_data['cover_image']
        if cover:
            if cover.size > 5 * 1024 * 1024:  # 5MB limit
                form.add_error('cover_image', 'File too large (max 5MB)')
                return self.form_invalid(form)
        
        return super().form_valid(form)
```

## Common Pitfalls and Solutions

### Pitfall 1: Forgetting Success URL
```python
# ❌ Will cause errors
class BookCreateView(CreateView):
    model = Book
    fields = ['title', 'author']
    # Missing success_url!

# ✅ Proper success handling
class BookCreateView(CreateView):
    model = Book
    fields = ['title', 'author']
    success_url = reverse_lazy('book-list')
    
    # Or implement get_absolute_url in model
    # Or override get_success_url method
```

### Pitfall 2: Security Vulnerabilities
```python
# ❌ Anyone can edit any book
class BookUpdateView(UpdateView):
    model = Book
    fields = ['title', 'author']

# ✅ Proper permission checks  
class BookUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Book
    fields = ['title', 'author']
    
    def test_func(self):
        book = self.get_object()
        return self.request.user == book.owner
```

## Practice Exercise: Complete Blog Management System

Build a full blog management system with:
1. Post creation (CreateView)
2. Post editing (UpdateView) 
3. Post deletion (DeleteView)
4. Comment moderation (FormView)
5. Bulk post management

This will give you hands-on experience with all editing views and prepare you for real-world applications!

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/class-based-views/generic-editing/
    ''',
    "is_free": False,
    "xp_reward": 80,
    "exercises": [
        {
            "id": "blog-management-system",
            "title": "Build Complete Blog Management System",
            "type": "project", 
            "instructions": """Create a comprehensive blog management system using generic editing views:

1. Post creation with custom validation
2. Post editing with permission checks  
3. Safe post deletion with confirmation
4. Comment moderation system
5. Bulk post operations

Your solution should demonstrate:
- All CRUD operations with appropriate views
- Form customization and validation
- User permission handling
- Success/error messaging
- Secure deletion with confirmations""",
            "starter_code": """# models.py (provided)
class Post(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_published = models.BooleanField(default=False)
    
class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    is_approved = models.BooleanField(default=False)

# Implement the editing views below:""",
            "solution": """from django.views.generic import CreateView, UpdateView, DeleteView, FormView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib import messages
from django.urls import reverse_lazy
from django.shortcuts import get_object_or_404

class PostCreateView(LoginRequiredMixin, CreateView):
    model = Post
    fields = ['title', 'content', 'is_published']
    template_name = 'blog/post_create.html'
    
    def form_valid(self, form):
        form.instance.author = self.request.user
        messages.success(self.request, 'Post created successfully!')
        return super().form_valid(form)

class PostUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Post
    fields = ['title', 'content', 'is_published']
    template_name = 'blog/post_update.html'
    
    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author
    
    def form_valid(self, form):
        messages.success(self.request, 'Post updated successfully!')
        return super().form_valid(form)

class PostDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Post
    template_name = 'blog/post_delete.html'
    success_url = reverse_lazy('post-list')
    
    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author
    
    def delete(self, request, *args, **kwargs):
        messages.success(request, 'Post deleted successfully!')
        return super().delete(request, *args, **kwargs)

class CommentModerationForm(forms.Form):
    comment_ids = forms.ModelMultipleChoiceField(
        queryset=Comment.objects.all(),
        widget=forms.CheckboxSelectMultiple
    )
    action = forms.ChoiceField(choices=[
        ('approve', 'Approve'),
        ('delete', 'Delete')
    ])

class CommentModerationView(LoginRequiredMixin, FormView):
    form_class = CommentModerationForm
    template_name = 'blog/comment_moderation.html'
    success_url = reverse_lazy('comment-moderation')
    
    def get_form(self):
        form = super().get_form()
        form.fields['comment_ids'].queryset = Comment.objects.filter(
            is_approved=False
        )
        return form
    
    def form_valid(self, form):
        comments = form.cleaned_data['comment_ids']
        action = form.cleaned_data['action']
        
        if action == 'approve':
            comments.update(is_approved=True)
            messages.success(self.request, f'{comments.count()} comments approved')
        elif action == 'delete':
            count = comments.count()
            comments.delete()
            messages.success(self.request, f'{count} comments deleted')
        
        return super().form_valid(form)""",
            "test_cases": [
                {
                    "name": "Views use appropriate mixins and permissions",
                    "input": "",
                    "expected_contains": ["LoginRequiredMixin", "UserPassesTestMixin", "test_func"]
                }
            ],
            "xp_reward": 120,
            "hints": [
                "Use LoginRequiredMixin for authentication",
                "Use UserPassesTestMixin for object-level permissions", 
                "Add success messages for user feedback",
                "Don't forget CSRF tokens in forms",
                "Implement proper success URLs"
            ]
        }
    ]
}