"""
SQL JOINs Basics lesson content
"""

SQL_JOINS_BASICS_LESSON = {
    "id": 34,
    "chapter": 34,
    "title": "SQL Multi-table Queries with JOINs",
    "slug": "sql-joins-basics", 
    "content": '''
# SQL JOINs: Connecting the Dots in Your Database

Think of SQL JOINs as connecting puzzle pieces to see the complete picture. Just as Instagram links users to their posts, Spotify connects songs to artists, and Netflix matches viewers to their watching history, JOINs allow you to combine related data from multiple tables to answer complex business questions.

## Understanding Relationships Between Tables

Real applications don't store everything in one massive table. Instead, they split data logically - like having separate contact lists for friends, work colleagues, and family, then connecting them when needed.

### Example: Social Media Platform Database Structure

**Users Table (social_users)**
```
+----+-----------+----------------+-------------+
| id | username  | email          | verified    |
+----+-----------+----------------+-------------+
| 1  | sarah_dev | sarah@email    | 1           |
| 2  | mike_photo| mike@email     | 0           |
| 3  | lisa_art  | lisa@email     | 1           |
| 4  | john_travel| john@email    | 0           |
+----+-----------+----------------+-------------+
```

**Posts Table (social_posts)**
```
+----+---------+-------------------+-------+--------+
| id | user_id | content           | likes | views  |
+----+---------+-------------------+-------+--------+
| 101| 1       | Learning SQL!     | 150   | 1200   |
| 102| 1       | Database design   | 89    | 890    |
| 103| 2       | Sunset photos     | 234   | 2100   |
| 104| 3       | Digital art       | 456   | 3200   |
| 105| 2       | Street photography| 178   | 1500   |
+----+---------+-------------------+-------+--------+
```

**Comments Table (social_comments)**
```
+----+---------+---------+------------------+
| id | post_id | user_id | comment_text     |
+----+---------+---------+------------------+
| 1  | 101     | 2       | Great explanation!|
| 2  | 101     | 3       | Very helpful     |
| 3  | 103     | 1       | Beautiful shot!  |
| 4  | 104     | 4       | Amazing artwork! |
+----+---------+---------+------------------+
```

## INNER JOIN: Finding Connected Data

INNER JOIN returns only records that have matches in both tables - like finding Instagram users who have actually posted content.

### Basic INNER JOIN Syntax
```sql
SELECT column1, column2
FROM table1
INNER JOIN table2 ON table1.id = table2.foreign_key_id;
```

### Real-World INNER JOIN Examples

**Find users and their posts (like browsing someone's Instagram profile):**
```sql
-- Basic user-posts connection
SELECT 
    u.username,
    u.verified,
    p.content,
    p.likes,
    p.views
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id;

-- This shows only users who have posted content
```

**Find posts with their authors' information:**
```sql
-- Post feed with author details (like Instagram feed)
SELECT 
    p.content,
    p.likes,
    p.views,
    u.username,
    u.verified
FROM social_posts p  
INNER JOIN social_users u ON p.user_id = u.id
ORDER BY p.likes DESC;
```

**Find comments with post and user information:**
```sql
-- Comment thread with context (like YouTube comments section)
SELECT 
    c.comment_text,
    u.username AS commenter,
    p.content AS post_content,
    p.likes AS post_likes
FROM social_comments c
INNER JOIN social_users u ON c.user_id = u.id  
INNER JOIN social_posts p ON c.post_id = p.id
ORDER BY p.id, c.id;
```

## Multiple Table JOINs: Complex Relationships

Real applications often need data from 3+ tables simultaneously, like showing TikTok comments with the commenter's profile info and the original video details.

### Three-Table JOIN Example
```sql
-- Complete social media feed with comments
SELECT 
    u.username AS author,
    u.verified AS author_verified,
    p.content,
    p.likes,
    p.views,
    c.comment_text,
    cu.username AS commenter
FROM social_posts p
INNER JOIN social_users u ON p.user_id = u.id
INNER JOIN social_comments c ON p.id = c.post_id  
INNER JOIN social_users cu ON c.user_id = cu.id
ORDER BY p.likes DESC, c.id;
```

## Real-World JOIN Scenarios

### E-commerce Platform (Amazon-style)
```sql
-- Product catalog with category and seller information
-- Tables: products, categories, sellers

SELECT 
    p.product_name,
    p.price,
    c.category_name,
    s.seller_name,
    s.seller_rating
FROM products p
INNER JOIN categories c ON p.category_id = c.id
INNER JOIN sellers s ON p.seller_id = s.id
WHERE p.price BETWEEN 50 AND 200
ORDER BY p.price ASC;
```

### Music Streaming Platform (Spotify-style)
```sql
-- Song library with artist and album information
-- Tables: songs, artists, albums

SELECT 
    s.title AS song_title,
    a.name AS artist_name, 
    al.title AS album_title,
    s.duration,
    s.play_count
FROM songs s
INNER JOIN artists a ON s.artist_id = a.id
INNER JOIN albums al ON s.album_id = al.id
WHERE s.play_count > 1000000
ORDER BY s.play_count DESC;
```

### Learning Platform (Khan Academy-style)
```sql
-- Course progress tracking
-- Tables: students, courses, enrollments, lessons

SELECT 
    st.student_name,
    c.course_title,
    l.lesson_title,
    e.completion_date,
    e.grade
FROM enrollments e
INNER JOIN students st ON e.student_id = st.id
INNER JOIN courses c ON e.course_id = c.id  
INNER JOIN lessons l ON e.lesson_id = l.id
WHERE e.completion_date IS NOT NULL
ORDER BY e.completion_date DESC;
```

## JOIN with WHERE Conditions

Combining JOINs with filtering creates powerful analytical queries.

### Filtered Social Media Analytics
```sql
-- Find viral posts by verified users
SELECT 
    u.username,
    u.verified,
    p.content,
    p.likes,
    p.views,
    (p.likes * 100.0 / p.views) AS engagement_rate
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id
WHERE u.verified = 1 
  AND p.likes > 200
ORDER BY engagement_rate DESC;

-- Find most commented posts  
SELECT 
    u.username,
    p.content,
    p.likes,
    COUNT(c.id) AS comment_count
FROM social_posts p
INNER JOIN social_users u ON p.user_id = u.id
INNER JOIN social_comments c ON p.id = c.post_id
GROUP BY u.username, p.content, p.likes
HAVING COUNT(c.id) > 1
ORDER BY comment_count DESC;
```

### Business Intelligence Queries
```sql
-- E-commerce: Find best-selling products by category
SELECT 
    c.category_name,
    p.product_name,
    SUM(oi.quantity) AS total_sold,
    SUM(oi.quantity * p.price) AS total_revenue
FROM products p
INNER JOIN categories c ON p.category_id = c.id
INNER JOIN order_items oi ON p.id = oi.product_id
INNER JOIN orders o ON oi.order_id = o.id
WHERE o.order_date >= '2024-01-01'
GROUP BY c.category_name, p.product_name
ORDER BY total_revenue DESC;
```

## Aliases and Readable JOIN Syntax

Clean, readable JOINs are essential for maintenance and collaboration.

### Good Alias Practices
```sql
-- ✅ Clear, meaningful aliases
SELECT 
    user.username,
    post.content,
    post.likes,
    commenter.username AS commenter_name,
    comment.comment_text
FROM social_users user
INNER JOIN social_posts post ON user.id = post.user_id
INNER JOIN social_comments comment ON post.id = comment.post_id
INNER JOIN social_users commenter ON comment.user_id = commenter.id;

-- ❌ Cryptic aliases
SELECT u1.username, p.content, u2.username, c.comment_text
FROM social_users u1
INNER JOIN social_posts p ON u1.id = p.user_id
INNER JOIN social_comments c ON p.id = c.post_id  
INNER JOIN social_users u2 ON c.user_id = u2.id;
```

## Common JOIN Patterns by Industry

### Social Media Analytics
```sql
-- User engagement analysis (Instagram/TikTok style)
SELECT 
    u.username,
    COUNT(p.id) AS post_count,
    SUM(p.likes) AS total_likes,
    AVG(p.likes) AS avg_likes_per_post
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id
WHERE u.verified = 1
GROUP BY u.username
ORDER BY total_likes DESC;
```

### Content Platform Analysis  
```sql
-- Video performance by channel (YouTube style)
SELECT 
    ch.channel_name,
    COUNT(v.id) AS video_count,
    SUM(v.views) AS total_views,
    AVG(v.duration) AS avg_duration
FROM channels ch
INNER JOIN videos v ON ch.id = v.channel_id
WHERE v.upload_date >= '2024-01-01'
GROUP BY ch.channel_name
ORDER BY total_views DESC;
```

### E-commerce Analysis
```sql
-- Customer purchase analysis (Amazon style)
SELECT 
    c.customer_name,
    c.email,
    COUNT(o.id) AS order_count,
    SUM(o.total_amount) AS total_spent,
    MAX(o.order_date) AS last_order_date
FROM customers c
INNER JOIN orders o ON c.id = o.customer_id
WHERE o.order_date >= '2024-01-01'
GROUP BY c.customer_name, c.email
HAVING total_spent > 500
ORDER BY total_spent DESC;
```

## Performance Tips for JOINs

### Efficient JOIN Patterns
```sql
-- ✅ Join on indexed columns (usually primary/foreign keys)
SELECT u.username, p.content  
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id;  -- id columns are indexed

-- ✅ Filter early to reduce dataset size
SELECT u.username, p.content
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id
WHERE u.verified = 1  -- Filter reduces data before processing
  AND p.likes > 100;
```

### Avoid Cartesian Products
```sql
-- ❌ Missing JOIN condition creates cartesian product
SELECT u.username, p.content
FROM social_users u, social_posts p;  -- Every user paired with every post!

-- ✅ Always specify JOIN conditions
SELECT u.username, p.content
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id;
```

## Troubleshooting Common JOIN Issues

### 1. No Results from JOIN
```sql
-- Problem: INNER JOIN returns nothing
-- Reason: No matching records between tables
-- Solution: Check foreign key relationships and data

-- Debug query: Check if relationships exist
SELECT COUNT(*) FROM social_users;  -- How many users?
SELECT COUNT(*) FROM social_posts;  -- How many posts?  
SELECT COUNT(DISTINCT user_id) FROM social_posts;  -- How many users have posts?
```

### 2. Duplicate Results
```sql
-- Problem: Getting more rows than expected
-- Reason: One-to-many relationships create multiple rows
-- Solution: Use GROUP BY or DISTINCT if needed

-- Example: User with multiple posts creates multiple rows
SELECT DISTINCT u.username, u.verified
FROM social_users u  
INNER JOIN social_posts p ON u.id = p.user_id;
```

### 3. Ambiguous Column Names
```sql
-- ❌ Error: Column 'id' is ambiguous  
SELECT id, username, content
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id;

-- ✅ Specify which table's id column
SELECT u.id, u.username, p.content
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id;
```

## Next Steps: LEFT JOIN and OUTER JOINs

INNER JOINs show you connected data, but what about users who haven't posted yet, or products with no orders? That's where OUTER JOINs come in - they show you the complete picture, including missing connections.

JOINs transform isolated data islands into a connected information ecosystem. Master these patterns, and you'll be able to analyze user behavior across platforms, track customer journeys through purchase funnels, or build recommendation engines that power the world's most successful applications! 🔗📊
    ''',
    "is_free": False,
    "xp_reward": 110,
    "exercises": [
        {
            "id": "social-media-joins",
            "title": "Social Media Platform JOINs",
            "type": "practice", 
            "instructions": """Practice INNER JOINs using social media platform data to connect users, posts, and comments.

Your tasks:
1. First explore each table: SELECT * FROM social_users; SELECT * FROM social_posts; SELECT * FROM social_comments;
2. Join users and posts to show who posted what
3. Find posts with their author information, sorted by likes
4. Join all three tables to show comments with post and user context
5. Find verified users and their most liked posts
6. Count how many posts each user has made

Tables:
- social_users: id, username, email, verified
- social_posts: id, user_id, content, likes, views  
- social_comments: id, post_id, user_id, comment_text""",
            "starter_code": """-- Task 1: Explore each table structure
SELECT * FROM social_users;
-- Also explore social_posts and social_comments tables

-- Task 2: Join users and posts to show who posted what
-- Use INNER JOIN to connect social_users and social_posts


-- Task 3: Find posts with author info, sorted by likes DESC
-- Join posts and users, order by likes descending


-- Task 4: Three-table JOIN - comments with post and user context
-- Join social_comments, social_posts, and social_users to show complete comment context


-- Task 5: Find verified users and their highest-liked posts
-- Join users and posts, filter for verified = 1, order by likes DESC


-- Task 6: Count posts per user
-- Use JOIN with GROUP BY to count how many posts each user has made
""",
            "solution": """-- Task 1: Explore each table structure
SELECT * FROM social_users;
SELECT * FROM social_posts; 
SELECT * FROM social_comments;

-- Task 2: Join users and posts to show who posted what
SELECT 
    u.username,
    u.verified,
    p.content,
    p.likes,
    p.views
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id;

-- Task 3: Find posts with author info, sorted by likes DESC
SELECT 
    p.content,
    p.likes,
    p.views,
    u.username,
    u.verified
FROM social_posts p
INNER JOIN social_users u ON p.user_id = u.id
ORDER BY p.likes DESC;

-- Task 4: Three-table JOIN - comments with post and user context
SELECT 
    c.comment_text,
    u.username AS commenter,
    p.content AS post_content,
    p.likes AS post_likes,
    pu.username AS post_author
FROM social_comments c
INNER JOIN social_users u ON c.user_id = u.id
INNER JOIN social_posts p ON c.post_id = p.id
INNER JOIN social_users pu ON p.user_id = pu.id
ORDER BY p.likes DESC;

-- Task 5: Find verified users and their highest-liked posts
SELECT 
    u.username,
    u.verified,
    p.content,
    p.likes,
    p.views
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id
WHERE u.verified = 1
ORDER BY p.likes DESC;

-- Task 6: Count posts per user  
SELECT 
    u.username,
    u.verified,
    COUNT(p.id) AS post_count,
    SUM(p.likes) AS total_likes
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id
GROUP BY u.username, u.verified
ORDER BY post_count DESC;""",
            "test_cases": [
                {
                    "name": "Basic INNER JOIN syntax",
                    "input": "SELECT u.username, p.content FROM social_users u INNER JOIN social_posts p ON u.id = p.user_id;",
                    "expected_contains": ["INNER JOIN", "ON", "u.id", "p.user_id"]
                },
                {
                    "name": "Three-table JOIN",
                    "input": "SELECT * FROM social_comments c INNER JOIN social_users u ON c.user_id = u.id INNER JOIN social_posts p ON c.post_id = p.id;", 
                    "expected_contains": ["INNER JOIN", "social_comments", "social_users", "social_posts"]
                }
            ],
            "xp_reward": 75,
            "hints": [
                "Use table aliases (u, p, c) to make queries more readable",
                "Always specify the JOIN condition with ON table1.id = table2.foreign_key_id",
                "For three-table JOINs, connect each table pair with their relationship keys",
                "GROUP BY is needed when using aggregate functions like COUNT()",
                "ORDER BY comes after GROUP BY in query structure"
            ]
        },
        {
            "id": "ecommerce-analytics-joins",
            "title": "E-commerce Analytics with Multiple JOINs",
            "type": "practice",
            "instructions": """Practice complex JOINs using e-commerce data to analyze products, orders, and customer behavior.

Your tasks:
1. Explore the table structures first
2. Join products and categories to show product catalog
3. Find orders with customer information
4. Create a complete order analysis (customer, product, category)
5. Find top-selling products by category
6. Analyze customer purchase patterns

Tables:
- customers: id, name, email, city
- orders: id, customer_id, order_date, total_amount
- order_items: id, order_id, product_id, quantity, price  
- products: id, name, category_id, price
- categories: id, name""",
            "starter_code": """-- Task 1: Explore table structures
SELECT * FROM customers LIMIT 3;
-- Explore other tables: orders, order_items, products, categories

-- Task 2: Join products and categories for product catalog
-- Show product name, price, and category name


-- Task 3: Join orders and customers to show order history
-- Show customer name, order date, and total amount


-- Task 4: Complete order analysis with customer, product, and category
-- Join all relevant tables to show customer, product, category, quantity


-- Task 5: Find top-selling products by category  
-- Use JOINs and GROUP BY to sum quantities sold per product


-- Task 6: Analyze customer purchase patterns
-- Show customer name, total orders, total spent, average order amount
""",
            "solution": """-- Task 1: Explore table structures
SELECT * FROM customers LIMIT 3;
SELECT * FROM orders LIMIT 3;
SELECT * FROM order_items LIMIT 3;  
SELECT * FROM products LIMIT 3;
SELECT * FROM categories LIMIT 3;

-- Task 2: Join products and categories for product catalog
SELECT 
    p.name AS product_name,
    p.price,
    c.name AS category_name
FROM products p
INNER JOIN categories c ON p.category_id = c.id
ORDER BY c.name, p.name;

-- Task 3: Join orders and customers to show order history
SELECT 
    cust.name AS customer_name,
    cust.email,
    o.order_date,
    o.total_amount
FROM orders o
INNER JOIN customers cust ON o.customer_id = cust.id
ORDER BY o.order_date DESC;

-- Task 4: Complete order analysis
SELECT 
    cust.name AS customer_name,
    p.name AS product_name,
    cat.name AS category_name,
    oi.quantity,
    oi.price,
    o.order_date
FROM order_items oi
INNER JOIN orders o ON oi.order_id = o.id
INNER JOIN customers cust ON o.customer_id = cust.id
INNER JOIN products p ON oi.product_id = p.id
INNER JOIN categories cat ON p.category_id = cat.id
ORDER BY o.order_date DESC;

-- Task 5: Find top-selling products by category
SELECT 
    cat.name AS category_name,
    p.name AS product_name,
    SUM(oi.quantity) AS total_sold,
    SUM(oi.quantity * oi.price) AS total_revenue
FROM order_items oi
INNER JOIN products p ON oi.product_id = p.id
INNER JOIN categories cat ON p.category_id = cat.id
GROUP BY cat.name, p.name
ORDER BY cat.name, total_sold DESC;

-- Task 6: Analyze customer purchase patterns
SELECT 
    c.name AS customer_name,
    c.email,
    COUNT(o.id) AS total_orders,
    SUM(o.total_amount) AS total_spent,
    AVG(o.total_amount) AS avg_order_amount,
    MAX(o.order_date) AS last_order_date
FROM customers c
INNER JOIN orders o ON c.id = o.customer_id
GROUP BY c.name, c.email
ORDER BY total_spent DESC;""",
            "test_cases": [
                {
                    "name": "Product catalog JOIN",
                    "input": "SELECT p.name, c.name FROM products p INNER JOIN categories c ON p.category_id = c.id;",
                    "expected_contains": ["products", "categories", "INNER JOIN", "category_id"]
                },
                {
                    "name": "Multi-table analysis with GROUP BY",
                    "input": "SELECT c.name, SUM(o.total_amount) FROM customers c INNER JOIN orders o ON c.id = o.customer_id GROUP BY c.name;",
                    "expected_contains": ["SUM", "GROUP BY", "INNER JOIN"]
                }
            ],
            "xp_reward": 85,
            "hints": [
                "Start with simple two-table JOINs, then build up to more complex ones",
                "Use meaningful aliases for tables (cust, cat, oi) to avoid confusion", 
                "When joining multiple tables, trace the foreign key relationships carefully",
                "GROUP BY is essential when using aggregate functions like SUM() and COUNT()",
                "ORDER BY can use calculated columns like total_sold for meaningful sorting"
            ]
        }
    ]
}