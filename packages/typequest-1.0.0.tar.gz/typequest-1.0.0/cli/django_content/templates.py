"""
Django Templates and Frontend lesson content
"""

DJANGO_TEMPLATES_LESSON = {
    "id": 4,
    "chapter": 4,
    "title": "Django Templates and Frontend",
    "slug": "django-templates",
    "content": '''
# Django Templates and Frontend: Crafting Beautiful User Experiences

Django templates are where your data transforms into beautiful, interactive web pages. They're the presentation layer that users see and interact with - the final step in turning your application logic into engaging user experiences.

## What are Django Templates? Your Presentation Powerhouse

Django Templates are sophisticated text files that use the Django Template Language (DTL) to create dynamic, data-driven HTML. They're not just static HTML files - they're intelligent documents that can make decisions, loop through data, and adapt their content based on user context.

**Templates Bridge Data and Design:**
- Transform raw data into formatted, styled content
- Apply conditional logic to show/hide elements
- Loop through collections to display lists and tables
- Include reusable components to maintain consistency
- Handle user input and form rendering securely

### The Template Philosophy: Smart Separation

Django templates embody the principle of separation of concerns - they focus purely on presentation while leaving data logic to views and business logic to models. This creates cleaner, more maintainable applications where designers and developers can work in parallel.

### Why Templates Matter

Templates provide:
- **Separation of concerns**: Keep HTML separate from Python code
- **Reusability**: Share common layouts across pages
- **Dynamic content**: Display database data in HTML
- **Template inheritance**: Build complex layouts efficiently
- **Security**: Automatic escaping prevents XSS attacks

## Template Syntax

### Variables

Display data from your views using double curly braces:

```html
<h1>{{ book.title }}</h1>
<p>Author: {{ book.author }}</p>
<p>Price: ${{ book.price }}</p>
```

### Tags

Control template logic with curly brace percent syntax:

```html
<!-- Conditional logic -->
{% if book.available %}
    <span class="badge badge-success">Available</span>
{% else %}
    <span class="badge badge-danger">Out of Stock</span>
{% endif %}

<!-- Loops -->
{% for book in books %}
    <div class="book-item">
        <h3>{{ book.title }}</h3>
        <p>{{ book.author }}</p>
    </div>
{% empty %}
    <p>No books available.</p>
{% endfor %}
```

### Filters

Transform variables with the pipe symbol:

```html
<!-- Text formatting -->
<h1>{{ book.title|upper }}</h1>
<p>{{ book.description|truncatewords:20 }}</p>

<!-- Date formatting -->
<p>Published: {{ book.publication_date|date:"F d, Y" }}</p>

<!-- Number formatting -->
<p>Price: ${{ book.price|floatformat:2 }}</p>
```

## Template Structure

### Base Template

Create a base template for common layout:

```html
<!-- books/templates/books/base.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{% block title %}Bookstore{% endblock %}</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    {% block extra_css %}{% endblock %}
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="{% url 'books:book-list' %}">📚 Bookstore</a>
            
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="{% url 'books:book-list' %}">Books</a>
                <a class="nav-link" href="{% url 'books:book-search' %}">Search</a>
            </div>
        </div>
    </nav>

    <!-- Main content -->
    <main class="container mt-4">
        {% block content %}
        {% endblock %}
    </main>

    <!-- Footer -->
    <footer class="bg-light mt-5 py-4">
        <div class="container text-center">
            <p>&copy; 2024 Bookstore. Built with Django.</p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    {% block extra_js %}{% endblock %}
</body>
</html>
```

### Child Templates

Extend the base template:

```html
<!-- books/templates/books/book_list.html -->
{% extends 'books/base.html' %}

{% block title %}All Books - {{ block.super }}{% endblock %}

{% block content %}
<div class="row">
    <div class="col-md-12">
        <h1>Our Book Collection</h1>
        <p class="text-muted">{{ books|length }} book{{ books|length|pluralize }} available</p>
        
        <div class="row">
            {% for book in books %}
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">{{ book.title }}</h5>
                            <p class="card-text">
                                <strong>Author:</strong> {{ book.author }}<br>
                                <strong>Pages:</strong> {{ book.pages }}<br>
                                <strong>Price:</strong> ${{ book.price }}
                            </p>
                            
                            {% if book.available %}
                                <span class="badge bg-success">Available</span>
                            {% else %}
                                <span class="badge bg-danger">Out of Stock</span>
                            {% endif %}
                            
                            <div class="mt-2">
                                <a href="{% url 'books:book-detail' book.id %}" class="btn btn-primary btn-sm">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            {% empty %}
                <div class="col-12">
                    <div class="alert alert-info">
                        <h4>No books available</h4>
                        <p>Check back later for new additions to our collection.</p>
                    </div>
                </div>
            {% endfor %}
        </div>
    </div>
</div>
{% endblock %}
```

### Detail Template

```html
<!-- books/templates/books/book_detail.html -->
{% extends 'books/base.html' %}

{% block title %}{{ book.title }} - {{ block.super }}{% endblock %}

{% block content %}
<div class="row">
    <div class="col-md-8">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{% url 'books:book-list' %}">Books</a></li>
                <li class="breadcrumb-item active">{{ book.title|truncatechars:30 }}</li>
            </ol>
        </nav>
        
        <h1>{{ book.title }}</h1>
        
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Author:</strong> {{ book.author }}</p>
                        <p><strong>ISBN:</strong> {{ book.isbn }}</p>
                        <p><strong>Pages:</strong> {{ book.pages }}</p>
                        <p><strong>Published:</strong> {{ book.publication_date|date:"F d, Y" }}</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Price:</strong> ${{ book.price }}</p>
                        <p><strong>Status:</strong> 
                            {% if book.available %}
                                <span class="badge bg-success">Available</span>
                            {% else %}
                                <span class="badge bg-danger">Out of Stock</span>
                            {% endif %}
                        </p>
                        <p><strong>Added:</strong> {{ book.created_at|date:"M d, Y" }}</p>
                    </div>
                </div>
                
                {% if book.description %}
                    <hr>
                    <h5>Description</h5>
                    <p>{{ book.description|linebreaks }}</p>
                {% endif %}
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5>Actions</h5>
            </div>
            <div class="card-body">
                {% if book.available %}
                    <button class="btn btn-success btn-block mb-2">Add to Cart</button>
                {% endif %}
                <a href="{% url 'books:book-list' %}" class="btn btn-outline-secondary btn-block">Back to Books</a>
            </div>
        </div>
    </div>
</div>
{% endblock %}
```

## Static Files

### Organizing Static Files

```
books/
    static/
        books/
            css/
                styles.css
            js/
                scripts.js
            images/
                book-placeholder.png
```

### Loading Static Files

```html
<!-- At the top of your template -->
{% load static %}

<!-- In your HTML -->
<link rel="stylesheet" href="{% static 'books/css/styles.css' %}">
<script src="{% static 'books/js/scripts.js' %}"></script>
<img src="{% static 'books/images/book-placeholder.png' %}" alt="Book">
```

## URL Reversing

Always use URL names instead of hardcoding paths:

```html
<!-- Good: Using URL names -->
<a href="{% url 'books:book-list' %}">All Books</a>
<a href="{% url 'books:book-detail' book.id %}">{{ book.title }}</a>

<!-- Bad: Hardcoded URLs -->
<a href="/books/">All Books</a>
<a href="/books/{{ book.id }}/">{{ book.title }}</a>
```

## Template Context

### Passing Data from Views

```python
# books/views.py
def book_list(request):
    books = Book.objects.filter(available=True)
    context = {
        'books': books,
        'total_books': books.count(),
        'page_title': 'Our Book Collection',
        'featured_categories': ['Fiction', 'Science', 'Biography']
    }
    return render(request, 'books/book_list.html', context)
```

### Accessing Context in Templates

```html
<h1>{{ page_title }}</h1>
<p>Total: {{ total_books }} book{{ total_books|pluralize }}</p>

<h3>Featured Categories</h3>
<ul>
    {% for category in featured_categories %}
        <li>{{ category }}</li>
    {% endfor %}
</ul>
```

## Common Template Patterns

### Pagination

```html
{% if is_paginated %}
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            {% if page_obj.has_previous %}
                <li class="page-item">
                    <a class="page-link" href="?page=1">&laquo; First</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="?page={{ page_obj.previous_page_number }}">Previous</a>
                </li>
            {% endif %}
            
            <li class="page-item active">
                <span class="page-link">
                    Page {{ page_obj.number }} of {{ page_obj.paginator.num_pages }}
                </span>
            </li>
            
            {% if page_obj.has_next %}
                <li class="page-item">
                    <a class="page-link" href="?page={{ page_obj.next_page_number }}">Next</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="?page={{ page_obj.paginator.num_pages }}">Last &raquo;</a>
                </li>
            {% endif %}
        </ul>
    </nav>
{% endif %}
```

### Search Results

```html
{% if query %}
    <div class="alert alert-info">
        <strong>Search Results for "{{ query }}"</strong>
        {% if books %}
            - {{ books|length }} book{{ books|length|pluralize }} found
        {% else %}
            - No books found
        {% endif %}
    </div>
{% endif %}
```

## Best Practices

1. **Use template inheritance**: Create a base template and extend it
2. **Keep templates simple**: Complex logic belongs in views
3. **Use meaningful names**: Clear template and block names
4. **Escape user input**: Django auto-escapes, but be aware
5. **Organize templates**: Use app-specific template directories
6. **Use static files**: Don't inline CSS/JS in templates
7. **Test across devices**: Ensure responsive design

## What's Next?

In the next lesson, we'll explore Django Forms - a powerful system for handling user input, validation, and rendering HTML forms.

Templates show the data, forms collect the data! 📝
    ''',
    "is_free": True,
    "xp_reward": 40,
    "exercises": [
        {
            "id": "django-templates",
            "title": "Create Book Template System",
            "type": "project",
            "instructions": '''Create a complete template system for your bookstore application.

Create these template files:

1. books/templates/books/base.html - Base template with:
   - HTML5 structure
   - Bootstrap CSS/JS
   - Navigation menu
   - Footer
   - Block areas for title, content, and extra CSS/JS

2. books/templates/books/book_list.html - Book listing page with:
   - Grid layout showing books
   - Book cards with title, author, price
   - Available/Out of Stock badges
   - Links to book detail pages

3. books/templates/books/book_detail.html - Book detail page with:
   - Complete book information
   - Breadcrumb navigation
   - Responsive layout
   - Action buttons

Use proper Django template syntax with variables, tags, filters, and URL reversing.''',
            "starter_code": '''<!-- books/templates/books/base.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>{% block title %}{% endblock %}</title>
    <!-- Add Bootstrap CSS and other head elements -->
</head>
<body>
    <!-- Add navigation here -->
    
    <main class="container mt-4">
        {% block content %}
        {% endblock %}
    </main>
    
    <!-- Add footer and Bootstrap JS -->
</body>
</html>''',
            "solution": '''<!-- books/templates/books/base.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{% block title %}Bookstore{% endblock %}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    {% block extra_css %}{% endblock %}
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="{% url 'books:book-list' %}">📚 Bookstore</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="{% url 'books:book-list' %}">Books</a>
                <a class="nav-link" href="{% url 'books:book-search' %}">Search</a>
            </div>
        </div>
    </nav>
    
    <main class="container mt-4">
        {% block content %}
        {% endblock %}
    </main>
    
    <footer class="bg-light mt-5 py-4">
        <div class="container text-center">
            <p>&copy; 2024 Bookstore. Built with Django.</p>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    {% block extra_js %}{% endblock %}
</body>
</html>

<!-- books/templates/books/book_list.html -->
{% extends 'books/base.html' %}

{% block title %}All Books - {{ block.super }}{% endblock %}

{% block content %}
<h1>Our Book Collection</h1>
<p class="text-muted">{{ books|length }} book{{ books|length|pluralize }} available</p>

<div class="row">
    {% for book in books %}
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">{{ book.title }}</h5>
                    <p class="card-text">
                        <strong>Author:</strong> {{ book.author }}<br>
                        <strong>Price:</strong> ${{ book.price }}
                    </p>
                    {% if book.available %}
                        <span class="badge bg-success">Available</span>
                    {% else %}
                        <span class="badge bg-danger">Out of Stock</span>
                    {% endif %}
                    <div class="mt-2">
                        <a href="{% url 'books:book-detail' book.id %}" class="btn btn-primary btn-sm">View Details</a>
                    </div>
                </div>
            </div>
        </div>
    {% empty %}
        <div class="col-12">
            <div class="alert alert-info">
                <p>No books available at this time.</p>
            </div>
        </div>
    {% endfor %}
</div>
{% endblock %}''',
            "test_cases": [
                {
                    "name": "Complete template system implemented",
                    "input": "",
                    "expected_contains": ["{% extends", "{% url", "{% for book in books", "{% if book.available", "{{ book.title }}"]
                }
            ],
            "xp_reward": 60,
            "hints": [
                "Use {% extends %} in child templates to inherit from base",
                "Use {% url %} tags for all links, never hardcode URLs",
                "Handle empty states with {% empty %} or {% if %} conditions",
                "Use Bootstrap classes for responsive design",
                "Don't forget the {% load static %} tag if using static files"
            ]
        }
    ]
}