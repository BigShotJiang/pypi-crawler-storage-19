"""
Django Views and URL Routing lesson content
"""

DJANGO_VIEWS_LESSON = {
    "id": 3,
    "chapter": 3,
    "title": "Django Views and URL Routing",
    "slug": "django-views",
    "content": '''
# Django Views and URL Routing: The Request-Response Engine

Views are Django's traffic controllers - they receive incoming requests, process them according to your business logic, and return appropriate responses. Every URL in your application connects to a view, making them the bridge between user actions and application responses.

## What are Django Views? Your Application's Brain

A view is a Python function (or class) that takes a web request and returns a web response. But views are much more than simple request handlers - they're where your application's logic lives, decisions are made, and user experiences are crafted.

**Views Handle the Full Request Lifecycle:**
- Receive and validate incoming requests
- Extract and process request data  
- Apply business logic and data transformations
- Prepare data for presentation
- Return formatted responses (HTML, JSON, redirects, etc.)

### The Power of Django Views

Views are where Django's "batteries included" philosophy really shines. You get powerful tools for handling common patterns like authentication, pagination, forms processing, and error handling - all with minimal code.

### View Types

Django supports two types of views:
- **Function-Based Views (FBV)**: Simple Python functions
- **Class-Based Views (CBV)**: Python classes that inherit from Django's view classes

## Function-Based Views

### Basic View Structure

```python
# books/views.py
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Book

def book_list(request):
    books = Book.objects.filter(available=True)
    context = {
        'books': books,
        'total_books': books.count()
    }
    return render(request, 'books/book_list.html', context)

def book_detail(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    context = {'book': book}
    return render(request, 'books/book_detail.html', context)
```

### HTTP Request Object

The request object contains:
- `request.method`: HTTP method (GET, POST, etc.)
- `request.GET`: GET parameters
- `request.POST`: POST data
- `request.user`: Current user
- `request.session`: Session data

### HTTP Response Types

```python
from django.http import HttpResponse, JsonResponse, Http404
from django.shortcuts import redirect

# Text response
def simple_view(request):
    return HttpResponse("Hello, World!")

# JSON response
def api_view(request):
    data = {'message': 'Hello, API!'}
    return JsonResponse(data)

# Redirect
def redirect_view(request):
    return redirect('book-list')

# 404 Error
def not_found_view(request):
    raise Http404("Page not found")
```

## URL Routing

### App URLs

```python
# books/urls.py
from django.urls import path
from . import views

app_name = 'books'
urlpatterns = [
    path('', views.book_list, name='book-list'),
    path('<int:book_id>/', views.book_detail, name='book-detail'),
    path('search/', views.book_search, name='book-search'),
    path('category/<slug:category_slug>/', views.books_by_category, name='books-by-category'),
]
```

### Project URLs

```python
# bookstore/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('books/', include('books.urls')),
    path('', views.home, name='home'),
]
```

### URL Parameters

Django supports several parameter types:
- `<int:id>`: Integer
- `<slug:slug>`: Slug (letters, numbers, hyphens, underscores)
- `<str:name>`: String (any non-empty string, excluding '/')
- `<uuid:id>`: UUID
- `<path:path>`: String including '/'

## Class-Based Views

### Generic Views

Django provides pre-built class-based views:

```python
from django.views.generic import ListView, DetailView
from .models import Book

class BookListView(ListView):
    model = Book
    template_name = 'books/book_list.html'
    context_object_name = 'books'
    queryset = Book.objects.filter(available=True)
    paginate_by = 10

class BookDetailView(DetailView):
    model = Book
    template_name = 'books/book_detail.html'
    context_object_name = 'book'
```

### Custom Class-Based Views

```python
from django.views import View
from django.http import JsonResponse

class BookAPIView(View):
    def get(self, request):
        books = Book.objects.all()
        data = [{'title': book.title, 'author': book.author} for book in books]
        return JsonResponse(data, safe=False)
    
    def post(self, request):
        # Handle POST request
        pass
```

## Request Processing

### GET Requests

```python
def book_search(request):
    query = request.GET.get('q', '')
    category = request.GET.get('category', '')
    
    books = Book.objects.all()
    
    if query:
        books = books.filter(title__icontains=query)
    
    if category:
        books = books.filter(category=category)
    
    context = {
        'books': books,
        'query': query,
        'category': category
    }
    return render(request, 'books/search.html', context)
```

### POST Requests

```python
def add_book(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        author = request.POST.get('author')
        
        book = Book.objects.create(
            title=title,
            author=author,
            # ... other fields
        )
        
        return redirect('books:book-detail', book_id=book.id)
    
    return render(request, 'books/add_book.html')
```

## Error Handling

### Custom Error Pages

```python
# views.py
from django.shortcuts import render

def handler404(request, exception):
    return render(request, '404.html', status=404)

def handler500(request):
    return render(request, '500.html', status=500)
```

### Try-Except in Views

```python
def book_detail(request, book_id):
    try:
        book = Book.objects.get(id=book_id)
    except Book.DoesNotExist:
        raise Http404("Book not found")
    
    return render(request, 'books/book_detail.html', {'book': book})
```

## Best Practices

1. **Keep views simple**: Business logic should be in models or separate modules
2. **Use get_object_or_404**: Cleaner than try-except for single objects
3. **Always validate input**: Never trust user data
4. **Use appropriate HTTP methods**: GET for reading, POST for modifications
5. **Follow naming conventions**: Descriptive view and URL names

## What's Next?

In the next lesson, we'll dive into Django Templates - the presentation layer that generates HTML dynamically.

Views process the data, templates show the data! 📝
    ''',
    "is_free": True,
    "xp_reward": 35,
    "exercises": [
        {
            "id": "django-views",
            "title": "Create Book Views",
            "type": "python", 
            "instructions": "Create a complete set of views for managing books including list, detail, and search functionality.",
            "starter_code": "from django.shortcuts import render\nfrom .models import Book\n\ndef book_list(request):\n    # Implement book list view\n    pass",
            "solution": "from django.shortcuts import render, get_object_or_404\nfrom .models import Book\n\ndef book_list(request):\n    books = Book.objects.filter(available=True)\n    return render(request, 'books/book_list.html', {'books': books})\n\ndef book_detail(request, book_id):\n    book = get_object_or_404(Book, id=book_id)\n    return render(request, 'books/book_detail.html', {'book': book})",
            "test_cases": [
                {
                    "name": "Views implemented correctly",
                    "input": "",
                    "expected_contains": ["def book_list", "def book_detail", "render"]
                }
            ],
            "xp_reward": 45,
            "hints": [
                "Import render and get_object_or_404 from django.shortcuts",
                "Filter books by available=True for the list view", 
                "Use get_object_or_404 to handle missing books gracefully",
                "Pass context data to templates as a dictionary"
            ]
        }
    ]
}