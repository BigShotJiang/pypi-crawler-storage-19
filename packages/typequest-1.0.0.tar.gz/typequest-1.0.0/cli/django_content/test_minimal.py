DJANGO_RAW_SQL_LESSON = {
    "id": 45,
    "chapter": 45,
    "title": "Django Raw SQL: When ORM Isn't Enough",
    "slug": "django-raw-sql",
    "description": "Learn when and how to use raw SQL in Django for complex queries and performance optimization",
    "content": """# Django Raw SQL: When ORM Isn't Enough

Test content here
""",
    "difficulty": "intermediate"
}