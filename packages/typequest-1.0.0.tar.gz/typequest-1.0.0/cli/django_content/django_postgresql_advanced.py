"""
Django Database Management - Lesson 5: PostgreSQL Advanced Features
Master Django's PostgreSQL-specific features for enterprise-grade applications
"""

DJANGO_POSTGRESQL_ADVANCED_LESSON = {
    "id": 58,
    "chapter": 58,
    "title": "Django PostgreSQL Advanced Features: Enterprise Database Capabilities",
    "slug": "django-postgresql-advanced",
    "description": "Learn to use PostgreSQL-specific features in Django including advanced field types, full-text search, and custom indexes",
    "content": '''# Django PostgreSQL Advanced Features: Enterprise Database Capabilities

## 🎯 Understanding PostgreSQL Advanced Features

**PostgreSQL** is Django's most feature-rich supported database, offering **advanced data types**, **sophisticated indexing**, **full-text search**, and **enterprise-grade capabilities** that go far beyond basic SQL.

**Key PostgreSQL Features**:
- **Advanced Field Types** → ArrayField, JSONField, HStoreField, Range fields
- **Specialized Indexes** → GIN, GiST, BRIN, Bloom, Hash indexes
- **Full-Text Search** → SearchVector, SearchQuery, ranking and highlighting
- **Database Functions** → PostgreSQL-specific functions and aggregations
- **Advanced Constraints** → Check constraints, exclusion constraints
- **Performance Features** → Partial indexes, expression indexes, materialized views

Think of PostgreSQL as a **Swiss Army knife for data** - the right tool for complex data scenarios that basic databases can't handle.

## 💾 PostgreSQL Advanced Features Database

Let's create comprehensive examples showcasing PostgreSQL's advanced capabilities:

```sql
-- POSTGRESQL ADVANCED FEATURES DATABASE
-- Database: postgres_advanced

-- Enable PostgreSQL extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "unaccent";

-- Advanced field types demonstration
CREATE TABLE products_advanced (
    id SERIAL PRIMARY KEY,
    uuid UUID DEFAULT uuid_generate_v4() UNIQUE,
    name VARCHAR(200) NOT NULL,
    slug VARCHAR(200) UNIQUE NOT NULL,
    description TEXT,
    
    -- Array fields for multiple values
    tags VARCHAR(50)[] DEFAULT '{}',
    categories INTEGER[] DEFAULT '{}',
    color_variants VARCHAR(20)[] DEFAULT '{}',
    size_options VARCHAR(10)[] DEFAULT '{}',
    
    -- JSON fields for structured data
    specifications JSONB DEFAULT '{}',
    metadata JSONB DEFAULT '{}',
    pricing_tiers JSONB DEFAULT '[]',
    
    -- Range fields for numeric and date ranges
    price_range NUMRANGE,
    availability_period TSRANGE,
    size_range INT4RANGE,
    
    -- Advanced data types
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    search_vector TSVECTOR
);

-- Sample data with advanced PostgreSQL features
INSERT INTO products_advanced (name, slug, description, tags, categories, color_variants, specifications, pricing_tiers, price_range, availability_period) VALUES
('Professional Camera Kit', 'professional-camera-kit', 'High-end camera with multiple lenses', 
 ARRAY['photography', 'professional', 'digital', 'mirrorless'], 
 ARRAY[1, 3, 7], 
 ARRAY['black', 'silver', 'white'],
 '{"sensor": "full-frame", "megapixels": 45, "iso_range": "100-51200", "video": "4K 60fps", "weather_sealed": true}',
 '[{"tier": "standard", "price": 2499.99}, {"tier": "bundle", "price": 3299.99}, {"tier": "pro", "price": 4499.99}]',
 '[1999.99, 4999.99)',
 '[2024-01-01, 2024-12-31)'),

('Gaming Laptop Pro', 'gaming-laptop-pro', 'High-performance laptop for gaming and content creation',
 ARRAY['gaming', 'laptop', 'nvidia', 'high-performance'], 
 ARRAY[2, 5, 8],
 ARRAY['black', 'red-accents'],
 '{"processor": "Intel i9-13900H", "gpu": "RTX 4080", "ram": "32GB DDR5", "storage": "2TB NVMe", "display": "17.3-inch 240Hz"}',
 '[{"tier": "base", "price": 2299.99}, {"tier": "upgraded", "price": 2799.99}]',
 '[1999.99, 3499.99)',
 '[2024-02-01, 2024-11-30)'),

('Wireless Earbuds Elite', 'wireless-earbuds-elite', 'Premium wireless earbuds with active noise cancellation',
 ARRAY['audio', 'wireless', 'noise-cancellation', 'premium'],
 ARRAY[4, 9],
 ARRAY['black', 'white', 'blue', 'pink'],
 '{"driver_size": "11mm", "frequency_response": "20Hz-40kHz", "anc_levels": 3, "battery_life": "8+24hrs", "water_resistance": "IPX5"}',
 '[{"tier": "standard", "price": 249.99}, {"tier": "limited_edition", "price": 299.99}]',
 '[199.99, 349.99)',
 '[2024-03-15, 2025-03-15)');

-- Advanced indexes for PostgreSQL features
CREATE INDEX idx_products_tags_gin ON products_advanced USING GIN(tags);
CREATE INDEX idx_products_specs_gin ON products_advanced USING GIN(specifications);
CREATE INDEX idx_products_search_gin ON products_advanced USING GIN(search_vector);
CREATE INDEX idx_products_price_range_gist ON products_advanced USING GIST(price_range);
CREATE INDEX idx_products_availability_gist ON products_advanced USING GIST(availability_period);

-- Full-text search setup
UPDATE products_advanced SET search_vector = to_tsvector('english', 
    COALESCE(name, '') || ' ' || 
    COALESCE(description, '') || ' ' || 
    COALESCE(array_to_string(tags, ' '), '')
);

-- Content management with advanced features
CREATE TABLE articles_advanced (
    id SERIAL PRIMARY KEY,
    uuid UUID DEFAULT uuid_generate_v4() UNIQUE,
    title VARCHAR(300) NOT NULL,
    slug VARCHAR(300) UNIQUE NOT NULL,
    content TEXT NOT NULL,
    excerpt TEXT,
    
    -- Author and content management
    author_id INTEGER NOT NULL,
    editor_ids INTEGER[] DEFAULT '{}',
    reviewer_ids INTEGER[] DEFAULT '{}',
    
    -- Content metadata
    metadata JSONB DEFAULT '{}',
    seo_data JSONB DEFAULT '{}',
    analytics_data JSONB DEFAULT '{}',
    
    -- Content structure
    table_of_contents JSONB DEFAULT '[]',
    related_articles INTEGER[] DEFAULT '{}',
    tags VARCHAR(50)[] DEFAULT '{}',
    categories VARCHAR(50)[] DEFAULT '{}',
    
    -- Publishing workflow
    status VARCHAR(20) DEFAULT 'draft',
    published_at TIMESTAMP WITH TIME ZONE,
    scheduled_at TIMESTAMP WITH TIME ZONE,
    
    -- Search and content features
    search_vector TSVECTOR,
    reading_time_minutes INTEGER,
    word_count INTEGER,
    
    -- Audit fields
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    version_number INTEGER DEFAULT 1
);

-- Sample article data
INSERT INTO articles_advanced (title, slug, content, excerpt, author_id, metadata, seo_data, tags, categories, status, reading_time_minutes, word_count) VALUES
('Advanced PostgreSQL Features in Django', 'advanced-postgresql-django', 
 'PostgreSQL offers many advanced features that can significantly enhance your Django applications. From array fields to full-text search, these capabilities provide powerful tools for complex data scenarios...',
 'Explore PostgreSQL advanced features including array fields, JSON support, and full-text search in Django applications.',
 1,
 '{"difficulty": "advanced", "prerequisites": ["django-basics", "postgresql-basics"], "estimated_time": "45 minutes"}',
 '{"title": "Advanced PostgreSQL Features in Django | Tutorial", "description": "Learn PostgreSQL advanced features in Django", "keywords": ["postgresql", "django", "advanced", "database"]}',
 ARRAY['postgresql', 'django', 'database', 'advanced'],
 ARRAY['tutorials', 'database'],
 'published',
 12,
 2400),

('Full-Text Search Implementation Guide', 'fulltext-search-guide',
 'Implementing effective full-text search requires understanding PostgreSQL search vectors, ranking algorithms, and optimization techniques...',
 'Complete guide to implementing full-text search with PostgreSQL and Django including ranking and highlighting.',
 2,
 '{"difficulty": "intermediate", "code_examples": true, "practical_exercises": true}',
 '{"title": "PostgreSQL Full-Text Search Guide", "description": "Complete full-text search implementation", "keywords": ["search", "postgresql", "tsvector", "ranking"]}',
 ARRAY['search', 'postgresql', 'performance'],
 ARRAY['tutorials', 'search'],
 'published',
 18,
 3600);

-- Advanced indexes for articles
CREATE INDEX idx_articles_search_gin ON articles_advanced USING GIN(search_vector);
CREATE INDEX idx_articles_tags_gin ON articles_advanced USING GIN(tags);
CREATE INDEX idx_articles_categories_gin ON articles_advanced USING GIN(categories);
CREATE INDEX idx_articles_metadata_gin ON articles_advanced USING GIN(metadata);
CREATE INDEX idx_articles_status_published ON articles_advanced(status, published_at);

-- Update search vectors for articles
UPDATE articles_advanced SET search_vector = to_tsvector('english',
    COALESCE(title, '') || ' ' ||
    COALESCE(content, '') || ' ' ||
    COALESCE(excerpt, '') || ' ' ||
    COALESCE(array_to_string(tags, ' '), '')
);

-- User preferences with advanced PostgreSQL features
CREATE TABLE user_preferences_advanced (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE NOT NULL,
    
    -- JSON preferences structure
    ui_preferences JSONB DEFAULT '{}',
    notification_settings JSONB DEFAULT '{}',
    privacy_settings JSONB DEFAULT '{}',
    
    -- Array-based preferences
    favorite_categories INTEGER[] DEFAULT '{}',
    blocked_users INTEGER[] DEFAULT '{}',
    subscribed_topics VARCHAR(100)[] DEFAULT '{}',
    
    -- Range-based preferences
    price_alert_range NUMRANGE,
    availability_window TSRANGE,
    
    -- Search and filtering preferences
    search_history JSONB DEFAULT '[]',
    filter_presets JSONB DEFAULT '{}',
    
    -- Behavioral tracking
    activity_log JSONB DEFAULT '[]',
    interaction_metrics JSONB DEFAULT '{}',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Sample user preferences
INSERT INTO user_preferences_advanced (user_id, ui_preferences, notification_settings, favorite_categories, subscribed_topics, price_alert_range, search_history) VALUES
(1, 
 '{"theme": "dark", "language": "en-US", "timezone": "America/New_York", "items_per_page": 25, "compact_view": true}',
 '{"email": true, "push": false, "sms": false, "frequency": "daily", "categories": ["orders", "promotions"]}',
 ARRAY[1, 3, 7, 9],
 ARRAY['technology', 'photography', 'gaming'],
 '[100.00, 1000.00)',
 '[{"query": "camera", "timestamp": "2024-12-20T10:30:00Z"}, {"query": "laptop gaming", "timestamp": "2024-12-21T14:22:00Z"}]'),

(2,
 '{"theme": "light", "language": "en-US", "timezone": "America/Los_Angeles", "items_per_page": 50, "compact_view": false}',
 '{"email": true, "push": true, "sms": true, "frequency": "immediate", "categories": ["security", "orders"]}',
 ARRAY[2, 4, 8],
 ARRAY['productivity', 'design', 'development'],
 '[50.00, 500.00)',
 '[{"query": "wireless headphones", "timestamp": "2024-12-19T16:45:00Z"}, {"query": "mechanical keyboard", "timestamp": "2024-12-20T09:15:00Z"}]');

-- Advanced indexes for user preferences
CREATE INDEX idx_user_prefs_categories_gin ON user_preferences_advanced USING GIN(favorite_categories);
CREATE INDEX idx_user_prefs_topics_gin ON user_preferences_advanced USING GIN(subscribed_topics);
CREATE INDEX idx_user_prefs_ui_gin ON user_preferences_advanced USING GIN(ui_preferences);
CREATE INDEX idx_user_prefs_price_range_gist ON user_preferences_advanced USING GIST(price_alert_range);

-- Analytics table with time-series data
CREATE TABLE analytics_events (
    id SERIAL PRIMARY KEY,
    event_uuid UUID DEFAULT uuid_generate_v4(),
    user_id INTEGER,
    session_id UUID,
    
    -- Event data
    event_type VARCHAR(50) NOT NULL,
    event_category VARCHAR(50) NOT NULL,
    event_data JSONB DEFAULT '{}',
    
    -- Context information
    user_agent TEXT,
    ip_address INET,
    referrer TEXT,
    page_url TEXT,
    
    -- Geographic data
    country_code VARCHAR(2),
    region VARCHAR(100),
    city VARCHAR(100),
    
    -- Timing and metrics
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    processing_time_ms INTEGER,
    response_size_bytes INTEGER,
    
    -- Additional metadata
    metadata JSONB DEFAULT '{}',
    tags VARCHAR(50)[] DEFAULT '{}'
);

-- Sample analytics data
INSERT INTO analytics_events (user_id, session_id, event_type, event_category, event_data, user_agent, country_code, tags) VALUES
(1, uuid_generate_v4(), 'page_view', 'navigation', 
 '{"page": "/products/cameras", "load_time": 1.2, "scroll_depth": 75}',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
 'US', ARRAY['page_view', 'products']),

(1, uuid_generate_v4(), 'product_view', 'engagement',
 '{"product_id": 1, "view_duration": 45, "images_viewed": 3, "zoom_interactions": 2}',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
 'US', ARRAY['product', 'engagement']),

(2, uuid_generate_v4(), 'search', 'interaction',
 '{"query": "wireless earbuds", "results_count": 25, "click_position": 3, "filter_used": ["price", "brand"]}',
 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
 'US', ARRAY['search', 'discovery']);

-- Analytics indexes optimized for time-series queries
CREATE INDEX idx_analytics_timestamp ON analytics_events(timestamp DESC);
CREATE INDEX idx_analytics_user_time ON analytics_events(user_id, timestamp DESC);
CREATE INDEX idx_analytics_event_type ON analytics_events(event_type, timestamp DESC);
CREATE INDEX idx_analytics_data_gin ON analytics_events USING GIN(event_data);
CREATE INDEX idx_analytics_tags_gin ON analytics_events USING GIN(tags);
```

## 🔧 Django PostgreSQL Field Types

### 1. ArrayField for Multiple Values

**Scenario**: Spotify's playlist and music tag management

```python
from django.contrib.postgres.fields import ArrayField
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

class SpotifyStyleModels:
    
    class Artist(models.Model):
        name = models.CharField(max_length=200)
        slug = models.SlugField(unique=True)
        
        # Array fields for multiple genres and influences
        genres = ArrayField(
            models.CharField(max_length=50),
            size=10,  # Maximum 10 genres
            default=list,
            help_text="Musical genres this artist performs"
        )
        
        influences = ArrayField(
            models.CharField(max_length=100),
            size=20,
            default=list,
            blank=True,
            help_text="Artists that influenced this musician"
        )
        
        # Array of social media handles
        social_media = ArrayField(
            models.URLField(),
            size=10,
            default=list,
            blank=True
        )
        
        # Numeric array for monthly listener counts by region
        monthly_listeners_by_region = ArrayField(
            models.IntegerField(validators=[MinValueValidator(0)]),
            size=50,  # Up to 50 regions
            default=list,
            blank=True
        )
        
        created_at = models.DateTimeField(auto_now_add=True)
        
        class Meta:
            indexes = [
                # GIN index for efficient array queries
                models.Index(fields=['genres'], name='idx_artist_genres_gin'),
            ]
        
        def __str__(self):
            return self.name
    
    class Song(models.Model):
        title = models.CharField(max_length=300)
        artist = models.ForeignKey(Artist, on_delete=models.CASCADE)
        album = models.CharField(max_length=200, blank=True)
        duration_seconds = models.IntegerField()
        
        # Array fields for song metadata
        tags = ArrayField(
            models.CharField(max_length=30),
            size=20,
            default=list,
            help_text="Descriptive tags for the song"
        )
        
        # Array of featured artists
        featured_artists = ArrayField(
            models.IntegerField(),  # Artist IDs
            size=10,
            default=list,
            blank=True
        )
        
        # Array of language codes for multilingual songs
        languages = ArrayField(
            models.CharField(max_length=5),  # ISO language codes
            size=5,
            default=list
        )
        
        # Audio characteristics as arrays
        audio_features = ArrayField(
            models.FloatField(validators=[MinValueValidator(0.0), MaxValueValidator(1.0)]),
            size=10,  # [energy, valence, danceability, acousticness, etc.]
            default=list,
            help_text="Audio analysis features (0.0-1.0)"
        )
        
        created_at = models.DateTimeField(auto_now_add=True)
        
        class Meta:
            indexes = [
                models.Index(fields=['tags'], name='idx_song_tags_gin'),
                models.Index(fields=['featured_artists'], name='idx_song_featured_gin'),
            ]

# Array field queries and operations
class SpotifyQueryService:
    
    @staticmethod
    def find_artists_by_genre(genre):
        """Find artists that perform a specific genre"""
        return Artist.objects.filter(genres__contains=[genre])
    
    @staticmethod
    def find_artists_with_multiple_genres(genres_list):
        """Find artists that perform all specified genres"""
        return Artist.objects.filter(genres__contains=genres_list)
    
    @staticmethod
    def find_songs_with_any_tags(tags):
        """Find songs that have any of the specified tags"""
        return Song.objects.filter(tags__overlap=tags)
    
    @staticmethod
    def find_energetic_songs():
        """Find songs with high energy (assuming energy is at index 0)"""
        # Using PostgreSQL array indexing (1-based)
        return Song.objects.extra(
            where=["audio_features[1] > 0.7"]
        )
    
    @staticmethod
    def get_genre_statistics():
        """Get statistics about genre usage across artists"""
        from django.db.models import Count
        from django.contrib.postgres.aggregates import ArrayAgg
        
        return Artist.objects.aggregate(
            all_genres=ArrayAgg('genres', distinct=True),
            total_artists=Count('id')
        )
    
    @staticmethod
    def add_genre_to_artist(artist_id, new_genre):
        """Add a genre to an artist's genres array"""
        from django.contrib.postgres.fields.array import Append
        
        Artist.objects.filter(id=artist_id).update(
            genres=Append('genres', new_genre)
        )
    
    @staticmethod
    def remove_genre_from_artist(artist_id, genre_to_remove):
        """Remove a specific genre from an artist"""
        artist = Artist.objects.get(id=artist_id)
        if genre_to_remove in artist.genres:
            artist.genres.remove(genre_to_remove)
            artist.save()
```

### 2. JSONField for Structured Data

**Scenario**: Slack's message and workspace configuration

```python
from django.contrib.postgres.fields import JSONField
from django.db import models
from django.contrib.postgres.indexes import GinIndex

class SlackStyleModels:
    
    class Workspace(models.Model):
        name = models.CharField(max_length=100)
        slug = models.SlugField(unique=True)
        
        # JSON field for workspace settings and configuration
        settings = models.JSONField(default=dict, help_text="Workspace configuration settings")
        
        # JSON field for custom emoji and reactions
        custom_emoji = models.JSONField(default=dict, help_text="Custom emoji definitions")
        
        # JSON field for integration configurations
        integrations = models.JSONField(default=list, help_text="Third-party integrations")
        
        # JSON field for member permissions and roles
        member_permissions = models.JSONField(default=dict, help_text="Custom member permission settings")
        
        created_at = models.DateTimeField(auto_now_add=True)
        
        class Meta:
            indexes = [
                GinIndex(fields=['settings']),
                GinIndex(fields=['integrations']),
            ]
    
    class Channel(models.Model):
        workspace = models.ForeignKey(Workspace, on_delete=models.CASCADE)
        name = models.CharField(max_length=100)
        description = models.TextField(blank=True)
        is_private = models.BooleanField(default=False)
        
        # JSON field for channel-specific settings
        channel_settings = models.JSONField(default=dict, help_text="Channel configuration")
        
        # JSON field for member list and roles
        members = models.JSONField(default=list, help_text="Channel members with roles")
        
        # JSON field for pinned messages
        pinned_messages = models.JSONField(default=list, help_text="Pinned message references")
        
        # JSON field for channel statistics
        analytics = models.JSONField(default=dict, help_text="Channel usage analytics")
        
        created_at = models.DateTimeField(auto_now_add=True)
        
        class Meta:
            indexes = [
                GinIndex(fields=['channel_settings']),
                GinIndex(fields=['members']),
            ]
    
    class Message(models.Model):
        channel = models.ForeignKey(Channel, on_delete=models.CASCADE)
        user_id = models.IntegerField()
        content = models.TextField()
        
        # JSON field for rich message formatting
        formatting = models.JSONField(default=dict, help_text="Text formatting and styling")
        
        # JSON field for attachments and media
        attachments = models.JSONField(default=list, help_text="File attachments and media")
        
        # JSON field for message reactions
        reactions = models.JSONField(default=dict, help_text="Emoji reactions with user lists")
        
        # JSON field for thread information
        thread_info = models.JSONField(default=dict, help_text="Thread replies and metadata")
        
        # JSON field for mentions and notifications
        mentions = models.JSONField(default=dict, help_text="User and channel mentions")
        
        # JSON field for message metadata
        metadata = models.JSONField(default=dict, help_text="Additional message metadata")
        
        timestamp = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        
        class Meta:
            indexes = [
                GinIndex(fields=['formatting']),
                GinIndex(fields=['reactions']),
                GinIndex(fields=['mentions']),
            ]

# JSON field queries and operations
class SlackQueryService:
    
    @staticmethod
    def find_workspaces_with_feature(feature_name):
        """Find workspaces that have a specific feature enabled"""
        return Workspace.objects.filter(
            settings__features__contains=[feature_name]
        )
    
    @staticmethod
    def find_channels_with_retention_policy():
        """Find channels with message retention policies"""
        return Channel.objects.filter(
            channel_settings__retention__isnull=False
        )
    
    @staticmethod
    def find_messages_with_attachments():
        """Find messages that have file attachments"""
        return Message.objects.filter(
            attachments__len__gt=0
        )
    
    @staticmethod
    def find_messages_mentioning_user(user_id):
        """Find messages that mention a specific user"""
        return Message.objects.filter(
            mentions__users__contains=[user_id]
        )
    
    @staticmethod
    def get_popular_reactions():
        """Get most used emoji reactions across all messages"""
        from django.db.models import Count
        
        # This would require custom aggregation for JSON fields
        return Message.objects.exclude(
            reactions={}
        ).values('reactions').annotate(
            usage_count=Count('id')
        ).order_by('-usage_count')
    
    @staticmethod
    def update_workspace_settings(workspace_id, new_settings):
        """Update workspace settings using JSON field operations"""
        workspace = Workspace.objects.get(id=workspace_id)
        
        # Merge new settings with existing ones
        current_settings = workspace.settings or {}
        current_settings.update(new_settings)
        
        workspace.settings = current_settings
        workspace.save()
    
    @staticmethod
    def add_channel_member(channel_id, user_id, role='member'):
        """Add a member to a channel"""
        channel = Channel.objects.get(id=channel_id)
        
        members = channel.members or []
        member_entry = {
            'user_id': user_id,
            'role': role,
            'joined_at': timezone.now().isoformat()
        }
        
        # Check if user is already a member
        existing_member = next((m for m in members if m['user_id'] == user_id), None)
        if existing_member:
            existing_member.update(member_entry)
        else:
            members.append(member_entry)
        
        channel.members = members
        channel.save()
```

### 3. Full-Text Search with SearchVector

**Scenario**: Medium's article search and discovery

```python
from django.contrib.postgres.search import SearchVector, SearchQuery, SearchRank
from django.contrib.postgres.indexes import GinIndex
from django.db import models

class MediumStyleModels:
    
    class Article(models.Model):
        title = models.CharField(max_length=300)
        subtitle = models.CharField(max_length=500, blank=True)
        content = models.TextField()
        excerpt = models.TextField(blank=True)
        author_id = models.IntegerField()
        
        # Tags for categorization
        tags = ArrayField(
            models.CharField(max_length=50),
            size=20,
            default=list
        )
        
        # SEO and metadata
        seo_data = models.JSONField(default=dict)
        
        # Search-specific fields
        search_vector = models.GeneratedField(
            expression=SearchVector('title', weight='A') + 
                      SearchVector('subtitle', weight='B') + 
                      SearchVector('content', weight='C') + 
                      SearchVector('excerpt', weight='D'),
            output_field=models.TextField(),
            db_persist=True
        )
        
        # Article metrics
        view_count = models.IntegerField(default=0)
        like_count = models.IntegerField(default=0)
        comment_count = models.IntegerField(default=0)
        reading_time_minutes = models.IntegerField(default=1)
        
        # Publishing workflow
        status = models.CharField(max_length=20, default='draft')
        published_at = models.DateTimeField(null=True, blank=True)
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        
        class Meta:
            indexes = [
                GinIndex(fields=['search_vector']),
                GinIndex(fields=['tags']),
                models.Index(fields=['status', 'published_at']),
                models.Index(fields=['-view_count', '-like_count']),
            ]

class MediumSearchService:
    
    @staticmethod
    def search_articles(query, limit=20):
        """Full-text search across articles with ranking"""
        search_query = SearchQuery(query, config='english')
        
        return Article.objects.annotate(
            rank=SearchRank(models.F('search_vector'), search_query)
        ).filter(
            search_vector=search_query,
            status='published'
        ).order_by('-rank', '-published_at')[:limit]
    
    @staticmethod
    def search_articles_with_filters(query, tags=None, min_reading_time=None):
        """Advanced search with additional filters"""
        search_query = SearchQuery(query, config='english')
        
        queryset = Article.objects.annotate(
            rank=SearchRank(models.F('search_vector'), search_query)
        ).filter(
            search_vector=search_query,
            status='published'
        )
        
        # Apply additional filters
        if tags:
            queryset = queryset.filter(tags__overlap=tags)
        
        if min_reading_time:
            queryset = queryset.filter(reading_time_minutes__gte=min_reading_time)
        
        return queryset.order_by('-rank', '-view_count')
    
    @staticmethod
    def search_with_highlighting(query, limit=10):
        """Search with content highlighting"""
        from django.contrib.postgres.search import SearchHeadline
        
        search_query = SearchQuery(query, config='english')
        
        return Article.objects.annotate(
            rank=SearchRank(models.F('search_vector'), search_query),
            headline=SearchHeadline(
                'content',
                search_query,
                config='english',
                start_sel='<mark>',
                stop_sel='</mark>',
                max_words=50,
                min_words=15,
            )
        ).filter(
            search_vector=search_query,
            status='published'
        ).order_by('-rank')[:limit]
    
    @staticmethod
    def similar_articles(article_id, limit=5):
        """Find similar articles based on tags and content"""
        try:
            article = Article.objects.get(id=article_id)
        except Article.DoesNotExist:
            return Article.objects.none()
        
        # Create search query from article tags
        tag_query = ' | '.join(article.tags) if article.tags else ''
        
        if tag_query:
            search_query = SearchQuery(tag_query, config='english')
            
            return Article.objects.annotate(
                rank=SearchRank(models.F('search_vector'), search_query)
            ).filter(
                tags__overlap=article.tags,
                status='published'
            ).exclude(
                id=article_id
            ).order_by('-rank', '-view_count')[:limit]
        
        # Fallback to tag-based similarity
        return Article.objects.filter(
            tags__overlap=article.tags,
            status='published'
        ).exclude(id=article_id).order_by('-view_count')[:limit]
    
    @staticmethod
    def autocomplete_search(partial_query, limit=10):
        """Provide search suggestions based on partial input"""
        # Use trigram similarity for autocomplete
        from django.contrib.postgres.search import TrigramSimilarity
        
        return Article.objects.annotate(
            similarity=TrigramSimilarity('title', partial_query)
        ).filter(
            similarity__gt=0.3,
            status='published'
        ).order_by('-similarity')[:limit]
```

### 4. Advanced PostgreSQL Indexes

**Scenario**: Uber's location and time-based data optimization

```python
from django.contrib.postgres.indexes import BrinIndex, GistIndex, HashIndex
from django.contrib.postgres.fields import DateTimeRangeField, DecimalRangeField
from django.db import models

class UberStyleModels:
    
    class Driver(models.Model):
        name = models.CharField(max_length=200)
        phone = models.CharField(max_length=20)
        license_number = models.CharField(max_length=50, unique=True)
        
        # JSON field for driver profile and preferences
        profile = models.JSONField(default=dict)
        
        # Array field for vehicle types they can drive
        vehicle_types = ArrayField(
            models.CharField(max_length=20),
            size=10,
            default=list
        )
        
        # Location and service area
        home_location = models.JSONField(default=dict)  # {"lat": 40.7128, "lng": -74.0060}
        service_areas = ArrayField(
            models.CharField(max_length=100),
            size=20,
            default=list
        )
        
        # Ratings and performance
        rating_avg = models.DecimalField(max_digits=3, decimal_places=2, default=0.0)
        trip_count = models.IntegerField(default=0)
        
        # Account status
        is_active = models.BooleanField(default=True)
        created_at = models.DateTimeField(auto_now_add=True)
        
        class Meta:
            indexes = [
                # Hash index for exact license lookups
                HashIndex(fields=['license_number']),
                # GIN index for array and JSON queries
                GinIndex(fields=['vehicle_types']),
                GinIndex(fields=['profile']),
                # Regular indexes for common queries
                models.Index(fields=['is_active', 'rating_avg']),
            ]
    
    class Trip(models.Model):
        driver = models.ForeignKey(Driver, on_delete=models.CASCADE)
        passenger_id = models.IntegerField()
        
        # Trip details
        pickup_location = models.JSONField()  # {"lat": ..., "lng": ..., "address": "..."}
        dropoff_location = models.JSONField()
        
        # Pricing and payment
        base_fare = models.DecimalField(max_digits=8, decimal_places=2)
        distance_fare = models.DecimalField(max_digits=8, decimal_places=2)
        time_fare = models.DecimalField(max_digits=8, decimal_places=2)
        surge_multiplier = models.DecimalField(max_digits=3, decimal_places=2, default=1.0)
        total_fare = models.DecimalField(max_digits=10, decimal_places=2)
        
        # Trip timing
        requested_at = models.DateTimeField()
        picked_up_at = models.DateTimeField(null=True, blank=True)
        completed_at = models.DateTimeField(null=True, blank=True)
        
        # Trip metadata
        distance_km = models.DecimalField(max_digits=8, decimal_places=3)
        duration_minutes = models.IntegerField()
        vehicle_type = models.CharField(max_length=20)
        
        # Status and ratings
        status = models.CharField(max_length=20, default='requested')
        passenger_rating = models.IntegerField(null=True, blank=True)
        driver_rating = models.IntegerField(null=True, blank=True)
        
        # Trip-specific data
        route_data = models.JSONField(default=dict)
        payment_data = models.JSONField(default=dict)
        
        created_at = models.DateTimeField(auto_now_add=True)
        
        class Meta:
            indexes = [
                # BRIN index for time-series data (very efficient for large datasets)
                BrinIndex(fields=['requested_at']),
                BrinIndex(fields=['created_at']),
                
                # GiST indexes for geographic and JSON data
                GistIndex(fields=['pickup_location']),
                GistIndex(fields=['dropoff_location']),
                
                # Composite indexes for common queries
                models.Index(fields=['driver', 'requested_at']),
                models.Index(fields=['status', 'requested_at']),
                models.Index(fields=['vehicle_type', 'requested_at']),
                
                # GIN indexes for complex data
                GinIndex(fields=['route_data']),
                GinIndex(fields=['payment_data']),
            ]
    
    class DriverLocation(models.Model):
        """Time-series location tracking for drivers"""
        driver = models.ForeignKey(Driver, on_delete=models.CASCADE)
        
        # Location data
        latitude = models.DecimalField(max_digits=10, decimal_places=8)
        longitude = models.DecimalField(max_digits=11, decimal_places=8)
        accuracy_meters = models.IntegerField(default=10)
        
        # Movement data
        speed_kmh = models.DecimalField(max_digits=5, decimal_places=2, default=0.0)
        heading_degrees = models.IntegerField(default=0)  # 0-360 degrees
        
        # Status
        is_available = models.BooleanField(default=True)
        is_in_trip = models.BooleanField(default=False)
        
        # Additional context
        battery_level = models.IntegerField(null=True, blank=True)  # 0-100
        signal_strength = models.IntegerField(null=True, blank=True)
        
        timestamp = models.DateTimeField(auto_now_add=True)
        
        class Meta:
            indexes = [
                # BRIN index for timestamp (excellent for time-series)
                BrinIndex(fields=['timestamp']),
                
                # Composite index for driver location queries
                models.Index(fields=['driver', 'timestamp']),
                models.Index(fields=['is_available', 'timestamp']),
                
                # Geographic indexes for location-based queries
                models.Index(fields=['latitude', 'longitude']),
            ]
            
            # Partition by month for better performance
            # This would require PostgreSQL 10+ and additional setup

class UberQueryService:
    
    @staticmethod
    def find_nearby_drivers(lat, lng, radius_km=5.0, vehicle_type=None):
        """Find available drivers within radius"""
        # Use PostgreSQL's earth distance functions
        from django.db import connection
        
        query = """
            SELECT DISTINCT d.id, d.name, d.rating_avg, dl.latitude, dl.longitude,
                   earth_distance(ll_to_earth(%s, %s), ll_to_earth(dl.latitude, dl.longitude)) as distance_meters
            FROM drivers d
            INNER JOIN driver_locations dl ON d.id = dl.driver_id
            WHERE d.is_active = TRUE 
            AND dl.is_available = TRUE
            AND dl.timestamp > NOW() - INTERVAL '5 minutes'
            AND earth_distance(ll_to_earth(%s, %s), ll_to_earth(dl.latitude, dl.longitude)) < %s
        """
        
        params = [lat, lng, lat, lng, radius_km * 1000]  # Convert km to meters
        
        if vehicle_type:
            query += " AND %s = ANY(d.vehicle_types)"
            params.append(vehicle_type)
        
        query += " ORDER BY distance_meters LIMIT 20"
        
        with connection.cursor() as cursor:
            cursor.execute(query, params)
            return cursor.fetchall()
    
    @staticmethod
    def get_trip_analytics(start_date, end_date):
        """Get comprehensive trip analytics using efficient indexes"""
        return Trip.objects.filter(
            requested_at__range=[start_date, end_date]
        ).aggregate(
            total_trips=models.Count('id'),
            total_revenue=models.Sum('total_fare'),
            avg_fare=models.Avg('total_fare'),
            avg_distance=models.Avg('distance_km'),
            avg_duration=models.Avg('duration_minutes')
        )
    
    @staticmethod
    def get_driver_performance_metrics(driver_id, days=30):
        """Get driver performance using optimized queries"""
        from django.utils import timezone
        from datetime import timedelta
        
        cutoff_date = timezone.now() - timedelta(days=days)
        
        trips = Trip.objects.filter(
            driver_id=driver_id,
            requested_at__gte=cutoff_date
        )
        
        return trips.aggregate(
            trip_count=models.Count('id'),
            total_earnings=models.Sum('total_fare'),
            avg_rating=models.Avg('passenger_rating'),
            avg_trip_distance=models.Avg('distance_km'),
            avg_trip_duration=models.Avg('duration_minutes'),
            completion_rate=models.Avg(
                models.Case(
                    models.When(status='completed', then=1.0),
                    default=0.0,
                    output_field=models.FloatField()
                )
            )
        )
```

## 🎯 Key Takeaways

1. **ArrayField enables multiple values in single field** → Perfect for tags, categories, preferences
2. **JSONField provides structured data storage** → Complex configurations and metadata
3. **Full-text search with SearchVector** → Powerful search capabilities with ranking
4. **Specialized indexes optimize specific queries** → GIN for arrays/JSON, GiST for ranges, BRIN for time-series
5. **PostgreSQL range fields handle intervals** → Price ranges, time periods, numeric ranges
6. **Advanced aggregations with PostgreSQL functions** → Leverage database-specific capabilities
7. **Time-series optimizations with BRIN indexes** → Efficient storage for chronological data

PostgreSQL's advanced features enable Django applications to handle complex data scenarios that would be difficult or impossible with basic SQL databases!
''',
    "difficulty": "advanced",
    "estimated_time": 60,
    "xp_reward": 40,
    "prerequisites": ["django-models-foundations", "django-database-optimization"],
    "exercises": [
        {
            "id": "postgresql_1",
            "title": "Explore PostgreSQL Advanced Field Types",
            "prompt": "Let's examine the PostgreSQL advanced features database. Write a query to see products with their array and JSON field data.",
            "table_name": "products_advanced",
            "initial_query": "SELECT * FROM products_advanced LIMIT 3;",
            "expected_keywords": ["SELECT", "*", "FROM", "products_advanced"],
            "hint": "Use SELECT * FROM products_advanced LIMIT 3; to see PostgreSQL advanced field types",
            "solution": "SELECT * FROM products_advanced LIMIT 3;",
            "explanation": "This shows PostgreSQL's advanced field types in action: arrays (tags, categories), JSONB (specifications, pricing_tiers), range types (price_range), and search vectors. Django's ArrayField and JSONField map to these PostgreSQL types for powerful data modeling."
        },
        {
            "id": "postgresql_2",
            "title": "Array Field Queries and Operations",
            "prompt": "Practice PostgreSQL array queries. Write a query to find products that contain 'photography' in their tags array.",
            "table_name": "products_advanced",
            "expected_keywords": ["SELECT", "WHERE", "tags", "@>", "ARRAY"],
            "hint": "Use PostgreSQL array contains operator @> with ARRAY['photography']",
            "solution": "SELECT name, tags FROM products_advanced WHERE tags @> ARRAY['photography'];",
            "explanation": "The @> operator checks if the left array contains all elements of the right array. This maps to Django's ArrayField contains lookup: Product.objects.filter(tags__contains=['photography']). GIN indexes make these array queries very efficient."
        },
        {
            "id": "postgresql_3",
            "title": "JSON Field Data Extraction",
            "prompt": "Explore JSONB capabilities by extracting specific data from product specifications. Write a query to get products with their sensor type from the specifications JSON.",
            "table_name": "products_advanced",
            "expected_keywords": ["SELECT", "name", "specifications", "->", "sensor"],
            "hint": "Use the -> operator to extract JSON values: specifications -> 'sensor'",
            "solution": "SELECT name, specifications -> 'sensor' as sensor_type, specifications -> 'megapixels' as megapixels FROM products_advanced WHERE specifications ? 'sensor';",
            "explanation": "PostgreSQL JSONB supports efficient querying with operators like -> for value extraction and ? for key existence. Django's JSONField provides similar functionality with lookups like specifications__sensor and specifications__has_key."
        },
        {
            "id": "postgresql_4",
            "title": "Range Field Operations",
            "prompt": "Practice PostgreSQL range queries. Write a query to find products where a specific price (2500.00) falls within their price range.",
            "table_name": "products_advanced",
            "expected_keywords": ["SELECT", "WHERE", "price_range", "@>", "2500"],
            "hint": "Use the range contains operator @> to check if a value is within a range",
            "solution": "SELECT name, price_range FROM products_advanced WHERE price_range @> 2500.00;",
            "explanation": "PostgreSQL range types support efficient range queries with operators like @> (contains), && (overlaps), and <@ (contained by). Django's range fields provide similar functionality for handling price ranges, date ranges, and numeric intervals."
        },
        {
            "id": "postgresql_5",
            "title": "Full-Text Search Vector Analysis",
            "prompt": "Examine the full-text search capabilities. Write a query to search for products containing 'camera' using the search_vector field.",
            "table_name": "products_advanced",
            "expected_keywords": ["SELECT", "WHERE", "search_vector", "@@", "to_tsquery"],
            "hint": "Use the @@ operator with to_tsquery('camera') for full-text search",
            "solution": "SELECT name, description FROM products_advanced WHERE search_vector @@ to_tsquery('english', 'camera');",
            "explanation": "PostgreSQL's full-text search uses tsvector for indexed search content and tsquery for search terms. The @@ operator performs efficient text matching. Django's SearchVector and SearchQuery provide ORM access to these powerful search capabilities."
        },
        {
            "id": "postgresql_6",
            "title": "Advanced User Preferences JSON Analysis",
            "prompt": "Explore complex JSON queries with user preferences. Write a query to find users who prefer dark theme from their UI preferences.",
            "table_name": "user_preferences_advanced",
            "expected_keywords": ["SELECT", "WHERE", "ui_preferences", "->", "theme", "dark"],
            "hint": "Navigate the nested JSON structure: ui_preferences -> 'theme' = 'dark'",
            "solution": "SELECT user_id, ui_preferences -> 'theme' as theme, ui_preferences -> 'language' as language FROM user_preferences_advanced WHERE ui_preferences ->> 'theme' = 'dark';",
            "explanation": "The ->> operator extracts JSON values as text for comparison, while -> extracts as JSON. This demonstrates Django's JSONField lookup capabilities like ui_preferences__theme='dark' for complex configuration queries with GIN index support."
        }
    ],
    "key_concepts": [
        "ArrayField for Multiple Values Storage",
        "JSONField for Structured Data Management",
        "PostgreSQL Range Types and Operations",
        "Full-Text Search with SearchVector",
        "Advanced PostgreSQL Index Types",
        "GIN and GiST Index Optimization",
        "PostgreSQL-Specific Query Operators",
        "Time-Series Data with BRIN Indexes"
    ]
}