"""
Django Database - Lesson 6: Custom Model Fields
Master creating custom model fields for specialized data types and validation
"""

DJANGO_CUSTOM_FIELDS_LESSON = {
    "id": 49,
    "chapter": 49,
    "title": "Django Custom Model Fields: Extending Django's Data Types",
    "slug": "django-custom-fields",
    "description": "Learn to create custom model fields for specialized data types, validation, and storage formats",
    "content": '''# Django Custom Model Fields: Extending Django's Data Types

## 🎯 Why Custom Fields Matter

While Django provides many built-in field types, real-world applications often need **specialized data handling**:

- **Custom validation logic** beyond Django's built-in validators
- **Specialized storage formats** (encrypted data, compressed JSON, etc.)
- **Domain-specific data types** (currency, coordinates, file sizes, etc.)
- **Automatic data transformation** (normalization, formatting, encoding)

Custom fields let you **encapsulate complex data logic** directly in your models, making your code cleaner and more reusable.

## 💾 Specialized Application Database

Let's work with a comprehensive application that needs various custom field types:

```sql
-- User profiles with specialized data types
CREATE TABLE user_profiles (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(254) NOT NULL,
    phone_number VARCHAR(20), -- Will be standardized with custom field
    encrypted_ssn VARCHAR(255), -- Encrypted storage
    profile_data JSONB, -- Compressed JSON storage
    location_lat DECIMAL(10, 8), -- Geographic coordinates
    location_lng DECIMAL(11, 8),
    file_sizes_json TEXT, -- Custom file size storage
    color_preferences TEXT, -- Hex color validation
    currency_amounts JSONB, -- Multi-currency storage
    tags_normalized TEXT, -- Normalized tag storage
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample user data showcasing custom field usage
INSERT INTO user_profiles (username, email, phone_number, location_lat, location_lng, color_preferences) VALUES
('techguru', 'guru@tech.com', '(555) 123-4567', 37.7749, -122.4194, '#FF5733,#33FF57,#3357FF'),
('designpro', 'pro@design.com', '+1-555-987-6543', 40.7128, -74.0060, '#E91E63,#9C27B0,#673AB7'),
('developer', 'dev@code.com', '555.456.7890', 34.0522, -118.2437, '#F44336,#FF9800,#FFC107'),
('analyst', 'data@analytics.com', '(555) 234-5678', 41.8781, -87.6298, '#4CAF50,#8BC34A,#CDDC39');

-- Product catalog with complex data types
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    price_data JSONB, -- Multi-currency pricing
    dimensions_json TEXT, -- Physical dimensions
    color_options TEXT, -- Validated color hex codes
    file_attachments JSONB, -- File metadata with sizes
    geo_restrictions JSONB, -- Geographic availability
    tags_normalized TEXT, -- Searchable normalized tags
    encryption_key VARCHAR(255), -- For sensitive product data
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample product data
INSERT INTO products (name, price_data, color_options) VALUES
('Premium Laptop', '{"USD": 1299.99, "EUR": 1199.99, "GBP": 999.99}', '#SILVER,#GOLD,#SPACEGRAY'),
('Wireless Headphones', '{"USD": 249.99, "EUR": 229.99, "GBP": 199.99}', '#000000,#FFFFFF,#FF0000'),
('Smartphone', '{"USD": 899.99, "EUR": 849.99, "GBP": 729.99}', '#000000,#FFFFFF,#BLUE');

-- Application settings with various data types
CREATE TABLE app_settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    encrypted_value TEXT, -- Encrypted setting storage
    color_theme TEXT, -- Color scheme validation
    file_size_limits TEXT, -- File size constraints
    geo_config JSONB, -- Geographic configuration
    phone_formats TEXT, -- Supported phone formats
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Configuration data
INSERT INTO app_settings (setting_key, color_theme, file_size_limits) VALUES
('ui_theme', '#2196F3,#FFC107,#4CAF50', '{"max_upload": "100MB", "max_avatar": "5MB"}'),
('admin_theme', '#9C27B0,#E91E63,#FF5722', '{"max_backup": "1GB", "max_log": "50MB"}');
```

## 🔧 Basic Custom Field Types

### 1. Phone Number Field - Standardization and Validation

**Scenario**: Standardizing phone numbers across different input formats

```python
import re
from django.db import models
from django.core.exceptions import ValidationError

class PhoneNumberField(models.CharField):
    """Custom field for phone number standardization and validation"""
    
    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 20
        super().__init__(*args, **kwargs)
    
    def to_python(self, value):
        """Convert input to Python object"""
        if value is None:
            return value
        
        # Remove all non-digit characters except +
        cleaned = re.sub(r'[^\d+]', '', str(value))
        
        # Standardize US numbers
        if cleaned.startswith('1') and len(cleaned) == 11:
            return f"+{cleaned}"
        elif len(cleaned) == 10:
            return f"+1{cleaned}"
        elif cleaned.startswith('+'):
            return cleaned
        else:
            return cleaned
    
    def validate(self, value, model_instance):
        """Custom validation logic"""
        super().validate(value, model_instance)
        
        if value and not self.is_valid_phone(value):
            raise ValidationError('Enter a valid phone number')
    
    def is_valid_phone(self, phone):
        """Validate phone number format"""
        # Basic validation for international numbers
        pattern = r'^\+[1-9]\d{1,14}$'
        return re.match(pattern, phone) is not None

# Usage in model
class UserProfile(models.Model):
    username = models.CharField(max_length=50)
    phone = PhoneNumberField(help_text="Phone number will be automatically formatted")
```

### 2. Encrypted Field - Secure Data Storage

**Scenario**: Storing sensitive data like SSNs or API keys

```python
import base64
from cryptography.fernet import Fernet
from django.conf import settings
from django.db import models

class EncryptedField(models.TextField):
    """Field that automatically encrypts/decrypts data"""
    
    def __init__(self, *args, **kwargs):
        self.encrypt_key = kwargs.pop('encrypt_key', None)
        super().__init__(*args, **kwargs)
    
    def get_cipher(self):
        """Get encryption cipher"""
        key = self.encrypt_key or getattr(settings, 'FIELD_ENCRYPTION_KEY', None)
        if not key:
            # Generate a key for demo (in production, use settings)
            key = base64.urlsafe_b64encode(b'demo_key_32_chars_long_exactly!')
        return Fernet(key)
    
    def to_python(self, value):
        """Decrypt when loading from database"""
        if value is None:
            return value
        
        try:
            cipher = self.get_cipher()
            # Decrypt the value
            decrypted = cipher.decrypt(value.encode())
            return decrypted.decode()
        except Exception:
            # Return original value if decryption fails
            return value
    
    def get_prep_value(self, value):
        """Encrypt when saving to database"""
        if value is None:
            return value
        
        try:
            cipher = self.get_cipher()
            # Encrypt the value
            encrypted = cipher.encrypt(value.encode())
            return encrypted.decode()
        except Exception:
            # Return original value if encryption fails
            return value

# Usage
class UserProfile(models.Model):
    ssn = EncryptedField(help_text="SSN is automatically encrypted")
    api_key = EncryptedField(help_text="API key stored securely")
```

### 3. Color Field - Hex Color Validation

**Scenario**: Validating and storing color values

```python
import re
from django.db import models
from django.core.exceptions import ValidationError

class ColorField(models.CharField):
    """Field for validating and storing hex color codes"""
    
    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 7  # #RRGGBB format
        super().__init__(*args, **kwargs)
    
    def to_python(self, value):
        """Normalize color format"""
        if value is None:
            return value
        
        value = str(value).upper().strip()
        
        # Add # if missing
        if not value.startswith('#'):
            value = f'#{value}'
        
        # Convert 3-char to 6-char format (#RGB -> #RRGGBB)
        if len(value) == 4:
            value = f'#{value[1]}{value[1]}{value[2]}{value[2]}{value[3]}{value[3]}'
        
        return value
    
    def validate(self, value, model_instance):
        """Validate hex color format"""
        super().validate(value, model_instance)
        
        if value and not self.is_valid_hex_color(value):
            raise ValidationError('Enter a valid hex color code (e.g., #FF5733)')
    
    def is_valid_hex_color(self, color):
        """Check if color is valid hex format"""
        pattern = r'^#[0-9A-F]{6}$'
        return re.match(pattern, color) is not None

class ColorListField(models.TextField):
    """Field for storing multiple colors as comma-separated list"""
    
    def to_python(self, value):
        """Convert to list of colors"""
        if not value:
            return []
        
        if isinstance(value, list):
            return value
        
        colors = [color.strip().upper() for color in value.split(',')]
        
        # Normalize each color
        normalized = []
        for color in colors:
            if not color.startswith('#'):
                color = f'#{color}'
            if len(color) == 4:  # Convert #RGB to #RRGGBB
                color = f'#{color[1]}{color[1]}{color[2]}{color[2]}{color[3]}{color[3]}'
            normalized.append(color)
        
        return normalized
    
    def get_prep_value(self, value):
        """Convert list to comma-separated string for storage"""
        if not value:
            return ''
        return ','.join(value)

# Usage
class Product(models.Model):
    primary_color = ColorField(help_text="Primary brand color")
    color_options = ColorListField(help_text="Available color variations")
```

## 📊 Advanced Custom Field Types

### 4. File Size Field - Human-Readable Storage

**Scenario**: Storing and displaying file sizes in human-readable format

```python
import re
from django.db import models
from django.core.exceptions import ValidationError

class FileSizeField(models.BigIntegerField):
    """Field that stores bytes but accepts human-readable input"""
    
    SIZE_UNITS = {
        'B': 1,
        'KB': 1024,
        'MB': 1024**2,
        'GB': 1024**3,
        'TB': 1024**4,
    }
    
    def to_python(self, value):
        """Convert human-readable size to bytes"""
        if value is None:
            return value
        
        if isinstance(value, int):
            return value
        
        # Parse human-readable format like "100MB", "1.5GB"
        if isinstance(value, str):
            match = re.match(r'^([\d.]+)\s*([KMGT]?B)$', value.upper().strip())
            if match:
                size, unit = match.groups()
                return int(float(size) * self.SIZE_UNITS[unit])
        
        return int(value)
    
    def from_db_value(self, value, expression, connection):
        """Convert bytes to human-readable when loading from DB"""
        if value is None:
            return value
        return self.bytes_to_human(value)
    
    def bytes_to_human(self, bytes_value):
        """Convert bytes to human-readable format"""
        for unit, size in reversed(list(self.SIZE_UNITS.items())):
            if bytes_value >= size:
                return f"{bytes_value / size:.1f}{unit}"
        return f"{bytes_value}B"
    
    def validate(self, value, model_instance):
        """Validate file size"""
        super().validate(value, model_instance)
        
        if value and value < 0:
            raise ValidationError('File size cannot be negative')

# Usage
class FileUpload(models.Model):
    filename = models.CharField(max_length=255)
    file_size = FileSizeField(help_text="Enter size like '100MB' or '1.5GB'")
```

### 5. Currency Field - Multi-Currency Support

**Scenario**: E-commerce with international currency support

```python
import json
from decimal import Decimal
from django.db import models
from django.core.exceptions import ValidationError

class CurrencyField(models.TextField):
    """Field for storing multi-currency amounts"""
    
    SUPPORTED_CURRENCIES = ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD']
    
    def to_python(self, value):
        """Convert to dictionary of currency amounts"""
        if not value:
            return {}
        
        if isinstance(value, dict):
            return value
        
        try:
            data = json.loads(value)
            # Convert string values to Decimal for precise calculation
            return {currency: Decimal(str(amount)) for currency, amount in data.items()}
        except (json.JSONDecodeError, ValueError):
            raise ValidationError('Invalid currency data format')
    
    def get_prep_value(self, value):
        """Convert dictionary to JSON for storage"""
        if not value:
            return '{}'
        
        # Convert Decimal to string for JSON serialization
        serializable = {currency: str(amount) for currency, amount in value.items()}
        return json.dumps(serializable)
    
    def validate(self, value, model_instance):
        """Validate currency codes and amounts"""
        super().validate(value, model_instance)
        
        if not value:
            return
        
        for currency, amount in value.items():
            if currency not in self.SUPPORTED_CURRENCIES:
                raise ValidationError(f'Unsupported currency: {currency}')
            
            try:
                amount = Decimal(str(amount))
                if amount < 0:
                    raise ValidationError('Currency amounts must be positive')
            except (ValueError, TypeError):
                raise ValidationError(f'Invalid amount for {currency}')

# Usage
class Product(models.Model):
    name = models.CharField(max_length=200)
    prices = CurrencyField(help_text="Enter prices as JSON: {'USD': 99.99, 'EUR': 89.99}")
    
    def get_price(self, currency='USD'):
        """Helper method to get price in specific currency"""
        return self.prices.get(currency, Decimal('0'))
```

### 6. Geographic Coordinate Field

**Scenario**: Storing precise location data

```python
from decimal import Decimal
from django.db import models
from django.core.exceptions import ValidationError

class CoordinateField(models.CharField):
    """Field for storing and validating geographic coordinates"""
    
    def __init__(self, coord_type='lat', *args, **kwargs):
        self.coord_type = coord_type  # 'lat' or 'lng'
        kwargs['max_length'] = 20
        super().__init__(*args, **kwargs)
    
    def to_python(self, value):
        """Convert to Decimal for precise coordinate storage"""
        if value is None:
            return value
        
        try:
            return Decimal(str(value))
        except ValueError:
            raise ValidationError('Enter a valid coordinate value')
    
    def validate(self, value, model_instance):
        """Validate coordinate ranges"""
        super().validate(value, model_instance)
        
        if value is None:
            return
        
        coord = Decimal(str(value))
        
        if self.coord_type == 'lat':
            if not (-90 <= coord <= 90):
                raise ValidationError('Latitude must be between -90 and 90 degrees')
        elif self.coord_type == 'lng':
            if not (-180 <= coord <= 180):
                raise ValidationError('Longitude must be between -180 and 180 degrees')

class LocationField(models.Model):
    """Composite field for complete location data"""
    latitude = CoordinateField(coord_type='lat')
    longitude = CoordinateField(coord_type='lng')
    
    class Meta:
        abstract = True
    
    def get_coordinates(self):
        """Get coordinates as tuple"""
        return (float(self.latitude), float(self.longitude))
    
    def distance_to(self, other_lat, other_lng):
        """Calculate distance to another point (simplified)"""
        from math import radians, cos, sin, sqrt, atan2
        
        # Convert to radians
        lat1, lng1 = radians(float(self.latitude)), radians(float(self.longitude))
        lat2, lng2 = radians(float(other_lat)), radians(float(other_lng))
        
        # Haversine formula for distance calculation
        dlat = lat2 - lat1
        dlng = lng2 - lng1
        
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlng/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        
        # Earth's radius in kilometers
        earth_radius = 6371
        
        return earth_radius * c

# Usage
class Store(LocationField):
    name = models.CharField(max_length=200)
    address = models.TextField()
```

## 🏢 Real-World Production Examples

### Slack's Message Field with Mentions

```python
import re
import json
from django.db import models
from django.core.exceptions import ValidationError

class SlackMessageField(models.TextField):
    """Field that processes Slack-style mentions and formatting"""
    
    def to_python(self, value):
        """Process message with mentions and formatting"""
        if not value:
            return {'text': '', 'mentions': [], 'channels': [], 'formatted': ''}
        
        if isinstance(value, dict):
            return value
        
        # Extract mentions (@username)
        mentions = re.findall(r'@(\w+)', value)
        
        # Extract channel references (#channel)
        channels = re.findall(r'#(\w+)', value)
        
        # Create formatted version with HTML
        formatted = value
        formatted = re.sub(r'@(\w+)', r'<span class="mention">@\\1</span>', formatted)
        formatted = re.sub(r'#(\w+)', r'<span class="channel">#\\1</span>', formatted)
        formatted = re.sub(r'\*([^*]+)\*', r'<strong>\\1</strong>', formatted)  # Bold
        formatted = re.sub(r'_([^_]+)_', r'<em>\\1</em>', formatted)  # Italic
        
        return {
            'text': value,
            'mentions': list(set(mentions)),
            'channels': list(set(channels)),
            'formatted': formatted
        }
    
    def get_prep_value(self, value):
        """Store as JSON"""
        if isinstance(value, dict):
            return json.dumps(value)
        return json.dumps({'text': value or '', 'mentions': [], 'channels': [], 'formatted': value or ''})

# Usage
class ChatMessage(models.Model):
    content = SlackMessageField(help_text="Supports @mentions and #channels")
    sender = models.CharField(max_length=50)
```

### Stripe's Money Field

```python
from decimal import Decimal
from django.db import models
from django.core.exceptions import ValidationError

class MoneyField(models.DecimalField):
    """Precise money field with currency support"""
    
    def __init__(self, currency='USD', *args, **kwargs):
        self.currency = currency
        kwargs['max_digits'] = kwargs.get('max_digits', 10)
        kwargs['decimal_places'] = kwargs.get('decimal_places', 2)
        super().__init__(*args, **kwargs)
    
    def to_python(self, value):
        """Convert to Money object"""
        if value is None:
            return None
        
        if hasattr(value, 'amount'):  # Already a Money object
            return value
        
        amount = super().to_python(value)
        return Money(amount, self.currency)
    
    def get_prep_value(self, value):
        """Extract amount for database storage"""
        if hasattr(value, 'amount'):
            return value.amount
        return super().get_prep_value(value)

class Money:
    """Money value object with currency"""
    
    def __init__(self, amount, currency='USD'):
        self.amount = Decimal(str(amount))
        self.currency = currency
    
    def __str__(self):
        return f"{self.currency} {self.amount:.2f}"
    
    def __add__(self, other):
        if self.currency != other.currency:
            raise ValueError("Cannot add different currencies")
        return Money(self.amount + other.amount, self.currency)
    
    def __sub__(self, other):
        if self.currency != other.currency:
            raise ValueError("Cannot subtract different currencies")
        return Money(self.amount - other.amount, self.currency)

# Usage
class Payment(models.Model):
    amount = MoneyField(currency='USD')
    fee = MoneyField(currency='USD')
```

### GitHub's Repository URL Field

```python
import re
from django.db import models
from django.core.exceptions import ValidationError

class GitRepositoryField(models.URLField):
    """Field that validates and normalizes Git repository URLs"""
    
    SUPPORTED_PROVIDERS = {
        'github.com': r'github\.com[/:]([\w\-\.]+)/([\w\-\.]+)',
        'gitlab.com': r'gitlab\.com[/:]([\w\-\.]+)/([\w\-\.]+)', 
        'bitbucket.org': r'bitbucket\.org[/:]([\w\-\.]+)/([\w\-\.]+)'
    }
    
    def to_python(self, value):
        """Normalize repository URL format"""
        if not value:
            return value
        
        # Convert SSH URLs to HTTPS
        value = re.sub(r'^git@([^:]+):', r'https://\\1/', value)
        
        # Remove .git suffix
        value = re.sub(r'\.git$', '', value)
        
        return super().to_python(value)
    
    def validate(self, value, model_instance):
        """Validate repository URL format"""
        super().validate(value, model_instance)
        
        if not value:
            return
        
        # Check if URL matches supported providers
        is_valid = False
        for provider, pattern in self.SUPPORTED_PROVIDERS.items():
            if re.search(pattern, value):
                is_valid = True
                break
        
        if not is_valid:
            raise ValidationError('Enter a valid Git repository URL (GitHub, GitLab, or Bitbucket)')
    
    def extract_info(self, value):
        """Extract repository information"""
        if not value:
            return None
        
        for provider, pattern in self.SUPPORTED_PROVIDERS.items():
            match = re.search(pattern, value)
            if match:
                return {
                    'provider': provider,
                    'owner': match.group(1),
                    'repo': match.group(2),
                    'url': value
                }
        return None

# Usage
class Project(models.Model):
    name = models.CharField(max_length=200)
    repository = GitRepositoryField(help_text="GitHub, GitLab, or Bitbucket repository URL")
```

## 🎯 Key Takeaways

1. **Custom fields encapsulate complex data logic** in reusable components
2. **to_python() handles input conversion** and normalization
3. **get_prep_value() prepares data for database storage**
4. **validate() implements business-specific validation rules**
5. **from_db_value() transforms data when loading from database**
6. **Custom fields improve code reusability** across multiple models
7. **Domain-specific validation** prevents invalid data at the field level

Custom fields let you extend Django's type system to match your application's specific needs, creating cleaner and more maintainable code!
''',
    "difficulty": "advanced",
    "estimated_time": 50,
    "xp_reward": 30,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals", "django-transactions"],
    "exercises": [
        {
            "id": "custom_fields_1",
            "title": "Explore Specialized Data Types",
            "prompt": "Let's examine our user profiles table with various specialized data types. Write a query to see the structure and sample data.",
            "table_name": "user_profiles",
            "initial_query": "SELECT * FROM user_profiles LIMIT 3;",
            "expected_keywords": ["SELECT", "*", "FROM", "user_profiles"],
            "hint": "Use SELECT * FROM user_profiles LIMIT 3; to explore the custom field data types",
            "solution": "SELECT * FROM user_profiles LIMIT 3;",
            "explanation": "This shows our specialized table with phone numbers, coordinates, color preferences, and other data types that would benefit from custom Django fields for validation and formatting."
        },
        {
            "id": "custom_fields_2",
            "title": "Analyze Phone Number Formats",
            "prompt": "Look at the variety of phone number formats in our data. Write a query to see all phone numbers and observe the different input formats that a custom PhoneNumberField would need to handle.",
            "table_name": "user_profiles",
            "expected_keywords": ["SELECT", "username", "phone_number"],
            "hint": "Select username and phone_number to see the format variations",
            "solution": "SELECT username, phone_number FROM user_profiles WHERE phone_number IS NOT NULL;",
            "explanation": "This shows different phone number formats like '(555) 123-4567', '+1-555-987-6543', and '555.456.7890'. A custom PhoneNumberField would standardize these to a consistent format like '+15551234567'."
        },
        {
            "id": "custom_fields_3",
            "title": "Geographic Coordinate Data",
            "prompt": "Examine the geographic coordinate data. Write a query to show usernames with their latitude and longitude coordinates.",
            "table_name": "user_profiles",
            "expected_keywords": ["SELECT", "username", "location_lat", "location_lng"],
            "hint": "Select username, location_lat, and location_lng to see coordinate data",
            "solution": "SELECT username, location_lat, location_lng FROM user_profiles WHERE location_lat IS NOT NULL;",
            "explanation": "These coordinates represent precise geographic locations. A custom CoordinateField would validate that latitude is between -90 to 90 and longitude between -180 to 180, preventing invalid coordinate data."
        },
        {
            "id": "custom_fields_4",
            "title": "Color Preference Validation",
            "prompt": "Look at the color preferences stored as comma-separated hex codes. Write a query to see how users store their color preferences.",
            "table_name": "user_profiles", 
            "expected_keywords": ["SELECT", "username", "color_preferences"],
            "hint": "Select username and color_preferences to see color data",
            "solution": "SELECT username, color_preferences FROM user_profiles WHERE color_preferences IS NOT NULL;",
            "explanation": "The color data shows hex color codes like '#FF5733,#33FF57,#3357FF'. A custom ColorListField would validate each hex code format and normalize them (e.g., convert '#F00' to '#FF0000')."
        },
        {
            "id": "custom_fields_5",
            "title": "Multi-Currency Product Pricing",
            "prompt": "Examine the products table to see multi-currency pricing data. Write a query to show product names and their pricing in different currencies.",
            "table_name": "products",
            "expected_keywords": ["SELECT", "name", "price_data"],
            "hint": "Select name and price_data to see the JSON currency structure",
            "solution": "SELECT name, price_data FROM products WHERE price_data IS NOT NULL;",
            "explanation": "The price_data shows JSON like '{\"USD\": 1299.99, \"EUR\": 1199.99, \"GBP\": 999.99}'. A custom CurrencyField would validate currency codes, ensure positive amounts, and provide helper methods to get prices in specific currencies."
        },
        {
            "id": "custom_fields_6",
            "title": "Application Configuration Settings",
            "prompt": "Look at the app_settings table to see various specialized configuration data types. Write a query to explore the different setting formats.",
            "table_name": "app_settings",
            "expected_keywords": ["SELECT", "setting_key", "color_theme", "file_size_limits"],
            "hint": "Select setting_key and the configuration fields to see the data patterns",
            "solution": "SELECT setting_key, color_theme, file_size_limits FROM app_settings;",
            "explanation": "This shows configuration data like color themes '#2196F3,#FFC107,#4CAF50' and file size limits '{\"max_upload\": \"100MB\", \"max_avatar\": \"5MB\"}'. Custom fields would validate color formats and parse human-readable file sizes to bytes for storage."
        }
    ],
    "key_concepts": [
        "Custom Field Class Inheritance",
        "to_python() Method for Input Processing",
        "get_prep_value() for Database Storage",
        "validate() Method for Business Rules",
        "from_db_value() for Database Loading",
        "Field Normalization and Standardization",
        "Complex Data Type Encapsulation",
        "Reusable Field Components"
    ]
}