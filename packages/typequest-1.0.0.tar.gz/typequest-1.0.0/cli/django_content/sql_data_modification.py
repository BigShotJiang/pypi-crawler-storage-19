"""
SQL Data Modification lesson content
"""

SQL_DATA_MODIFICATION_LESSON = {
    "id": 38,
    "chapter": 38,
    "title": "SQL Data Modification: INSERT, UPDATE, DELETE",
    "slug": "sql-data-modification",
    "content": '''
# SQL Data Modification: Changing the Database Landscape

Reading data tells you what happened, but modifying data shapes what happens next. When you post on Instagram, update your Spotify playlist, or delete an Amazon review, you're using SQL data modification statements. These operations transform static databases into dynamic, living systems that respond to user actions in real-time.

## The Three Pillars of Data Modification

**INSERT** - Adding new records (creating content)
**UPDATE** - Changing existing records (editing content) 
**DELETE** - Removing records (removing content)

**Real-world examples:**
- **Instagram:** INSERT new posts, UPDATE profile info, DELETE old photos
- **Amazon:** INSERT new products, UPDATE inventory, DELETE discontinued items
- **Netflix:** INSERT new shows, UPDATE ratings, DELETE expired content

## Our Practice Tables for Data Modification

### Table 1: User Profiles (user_profiles)
**First action: `SELECT * FROM user_profiles;`**

```
+----+-----------+------------------+---------------+--------+
| id | username  | email            | follower_count| status |
+----+-----------+------------------+---------------+--------+
| 1  | sarah_dev | sarah@email.com  | 1500          | active |
| 2  | mike_photo| mike@gmail.com   | 2300          | active |
| 3  | old_user  | old@email.com    | 0             | inactive|
+----+-----------+------------------+---------------+--------+
```

### Table 2: Product Inventory (product_inventory)
**First action: `SELECT * FROM product_inventory;`**

```
+----+------------------+----------+-------+--------+
| id | product_name     | price    | stock | status |
+----+------------------+----------+-------+--------+
| 1  | iPhone 15        | 999.00   | 45    | active |
| 2  | MacBook Pro      | 2499.00  | 12    | active |
| 3  | Old Model Phone  | 299.00   | 0     | discontinued |
+----+------------------+----------+-------+--------+
```

### Table 3: Content Library (content_library)
**First action: `SELECT * FROM content_library;`**

```
+----+------------------+----------+--------+----------+
| id | title            | category | rating | status   |
+----+------------------+----------+--------+----------+
| 1  | Python Tutorial  | Tech     | 4.5    | published|
| 2  | Old Course       | Tech     | 2.1    | draft    |
+----+------------------+----------+--------+----------+
```

## INSERT: Adding New Data

INSERT statements create new records in your database - like users signing up, products being added, or content being published.

### Basic INSERT Syntax

**Single Record INSERT**
```sql
INSERT INTO table_name (column1, column2, column3)
VALUES (value1, value2, value3);
```

### Real-World INSERT Examples

**Adding New Users (Instagram/TikTok style)**
```sql
-- New user registration
INSERT INTO user_profiles (username, email, follower_count, status)
VALUES ('jenny_travel', 'jenny@email.com', 0, 'active');

-- Multiple new users (batch registration)
INSERT INTO user_profiles (username, email, follower_count, status)
VALUES 
    ('alex_tech', 'alex@email.com', 0, 'active'),
    ('lisa_art', 'lisa@gmail.com', 0, 'active'),
    ('mark_fitness', 'mark@email.com', 0, 'active');
```

**Adding Products to Inventory (Amazon/e-commerce style)**
```sql
-- New product launch
INSERT INTO product_inventory (product_name, price, stock, status)
VALUES ('AirPods Pro 2', 249.00, 100, 'active');

-- Bulk product additions
INSERT INTO product_inventory (product_name, price, stock, status)
VALUES
    ('iPad Air', 599.00, 50, 'active'),
    ('Apple Watch', 399.00, 75, 'active'),
    ('Magic Keyboard', 299.00, 25, 'active');
```

**Publishing New Content (YouTube/Netflix style)**
```sql
-- New course publication
INSERT INTO content_library (title, category, rating, status)
VALUES ('Advanced SQL Mastery', 'Tech', 4.8, 'published');

-- Content batch upload
INSERT INTO content_library (title, category, rating, status)
VALUES
    ('JavaScript Fundamentals', 'Tech', 4.6, 'published'),
    ('React Complete Guide', 'Tech', 4.7, 'published'),
    ('Database Design Patterns', 'Tech', 4.5, 'published');
```

### INSERT with SELECT (Data Migration)

**Copying Data Between Tables**
```sql
-- Create archive of inactive users
INSERT INTO user_archive (username, email, archived_date)
SELECT username, email, CURRENT_DATE
FROM user_profiles
WHERE status = 'inactive';

-- Copy top-rated content to featured collection
INSERT INTO featured_content (title, category, rating)
SELECT title, category, rating
FROM content_library
WHERE rating > 4.5 AND status = 'published';
```

### Advanced INSERT Patterns

**INSERT with Default Values**
```sql
-- Using database defaults for some columns
INSERT INTO user_profiles (username, email)  -- follower_count defaults to 0
VALUES ('default_user', 'default@email.com');
```

**INSERT with Calculated Values**
```sql
-- Product with calculated pricing
INSERT INTO product_inventory (product_name, price, stock, status)
VALUES ('Discounted iPhone', (SELECT price * 0.8 FROM product_inventory WHERE product_name = 'iPhone 15'), 20, 'active');
```

## UPDATE: Modifying Existing Data

UPDATE statements change existing records - like users updating profiles, inventory adjustments, or content revisions.

### Basic UPDATE Syntax

```sql
UPDATE table_name
SET column1 = new_value1, column2 = new_value2
WHERE condition;
```

### User Profile Updates

**Social Media Profile Management**
```sql
-- User gains followers (Instagram/TikTok growth)
UPDATE user_profiles
SET follower_count = 2500
WHERE username = 'sarah_dev';

-- Bulk follower update (viral growth simulation)
UPDATE user_profiles
SET follower_count = follower_count + 500
WHERE status = 'active' AND follower_count > 1000;

-- Email address change
UPDATE user_profiles
SET email = 'sarah.developer@newemail.com'
WHERE username = 'sarah_dev';

-- Account status changes
UPDATE user_profiles
SET status = 'inactive'
WHERE follower_count = 0 AND username = 'old_user';
```

### Inventory Management Updates

**E-commerce Stock and Pricing Management**
```sql
-- Stock adjustment after sales
UPDATE product_inventory
SET stock = stock - 5
WHERE product_name = 'iPhone 15';

-- Price reduction (sale/promotion)
UPDATE product_inventory
SET price = price * 0.9  -- 10% discount
WHERE status = 'active' AND stock > 50;

-- Discontinue low-stock items
UPDATE product_inventory
SET status = 'discontinued'
WHERE stock = 0;

-- Seasonal pricing adjustment
UPDATE product_inventory
SET price = CASE 
    WHEN product_name LIKE '%iPhone%' THEN price * 0.95
    WHEN product_name LIKE '%MacBook%' THEN price * 0.98
    ELSE price
END
WHERE status = 'active';
```

### Content Management Updates

**Content Platform Management**
```sql
-- Content performance update
UPDATE content_library
SET rating = 4.9
WHERE title = 'Python Tutorial';

-- Bulk status update (publish drafts)
UPDATE content_library
SET status = 'published'
WHERE rating > 4.0 AND status = 'draft';

-- Content categorization update
UPDATE content_library
SET category = 'Programming'
WHERE category = 'Tech' AND title LIKE '%Programming%';
```

### Advanced UPDATE Patterns

**Conditional Updates with Complex Logic**
```sql
-- User tier advancement based on followers
UPDATE user_profiles
SET status = CASE 
    WHEN follower_count >= 10000 THEN 'influencer'
    WHEN follower_count >= 1000 THEN 'creator'
    ELSE 'user'
END
WHERE status = 'active';

-- Dynamic pricing based on stock levels
UPDATE product_inventory
SET price = CASE 
    WHEN stock < 10 THEN price * 1.05  -- Increase price for low stock
    WHEN stock > 100 THEN price * 0.95  -- Decrease price for excess stock
    ELSE price
END
WHERE status = 'active';
```

**UPDATE with JOIN (Advanced)**
```sql
-- Update user follower counts based on activity
UPDATE user_profiles
SET follower_count = follower_count + 
    (SELECT COUNT(*) * 10 FROM user_activity WHERE user_activity.username = user_profiles.username)
WHERE status = 'active';
```

## DELETE: Removing Data

DELETE statements remove records from your database - like users deleting posts, removing products, or cleaning up old data.

### Basic DELETE Syntax

```sql
DELETE FROM table_name
WHERE condition;
```

### User Management Deletions

**Account and Profile Management**
```sql
-- Remove inactive users (data cleanup)
DELETE FROM user_profiles
WHERE status = 'inactive' AND follower_count = 0;

-- Remove users who haven't been active
DELETE FROM user_profiles
WHERE username = 'old_user';

-- Bulk cleanup of test accounts
DELETE FROM user_profiles
WHERE email LIKE '%test%' OR username LIKE '%test%';
```

### Inventory Management Deletions

**Product Catalog Cleanup**
```sql
-- Remove discontinued products with zero stock
DELETE FROM product_inventory
WHERE status = 'discontinued' AND stock = 0;

-- Remove outdated products
DELETE FROM product_inventory
WHERE product_name = 'Old Model Phone';

-- Cleanup low-value items
DELETE FROM product_inventory
WHERE price < 50 AND stock < 5 AND status = 'discontinued';
```

### Content Management Deletions

**Content Library Maintenance**
```sql
-- Remove poorly performing content
DELETE FROM content_library
WHERE rating < 3.0 AND status = 'draft';

-- Remove specific outdated content
DELETE FROM content_library
WHERE title = 'Old Course';

-- Cleanup unpublished low-rated content
DELETE FROM content_library
WHERE status = 'draft' AND rating < 2.5;
```

### Safe DELETE Practices

**Always Use WHERE Clauses**
```sql
-- ❌ DANGEROUS: Deletes ALL records
DELETE FROM user_profiles;

-- ✅ SAFE: Deletes specific records
DELETE FROM user_profiles
WHERE status = 'inactive';

-- ✅ EXTRA SAFE: Count first, then delete
SELECT COUNT(*) FROM user_profiles WHERE status = 'inactive';
-- If count looks correct, then:
DELETE FROM user_profiles WHERE status = 'inactive';
```

## Data Modification Best Practices

### 1. Always Backup Before Bulk Operations

```sql
-- Create backup before major changes
CREATE TABLE user_profiles_backup AS
SELECT * FROM user_profiles;

-- Then perform your modifications
UPDATE user_profiles SET status = 'verified' WHERE follower_count > 10000;
```

### 2. Use Transactions for Related Changes

```sql
-- Ensure all related changes succeed or fail together
BEGIN TRANSACTION;

UPDATE product_inventory 
SET stock = stock - 1 
WHERE product_name = 'iPhone 15';

INSERT INTO sales_log (product, quantity, sale_date)
VALUES ('iPhone 15', 1, CURRENT_DATE);

-- If everything looks good:
COMMIT;
-- If something went wrong:
-- ROLLBACK;
```

### 3. Validate Before Modifying

```sql
-- Check impact before deletion
SELECT COUNT(*) AS records_to_delete
FROM user_profiles 
WHERE status = 'inactive' AND follower_count = 0;

-- Check update impact
SELECT username, follower_count, 
       follower_count + 100 AS new_follower_count
FROM user_profiles
WHERE status = 'active';
-- If preview looks correct, run the actual UPDATE
```

## Real-World Data Modification Scenarios

### E-commerce Product Launch

**Complete Product Launch Workflow**
```sql
-- 1. Add new product
INSERT INTO product_inventory (product_name, price, stock, status)
VALUES ('iPhone 16', 1099.00, 100, 'active');

-- 2. Update related products (mark previous version as discounted)
UPDATE product_inventory
SET price = price * 0.9,
    status = 'clearance'
WHERE product_name = 'iPhone 15';

-- 3. Remove truly obsolete products
DELETE FROM product_inventory
WHERE product_name LIKE '%iPhone 13%' AND stock = 0;
```

### Social Media User Lifecycle

**User Account Management Workflow**
```sql
-- 1. New user registration
INSERT INTO user_profiles (username, email, follower_count, status)
VALUES ('new_creator', 'creator@email.com', 0, 'active');

-- 2. User growth and status updates
UPDATE user_profiles
SET follower_count = 15000,
    status = 'influencer'
WHERE username = 'new_creator';

-- 3. Cleanup inactive accounts
DELETE FROM user_profiles
WHERE status = 'inactive' 
  AND follower_count < 10
  AND email NOT LIKE '%@company.com';  -- Keep company accounts
```

### Content Platform Management

**Content Lifecycle Management**
```sql
-- 1. Publish new content
INSERT INTO content_library (title, category, rating, status)
VALUES ('Master Class: Advanced SQL', 'Education', 0.0, 'published');

-- 2. Update content based on feedback
UPDATE content_library
SET rating = 4.8,
    category = 'Premium Education'
WHERE title = 'Master Class: Advanced SQL';

-- 3. Archive outdated content
UPDATE content_library
SET status = 'archived'
WHERE rating < 3.0 AND status = 'published';

-- 4. Remove unsuccessful drafts
DELETE FROM content_library
WHERE status = 'draft' AND rating < 2.0;
```

## Performance and Safety Considerations

### Efficient Modification Queries

```sql
-- ✅ Use indexes for WHERE clauses
UPDATE user_profiles 
SET follower_count = follower_count + 100
WHERE id = 1;  -- id is typically indexed

-- ✅ Batch operations when possible
UPDATE product_inventory
SET price = price * 0.95
WHERE category = 'Electronics' AND stock > 10;
```

### Data Integrity Safeguards

```sql
-- ✅ Use constraints and checks
UPDATE product_inventory
SET stock = stock - 5
WHERE product_name = 'iPhone 15' AND stock >= 5;  -- Ensure sufficient stock

-- ✅ Validate data before insertion
INSERT INTO user_profiles (username, email, follower_count, status)
SELECT 'validated_user', 'valid@email.com', 0, 'active'
WHERE 'valid@email.com' NOT IN (SELECT email FROM user_profiles);  -- Prevent duplicates
```

Data modification transforms databases from static repositories into dynamic, responsive systems. Whether you're managing Instagram's user growth, Amazon's inventory fluctuations, or Netflix's content library, these operations ensure your data reflects real-world changes accurately and efficiently! 🔧📊
    ''',
    "is_free": False,
    "xp_reward": 125,
    "exercises": [
        {
            "id": "user-management-modifications",
            "title": "User Profile Management with INSERT, UPDATE, DELETE",
            "type": "practice",
            "instructions": """Practice data modification operations to manage user profiles in a social media platform, simulating real user lifecycle events.

Your tasks:
1. First explore the data with SELECT * FROM user_profiles;
2. Add new users with INSERT statements
3. Update user follower counts and statuses
4. Change user email addresses
5. Remove inactive users with DELETE
6. Perform bulk user status updates

Table: user_profiles
Columns: id, username, email, follower_count, status

Note: Be careful with DELETE operations - always use WHERE clauses!""",
            "starter_code": """-- Task 1: Explore current user data
SELECT * FROM user_profiles;

-- Task 2: Add new users to the platform
-- INSERT a single user: 'jenny_travel', 'jenny@email.com', 0 followers, 'active'


-- Task 3: Update follower counts (simulate user growth)
-- UPDATE sarah_dev's follower_count to 3000


-- Task 4: Change email address  
-- UPDATE mike_photo's email to 'mike.photographer@gmail.com'


-- Task 5: Remove inactive users
-- DELETE users where status = 'inactive' AND follower_count = 0


-- Task 6: Bulk status update based on follower count
-- UPDATE status to 'influencer' for users with follower_count >= 2500
""",
            "solution": """-- Task 1: Explore current user data
SELECT * FROM user_profiles;

-- Task 2: Add new users to the platform
INSERT INTO user_profiles (username, email, follower_count, status)
VALUES ('jenny_travel', 'jenny@email.com', 0, 'active');

-- Task 3: Update follower counts (simulate user growth)
UPDATE user_profiles
SET follower_count = 3000
WHERE username = 'sarah_dev';

-- Task 4: Change email address
UPDATE user_profiles
SET email = 'mike.photographer@gmail.com'
WHERE username = 'mike_photo';

-- Task 5: Remove inactive users
DELETE FROM user_profiles
WHERE status = 'inactive' AND follower_count = 0;

-- Task 6: Bulk status update based on follower count
UPDATE user_profiles
SET status = 'influencer'
WHERE follower_count >= 2500;""",
            "test_cases": [
                {
                    "name": "INSERT with VALUES",
                    "input": "INSERT INTO user_profiles (username, email, follower_count, status) VALUES ('test_user', 'test@email.com', 0, 'active');",
                    "expected_contains": ["INSERT INTO", "VALUES", "username", "email"]
                },
                {
                    "name": "UPDATE with WHERE condition",
                    "input": "UPDATE user_profiles SET follower_count = 3000 WHERE username = 'sarah_dev';",
                    "expected_contains": ["UPDATE", "SET", "WHERE", "follower_count"]
                }
            ],
            "xp_reward": 75,
            "hints": [
                "INSERT syntax: INSERT INTO table (columns) VALUES (values);",
                "UPDATE syntax: UPDATE table SET column = value WHERE condition;",
                "DELETE syntax: DELETE FROM table WHERE condition;",
                "Always use WHERE in UPDATE and DELETE to avoid modifying all rows",
                "Check your changes with SELECT statements after modifications"
            ]
        },
        {
            "id": "ecommerce-inventory-modifications",
            "title": "E-commerce Inventory Management with Data Modifications",
            "type": "practice",
            "instructions": """Practice comprehensive inventory management using INSERT, UPDATE, and DELETE operations to simulate real e-commerce scenarios.

Your tasks:
1. Explore product inventory data
2. Add new products to the catalog
3. Update stock levels after sales
4. Apply promotional pricing changes
5. Discontinue products and cleanup
6. Perform bulk operations for business scenarios

Table: product_inventory
Columns: id, product_name, price, stock, status""",
            "starter_code": """-- Task 1: Explore current inventory
SELECT * FROM product_inventory;

-- Task 2: Add new products to catalog
-- INSERT 'AirPods Pro 2' with price 249.00, stock 50, status 'active'


-- Task 3: Update stock after sales
-- UPDATE iPhone 15 stock, reduce by 10 units (simulate sales)


-- Task 4: Apply promotional pricing (10% discount)
-- UPDATE all active products with stock > 20, reduce price by 10%


-- Task 5: Discontinue and remove old products
-- UPDATE products with stock = 0 to status 'discontinued'
-- Then DELETE products that are discontinued AND have stock = 0


-- Task 6: Bulk pricing adjustment
-- Increase prices by 5% for all products with price > 1000
""",
            "solution": """-- Task 1: Explore current inventory
SELECT * FROM product_inventory;

-- Task 2: Add new products to catalog
INSERT INTO product_inventory (product_name, price, stock, status)
VALUES ('AirPods Pro 2', 249.00, 50, 'active');

-- Task 3: Update stock after sales
UPDATE product_inventory
SET stock = stock - 10
WHERE product_name = 'iPhone 15';

-- Task 4: Apply promotional pricing (10% discount)
UPDATE product_inventory
SET price = price * 0.9
WHERE status = 'active' AND stock > 20;

-- Task 5: Discontinue and remove old products
UPDATE product_inventory
SET status = 'discontinued'
WHERE stock = 0;

DELETE FROM product_inventory
WHERE status = 'discontinued' AND stock = 0;

-- Task 6: Bulk pricing adjustment
UPDATE product_inventory
SET price = price * 1.05
WHERE price > 1000;""",
            "test_cases": [
                {
                    "name": "Stock update with calculation",
                    "input": "UPDATE product_inventory SET stock = stock - 10 WHERE product_name = 'iPhone 15';",
                    "expected_contains": ["UPDATE", "SET", "stock = stock -", "WHERE"]
                },
                {
                    "name": "Conditional DELETE with multiple conditions",
                    "input": "DELETE FROM product_inventory WHERE status = 'discontinued' AND stock = 0;",
                    "expected_contains": ["DELETE FROM", "WHERE", "AND", "status", "stock"]
                }
            ],
            "xp_reward": 80,
            "hints": [
                "Use arithmetic in UPDATE: stock = stock - 10 for reducing stock",
                "Multiply by decimal for percentage: price = price * 0.9 for 10% off",
                "Use AND in WHERE clauses for multiple conditions",
                "Consider doing operations in logical order (update status, then delete)",
                "Test with SELECT before running destructive operations"
            ]
        }
    ]
}