"""
Django Migrations - Lesson 2: Writing Custom Migrations and Data Migrations
Learn to write powerful custom migrations with real-world examples
"""

DJANGO_MIGRATIONS_CUSTOM_LESSON = {
    "id": 41,
    "chapter": 41,
    "title": "Writing Custom Django Migrations",
    "slug": "django-migrations-custom",
    "description": "Master custom migrations for complex database transformations",
    "content": '''# Writing Custom Django Migrations

## 🎯 Beyond Simple Schema Changes

While Django automatically generates migrations for model changes, real-world applications often need **custom migrations** for:
- **Data transformations** (like combining first_name + last_name into full_name)
- **Complex schema changes** (like table splits or merges)
- **Initial data setup** (creating admin users, default categories)
- **Database optimizations** (adding indexes for specific use cases)

## 📱 Real Example: Twitter's Username Migration

In 2017, Twitter changed usernames to allow more characters and emoji. Here's how they might have handled it:

**Before**: Usernames limited to alphanumeric + underscore
**After**: Usernames allow Unicode characters, emoji, etc.

This required a **custom migration** to:
1. Add a new `username_normalized` field
2. Populate it with cleaned usernames
3. Update all related tables
4. Switch the application to use the new field

## 🗄️ Our Enhanced Social Media Database

Let's work with an evolved version of our social media platform:

```sql
-- Enhanced users table with profile features
CREATE TABLE users_enhanced (
    id SERIAL PRIMARY KEY,
    username VARCHAR(30) UNIQUE NOT NULL,
    email VARCHAR(254) NOT NULL,
    password VARCHAR(128) NOT NULL,
    first_name VARCHAR(30),
    last_name VARCHAR(30),
    bio TEXT,
    profile_picture VARCHAR(200),
    is_verified BOOLEAN DEFAULT FALSE,
    follower_count INTEGER DEFAULT 0,
    following_count INTEGER DEFAULT 0,
    date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample data with names to combine
INSERT INTO users_enhanced (username, email, password, first_name, last_name, bio, follower_count) VALUES 
('elonmusk', 'elon@tesla.com', 'hash123', 'Elon', 'Musk', 'CEO of Tesla and SpaceX', 150000000),
('sundarpichai', 'sundar@google.com', 'hash456', 'Sundar', 'Pichai', 'CEO of Alphabet/Google', 5000000),
('satyanadella', 'satya@microsoft.com', 'hash789', 'Satya', 'Nadella', 'CEO of Microsoft', 3000000),
('oprah', 'oprah@oprah.com', 'hash000', 'Oprah', 'Winfrey', 'Media mogul and philanthropist', 45000000);
```

## 🔧 Types of Custom Migrations

### 1. Data Migration with RunPython

**Scenario**: Combine first_name and last_name into a full_name field

```python
# Migration file: 0005_combine_user_names.py
from django.db import migrations

def combine_names(apps, schema_editor):
    """Combine first_name and last_name into full_name"""
    User = apps.get_model('accounts', 'User')
    
    for user in User.objects.all():
        if user.first_name and user.last_name:
            user.full_name = f"{user.first_name} {user.last_name}"
        elif user.first_name:
            user.full_name = user.first_name
        elif user.last_name:
            user.full_name = user.last_name
        else:
            user.full_name = user.username.title()
        user.save()

def reverse_combine_names(apps, schema_editor):
    """Split full_name back into first_name and last_name"""
    User = apps.get_model('accounts', 'User')
    
    for user in User.objects.all():
        if user.full_name and ' ' in user.full_name:
            parts = user.full_name.split(' ', 1)
            user.first_name = parts[0]
            user.last_name = parts[1]
        else:
            user.first_name = user.full_name or ''
            user.last_name = ''
        user.save()

class Migration(migrations.Migration):
    dependencies = [
        ('accounts', '0004_user_full_name'),
    ]
    
    operations = [
        migrations.RunPython(
            combine_names,
            reverse_combine_names,
        ),
    ]
```

### 2. Raw SQL Migration

**Scenario**: Create a materialized view for popular posts

```python
# Migration file: 0008_create_popular_posts_view.py
from django.db import migrations

class Migration(migrations.Migration):
    dependencies = [
        ('social', '0007_post_metrics'),
    ]
    
    operations = [
        migrations.RunSQL(
            """
            CREATE MATERIALIZED VIEW popular_posts AS
            SELECT 
                p.id,
                p.title,
                p.author_id,
                COUNT(l.id) as like_count,
                COUNT(c.id) as comment_count,
                COUNT(l.id) + (COUNT(c.id) * 2) as engagement_score
            FROM posts p
            LEFT JOIN likes l ON p.id = l.post_id
            LEFT JOIN comments c ON p.id = c.post_id
            WHERE p.created_at >= NOW() - INTERVAL '7 days'
            GROUP BY p.id, p.title, p.author_id
            HAVING engagement_score > 10
            ORDER BY engagement_score DESC;
            
            CREATE UNIQUE INDEX ON popular_posts (id);
            """,
            reverse_sql="DROP MATERIALIZED VIEW IF EXISTS popular_posts;"
        ),
    ]
```

### 3. Conditional Migration

**Scenario**: Only run migration on specific databases

```python
def create_admin_user(apps, schema_editor):
    """Create admin user only in development"""
    if schema_editor.connection.alias != "default":
        return  # Skip on other databases
    
    User = apps.get_model('auth', 'User')
    if not User.objects.filter(username='admin').exists():
        User.objects.create_superuser(
            username='admin',
            email='admin@example.com',
            password='admin123'  # Change in production!
        )

class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(create_admin_user),
    ]
```

### 4. Large Data Migration with Batching

**Scenario**: Update millions of user records safely

```python
def update_user_slugs_in_batches(apps, schema_editor):
    """Update user slugs in batches to avoid memory issues"""
    from django.utils.text import slugify
    
    User = apps.get_model('accounts', 'User')
    batch_size = 1000
    
    # Process in batches
    total_users = User.objects.count()
    for i in range(0, total_users, batch_size):
        users = User.objects.all()[i:i + batch_size]
        
        for user in users:
            if not user.slug:
                user.slug = slugify(user.username)
        
        # Bulk update for efficiency
        User.objects.bulk_update(users, ['slug'])
        
        print(f"Updated users {i} to {i + len(users)}")

class Migration(migrations.Migration):
    # Mark as non-atomic for large datasets
    atomic = False
    
    operations = [
        migrations.RunPython(update_user_slugs_in_batches),
    ]
```

## 🏢 Advanced Real-World Examples

### Netflix's Content Migration
When Netflix added support for multiple languages:

```python
def migrate_content_to_multilingual(apps, schema_editor):
    """Migrate single-language content to multi-language structure"""
    Content = apps.get_model('content', 'Content')
    ContentTranslation = apps.get_model('content', 'ContentTranslation')
    
    for content in Content.objects.all():
        # Create English translation from existing data
        ContentTranslation.objects.get_or_create(
            content=content,
            language='en',
            defaults={
                'title': content.title,
                'description': content.description,
                'synopsis': content.synopsis
            }
        )
```

### Spotify's Playlist Migration
When Spotify changed playlist privacy model:

```python
def migrate_playlist_privacy(apps, schema_editor):
    """Update playlist privacy based on old follower count"""
    Playlist = apps.get_model('music', 'Playlist')
    
    for playlist in Playlist.objects.all():
        if playlist.follower_count > 1000:
            playlist.visibility = 'public'
        elif playlist.follower_count > 10:
            playlist.visibility = 'followers_only'
        else:
            playlist.visibility = 'private'
        
    Playlist.objects.bulk_update(Playlist.objects.all(), ['visibility'])
```

## ⚠️ Custom Migration Best Practices

### 1. Always Handle Edge Cases
```python
def safe_data_migration(apps, schema_editor):
    User = apps.get_model('accounts', 'User')
    
    for user in User.objects.all():
        try:
            # Your migration logic
            user.some_field = calculate_value(user)
            user.save()
        except Exception as e:
            # Log error but don't fail entire migration
            print(f"Error processing user {user.id}: {e}")
```

### 2. Test with Production-Like Data
```python
# Always test migrations with:
# - Large datasets (performance)
# - Edge case data (null values, special characters)
# - Different database engines
```

### 3. Make Migrations Reversible When Possible
```python
class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(
            forwards_function,
            reverse_function,  # Always provide reverse!
        ),
    ]
```

## 🎯 Key Takeaways

1. **Custom migrations handle complex scenarios** that automatic migrations can't
2. **Data migrations use RunPython** for complex transformations
3. **Raw SQL migrations** provide maximum database control
4. **Batch processing** prevents memory issues with large datasets
5. **Always test thoroughly** before production deployment

Next, we'll explore advanced migration operations and the Schema Editor!
''',
    "difficulty": "intermediate",
    "estimated_time": 35,
    "xp_reward": 20,
    "prerequisites": ["django-migrations-intro"],
    "exercises": [
        {
            "id": "custom_migrations_1",
            "title": "Analyze Current User Data",
            "prompt": "Before writing our custom migration to combine names, let's examine the current data. Write a query to see users with both first and last names.",
            "table_name": "users_enhanced",
            "initial_query": "SELECT * FROM users_enhanced;",
            "expected_keywords": ["SELECT", "first_name", "last_name", "users_enhanced"],
            "hint": "Select the username, first_name, and last_name columns to see the data we'll combine",
            "solution": "SELECT username, first_name, last_name FROM users_enhanced WHERE first_name IS NOT NULL AND last_name IS NOT NULL;",
            "explanation": "This shows users with both names. In our custom migration, we'd combine these into a full_name field!"
        },
        {
            "id": "custom_migrations_2",
            "title": "Practice Name Combination Logic",
            "prompt": "Simulate the custom migration logic: create a query that combines first_name and last_name into a full name for display.",
            "table_name": "users_enhanced", 
            "expected_keywords": ["SELECT", "CONCAT", "first_name", "last_name"],
            "hint": "Use CONCAT() or || to combine first_name and last_name with a space",
            "solution": "SELECT username, CONCAT(first_name, ' ', last_name) AS full_name FROM users_enhanced WHERE first_name IS NOT NULL AND last_name IS NOT NULL;",
            "explanation": "This simulates what our RunPython migration would do - combining names into a single field. The CONCAT function handles the string combination safely."
        },
        {
            "id": "custom_migrations_3",
            "title": "Handle Edge Cases in Data Migration",
            "prompt": "Write a query to find users who might have issues in our migration (those with missing first or last names).",
            "table_name": "users_enhanced",
            "expected_keywords": ["SELECT", "WHERE", "NULL", "OR"],
            "hint": "Look for users where either first_name OR last_name is NULL",
            "solution": "SELECT username, first_name, last_name FROM users_enhanced WHERE first_name IS NULL OR last_name IS NULL;",
            "explanation": "Good migrations handle edge cases! These users would need special logic in our custom migration - perhaps using just the available name or falling back to username."
        },
        {
            "id": "custom_migrations_4",
            "title": "Analyze High-Impact Users",
            "prompt": "Before making schema changes affecting popular users, write a query to find verified users or those with high follower counts (over 1M).",
            "table_name": "users_enhanced",
            "expected_keywords": ["SELECT", "WHERE", "follower_count", "is_verified"],
            "hint": "Use WHERE with conditions for is_verified = true OR follower_count > 1000000",
            "solution": "SELECT username, follower_count, is_verified FROM users_enhanced WHERE is_verified = true OR follower_count > 1000000 ORDER BY follower_count DESC;",
            "explanation": "High-profile users require extra care during migrations. Any downtime or data issues would be highly visible, so we'd test migrations thoroughly with their data patterns."
        }
    ],
    "key_concepts": [
        "RunPython for Data Migrations",
        "RunSQL for Raw Database Operations", 
        "Batch Processing for Large Datasets",
        "Reversible Migration Design",
        "Edge Case Handling",
        "Production Safety Considerations"
    ]
}