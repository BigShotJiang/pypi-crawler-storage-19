"""
Django Authentication and User Management lesson content
"""

DJANGO_AUTH_LESSON = {
    "id": 6,
    "chapter": 6,
    "title": "Django Authentication and User Management",
    "slug": "django-authentication",
    "content": '''
# Django Authentication and User Management

## What is Django Authentication?

Django comes with a built-in authentication system that handles user accounts, groups, permissions, and cookie-based user sessions. It provides secure user management out of the box.

### Key Components

- **User Model**: Built-in User model with username, email, password
- **Authentication Views**: Login, logout, password change/reset
- **Permissions**: Fine-grained access control
- **Groups**: Organize users with similar permissions
- **Sessions**: Track logged-in users across requests

## User Model

### Built-in User Model

Django provides a User model with these fields:

```python
from django.contrib.auth.models import User

# User fields:
# - username (required)
# - first_name
# - last_name  
# - email
# - password (hashed)
# - is_staff (admin access)
# - is_active (account enabled)
# - is_superuser (full permissions)
# - date_joined
# - last_login
```

### Creating Users

```python
# Create regular user
from django.contrib.auth.models import User

user = User.objects.create_user(
    username='bookworm',
    email='bookworm@example.com',
    password='securepassword123',
    first_name='Book',
    last_name='Lover'
)

# Create superuser (for admin)
admin = User.objects.create_superuser(
    username='admin',
    email='admin@bookstore.com',
    password='adminpass123'
)
```

### Custom User Profile

Extend the User model with additional fields:

```python
# accounts/models.py
from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(max_length=500, blank=True)
    location = models.CharField(max_length=30, blank=True)
    birth_date = models.DateField(null=True, blank=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True)
    
    def __str__(self):
        return f"{self.user.username}'s Profile"

# Signal to create profile when user is created
from django.db.models.signals import post_save
from django.dispatch import receiver

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.userprofile.save()
```

## Authentication Views

### Login View

```python
# accounts/views.py
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from django.contrib import messages

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            if user.is_active:
                login(request, user)
                messages.success(request, f'Welcome back, {user.first_name or user.username}!')
                
                # Redirect to next page or default
                next_page = request.GET.get('next', 'books:book-list')
                return redirect(next_page)
            else:
                messages.error(request, 'Your account has been disabled.')
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'accounts/login.html')
```

### Login Template

```html
<!-- accounts/templates/accounts/login.html -->
{% extends 'books/base.html' %}

{% block title %}Login - {{ block.super }}{% endblock %}

{% block content %}
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h2 class="card-title text-center">Login</h2>
                
                <form method="post">
                    {% csrf_token %}
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" 
                               name="username" required autocomplete="username">
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" 
                               name="password" required autocomplete="current-password">
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
                
                <hr>
                
                <div class="text-center">
                    <p>Don't have an account? <a href="{% url 'accounts:register' %}">Register here</a></p>
                    <p><a href="{% url 'accounts:password-reset' %}">Forgot your password?</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
```

### Registration View

```python
# accounts/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        
        if commit:
            user.save()
        
        return user

# accounts/views.py
from .forms import UserRegistrationForm

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        
        if form.is_valid():
            user = form.save()
            
            # Log the user in automatically
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            
            messages.success(request, f'Welcome to Bookstore, {user.first_name}!')
            return redirect('books:book-list')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'accounts/register.html', {'form': form})
```

### Logout View

```python
def user_logout(request):
    logout(request)
    messages.success(request, 'You have been successfully logged out.')
    return redirect('books:book-list')
```

## Authentication Decorators

### Login Required

Protect views that require authentication:

```python
from django.contrib.auth.decorators import login_required

@login_required
def add_book(request):
    # Only logged-in users can access this view
    if request.method == 'POST':
        # Handle form submission
        pass
    
    return render(request, 'books/add_book.html')

@login_required(login_url='/accounts/login/')
def profile(request):
    return render(request, 'accounts/profile.html')
```

### Permission Required

Check specific permissions:

```python
from django.contrib.auth.decorators import permission_required

@permission_required('books.add_book')
def add_book(request):
    # Only users with 'add_book' permission can access
    pass

@permission_required('books.delete_book', raise_exception=True)
def delete_book(request, book_id):
    # Raises PermissionDenied if user lacks permission
    pass
```

### User Test

Custom user tests:

```python
from django.contrib.auth.decorators import user_passes_test

def is_staff_member(user):
    return user.is_staff

@user_passes_test(is_staff_member)
def staff_only_view(request):
    # Only staff members can access
    pass
```

## Class-Based View Authentication

### Login Required Mixin

```python
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import CreateView, UpdateView

class BookCreateView(LoginRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'isbn', 'price']
    login_url = '/accounts/login/'
    
    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

class BookUpdateView(LoginRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'price', 'available']
    
    def get_queryset(self):
        # Only allow users to edit their own books
        return Book.objects.filter(created_by=self.request.user)
```

### Permission Required Mixin

```python
from django.contrib.auth.mixins import PermissionRequiredMixin

class BookDeleteView(PermissionRequiredMixin, DeleteView):
    model = Book
    permission_required = 'books.delete_book'
    success_url = reverse_lazy('books:book-list')
```

## Template Context

### User in Templates

Access user information in templates:

```html
<!-- In any template -->
{% if user.is_authenticated %}
    <p>Hello, {{ user.first_name|default:user.username }}!</p>
    <a href="{% url 'accounts:profile' %}">My Profile</a>
    <a href="{% url 'accounts:logout' %}">Logout</a>
{% else %}
    <a href="{% url 'accounts:login' %}">Login</a>
    <a href="{% url 'accounts:register' %}">Register</a>
{% endif %}

<!-- Check permissions -->
{% if perms.books.add_book %}
    <a href="{% url 'books:add-book' %}" class="btn btn-primary">Add Book</a>
{% endif %}

<!-- Check if user is staff -->
{% if user.is_staff %}
    <a href="/admin/" class="btn btn-secondary">Admin Panel</a>
{% endif %}
```

### Navigation Updates

Update your base template navigation:

```html
<!-- In books/templates/books/base.html -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="{% url 'books:book-list' %}">📚 Bookstore</a>
        
        <div class="navbar-nav me-auto">
            <a class="nav-link" href="{% url 'books:book-list' %}">Books</a>
            <a class="nav-link" href="{% url 'books:book-search' %}">Search</a>
            {% if user.is_authenticated and perms.books.add_book %}
                <a class="nav-link" href="{% url 'books:add-book' %}">Add Book</a>
            {% endif %}
        </div>
        
        <div class="navbar-nav ms-auto">
            {% if user.is_authenticated %}
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" 
                       data-bs-toggle="dropdown">
                        {{ user.first_name|default:user.username }}
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="{% url 'accounts:profile' %}">Profile</a></li>
                        {% if user.is_staff %}
                            <li><a class="dropdown-item" href="/admin/">Admin</a></li>
                        {% endif %}
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="{% url 'accounts:logout' %}">Logout</a></li>
                    </ul>
                </div>
            {% else %}
                <a class="nav-link" href="{% url 'accounts:login' %}">Login</a>
                <a class="nav-link" href="{% url 'accounts:register' %}">Register</a>
            {% endif %}
        </div>
    </div>
</nav>
```

## Password Management

### Password Change

```python
from django.contrib.auth.views import PasswordChangeView
from django.urls import reverse_lazy

class CustomPasswordChangeView(PasswordChangeView):
    template_name = 'accounts/password_change.html'
    success_url = reverse_lazy('accounts:password-change-done')
```

### Password Reset

Use Django's built-in password reset views:

```python
# accounts/urls.py
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('password-reset/', 
         auth_views.PasswordResetView.as_view(template_name='accounts/password_reset.html'),
         name='password-reset'),
    path('password-reset-done/', 
         auth_views.PasswordResetDoneView.as_view(template_name='accounts/password_reset_done.html'),
         name='password-reset-done'),
    path('password-reset-confirm/<uidb64>/<token>/', 
         auth_views.PasswordResetConfirmView.as_view(template_name='accounts/password_reset_confirm.html'),
         name='password-reset-confirm'),
]
```

## Security Best Practices

1. **Use HTTPS**: Always use SSL/TLS in production
2. **Strong Passwords**: Enforce password complexity
3. **Session Security**: Configure secure session cookies
4. **CSRF Protection**: Always use {% csrf_token %}
5. **Rate Limiting**: Prevent brute force attacks
6. **Input Validation**: Validate all user input
7. **Regular Updates**: Keep Django updated

## Settings Configuration

```python
# settings.py

# Authentication backends
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
]

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {
            'min_length': 8,
        }
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Login/logout redirects
LOGIN_URL = '/accounts/login/'
LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = '/'

# Session settings
SESSION_COOKIE_AGE = 86400  # 24 hours
SESSION_EXPIRE_AT_BROWSER_CLOSE = True
SESSION_COOKIE_SECURE = True  # HTTPS only
SESSION_COOKIE_HTTPONLY = True  # JavaScript can't access
```

## What's Next?

In the next lesson, we'll explore Django Admin - the powerful administrative interface for managing your application's data.

Authentication protects your app, admin helps you manage it! ⚙️
    ''',
    "is_free": True,
    "xp_reward": 45,
    "exercises": [
        {
            "id": "django-auth",
            "title": "Create Authentication System",
            "type": "project",
            "instructions": '''Create a complete authentication system for your bookstore.

Implement the following:

1. User registration with email verification
2. Login/logout functionality  
3. User profile pages with additional fields
4. Password change and reset
5. Protect book creation with login_required
6. Add user-specific features (e.g., favorite books)
7. Update navigation to show authentication state

Test the complete flow: register → login → add book → logout''',
            "starter_code": '''# accounts/models.py
from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    # Add additional fields
    pass

# accounts/forms.py  
from django.contrib.auth.forms import UserCreationForm

class UserRegistrationForm(UserCreationForm):
    # Extend with additional fields
    pass''',
            "solution": '''# accounts/models.py
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(max_length=500, blank=True)
    location = models.CharField(max_length=30, blank=True)
    birth_date = models.DateField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.user.username}'s Profile"

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

# accounts/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']

# accounts/views.py
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import UserRegistrationForm

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}!')
            return redirect('accounts:login')
    else:
        form = UserRegistrationForm()
    return render(request, 'accounts/register.html', {'form': form})''',
            "test_cases": [
                {
                    "name": "Complete authentication system implemented",
                    "input": "",
                    "expected_contains": ["UserRegistrationForm", "login_required", "authenticate", "UserProfile"]
                }
            ],
            "xp_reward": 80,
            "hints": [
                "Use Django's built-in authentication views where possible",
                "Create UserProfile with OneToOneField to User model",
                "Use @login_required decorator to protect views",
                "Handle form validation and user feedback properly",
                "Update base template navigation for authenticated users"
            ]
        }
    ]
}