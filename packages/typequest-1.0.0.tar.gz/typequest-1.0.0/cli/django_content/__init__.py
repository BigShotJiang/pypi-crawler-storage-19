"""
Django Content Module - Flexible lesson management system

This module provides a comprehensive system for managing Django lessons
with configurable ordering and flexible content management.
"""

# Original Django course imports (preserved for backward compatibility)
from .introduction import DJANGO_INTRODUCTION_LESSON
from .models import DJANGO_MODELS_LESSON
from .views import DJANGO_VIEWS_LESSON
from .templates import DJANGO_TEMPLATES_LESSON
from .forms import DJANGO_FORMS_LESSON
from .authentication import DJANGO_AUTH_LESSON
from .serialization import DJANGO_SERIALIZATION_LESSON
from .settings import DJANGO_SETTINGS_LESSON

# New lesson management system imports
from .lesson_manager import (
    DjangoLessonManager,
    django_lessons,
    get_django_lessons,
    get_beginner_django_lessons,
    get_django_lesson
)

from .lesson_registry import (
    get_ordered_lessons,
    get_available_orders,
    get_lesson_metadata,
    get_lessons_by_difficulty,
    get_lessons_by_prerequisites,
    LESSON_ORDER_CONFIGS
)

# Version info
__version__ = "1.0.0"
__author__ = "Claude Code Assistant"

# Original course content structure (preserved for backward compatibility)
DJANGO_COURSE_CONTENT = {
    "course": {
        "name": "Master Django Web Development",
        "slug": "master-django",
        "description": "Learn Django from basics to deployment. Build real web applications with Python's most popular web framework.",
        "difficulty": "intermediate",
        "estimated_hours": 80,
        "track": "backend"
    },
    
    "lessons": [
        DJANGO_INTRODUCTION_LESSON,
        DJANGO_MODELS_LESSON,
        DJANGO_VIEWS_LESSON,
        DJANGO_TEMPLATES_LESSON,
        DJANGO_FORMS_LESSON,
        DJANGO_AUTH_LESSON,
        DJANGO_SERIALIZATION_LESSON,
        DJANGO_SETTINGS_LESSON,
        # Future lessons:
        # DJANGO_ADMIN_LESSON,
        # DJANGO_API_LESSON,
        # DJANGO_DEPLOYMENT_LESSON,
    ]
}

# Export main interfaces
__all__ = [
    # Main manager classes
    'DjangoLessonManager',
    'django_lessons',
    
    # Convenience functions
    'get_django_lessons',
    'get_beginner_django_lessons', 
    'get_django_lesson',
    
    # Registry functions
    'get_ordered_lessons',
    'get_available_orders',
    'get_lesson_metadata',
    'get_lessons_by_difficulty',
    'get_lessons_by_prerequisites',
    
    # Configuration
    'LESSON_ORDER_CONFIGS',
    
    # Backward compatibility
    'DJANGO_COURSE_CONTENT',
    'DJANGO_INTRODUCTION_LESSON',
    'DJANGO_MODELS_LESSON',
    'DJANGO_VIEWS_LESSON',
    'DJANGO_TEMPLATES_LESSON',
    'DJANGO_FORMS_LESSON',
    'DJANGO_AUTH_LESSON',
    'DJANGO_SERIALIZATION_LESSON',
    'DJANGO_SETTINGS_LESSON'
]

# Quick start documentation
QUICK_START = """
Quick Start Guide for Class-Based Views:

1. Basic Usage:
   from django_content import django_lessons
   lessons = django_lessons.get_all_lessons()

2. Get Beginner Track:
   beginner_lessons = django_lessons.get_beginner_track()

3. Get Specific Lesson:
   intro_lesson = django_lessons.get_lesson('cbv_intro')

4. Custom Learning Path:
   path = django_lessons.get_learning_path_for_goal('crud_focus')

5. Create Custom Order:
   django_lessons.create_custom_track('my_order', ['cbv_intro', 'async_views'])

Available Lesson Keys:
- models_foundations: Django Models Foundations
- model_relationships: Django Model Relationships
- model_fields_advanced: Advanced Model Fields and Validation
- model_instance_methods: Django Model Instance Methods
- model_relations_advanced: Advanced Model Relations Management
- queryset_fundamentals: Django QuerySet Fundamentals
- queryset_advanced_operations: Advanced QuerySet Operations
- queryset_lookups_optimization: QuerySet Lookups and Optimization
- cbv_intro: Introduction to Class-Based Views
- generic_display: Generic Display Views (ListView, DetailView)
- generic_editing: Generic Editing Views (CreateView, UpdateView, DeleteView)
- mixins: Using Mixins with Class-Based Views
- urlconf_usage: URL Configuration with Class-Based Views
- subclassing_views: Subclassing Generic Views
- async_views: Asynchronous Class-Based Views

Available Orders:
- default: Complete progression from models to advanced views
- models_focus: Focus only on models and database operations
- views_focus: Focus only on class-based views
- beginner_friendly: Easier concepts first with gradual complexity
- practical_first: Hands-on examples early
- advanced_first: Complex topics first (for experienced developers)
"""