"""
SQL execution engine for CLI application
"""

import sqlite3
import tempfile
import os
from contextlib import contextmanager
from rich.console import Console
from rich.table import Table
from rich.text import Text
from rich.panel import Panel
from rich.syntax import Syntax
import re

console = Console()

class SQLExecutor:
    def __init__(self):
        self.datasets = self.load_datasets()
    
    def load_datasets(self):
        """Load sample datasets"""
        return {
            "company_db": {
                "name": "Company Database",
                "description": "Employee, department, and project data",
                "schema": """
CREATE TABLE departments (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    location TEXT,
    budget REAL
);

CREATE TABLE employees (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    department TEXT,
    salary REAL,
    hire_date TEXT,
    manager_id INTEGER,
    FOREIGN KEY (manager_id) REFERENCES employees(id)
);

CREATE TABLE projects (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    department_id INTEGER,
    start_date TEXT,
    end_date TEXT,
    budget REAL,
    status TEXT,
    FOREIGN KEY (department_id) REFERENCES departments(id)
);
                """,
                "data": """
INSERT INTO departments VALUES 
(1, 'Engineering', 'San Francisco', 2000000),
(2, 'Sales', 'New York', 1500000),
(3, 'Marketing', 'Los Angeles', 1200000),
(4, 'HR', 'Chicago', 800000),
(5, 'Finance', 'Boston', 1000000);

INSERT INTO employees VALUES
(1, 'Alice Johnson', 'alice@company.com', 'Engineering', 120000, '2020-01-15', NULL),
(2, 'Bob Smith', 'bob@company.com', 'Engineering', 95000, '2021-03-22', 1),
(3, 'Carol White', 'carol@company.com', 'Sales', 85000, '2019-07-10', NULL),
(4, 'David Brown', 'david@company.com', 'Sales', 72000, '2022-02-28', 3),
(5, 'Emma Davis', 'emma@company.com', 'Marketing', 90000, '2020-09-15', NULL),
(6, 'Frank Wilson', 'frank@company.com', 'Marketing', 68000, '2021-11-30', 5),
(7, 'Grace Lee', 'grace@company.com', 'Engineering', 110000, '2018-05-20', 1),
(8, 'Henry Taylor', 'henry@company.com', 'Finance', 98000, '2020-04-12', NULL),
(9, 'Ivy Martinez', 'ivy@company.com', 'HR', 75000, '2021-08-05', NULL),
(10, 'Jack Anderson', 'jack@company.com', 'Engineering', 105000, '2019-12-01', 1);

INSERT INTO projects VALUES
(1, 'Mobile App Development', 1, '2024-01-01', '2024-06-30', 500000, 'Active'),
(2, 'Sales CRM Upgrade', 2, '2024-02-15', '2024-08-15', 300000, 'Active'),
(3, 'Brand Redesign', 3, '2024-03-01', '2024-09-01', 250000, 'Planning'),
(4, 'Cloud Migration', 1, '2023-09-01', '2024-03-31', 800000, 'Completed');
                """
            },
            "ecommerce_db": {
                "name": "E-commerce Database", 
                "description": "Online store with products, customers, and orders",
                "schema": """
CREATE TABLE customers (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    city TEXT,
    registration_date TEXT
);

CREATE TABLE products (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    price REAL,
    category TEXT,
    stock_quantity INTEGER
);

CREATE TABLE orders (
    order_id INTEGER PRIMARY KEY,
    customer_id INTEGER,
    order_date TEXT,
    total REAL,
    status TEXT,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE order_items (
    order_id INTEGER,
    product_id INTEGER,
    quantity INTEGER,
    unit_price REAL,
    PRIMARY KEY (order_id, product_id),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);
                """,
                "data": """
INSERT INTO customers VALUES
(1, 'John Doe', 'john.doe@email.com', 'New York', '2023-01-10'),
(2, 'Jane Smith', 'jane.smith@email.com', 'Los Angeles', '2023-01-15'),
(3, 'Michael Johnson', 'michael.j@email.com', 'Chicago', '2023-01-20'),
(4, 'Emily Brown', 'emily.b@email.com', 'Houston', '2023-02-01'),
(5, 'William Davis', 'william.d@email.com', 'Phoenix', '2023-02-10');

INSERT INTO products VALUES
(101, 'Laptop Pro 15', 1299.99, 'Electronics', 25),
(102, 'Wireless Mouse', 29.99, 'Electronics', 150),
(103, 'USB-C Hub', 49.99, 'Electronics', 80),
(104, 'Mechanical Keyboard', 89.99, 'Electronics', 45),
(105, 'Monitor 27"', 399.99, 'Electronics', 30),
(201, 'Cotton T-Shirt', 19.99, 'Clothing', 200),
(202, 'Jeans Classic', 59.99, 'Clothing', 120),
(301, 'Python Programming', 39.99, 'Books', 100),
(302, 'Data Science Handbook', 49.99, 'Books', 75);

INSERT INTO orders VALUES
(1001, 1, '2024-01-05', 1329.98, 'Delivered'),
(1002, 2, '2024-01-10', 89.97, 'Delivered'),
(1003, 3, '2024-01-15', 449.98, 'Delivered'),
(1004, 1, '2024-01-20', 79.99, 'Delivered'),
(1005, 4, '2024-01-25', 259.97, 'Processing');

INSERT INTO order_items VALUES
(1001, 101, 1, 1299.99),
(1001, 102, 1, 29.99),
(1002, 201, 3, 19.99),
(1002, 102, 1, 29.99),
(1003, 105, 1, 399.99),
(1003, 103, 1, 49.99);
                """
            }
        }
    
    @contextmanager
    def create_temp_database(self, dataset_name):
        """Create temporary database with sample data"""
        if dataset_name not in self.datasets:
            raise ValueError(f"Dataset {dataset_name} not found")
        
        dataset = self.datasets[dataset_name]
        
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as temp_db:
            db_path = temp_db.name
        
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Execute schema
            cursor.executescript(dataset["schema"])
            
            # Insert sample data  
            cursor.executescript(dataset["data"])
            
            conn.commit()
            conn.close()
            
            yield db_path
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def validate_query(self, query):
        """Validate SQL query for safety"""
        query = query.strip().upper()
        
        # Dangerous keywords
        dangerous = ['DROP', 'DELETE', 'TRUNCATE', 'ALTER', 'CREATE', 'INSERT', 'UPDATE']
        
        # For exercises, allow only SELECT
        if not query.startswith('SELECT'):
            return False, "Only SELECT queries are allowed in exercises"
        
        # Check for dangerous keywords
        for keyword in dangerous:
            if re.search(r'\b' + keyword + r'\b', query):
                return False, f"Keyword '{keyword}' not allowed"
        
        return True, "Valid query"
    
    def execute_query(self, query, dataset_name="company_db", validate=True):
        """Execute SQL query and return results"""
        
        if validate:
            is_valid, message = self.validate_query(query)
            if not is_valid:
                return {
                    'success': False,
                    'error': message,
                    'data': None
                }
        
        try:
            with self.create_temp_database(dataset_name) as db_path:
                conn = sqlite3.connect(db_path)
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                cursor.execute(query)
                rows = cursor.fetchall()
                
                if rows:
                    columns = list(rows[0].keys())
                    data = [dict(row) for row in rows]
                else:
                    columns = []
                    data = []
                
                conn.close()
                
                return {
                    'success': True,
                    'data': data,
                    'columns': columns,
                    'row_count': len(data)
                }
                
        except sqlite3.Error as e:
            return {
                'success': False,
                'error': str(e),
                'data': None
            }
        except Exception as e:
            return {
                'success': False,
                'error': f"Unexpected error: {str(e)}",
                'data': None
            }
    
    def display_query_result(self, result):
        """Display query results in a formatted table"""
        if not result['success']:
            console.print(f"\n❌ [bold red]Error:[/bold red] {result['error']}")
            return
        
        if not result['data']:
            console.print("\n📭 [dim]No results found[/dim]")
            return
        
        # Create table
        table = Table(show_header=True, header_style="bold cyan")
        
        # Add columns
        for column in result['columns']:
            table.add_column(column.replace('_', ' ').title())
        
        # Add rows
        for row in result['data'][:50]:  # Limit to 50 rows for display
            table.add_row(*[str(value) for value in row.values()])
        
        console.print()
        console.print(table)
        
        if result['row_count'] > 50:
            console.print(f"\n[dim]... showing first 50 of {result['row_count']} rows[/dim]")
        else:
            console.print(f"\n📊 [green]{result['row_count']} rows returned[/green]")
    
    def compare_results(self, user_result, expected_result):
        """Compare user query result with expected result"""
        if not user_result['success']:
            return {
                'correct': False,
                'message': "Your query has errors",
                'score': 0
            }
        
        if not expected_result['success']:
            return {
                'correct': False,
                'message': "Unable to compare results",
                'score': 0
            }
        
        user_data = user_result['data']
        expected_data = expected_result['data']
        
        # Sort data for comparison (order might vary)
        def sort_data(data):
            if not data:
                return []
            return sorted(data, key=lambda x: str(sorted(x.items())))
        
        user_sorted = sort_data(user_data)
        expected_sorted = sort_data(expected_data)
        
        if user_sorted == expected_sorted:
            return {
                'correct': True,
                'message': "Perfect! Your query returned exactly the right results! 🎉",
                'score': 100
            }
        
        # Check columns
        user_columns = set(user_result.get('columns', []))
        expected_columns = set(expected_result.get('columns', []))
        
        if user_columns != expected_columns:
            missing = expected_columns - user_columns
            extra = user_columns - expected_columns
            
            message = "Column mismatch. "
            if missing:
                message += f"Missing: {', '.join(missing)}. "
            if extra:
                message += f"Extra: {', '.join(extra)}. "
            
            return {
                'correct': False,
                'message': message,
                'score': 25
            }
        
        # Check row count
        if len(user_data) != len(expected_data):
            return {
                'correct': False,
                'message': f"Wrong number of rows. Expected {len(expected_data)}, got {len(user_data)}",
                'score': 50
            }
        
        return {
            'correct': False,
            'message': "Results don't match exactly. Check your logic!",
            'score': 70
        }
    
    def show_dataset_info(self, dataset_name):
        """Show information about a dataset"""
        if dataset_name not in self.datasets:
            console.print(f"❌ Dataset '{dataset_name}' not found")
            return
        
        dataset = self.datasets[dataset_name]
        
        console.print(f"\n📊 [bold cyan]{dataset['name']}[/bold cyan]")
        console.print(f"📝 {dataset['description']}")
        
        # Show table structure
        with self.create_temp_database(dataset_name) as db_path:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Get table names
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = [row[0] for row in cursor.fetchall()]
            
            for table_name in tables:
                console.print(f"\n🗂️  [bold]{table_name.upper()}[/bold]")
                
                # Get column info
                cursor.execute(f"PRAGMA table_info({table_name});")
                columns = cursor.fetchall()
                
                col_table = Table(show_header=False)
                col_table.add_column("Column", style="cyan")
                col_table.add_column("Type", style="white")
                col_table.add_column("Notes", style="dim")
                
                for col in columns:
                    col_name, col_type, not_null, default, pk = col[1], col[2], col[3], col[4], col[5]
                    notes = []
                    if pk:
                        notes.append("PRIMARY KEY")
                    if not_null:
                        notes.append("NOT NULL")
                    
                    col_table.add_row(
                        col_name,
                        col_type,
                        ", ".join(notes)
                    )
                
                console.print(col_table)
                
                # Show sample data
                cursor.execute(f"SELECT * FROM {table_name} LIMIT 3;")
                sample_rows = cursor.fetchall()
                
                if sample_rows:
                    console.print(f"\n📋 [dim]Sample data (first 3 rows):[/dim]")
                    sample_table = Table()
                    
                    # Add columns
                    for col in columns:
                        sample_table.add_column(col[1], style="white")
                    
                    # Add sample rows
                    for row in sample_rows:
                        sample_table.add_row(*[str(val) if val is not None else "NULL" for val in row])
                    
                    console.print(sample_table)
            
            conn.close()
    
    def get_available_datasets(self):
        """Get list of available datasets"""
        return [
            {
                'name': key,
                'display_name': data['name'],
                'description': data['description']
            }
            for key, data in self.datasets.items()
        ]