"""
Python code execution engine for decorator exercises
"""

import sys
import tempfile
import os
import subprocess
import re
from contextlib import contextmanager, redirect_stdout, redirect_stderr
from io import StringIO
import time
from rich.console import Console
from rich.syntax import Syntax
from rich.panel import Panel

console = Console()

class PythonExecutor:
    def __init__(self):
        self.timeout = 10  # seconds
    
    def execute_code(self, code, test_input=""):
        """Execute Python code and return results"""
        try:
            # Create temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(code)
                temp_file = f.name
            
            try:
                # Execute code with timeout
                result = subprocess.run(
                    [sys.executable, temp_file],
                    input=test_input,
                    capture_output=True,
                    text=True,
                    timeout=self.timeout
                )
                
                return {
                    'success': result.returncode == 0,
                    'output': result.stdout.strip(),
                    'error': result.stderr.strip() if result.returncode != 0 else '',
                    'return_code': result.returncode
                }
                
            finally:
                # Clean up temp file
                if os.path.exists(temp_file):
                    os.unlink(temp_file)
                    
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'error': f'Code execution timed out after {self.timeout} seconds',
                'output': ''
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'Execution error: {str(e)}',
                'output': ''
            }
    
    def validate_decorator_exercise(self, user_code, exercise):
        """Validate decorator exercise solutions"""
        test_cases = exercise.get('test_cases', [])
        
        if not test_cases:
            # Fallback to basic execution
            result = self.execute_code(user_code)
            return {
                'success': result['success'],
                'message': "Code executed successfully!" if result['success'] else result['error'],
                'score': 100 if result['success'] else 0,
                'test_results': []
            }
        
        passed_tests = 0
        test_results = []
        
        for test_case in test_cases:
            test_result = self.run_test_case(user_code, test_case)
            test_results.append(test_result)
            if test_result['passed']:
                passed_tests += 1
        
        success = passed_tests == len(test_cases)
        score = int((passed_tests / len(test_cases)) * 100) if test_cases else 0
        
        if success:
            message = "🎉 Perfect! All tests passed!"
        elif passed_tests > 0:
            message = f"✅ {passed_tests}/{len(test_cases)} tests passed. Keep trying!"
        else:
            message = "❌ No tests passed. Check your implementation."
        
        return {
            'success': success,
            'message': message,
            'score': score,
            'test_results': test_results
        }
    
    def run_test_case(self, user_code, test_case):
        """Run a specific test case"""
        test_input = test_case.get('input', '')
        
        # Execute user code
        result = self.execute_code(user_code, test_input)
        
        if not result['success']:
            return {
                'name': test_case.get('name', 'Test'),
                'passed': False,
                'expected': test_case.get('expected_output', ''),
                'actual': result['error'],
                'error': True
            }
        
        actual_output = result['output']
        
        # Check different types of expected output
        if 'expected_output' in test_case:
            expected = test_case['expected_output'].strip()
            passed = actual_output == expected
        elif 'expected_pattern' in test_case:
            pattern = test_case['expected_pattern']
            passed = bool(re.search(pattern, actual_output))
            expected = f"Pattern: {pattern}"
        elif 'expected_contains' in test_case:
            contains_list = test_case['expected_contains']
            passed = all(item in actual_output for item in contains_list)
            expected = f"Should contain: {', '.join(contains_list)}"
        else:
            passed = True
            expected = "Any output"
        
        return {
            'name': test_case.get('name', 'Test'),
            'passed': passed,
            'expected': expected,
            'actual': actual_output,
            'error': False
        }
    
    def display_code_result(self, result):
        """Display Python code execution results"""
        if not result['success']:
            console.print(f"\n❌ [bold red]Error:[/bold red] {result['error']}")
            return
        
        if result['output']:
            console.print("\n📄 [bold]Output:[/bold]")
            # Display output with syntax highlighting if it looks like Python
            if any(keyword in result['output'] for keyword in ['def ', 'class ', 'import ', 'print(']):
                syntax = Syntax(result['output'], "python", theme="monokai", line_numbers=False)
                console.print(syntax)
            else:
                console.print(result['output'])
        else:
            console.print("\n📭 [dim]No output generated[/dim]")
    
    def display_test_results(self, validation_result):
        """Display detailed test results"""
        console.print(f"\n🧪 [bold]Test Results:[/bold]")
        
        for test_result in validation_result['test_results']:
            status = "✅" if test_result['passed'] else "❌"
            console.print(f"\n{status} [bold]{test_result['name']}[/bold]")
            
            if not test_result['passed']:
                if test_result['error']:
                    console.print(f"   [red]Error:[/red] {test_result['actual']}")
                else:
                    console.print(f"   [dim]Expected:[/dim] {test_result['expected']}")
                    console.print(f"   [dim]Actual:[/dim]   {test_result['actual']}")
        
        # Overall score
        score = validation_result['score']
        if score == 100:
            console.print(f"\n🎯 [bold green]Perfect Score: {score}%[/bold green]")
        elif score >= 70:
            console.print(f"\n👍 [bold yellow]Good Job: {score}%[/bold yellow]")
        else:
            console.print(f"\n🔄 [bold red]Keep Trying: {score}%[/bold red]")
    
    def show_decorator_help(self):
        """Show decorator help and examples"""
        help_text = """
[bold cyan]Python Decorators Quick Reference:[/bold cyan]

[bold]Basic Decorator Structure:[/bold]
```python
def my_decorator(func):
    def wrapper(*args, **kwargs):
        # Do something before
        result = func(*args, **kwargs)
        # Do something after
        return result
    return wrapper
```

[bold]Using functools.wraps:[/bold]
```python
import functools

def my_decorator(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper
```

[bold]Decorator with Parameters:[/bold]
```python
def repeat(times):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for _ in range(times):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator
```

[bold]Property Decorators:[/bold]
```python
class MyClass:
    @property
    def value(self):
        return self._value
    
    @value.setter
    def value(self, val):
        self._value = val
```
        """
        console.print(Panel(help_text, title="🐍 Python Decorators Help", border_style="yellow"))
    
    def validate_decorator_syntax(self, code):
        """Basic validation for decorator syntax"""
        errors = []
        
        # Check for basic decorator patterns
        if '@' not in code:
            errors.append("No decorator (@) symbol found")
        
        if 'def ' not in code:
            errors.append("No function definition found")
        
        # Check for functools.wraps usage in more complex decorators
        if 'functools.wraps' not in code and code.count('def ') > 2:
            errors.append("Consider using @functools.wraps to preserve function metadata")
        
        # Check for proper return statements
        func_defs = code.count('def ')
        return_statements = code.count('return ')
        
        if func_defs > 1 and return_statements < func_defs - 1:
            errors.append("Make sure your decorator functions return the wrapper")
        
        return errors
    
    def provide_decorator_hints(self, exercise_id, error_message=""):
        """Provide specific hints for decorator exercises"""
        hints = {
            'basic-decorator': [
                "Remember the basic structure: decorator takes a function, returns a wrapper",
                "Your wrapper function should call the original function",
                "Don't forget to return the result of the original function",
                "Use *args, **kwargs to handle any function signature"
            ],
            'timer-decorator': [
                "Use time.time() to get timestamps before and after function execution",
                "Calculate duration by subtracting start_time from end_time",
                "Format the output with :.4f for 4 decimal places",
                "Remember to return the original function's result"
            ],
            'cache-decorator': [
                "Create a dictionary outside the wrapper to store cached results",
                "Use function arguments as the cache key",
                "Check if the key exists before computing the result",
                "Store the result in cache before returning it"
            ],
            'parametrized-decorator': [
                "This needs three levels: decorator factory -> decorator -> wrapper",
                "The outer function takes the parameter (times)",
                "The middle function takes the original function",
                "The inner wrapper executes the function multiple times"
            ],
            'property-decorator': [
                "Use @property for getter methods",
                "Use @property_name.setter for setter methods",
                "Store data in private attributes (prefixed with _)",
                "Validate input in setter methods"
            ]
        }
        
        return hints.get(exercise_id, ["Check the exercise instructions for guidance"])
    
    def run_decorator_playground(self):
        """Interactive Python decorator playground"""
        console.print("\n🐍 [bold cyan]Python Decorator Playground[/bold cyan]")
        console.print("Practice Python decorators interactively!\n")
        
        console.print("💡 [bold]Available commands:[/bold]")
        console.print("• Write Python code with decorators")
        console.print("• Type 'help' for decorator quick reference")
        console.print("• Type 'examples' to see common decorator patterns")
        console.print("• Type 'exit' to return to main menu\n")
        
        while True:
            try:
                from rich.prompt import Prompt
                
                code = Prompt.ask("\n[bold cyan]Python>[/bold cyan] Enter your decorator code (or 'multiline' for multiple lines)")
                
                if code.lower() == 'exit':
                    break
                elif code.lower() == 'help':
                    self.show_decorator_help()
                    continue
                elif code.lower() == 'examples':
                    self.show_decorator_examples()
                    continue
                elif code.lower() == 'multiline':
                    code = self.get_multiline_input()
                elif not code.strip():
                    continue
                
                # Execute the code
                result = self.execute_code(code)
                self.display_code_result(result)
                
                # Check for common issues
                if result['success']:
                    syntax_errors = self.validate_decorator_syntax(code)
                    if syntax_errors:
                        console.print("\n💡 [yellow]Suggestions:[/yellow]")
                        for error in syntax_errors:
                            console.print(f"   • {error}")
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                console.print(f"❌ Error: {e}")
    
    def get_multiline_input(self):
        """Get multiline code input"""
        console.print("📝 [dim]Enter your code (type 'END' on a new line to finish):[/dim]")
        lines = []
        
        while True:
            from rich.prompt import Prompt
            line = Prompt.ask("", default="")
            if line.strip() == 'END':
                break
            lines.append(line)
        
        return '\n'.join(lines)
    
    def show_decorator_examples(self):
        """Show common decorator examples"""
        examples = [
            {
                "title": "Logging Decorator",
                "code": """
import functools

def log_calls(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        print(f"Calling {func.__name__} with args: {args}, kwargs: {kwargs}")
        result = func(*args, **kwargs)
        print(f"{func.__name__} returned: {result}")
        return result
    return wrapper

@log_calls
def add(a, b):
    return a + b

result = add(5, 3)
                """
            },
            {
                "title": "Retry Decorator",
                "code": """
import functools
import random

def retry(max_attempts=3):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_attempts - 1:
                        raise e
                    print(f"Attempt {attempt + 1} failed: {e}. Retrying...")
            return None
        return wrapper
    return decorator

@retry(3)
def unreliable_function():
    if random.random() < 0.7:  # 70% chance of failure
        raise ValueError("Random failure!")
    return "Success!"

try:
    result = unreliable_function()
    print(f"Final result: {result}")
except Exception as e:
    print(f"All attempts failed: {e}")
                """
            }
        ]
        
        console.print("\n📚 [bold]Decorator Examples:[/bold]\n")
        
        for i, example in enumerate(examples, 1):
            console.print(f"[bold cyan]{i}. {example['title']}[/bold cyan]")
            syntax = Syntax(example['code'].strip(), "python", theme="monokai", line_numbers=True)
            console.print(syntax)
            console.print()