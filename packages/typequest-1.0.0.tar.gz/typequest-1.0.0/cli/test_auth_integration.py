#!/usr/bin/env python3
"""
Test script for TypeQuest CLI authentication integration
This script tests the device authorization flow with the TypeQuest service
"""

import sys
import os
from pathlib import Path

# Add the CLI module to path
cli_path = Path(__file__).parent / "boots"
sys.path.insert(0, str(cli_path))

from boots.config import Config
from boots.auth import TypeQuestAuth
from boots.api_client import TypeQuestAPIClient
from rich.console import Console
from rich.panel import Panel

console = Console()

def test_service_connectivity():
    """Test basic service connectivity"""
    console.print("🔍 [bold cyan]Testing Service Connectivity[/bold cyan]\n")
    
    config = Config()
    auth = TypeQuestAuth(config)
    api_client = TypeQuestAPIClient(auth)
    
    # Test health check
    if api_client.check_service_health():
        console.print("✅ [green]Service is healthy and accessible[/green]")
        return True
    else:
        console.print("❌ [red]Service is not accessible[/red]")
        console.print("Make sure your TypeQuest service is running and TYPEQUEST_API_URL is set correctly")
        return False

def test_device_auth_flow():
    """Test the device authorization flow"""
    console.print("\n🔐 [bold cyan]Testing Device Authorization Flow[/bold cyan]\n")
    
    config = Config()
    auth = TypeQuestAuth(config)
    
    console.print("📱 This will test the device authorization flow.")
    console.print("You'll need to visit the activation URL and enter the user code.")
    console.print("Press Enter to start the test...")
    input()
    
    # Test login flow
    success = auth.login_flow()
    
    if success:
        console.print("✅ [green]Device authorization flow completed successfully![/green]")
        
        # Test getting user info
        user = auth.get_current_user()
        if user:
            console.print(f"👤 Logged in as: {user.get('display_name') or user.get('email', 'Unknown User')}")
        
        # Test token validation
        token_info = auth.validate_token()
        if token_info.get('valid'):
            console.print("✅ [green]Token validation successful[/green]")
        else:
            console.print("❌ [red]Token validation failed[/red]")
        
        return True
    else:
        console.print("❌ [red]Device authorization flow failed[/red]")
        return False

def test_authenticated_api_calls():
    """Test authenticated API calls"""
    console.print("\n📡 [bold cyan]Testing Authenticated API Calls[/bold cyan]\n")
    
    config = Config()
    auth = TypeQuestAuth(config)
    api_client = TypeQuestAPIClient(auth)
    
    if not auth.is_logged_in():
        console.print("❌ [red]User not logged in. Cannot test authenticated calls.[/red]")
        return False
    
    # Test user profile
    try:
        user_profile = api_client.get_user_profile()
        if user_profile:
            console.print("✅ [green]User profile API call successful[/green]")
            console.print(f"   Email: {user_profile.get('email', 'N/A')}")
        else:
            console.print("❌ [red]User profile API call failed[/red]")
    except Exception as e:
        console.print(f"❌ [red]User profile API error: {e}[/red]")
    
    # Test preferences
    try:
        preferences = api_client.get_user_preferences()
        console.print("✅ [green]User preferences API call successful[/green]")
        console.print(f"   Preferences: {preferences}")
    except Exception as e:
        console.print(f"❌ [red]User preferences API error: {e}[/red]")
    
    # Test session info
    try:
        session_info = api_client.get_session_info()
        if session_info:
            console.print("✅ [green]Session info API call successful[/green]")
        else:
            console.print("❌ [yellow]Session info API call returned no data[/yellow]")
    except Exception as e:
        console.print(f"❌ [red]Session info API error: {e}[/red]")
    
    return True

def test_token_refresh():
    """Test token refresh functionality"""
    console.print("\n🔄 [bold cyan]Testing Token Refresh[/bold cyan]\n")
    
    config = Config()
    auth = TypeQuestAuth(config)
    
    if not auth.is_logged_in():
        console.print("❌ [red]User not logged in. Cannot test token refresh.[/red]")
        return False
    
    # Try to refresh token
    if auth.refresh_token():
        console.print("✅ [green]Token refresh successful[/green]")
        return True
    else:
        console.print("❌ [yellow]Token refresh failed (may not be needed)[/yellow]")
        return True  # This is okay if token hasn't expired

def display_environment_info():
    """Display current environment information"""
    console.print("\n🌍 [bold cyan]Environment Information[/bold cyan]\n")
    
    # API URL
    api_url = os.getenv("TYPEQUEST_API_URL", "http://localhost:8000")
    console.print(f"API URL: {api_url}")
    
    # Client ID
    client_id = os.getenv("TYPEQUEST_CLIENT_ID", "your-auth0-client-id")
    console.print(f"Client ID: {client_id}")
    
    # Check if environment vars are set
    if api_url == "http://localhost:8000":
        console.print("ℹ️  [yellow]Using default API URL. Set TYPEQUEST_API_URL if needed.[/yellow]")
    
    if client_id == "your-auth0-client-id":
        console.print("⚠️  [yellow]Default client ID detected. Set TYPEQUEST_CLIENT_ID for production.[/yellow]")

def main():
    """Run all authentication tests"""
    console.clear()
    
    banner = """
╔══════════════════════════════════════════════╗
║        TypeQuest CLI Authentication Test     ║
║              Device Authorization Flow       ║
╚══════════════════════════════════════════════╝
"""
    
    console.print(Panel(banner, border_style="cyan"))
    
    display_environment_info()
    
    # Test service connectivity first
    if not test_service_connectivity():
        console.print("\n❌ [red]Service connectivity test failed. Exiting.[/red]")
        return False
    
    # Test device auth flow
    if not test_device_auth_flow():
        console.print("\n❌ [red]Device auth flow test failed. Skipping API tests.[/red]")
        return False
    
    # Test authenticated API calls
    test_authenticated_api_calls()
    
    # Test token refresh
    test_token_refresh()
    
    console.print("\n" + "="*50)
    console.print("🎉 [bold green]All tests completed![/bold green]")
    console.print("\nYour TypeQuest CLI is now integrated with the authentication service!")
    console.print("Users can run 'typequest' and login with the device authorization flow.")
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        console.print("\n\n👋 Test interrupted by user")
        sys.exit(0)
    except Exception as e:
        console.print(f"\n❌ [red]Test failed with error: {e}[/red]")
        import traceback
        console.print(f"[dim]{traceback.format_exc()}[/dim]")
        sys.exit(1)