#!/usr/bin/env python3
"""
TypeQuest - Entry Point
Interactive coding education platform
"""

if __name__ == "__main__":
    # Import and run the main application
    from main import BootsCLI
    app = BootsCLI()
    app.run()