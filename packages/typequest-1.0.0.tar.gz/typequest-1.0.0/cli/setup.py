"""
Fallback setup.py for older pip versions
"""

from setuptools import setup, find_packages
import os

# Read version from __init__.py
def get_version():
    init_path = os.path.join(os.path.dirname(__file__), "boots", "__init__.py")
    with open(init_path, "r") as f:
        for line in f:
            if line.startswith("__version__"):
                return line.split("=")[1].strip().strip('"').strip("'")
    return "1.0.0"

# Read README for long description
def get_long_description():
    readme_path = os.path.join(os.path.dirname(__file__), "README.md")
    if os.path.exists(readme_path):
        with open(readme_path, "r", encoding="utf-8") as f:
            return f.read()
    return "Interactive coding education platform"

setup(
    name="typequest",
    version=get_version(),
    description="Interactive CLI for learning backend development with SQL, Python, and Django",
    long_description=get_long_description(),
    long_description_content_type="text/markdown",
    author="TypeQuest Team",
    author_email="hello@typequest.dev",
    url="https://typequest.dev",
    project_urls={
        "Documentation": "https://docs.typequest.dev",
        "Repository": "https://github.com/typequest-dev/typequest",
        "Issues": "https://github.com/typequest-dev/typequest/issues",
        "Changelog": "https://github.com/typequest-dev/typequest/releases",
    },
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "typequest": ["*.json", "*.sql", "*.txt"],
    },
    install_requires=[
        "rich>=13.0.0",
        "typer>=0.9.0", 
        "inquirer>=3.1.0",
        "requests>=2.28.0",
        "pyfiglet>=0.8.0",
        "click>=8.0.0",
        "pydantic>=1.10.0",
        "packaging>=21.0",
        "pyjwt>=2.4.0",
        "stripe>=5.0.0",
        "python-dotenv>=1.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=22.0.0", 
            "flake8>=5.0.0",
            "mypy>=0.991",
            "pytest-cov>=4.0.0",
        ]
    },
    
    # CRITICAL: Console scripts entry point
    entry_points={
        "console_scripts": [
            "typequest=typequest.cli:main",
            "tq=typequest.cli:main",
            "typequest-setup=setup_db:main",
        ],
    },
    
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Education",
        "Topic :: Software Development",
        "Topic :: Database",
        "Environment :: Console",
        "Operating System :: OS Independent",
    ],
    keywords="education coding sql python django cli interactive learning",
    zip_safe=False,
)