#!/usr/bin/env python3
"""
Demo script to test the typewriter effect
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from typewriter_display import type_text, type_lesson, type_markdown, show_typewriter_settings, set_typewriter_speed
from rich.console import Console
from rich.prompt import Prompt

console = Console()

def demo_typewriter():
    """Demonstrate the typewriter effect"""
    
    console.print("[bold cyan]🎬 Typewriter Effect Demo[/bold cyan]\n")
    
    # Show current settings
    show_typewriter_settings()
    
    # Demo different speeds
    console.print("\n[bold]Testing Different Speeds:[/bold]")
    
    # Normal speed
    console.print("\n📝 Normal Speed:")
    type_text("Welcome to the TypeQuest! This is how text appears with the typewriter effect at normal speed.", style="white")
    
    Prompt.ask("\nPress Enter to try fast speed")
    
    # Fast speed
    set_typewriter_speed('fast')
    console.print("\n🏃 Fast Speed:")
    type_text("This is the same text, but now it appears much faster! Great for users who want to move through content quickly.", style="green")
    
    Prompt.ask("\nPress Enter to try slow speed")
    
    # Slow speed  
    set_typewriter_speed('slow')
    console.print("\n🐌 Slow Speed:")
    type_text("And this is slow speed - perfect for readers who want to savor every word and follow along carefully.", style="yellow")
    
    Prompt.ask("\nPress Enter to try instant mode")
    
    # Instant mode
    set_typewriter_speed('instant')
    console.print("\n🚀 Instant Mode:")
    type_text("Instant mode shows all text immediately - just like traditional CLI output. No delay at all!", style="red")
    
    # Reset to normal
    set_typewriter_speed('normal')
    
    Prompt.ask("\nPress Enter to see markdown/lesson content demo")
    
    # Demo lesson content
    sample_lesson = """
# Introduction to SQL Typewriter Demo

Welcome to this **exciting demonstration** of the typewriter effect! This simulates how SQL lessons will appear to students.

## Key Features

The typewriter effect provides several benefits:

- **Enhanced Readability**: Text appears at a comfortable pace
- **Better Focus**: Students can follow along more easily  
- **Customizable Speed**: Four different speed settings
- **Skip Functionality**: Press SPACE to skip ahead

## Code Example

Here's how SQL code will appear:

```sql
SELECT * FROM students 
WHERE engagement_level = 'high';
```

## Real-World Application

This typewriter effect makes learning more engaging and helps students:

1. **Focus on content** rather than rushing through
2. **Absorb information** at an appropriate pace
3. **Feel immersed** in the learning experience

**Ready to revolutionize CLI education? Let's go! 🚀**
    """
    
    console.print("\n[bold]📖 Lesson Content Demo:[/bold]")
    console.print("[dim]💡 This simulates how a real SQL lesson will appear[/dim]\n")
    
    type_lesson(sample_lesson)
    
    console.print("\n[bold green]🎉 Demo Complete![/bold green]")
    console.print("The typewriter effect is now integrated into the TypeQuest!")
    console.print("Users can customize their experience through the Settings menu.")

if __name__ == "__main__":
    demo_typewriter()