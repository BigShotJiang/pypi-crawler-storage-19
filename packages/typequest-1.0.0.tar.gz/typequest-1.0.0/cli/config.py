"""
Configuration and database setup for CLI application
"""

import sqlite3
import json
import os
from pathlib import Path
from datetime import datetime
from .database import db

class Config:
    def __init__(self):
        self.app_dir = Path.home() / ".typequest"  # Updated app name
        self.config_path = self.app_dir / "config.json"
        
        # Create app directory if it doesn't exist
        self.app_dir.mkdir(exist_ok=True)
        
        # Initialize database and config
        self.init_database()
        self.init_config()
    
    def init_database(self):
        """Initialize database using the new database abstraction layer"""
        db.execute_schema_migration()
    
    def init_config(self):
        """Initialize configuration file"""
        default_config = {
            "app_version": "1.0.0",
            "theme": "dark",
            "auto_save": True,
            "sound_enabled": False,
            "notifications": True,
            "default_dataset": "company_db"
        }
        
        if not self.config_path.exists():
            with open(self.config_path, 'w') as f:
                json.dump(default_config, f, indent=2)
    
    def get_config(self):
        """Get configuration settings"""
        with open(self.config_path, 'r') as f:
            return json.load(f)
    
    def update_config(self, key, value):
        """Update a configuration setting"""
        config = self.get_config()
        config[key] = value
        
        with open(self.config_path, 'w') as f:
            json.dump(config, f, indent=2)
    
    def get_db_connection(self):
        """Get database connection using the new abstraction layer"""
        return db.get_connection()