"""
Database abstraction layer supporting both SQLite (local) and PostgreSQL (production)
"""
import os
import sqlite3
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any
import logging

try:
    import psycopg2
    from psycopg2.extras import RealDictCursor
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False

class DatabaseConfig:
    """Database configuration management"""
    
    def __init__(self):
        self.app_dir = Path.home() / ".typequest"
        self.app_dir.mkdir(exist_ok=True)
        
    def get_database_url(self) -> Optional[str]:
        """Get database URL from environment or config"""
        # Priority: ENV var > config file > default SQLite
        db_url = os.getenv('TYPEQUEST_DATABASE_URL')
        
        if not db_url:
            config_file = self.app_dir / "database.json"
            if config_file.exists():
                with open(config_file, 'r') as f:
                    config = json.load(f)
                    db_url = config.get('database_url')
        
        return db_url
    
    def set_database_url(self, url: str):
        """Save database URL to config file"""
        config_file = self.app_dir / "database.json"
        config = {}
        
        if config_file.exists():
            with open(config_file, 'r') as f:
                config = json.load(f)
        
        config['database_url'] = url
        config['updated_at'] = datetime.now().isoformat()
        
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=2)

class DatabaseConnection:
    """Abstract database connection supporting SQLite and PostgreSQL"""
    
    def __init__(self):
        self.config = DatabaseConfig()
        self.db_url = self.config.get_database_url()
        self.connection_type = self._detect_connection_type()
        self.logger = logging.getLogger(__name__)
    
    def _detect_connection_type(self) -> str:
        """Detect whether to use PostgreSQL or SQLite"""
        if self.db_url:
            if self.db_url.startswith('postgresql://') or self.db_url.startswith('postgres://'):
                if POSTGRES_AVAILABLE:
                    return 'postgresql'
                else:
                    self.logger.warning("PostgreSQL URL provided but psycopg2 not available. Falling back to SQLite.")
            elif self.db_url.startswith('sqlite://'):
                return 'sqlite'
        
        # Default to SQLite
        return 'sqlite'
    
    def get_connection(self):
        """Get appropriate database connection"""
        if self.connection_type == 'postgresql':
            return self._get_postgres_connection()
        else:
            return self._get_sqlite_connection()
    
    def _get_postgres_connection(self):
        """Get PostgreSQL connection"""
        try:
            return psycopg2.connect(
                self.db_url,
                cursor_factory=RealDictCursor,
                sslmode='require'  # For hosted databases
            )
        except Exception as e:
            self.logger.error(f"PostgreSQL connection failed: {e}")
            self.logger.info("Falling back to SQLite")
            return self._get_sqlite_connection()
    
    def _get_sqlite_connection(self):
        """Get SQLite connection"""
        if self.db_url and self.db_url.startswith('sqlite://'):
            db_path = self.db_url.replace('sqlite://', '')
        else:
            db_path = self.config.app_dir / "typequest.db"
        
        return sqlite3.connect(db_path)
    
    def execute_schema_migration(self):
        """Run database schema setup/migrations"""
        if self.connection_type == 'postgresql':
            self._setup_postgres_schema()
        else:
            self._setup_sqlite_schema()
    
    def _setup_postgres_schema(self):
        """Set up PostgreSQL schema"""
        schema_sql = """
        -- Users table
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            total_xp INTEGER DEFAULT 10,
            level INTEGER DEFAULT 1,
            streak_days INTEGER DEFAULT 0,
            last_active TIMESTAMP,
            bio TEXT DEFAULT '',
            github_username VARCHAR(50) DEFAULT '',
            linkedin_url TEXT DEFAULT ''
        );
        
        -- User progress table
        CREATE TABLE IF NOT EXISTS user_progress (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            course_slug VARCHAR(100),
            lesson_slug VARCHAR(100),
            is_completed BOOLEAN DEFAULT FALSE,
            completed_at TIMESTAMP,
            time_spent INTEGER DEFAULT 0,
            UNIQUE(user_id, course_slug, lesson_slug)
        );
        
        -- Exercise submissions table  
        CREATE TABLE IF NOT EXISTS exercise_submissions (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            exercise_id VARCHAR(100),
            code TEXT,
            is_correct BOOLEAN DEFAULT FALSE,
            xp_earned INTEGER DEFAULT 0,
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            hints_used INTEGER DEFAULT 0
        );
        
        -- Achievements table
        CREATE TABLE IF NOT EXISTS user_achievements (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            achievement_slug VARCHAR(100),
            earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, achievement_slug)
        );
        
        -- Daily challenges table
        CREATE TABLE IF NOT EXISTS daily_challenges (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            date DATE,
            completed BOOLEAN DEFAULT FALSE,
            completed_at TIMESTAMP,
            xp_earned INTEGER DEFAULT 0,
            UNIQUE(user_id, date)
        );
        
        -- Learning goals table
        CREATE TABLE IF NOT EXISTS learning_goals (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            description TEXT,
            target_date DATE,
            is_completed BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Create indexes for better performance
        CREATE INDEX IF NOT EXISTS idx_user_progress_user_course ON user_progress(user_id, course_slug);
        CREATE INDEX IF NOT EXISTS idx_exercise_submissions_user ON exercise_submissions(user_id);
        CREATE INDEX IF NOT EXISTS idx_achievements_user ON user_achievements(user_id);
        """
        
        conn = self.get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(schema_sql)
            conn.commit()
            self.logger.info("PostgreSQL schema initialized successfully")
        except Exception as e:
            self.logger.error(f"PostgreSQL schema setup failed: {e}")
            conn.rollback()
        finally:
            conn.close()
    
    def _setup_sqlite_schema(self):
        """Set up SQLite schema (existing logic)"""
        schema_sql = """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            total_xp INTEGER DEFAULT 10,
            level INTEGER DEFAULT 1,
            streak_days INTEGER DEFAULT 0,
            last_active TEXT,
            bio TEXT DEFAULT '',
            github_username TEXT DEFAULT '',
            linkedin_url TEXT DEFAULT ''
        );
        
        CREATE TABLE IF NOT EXISTS user_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            course_slug TEXT,
            lesson_slug TEXT,
            is_completed BOOLEAN DEFAULT FALSE,
            completed_at TEXT,
            time_spent INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );
        
        CREATE TABLE IF NOT EXISTS exercise_submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            exercise_id TEXT,
            code TEXT,
            is_correct BOOLEAN DEFAULT FALSE,
            xp_earned INTEGER DEFAULT 0,
            submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
            hints_used INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );
        
        CREATE TABLE IF NOT EXISTS user_achievements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            achievement_slug TEXT,
            earned_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );
        
        CREATE TABLE IF NOT EXISTS daily_challenges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            date TEXT,
            completed BOOLEAN DEFAULT FALSE,
            completed_at TEXT,
            xp_earned INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );
        
        CREATE TABLE IF NOT EXISTS learning_goals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT NOT NULL,
            description TEXT,
            target_date TEXT,
            is_completed BOOLEAN DEFAULT FALSE,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );
        """
        
        conn = self.get_connection()
        try:
            cursor = conn.cursor()
            cursor.executescript(schema_sql)
            conn.commit()
            self.logger.info("SQLite schema initialized successfully")
        except Exception as e:
            self.logger.error(f"SQLite schema setup failed: {e}")
        finally:
            conn.close()

# Global database instance
db = DatabaseConnection()