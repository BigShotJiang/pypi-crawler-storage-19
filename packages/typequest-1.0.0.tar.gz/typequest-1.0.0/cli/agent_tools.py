"""
OpenAI-style agent tool system for the learning platform
"""

import json
import inspect
from typing import Dict, List, Any, Callable, Optional
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

console = Console()

class Tool:
    """Represents a tool that the agent can use"""
    
    def __init__(self, name: str, description: str, function: Callable, 
                 parameters: Dict[str, Any], examples: List[str] = None):
        self.name = name
        self.description = description
        self.function = function
        self.parameters = parameters
        self.examples = examples or []
        
    def to_dict(self):
        """Convert tool to OpenAI function format"""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters
            }
        }
    
    def call(self, **kwargs):
        """Call the tool function with provided arguments"""
        try:
            # Validate parameters
            sig = inspect.signature(self.function)
            bound = sig.bind(**kwargs)
            bound.apply_defaults()
            
            result = self.function(**bound.arguments)
            return {
                "success": True,
                "result": result,
                "tool_name": self.name
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "tool_name": self.name
            }


class ToolRegistry:
    """Registry for all available tools"""
    
    def __init__(self):
        self.tools: Dict[str, Tool] = {}
        self._register_default_tools()
    
    def register_tool(self, tool: Tool):
        """Register a new tool"""
        self.tools[tool.name] = tool
    
    def get_tool(self, name: str) -> Optional[Tool]:
        """Get a tool by name"""
        return self.tools.get(name)
    
    def get_all_tools(self) -> List[Tool]:
        """Get all registered tools"""
        return list(self.tools.values())
    
    def get_tools_for_openai(self) -> List[Dict]:
        """Get tools in OpenAI function calling format"""
        return [tool.to_dict() for tool in self.tools.values()]
    
    def _register_default_tools(self):
        """Register default learning platform tools"""
        from cli.config import Config
        from cli.course_manager import CourseManager
        from cli.user_manager import UserManager
        from cli.sql_executor import SQLExecutor
        from cli.python_executor import PythonExecutor
        from cli.gamification import GamificationManager
        
        # Initialize managers
        config = Config()
        course_manager = CourseManager()
        user_manager = UserManager()
        sql_executor = SQLExecutor()
        python_executor = PythonExecutor()
        gamification = GamificationManager()
        
        # Store references for tool functions
        self.config = config
        self.course_manager = course_manager
        self.user_manager = user_manager
        self.sql_executor = sql_executor
        self.python_executor = python_executor
        self.gamification = gamification
        self.current_user_id = None
        
        self._register_learning_tools()
        self._register_code_execution_tools()
        self._register_progress_tools()
        self._register_gamification_tools()
    
    def set_current_user(self, user_id: int):
        """Set the current user for tool operations"""
        self.current_user_id = user_id
    
    def _register_learning_tools(self):
        """Register learning-related tools"""
        
        def get_available_courses():
            """Get list of all available courses"""
            tracks = self.course_manager.get_tracks()
            courses = []
            for track in tracks:
                for course in track['courses']:
                    if isinstance(course, dict):
                        courses.append({
                            'name': course['name'],
                            'slug': course['slug'],
                            'difficulty': course['difficulty'],
                            'track': track['name']
                        })
                    else:
                        course_data = self.course_manager.get_course(course)
                        if course_data:
                            courses.append({
                                'name': course_data['name'],
                                'slug': course_data['slug'],
                                'difficulty': course_data['difficulty'],
                                'track': track['name']
                            })
            return courses
        
        def get_course_details(course_slug: str):
            """Get detailed information about a specific course"""
            course = self.course_manager.get_course(course_slug)
            if not course:
                return f"Course '{course_slug}' not found"
            
            return {
                'name': course['name'],
                'description': course['description'],
                'difficulty': course['difficulty'],
                'estimated_hours': course['estimated_hours'],
                'lessons': [
                    {
                        'chapter': lesson['chapter'],
                        'title': lesson['title'],
                        'is_free': lesson['is_free'],
                        'xp_reward': lesson['xp_reward']
                    }
                    for lesson in course['lessons']
                ]
            }
        
        def get_lesson_content(course_slug: str, lesson_slug: str):
            """Get the content of a specific lesson"""
            lesson = self.course_manager.get_lesson(course_slug, lesson_slug)
            if not lesson:
                return f"Lesson '{lesson_slug}' not found in course '{course_slug}'"
            
            return {
                'title': lesson['title'],
                'content': lesson['content'][:500] + "..." if len(lesson['content']) > 500 else lesson['content'],
                'exercises': len(lesson.get('exercises', [])),
                'xp_reward': lesson['xp_reward']
            }
        
        def search_lessons(query: str):
            """Search for lessons containing specific keywords"""
            results = []
            courses = ['learn-sql', 'learn-python']
            
            for course_slug in courses:
                course = self.course_manager.get_course(course_slug)
                if course:
                    for lesson in course['lessons']:
                        if query.lower() in lesson['title'].lower() or query.lower() in lesson['content'].lower():
                            results.append({
                                'course': course['name'],
                                'lesson': lesson['title'],
                                'chapter': lesson['chapter'],
                                'relevance': lesson['title'].lower().count(query.lower()) + lesson['content'].lower().count(query.lower())
                            })
            
            # Sort by relevance
            results.sort(key=lambda x: x['relevance'], reverse=True)
            return results[:5]  # Return top 5 results
        
        # Register learning tools
        self.register_tool(Tool(
            name="get_available_courses",
            description="Get a list of all available courses in the learning platform",
            function=get_available_courses,
            parameters={
                "type": "object",
                "properties": {},
                "required": []
            },
            examples=["What courses are available?", "Show me all courses"]
        ))
        
        self.register_tool(Tool(
            name="get_course_details",
            description="Get detailed information about a specific course including lessons",
            function=get_course_details,
            parameters={
                "type": "object",
                "properties": {
                    "course_slug": {
                        "type": "string",
                        "description": "The slug of the course (e.g., 'learn-sql', 'learn-python')"
                    }
                },
                "required": ["course_slug"]
            },
            examples=["Tell me about the SQL course", "What's in the Python course?"]
        ))
        
        self.register_tool(Tool(
            name="get_lesson_content",
            description="Get the content of a specific lesson",
            function=get_lesson_content,
            parameters={
                "type": "object",
                "properties": {
                    "course_slug": {
                        "type": "string",
                        "description": "The slug of the course"
                    },
                    "lesson_slug": {
                        "type": "string",
                        "description": "The slug of the lesson"
                    }
                },
                "required": ["course_slug", "lesson_slug"]
            },
            examples=["Show me the decorators lesson", "What's in the SQL basics lesson?"]
        ))
        
        self.register_tool(Tool(
            name="search_lessons",
            description="Search for lessons containing specific keywords or topics",
            function=search_lessons,
            parameters={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The search term or keyword to look for in lessons"
                    }
                },
                "required": ["query"]
            },
            examples=["Find lessons about decorators", "Search for JOIN tutorials"]
        ))
    
    def _register_code_execution_tools(self):
        """Register code execution tools"""
        
        def execute_sql_query(query: str, dataset: str = "company_db"):
            """Execute a SQL query on a sample dataset"""
            result = self.sql_executor.execute_query(query, dataset, validate=False)
            
            if result['success']:
                return {
                    'success': True,
                    'data': result['data'][:10],  # Limit to 10 rows for agent
                    'row_count': result['row_count'],
                    'columns': result['columns']
                }
            else:
                return {
                    'success': False,
                    'error': result['error']
                }
        
        def execute_python_code(code: str):
            """Execute Python code and return the result"""
            result = self.python_executor.execute_code(code)
            
            return {
                'success': result['success'],
                'output': result['output'][:1000],  # Limit output length
                'error': result.get('error', '')
            }
        
        def get_dataset_info(dataset_name: str = "company_db"):
            """Get information about available datasets"""
            datasets = self.sql_executor.get_available_datasets()
            
            for dataset in datasets:
                if dataset['name'] == dataset_name:
                    return {
                        'name': dataset['name'],
                        'display_name': dataset['display_name'],
                        'description': dataset['description'],
                        'available': True
                    }
            
            return {
                'available': False,
                'error': f"Dataset '{dataset_name}' not found",
                'available_datasets': [d['name'] for d in datasets]
            }
        
        # Register code execution tools
        self.register_tool(Tool(
            name="execute_sql_query",
            description="Execute a SQL query on sample datasets to demonstrate concepts or help with learning",
            function=execute_sql_query,
            parameters={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The SQL query to execute"
                    },
                    "dataset": {
                        "type": "string",
                        "description": "The dataset to query (company_db, ecommerce_db)",
                        "default": "company_db"
                    }
                },
                "required": ["query"]
            },
            examples=["Show me all employees", "Execute: SELECT * FROM products LIMIT 5"]
        ))
        
        self.register_tool(Tool(
            name="execute_python_code",
            description="Execute Python code to demonstrate concepts or test solutions",
            function=execute_python_code,
            parameters={
                "type": "object",
                "properties": {
                    "code": {
                        "type": "string",
                        "description": "The Python code to execute"
                    }
                },
                "required": ["code"]
            },
            examples=["Test this decorator", "Run: print('Hello, World!')"]
        ))
        
        self.register_tool(Tool(
            name="get_dataset_info",
            description="Get information about available datasets for SQL practice",
            function=get_dataset_info,
            parameters={
                "type": "object",
                "properties": {
                    "dataset_name": {
                        "type": "string",
                        "description": "Name of the dataset to get info about",
                        "default": "company_db"
                    }
                },
                "required": []
            },
            examples=["What datasets are available?", "Tell me about the company database"]
        ))
    
    def _register_progress_tools(self):
        """Register progress tracking tools"""
        
        def get_user_progress(course_slug: str = None):
            """Get user's learning progress"""
            if not self.current_user_id:
                return "No user logged in"
            
            if course_slug:
                progress = self.course_manager.get_user_progress(self.current_user_id, course_slug)
                stats = self.course_manager.get_course_stats(self.current_user_id, course_slug)
                return {
                    'course': course_slug,
                    'progress': progress,
                    'stats': stats
                }
            else:
                # Get overall stats
                stats = self.user_manager.get_user_stats(self.current_user_id)
                return stats
        
        def get_next_lesson(course_slug: str = "learn-sql"):
            """Get the next lesson the user should take"""
            if not self.current_user_id:
                return "No user logged in"
            
            next_lesson = self.course_manager.get_next_lesson(self.current_user_id, course_slug)
            if next_lesson:
                return {
                    'course': course_slug,
                    'next_lesson': {
                        'title': next_lesson['title'],
                        'chapter': next_lesson['chapter'],
                        'slug': next_lesson['slug']
                    }
                }
            else:
                return f"All lessons completed in {course_slug}!"
        
        def get_user_achievements():
            """Get user's achievements"""
            if not self.current_user_id:
                return "No user logged in"
            
            achievements = self.gamification.get_user_achievements(self.current_user_id)
            return {
                'total_achievements': len(achievements),
                'recent_achievements': achievements[:5]  # Last 5
            }
        
        # Register progress tools
        self.register_tool(Tool(
            name="get_user_progress",
            description="Get the user's learning progress in courses",
            function=get_user_progress,
            parameters={
                "type": "object",
                "properties": {
                    "course_slug": {
                        "type": "string",
                        "description": "Specific course to check progress for (optional)"
                    }
                },
                "required": []
            },
            examples=["How's my progress?", "Check my SQL progress"]
        ))
        
        self.register_tool(Tool(
            name="get_next_lesson",
            description="Get the next lesson the user should take in a course",
            function=get_next_lesson,
            parameters={
                "type": "object",
                "properties": {
                    "course_slug": {
                        "type": "string",
                        "description": "The course to get next lesson for",
                        "default": "learn-sql"
                    }
                },
                "required": []
            },
            examples=["What should I learn next?", "Next lesson in Python course"]
        ))
        
        self.register_tool(Tool(
            name="get_user_achievements",
            description="Get user's earned achievements and progress",
            function=get_user_achievements,
            parameters={
                "type": "object",
                "properties": {},
                "required": []
            },
            examples=["Show my achievements", "What achievements do I have?"]
        ))
    
    def _register_gamification_tools(self):
        """Register gamification-related tools"""
        
        def get_leaderboard(board_type: str = "all_time"):
            """Get leaderboard information"""
            leaderboard = self.gamification.get_leaderboard(board_type, limit=10)
            return {
                'type': board_type,
                'top_users': leaderboard[:5]  # Top 5 for agent
            }
        
        def check_daily_challenge():
            """Check today's daily challenge"""
            if not self.current_user_id:
                return "No user logged in"
            
            challenge = self.gamification.get_daily_challenge(self.current_user_id)
            return {
                'title': challenge['title'],
                'description': challenge['description'],
                'bonus_xp': challenge['bonus_xp'],
                'completed': challenge['status']['completed']
            }
        
        # Register gamification tools
        self.register_tool(Tool(
            name="get_leaderboard",
            description="Get current leaderboard rankings",
            function=get_leaderboard,
            parameters={
                "type": "object",
                "properties": {
                    "board_type": {
                        "type": "string",
                        "description": "Type of leaderboard: 'all_time' or 'weekly'",
                        "default": "all_time"
                    }
                },
                "required": []
            },
            examples=["Show me the leaderboard", "Who's at the top this week?"]
        ))
        
        self.register_tool(Tool(
            name="check_daily_challenge",
            description="Check today's daily coding challenge",
            function=check_daily_challenge,
            parameters={
                "type": "object",
                "properties": {},
                "required": []
            },
            examples=["What's today's challenge?", "Show daily challenge"]
        ))


class LearningAgent:
    """AI Agent that can help with learning using tools"""
    
    def __init__(self, tool_registry: ToolRegistry):
        self.tools = tool_registry
        self.conversation_history = []
        
    def set_user(self, user_id: int):
        """Set the current user for the agent"""
        self.tools.set_current_user(user_id)
    
    def process_message(self, user_message: str) -> Dict[str, Any]:
        """Process a user message and determine what tools to use"""
        # Simple rule-based tool selection (in a real implementation, you'd use an LLM)
        message_lower = user_message.lower()
        
        # Determine intent and select tools
        tools_to_use = self._select_tools(message_lower)
        
        if not tools_to_use:
            return self._generate_general_response(user_message)
        
        # Execute tools
        tool_results = []
        for tool_name, params in tools_to_use:
            tool = self.tools.get_tool(tool_name)
            if tool:
                result = tool.call(**params)
                tool_results.append(result)
        
        # Generate response based on tool results
        response = self._generate_response(user_message, tool_results)
        
        # Store in conversation history
        self.conversation_history.append({
            'user_message': user_message,
            'tools_used': [t[0] for t in tools_to_use],
            'response': response,
            'timestamp': datetime.now().isoformat()
        })
        
        return response
    
    def _select_tools(self, message: str) -> List[tuple]:
        """Select appropriate tools based on user message"""
        tools_to_use = []
        
        # Course and lesson queries
        if any(word in message for word in ['courses', 'what can i learn', 'available']):
            tools_to_use.append(('get_available_courses', {}))
        
        if any(word in message for word in ['sql course', 'python course']) and 'details' in message:
            if 'sql' in message:
                tools_to_use.append(('get_course_details', {'course_slug': 'learn-sql'}))
            elif 'python' in message:
                tools_to_use.append(('get_course_details', {'course_slug': 'learn-python'}))
        
        # Progress queries
        if any(word in message for word in ['progress', 'how am i doing', 'stats']):
            tools_to_use.append(('get_user_progress', {}))
        
        if any(word in message for word in ['next lesson', 'what should i learn', 'continue']):
            tools_to_use.append(('get_next_lesson', {}))
        
        # Achievement queries
        if any(word in message for word in ['achievements', 'badges', 'accomplishments']):
            tools_to_use.append(('get_user_achievements', {}))
        
        # Leaderboard queries
        if any(word in message for word in ['leaderboard', 'rankings', 'top users']):
            board_type = 'weekly' if 'week' in message else 'all_time'
            tools_to_use.append(('get_leaderboard', {'board_type': board_type}))
        
        # Daily challenge
        if any(word in message for word in ['daily challenge', "today's challenge", 'challenge']):
            tools_to_use.append(('check_daily_challenge', {}))
        
        # Code execution
        if message.startswith('run sql:') or message.startswith('execute sql:'):
            query = message.split(':', 1)[1].strip()
            tools_to_use.append(('execute_sql_query', {'query': query}))
        
        if message.startswith('run python:') or message.startswith('execute python:'):
            code = message.split(':', 1)[1].strip()
            tools_to_use.append(('execute_python_code', {'code': code}))
        
        # Search
        if message.startswith('search:') or message.startswith('find:'):
            query = message.split(':', 1)[1].strip()
            tools_to_use.append(('search_lessons', {'query': query}))
        
        return tools_to_use
    
    def _generate_response(self, user_message: str, tool_results: List[Dict]) -> Dict[str, Any]:
        """Generate a response based on tool results"""
        if not tool_results:
            return self._generate_general_response(user_message)
        
        response_parts = []
        
        for result in tool_results:
            if result['success']:
                response_parts.append(self._format_tool_result(result))
            else:
                response_parts.append(f"❌ Error with {result['tool_name']}: {result['error']}")
        
        return {
            'type': 'tool_response',
            'message': '\n\n'.join(response_parts),
            'tools_used': [r['tool_name'] for r in tool_results],
            'success': all(r['success'] for r in tool_results)
        }
    
    def _format_tool_result(self, result: Dict) -> str:
        """Format tool results for display"""
        tool_name = result['tool_name']
        data = result['result']
        
        if tool_name == 'get_available_courses':
            courses_list = '\n'.join([f"📚 {c['name']} ({c['difficulty']}) - {c['track']}" for c in data])
            return f"**Available Courses:**\n{courses_list}"
        
        elif tool_name == 'get_course_details':
            course = data
            lessons_list = '\n'.join([f"  Ch{l['chapter']}: {l['title']} ({'Free' if l['is_free'] else 'Premium'}) - {l['xp_reward']} XP" for l in course['lessons']])
            return f"**{course['name']}** ({course['difficulty']})\n{course['description']}\n\n**Lessons:**\n{lessons_list}"
        
        elif tool_name == 'get_user_progress':
            if isinstance(data, dict) and 'total_xp' in data:
                return f"**Your Progress:**\n🎯 Level {data['level']} • {data['total_xp']} XP\n📚 {data['lessons_completed']} lessons completed\n🔥 {data['streak_days']} day streak"
            else:
                return f"**Progress:** {data}"
        
        elif tool_name == 'execute_sql_query':
            if data['success']:
                return f"**SQL Query Results:**\n✅ {data['row_count']} rows returned\nColumns: {', '.join(data['columns'])}\n\nFirst few rows:\n{json.dumps(data['data'][:3], indent=2)}"
            else:
                return f"**SQL Error:** {data['error']}"
        
        elif tool_name == 'execute_python_code':
            if data['success']:
                return f"**Python Output:**\n```\n{data['output']}\n```"
            else:
                return f"**Python Error:** {data['error']}"
        
        elif tool_name == 'get_leaderboard':
            top_users = '\n'.join([f"{i+1}. {u['username']} - {u['total_xp']} XP" for i, u in enumerate(data['top_users'])])
            return f"**🏆 {data['type'].replace('_', ' ').title()} Leaderboard:**\n{top_users}"
        
        else:
            return f"**{tool_name}:** {json.dumps(data, indent=2)}"
    
    def _generate_general_response(self, user_message: str) -> Dict[str, Any]:
        """Generate a general response when no tools are needed"""
        responses = {
            'hello': "👋 Hi! I'm your learning assistant. I can help you with courses, track your progress, execute code, and more!",
            'help': """🤖 **I can help you with:**
• 📚 **Courses**: "What courses are available?" or "Tell me about the SQL course"
• 📊 **Progress**: "How's my progress?" or "What should I learn next?"
• 🏆 **Achievements**: "Show my achievements" or "Check leaderboard"
• 💻 **Code**: "Run SQL: SELECT * FROM employees" or "Execute Python: print('Hello')"
• 🔍 **Search**: "Search: decorators" or "Find: JOIN tutorials"
• 🎯 **Daily**: "What's today's challenge?"

Just ask me naturally!""",
            'thanks': "🎉 You're welcome! Keep learning and coding! 🚀"
        }
        
        message_lower = user_message.lower()
        
        if any(word in message_lower for word in ['hello', 'hi', 'hey']):
            return {'type': 'general', 'message': responses['hello']}
        elif any(word in message_lower for word in ['help', 'what can you do', 'commands']):
            return {'type': 'general', 'message': responses['help']}
        elif any(word in message_lower for word in ['thanks', 'thank you']):
            return {'type': 'general', 'message': responses['thanks']}
        else:
            return {
                'type': 'general', 
                'message': "🤔 I'm not sure how to help with that. Type 'help' to see what I can do, or try asking about courses, progress, or code execution!"
            }
    
    def get_conversation_summary(self) -> str:
        """Get a summary of the conversation"""
        if not self.conversation_history:
            return "No conversation history yet."
        
        total_messages = len(self.conversation_history)
        tools_used = set()
        for entry in self.conversation_history:
            tools_used.update(entry.get('tools_used', []))
        
        return f"**Conversation Summary:**\n📝 {total_messages} messages exchanged\n🛠️ Tools used: {', '.join(tools_used) if tools_used else 'None'}"