"""
Course and lesson management for CLI application
"""

import json
from datetime import datetime
from cli.config import Config
from cli.python_content_comprehensive import COMPREHENSIVE_PYTHON_CONTENT
from cli.django_content import DJANGO_COURSE_CONTENT
from cli.django_content.lesson_registry import get_ordered_lessons, get_lesson_by_key

class CourseManager:
    def __init__(self):
        self.config = Config()
        self.courses_data = self.load_course_data()
    
    def build_sql_course_from_registry(self):
        """Build SQL course from the comprehensive lesson registry"""
        try:
            # Get SQL lessons from the registry
            sql_lessons = get_ordered_lessons('sql_course')
            
            return {
                "name": "Master SQL Database Development",
                "slug": "learn-sql",
                "description": "Complete SQL mastery from basics to advanced database design. Learn with real-world examples from Instagram, Amazon, Netflix, and more!",
                "difficulty": "beginner",
                "estimated_hours": 25,
                "track": "backend",
                "lessons": sql_lessons
            }
        except Exception as e:
            print(f"Warning: Could not load SQL lessons from registry: {e}")
            # Fallback to a simple structure
            return {
                "name": "Learn SQL Basics",
                "slug": "learn-sql", 
                "description": "Learn SQL fundamentals",
                "difficulty": "beginner",
                "estimated_hours": 10,
                "track": "backend",
                "lessons": []
            }
    
    def build_comprehensive_courses(self):
        """Build 3 comprehensive mega-courses"""
        courses = {}
        
        try:
            # Course 1: Master SQL Database Development
            sql_lessons = get_ordered_lessons('sql_course')
            courses["master-sql"] = {
                "name": "Master SQL Database Development",
                "slug": "master-sql",
                "description": "Complete SQL mastery from basics to advanced database design with real-world examples from Instagram, Netflix, and more",
                "difficulty": "beginner", 
                "estimated_hours": 25,
                "track": "backend",
                "lessons": sql_lessons,
                "icon": "🗄️",
                "highlights": [
                    "Query real company databases (Instagram users, Netflix movies, Spotify playlists) to extract business insights",
                    "Master advanced JOINs to combine data across multiple tables and build complex analytics reports",
                    "Optimize database performance with indexes, query planning, and efficient data retrieval strategies"
                ]
            }
            
            # Course 2: Software Engineering Fundamentals with Python
            # Combine Python + Django foundations + basic concepts
            try:
                python_lessons = []
                # Add Django foundations lessons to Python course
                django_foundations = get_ordered_lessons('django_foundations_course')
                for lesson in django_foundations:
                    python_lessons.append(lesson)
                
                courses["python-fundamentals"] = {
                    "name": "Software Engineering Fundamentals with Python", 
                    "slug": "python-fundamentals",
                    "description": "Master Python programming, software engineering principles, and Django project fundamentals",
                    "difficulty": "beginner",
                    "estimated_hours": 60,
                    "track": "backend",
                    "lessons": python_lessons,
                    "icon": "🐍",
                    "highlights": [
                        "Build production-ready Python applications with proper code structure, testing, and error handling",
                        "Master Django project architecture - apps, settings, URLs, and management commands for scalable web development",
                        "Implement professional development workflows with Git version control, virtual environments, and deployment strategies"
                    ]
                }
            except Exception as e:
                print(f"Warning: Could not build Python fundamentals course: {e}")
            
            # Course 3: Building Backend Apps with Django
            # Combine all Django courses into one mega-course
            django_all_lessons = []
            
            # Get lessons from different Django courses in logical order
            course_order = [
                'django_foundations_course',  # Settings, apps, commands (fundamentals first!)
                'models_focus',  # Models and database
                'views_focus',   # Views and URLs
                'django_database_course',  # Advanced database
                'django_migrations_course',  # Migrations
                'django_expressions_course',  # Database expressions
                'django_async_course'  # Async development
            ]
            
            for course_key in course_order:
                try:
                    lessons = get_ordered_lessons(course_key)
                    django_all_lessons.extend(lessons)
                except Exception as e:
                    print(f"Warning: Could not load {course_key}: {e}")
            
            courses["django-backend"] = {
                "name": "Building Backend Apps with Django",
                "slug": "django-backend", 
                "description": "Complete Django backend development from models to production-ready applications with async support",
                "difficulty": "intermediate",
                "estimated_hours": 85,
                "track": "backend",
                "lessons": django_all_lessons,
                "icon": "🌐", 
                "highlights": [
                    "Build scalable web applications with Django ORM, complex relationships, and optimized database queries",
                    "Create robust REST APIs using class-based views, authentication, serialization, and advanced URL routing patterns",
                    "Deploy production-ready apps with async support, database migrations, performance optimization, and modern DevOps practices"
                ]
            }
            
        except Exception as e:
            print(f"Warning: Could not build comprehensive courses: {e}")
        
        return courses
    
    def load_course_data(self):
        """Load course data with 3 comprehensive mega-courses"""
        
        # Build the 3 comprehensive courses
        comprehensive_courses = self.build_comprehensive_courses()
        
        return {
            "tracks": [
                {
                    "id": 1,
                    "name": "Backend Development",
                    "slug": "backend", 
                    "description": "Complete backend development mastery - from databases to production applications",
                    "icon": "🚀",
                    "courses": list(comprehensive_courses.keys())
                }
            ],
            "courses": comprehensive_courses
        }
    
    def get_tracks(self):
        """Get all learning tracks"""
        return self.courses_data["tracks"]
    
    def get_course(self, slug):
        """Get course data by slug"""
        return self.courses_data["courses"].get(slug)
    
    def get_lesson(self, course_slug, lesson_slug):
        """Get a specific lesson"""
        course = self.get_course(course_slug)
        if not course:
            return None
        
        # Try to get from lesson registry first (works for all our courses)
        if course_slug in ["master-sql", "python-fundamentals", "django-backend"]:
            try:
                return get_lesson_by_key(lesson_slug)
            except Exception as e:
                print(f"Warning: Could not get lesson {lesson_slug} from registry: {e}")
                pass
        
        # Fallback to course lessons
        for lesson in course.get("lessons", []):
            if lesson.get("slug") == lesson_slug:
                return lesson
        
        return None
    
    def get_user_progress(self, user_id, course_slug):
        """Get user progress for a course"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT lesson_slug, is_completed, completed_at
            FROM user_progress 
            WHERE user_id = ? AND course_slug = ?
        ''', (user_id, course_slug))
        
        progress = {}
        for lesson_slug, is_completed, completed_at in cursor.fetchall():
            progress[lesson_slug] = {
                'completed': bool(is_completed),
                'completion_date': completed_at
            }
        
        conn.close()
        return progress
    
    def mark_lesson_complete(self, user_id, course_slug, lesson_slug, time_spent=0):
        """Mark a lesson as completed"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        # Insert or update progress
        cursor.execute('''
            INSERT OR REPLACE INTO user_progress 
            (user_id, course_slug, lesson_slug, is_completed, completed_at, time_spent)
            VALUES (?, ?, ?, 1, ?, ?)
        ''', (user_id, course_slug, lesson_slug, datetime.now().isoformat(), time_spent))
        
        conn.commit()
        conn.close()
    
    def get_next_lesson(self, user_id, course_slug):
        """Get the next lesson for a user to take"""
        course = self.get_course(course_slug)
        if not course:
            return None
        
        progress = self.get_user_progress(user_id, course_slug)
        
        for lesson in course["lessons"]:
            lesson_slug = lesson.get("slug")
            if lesson_slug not in progress or not progress[lesson_slug]["completed"]:
                return lesson
        
        return None
    
    def get_course_stats(self, user_id, course_slug):
        """Get statistics for a course"""
        course = self.get_course(course_slug)
        if not course:
            return None
        
        progress = self.get_user_progress(user_id, course_slug)
        total_lessons = len(course["lessons"])
        completed_lessons = sum(1 for p in progress.values() if p["completed"])
        
        # Calculate total XP earned
        total_xp_earned = 0
        for lesson in course["lessons"]:
            lesson_slug = lesson.get("slug")
            if lesson_slug in progress and progress[lesson_slug]["completed"]:
                total_xp_earned += lesson.get("xp_reward", 0)
        
        return {
            "total_lessons": total_lessons,
            "completed_lessons": completed_lessons,
            "progress_percentage": (completed_lessons / total_lessons * 100) if total_lessons > 0 else 0,
            "total_xp_earned": total_xp_earned
        }