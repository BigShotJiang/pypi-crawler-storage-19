#!/usr/bin/env python3
"""
Test script to verify CLI installation works correctly
"""
import sys
import subprocess
import os
from pathlib import Path

def test_package_structure():
    """Test if package structure is correct"""
    print("🔍 Testing package structure...")
    
    # Check if boots directory exists
    boots_dir = Path("boots")
    if not boots_dir.exists():
        print("❌ boots/ directory not found")
        return False
    
    # Check if cli.py exists
    cli_file = boots_dir / "cli.py"
    if not cli_file.exists():
        print("❌ boots/cli.py not found")
        return False
        
    print("✅ Package structure looks good")
    return True

def test_imports():
    """Test if imports work correctly"""
    print("🔍 Testing imports...")
    
    try:
        # Test main imports
        sys.path.insert(0, '.')
        from boots import cli
        print("✅ Main CLI import successful")
        
        # Test database import
        from database import DatabaseConnection
        print("✅ Database import successful")
        
        # Test config import
        from config import Config
        print("✅ Config import successful")
        
        return True
    except Exception as e:
        print(f"❌ Import failed: {e}")
        return False

def test_console_scripts():
    """Test if console scripts are configured correctly"""
    print("🔍 Testing console scripts configuration...")
    
    # Check pyproject.toml
    pyproject_file = Path("pyproject.toml")
    if pyproject_file.exists():
        content = pyproject_file.read_text()
        if 'boots = "boots.cli:main"' in content:
            print("✅ Console scripts configured in pyproject.toml")
            return True
    
    # Check setup.py
    setup_file = Path("setup.py")
    if setup_file.exists():
        content = setup_file.read_text()
        if 'boots=boots.cli:main' in content or 'boots.cli:main' in content:
            print("✅ Console scripts configured in setup.py")
            return True
    
    print("❌ Console scripts not properly configured")
    return False

def test_dependencies():
    """Test if dependencies are properly specified"""
    print("🔍 Testing dependencies...")
    
    required_deps = [
        "rich",
        "inquirer", 
        "psycopg2-binary"
    ]
    
    # Check pyproject.toml dependencies
    pyproject_file = Path("pyproject.toml")
    if pyproject_file.exists():
        content = pyproject_file.read_text()
        missing_deps = []
        
        for dep in required_deps:
            if dep not in content:
                missing_deps.append(dep)
        
        if missing_deps:
            print(f"❌ Missing dependencies in pyproject.toml: {missing_deps}")
            return False
        else:
            print("✅ All dependencies found in pyproject.toml")
            return True
    
    print("❌ pyproject.toml not found")
    return False

def test_build_package():
    """Test if package can be built"""
    print("🔍 Testing package build...")
    
    try:
        # Try to build the package
        result = subprocess.run(
            [sys.executable, "-m", "build", "--wheel"],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode == 0:
            print("✅ Package builds successfully")
            return True
        else:
            print(f"❌ Build failed: {result.stderr}")
            return False
            
    except subprocess.TimeoutExpired:
        print("❌ Build timed out")
        return False
    except FileNotFoundError:
        print("⚠️ Build tools not available (install with: pip install build)")
        return True  # Not critical for basic functionality

def main():
    """Run all tests"""
    print("🚀 Testing CLI Installation Setup\n")
    
    tests = [
        ("Package Structure", test_package_structure),
        ("Import Tests", test_imports),
        ("Console Scripts", test_console_scripts),
        ("Dependencies", test_dependencies),
        ("Build Package", test_build_package),
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n{'='*50}")
        print(f"Running: {test_name}")
        print(f"{'='*50}")
        
        try:
            if test_func():
                passed += 1
        except Exception as e:
            print(f"❌ Test failed with exception: {e}")
    
    print(f"\n{'='*50}")
    print(f"RESULTS: {passed}/{total} tests passed")
    print(f"{'='*50}")
    
    if passed == total:
        print("🎉 All tests passed! Your CLI is ready for distribution.")
        print("\nNext steps:")
        print("1. Build package: python -m build")
        print("2. Test locally: pip install dist/*.whl")
        print("3. Test CLI: boots")
        print("4. Upload to PyPI: twine upload dist/*")
    else:
        print("⚠️ Some tests failed. Please fix issues before distributing.")
        
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)