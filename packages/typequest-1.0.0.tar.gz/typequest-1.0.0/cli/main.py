#!/usr/bin/env python3
"""
TypeQuest
A terminal-based coding education platform
"""

import sys
import os
from pathlib import Path

# Add the parent directory to the Python path
sys.path.append(str(Path(__file__).parent.parent))

from rich.console import Console
from rich.text import Text
from rich.panel import Panel
from rich.layout import Layout
from rich.table import Table
from rich.prompt import Prompt, Confirm
from rich.progress import track, Progress, SpinnerColumn, TextColumn
import pyfiglet
import inquirer
import json
import sqlite3
from datetime import datetime, timedelta
import time

from cli.user_manager import UserManager
from cli.course_manager import CourseManager
from cli.sql_executor import SQLExecutor
from cli.python_executor import PythonExecutor
from cli.gamification import GamificationManager
from cli.config import Config
from cli.agent_tools import ToolRegistry, LearningAgent
from cli.typewriter_display import typewriter, type_lesson, type_text, toggle_typewriter, set_typewriter_speed, show_typewriter_settings

console = Console()

class BootsCLI:
    def __init__(self):
        self.config = Config()
        self.user_manager = UserManager()
        self.course_manager = CourseManager()
        self.sql_executor = SQLExecutor()
        self.python_executor = PythonExecutor()
        self.gamification = GamificationManager()
        self.tool_registry = ToolRegistry()
        self.agent = LearningAgent(self.tool_registry)
        self.current_user = None
        
    def display_banner(self):
        """Display the welcome banner"""
        banner = pyfiglet.figlet_format("TYPEQUEST", font="slant")
        banner_text = Text(banner, style="bold cyan")
        subtitle = Text("🚀 Learn to Code • Master SQL • Build Projects", style="dim white")
        
        console.print()
        console.print(Panel(
            f"{banner_text}\n{subtitle}",
            border_style="cyan",
            padding=(1, 2)
        ))
        console.print()
    
    def show_main_menu(self):
        """Display main menu options"""
        if not self.current_user:
            choices = [
                "📚 Browse Courses (Guest)",
                "🎮 SQL Playground",
                "🐍 Python Playground",
                "🤖 AI Learning Assistant", 
                "👤 Login",
                "📝 Sign Up",
                "⌨️  Typewriter Settings",
                "❓ About",
                "🚪 Exit"
            ]
        else:
            user_info = f"🎯 Level {self.current_user['level']} • {self.current_user['xp']} XP"
            choices = [
                f"📊 Dashboard ({user_info})",
                "📚 My Courses",
                "🎯 Continue Learning",
                "🎮 SQL Playground",
                "🐍 Python Playground",
                "🤖 AI Learning Assistant",
                "🏆 Achievements",
                "📈 Leaderboard", 
                "👤 Profile",
                "⌨️  Typewriter Settings",
                "🔓 Logout",
                "🚪 Exit"
            ]
        
        questions = [
            inquirer.List(
                'action',
                message="What would you like to do?",
                choices=choices,
                carousel=True
            )
        ]
        
        answer = inquirer.prompt(questions)
        return answer['action'] if answer else None
    
    def handle_guest_browse(self):
        """Allow guests to browse course content with enhanced UI"""
        console.print("\n🎓 [bold cyan]TypeQuest Backend Mastery Program[/bold cyan]")
        console.print("[dim]📈 A structured 170-hour journey from SQL basics to production Django apps[/dim]\n")
        
        tracks = self.course_manager.get_tracks()
        track = tracks[0]  # Get the backend track
        
        # Get course data for the table
        courses_data = []
        for course_slug in track['courses']:
            course = self.course_manager.get_course(course_slug)
            if course:
                courses_data.append(course)
        
        # Create enhanced course table with progression flow
        course_table = Table(title="📚 Backend Development Courses", show_header=True, border_style="cyan")
        course_table.add_column("Stage", style="bold cyan", width=8, justify="center")  # Stage number
        course_table.add_column("Course", style="bold white", min_width=35)
        course_table.add_column("Level", style="yellow", width=12, justify="center")
        course_table.add_column("Duration", style="green", width=10, justify="center")
        course_table.add_column("Career Outcome", style="bright_blue", min_width=40)
        
        # Define career outcomes and progression
        career_outcomes = [
            "🎯 [bold]Data Analyst Ready[/bold] - Query real databases, extract insights",
            "🛠️ [bold]Junior Developer Ready[/bold] - Build apps, work with teams",
            "🚀 [bold]Backend Developer Ready[/bold] - Production apps, API design"
        ]
        
        # Prerequisites for each stage
        prerequisites = [
            "No experience needed • Start here",
            "Complete Stage 1 • Basic SQL knowledge", 
            "Complete Stages 1-2 • Python & Django foundations"
        ]
        
        for i, course in enumerate(courses_data, 1):
            # Add flow arrow for progression with better visual hierarchy
            if i == 1:
                stage_indicator = f"[bold green]START[/bold green]\n[dim]{i}[/dim]"
            elif i < len(courses_data):
                stage_indicator = f"[bold cyan]{i}[/bold cyan]\n[dim]↓[/dim]"
            else:
                stage_indicator = f"[bold magenta]GOAL[/bold magenta]\n[dim]{i}[/dim]"
            
            course_table.add_row(
                stage_indicator,
                f"{course.get('icon', '📚')} [bold]{course['name']}[/bold]\n[dim]{prerequisites[i-1]}[/dim]",
                course['difficulty'].title(),
                f"{course['estimated_hours']}h",
                career_outcomes[i-1] if i <= len(career_outcomes) else "Advanced backend skills"
            )
            
            # Add separator between stages for better visual flow
            if i < len(courses_data):
                course_table.add_row("", "", "", "", "", style="dim")
        
        console.print(course_table)
        
        # Simple, powerful call to action
        console.print(f"\n🚀 [bold cyan]Ready to become a backend developer?[/bold cyan]")
        console.print(f"[dim]Choose a course and start building real-world skills today.[/dim]\n")
        
        # Course selection with clean choices
        course_choices = []
        for course in courses_data:
            icon = course.get('icon', '📚')
            choice_text = f"{icon} {course['name']}"
            course_choices.append(choice_text)
        
        course_choices.append("🔙 Back to Main Menu")
        
        from inquirer import List, prompt
        questions = [
            List('course',
                message="Pick a course to get started",
                choices=course_choices,
                carousel=True  # Enable circular navigation
            ),
        ]
        
        answers = prompt(questions)
        if answers and "Back to Main Menu" not in answers['course']:
            # Find selected course by matching the name
            selected_course = None
            for course in courses_data:
                if course['name'] in answers['course']:
                    selected_course = course
                    break
            
            if selected_course:
                self.preview_course_enhanced(selected_course)
    
    def preview_course_enhanced(self, course):
        """Enhanced course preview with highlights and better formatting"""
        console.clear()
        
        # Course header with icon
        icon = course.get('icon', '📚')
        console.print(f"\n{icon} [bold blue]{course['name']}[/bold blue]")
        console.print(f"📝 {course['description']}")
        console.print()
        
        # Course info table
        info_table = Table.grid(padding=1)
        info_table.add_column(style="cyan")
        info_table.add_column(style="white")
        
        info_table.add_row("⏱️  Duration:", f"{course['estimated_hours']} hours")
        info_table.add_row("📊 Difficulty:", course['difficulty'].title())
        info_table.add_row("🎯 Track:", "Backend Development")
        
        console.print(info_table)
        
        # Course highlights
        if 'highlights' in course:
            console.print("\n✨ [bold]What You'll Learn:[/bold]")
            for highlight in course['highlights']:
                console.print(f"  ✅ {highlight}")
        
        # Course outline with better formatting
        console.print(f"\n📋 [bold]Course Outline:[/bold] ({len(course['lessons'])} lessons)")
        
        # Show first 8 lessons in a nice format
        outline_table = Table(show_header=False, box=None)
        outline_table.add_column("Status", width=4)
        outline_table.add_column("Chapter", width=10)
        outline_table.add_column("Title", style="white")
        
        for i, lesson in enumerate(course['lessons'][:8]):
            status = "🆓" if lesson.get('is_free', False) else "🔒"
            outline_table.add_row(
                status,
                f"Ch. {lesson.get('chapter', i+1)}",
                lesson['title']
            )
        
        console.print(outline_table)
        
        if len(course['lessons']) > 8:
            console.print(f"   [dim]... and {len(course['lessons']) - 8} more chapters[/dim]")
        
        # Enhanced call to action
        console.print(f"\n🚀 [bold green]Ready to start your backend development journey?[/bold green]")
        console.print("💡 [dim]Create an account to track progress, earn XP, and unlock achievements![/dim]\n")
        
        # Action choices
        choices = [
            "🎯 Start Learning (Sign Up)",
            "🔑 I Have an Account (Login)", 
            "🔙 Back to Course Catalog"
        ]
        
        from inquirer import List, prompt
        questions = [
            List('action',
                message="What would you like to do?",
                choices=choices,
                carousel=True
            ),
        ]
        
        answers = prompt(questions)
        if answers:
            if "Sign Up" in answers['action']:
                self.handle_signup()
            elif "Login" in answers['action']:
                self.handle_login()
            elif "Back" in answers['action']:
                self.handle_guest_browse()  # Go back to course catalog
    
    def preview_course(self, course):
        """Legacy course preview - redirect to enhanced version"""
        self.preview_course_enhanced(course)
    
    def handle_login(self):
        """Handle user login with multiple attempts and recovery options"""
        console.print("\n🔐 [bold]Login to Your Account[/bold]")
        
        max_attempts = 2
        
        for attempt in range(max_attempts):
            if attempt > 0:
                console.print(f"\n[dim]Attempt {attempt + 1} of {max_attempts}[/dim]")
            
            username = Prompt.ask("Username")
            password = Prompt.ask("Password", password=True)
            
            user = self.user_manager.login(username, password)
            if user:
                self.current_user = user
                self.agent.set_user(user['id'])
                type_text(f"Welcome back, {user['username']}! 🎉", style="bold green")
                
                # Show quick stats
                stats = self.user_manager.get_user_stats(user['id'])
                type_text(f"📊 Level {stats['level']} • {stats['total_xp']} XP • {stats['streak_days']} day streak")
                
                time.sleep(1)
                return
            else:
                console.print("\n❌ [bold red]Invalid username or password.[/bold red]")
                
                # If this was the last attempt, offer recovery options
                if attempt == max_attempts - 1:
                    console.print("\n🤔 [bold]Having trouble logging in?[/bold]")
                    
                    choice = Prompt.ask(
                        "What would you like to do?",
                        choices=["reset", "retry", "signup", "back"],
                        default="reset"
                    )
                    
                    if choice == "reset":
                        self.handle_password_reset()
                        return
                    elif choice == "retry":
                        # Give them another chance
                        self.handle_login()
                        return
                    elif choice == "signup":
                        console.print("\n💡 [dim]No problem! Let's create a new account.[/dim]")
                        self.handle_signup()
                        return
                    elif choice == "back":
                        return
                else:
                    time.sleep(1)
    
    def handle_signup(self):
        """Handle user signup"""
        console.print("\n📝 [bold]Create Your Account[/bold]")
        
        username = Prompt.ask("Choose a username")
        email = Prompt.ask("Email address")
        password = Prompt.ask("Password", password=True)
        
        user = self.user_manager.register(username, email, password)
        if user:
            self.current_user = user
            self.agent.set_user(user['id'])
            type_text(f"🎉 Welcome to Boots, {user['username']}!", style="bold green")
            type_text("🎯 You've earned your first 10 XP for joining!", style="cyan")
            
            # Award welcome achievement
            self.gamification.check_achievement(user['id'], 'welcome')
            
            time.sleep(2)
        else:
            console.print("\n❌ [bold red]Username already exists. Please try another.[/bold red]")
            time.sleep(1)
    
    def handle_password_reset(self):
        """Handle password reset request"""
        console.print("\n🔑 [bold]Password Reset[/bold]")
        console.print("Enter your username or email to reset your password.")
        
        username_or_email = Prompt.ask("Username or Email")
        
        # Check if user exists
        if self.user_manager.user_exists(username_or_email):
            console.print("\n✅ [bold green]Password reset initiated![/bold green]")
            console.print("📧 [dim]In a real app, we'd send you a reset link by email.[/dim]")
            console.print("🔧 [dim]For this demo, please create a new account or contact support.[/dim]")
        else:
            console.print("\n❌ [bold red]User not found.[/bold red]")
            console.print("💡 [dim]Double-check your username/email or try creating a new account.[/dim]")
        
        # Offer to create new account
        if Confirm.ask("\nWould you like to create a new account instead?"):
            self.handle_signup()
        else:
            time.sleep(2)
    
    def show_dashboard(self):
        """Show user dashboard"""
        if not self.current_user:
            return
        
        stats = self.user_manager.get_user_stats(self.current_user['id'])
        recent_activity = self.user_manager.get_recent_activity(self.current_user['id'])
        
        # Create dashboard layout
        layout = Layout()
        layout.split_column(
            Layout(name="header", size=8),
            Layout(name="body")
        )
        layout["body"].split_row(
            Layout(name="left"),
            Layout(name="right")
        )
        
        # Header with user info
        header_table = Table.grid(padding=1)
        header_table.add_column(style="bold cyan")
        header_table.add_column(style="bold white")
        header_table.add_column(style="bold green")
        
        header_table.add_row(
            f"👤 {self.current_user['username']}",
            f"🎯 Level {stats['level']} ({stats['total_xp']} XP)",
            f"🔥 {stats['streak_days']} day streak"
        )
        
        progress_bar = self.get_level_progress_bar(stats['total_xp'])
        
        layout["header"].update(Panel(
            f"{header_table}\n{progress_bar}",
            title="🏠 Dashboard",
            border_style="cyan"
        ))
        
        # Left side - Stats
        stats_table = Table(title="📊 Your Stats")
        stats_table.add_column("Metric", style="cyan")
        stats_table.add_column("Value", style="white")
        
        stats_table.add_row("Total Lessons Completed", str(stats['lessons_completed']))
        stats_table.add_row("Exercises Solved", str(stats['exercises_completed']))
        stats_table.add_row("Courses In Progress", str(stats['courses_in_progress']))
        stats_table.add_row("Total Time Spent", f"{stats['total_time_spent']} min")
        
        layout["left"].update(Panel(stats_table, border_style="green"))
        
        # Right side - Recent Activity
        activity_table = Table(title="📈 Recent Activity")
        activity_table.add_column("Date", style="dim")
        activity_table.add_column("Activity", style="white")
        activity_table.add_column("XP", style="green")
        
        for activity in recent_activity[:5]:
            activity_table.add_row(
                activity['date'],
                activity['description'],
                f"+{activity['xp']}"
            )
        
        layout["right"].update(Panel(activity_table, border_style="blue"))
        
        console.print(layout)
        console.print()
        
        Prompt.ask("Press Enter to continue")
    
    def get_level_progress_bar(self, total_xp):
        """Generate a progress bar for level progression"""
        current_level = total_xp // 100 + 1
        xp_in_level = total_xp % 100
        progress = xp_in_level / 100
        
        bar_length = 30
        filled = int(progress * bar_length)
        bar = "█" * filled + "░" * (bar_length - filled)
        
        return f"Level {current_level}: [{bar}] {xp_in_level}/100 XP"
    
    def show_about(self):
        """Show about information"""
        about_text = """
[bold cyan]TypeQuest[/bold cyan]

🎯 [bold]Mission:[/bold] Learn backend development through interactive coding challenges

🚀 [bold]Features:[/bold]
  • Interactive SQL exercises with real datasets
  • Gamified learning with XP, achievements, and streaks
  • Progress tracking across multiple courses
  • SQL playground for free practice
  • Leaderboards and daily challenges

📚 [bold]Current Courses:[/bold]
  • SQL Mastery (10 chapters, 50+ exercises)
  • Coming soon: Python, Go, Java, TypeScript

💡 [bold]Inspired by:[/bold] boot.dev and similar platforms
🛠️  [bold]Built with:[/bold] Python, Rich, SQLite
        """
        
        console.print(Panel(about_text, title="ℹ️  About Boots", border_style="blue"))
        Prompt.ask("\nPress Enter to continue")
    
    def run(self):
        """Main CLI loop"""
        try:
            while True:
                console.clear()
                self.display_banner()
                
                choice = self.show_main_menu()
                
                if not choice or "Exit" in choice:
                    console.print("\n👋 Thanks for using Boots! Happy coding! 🚀")
                    break
                elif "Browse Courses" in choice:
                    self.handle_guest_browse()
                elif "SQL Playground" in choice:
                    self.handle_sql_playground()
                elif "Python Playground" in choice:
                    self.handle_python_playground()
                elif "AI Learning Assistant" in choice:
                    self.handle_ai_assistant()
                elif "Login" in choice:
                    self.handle_login()
                elif "Sign Up" in choice:
                    self.handle_signup()
                elif "About" in choice:
                    self.show_about()
                elif "Dashboard" in choice:
                    self.show_dashboard()
                elif "My Courses" in choice:
                    self.handle_my_courses()
                elif "Continue Learning" in choice:
                    self.handle_continue_learning()
                elif "Achievements" in choice:
                    self.handle_achievements()
                elif "Leaderboard" in choice:
                    self.handle_leaderboard()
                elif "Profile" in choice:
                    self.handle_profile()
                elif "Typewriter Settings" in choice:
                    self.handle_typewriter_settings()
                elif "Logout" in choice:
                    self.current_user = None
                    console.print("\n👋 Logged out successfully!")
                    time.sleep(1)
                
        except KeyboardInterrupt:
            console.print("\n\n👋 Thanks for using Boots!")
        except Exception as e:
            console.print(f"\n❌ Error: {e}")
            console.print("Please report this issue on GitHub.")

    def handle_sql_playground(self):
        """Handle SQL playground access"""
        from rich.prompt import Prompt, Confirm
        
        console.print("\n🎮 [bold cyan]SQL Playground[/bold cyan]")
        console.print("Practice your SQL skills with real datasets!\n")
        
        # Show available datasets
        datasets = self.sql_executor.get_available_datasets()
        
        dataset_choices = [f"{d['display_name']} - {d['description']}" for d in datasets]
        
        questions = [
            inquirer.List(
                'dataset',
                message="Choose a dataset to practice with:",
                choices=dataset_choices,
                carousel=True
            )
        ]
        
        answer = inquirer.prompt(questions)
        if not answer:
            return
        
        # Extract dataset name
        selected_index = dataset_choices.index(answer['dataset'])
        dataset_name = datasets[selected_index]['name']
        
        # Show dataset info
        console.clear()
        console.print("\n🎮 [bold cyan]SQL Playground[/bold cyan]\n")
        self.sql_executor.show_dataset_info(dataset_name)
        
        console.print(f"\n💡 [bold]Instructions:[/bold]")
        console.print("• Write SQL queries to explore the data")
        console.print("• Type 'help' for tips")
        console.print("• Type 'info' to see dataset info again")
        console.print("• Type 'datasets' to switch datasets")
        console.print("• Type 'exit' to leave playground\n")
        
        while True:
            try:
                query = Prompt.ask(f"\n[bold cyan]{dataset_name}>[/bold cyan] Enter SQL query")
                
                if query.lower() == 'exit':
                    break
                elif query.lower() == 'help':
                    self.show_sql_help()
                    continue
                elif query.lower() == 'info':
                    self.sql_executor.show_dataset_info(dataset_name)
                    continue
                elif query.lower() == 'datasets':
                    console.print("Available datasets:")
                    for d in datasets:
                        console.print(f"  • {d['name']}: {d['display_name']}")
                    continue
                elif not query.strip():
                    continue
                
                # Execute query
                result = self.sql_executor.execute_query(query, dataset_name, validate=False)
                self.sql_executor.display_query_result(result)
                
                # Award XP for successful queries (if logged in)
                if self.current_user and result['success'] and result['data']:
                    self.user_manager.add_xp(self.current_user['id'], 5)
                    console.print("[dim]+5 XP for successful query![/dim]")
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                console.print(f"❌ Error: {e}")
    
    def show_sql_help(self):
        """Show SQL help"""
        help_text = """
[bold cyan]SQL Quick Reference:[/bold cyan]

[bold]Basic Queries:[/bold]
• SELECT * FROM table_name;
• SELECT column1, column2 FROM table_name;
• SELECT * FROM table_name WHERE condition;

[bold]Filtering:[/bold]
• WHERE column = 'value'
• WHERE column > 100
• WHERE column BETWEEN 10 AND 50
• WHERE column IN ('val1', 'val2')

[bold]Sorting & Limiting:[/bold]
• ORDER BY column ASC/DESC
• LIMIT 10

[bold]Aggregation:[/bold]
• COUNT(*), SUM(column), AVG(column)
• GROUP BY column
• HAVING COUNT(*) > 5

[bold]Joins:[/bold]
• INNER JOIN table2 ON table1.id = table2.id
• LEFT JOIN table2 ON table1.id = table2.id
        """
        console.print(Panel(help_text, title="💡 SQL Help", border_style="yellow"))
    
    def handle_my_courses(self):
        """Handle my courses view with beautiful interface"""
        if not self.current_user:
            return
        
        console.clear()
        console.print("\n🎯 [bold cyan]My Backend Mastery Progress[/bold cyan]")
        console.print(f"[dim]Welcome back, {self.current_user['username']}! Track your progress through the 3-stage backend journey[/dim]\n")
        
        # Get available courses
        tracks = self.course_manager.get_tracks()
        track = tracks[0]  # Backend Development track
        
        # Create beautiful course dashboard with stage progression
        dashboard_table = Table(title="🚀 Your 3-Stage Backend Journey Progress", show_header=True, header_style="bold cyan", border_style="cyan")
        dashboard_table.add_column("Stage", style="bold cyan", width=8, justify="center")  # Stage indicator
        dashboard_table.add_column("Course", style="bold white", min_width=30)
        dashboard_table.add_column("Progress", style="green", width=20, justify="center")
        dashboard_table.add_column("Level", style="yellow", width=12, justify="center")
        dashboard_table.add_column("Status", style="bright_blue", width=15, justify="center")
        
        course_data = []
        stage_indicators = [
            "[bold green]1[/bold green]\n[dim]START[/dim]",
            "[bold cyan]2[/bold cyan]\n[dim]BUILD[/dim]", 
            "[bold magenta]3[/bold magenta]\n[dim]MASTER[/dim]"
        ]
        
        for i, course_slug in enumerate(track['courses']):
            course = self.course_manager.get_course(course_slug)
            if course:
                # Get user progress for this course
                try:
                    progress = self.course_manager.get_user_progress(self.current_user['id'], course_slug)
                    stats = self.course_manager.get_course_stats(self.current_user['id'], course_slug)
                    
                    # Calculate progress
                    total_lessons = len(course['lessons'])
                    completed_lessons = stats.get('completed_lessons', 0) if stats else 0
                    progress_percent = (completed_lessons / total_lessons * 100) if total_lessons > 0 else 0
                    
                    # Create progress bar
                    progress_bar = self.create_progress_bar(progress_percent, width=15)
                    
                    # Determine status
                    if completed_lessons == 0:
                        status = "🆕 Not Started"
                    elif progress_percent == 100:
                        status = "✅ Complete"
                    else:
                        status = "🔥 In Progress"
                    
                except:
                    progress_bar = self.create_progress_bar(0, width=15)
                    status = "🆕 Not Started"
                
                # Add to table with stage indicator
                stage_indicator = stage_indicators[i] if i < len(stage_indicators) else f"[bold]{i+1}[/bold]"
                dashboard_table.add_row(
                    stage_indicator,
                    f"{course.get('icon', '📚')} {course['name']}",
                    progress_bar,
                    course['difficulty'].title(),
                    status
                )
                
                course_data.append(course)
        
        console.print(dashboard_table)
        
        # Enhanced course selection with stage progression
        console.print(f"\n🚀 [bold]Continue Your Backend Journey[/bold]")
        console.print(f"[dim]Select a stage to continue learning or review your progress[/dim]\n")
        
        course_choices = []
        stage_prefixes = ["🎯 Stage 1:", "🛠️ Stage 2:", "🚀 Stage 3:"]
        
        for i, course in enumerate(course_data):
            icon = course.get('icon', '📚')
            stage_prefix = stage_prefixes[i] if i < len(stage_prefixes) else f"📚 Stage {i+1}:"
            choice_text = f"{stage_prefix} {icon} {course['name']}"
            course_choices.append(choice_text)
        
        course_choices.append("🔙 Back to Dashboard")
        
        from inquirer import List, prompt
        questions = [
            List('course',
                message="🎯 Select your learning stage",
                choices=course_choices,
                carousel=True
            ),
        ]
        
        answers = prompt(questions)
        if answers and "Back to Dashboard" not in answers['course']:
            # Find selected course by matching the name
            selected_course = None
            for course in course_data:
                if course['name'] in answers['course']:
                    selected_course = course
                    break
            
            if selected_course:
                self.show_course_detail(selected_course)
    
    def show_course_detail(self, course):
        """Show detailed course view with progress tracking"""
        console.clear()
        
        # Course header
        icon = course.get('icon', '📚')
        console.print(f"\n{icon} [bold blue]{course['name']}[/bold blue]")
        console.print(f"[dim]{course['description']}[/dim]\n")
        
        # Get user progress
        try:
            progress = self.course_manager.get_user_progress(self.current_user['id'], course['slug'])
            stats = self.course_manager.get_course_stats(self.current_user['id'], course['slug'])
            
            # Progress overview
            total_lessons = len(course['lessons'])
            completed_lessons = stats.get('completed_lessons', 0) if stats else 0
            progress_percent = (completed_lessons / total_lessons * 100) if total_lessons > 0 else 0
            
            progress_bar = self.create_progress_bar(progress_percent, width=30)
            
            # Course stats table
            stats_table = Table.grid(padding=1)
            stats_table.add_column(style="cyan")
            stats_table.add_column(style="white")
            
            stats_table.add_row("📊 Progress:", f"{progress_bar} {completed_lessons}/{total_lessons} lessons")
            stats_table.add_row("⏱️  Duration:", f"{course['estimated_hours']} hours total")
            stats_table.add_row("📈 Level:", course['difficulty'].title())
            stats_table.add_row("🎯 XP Earned:", f"{stats.get('total_xp_earned', 0)}" if stats else "0")
            
            console.print(stats_table)
            
        except Exception as e:
            console.print(f"[dim]No progress data available[/dim]")
        
        # Show course highlights if available
        if 'highlights' in course:
            console.print("\n✨ [bold]What You'll Master:[/bold]")
            for highlight in course['highlights']:
                console.print(f"  🎯 {highlight}")
        
        # Enhanced lesson selection
        console.print(f"\n📋 [bold]Course Lessons[/bold] ({len(course['lessons'])} total)")
        
        from inquirer import List, prompt
        lesson_choices = [
            "🚀 Start Next Lesson",
            "📖 Browse All Lessons", 
            "🔙 Back to My Courses"
        ]
        
        questions = [
            List('action',
                message="What would you like to do?",
                choices=lesson_choices,
                carousel=True
            ),
        ]
        
        answers = prompt(questions)
        if answers:
            if "Start Next" in answers['action']:
                # Find next incomplete lesson
                for lesson in course['lessons']:
                    if not lesson.get('completed', False):  # Simple check for now
                        self.start_lesson(course['slug'], lesson['slug'])
                        break
            elif "Browse All" in answers['action']:
                self.browse_course_lessons(course)
            elif "Back" in answers['action']:
                self.handle_my_courses()
    
    def browse_course_lessons(self, course):
        """Browse all lessons in a course with enhanced interface"""
        console.clear()
        
        icon = course.get('icon', '📚')
        console.print(f"\n{icon} [bold blue]{course['name']} - Lesson Browser[/bold blue]\n")
        
        # Create lessons table
        lessons_table = Table(title=f"📚 All Lessons ({len(course['lessons'])} total)")
        lessons_table.add_column("Ch.", style="dim cyan", width=5)
        lessons_table.add_column("Lesson Title", style="white", min_width=40)
        lessons_table.add_column("Status", style="green", width=10, justify="center")
        lessons_table.add_column("XP", style="yellow", width=8, justify="center")
        lessons_table.add_column("Duration", style="dim", width=10, justify="center")
        
        for lesson in course['lessons']:
            # Status logic (simplified for now)
            if lesson.get('is_free', False):
                status = "🆓 Free"
            else:
                status = "🔒 Locked"
            
            lessons_table.add_row(
                f"Ch.{lesson.get('chapter', '?')}",
                lesson['title'],
                status,
                f"{lesson.get('xp_reward', 0)}",
                f"{lesson.get('estimated_time', 30)}m"
            )
        
        console.print(lessons_table)
        
        console.print(f"\n💡 [dim]Select a lesson to start learning[/dim]")
        
        # Lesson selection
        lesson_choices = []
        for lesson in course['lessons']:
            choice_text = f"📖 {lesson['title']}"
            lesson_choices.append(choice_text)
        
        lesson_choices.append("🔙 Back to Course Details")
        
        from inquirer import List, prompt
        questions = [
            List('lesson',
                message="Choose a lesson to start",
                choices=lesson_choices,
                carousel=True
            ),
        ]
        
        answers = prompt(questions)
        if answers and "Back to Course Details" not in answers['lesson']:
            # Find selected lesson
            for i, lesson in enumerate(course['lessons']):
                if lesson['title'] in answers['lesson']:
                    self.start_lesson(course['slug'], lesson['slug'])
                    break
        else:
            self.show_course_detail(course)
    
    def create_progress_bar(self, percentage, width=20):
        """Create a visual progress bar"""
        filled = int((percentage / 100) * width)
        bar = "█" * filled + "░" * (width - filled)
        return f"[{bar}] {percentage:.0f}%"
    
    def handle_continue_learning(self):
        """Handle continue learning"""
        if not self.current_user:
            return
        
        # Find next lesson to continue
        next_lesson = self.course_manager.get_next_lesson(self.current_user['id'], 'learn-sql')
        
        if next_lesson:
            console.print(f"\n🎯 [bold]Continuing with:[/bold] Chapter {next_lesson['chapter']} - {next_lesson['title']}")
            time.sleep(1)
            self.start_lesson('learn-sql', next_lesson['slug'])
        else:
            console.print("\n🎉 [bold green]All lessons completed![/bold green]")
            console.print("🆕 [dim]New courses coming soon...[/dim]")
            Prompt.ask("\nPress Enter to continue")
    
    def start_lesson(self, course_slug, lesson_slug):
        """Start a specific lesson with micro-lesson support"""
        lesson = self.course_manager.get_lesson(course_slug, lesson_slug)
        if not lesson:
            console.print("❌ Lesson not found")
            return
        
        console.clear()
        
        # Display lesson header with typewriter effect
        type_text(f"Chapter {lesson['chapter']}: {lesson['title']}", style="bold blue")
        console.print()
        
        # Check if this lesson has micro-lessons (new format)
        if 'micro_lessons' in lesson:
            self._handle_micro_lesson_format(lesson)
        else:
            # Fallback to traditional format
            self._handle_traditional_lesson_format(lesson)
    
    def _handle_micro_lesson_format(self, lesson):
        """Handle lessons with micro-lesson structure"""
        # Show intro content
        if 'content' in lesson:
            type_lesson(lesson['content'])
            console.print("\n" + "="*60)
            console.print("📚 [bold cyan]Interactive Micro-Lessons[/bold cyan]")
            console.print("Each topic includes immediate practice and concept checks!")
            console.print("="*60 + "\n")
        
        # Process each micro-lesson
        for i, micro_lesson in enumerate(lesson['micro_lessons'], 1):
            console.print(f"\n🎯 [bold]Topic {i}: {micro_lesson['topic']}[/bold]")
            console.print("-" * 50)
            
            # Show teaching content
            type_lesson(micro_lesson['teaching_content'])
            
            # Immediate practice
            if 'immediate_practice' in micro_lesson:
                console.print("\n🏃‍♂️ [bold green]Quick Practice Time![/bold green]")
                self._handle_immediate_practice(micro_lesson['immediate_practice'])
            
            # Comprehension quiz
            if 'comprehension_quiz' in micro_lesson:
                console.print("\n🧠 [bold yellow]Concept Check![/bold yellow]")
                self._handle_comprehension_quiz(micro_lesson['comprehension_quiz'])
            
            # Continue prompt between topics
            if i < len(lesson['micro_lessons']):
                console.print(f"\n✅ [green]Topic {i} Complete![/green]")
                if not Confirm.ask(f"Ready for Topic {i+1}?", default=True):
                    console.print("📖 Feel free to review anytime!")
                    break
        
        # Final exercises if any
        if 'final_exercises' in lesson:
            console.print("\n🎯 [bold]Comprehensive Practice[/bold]")
            for exercise in lesson['final_exercises']:
                self._handle_comprehensive_exercise(exercise)
    
    def _handle_traditional_lesson_format(self, lesson):
        """Handle traditional lesson format (fallback)"""
        # Display lesson content with full typewriter effect
        type_lesson(lesson['content'])
        
        # Handle exercises
        exercises = lesson.get('exercises', [])
        
        if exercises:
            console.print("🎯 [bold]Practice Exercises:[/bold]\n")
            
            for i, exercise in enumerate(exercises, 1):
                console.print(f"📝 [bold]Exercise {i}: {exercise['title']}[/bold]")
                
                if exercise['type'] == 'quiz':
                    if self.handle_quiz_exercise(exercise):
                        if self.current_user:
                            self.user_manager.add_xp(self.current_user['id'], exercise['xp_reward'])
                            console.print(f"[green]+{exercise['xp_reward']} XP earned![/green]")
                elif exercise['type'] == 'sql':
                    if self.handle_sql_exercise(exercise):
                        if self.current_user:
                            self.user_manager.add_xp(self.current_user['id'], exercise['xp_reward'])
                            console.print(f"[green]+{exercise['xp_reward']} XP earned![/green]")
                elif exercise['type'] == 'python':
                    if self.handle_python_exercise(exercise):
                        if self.current_user:
                            self.user_manager.add_xp(self.current_user['id'], exercise['xp_reward'])
                            console.print(f"[green]+{exercise['xp_reward']} XP earned![/green]")
                
                console.print()
        
        # Mark lesson as completed
        if self.current_user:
            self.course_manager.mark_lesson_complete(
                self.current_user['id'], 
                course_slug, 
                lesson_slug,
                time_spent=5  # Placeholder time
            )
            
            # Award lesson XP
            self.user_manager.add_xp(self.current_user['id'], lesson['xp_reward'])
            console.print(f"✅ [bold green]Lesson completed! +{lesson['xp_reward']} XP[/bold green]")
            
            # Check for achievements
            self.gamification.check_achievement(self.current_user['id'], 'first_lesson')
            self.gamification.check_all_achievements(self.current_user['id'])
        
        # Show control hints
        console.print("\n[dim]💡 Typewriter Controls:[/dim]")
        console.print("[dim]  • Press Ctrl+C during typing to skip to end[/dim]") 
        console.print("[dim]  • Access ⌨️ Typewriter Settings from main menu to change speed[/dim]")
        console.print("[dim]  • Set instant mode for faster learning[/dim]")
        
        Prompt.ask("\nPress Enter to continue")
    
    def _handle_immediate_practice(self, practice_data):
        """Handle immediate practice after teaching content with enhanced formatting"""
        from django_content.microlearning_config import get_microlearning_settings, get_visual_settings, get_encouragement_message
        
        # Get settings for this practice type
        practice_type = practice_data.get('practice_type', 'default')
        settings = get_microlearning_settings(practice_type)
        visual = get_visual_settings()
        
        # Practice session header
        console.print()
        console.print(visual['separators']['section_separator'])
        console.print(f"🏃‍♂️ [bold green]Quick Practice Time![/bold green]")
        console.print(f"📝 [cyan]{practice_data['title']}[/cyan]")
        console.print(f"💡 {practice_data['instructions']}")
        console.print(visual['separators']['section_separator'])
        console.print()
        
        total_tasks = len(practice_data.get('tasks', []))
        
        for i, task in enumerate(practice_data.get('tasks', []), 1):
            # Task header with visual separation
            console.print(f"🎯 [bold white]Task {i} of {total_tasks}[/bold white]")
            console.print(visual['separators']['task_separator'])
            console.print(f"📋 [bold]{task['task']}[/bold]")
            console.print()
            
            # Multi-attempt handling
            max_attempts = settings['max_attempts_per_task']
            task_completed = False
            
            for attempt in range(1, max_attempts + 1):
                # Create input box visual
                console.print("┌─ SQL Query Input " + "─" * (visual['input_prompt']['box_width'] - 20) + "┐")
                console.print("│")
                
                # Get user's SQL query with enhanced prompt
                user_query = Prompt.ask(f"│ 💭 [bright_blue]Enter your SQL query (Attempt {attempt}/{max_attempts})[/bright_blue]").strip()
                console.print("│")
                console.print("└" + "─" * visual['input_prompt']['box_width'] + "┘")
                console.print()
                
                # Validation logic
                expected = task['expected_query'].strip().lower()
                user_lower = user_query.strip().lower()
                
                # Check if answer is correct (flexible matching)
                is_correct = self._validate_sql_query(user_lower, expected, task)
                
                if is_correct:
                    # Success feedback
                    encouragement = get_encouragement_message(attempt, True)
                    console.print(f"✅ [bold green]{encouragement}[/bold green]")
                    
                    if settings.get('show_detailed_explanations', True):
                        console.print(f"💡 [dim]Explanation: {task.get('explanation', task.get('hint', ''))}[/dim]")
                    
                    task_completed = True
                    break
                    
                else:
                    # Incorrect feedback
                    encouragement = get_encouragement_message(attempt, False)
                    console.print(f"❌ [bold red]{encouragement}[/bold red]")
                    
                    # Show hint based on settings
                    if attempt >= settings['show_hint_after_attempt'] and attempt < max_attempts:
                        console.print(f"💡 [yellow]Hint: {task.get('hint', '')}[/yellow]")
                    
                    # Show solution if this was the last attempt
                    if attempt >= settings['show_solution_after_attempts']:
                        console.print()
                        console.print("┌─ Expected Solution " + "─" * 35 + "┐")
                        console.print(f"│ 📋 [cyan]{task['expected_query']}[/cyan]")
                        console.print("└" + "─" * 52 + "┘")
                        
                        if task.get('explanation'):
                            console.print(f"📖 [dim]Explanation: {task['explanation']}[/dim]")
                
                console.print()
            
            # Task completion status
            if task_completed:
                console.print("🎉 [bold green]Task Complete![/bold green]")
            else:
                if settings.get('allow_skip_task', True):
                    console.print("⚠️ [yellow]Task not completed - moving to next task[/yellow]")
                
            # Visual separator between tasks
            if i < total_tasks:
                console.print()
                console.print(visual['separators']['mini_separator'])
                console.print()
        
        # Practice session summary
        console.print()
        console.print(visual['separators']['section_separator'])
        console.print("✅ [bold cyan]Practice Session Complete![/bold cyan]")
        console.print(visual['separators']['section_separator'])
        console.print()
    
    def _validate_sql_query(self, user_query, expected_query, task):
        """Enhanced SQL query validation with flexible matching"""
        # Remove extra whitespace and normalize
        user_clean = ' '.join(user_query.split())
        expected_clean = ' '.join(expected_query.split())
        
        # Direct match
        if user_clean == expected_clean:
            return True
            
        # Flexible matching - check if key components are present
        expected_parts = expected_clean.split()
        user_parts = user_clean.split()
        
        # Check for essential SQL keywords
        essential_keywords = ['select', 'from']
        for keyword in essential_keywords:
            if keyword in expected_parts and keyword not in user_parts:
                return False
        
        # Check for table names and column names
        if 'from' in expected_parts and 'from' in user_parts:
            expected_table_idx = expected_parts.index('from') + 1 if expected_parts.index('from') + 1 < len(expected_parts) else -1
            user_table_idx = user_parts.index('from') + 1 if user_parts.index('from') + 1 < len(user_parts) else -1
            
            if expected_table_idx > 0 and user_table_idx > 0:
                expected_table = expected_parts[expected_table_idx].rstrip(';')
                user_table = user_parts[user_table_idx].rstrip(';')
                if expected_table == user_table:
                    return True
        
        # Partial credit for close matches (configurable)
        task_settings = task.get('settings', {})
        if task_settings.get('partial_credit', False):
            # Check if most keywords match
            matching_words = sum(1 for word in user_parts if word in expected_parts)
            match_ratio = matching_words / len(expected_parts) if expected_parts else 0
            return match_ratio >= 0.8  # 80% match threshold
        
        return False
    
    def _handle_comprehension_quiz(self, quiz_data):
        """Handle multiple choice comprehension quiz"""
        console.print(f"🧠 [yellow]{quiz_data['title']}[/yellow]")
        console.print()
        
        score = 0
        total = len(quiz_data['questions'])
        
        for i, question in enumerate(quiz_data['questions'], 1):
            console.print(f"❓ [bold]Question {i}:[/bold] {question['question']}")
            
            # Display options
            for option in question['options']:
                console.print(f"   {option}")
            
            # Get user answer
            user_answer = Prompt.ask("Your answer (A, B, C, or D)").upper().strip()
            
            if user_answer == question['correct']:
                console.print("✅ [green]Correct![/green]")
                score += 1
            else:
                console.print(f"❌ [red]Incorrect. The correct answer is {question['correct']}[/red]")
            
            console.print(f"💡 [dim]{question['explanation']}[/dim]")
            console.print()
        
        # Show final score
        percentage = (score / total) * 100
        if percentage >= 80:
            console.print(f"🎉 [green]Excellent! {score}/{total} correct ({percentage:.0f}%)[/green]")
        elif percentage >= 60:
            console.print(f"👍 [yellow]Good job! {score}/{total} correct ({percentage:.0f}%)[/yellow]")
        else:
            console.print(f"📖 [red]Keep studying! {score}/{total} correct ({percentage:.0f}%)[/red]")
            console.print("[dim]💡 Consider reviewing the concept before moving on[/dim]")
    
    def _handle_comprehensive_exercise(self, exercise_data):
        """Handle final comprehensive exercises"""
        console.print(f"🎯 [bold cyan]{exercise_data['title']}[/bold cyan]")
        console.print(f"📝 {exercise_data['instructions']}")
        console.print()
        
        for i, task in enumerate(exercise_data.get('tasks', []), 1):
            console.print(f"🎯 [bold]Challenge {i}:[/bold] {task['task']}")
            
            if 'requirements' in task:
                console.print("📋 [yellow]Requirements:[/yellow]")
                for req in task['requirements']:
                    console.print(f"  • {req}")
            
            # Get user's query
            user_query = Prompt.ask("Enter your SQL query").strip()
            
            # Show expected solution
            console.print(f"\n📋 [cyan]Expected Solution:[/cyan]")
            console.print(f"{task['expected_query']}")
            console.print(f"💡 [dim]{task.get('hint', '')}[/dim]")
            console.print()
    
    def handle_quiz_exercise(self, exercise):
        """Handle quiz exercise"""
        console.print(f"❓ {exercise['question']}")
        console.print()
        
        options = exercise['options']
        for i, option in enumerate(options, 1):
            console.print(f"  {i}. {option}")
        
        console.print()
        
        while True:
            try:
                answer = Prompt.ask("Your answer (1-4)")
                choice = int(answer) - 1
                
                if 0 <= choice < len(options):
                    if choice == exercise['correct']:
                        console.print("✅ [bold green]Correct![/bold green]")
                        return True
                    else:
                        console.print(f"❌ [bold red]Incorrect.[/bold red] The correct answer was: {options[exercise['correct']]}")
                        return False
                else:
                    console.print("Please enter a number between 1 and 4")
                    
            except ValueError:
                console.print("Please enter a valid number")
    
    def handle_sql_exercise(self, exercise):
        """Handle SQL exercise"""
        console.print(f"💻 [bold]{exercise['instructions']}[/bold]")
        
        dataset_name = exercise.get('dataset', 'company_db')
        
        # Show relevant dataset info briefly
        console.print(f"\n📊 [dim]Dataset: {dataset_name}[/dim]")
        
        hints_used = 0
        max_attempts = 3
        
        for attempt in range(max_attempts):
            console.print(f"\n[dim]Attempt {attempt + 1}/{max_attempts}[/dim]")
            
            query = Prompt.ask("[bold cyan]SQL>[/bold cyan] Enter your query")
            
            if query.lower() == 'hint':
                if hints_used < len(exercise.get('hints', [])):
                    console.print(f"💡 [yellow]Hint {hints_used + 1}:[/yellow] {exercise['hints'][hints_used]}")
                    hints_used += 1
                    continue
                else:
                    console.print("💡 [dim]No more hints available[/dim]")
                    continue
            
            # Execute user query
            user_result = self.sql_executor.execute_query(query, dataset_name)
            
            if not user_result['success']:
                console.print(f"❌ [red]Error:[/red] {user_result['error']}")
                continue
            
            # Execute expected query
            expected_result = self.sql_executor.execute_query(exercise['solution'], dataset_name)
            
            # Compare results
            comparison = self.sql_executor.compare_results(user_result, expected_result)
            
            if comparison['correct']:
                console.print(f"✅ [bold green]{comparison['message']}[/bold green]")
                
                # Show results
                self.sql_executor.display_query_result(user_result)
                
                # Record submission
                if self.current_user:
                    self.record_exercise_submission(
                        exercise['id'], 
                        query, 
                        True, 
                        exercise['xp_reward'],
                        hints_used
                    )
                
                return True
            else:
                console.print(f"❌ [yellow]{comparison['message']}[/yellow]")
                
                # Show user's results for debugging
                if user_result['data']:
                    console.print("\n🔍 [dim]Your results:[/dim]")
                    self.sql_executor.display_query_result(user_result)
        
        # Show solution after max attempts
        console.print(f"\n💡 [bold]Solution:[/bold]")
        console.print(f"[dim]{exercise['solution']}[/dim]")
        
        expected_result = self.sql_executor.execute_query(exercise['solution'], dataset_name)
        console.print("\n✅ [bold]Expected results:[/bold]")
        self.sql_executor.display_query_result(expected_result)
        
        return False
    
    def record_exercise_submission(self, exercise_id, code, is_correct, xp_earned, hints_used):
        """Record exercise submission"""
        if not self.current_user:
            return
        
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO exercise_submissions 
            (user_id, exercise_id, code, is_correct, xp_earned, hints_used)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            self.current_user['id'],
            exercise_id,
            code,
            is_correct,
            xp_earned,
            hints_used
        ))
        
        conn.commit()
        conn.close()
    
    def handle_achievements(self):
        """Handle achievements view"""
        if not self.current_user:
            console.print("👤 Please log in to view achievements")
            time.sleep(1)
            return
        
        self.gamification.display_achievements(self.current_user['id'])
        Prompt.ask("\nPress Enter to continue")
    
    def handle_leaderboard(self):
        """Handle leaderboard view"""
        console.print("\n📈 [bold cyan]Leaderboard[/bold cyan]")
        
        # Choose leaderboard type
        choices = [
            "🏆 All-Time Leaderboard",
            "📅 Weekly Leaderboard", 
            "🔙 Back to Main Menu"
        ]
        
        questions = [
            inquirer.List(
                'board_type',
                message="Which leaderboard would you like to see?",
                choices=choices,
                carousel=True
            )
        ]
        
        answer = inquirer.prompt(questions)
        if not answer or "Back" in answer['board_type']:
            return
        
        board_type = 'all_time' if 'All-Time' in answer['board_type'] else 'weekly'
        
        console.clear()
        self.gamification.display_leaderboard(board_type)
        
        # Show daily challenge
        if self.current_user:
            console.print("\n🎯 [bold]Daily Challenge[/bold]")
            challenge = self.gamification.get_daily_challenge(self.current_user['id'])
            
            if not challenge['status']['completed']:
                console.print(f"📝 {challenge['title']}: {challenge['description']}")
                console.print(f"💰 Bonus XP: +{challenge['bonus_xp']}")
                
                if Confirm.ask("Would you like to attempt today's challenge?"):
                    self.handle_daily_challenge(challenge)
            else:
                console.print("✅ [green]Today's challenge completed![/green]")
        
        Prompt.ask("\nPress Enter to continue")
    
    def handle_daily_challenge(self, challenge):
        """Handle daily challenge"""
        console.print(f"\n🎯 [bold cyan]Daily Challenge[/bold cyan]")
        console.print(f"📝 {challenge['description']}")
        console.print(f"💾 Dataset: {challenge['dataset']}")
        console.print(f"💰 Bonus XP: +{challenge['bonus_xp']}")
        
        # Let user attempt the challenge
        query = Prompt.ask("\n[bold cyan]SQL>[/bold cyan] Enter your solution")
        
        user_result = self.sql_executor.execute_query(query, challenge['dataset'])
        expected_result = self.sql_executor.execute_query(challenge['query'], challenge['dataset'])
        
        comparison = self.sql_executor.compare_results(user_result, expected_result)
        
        if comparison['correct']:
            console.print("🎉 [bold green]Challenge completed successfully![/bold green]")
            self.gamification.complete_daily_challenge(self.current_user['id'])
        else:
            console.print(f"❌ [yellow]{comparison['message']}[/yellow]")
            console.print(f"\n💡 [bold]Solution:[/bold] {challenge['query']}")
    
    def handle_profile(self):
        """Handle profile management"""
        if not self.current_user:
            return
        
        profile = self.user_manager.get_user_profile(self.current_user['id'])
        
        console.print("\n👤 [bold cyan]Your Profile[/bold cyan]\n")
        
        # Profile info table
        profile_table = Table(title=f"Profile: {profile['username']}")
        profile_table.add_column("Field", style="cyan")
        profile_table.add_column("Value", style="white")
        
        profile_table.add_row("Username", profile['username'])
        profile_table.add_row("Email", profile['email'])
        profile_table.add_row("Level", str(profile['level']))
        profile_table.add_row("Total XP", str(profile['total_xp']))
        profile_table.add_row("Current Streak", f"{profile['streak_days']} days")
        profile_table.add_row("Member Since", datetime.fromisoformat(profile['member_since']).strftime('%Y-%m-%d'))
        profile_table.add_row("Bio", profile['bio'] if profile['bio'] else "[dim]No bio set[/dim]")
        profile_table.add_row("GitHub", profile['github_username'] if profile['github_username'] else "[dim]Not set[/dim]")
        profile_table.add_row("LinkedIn", profile['linkedin_url'] if profile['linkedin_url'] else "[dim]Not set[/dim]")
        
        console.print(profile_table)
        
        # Profile actions
        choices = [
            "✏️  Edit Bio",
            "🐙 Update GitHub Username", 
            "💼 Update LinkedIn URL",
            "🔙 Back to Main Menu"
        ]
        
        questions = [
            inquirer.List(
                'action',
                message="What would you like to do?",
                choices=choices,
                carousel=True
            )
        ]
        
        answer = inquirer.prompt(questions)
        if not answer or "Back" in answer['action']:
            return
        
        action = answer['action']
        
        if "Bio" in action:
            new_bio = Prompt.ask("Enter your bio (or press Enter to keep current)", default=profile['bio'])
            self.user_manager.update_profile(self.current_user['id'], bio=new_bio)
            console.print("✅ Bio updated!")
            
        elif "GitHub" in action:
            new_github = Prompt.ask("Enter GitHub username (or press Enter to keep current)", default=profile['github_username'])
            self.user_manager.update_profile(self.current_user['id'], github_username=new_github)
            console.print("✅ GitHub username updated!")
            
        elif "LinkedIn" in action:
            new_linkedin = Prompt.ask("Enter LinkedIn URL (or press Enter to keep current)", default=profile['linkedin_url'])
            self.user_manager.update_profile(self.current_user['id'], linkedin_url=new_linkedin)
            console.print("✅ LinkedIn URL updated!")
        
        time.sleep(1)
    
    def handle_typewriter_settings(self):
        """Handle typewriter display settings"""
        console.print("\n⌨️  [bold cyan]Typewriter Display Settings[/bold cyan]\n")
        
        show_typewriter_settings()
        
        # Settings menu
        choices = [
            "🐌 Set Speed: Slow",
            "🚶 Set Speed: Normal", 
            "🏃 Set Speed: Fast",
            "🚀 Set Speed: Instant",
            "🔄 Toggle Typewriter On/Off",
            "🔙 Back to Main Menu"
        ]
        
        questions = [
            inquirer.List(
                'setting',
                message="Choose a setting to modify:",
                choices=choices,
                carousel=True
            )
        ]
        
        answer = inquirer.prompt(questions)
        if not answer or "Back" in answer['setting']:
            return
        
        setting = answer['setting']
        
        if "Slow" in setting:
            set_typewriter_speed('slow')
        elif "Normal" in setting:
            set_typewriter_speed('normal')
        elif "Fast" in setting:
            set_typewriter_speed('fast')
        elif "Instant" in setting:
            set_typewriter_speed('instant')
        elif "Toggle" in setting:
            toggle_typewriter()
        
        time.sleep(2)
    
    def handle_python_playground(self):
        """Handle Python playground access"""
        self.python_executor.run_decorator_playground()
    
    def handle_python_exercise(self, exercise):
        """Handle Python exercise execution"""
        console.print(f"🐍 [bold]{exercise['instructions']}[/bold]")
        
        # Show starter code if available
        if exercise.get('starter_code'):
            console.print("\n📝 [bold]Starter Code:[/bold]")
            from rich.syntax import Syntax
            syntax = Syntax(exercise['starter_code'], "python", theme="monokai", line_numbers=True)
            console.print(syntax)
        
        hints_used = 0
        max_attempts = 3
        
        for attempt in range(max_attempts):
            console.print(f"\n[dim]Attempt {attempt + 1}/{max_attempts}[/dim]")
            
            # Get code input
            console.print("\n💻 [bold]Enter your Python code:[/bold]")
            console.print("[dim]Type your code below. When finished, type 'RUN' on a new line:[/dim]")
            
            code_lines = []
            while True:
                from rich.prompt import Prompt
                line = Prompt.ask("", default="")
                if line.strip().upper() == 'RUN':
                    break
                elif line.strip().lower() == 'hint':
                    if hints_used < len(exercise.get('hints', [])):
                        console.print(f"💡 [yellow]Hint {hints_used + 1}:[/yellow] {exercise['hints'][hints_used]}")
                        hints_used += 1
                        continue
                    else:
                        console.print("💡 [dim]No more hints available[/dim]")
                        continue
                elif line.strip().lower() == 'starter':
                    # Show starter code again
                    if exercise.get('starter_code'):
                        syntax = Syntax(exercise['starter_code'], "python", theme="monokai", line_numbers=True)
                        console.print(syntax)
                    continue
                
                code_lines.append(line)
            
            user_code = '\n'.join(code_lines)
            
            if not user_code.strip():
                console.print("❌ No code provided. Try again.")
                continue
            
            # Validate the solution
            validation = self.python_executor.validate_decorator_exercise(user_code, exercise)
            
            if validation['success']:
                console.print(f"✅ [bold green]{validation['message']}[/bold green]")
                
                # Show test results if available
                if validation.get('test_results'):
                    self.python_executor.display_test_results(validation)
                
                # Record submission
                if self.current_user:
                    self.record_exercise_submission(
                        exercise['id'],
                        user_code,
                        True,
                        exercise['xp_reward'],
                        hints_used
                    )
                
                return True
            else:
                console.print(f"❌ [yellow]{validation['message']}[/yellow]")
                
                # Show test results for debugging
                if validation.get('test_results'):
                    self.python_executor.display_test_results(validation)
                
                # Show specific hints for this exercise
                exercise_hints = self.python_executor.provide_decorator_hints(exercise['id'])
                console.print(f"\n💡 [bold]Hints for this exercise:[/bold]")
                for hint in exercise_hints[:2]:  # Show first 2 hints
                    console.print(f"   • {hint}")
        
        # Show solution after max attempts
        console.print(f"\n💡 [bold]Solution:[/bold]")
        if exercise.get('solution'):
            syntax = Syntax(exercise['solution'], "python", theme="monokai", line_numbers=True)
            console.print(syntax)
        
        return False
    
    def handle_ai_assistant(self):
        """Handle AI Learning Assistant conversation"""
        console.print("\n🤖 [bold cyan]AI Learning Assistant[/bold cyan]")
        console.print("Your personal coding tutor powered by intelligent tools!\n")
        
        # Show introduction
        console.print("💡 [bold]I can help you with:[/bold]")
        console.print("• 📚 Finding courses and lessons")
        console.print("• 📊 Tracking your progress and next steps")
        console.print("• 💻 Executing SQL and Python code")
        console.print("• 🏆 Checking achievements and leaderboards")
        console.print("• 🔍 Searching for specific topics")
        console.print("• 🎯 Daily challenges and recommendations")
        console.print()
        
        console.print("🔧 [bold]Example commands:[/bold]")
        console.print("• 'What courses are available?'")
        console.print("• 'How's my progress?'")
        console.print("• 'Run SQL: SELECT * FROM employees LIMIT 5'")
        console.print("• 'Search: decorators'")
        console.print("• 'What should I learn next?'")
        console.print("• 'Show leaderboard'")
        console.print()
        
        console.print("[dim]Type 'exit' to return to main menu, 'help' for more commands[/dim]\n")
        
        # Main conversation loop
        while True:
            try:
                from rich.prompt import Prompt
                from rich.markdown import Markdown
                
                user_input = Prompt.ask("\n[bold cyan]You>[/bold cyan]", default="")
                
                if user_input.lower() in ['exit', 'quit', 'bye']:
                    console.print("\n👋 [green]Thanks for chatting! Happy learning![/green]")
                    break
                
                if not user_input.strip():
                    continue
                
                # Show thinking indicator
                with console.status("[bold green]🤔 Thinking..."):
                    response = self.agent.process_message(user_input)
                
                # Display response
                console.print(f"\n🤖 [bold cyan]Assistant>[/bold cyan]")
                
                # Format response based on type
                if response['type'] == 'tool_response':
                    # Show which tools were used
                    if response.get('tools_used'):
                        tools_used = ', '.join(response['tools_used'])
                        console.print(f"[dim]🔧 Using tools: {tools_used}[/dim]\n")
                    
                    # Display the formatted response
                    try:
                        markdown = Markdown(response['message'])
                        console.print(markdown)
                    except:
                        console.print(response['message'])
                else:
                    # General response
                    console.print(response['message'])
                
                # Show success/error indicator
                if response['type'] == 'tool_response':
                    if response['success']:
                        console.print("\n[green]✅ Request completed successfully[/green]")
                    else:
                        console.print("\n[red]❌ Some operations had errors[/red]")
                
            except KeyboardInterrupt:
                console.print("\n\n👋 [green]Thanks for chatting![/green]")
                break
            except Exception as e:
                console.print(f"\n❌ [red]Error: {e}[/red]")
                console.print("[dim]Please try again or type 'exit' to return to main menu[/dim]")
        
        # Show conversation summary
        summary = self.agent.get_conversation_summary()
        if "No conversation history" not in summary:
            console.print(f"\n📋 {summary}")
        
        Prompt.ask("\nPress Enter to continue")


if __name__ == "__main__":
    app = BootsCLI()
    app.run()