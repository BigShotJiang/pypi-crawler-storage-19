#!/usr/bin/env python3
"""
Quick test script to verify the package structure is correct
"""

import sys
import os
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

def test_imports():
    """Test all major imports work"""
    
    try:
        import typequest
        print(f"✅ Main package imports: version {boots.__version__}")
    except Exception as e:
        print(f"❌ Failed to import boots: {e}")
        return False
    
    # Test individual modules (without dependencies for now)
    modules_to_test = [
        'boots.config',
        'boots.session', 
        'boots.utils.platform'
    ]
    
    for module in modules_to_test:
        try:
            __import__(module)
            print(f"✅ {module} imports successfully")
        except Exception as e:
            print(f"❌ Failed to import {module}: {e}")
    
    return True

def test_package_structure():
    """Test package structure is correct"""
    
    package_dir = Path(__file__).parent / "boots"
    
    required_files = [
        "__init__.py",
        "__main__.py", 
        "cli.py",
        "config.py",
        "main.py",
        "auth.py",
        "sync.py",
        "subscription.py",
        "session.py",
        "utils/__init__.py",
        "utils/platform.py",
        "utils/typewriter.py",
        "utils/updater.py"
    ]
    
    for file_path in required_files:
        full_path = package_dir / file_path
        if full_path.exists():
            print(f"✅ {file_path} exists")
        else:
            print(f"❌ Missing required file: {file_path}")
    
    return True

def test_entry_points():
    """Test entry point configuration"""
    
    try:
        from typequest.cli import main
        print("✅ Entry point boots.cli:main is accessible")
    except Exception as e:
        print(f"❌ Entry point test failed: {e}")
        return False
    
    return True

def test_configuration_files():
    """Test configuration files exist"""
    
    config_files = [
        "pyproject.toml",
        "setup.py", 
        "README.md",
        "LICENSE",
        "requirements.txt",
        ".env.example"
    ]
    
    base_dir = Path(__file__).parent
    
    for config_file in config_files:
        file_path = base_dir / config_file
        if file_path.exists():
            print(f"✅ {config_file} exists")
        else:
            print(f"❌ Missing configuration file: {config_file}")
    
    return True

if __name__ == "__main__":
    print("🧪 Testing Boots CLI Package Structure\n")
    
    print("📁 Testing package structure...")
    test_package_structure()
    
    print("\n📦 Testing imports...")
    test_imports()
    
    print("\n🚀 Testing entry points...")
    test_entry_points()
    
    print("\n⚙️  Testing configuration files...")
    test_configuration_files()
    
    print("\n✅ Package structure test completed!")
    print("\n📝 Next steps:")
    print("1. Install dependencies: pip install -r requirements.txt")
    print("2. Set up environment: cp .env.example .env && edit .env") 
    print("3. Install in development mode: pip install -e .")
    print("4. Test CLI: boots --help")
    print("5. Configure Auth0 and Stripe credentials")
    print("6. Build package: python -m build")
    print("7. Upload to PyPI: twine upload dist/*")