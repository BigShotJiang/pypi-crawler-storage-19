# 🚀 Boots Learning Platform

A comprehensive coding education platform inspired by boot.dev, built with Django REST Framework. Learn SQL, Python, Go, Java, and more through interactive exercises, gamification, and real-time code execution.

## ✨ Features

### 🎓 Core Learning Features
- **Structured Learning Paths**: Backend development tracks starting with SQL
- **Interactive Exercises**: Write and execute code directly in the browser
- **SQL Playground**: Practice SQL queries with real datasets
- **Progressive Difficulty**: From beginner to advanced concepts
- **Code Validation**: Real-time feedback on your solutions

### 🎮 Gamification System
- **XP System**: Earn experience points for completing lessons and exercises
- **Achievements**: Unlock achievements for milestones
- **Leaderboards**: Weekly, monthly, and all-time rankings
- **Badges**: Collect badges for mastering skills
- **Daily Challenges**: New coding challenge every day
- **Learning Streaks**: Track consecutive days of learning

### 📊 Sample Datasets
- **Company Database**: Employees, departments, projects
- **E-commerce Database**: Products, customers, orders, reviews
- **School Database**: Students, courses, enrollments

### 👤 User Features
- **Progress Tracking**: Monitor your learning journey
- **User Profiles**: Customize your profile with bio, GitHub, LinkedIn
- **Learning Goals**: Set and track personal learning objectives
- **Dashboard**: Overview of stats, achievements, and recent activity

## 🛠️ Tech Stack

- **Backend**: Django 5.0, Django REST Framework
- **Database**: SQLite (development), PostgreSQL (production)
- **Authentication**: JWT with djangorestframework-simplejwt
- **Code Execution**: Sandboxed SQL execution, Python/JS/Go/Java support
- **API**: RESTful API with comprehensive endpoints

## 📦 Installation

### Prerequisites
- Python 3.10+
- pip
- virtualenv (recommended)

### Setup Instructions

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/boots.git
cd boots
```

2. **Create virtual environment**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\\Scripts\\activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Run migrations**
```bash
python manage.py makemigrations
python manage.py migrate
```

5. **Populate initial data**
```bash
python manage.py populate_data
```

6. **Create superuser (optional)**
```bash
python manage.py createsuperuser
```

7. **Run the server**
```bash
python manage.py runserver
```

The API will be available at `http://localhost:8000/api/`

## 🔑 API Endpoints

### Authentication
- `POST /api/auth/login/` - Login with username/password
- `POST /api/auth/refresh/` - Refresh JWT token
- `POST /api/users/register/` - Register new user

### Courses
- `GET /api/courses/tracks/` - List all learning tracks
- `GET /api/courses/courses/` - List all courses
- `GET /api/courses/courses/{slug}/` - Course details
- `POST /api/courses/courses/{slug}/enroll/` - Enroll in course
- `GET /api/courses/lessons/{id}/` - Lesson details
- `POST /api/courses/lessons/{id}/complete/` - Mark lesson complete

### Exercises
- `GET /api/courses/exercises/{id}/` - Exercise details
- `POST /api/courses/exercises/{id}/submit/` - Submit solution
- `GET /api/courses/exercises/{id}/hint/` - Get hint

### SQL Playground
- `POST /api/courses/sql-playground/execute/` - Execute SQL query
- `GET /api/courses/sql-playground/datasets/` - List available datasets

### User Profile
- `GET /api/users/profile/` - Get user profile
- `PATCH /api/users/update_profile/` - Update profile
- `GET /api/users/dashboard/` - User dashboard with stats

### Gamification
- `GET /api/gamification/achievements/` - List achievements
- `GET /api/gamification/achievements/my_achievements/` - User's achievements
- `GET /api/gamification/leaderboards/weekly/` - Weekly leaderboard
- `GET /api/gamification/leaderboards/all_time/` - All-time leaderboard
- `GET /api/gamification/daily-challenges/today/` - Today's challenge
- `POST /api/gamification/daily-challenges/complete/` - Complete daily challenge

## 🎯 Demo Credentials

- **Username**: demo
- **Password**: demo123

## 📚 Course Structure

### SQL Course (10 Chapters)
1. **Introduction to Databases** - Database concepts and terminology
2. **SELECT Statements** - Basic queries and WHERE clauses
3. **Filtering and Sorting** - AND/OR/NOT, ORDER BY, LIMIT
4. **JOIN Operations** - INNER, LEFT, RIGHT, FULL OUTER joins
5. **Aggregate Functions** - COUNT, SUM, AVG, GROUP BY, HAVING
6. **Subqueries** - Nested queries and EXISTS operator
7. **Data Manipulation** - INSERT, UPDATE, DELETE
8. **Database Design** - CREATE TABLE, data types, constraints
9. **Advanced Queries** - Window functions, CTEs, CASE statements
10. **Performance Optimization** - Indexes, query optimization

## 🚀 Future Enhancements

- [ ] Additional programming languages (Go, Java, TypeScript)
- [ ] Video content integration
- [ ] Live coding sessions
- [ ] Peer code reviews
- [ ] Project-based learning
- [ ] Certification system
- [ ] Mobile app
- [ ] AI-powered code review
- [ ] Collaborative learning features
- [ ] Integration with GitHub

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Inspired by [boot.dev](https://boot.dev)
- Built with Django REST Framework
- SQL datasets for educational purposes

## 📧 Contact

For questions or suggestions, please open an issue or contact the maintainers.

---

**Happy Learning! 🎓**