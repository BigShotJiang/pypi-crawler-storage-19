"""Context gathering for wtf."""
