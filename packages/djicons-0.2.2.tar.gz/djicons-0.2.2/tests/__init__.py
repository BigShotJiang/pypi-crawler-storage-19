"""Tests for djicons."""
