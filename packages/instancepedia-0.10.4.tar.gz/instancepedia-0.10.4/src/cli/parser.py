"""CLI argument parser"""

import argparse
from src.cli import commands
from src.config.settings import Settings
from src.models.region import is_valid_region, AWS_REGIONS


def region_type(value: str) -> str:
    """Argparse type validator for AWS region codes."""
    if is_valid_region(value):
        return value
    # Find similar regions for helpful error
    similar = [r for r in AWS_REGIONS.keys() if value in r or r in value]
    hint = f" Did you mean: {', '.join(similar[:3])}?" if similar else ""
    raise argparse.ArgumentTypeError(
        f"Invalid region '{value}'.{hint}\n"
        "Use 'instancepedia regions' to see available regions."
    )


def add_common_args(parser: argparse.ArgumentParser):
    """Add common arguments to a parser"""
    parser.add_argument(
        "--region",
        type=region_type,
        default=None,
        help="AWS region (default: from config or us-east-1)"
    )
    parser.add_argument(
        "--profile",
        type=str,
        default=None,
        help="AWS profile name"
    )
    parser.add_argument(
        "--format",
        type=str,
        choices=["table", "json", "csv"],
        default="table",
        help="Output format (default: table)"
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output file path (default: stdout)"
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress progress messages"
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug output"
    )


def create_parser() -> argparse.ArgumentParser:
    """Create the main argument parser"""
    settings = Settings()
    
    parser = argparse.ArgumentParser(
        description="Instancepedia - EC2 Instance Type Browser (CLI Mode)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # List all instance types
  instancepedia list --region us-east-1

  # Show details for a specific instance
  instancepedia show t3.micro --region us-east-1

  # Search for instances
  instancepedia search m5 --region us-east-1

  # Get pricing information
  instancepedia pricing t3.micro --region us-east-1 --format json

  # List available regions
  instancepedia regions

  # Compare two instances
  instancepedia compare t3.micro t3.small --region us-east-1

  # Filter free tier instances
  instancepedia list --region us-east-1 --free-tier-only

  # Output to file
  instancepedia list --region us-east-1 --format json --output instances.json
        """
    )
    
    # Global arguments
    parser.add_argument(
        "--tui",
        action="store_true",
        help="Run in TUI mode (interactive terminal UI)"
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug output"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands", metavar="COMMAND")
    
    # List command
    list_parser = subparsers.add_parser("list", help="List instance types")
    add_common_args(list_parser)
    list_parser.add_argument(
        "--search",
        type=str,
        default=None,
        help="Search filter (instance type name)"
    )
    list_parser.add_argument(
        "--free-tier-only",
        action="store_true",
        help="Show only free tier eligible instances"
    )
    list_parser.add_argument(
        "--family",
        type=str,
        default=None,
        help="Filter by instance family (e.g., t3, m5)"
    )
    list_parser.add_argument(
        "--storage-type",
        type=str,
        choices=["ebs-only", "instance-store"],
        default=None,
        help="Filter by storage type: ebs-only or instance-store"
    )
    list_parser.add_argument(
        "--nvme",
        type=str,
        choices=["required", "supported", "unsupported"],
        default=None,
        help="Filter by NVMe support: required, supported, or unsupported"
    )
    list_parser.add_argument(
        "--processor-family",
        type=str,
        choices=["intel", "amd", "graviton"],
        default=None,
        help="Filter by processor family: intel, amd, or graviton"
    )
    list_parser.add_argument(
        "--network-performance",
        type=str,
        choices=["low", "moderate", "high", "very-high"],
        default=None,
        help="Filter by network performance tier"
    )
    list_parser.add_argument(
        "--min-price",
        type=float,
        default=None,
        help="Minimum hourly price in USD"
    )
    list_parser.add_argument(
        "--max-price",
        type=float,
        default=None,
        help="Maximum hourly price in USD"
    )
    list_parser.add_argument(
        "--include-pricing",
        action="store_true",
        help="Include pricing information (slower)"
    )
    list_parser.set_defaults(func=commands.cmd_list)
    
    # Show command
    show_parser = subparsers.add_parser("show", help="Show instance type details")
    add_common_args(show_parser)
    show_parser.add_argument(
        "instance_type",
        type=str,
        help="Instance type (e.g., t3.micro)"
    )
    show_parser.add_argument(
        "--include-pricing",
        action="store_true",
        help="Include pricing information"
    )
    show_parser.set_defaults(func=commands.cmd_show)
    
    # Search command (alias for list with search)
    search_parser = subparsers.add_parser("search", help="Search instance types")
    add_common_args(search_parser)
    search_parser.add_argument(
        "term",
        type=str,
        help="Search term"
    )
    search_parser.add_argument(
        "--free-tier-only",
        action="store_true",
        help="Show only free tier eligible instances"
    )
    search_parser.add_argument(
        "--family",
        type=str,
        default=None,
        help="Filter by instance family (e.g., t3, m5)"
    )
    search_parser.add_argument(
        "--storage-type",
        type=str,
        choices=["ebs-only", "instance-store"],
        default=None,
        help="Filter by storage type: ebs-only or instance-store"
    )
    search_parser.add_argument(
        "--nvme",
        type=str,
        choices=["required", "supported", "unsupported"],
        default=None,
        help="Filter by NVMe support: required, supported, or unsupported"
    )
    search_parser.add_argument(
        "--processor-family",
        type=str,
        choices=["intel", "amd", "graviton"],
        default=None,
        help="Filter by processor family: intel, amd, or graviton"
    )
    search_parser.add_argument(
        "--network-performance",
        type=str,
        choices=["low", "moderate", "high", "very-high"],
        default=None,
        help="Filter by network performance tier"
    )
    search_parser.add_argument(
        "--min-price",
        type=float,
        default=None,
        help="Minimum hourly price in USD"
    )
    search_parser.add_argument(
        "--max-price",
        type=float,
        default=None,
        help="Maximum hourly price in USD"
    )
    search_parser.add_argument(
        "--include-pricing",
        action="store_true",
        help="Include pricing information (slower)"
    )
    # Override the search term to be used as --search
    def search_wrapper(args):
        args.search = args.term
        return commands.cmd_list(args)
    search_parser.set_defaults(func=search_wrapper)
    
    # Pricing command
    pricing_parser = subparsers.add_parser("pricing", help="Get pricing information")
    add_common_args(pricing_parser)
    pricing_parser.add_argument(
        "instance_type",
        type=str,
        help="Instance type (e.g., t3.micro)"
    )
    pricing_parser.set_defaults(func=commands.cmd_pricing)
    
    # Regions command
    regions_parser = subparsers.add_parser("regions", help="List available regions")
    add_common_args(regions_parser)
    regions_parser.set_defaults(func=commands.cmd_regions)
    
    # Compare command
    compare_parser = subparsers.add_parser("compare", help="Compare two instance types")
    add_common_args(compare_parser)
    compare_parser.add_argument(
        "instance_type1",
        type=str,
        help="First instance type (e.g., t3.micro)"
    )
    compare_parser.add_argument(
        "instance_type2",
        type=str,
        help="Second instance type (e.g., t3.small)"
    )
    compare_parser.add_argument(
        "--include-pricing",
        action="store_true",
        help="Include pricing information"
    )
    compare_parser.set_defaults(func=commands.cmd_compare)

    # Cost estimate command
    cost_parser = subparsers.add_parser("cost-estimate", help="Calculate cost estimates for an instance type")
    add_common_args(cost_parser)
    cost_parser.add_argument(
        "instance_type",
        type=str,
        help="Instance type (e.g., t3.micro)"
    )
    cost_parser.add_argument(
        "--hours-per-month",
        type=float,
        default=730,
        help="Hours per month (default: 730 for full month)"
    )
    cost_parser.add_argument(
        "--months",
        type=int,
        default=12,
        help="Number of months (default: 12)"
    )
    cost_parser.add_argument(
        "--pricing-model",
        type=str,
        choices=["on-demand", "spot", "savings-1yr", "savings-3yr"],
        default="on-demand",
        help="Pricing model to use (default: on-demand)"
    )
    cost_parser.set_defaults(func=commands.cmd_cost_estimate)

    # Compare regions command
    compare_regions_parser = subparsers.add_parser("compare-regions", help="Compare pricing across regions")
    compare_regions_parser.add_argument(
        "instance_type",
        type=str,
        help="Instance type (e.g., t3.micro)"
    )
    compare_regions_parser.add_argument(
        "--regions",
        type=str,
        required=True,
        help="Comma-separated list of regions (e.g., us-east-1,us-west-2,eu-west-1)"
    )
    compare_regions_parser.add_argument(
        "--format",
        type=str,
        choices=["table", "json", "csv"],
        default="table",
        help="Output format (default: table)"
    )
    compare_regions_parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output file path (default: stdout)"
    )
    compare_regions_parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress progress messages"
    )
    compare_regions_parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug output"
    )
    compare_regions_parser.set_defaults(func=commands.cmd_compare_regions)

    # Compare family command
    compare_family_parser = subparsers.add_parser("compare-family", help="Compare all instances in a family")
    add_common_args(compare_family_parser)
    compare_family_parser.add_argument(
        "family",
        type=str,
        help="Instance family (e.g., t3, m5, c6i)"
    )
    compare_family_parser.add_argument(
        "--include-pricing",
        action="store_true",
        help="Include pricing information"
    )
    compare_family_parser.add_argument(
        "--sort-by",
        type=str,
        choices=["vcpu", "memory", "price", "name"],
        default="name",
        help="Sort instances by (default: name)"
    )
    compare_family_parser.set_defaults(func=commands.cmd_compare_family)

    # Filter presets command
    presets_parser = subparsers.add_parser("presets", help="Manage filter presets")
    presets_subparsers = presets_parser.add_subparsers(dest="presets_command", help="Preset commands")

    # Presets list subcommand
    presets_list_parser = presets_subparsers.add_parser("list", help="List available filter presets")
    presets_list_parser.add_argument(
        "--format",
        type=str,
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)"
    )
    presets_list_parser.set_defaults(func=commands.cmd_presets_list)

    # Presets apply subcommand
    presets_apply_parser = presets_subparsers.add_parser("apply", help="Apply a filter preset")
    add_common_args(presets_apply_parser)
    presets_apply_parser.add_argument(
        "preset_name",
        type=str,
        help="Name of the preset to apply"
    )
    presets_apply_parser.add_argument(
        "--include-pricing",
        action="store_true",
        help="Include pricing information"
    )
    presets_apply_parser.set_defaults(func=commands.cmd_presets_apply)

    # Presets save subcommand
    presets_save_parser = presets_subparsers.add_parser("save", help="Save a custom filter preset")
    presets_save_parser.add_argument(
        "preset_name",
        type=str,
        help="Name for the preset"
    )
    presets_save_parser.add_argument(
        "--description",
        type=str,
        default=None,
        help="Description of the preset"
    )
    presets_save_parser.add_argument(
        "--min-vcpu",
        type=int,
        default=None,
        help="Minimum vCPU count"
    )
    presets_save_parser.add_argument(
        "--max-vcpu",
        type=int,
        default=None,
        help="Maximum vCPU count"
    )
    presets_save_parser.add_argument(
        "--min-memory",
        type=float,
        default=None,
        help="Minimum memory in GB"
    )
    presets_save_parser.add_argument(
        "--max-memory",
        type=float,
        default=None,
        help="Maximum memory in GB"
    )
    presets_save_parser.add_argument(
        "--has-gpu",
        action="store_true",
        default=None,
        help="Require GPU"
    )
    presets_save_parser.add_argument(
        "--no-gpu",
        dest="has_gpu",
        action="store_false",
        help="Exclude GPU instances"
    )
    presets_save_parser.add_argument(
        "--current-generation",
        action="store_true",
        default=False,
        help="Current generation only"
    )
    presets_save_parser.add_argument(
        "--burstable",
        action="store_true",
        default=False,
        help="Burstable instances only"
    )
    presets_save_parser.add_argument(
        "--free-tier",
        action="store_true",
        default=False,
        help="Free tier eligible only"
    )
    presets_save_parser.add_argument(
        "--architecture",
        type=str,
        choices=["x86_64", "arm64"],
        default=None,
        help="Architecture filter"
    )
    presets_save_parser.add_argument(
        "--instance-families",
        type=str,
        default=None,
        help="Comma-separated instance families (e.g., t3,m5,c6i)"
    )
    presets_save_parser.add_argument(
        "--processor-family",
        type=str,
        choices=["intel", "amd", "graviton"],
        default=None,
        help="Processor family filter"
    )
    presets_save_parser.add_argument(
        "--network-performance",
        type=str,
        choices=["low", "moderate", "high", "very_high"],
        default=None,
        help="Network performance tier"
    )
    presets_save_parser.add_argument(
        "--storage-type",
        type=str,
        choices=["ebs_only", "has_instance_store"],
        default=None,
        help="Storage type filter"
    )
    presets_save_parser.add_argument(
        "--nvme-support",
        type=str,
        choices=["required", "supported", "unsupported"],
        default=None,
        help="NVMe support filter"
    )
    presets_save_parser.add_argument(
        "--min-price",
        type=float,
        default=None,
        help="Minimum hourly price in USD"
    )
    presets_save_parser.add_argument(
        "--max-price",
        type=float,
        default=None,
        help="Maximum hourly price in USD"
    )
    presets_save_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing preset without confirmation"
    )
    presets_save_parser.add_argument(
        "--format",
        type=str,
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)"
    )
    presets_save_parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress output messages"
    )
    presets_save_parser.set_defaults(func=commands.cmd_presets_save)

    # Presets delete subcommand
    presets_delete_parser = presets_subparsers.add_parser("delete", help="Delete a custom filter preset")
    presets_delete_parser.add_argument(
        "preset_name",
        type=str,
        help="Name of the preset to delete"
    )
    presets_delete_parser.add_argument(
        "--force",
        action="store_true",
        help="Skip confirmation prompt"
    )
    presets_delete_parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress output messages"
    )
    presets_delete_parser.set_defaults(func=commands.cmd_presets_delete)

    # Spot history command
    spot_history_parser = subparsers.add_parser("spot-history", help="Show spot price history and trends")
    add_common_args(spot_history_parser)
    spot_history_parser.add_argument(
        "instance_type",
        type=str,
        help="Instance type (e.g., t3.micro)"
    )
    spot_history_parser.add_argument(
        "--days",
        type=int,
        default=30,
        help="Number of days of history (default: 30)"
    )
    spot_history_parser.set_defaults(func=commands.cmd_spot_history)

    # Optimize command
    optimize_parser = subparsers.add_parser("optimize", help="Get cost optimization recommendations")
    add_common_args(optimize_parser)
    optimize_parser.add_argument(
        "instance_type",
        type=str,
        help="Instance type to analyze (e.g., t3.large)"
    )
    optimize_parser.add_argument(
        "--usage-pattern",
        type=str,
        choices=["standard", "burst", "continuous"],
        default="standard",
        help="Expected usage pattern (default: standard). standard=normal workloads, burst=flexible timing, continuous=24/7 critical"
    )
    optimize_parser.set_defaults(func=commands.cmd_optimize)

    # Cache command
    cache_parser = subparsers.add_parser("cache", help="Manage pricing cache")
    cache_subparsers = cache_parser.add_subparsers(dest="cache_command", help="Cache commands")

    # Cache stats subcommand
    cache_stats_parser = cache_subparsers.add_parser("stats", help="Show cache statistics")
    cache_stats_parser.add_argument(
        "--format",
        type=str,
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)"
    )
    cache_stats_parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug output"
    )
    cache_stats_parser.set_defaults(func=commands.cmd_cache_stats)

    # Cache clear subcommand
    cache_clear_parser = cache_subparsers.add_parser("clear", help="Clear cache entries")
    cache_clear_parser.add_argument(
        "--region",
        type=str,
        default=None,
        help="Clear only entries for this region"
    )
    cache_clear_parser.add_argument(
        "--instance-type",
        type=str,
        default=None,
        help="Clear only entries for this instance type"
    )
    cache_clear_parser.add_argument(
        "--force",
        action="store_true",
        help="Skip confirmation prompt"
    )
    cache_clear_parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress output messages"
    )
    cache_clear_parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug output"
    )
    cache_clear_parser.set_defaults(func=commands.cmd_cache_clear)

    return parser


def parse_args(args=None):
    """Parse command line arguments"""
    parser = create_parser()
    parsed_args = parser.parse_args(args)

    # Set default region if not provided (only for CLI commands with region attribute)
    if parsed_args.command and hasattr(parsed_args, 'region'):
        if not parsed_args.region:
            settings = Settings()
            parsed_args.region = settings.aws_region

    # Set default profile if not provided (only for CLI commands with profile attribute)
    if parsed_args.command and hasattr(parsed_args, 'profile'):
        if not parsed_args.profile:
            settings = Settings()
            parsed_args.profile = settings.aws_profile

    return parsed_args
