---
description: General backend development workflow for planning and execution phases
globs:
  - "**/*.py"
  - "**/*.js"
  - "**/*.ts"
  - "**/requirements.txt"
  - "**/pyproject.toml"
  - "**/package.json"
  - "**/go.mod"
  - "**/*.go"
alwaysApply: false
---

# Backend Development Workflow

Follow these workflows during planning and execution phases for all backend development tasks.

## Planning Mode

### 1. Gain Understanding of the Project

Before making any changes:

- **Review file structure**: Examine the project directory layout to understand organization, patterns, and conventions
- **Read documentation**: Review all `.md` files (README, docs, etc.) to understand project context, architecture, and existing patterns
- **Understand existing code**: Identify current patterns, conventions, and architectural decisions

### 2. Research Libraries and Documentation

Prioritize using existing libraries over writing custom code:

- **Prefer libraries**: Always check if an existing library solves the problem before writing custom code
- **Web search for alternatives**: If the user's request cannot be solved by known libraries, perform a web search to find open-source alternatives
- **Ask for approval**: Always ask the user explicitly if they want to use a discovered library or prefer a different approach
- **Reference library documentation**:
  - Use MCP tools when available to query library documentation
  - Install the library and read library files directly from virtual environment
  - Use web search to find official documentation and examples
  - Reference library code and documentation in context of the user's specific ask

### 3. Formulate Plan

Create a clear, actionable plan:

- **Combine information**: Use project understanding, library research, and industry best practices
- **Minimize changes**: Keep code changes minimal and focused for easier review
- **Document approach**: Clearly outline the steps, libraries to use, and expected outcomes
- **Consider impact**: Assess how changes affect existing code and architecture

## Execution Mode

### 1. Stick to the Plan

Maintain consistency with the agreed-upon plan:

- **Follow the plan**: Always adhere to the created plan unless explicitly asked to change
- **Request approval for changes**: If deviations are needed, ask the user explicitly before proceeding
- **Document deviations**: If changes are approved, update the plan accordingly

### 2. Test-Driven Development

Write tests before implementation:

- **Write tests first**:
  - Start with unit tests, then integration tests
  - Follow library/framework best practices for test structure
  - Reference documentation or ask user for testing guidelines if needed
- **Implement code**: Write code to make tests pass
- **Execute tests**: Run unit tests first, then integration tests
- **Iterate**: Continue writing tests and code until all tests pass
- **Maintain coverage**: Ensure critical paths and edge cases are covered

### 3. Code Formatting and Quality

Maintain code quality standards:

- **Never ignore linter errors**: Address all linter warnings and errors before considering code complete
- **Check editor settings**:
  - Review `.vscode/settings.json` or equivalent editor configuration files
  - Identify formatting rules and conventions
  - Apply consistent formatting across all files
- **Format on completion**: Use editor formatting commands or equivalent CLI tools to format files when done
- **Follow project conventions**: Adhere to existing code style, naming conventions, and patterns

## Best Practices

- **Keep changes focused**: Make minimal, targeted changes that solve the specific problem
- **Maintain consistency**: Follow existing project patterns and conventions
- **Document decisions**: Add comments or documentation for non-obvious choices
- **Review before completion**: Ensure all tests pass, linter is clean, and code follows project standards
