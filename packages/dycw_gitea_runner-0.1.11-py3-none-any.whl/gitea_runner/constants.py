from __future__ import annotations

from utilities.importlib import files
from xdg_base_dirs import xdg_cache_home

GITEA_RUNNER_CACHE = xdg_cache_home() / "gitea-runner"
PATH_GITEA_RUNNER = files(anchor="gitea_runner")
PATH_WAIT_FOR_IT = GITEA_RUNNER_CACHE / "wait-for-it.sh"
URL_WAIT_FOR_IT = "https://raw.githubusercontent.com/vishnubob/wait-for-it/refs/heads/master/wait-for-it.sh"


__all__ = [
    "GITEA_RUNNER_CACHE",
    "PATH_GITEA_RUNNER",
    "PATH_WAIT_FOR_IT",
    "URL_WAIT_FOR_IT",
]
