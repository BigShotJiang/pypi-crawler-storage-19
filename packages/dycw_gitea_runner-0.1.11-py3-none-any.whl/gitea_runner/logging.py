from __future__ import annotations

from logging import getLogger

LOGGER = getLogger("gitea_runner")


__all__ = ["LOGGER"]
