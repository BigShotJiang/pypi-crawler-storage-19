from __future__ import annotations

from click import group
from rich.pretty import pretty_repr
from typed_settings import click_options
from utilities.click import CONTEXT_SETTINGS
from utilities.logging import basic_config
from utilities.os import is_pytest

from gitea_runner.lib import register_against_local, register_against_remote
from gitea_runner.logging import LOGGER
from gitea_runner.settings import LOADER, Settings


@group(**CONTEXT_SETTINGS)
def _main() -> None: ...


@_main.command(name="remote", **CONTEXT_SETTINGS)
@click_options(Settings, [LOADER], show_envvars_in_help=True)
def remote_sub_cmd(settings: Settings, /) -> None:
    if is_pytest():
        return
    basic_config(obj=LOGGER)
    LOGGER.info("Settings = %s", pretty_repr(settings))
    register_against_remote(
        ssh_user=settings.ssh_user,
        ssh_host=settings.ssh_host,
        gitea_container_user=settings.gitea_container_user,
        gitea_container_name=settings.gitea_container_name,
        runner_certificate=settings.runner_certificate,
        runner_capacity=settings.runner_capacity,
        runner_container_name=settings.runner_container_name,
        gitea_host=settings.gitea_host,
        gitea_port=settings.gitea_port,
        runner_instance_name=settings.runner_instance_name,
    )


@_main.command(name="local", **CONTEXT_SETTINGS)
@click_options(Settings, [LOADER], show_envvars_in_help=True)
def local_sub_cmd(settings: Settings, /) -> None:
    if is_pytest():
        return
    basic_config(obj=LOGGER)
    LOGGER.info("Settings = %s", pretty_repr(settings))
    register_against_local(
        gitea_container_user=settings.gitea_container_user,
        gitea_container_name=settings.gitea_container_name,
        runner_certificate=settings.runner_certificate,
        runner_capacity=settings.runner_capacity,
        runner_container_name=settings.runner_container_name,
        gitea_host=settings.gitea_host,
        gitea_port=settings.gitea_port,
        runner_instance_name=settings.runner_instance_name,
    )


if __name__ == "__main__":
    _main()
