"""
CLI for pyPASreporter-PACLIparser.

Parse CyberArk PACLI configuration files and load to DuckDB.

Usage:
    pypasreporter-pacliparser license --input License.xml --db vault.duckdb
    pypasreporter-pacliparser dbparm --input DBParm.ini --db vault.duckdb
    pypasreporter-pacliparser policies --input Policies.xml --db vault.duckdb
    pypasreporter-pacliparser cpm-policies --input ./cpm_ini_policies/ --db vault.duckdb
    pypasreporter-pacliparser all --input ./pacli_exports/ --db vault.duckdb
"""

from __future__ import annotations

import csv
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import click

from . import __version__
from .normalize import clean_column_name


# =============================================================================
# LOGGING SETUP
# =============================================================================

LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
LOG_FORMAT_SIMPLE = "[%(levelname)s] %(message)s"


def setup_logging(
    verbose: bool = False,
    debug: bool = False,
    log_file: Path | None = None,
    quiet: bool = False,
) -> logging.Logger:
    """
    Configure logging for the CLI.

    Args:
        verbose: Enable INFO level logging
        debug: Enable DEBUG level logging
        log_file: Path to log file (creates parent dirs if needed)
        quiet: Suppress console output (log file still works)

    Returns:
        Configured logger for CLI
    """
    # Determine log level
    if debug:
        level = logging.DEBUG
    elif verbose:
        level = logging.INFO
    else:
        level = logging.WARNING

    # Root logger for package
    logger = logging.getLogger("pypasreporter_pacliparser")
    logger.setLevel(logging.DEBUG)  # Capture all, handlers filter
    logger.handlers.clear()  # Reset handlers on repeated calls

    # Console handler (unless quiet)
    if not quiet:
        console = logging.StreamHandler(sys.stderr)
        console.setLevel(level)
        console.setFormatter(logging.Formatter(LOG_FORMAT_SIMPLE))
        logger.addHandler(console)

    # File handler (always DEBUG level if specified)
    if log_file:
        try:
            log_file.parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(log_file, mode="a", encoding="utf-8")
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(logging.Formatter(LOG_FORMAT))
            logger.addHandler(file_handler)
            logger.debug(f"Log file: {log_file}")
        except OSError as e:
            click.echo(f"Warning: Could not create log file {log_file}: {e}", err=True)

    return logger


# Get logger for this module
logger = logging.getLogger("pypasreporter_pacliparser.cli")


# =============================================================================
# ERROR HANDLING
# =============================================================================


class PACLIParserError(Exception):
    """Base exception for PACLI parser errors."""

    pass


class FileNotFoundError_(PACLIParserError):
    """Input file or directory not found."""

    pass


class ParseError(PACLIParserError):
    """Failed to parse input file."""

    pass


class DatabaseError(PACLIParserError):
    """Database operation failed."""

    pass


def handle_error(error: Exception, logger: logging.Logger, quiet: bool = False) -> None:
    """
    Handle and log errors consistently.

    Args:
        error: The exception that occurred
        logger: Logger instance
        quiet: Suppress console output
    """
    error_msg = str(error)

    if isinstance(error, PACLIParserError):
        logger.error(error_msg)
        if not quiet:
            click.echo(f"Error: {error_msg}", err=True)
    else:
        logger.exception(f"Unexpected error: {error_msg}")
        if not quiet:
            click.echo(f"Unexpected error: {error_msg}", err=True)
            click.echo("Use --debug for detailed traceback", err=True)


# =============================================================================
# PATH VALIDATION
# =============================================================================


def validate_input_file(path: Path, description: str = "Input file") -> Path:
    """
    Validate that input file exists and is readable.

    Args:
        path: Path to validate
        description: Human-readable description for error messages

    Returns:
        Resolved absolute path

    Raises:
        FileNotFoundError_: If file doesn't exist or isn't readable
    """
    resolved = path.resolve()

    if not resolved.exists():
        raise FileNotFoundError_(f"{description} not found: {resolved}")

    if not resolved.is_file():
        raise FileNotFoundError_(f"{description} is not a file: {resolved}")

    # Check readable
    try:
        with open(resolved, "rb") as f:
            f.read(1)
    except PermissionError:
        raise FileNotFoundError_(f"{description} is not readable: {resolved}")

    logger.debug(f"Validated input file: {resolved}")
    return resolved


def validate_input_dir(path: Path, description: str = "Input directory") -> Path:
    """
    Validate that input directory exists and is readable.

    Args:
        path: Path to validate
        description: Human-readable description for error messages

    Returns:
        Resolved absolute path

    Raises:
        FileNotFoundError_: If directory doesn't exist
    """
    resolved = path.resolve()

    if not resolved.exists():
        raise FileNotFoundError_(f"{description} not found: {resolved}")

    if not resolved.is_dir():
        raise FileNotFoundError_(f"{description} is not a directory: {resolved}")

    logger.debug(f"Validated input directory: {resolved}")
    return resolved


def ensure_output_path(path: Path, description: str = "Output file") -> Path:
    """
    Ensure output path parent directories exist.

    Args:
        path: Path to prepare
        description: Human-readable description for error messages

    Returns:
        Resolved absolute path

    Raises:
        PACLIParserError: If parent directory cannot be created
    """
    resolved = path.resolve()

    try:
        resolved.parent.mkdir(parents=True, exist_ok=True)
        logger.debug(f"Ensured output path: {resolved}")
        return resolved
    except OSError as e:
        raise PACLIParserError(f"Cannot create directory for {description}: {e}")


# =============================================================================
# DATABASE OPERATIONS
# =============================================================================


def get_db_connection(db_path: Path) -> "duckdb.DuckDBPyConnection":
    """
    Get DuckDB connection with proper error handling.

    Args:
        db_path: Path to DuckDB file

    Returns:
        DuckDB connection

    Raises:
        DatabaseError: If connection fails
    """
    import duckdb

    try:
        db_path = ensure_output_path(db_path, "Database file")
        con = duckdb.connect(str(db_path))
        logger.debug(f"Connected to database: {db_path}")
        return con
    except Exception as e:
        raise DatabaseError(f"Failed to connect to database {db_path}: {e}")


def load_records_to_table(
    con: "duckdb.DuckDBPyConnection",
    records: list[dict[str, Any]],
    table_name: str,
    schema: str,
    source_path: Path | None = None,
) -> int:
    """
    Load records into a DuckDB table.

    Applies:
    - Column name normalization (snake_case)
    - NULL sanitization
    - Metadata columns (_loaded_at, _source_file_modified_at)

    Args:
        con: DuckDB connection
        records: List of dictionaries to load
        table_name: Target table name
        schema: Target schema name
        source_path: Optional source file path for metadata

    Returns:
        Number of rows loaded

    Raises:
        DatabaseError: If loading fails
    """
    if not records:
        logger.warning(f"No records to load for {schema}.{table_name}")
        return 0

    try:
        import pyarrow as pa

        load_timestamp = datetime.now(timezone.utc).isoformat()
        file_modified_at = None
        if source_path and source_path.exists():
            try:
                mtime = source_path.stat().st_mtime
                file_modified_at = datetime.fromtimestamp(mtime, timezone.utc).isoformat()
            except OSError:
                logger.warning(f"Could not get mtime for {source_path}")

        # Normalize records
        NULL_SENTINELS = {"", "NULL", "null", "None"}
        normalized_records: list[dict[str, Any]] = []

        for rec in records:
            normalized: dict[str, Any] = {}
            for key, value in rec.items():
                clean_key = clean_column_name(key)
                if isinstance(value, str) and value.strip() in NULL_SENTINELS:
                    normalized[clean_key] = None
                else:
                    normalized[clean_key] = value
            normalized["_loaded_at"] = load_timestamp
            if file_modified_at:
                normalized["_source_file_modified_at"] = file_modified_at
            normalized_records.append(normalized)

        # Create schema and drop old table
        con.execute(f'CREATE SCHEMA IF NOT EXISTS "{schema}"')
        con.execute(f'DROP TABLE IF EXISTS "{schema}"."{table_name}"')

        # Get all unique keys
        all_keys: set[str] = set()
        for rec in normalized_records:
            all_keys.update(rec.keys())
        sorted_keys = sorted(all_keys)

        # Build arrays for each column
        arrays = {key: [rec.get(key) for rec in normalized_records] for key in sorted_keys}

        # Use PyArrow for efficient bulk insert
        pa_table = pa.table(arrays)
        con.register("_temp_records", pa_table)
        con.execute(f'''
            CREATE TABLE "{schema}"."{table_name}" AS
            SELECT * FROM _temp_records
        ''')
        con.unregister("_temp_records")

        logger.info(f"Loaded {len(normalized_records)} rows to {schema}.{table_name}")
        return len(normalized_records)

    except Exception as e:
        raise DatabaseError(f"Failed to load data to {schema}.{table_name}: {e}")


# =============================================================================
# CSV EXPORT
# =============================================================================


def export_to_csv(records: list[dict[str, Any]], csv_path: Path) -> int:
    """
    Export records to CSV file.

    Args:
        records: List of dictionaries to export
        csv_path: Output CSV path

    Returns:
        Number of rows exported

    Raises:
        PACLIParserError: If export fails
    """
    if not records:
        logger.warning(f"No records to export to {csv_path}")
        return 0

    try:
        csv_path = ensure_output_path(csv_path, "CSV file")

        # Normalize column names for CSV
        normalized_records = []
        for rec in records:
            normalized_records.append({clean_column_name(k): v for k, v in rec.items()})

        # Get all keys in consistent order
        all_keys: set[str] = set()
        for rec in normalized_records:
            all_keys.update(rec.keys())
        fieldnames = sorted(all_keys)

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(normalized_records)

        logger.info(f"Exported {len(normalized_records)} rows to {csv_path}")
        return len(normalized_records)

    except OSError as e:
        raise PACLIParserError(f"Failed to write CSV to {csv_path}: {e}")


# =============================================================================
# COMMON CLI OPTIONS
# =============================================================================


def common_options(func):
    """Decorator for common options across commands."""
    func = click.option(
        "--db",
        "-d",
        type=click.Path(dir_okay=False, path_type=Path),
        help="Path to DuckDB database file. Creates if not exists.",
    )(func)
    func = click.option(
        "--csv-export-path",
        "-c",
        type=click.Path(dir_okay=False, writable=True, path_type=Path),
        help="Export results to CSV file.",
    )(func)
    func = click.option(
        "--schema",
        "-s",
        default="cyberark_pacli",
        show_default=True,
        help="DuckDB schema name.",
    )(func)
    func = click.option(
        "--format",
        "-f",
        type=click.Choice(["wide", "long", "both"]),
        default="wide",
        show_default=True,
        help="Output format: wide (pivoted), long (key-value), or both.",
    )(func)
    return func


def logging_options(func):
    """Decorator for logging options."""
    func = click.option(
        "--verbose",
        "-v",
        is_flag=True,
        help="Enable verbose output (INFO level).",
    )(func)
    func = click.option(
        "--debug",
        is_flag=True,
        help="Enable debug output (DEBUG level).",
    )(func)
    func = click.option(
        "--log-file",
        "-l",
        type=click.Path(dir_okay=False, path_type=Path),
        help="Write logs to file (always DEBUG level).",
    )(func)
    func = click.option(
        "--quiet",
        "-q",
        is_flag=True,
        help="Suppress console output (log file still works).",
    )(func)
    return func


# =============================================================================
# CLI GROUP
# =============================================================================


@click.group()
@click.version_option(version=__version__, prog_name="pypasreporter-pacliparser")
def main():
    """
    Parse CyberArk PACLI configuration files.

    Load DBParm.ini, License.xml, Policies.xml, and CPM policy INI files
    into DuckDB for analysis.

    Examples:

        # Parse a single file
        pypasreporter-pacliparser license -i License.xml -d vault.duckdb

        # Parse all files in a directory
        pypasreporter-pacliparser all -i ./pacli_exports/ -d vault.duckdb

        # With logging to file
        pypasreporter-pacliparser all -i ./exports/ -d vault.duckdb -v --log-file parse.log
    """
    pass


# =============================================================================
# LICENSE COMMAND
# =============================================================================


@main.command()
@click.option(
    "--input",
    "-i",
    "input_path",
    type=click.Path(path_type=Path),
    required=True,
    help="Path to License.xml file.",
)
@click.option(
    "--table-name",
    "-t",
    default="license",
    show_default=True,
    help="Table name in DuckDB.",
)
@common_options
@logging_options
def license(
    input_path: Path,
    table_name: str,
    db: Path | None,
    csv_export_path: Path | None,
    schema: str,
    format: str,
    verbose: bool,
    debug: bool,
    log_file: Path | None,
    quiet: bool,
):
    """Parse License.xml file.

    Extracts license metadata including user type limits, expiration dates,
    and allowed applications.

    Example:
        pypasreporter-pacliparser license -i License.xml -d vault.duckdb -v
    """
    setup_logging(verbose, debug, log_file, quiet)
    logger.info(f"Parsing License.xml: {input_path}")

    try:
        # Validate input
        input_path = validate_input_file(input_path, "License.xml")

        # Import parser (deferred to avoid import errors if deps missing)
        from .parsers import parse_license_xml

        # Parse
        records = parse_license_xml(input_path)

        if not records:
            raise ParseError(f"No data parsed from {input_path}")

        logger.info(f"Parsed {len(records)} items from {input_path.name}")
        if not quiet:
            click.echo(f"✓ Parsed {len(records)} items from {input_path.name}")

        # Load to DuckDB
        if db:
            con = get_db_connection(db)
            try:
                row_count = load_records_to_table(con, records, table_name, schema, input_path)
                if not quiet:
                    click.echo(f"✓ Loaded {row_count} rows to {schema}.{table_name}")
            finally:
                con.close()

        # Export to CSV
        if csv_export_path:
            export_to_csv(records, csv_export_path)
            if not quiet:
                click.echo(f"✓ Exported to {csv_export_path}")

    except PACLIParserError as e:
        handle_error(e, logger, quiet)
        sys.exit(1)
    except Exception as e:
        handle_error(e, logger, quiet)
        sys.exit(2)


# =============================================================================
# DBPARM COMMAND
# =============================================================================


@main.command()
@click.option(
    "--input",
    "-i",
    "input_path",
    type=click.Path(path_type=Path),
    required=True,
    help="Path to DBParm.ini file.",
)
@click.option(
    "--table-name",
    "-t",
    default="dbparm",
    show_default=True,
    help="Table name in DuckDB.",
)
@common_options
@logging_options
def dbparm(
    input_path: Path,
    table_name: str,
    db: Path | None,
    csv_export_path: Path | None,
    schema: str,
    format: str,
    verbose: bool,
    debug: bool,
    log_file: Path | None,
    quiet: bool,
):
    """Parse DBParm.ini file.

    Extracts vault database configuration parameters.

    Example:
        pypasreporter-pacliparser dbparm -i DBParm.ini -d vault.duckdb -v
    """
    setup_logging(verbose, debug, log_file, quiet)
    logger.info(f"Parsing DBParm.ini: {input_path}")

    try:
        # Validate input
        input_path = validate_input_file(input_path, "DBParm.ini")

        # Import parser
        from .parsers import parse_dbparm_ini

        # Parse
        records = parse_dbparm_ini(input_path)

        if not records:
            raise ParseError(f"No data parsed from {input_path}")

        logger.info(f"Parsed {len(records)} items from {input_path.name}")
        if not quiet:
            click.echo(f"✓ Parsed {len(records)} items from {input_path.name}")

        # Load to DuckDB
        if db:
            con = get_db_connection(db)
            try:
                row_count = load_records_to_table(con, records, table_name, schema, input_path)
                if not quiet:
                    click.echo(f"✓ Loaded {row_count} rows to {schema}.{table_name}")
            finally:
                con.close()

        # Export to CSV
        if csv_export_path:
            export_to_csv(records, csv_export_path)
            if not quiet:
                click.echo(f"✓ Exported to {csv_export_path}")

    except PACLIParserError as e:
        handle_error(e, logger, quiet)
        sys.exit(1)
    except Exception as e:
        handle_error(e, logger, quiet)
        sys.exit(2)


# =============================================================================
# POLICIES COMMAND
# =============================================================================


@main.command()
@click.option(
    "--input",
    "-i",
    "input_path",
    type=click.Path(path_type=Path),
    required=True,
    help="Path to Policies.xml file.",
)
@click.option(
    "--table-name",
    "-t",
    default="policies",
    show_default=True,
    help="Table name in DuckDB (for wide format). Long format uses {name}_long.",
)
@common_options
@logging_options
def policies(
    input_path: Path,
    table_name: str,
    db: Path | None,
    csv_export_path: Path | None,
    schema: str,
    format: str,
    verbose: bool,
    debug: bool,
    log_file: Path | None,
    quiet: bool,
):
    """Parse Policies.xml file.

    Extracts platform policy definitions with properties and settings.

    Formats:
      - wide: One row per policy, properties as columns (default)
      - long: Key-value format with policy_id, key, value columns
      - both: Creates both tables

    Example:
        pypasreporter-pacliparser policies -i Policies.xml -d vault.duckdb -f both
    """
    setup_logging(verbose, debug, log_file, quiet)
    logger.info(f"Parsing Policies.xml: {input_path}")

    try:
        # Validate input
        input_path = validate_input_file(input_path, "Policies.xml")

        # Import parsers
        from .parsers import parse_policies_xml, parse_policies_xml_wide

        # Parse based on format
        records_wide = None
        records_long = None

        if format in ("wide", "both"):
            records_wide = parse_policies_xml_wide(input_path)
            logger.debug(f"Parsed {len(records_wide) if records_wide else 0} wide records")

        if format in ("long", "both"):
            records_long = parse_policies_xml(input_path)
            logger.debug(f"Parsed {len(records_long) if records_long else 0} long records")

        # Check we got data
        if format == "wide" and not records_wide:
            raise ParseError(f"No data parsed from {input_path}")
        if format == "long" and not records_long:
            raise ParseError(f"No data parsed from {input_path}")
        if format == "both" and not records_wide and not records_long:
            raise ParseError(f"No data parsed from {input_path}")

        if not quiet:
            if format == "both":
                click.echo(
                    f"✓ Parsed {len(records_wide or [])} policies (wide), "
                    f"{len(records_long or [])} records (long)"
                )
            elif format == "wide":
                click.echo(f"✓ Parsed {len(records_wide or [])} policies from {input_path.name}")
            else:
                click.echo(f"✓ Parsed {len(records_long or [])} records from {input_path.name}")

        # Load to DuckDB
        if db:
            con = get_db_connection(db)
            try:
                if format in ("wide", "both") and records_wide:
                    row_count = load_records_to_table(
                        con, records_wide, table_name, schema, input_path
                    )
                    if not quiet:
                        click.echo(f"✓ Loaded {row_count} rows to {schema}.{table_name}")

                if format in ("long", "both") and records_long:
                    long_table = f"{table_name}_long" if format == "both" else table_name
                    row_count = load_records_to_table(
                        con, records_long, long_table, schema, input_path
                    )
                    if not quiet:
                        click.echo(f"✓ Loaded {row_count} rows to {schema}.{long_table}")
            finally:
                con.close()

        # Export to CSV
        if csv_export_path:
            if format == "both":
                if records_wide:
                    export_to_csv(records_wide, csv_export_path)
                if records_long:
                    long_path = csv_export_path.with_stem(f"{csv_export_path.stem}_long")
                    export_to_csv(records_long, long_path)
                if not quiet:
                    click.echo(f"✓ Exported to {csv_export_path} and {long_path}")
            else:
                records = records_wide if format == "wide" else records_long
                if records:
                    export_to_csv(records, csv_export_path)
                    if not quiet:
                        click.echo(f"✓ Exported to {csv_export_path}")

    except PACLIParserError as e:
        handle_error(e, logger, quiet)
        sys.exit(1)
    except Exception as e:
        handle_error(e, logger, quiet)
        sys.exit(2)


# =============================================================================
# CPM-POLICIES COMMAND
# =============================================================================


@main.command("cpm-policies")
@click.option(
    "--input",
    "-i",
    "input_path",
    type=click.Path(path_type=Path),
    required=True,
    help="Path to directory containing Policy-*.ini files.",
)
@click.option(
    "--table-name",
    "-t",
    default="cpm_policies",
    show_default=True,
    help="Table name in DuckDB (for wide format). Long format uses {name}_long.",
)
@common_options
@logging_options
def cpm_policies(
    input_path: Path,
    table_name: str,
    db: Path | None,
    csv_export_path: Path | None,
    schema: str,
    format: str,
    verbose: bool,
    debug: bool,
    log_file: Path | None,
    quiet: bool,
):
    """Parse CPM policy INI files from a directory.

    Parses all Policy-*.ini files from the specified directory.

    Formats:
      - wide: One row per policy file, all keys as columns (default)
      - long: Key-value format with file_name, section, key, value columns
      - both: Creates both tables

    Example:
        pypasreporter-pacliparser cpm-policies -i ./cpm_ini_policies/ -d vault.duckdb
    """
    setup_logging(verbose, debug, log_file, quiet)
    logger.info(f"Parsing CPM policies from: {input_path}")

    try:
        # Validate input directory
        input_path = validate_input_dir(input_path, "CPM policies directory")

        # Check for INI files
        ini_files = list(input_path.glob("Policy-*.ini"))
        if not ini_files:
            raise FileNotFoundError_(f"No Policy-*.ini files found in {input_path}")
        logger.info(f"Found {len(ini_files)} Policy-*.ini files")

        # Import parsers
        from .parsers import parse_cpm_ini_files, parse_cpm_ini_files_wide

        # Parse based on format
        records_wide = None
        records_long = None

        if format in ("wide", "both"):
            records_wide = parse_cpm_ini_files_wide(input_path)
            logger.debug(f"Parsed {len(records_wide) if records_wide else 0} wide records")

        if format in ("long", "both"):
            records_long = parse_cpm_ini_files(input_path)
            logger.debug(f"Parsed {len(records_long) if records_long else 0} long records")

        # Check we got data
        if format == "wide" and not records_wide:
            raise ParseError(f"No data parsed from {input_path}")
        if format == "long" and not records_long:
            raise ParseError(f"No data parsed from {input_path}")
        if format == "both" and not records_wide and not records_long:
            raise ParseError(f"No data parsed from {input_path}")

        if not quiet:
            if format == "both":
                click.echo(
                    f"✓ Parsed {len(records_wide or [])} policies (wide), "
                    f"{len(records_long or [])} records (long)"
                )
            elif format == "wide":
                click.echo(f"✓ Parsed {len(records_wide or [])} policies from {input_path}")
            else:
                click.echo(f"✓ Parsed {len(records_long or [])} records from {input_path}")

        # Load to DuckDB
        if db:
            con = get_db_connection(db)
            try:
                if format in ("wide", "both") and records_wide:
                    row_count = load_records_to_table(con, records_wide, table_name, schema)
                    if not quiet:
                        click.echo(f"✓ Loaded {row_count} rows to {schema}.{table_name}")

                if format in ("long", "both") and records_long:
                    long_table = f"{table_name}_long" if format == "both" else table_name
                    row_count = load_records_to_table(con, records_long, long_table, schema)
                    if not quiet:
                        click.echo(f"✓ Loaded {row_count} rows to {schema}.{long_table}")
            finally:
                con.close()

        # Export to CSV
        if csv_export_path:
            if format == "both":
                if records_wide:
                    export_to_csv(records_wide, csv_export_path)
                if records_long:
                    long_path = csv_export_path.with_stem(f"{csv_export_path.stem}_long")
                    export_to_csv(records_long, long_path)
                if not quiet:
                    click.echo(f"✓ Exported to {csv_export_path} and {long_path}")
            else:
                records = records_wide if format == "wide" else records_long
                if records:
                    export_to_csv(records, csv_export_path)
                    if not quiet:
                        click.echo(f"✓ Exported to {csv_export_path}")

    except PACLIParserError as e:
        handle_error(e, logger, quiet)
        sys.exit(1)
    except Exception as e:
        handle_error(e, logger, quiet)
        sys.exit(2)


# =============================================================================
# ALL COMMAND (convenience)
# =============================================================================


@main.command()
@click.option(
    "--input",
    "-i",
    "input_path",
    type=click.Path(path_type=Path),
    required=True,
    help="Path to directory containing all PACLI exports.",
)
@click.option(
    "--db",
    "-d",
    type=click.Path(dir_okay=False, path_type=Path),
    required=True,
    help="Path to DuckDB database file.",
)
@click.option(
    "--schema",
    "-s",
    default="cyberark_pacli",
    show_default=True,
    help="DuckDB schema name.",
)
@click.option(
    "--format",
    "-f",
    type=click.Choice(["wide", "long", "both"]),
    default="both",
    show_default=True,
    help="Output format.",
)
@logging_options
def all(
    input_path: Path,
    db: Path,
    schema: str,
    format: str,
    verbose: bool,
    debug: bool,
    log_file: Path | None,
    quiet: bool,
):
    """Parse all PACLI files from a directory.

    Looks for DBParm.ini, License.xml, Policies.xml, and cpm_ini_policies/
    in the specified directory.

    Example:
        pypasreporter-pacliparser all -i ./pacli_exports/ -d vault.duckdb -v

        # With log file
        pypasreporter-pacliparser all -i ./exports/ -d vault.duckdb --log-file parse.log
    """
    setup_logging(verbose, debug, log_file, quiet)
    logger.info(f"Parsing all PACLI files from: {input_path}")

    try:
        # Validate input directory
        input_path = validate_input_dir(input_path, "PACLI exports directory")

        # Import all parsers
        from .parsers import (
            parse_cpm_ini_files,
            parse_cpm_ini_files_wide,
            parse_dbparm_ini,
            parse_license_xml,
            parse_policies_xml,
            parse_policies_xml_wide,
        )

        # Connect to database
        con = get_db_connection(db)

        total_tables = 0
        total_rows = 0
        errors: list[str] = []

        try:
            # DBParm.ini
            dbparm_path = input_path / "DBParm.ini"
            if dbparm_path.exists():
                logger.info(f"Processing {dbparm_path}")
                try:
                    records = parse_dbparm_ini(dbparm_path)
                    if records:
                        rows = load_records_to_table(con, records, "dbparm", schema, dbparm_path)
                        total_tables += 1
                        total_rows += rows
                        if not quiet:
                            click.echo(f"✓ dbparm: {rows} rows")
                except Exception as e:
                    errors.append(f"DBParm.ini: {e}")
                    logger.error(f"Failed to process DBParm.ini: {e}")
            else:
                logger.debug("DBParm.ini not found, skipping")

            # License.xml
            license_path = input_path / "License.xml"
            if license_path.exists():
                logger.info(f"Processing {license_path}")
                try:
                    records = parse_license_xml(license_path)
                    if records:
                        rows = load_records_to_table(con, records, "license", schema, license_path)
                        total_tables += 1
                        total_rows += rows
                        if not quiet:
                            click.echo(f"✓ license: {rows} rows")
                except Exception as e:
                    errors.append(f"License.xml: {e}")
                    logger.error(f"Failed to process License.xml: {e}")
            else:
                logger.debug("License.xml not found, skipping")

            # Policies.xml
            policies_path = input_path / "Policies.xml"
            if policies_path.exists():
                logger.info(f"Processing {policies_path}")
                try:
                    if format in ("wide", "both"):
                        records = parse_policies_xml_wide(policies_path)
                        if records:
                            rows = load_records_to_table(
                                con, records, "policies", schema, policies_path
                            )
                            total_tables += 1
                            total_rows += rows
                            if not quiet:
                                click.echo(f"✓ policies: {rows} rows")

                    if format in ("long", "both"):
                        records = parse_policies_xml(policies_path)
                        if records:
                            rows = load_records_to_table(
                                con, records, "policies_long", schema, policies_path
                            )
                            total_tables += 1
                            total_rows += rows
                            if not quiet:
                                click.echo(f"✓ policies_long: {rows} rows")
                except Exception as e:
                    errors.append(f"Policies.xml: {e}")
                    logger.error(f"Failed to process Policies.xml: {e}")
            else:
                logger.debug("Policies.xml not found, skipping")

            # CPM policies
            cpm_path = input_path / "cpm_ini_policies"
            if cpm_path.exists() and cpm_path.is_dir():
                ini_files = list(cpm_path.glob("Policy-*.ini"))
                if ini_files:
                    logger.info(f"Processing {len(ini_files)} CPM policy files from {cpm_path}")
                    try:
                        if format in ("wide", "both"):
                            records = parse_cpm_ini_files_wide(cpm_path)
                            if records:
                                rows = load_records_to_table(con, records, "cpm_policies", schema)
                                total_tables += 1
                                total_rows += rows
                                if not quiet:
                                    click.echo(f"✓ cpm_policies: {rows} rows")

                        if format in ("long", "both"):
                            records = parse_cpm_ini_files(cpm_path)
                            if records:
                                rows = load_records_to_table(
                                    con, records, "cpm_policies_long", schema
                                )
                                total_tables += 1
                                total_rows += rows
                                if not quiet:
                                    click.echo(f"✓ cpm_policies_long: {rows} rows")
                    except Exception as e:
                        errors.append(f"CPM policies: {e}")
                        logger.error(f"Failed to process CPM policies: {e}")
                else:
                    logger.debug("No Policy-*.ini files found in cpm_ini_policies/")
            else:
                logger.debug("cpm_ini_policies/ not found, skipping")

            # Summary
            if not quiet:
                if errors:
                    click.echo(f"\n⚠ Completed with {len(errors)} error(s):", err=True)
                    for err in errors:
                        click.echo(f"  - {err}", err=True)
                    click.echo(f"\n✓ Loaded {total_tables} tables, {total_rows} total rows to {db}")
                else:
                    click.echo(f"\n✓ Loaded {total_tables} tables, {total_rows} total rows to {db}")

            logger.info(f"Completed: {total_tables} tables, {total_rows} rows, {len(errors)} errors")

            if total_tables == 0:
                raise ParseError(
                    f"No PACLI files found in {input_path}. "
                    "Expected: DBParm.ini, License.xml, Policies.xml, or cpm_ini_policies/"
                )

        finally:
            con.close()

        # Exit with error code if there were any errors
        if errors:
            sys.exit(1)

    except PACLIParserError as e:
        handle_error(e, logger, quiet)
        sys.exit(1)
    except Exception as e:
        handle_error(e, logger, quiet)
        sys.exit(2)


if __name__ == "__main__":
    main()
