"""
PACLI File Parsers - Parse INI and XML files from CyberArk PACLI exports.

Parsers for:
- DBParm.ini - Database configuration parameters
- License.xml - License information and user type limits
- Policies.xml - Platform policy definitions
- CPM INI policies - CPM platform configurations (Policy-*.ini files)
"""

from __future__ import annotations

import logging
import xml.etree.ElementTree as ET
from collections import OrderedDict, defaultdict
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# =============================================================================
# DBParm.ini PARSER
# =============================================================================


def parse_dbparm_ini(ini_path: Path) -> list[dict[str, Any]]:
    """
    Parse DBParm.ini file into a list of records.

    Args:
        ini_path: Path to DBParm.ini file

    Returns:
        List of dicts with keys: section, key, value
    """
    if not ini_path.exists():
        logger.warning(f"DBParm.ini not found: {ini_path}")
        return []

    records: list[dict[str, Any]] = []
    current_section = "MAIN"

    try:
        with open(ini_path, encoding="utf-8", errors="ignore") as f:
            for line in f:
                stripped = line.strip()

                # Skip empty lines and comments
                if not stripped or stripped.startswith("*"):
                    continue

                # Section header
                if stripped.startswith("[") and stripped.endswith("]"):
                    current_section = stripped[1:-1]
                    continue

                # Key-value pair
                if "=" in stripped:
                    key, value = stripped.split("=", 1)
                    records.append({
                        "section": current_section,
                        "key": key.strip(),
                        "value": value.strip(),
                    })

        logger.info(f"Parsed {len(records)} items from DBParm.ini")
        return records

    except Exception as e:
        logger.error(f"Failed to parse DBParm.ini: {e}")
        return []


# =============================================================================
# License.xml PARSER
# =============================================================================


def parse_license_xml(xml_path: Path) -> list[dict[str, Any]]:
    """
    Parse License.xml file into a list of records.

    Args:
        xml_path: Path to License.xml file

    Returns:
        List of dicts with keys: category, section, key, value
    """
    if not xml_path.exists():
        logger.warning(f"License.xml not found: {xml_path}")
        return []

    records: list[dict[str, Any]] = []

    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()

        # License version
        version = root.get("version", "")
        if version:
            records.append({
                "category": "General",
                "section": "Version",
                "key": "LicenseXMLVersion",
                "value": version,
            })

        # General section
        general = root.find("General")
        if general is not None:
            # Customer
            customer = general.find("Customer")
            if customer is not None:
                cust_id = customer.get("ID", "")
                if cust_id:
                    records.append({
                        "category": "General",
                        "section": "Customer",
                        "key": "CustomerID",
                        "value": cust_id,
                    })

            # VaultProperties
            vault_props = general.find("VaultProperties")
            if vault_props is not None:
                db_type = vault_props.get("DB", "")
                if db_type:
                    records.append({
                        "category": "General",
                        "section": "VaultProperties",
                        "key": "DatabaseType",
                        "value": db_type,
                    })

            # LicenseKey (truncated for security)
            license_key = general.find("LicenseKey")
            if license_key is not None:
                key_val = license_key.get("key", "")
                if key_val:
                    truncated = (
                        f"{key_val[:10]}...{key_val[-10:]}"
                        if len(key_val) > 20
                        else key_val
                    )
                    records.append({
                        "category": "General",
                        "section": "LicenseKey",
                        "key": "LicenseKey",
                        "value": truncated,
                    })

        # Limitations section
        limitations = root.find("Limitations")
        if limitations is not None:
            license_limits = limitations.find("LicenseLimitations")
            if license_limits is not None:
                for attr_name, attr_value in license_limits.attrib.items():
                    records.append({
                        "category": "Limitations",
                        "section": "LicenseLimitations",
                        "key": attr_name,
                        "value": attr_value,
                    })

            for child in limitations:
                if child.tag != "LicenseLimitations" and child.text:
                    records.append({
                        "category": "Limitations",
                        "section": child.tag,
                        "key": child.tag,
                        "value": child.text.strip(),
                    })

        # UserTypes section
        user_types = root.find("UserTypes")
        if user_types is not None:
            for user_type in user_types.findall("UserType"):
                name = user_type.get("Name", "Unknown")

                for attr in ["ID", "Description", "LicensedUsers", "Multiplicity", "Options"]:
                    val = user_type.get(attr, "")
                    if val:
                        records.append({
                            "category": "UserTypes",
                            "section": name,
                            "key": attr,
                            "value": val,
                        })

                # Allowed applications
                apps = [
                    app.get("App", "")
                    for app in user_type.findall("AllowedApplication")
                ]
                apps = [a for a in apps if a]
                if apps:
                    records.append({
                        "category": "UserTypes",
                        "section": name,
                        "key": "AllowedApplications",
                        "value": ", ".join(apps),
                    })

        logger.info(f"Parsed {len(records)} items from License.xml")
        return records

    except Exception as e:
        logger.error(f"Failed to parse License.xml: {e}")
        return []


# =============================================================================
# Policies.xml PARSERS
# =============================================================================


def parse_policies_xml(xml_path: Path) -> list[dict[str, Any]]:
    """
    Parse Policies.xml file into a list of records (long format).

    Args:
        xml_path: Path to Policies.xml file

    Returns:
        List of dicts with keys: policy_id, policy_name, key, value, value_order
    """
    if not xml_path.exists():
        logger.warning(f"Policies.xml not found: {xml_path}")
        return []

    records: list[dict[str, Any]] = []

    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()

        # Iterate through all Policy/Device elements
        for policy in root.iter():
            if policy.tag in ("Policy", "Device", "Usage"):
                policy_id = policy.get("ID", policy.get("PolicyID", ""))
                policy_name = policy.get("Name", policy.get("PolicyName", ""))

                if not policy_id and not policy_name:
                    continue

                # Extract all attributes as key-value pairs
                for attr_name, attr_value in policy.attrib.items():
                    if attr_name not in ("ID", "PolicyID", "Name", "PolicyName"):
                        records.append({
                            "policy_id": policy_id,
                            "policy_name": policy_name,
                            "key": attr_name,
                            "value": attr_value,
                            "value_order": 0,
                        })

                # Extract all child elements
                for child in policy:
                    if child.text and child.text.strip():
                        records.append({
                            "policy_id": policy_id,
                            "policy_name": policy_name,
                            "key": child.tag,
                            "value": child.text.strip(),
                            "value_order": 0,
                        })

                    # Handle child attributes
                    for attr_name, attr_value in child.attrib.items():
                        records.append({
                            "policy_id": policy_id,
                            "policy_name": policy_name,
                            "key": f"{child.tag}.{attr_name}",
                            "value": attr_value,
                            "value_order": 0,
                        })

        logger.info(f"Parsed {len(records)} items from Policies.xml")
        return records

    except Exception as e:
        logger.error(f"Failed to parse Policies.xml: {e}")
        return []


def parse_policies_xml_wide(xml_path: Path) -> list[dict[str, Any]]:
    """
    Parse Policies.xml file and pivot to wide format (one row per policy).

    Each key becomes a column. Multiple values for the same key are joined with "; ".

    Args:
        xml_path: Path to Policies.xml file

    Returns:
        List of dicts, one per policy, with all properties as columns
    """
    # First get the long-format records
    long_records = parse_policies_xml(xml_path)
    if not long_records:
        return []

    # Group by policy_id and pivot
    policy_data: dict[str, OrderedDict[str, str]] = {}

    for record in long_records:
        policy_id = record["policy_id"]
        policy_name = record["policy_name"]
        key = record["key"].lower().strip()  # Normalize key names
        value = record["value"]

        if policy_id not in policy_data:
            policy_data[policy_id] = OrderedDict()
            policy_data[policy_id]["policy_id"] = policy_id
            policy_data[policy_id]["policy_name"] = policy_name

        # Handle multiple values for same key: join with "; "
        if key in policy_data[policy_id]:
            existing = policy_data[policy_id][key]
            policy_data[policy_id][key] = f"{existing}; {value}"
        else:
            policy_data[policy_id][key] = value

    # Convert to list of dicts
    wide_records: list[dict[str, Any]] = [dict(d) for d in policy_data.values()]
    logger.info(f"Pivoted {len(wide_records)} policies to wide format")
    return wide_records


# =============================================================================
# CPM INI PARSERS
# =============================================================================


def parse_cpm_ini_files(ini_dir: Path) -> list[dict[str, Any]]:
    """
    Parse multiple CPM INI policy files from a directory (long format).

    Args:
        ini_dir: Path to directory containing Policy-*.ini files

    Returns:
        List of dicts with keys: file_name, section, key, value, key_order
    """
    if not ini_dir.exists() or not ini_dir.is_dir():
        logger.warning(f"CPM INI directory not found: {ini_dir}")
        return []

    records: list[dict[str, Any]] = []
    ini_files = list(ini_dir.glob("Policy-*.ini")) + list(ini_dir.glob("*.ini"))
    ini_files = list(set(ini_files))  # Remove duplicates

    if not ini_files:
        logger.warning(f"No INI files found in {ini_dir}")
        return []

    for ini_file in ini_files:
        try:
            current_section = "DEFAULT"
            key_counts: dict[str, int] = defaultdict(int)

            with open(ini_file, encoding="utf-8", errors="ignore") as f:
                for line in f:
                    stripped = line.strip()

                    # Skip empty, comments
                    if (
                        not stripped
                        or stripped.startswith(";")
                        or stripped.startswith("#")
                        or stripped.startswith(".")
                    ):
                        continue

                    # Section header
                    if stripped.startswith("[") and stripped.endswith("]"):
                        current_section = stripped[1:-1].strip()
                        continue

                    # Key-value pair
                    if "=" in stripped:
                        key, value = stripped.split("=", 1)
                        key = key.strip()
                        value = value.split(";", 1)[0].strip()  # Remove inline comments

                        order = key_counts[key]
                        key_counts[key] += 1

                        records.append({
                            "file_name": ini_file.name,
                            "section": current_section,
                            "key": key,
                            "value": value,
                            "key_order": order,
                        })

        except Exception as e:
            logger.warning(f"Failed to parse {ini_file.name}: {e}")
            continue

    logger.info(f"Parsed {len(records)} items from {len(ini_files)} CPM INI files")
    return records


def parse_cpm_ini_files_wide(ini_dir: Path) -> list[dict[str, Any]]:
    """
    Parse CPM INI policy files and pivot to wide format (one row per policy file).

    Each key becomes a column with values from the INI file. Keys with dots (e.g.,
    ExtraInfo.Port) are preserved as-is. Duplicate keys use first occurrence.

    Args:
        ini_dir: Path to directory containing Policy-*.ini files

    Returns:
        List of dicts, one per policy file, with all keys as columns
    """
    # First get the long-format records
    long_records = parse_cpm_ini_files(ini_dir)
    if not long_records:
        return []

    # Pivot: group by file_name, flatten section.key into columns
    file_data: dict[str, OrderedDict[str, str]] = {}

    for record in long_records:
        file_name = record["file_name"]
        section = record["section"]
        key = record["key"]
        value = record["value"]

        if file_name not in file_data:
            file_data[file_name] = OrderedDict()
            file_data[file_name]["file_name"] = file_name

        # Build column name: section.key for non-DEFAULT sections
        col_name = f"{section}.{key}" if section and section != "DEFAULT" else key

        # Only use first occurrence of each key (key_order=0)
        if col_name not in file_data[file_name]:
            file_data[file_name][col_name] = value

    # Convert to list of dicts
    wide_records: list[dict[str, Any]] = [dict(d) for d in file_data.values()]
    logger.info(f"Pivoted {len(wide_records)} policy files to wide format")
    return wide_records
