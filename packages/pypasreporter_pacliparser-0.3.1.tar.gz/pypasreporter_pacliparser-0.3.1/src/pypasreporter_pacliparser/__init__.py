"""
pyPASreporter-PACLIparser: PACLI configuration parser for CyberArk PAM.

Parse DBParm.ini, License.xml, Policies.xml, and CPM policy INI files
into DuckDB or CSV for analysis.

Part of the pyPASreporter ecosystem.

Usage:
    # CLI
    pypasreporter-pacliparser license -i License.xml -d vault.duckdb
    pypasreporter-pacliparser dbparm -i DBParm.ini -d vault.duckdb
    pypasreporter-pacliparser policies -i Policies.xml -d vault.duckdb
    pypasreporter-pacliparser cpm-policies -i ./cpm_ini_policies/ -d vault.duckdb
    pypasreporter-pacliparser all -i ./pacli_exports/ -d vault.duckdb

    # Python API
    from pypasreporter_pacliparser import parse_license_xml, parse_dbparm_ini

    records = parse_license_xml(Path("License.xml"))
    records = parse_dbparm_ini(Path("DBParm.ini"))
"""

__version__ = "0.3.1"
__author__ = "itpamltd"
__email__ = "itpamltd@proton.me"

from .parsers import (
    parse_cpm_ini_files,
    parse_cpm_ini_files_wide,
    parse_dbparm_ini,
    parse_license_xml,
    parse_policies_xml,
    parse_policies_xml_wide,
)
from .normalize import clean_column_name, sanitize_null

__all__ = [
    # Parsers
    "parse_dbparm_ini",
    "parse_license_xml",
    "parse_policies_xml",
    "parse_policies_xml_wide",
    "parse_cpm_ini_files",
    "parse_cpm_ini_files_wide",
    # Utilities
    "clean_column_name",
    "sanitize_null",
    # Metadata
    "__version__",
]
