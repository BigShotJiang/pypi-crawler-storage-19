"""
Column and row normalization functions.

Handles:
- Column name normalization (snake_case)
- NULL value sanitization
"""

from __future__ import annotations

import re
from functools import lru_cache


@lru_cache(maxsize=4096)
def clean_column_name(name: str) -> str:
    """
    Normalize column name to snake_case.

    - Strips whitespace
    - Converts camelCase to snake_case
    - Replaces special characters with underscores
    - Lowercases
    - Removes leading/trailing underscores

    Examples:
        >>> clean_column_name("UserName")
        'user_name'
        >>> clean_column_name("Last Logon Date")
        'last_logon_date'
        >>> clean_column_name("%UsedSize")
        'used_size'
        >>> clean_column_name("PSMConcurrentSessions")
        'psm_concurrent_sessions'
        >>> clean_column_name("ChangeTask.EnforcePolicy")
        'change_task_enforce_policy'
    """
    s = name.strip()
    # camelCase -> snake_case
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s)
    # Replace non-alphanumeric with underscore
    s = re.sub(r"[^a-zA-Z0-9]+", "_", s)
    # Lowercase and clean up
    s = s.lower().strip("_")
    # Collapse multiple underscores
    s = re.sub(r"_+", "_", s)
    return s


# NULL sentinel values that should be converted to None
NULL_SENTINELS = frozenset({"", "NULL", "null", "None", "none", "N/A", "n/a"})


def sanitize_null(value: str | None) -> str | None:
    """
    Convert NULL sentinel values to None.

    Args:
        value: String value to check

    Returns:
        None if value is a NULL sentinel, otherwise the original value
    """
    if value is None:
        return None
    if isinstance(value, str) and value.strip() in NULL_SENTINELS:
        return None
    return value
