# 二分归并加密

### 加密方法
* abcdefg => 
* aceg => 
* ae
* cg
* bdf =>
* bf
* d
* => aecgbfd

### 调用方法
```
from BRME import *

"""
BRME/BinaryRecursiveMergeEncryption/brme
"""

print(brme("sdgj")) # => sgdj
```