# コアコンセプト

> agent-contractsアーキテクチャの詳細

---

## 概要

`agent-contracts`はシンプルな原則に基づいています：**ノードが何をするかを宣言し、どう接続するかは宣言しない**

```
┌─────────────────────────────────────────────────────────────┐
│                        Registry                              │
│  ┌───────────┐  ┌───────────┐  ┌───────────┐               │
│  │ NodeA     │  │ NodeB     │  │ NodeC     │  ...          │
│  │ CONTRACT  │  │ CONTRACT  │  │ CONTRACT  │               │
│  └───────────┘  └───────────┘  └───────────┘               │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                     GraphBuilder                             │
│  • コントラクトを分析                                         │
│  • スーパーバイザーを作成                                     │
│  • LangGraphを自動配線                                       │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                      LangGraph                               │
│  START → Supervisor ⟷ Nodes → END                           │
└─────────────────────────────────────────────────────────────┘
```

---

## NodeContract

`NodeContract`はライブラリの中心です。ノードに関するすべてを宣言します：

```python
NodeContract(
    # === 識別 ===
    name="my_node",                    # 一意の識別子
    description="このノードの役割", # 人間が読める説明
    
    # === I/O定義 ===
    reads=["request", "context"],      # 読み取るステートスライス
    writes=["response"],               # 書き込むステートスライス
    
    # === 依存関係 ===
    requires_llm=True,                 # LLMが必要か
    services=["db_service"],           # 必要な外部サービス
    
    # === ルーティング ===
    supervisor="main",                 # 管理するスーパーバイザー
    trigger_conditions=[...],          # ノードを起動する条件
    is_terminal=False,                 # 実行後にフローを終了するか
)
```

### なぜコントラクトか？

| コントラクトなし | コントラクトあり |
|-----------------|-----------------|
| 手動でグラフを配線 | 自動グラフ構築 |
| 依存関係が隠れている | 明示的なI/O宣言 |
| ランタイムエラー | 静的検証 |
| ドキュメント化が困難 | 自動生成ドキュメント |

---

## ステートスライス

`agent-contracts`のステートは独立した**スライス**に整理されます：

```python
state = {
    "request": {           # ユーザーからの入力
        "action": "search",
        "params": {"query": "laptop"}
    },
    "response": {          # ユーザーへの出力
        "response_type": "results",
        "data": [...]
    },
    "context": {           # 共有コンテキスト
        "user_preferences": {...}
    },
    "_internal": {         # フレームワーク内部
        "decision": "search_node",
        "iteration": 1
    }
}
```

### 設計原則

1. **関心の分離**: 各スライスは単一の目的を持つ
2. **明示的アクセス**: ノードは読み書きするスライスを宣言
3. **検証**: 不明なスライスはエラーをトリガー

### 組み込みスライス

| スライス | 目的 |
|----------|------|
| `request` | ユーザー入力（読み取り専用推奨） |
| `response` | ユーザー出力 |
| `_internal` | フレームワークのルーティング/イテレーション |

カスタムスライスを定義可能：

```python
registry.add_valid_slice("shopping")
registry.add_valid_slice("interview")
```

---

## TriggerCondition

トリガー条件はノードが選択されるタイミングを制御します：

```python
TriggerCondition(
    priority=10,                           # 高い = 先に評価
    when={"request.action": "search"},     # マッチ条件
    when_not={"response.done": True},      # 否定マッチ
    llm_hint="商品検索に使用",               # LLMルーティングヒント
)
```

### 優先度レベル

| 範囲 | 用途 | 例 |
|------|------|----|
| 🔴 100+ | クリティカル/即時 | エラーハンドラ |
| 🟡 50-99 | 主要ハンドラ | メインビジネスロジック |
| 🟢 1-49 | フォールバック | デフォルトハンドラ |
| ⚪ 0 | 常にマッチ | キャッチオール |

### 条件マッチング

```python
# 正確な値マッチ
when={"request.action": "search"}

# ブール値チェック
when={"context.authenticated": True}

# ネストパス
when={"request.params.category": "electronics"}

# 複数条件 (AND)
when={"request.action": "buy", "context.cart_ready": True}
```

---

## GenericSupervisor

スーパーバイザーは多段階アプローチでノード選択を調整します：

```
┌─────────────────────────────────────────────────────────────┐
│                    決定フロー                                │
├─────────────────────────────────────────────────────────────┤
│  1. 終了状態チェック                                         │
│     └─ response_type が terminal_states に含まれる → done    │
│                                                              │
│  2. 明示的ルーティング                                       │
│     └─ action="answer" → 質問の送信元にルーティング          │
│                                                              │
│  3. ルールベース評価                                         │
│     └─ 全TriggerConditionを評価、候補を収集                  │
│                                                              │
│  4. LLM決定（利用可能な場合）                                │
│     └─ LLMがllm_hintsを使用して候補から選択                  │
│                                                              │
│  5. フォールバック                                           │
│     └─ 最高優先度のルールマッチを使用                        │
└─────────────────────────────────────────────────────────────┘
```

### LLMあり vs なし

| モード | 動作 |
|--------|------|
| **LLMあり** | LLMがルールヒントを使用して最終決定 |
| **LLMなし** | 純粋なルールベース、最高優先度マッチを使用 |

---

## InteractiveNode

会話型エージェントには`InteractiveNode`を使用：

```python
from agent_contracts import InteractiveNode


class InterviewNode(InteractiveNode):
    CONTRACT = NodeContract(...)
    
    def prepare_context(self, inputs):
        """入力からコンテキストを抽出"""
        return inputs.get_slice("interview")
    
    def check_completion(self, context, inputs):
        """インタビュー完了をチェック"""
        return len(context.get("answers", [])) >= 5
    
    async def process_answer(self, context, inputs, config=None):
        """ユーザーの回答を処理"""
        answer = inputs.get_slice("request").get("answer")
        # 回答を保存...
        return True
    
    async def generate_question(self, context, inputs, config=None):
        """次の質問を生成"""
        # LLMで質問を生成...
        return NodeOutputs(response={"question": "どの色が好きですか？"})
```

### ライフサイクル

```
┌─────────────────────────────────────────────────────────────┐
│                  InteractiveNode フロー                      │
├─────────────────────────────────────────────────────────────┤
│  1. prepare_context()     → 必要なデータを抽出               │
│  2. check_completion()    → 既に完了？                       │
│       └─ Yes → create_completion_output()                    │
│       └─ No ↓                                               │
│  3. process_answer()      → ユーザーの応答を処理             │
│  4. check_completion()    → 今完了？                         │
│       └─ Yes → create_completion_output()                    │
│       └─ No → generate_question()                           │
└─────────────────────────────────────────────────────────────┘
```

---

## ContractValidator

実行前にコントラクトを検証：

```python
from agent_contracts import ContractValidator

validator = ContractValidator(
    registry,
    known_services={"db_service", "cache_service"},
)
result = validator.validate()

if result.has_errors:
    print(result)  # エラーを表示
    exit(1)
```

### 検証レベル

| レベル | 例 |
|--------|-----|
| **ERROR** | reads/writesの不明なスライス |
| **WARNING** | 不明なサービス、到達不能ノード |
| **INFO** | 共有ライター（複数ノードが同じスライスに書き込み） |

---

## トレーサブルルーティング

デバッグには`decide_with_trace()`を使用：

```python
decision = await supervisor.decide_with_trace(state)

print(f"選択: {decision.selected_node}")
print(f"タイプ: {decision.reason.decision_type}")

for rule in decision.reason.matched_rules:
    print(f"  {rule.node} (P{rule.priority}): {rule.condition}")
```

### 決定タイプ

| タイプ | 意味 |
|--------|------|
| `terminal_state` | レスポンスタイプが終了をトリガー |
| `explicit_routing` | 回答が質問の送信元にルーティング |
| `rule_match` | TriggerConditionがマッチ |
| `llm_decision` | LLMが選択 |
| `fallback` | マッチなし、デフォルトを使用 |

---

## StateAccessorパターン

型安全でイミュータブルな状態フィールドアクセス：

```python
from agent_contracts import Internal, Request, Response, reset_response

# 状態の読み取り
count = Internal.turn_count.get(state)
action = Request.action.get(state)

# 状態の書き込み（イミュータブル - 新しいstateを返す）
state = Internal.turn_count.set(state, 5)
state = reset_response(state)
```

### 利用可能なアクセサー

| クラス | フィールド |
|-------|----------|
| `Internal` | `turn_count`, `is_first_turn`, `active_mode`, `next_node`, `error` |
| `Request` | `session_id`, `action`, `params`, `message`, `image` |
| `Response` | `response_type`, `response_data`, `response_message` |

### 便利関数

```python
from agent_contracts import increment_turn, set_error, clear_error

state = increment_turn(state)  # turn_count++, is_first_turn=False
state = set_error(state, "エラーが発生しました")
state = clear_error(state)
```

---

## Runtimeレイヤー

本番アプリケーションでは、統合実行のためにRuntimeレイヤーを使用：

### AgentRuntime

```python
from agent_contracts import AgentRuntime, RequestContext, InMemorySessionStore

runtime = AgentRuntime(
    graph=compiled_graph,
    session_store=InMemorySessionStore(),
)

result = await runtime.execute(RequestContext(
    session_id="abc123",
    action="answer",
    message="カジュアルが好き",
    resume_session=True,
))
```

### 実行ライフサイクル

```
┌─────────────────────────────────────────────────────────────┐
│                  AgentRuntime ライフサイクル                 │
├─────────────────────────────────────────────────────────────┤
│  1. 初期状態を作成                                           │
│  2. セッションを復元（resume_session=True の場合）            │
│  3. hooks.prepare_state() → 実行前カスタマイズ               │
│  4. graph.ainvoke() → LangGraphを実行                        │
│  5. ExecutionResultを構築                                    │
│  6. hooks.after_execution() → 永続化、クリーンアップ         │
└─────────────────────────────────────────────────────────────┘
```

### カスタムフック

```python
from agent_contracts import RuntimeHooks

class MyHooks(RuntimeHooks):
    async def prepare_state(self, state, request):
        # 状態の正規化、リソースの読み込み
        return state
    
    async def after_execution(self, state, result):
        # セッション保存、ログなど
        await self.session_store.save(...)
```

### StreamingRuntime（SSE対応）

```python
from agent_contracts.runtime import StreamingRuntime, StreamEventType

runtime = (
    StreamingRuntime()
    .add_node("search", search_node, "検索中...")
    .add_node("stylist", stylist_node, "生成中...")
)

async for event in runtime.stream(request):
    if event.type == StreamEventType.NODE_END:
        print(f"ノード {event.node_name} 完了")
    yield event.to_sse()
```

---

## 次のステップ

- 🎯 [ベストプラクティス](best_practices.ja.md) - 設計パターン
- 🐛 [トラブルシューティング](troubleshooting.ja.md) - よくある問題
