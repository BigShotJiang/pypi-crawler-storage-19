import time
import json
import platform
import requests
import subprocess
from pathlib import Path
from colorama import Fore

headers = {"User-Agent": "XiaomiPCSuite"}

def download_captcha(path, captchaUrl, cookies):    
    response = requests.get(f"https://account.xiaomi.com{captchaUrl}", cookies=cookies, headers=headers)
    cookies.update(response.cookies.get_dict())
    with open(path, "wb") as f:
        f.write(response.content)
    input(f'\n{Fore.CYAN}Press Enter to open the CAPTCHA image')
    if platform.system() == 'Windows':
        subprocess.run(['start', str(path)], shell=True)
    elif platform.system() == 'Darwin':
        subprocess.run(['open', str(path)])
    else:
        subprocess.run(['xdg-open', str(path)])
    
    print(f"\n{Fore.GREEN}Captcha displayed from {path}\n")
    return cookies

def verify(captchaUrl, cookies, data):
    path = Path.home() / f"{int(time.time())}_captcha.jpg"
    cookies = download_captcha(path, captchaUrl, cookies)
    captCode = input(f"\n{Fore.CYAN}Enter captcha code: ").strip()
    data.update({'captCode': captCode})
    response = requests.post(f"https://account.xiaomi.com/pass/serviceLoginAuth2", data=data, headers=headers, cookies=cookies)
    response_text = json.loads(response.text[11:])
    data.pop('captCode', None)
    if response_text.get("code") == 87001:
        path.unlink()
        print(f"\n{Fore.YELLOW}Incorrect captcha code. A new captcha will be generated ...\n")
        return verify(response_text["captchaUrl"], response.cookies.get_dict(), data)
    cookies = response.cookies.get_dict()
    path.unlink()

    if 'passToken' not in cookies:
        if 'authStart?sid=unlockApi&context' in response_text.get('notificationUrl', ''):
            notificationUrl = response_text['notificationUrl']
            return {"notificationUrl": notificationUrl}
        else:
            return {"error": f"\npass token was not found:\ncookies: {cookies}\nresponse_text: {response_text}\n"}

    return cookies