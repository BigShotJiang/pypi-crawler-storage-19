# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BackupNodeInfoResult:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'az_list': 'str',
        'node_list': 'str'
    }

    attribute_map = {
        'az_list': 'az_list',
        'node_list': 'node_list'
    }

    def __init__(self, az_list=None, node_list=None):
        r"""BackupNodeInfoResult

        The model defined in huaweicloud sdk

        :param az_list: **参数解释**: 选择指定az下的节点进行备份。 **取值范围**: 不涉及。
        :type az_list: str
        :param node_list: **参数解释**: 选择指定节点进行备份。 **取值范围**: 不涉及。
        :type node_list: str
        """
        
        

        self._az_list = None
        self._node_list = None
        self.discriminator = None

        if az_list is not None:
            self.az_list = az_list
        if node_list is not None:
            self.node_list = node_list

    @property
    def az_list(self):
        r"""Gets the az_list of this BackupNodeInfoResult.

        **参数解释**: 选择指定az下的节点进行备份。 **取值范围**: 不涉及。

        :return: The az_list of this BackupNodeInfoResult.
        :rtype: str
        """
        return self._az_list

    @az_list.setter
    def az_list(self, az_list):
        r"""Sets the az_list of this BackupNodeInfoResult.

        **参数解释**: 选择指定az下的节点进行备份。 **取值范围**: 不涉及。

        :param az_list: The az_list of this BackupNodeInfoResult.
        :type az_list: str
        """
        self._az_list = az_list

    @property
    def node_list(self):
        r"""Gets the node_list of this BackupNodeInfoResult.

        **参数解释**: 选择指定节点进行备份。 **取值范围**: 不涉及。

        :return: The node_list of this BackupNodeInfoResult.
        :rtype: str
        """
        return self._node_list

    @node_list.setter
    def node_list(self, node_list):
        r"""Sets the node_list of this BackupNodeInfoResult.

        **参数解释**: 选择指定节点进行备份。 **取值范围**: 不涉及。

        :param node_list: The node_list of this BackupNodeInfoResult.
        :type node_list: str
        """
        self._node_list = node_list

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BackupNodeInfoResult):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
