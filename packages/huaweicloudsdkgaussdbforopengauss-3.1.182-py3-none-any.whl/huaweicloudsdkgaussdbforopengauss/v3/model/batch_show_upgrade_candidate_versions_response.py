# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BatchShowUpgradeCandidateVersionsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'upgrade_type_list': 'list[UpgradeTypeInfo]',
        'target_version': 'str',
        'upgrade_candidate_versions': 'list[str]',
        'hotfix_upgrade_infos': 'list[HotfixInfoResult]',
        'hotfix_rollback_infos': 'list[HotfixInfoResult]'
    }

    attribute_map = {
        'upgrade_type_list': 'upgrade_type_list',
        'target_version': 'target_version',
        'upgrade_candidate_versions': 'upgrade_candidate_versions',
        'hotfix_upgrade_infos': 'hotfix_upgrade_infos',
        'hotfix_rollback_infos': 'hotfix_rollback_infos'
    }

    def __init__(self, upgrade_type_list=None, target_version=None, upgrade_candidate_versions=None, hotfix_upgrade_infos=None, hotfix_rollback_infos=None):
        r"""BatchShowUpgradeCandidateVersionsResponse

        The model defined in huaweicloud sdk

        :param upgrade_type_list: 升级类型信息列表。
        :type upgrade_type_list: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.UpgradeTypeInfo`]
        :param target_version: 升级目标版本，没有在滚动升级中返回null。
        :type target_version: str
        :param upgrade_candidate_versions: 可以升级的版本，包括大小版本。
        :type upgrade_candidate_versions: list[str]
        :param hotfix_upgrade_infos: 可以升级的热补丁信息。
        :type hotfix_upgrade_infos: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.HotfixInfoResult`]
        :param hotfix_rollback_infos: 可以回滚的热补丁信息。
        :type hotfix_rollback_infos: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.HotfixInfoResult`]
        """
        
        super().__init__()

        self._upgrade_type_list = None
        self._target_version = None
        self._upgrade_candidate_versions = None
        self._hotfix_upgrade_infos = None
        self._hotfix_rollback_infos = None
        self.discriminator = None

        if upgrade_type_list is not None:
            self.upgrade_type_list = upgrade_type_list
        if target_version is not None:
            self.target_version = target_version
        if upgrade_candidate_versions is not None:
            self.upgrade_candidate_versions = upgrade_candidate_versions
        if hotfix_upgrade_infos is not None:
            self.hotfix_upgrade_infos = hotfix_upgrade_infos
        if hotfix_rollback_infos is not None:
            self.hotfix_rollback_infos = hotfix_rollback_infos

    @property
    def upgrade_type_list(self):
        r"""Gets the upgrade_type_list of this BatchShowUpgradeCandidateVersionsResponse.

        升级类型信息列表。

        :return: The upgrade_type_list of this BatchShowUpgradeCandidateVersionsResponse.
        :rtype: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.UpgradeTypeInfo`]
        """
        return self._upgrade_type_list

    @upgrade_type_list.setter
    def upgrade_type_list(self, upgrade_type_list):
        r"""Sets the upgrade_type_list of this BatchShowUpgradeCandidateVersionsResponse.

        升级类型信息列表。

        :param upgrade_type_list: The upgrade_type_list of this BatchShowUpgradeCandidateVersionsResponse.
        :type upgrade_type_list: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.UpgradeTypeInfo`]
        """
        self._upgrade_type_list = upgrade_type_list

    @property
    def target_version(self):
        r"""Gets the target_version of this BatchShowUpgradeCandidateVersionsResponse.

        升级目标版本，没有在滚动升级中返回null。

        :return: The target_version of this BatchShowUpgradeCandidateVersionsResponse.
        :rtype: str
        """
        return self._target_version

    @target_version.setter
    def target_version(self, target_version):
        r"""Sets the target_version of this BatchShowUpgradeCandidateVersionsResponse.

        升级目标版本，没有在滚动升级中返回null。

        :param target_version: The target_version of this BatchShowUpgradeCandidateVersionsResponse.
        :type target_version: str
        """
        self._target_version = target_version

    @property
    def upgrade_candidate_versions(self):
        r"""Gets the upgrade_candidate_versions of this BatchShowUpgradeCandidateVersionsResponse.

        可以升级的版本，包括大小版本。

        :return: The upgrade_candidate_versions of this BatchShowUpgradeCandidateVersionsResponse.
        :rtype: list[str]
        """
        return self._upgrade_candidate_versions

    @upgrade_candidate_versions.setter
    def upgrade_candidate_versions(self, upgrade_candidate_versions):
        r"""Sets the upgrade_candidate_versions of this BatchShowUpgradeCandidateVersionsResponse.

        可以升级的版本，包括大小版本。

        :param upgrade_candidate_versions: The upgrade_candidate_versions of this BatchShowUpgradeCandidateVersionsResponse.
        :type upgrade_candidate_versions: list[str]
        """
        self._upgrade_candidate_versions = upgrade_candidate_versions

    @property
    def hotfix_upgrade_infos(self):
        r"""Gets the hotfix_upgrade_infos of this BatchShowUpgradeCandidateVersionsResponse.

        可以升级的热补丁信息。

        :return: The hotfix_upgrade_infos of this BatchShowUpgradeCandidateVersionsResponse.
        :rtype: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.HotfixInfoResult`]
        """
        return self._hotfix_upgrade_infos

    @hotfix_upgrade_infos.setter
    def hotfix_upgrade_infos(self, hotfix_upgrade_infos):
        r"""Sets the hotfix_upgrade_infos of this BatchShowUpgradeCandidateVersionsResponse.

        可以升级的热补丁信息。

        :param hotfix_upgrade_infos: The hotfix_upgrade_infos of this BatchShowUpgradeCandidateVersionsResponse.
        :type hotfix_upgrade_infos: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.HotfixInfoResult`]
        """
        self._hotfix_upgrade_infos = hotfix_upgrade_infos

    @property
    def hotfix_rollback_infos(self):
        r"""Gets the hotfix_rollback_infos of this BatchShowUpgradeCandidateVersionsResponse.

        可以回滚的热补丁信息。

        :return: The hotfix_rollback_infos of this BatchShowUpgradeCandidateVersionsResponse.
        :rtype: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.HotfixInfoResult`]
        """
        return self._hotfix_rollback_infos

    @hotfix_rollback_infos.setter
    def hotfix_rollback_infos(self, hotfix_rollback_infos):
        r"""Sets the hotfix_rollback_infos of this BatchShowUpgradeCandidateVersionsResponse.

        可以回滚的热补丁信息。

        :param hotfix_rollback_infos: The hotfix_rollback_infos of this BatchShowUpgradeCandidateVersionsResponse.
        :type hotfix_rollback_infos: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.HotfixInfoResult`]
        """
        self._hotfix_rollback_infos = hotfix_rollback_infos

    def to_dict(self):
        import warnings
        warnings.warn("BatchShowUpgradeCandidateVersionsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BatchShowUpgradeCandidateVersionsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
