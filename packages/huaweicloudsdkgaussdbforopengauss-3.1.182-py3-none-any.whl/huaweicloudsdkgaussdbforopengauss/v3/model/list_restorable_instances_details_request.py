# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListRestorableInstancesDetailsRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'x_language': 'str',
        'source_instance_id': 'str',
        'backup_id': 'str',
        'restore_time': 'str',
        'offset': 'int',
        'limit': 'int',
        'backup_restore_type': 'str',
        'source_backup_schema': 'str',
        'target_instance_id': 'str',
        'instance_name': 'str'
    }

    attribute_map = {
        'x_language': 'X-Language',
        'source_instance_id': 'source_instance_id',
        'backup_id': 'backup_id',
        'restore_time': 'restore_time',
        'offset': 'offset',
        'limit': 'limit',
        'backup_restore_type': 'backup_restore_type',
        'source_backup_schema': 'source_backup_schema',
        'target_instance_id': 'target_instance_id',
        'instance_name': 'instance_name'
    }

    def __init__(self, x_language=None, source_instance_id=None, backup_id=None, restore_time=None, offset=None, limit=None, backup_restore_type=None, source_backup_schema=None, target_instance_id=None, instance_name=None):
        r"""ListRestorableInstancesDetailsRequest

        The model defined in huaweicloud sdk

        :param x_language: **参数解释**: 语言。 **约束限制**: 不涉及。 **取值范围**:   - zh-cn   - en-us  **默认取值**: en-us
        :type x_language: str
        :param source_instance_id: 源实例id，需要恢复的实例ID。
        :type source_instance_id: str
        :param backup_id: 实例备份信息ID，根据备份ID查询实例拓扑信息，过滤查询出来的实例，包含节点数，副本数等。参数为空时，根据restore_time查询。。
        :type backup_id: str
        :param restore_time: 恢复点，当备份ID为空时，通过此参数查询实例拓扑信息，过滤实例列表。
        :type restore_time: str
        :param offset: 索引位置，偏移量。从第一条数据偏移offset条数据后开始查询，默认为0（偏移0条数据，表示从第一条数据开始查询），必须为数字，不能为负数。
        :type offset: int
        :param limit: 查询记录数。默认为100，不能为负数，最小值为1，最大值为100。
        :type limit: int
        :param backup_restore_type: **参数解释**: 查备份恢复的粒度。 **约束限制**: 不涉及。 **取值范围**:   - INSTANCE   - DATABASE_TABLE   - DATABASE **默认取值**: INSTANCE
        :type backup_restore_type: str
        :param source_backup_schema: **参数解释**: 源实例的备份类型。 **约束限制**: 不涉及。 **取值范围**:   - INSTANCE   - DATABASE_TABLE **默认取值**: INSTANCE
        :type source_backup_schema: str
        :param target_instance_id: **参数解释**: 目标实例ID，通过此参数过滤实例列表。 **约束限制**: 不涉及。 **取值范围**: 不涉及。 **默认取值**: 不涉及。
        :type target_instance_id: str
        :param instance_name: **参数解释**: 目标实例名称，通过此参数过滤实例列表。 **约束限制**: 不涉及。 **取值范围**: 不涉及。 **默认取值**: 不涉及。
        :type instance_name: str
        """
        
        

        self._x_language = None
        self._source_instance_id = None
        self._backup_id = None
        self._restore_time = None
        self._offset = None
        self._limit = None
        self._backup_restore_type = None
        self._source_backup_schema = None
        self._target_instance_id = None
        self._instance_name = None
        self.discriminator = None

        if x_language is not None:
            self.x_language = x_language
        self.source_instance_id = source_instance_id
        if backup_id is not None:
            self.backup_id = backup_id
        if restore_time is not None:
            self.restore_time = restore_time
        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit
        if backup_restore_type is not None:
            self.backup_restore_type = backup_restore_type
        if source_backup_schema is not None:
            self.source_backup_schema = source_backup_schema
        if target_instance_id is not None:
            self.target_instance_id = target_instance_id
        if instance_name is not None:
            self.instance_name = instance_name

    @property
    def x_language(self):
        r"""Gets the x_language of this ListRestorableInstancesDetailsRequest.

        **参数解释**: 语言。 **约束限制**: 不涉及。 **取值范围**:   - zh-cn   - en-us  **默认取值**: en-us

        :return: The x_language of this ListRestorableInstancesDetailsRequest.
        :rtype: str
        """
        return self._x_language

    @x_language.setter
    def x_language(self, x_language):
        r"""Sets the x_language of this ListRestorableInstancesDetailsRequest.

        **参数解释**: 语言。 **约束限制**: 不涉及。 **取值范围**:   - zh-cn   - en-us  **默认取值**: en-us

        :param x_language: The x_language of this ListRestorableInstancesDetailsRequest.
        :type x_language: str
        """
        self._x_language = x_language

    @property
    def source_instance_id(self):
        r"""Gets the source_instance_id of this ListRestorableInstancesDetailsRequest.

        源实例id，需要恢复的实例ID。

        :return: The source_instance_id of this ListRestorableInstancesDetailsRequest.
        :rtype: str
        """
        return self._source_instance_id

    @source_instance_id.setter
    def source_instance_id(self, source_instance_id):
        r"""Sets the source_instance_id of this ListRestorableInstancesDetailsRequest.

        源实例id，需要恢复的实例ID。

        :param source_instance_id: The source_instance_id of this ListRestorableInstancesDetailsRequest.
        :type source_instance_id: str
        """
        self._source_instance_id = source_instance_id

    @property
    def backup_id(self):
        r"""Gets the backup_id of this ListRestorableInstancesDetailsRequest.

        实例备份信息ID，根据备份ID查询实例拓扑信息，过滤查询出来的实例，包含节点数，副本数等。参数为空时，根据restore_time查询。。

        :return: The backup_id of this ListRestorableInstancesDetailsRequest.
        :rtype: str
        """
        return self._backup_id

    @backup_id.setter
    def backup_id(self, backup_id):
        r"""Sets the backup_id of this ListRestorableInstancesDetailsRequest.

        实例备份信息ID，根据备份ID查询实例拓扑信息，过滤查询出来的实例，包含节点数，副本数等。参数为空时，根据restore_time查询。。

        :param backup_id: The backup_id of this ListRestorableInstancesDetailsRequest.
        :type backup_id: str
        """
        self._backup_id = backup_id

    @property
    def restore_time(self):
        r"""Gets the restore_time of this ListRestorableInstancesDetailsRequest.

        恢复点，当备份ID为空时，通过此参数查询实例拓扑信息，过滤实例列表。

        :return: The restore_time of this ListRestorableInstancesDetailsRequest.
        :rtype: str
        """
        return self._restore_time

    @restore_time.setter
    def restore_time(self, restore_time):
        r"""Sets the restore_time of this ListRestorableInstancesDetailsRequest.

        恢复点，当备份ID为空时，通过此参数查询实例拓扑信息，过滤实例列表。

        :param restore_time: The restore_time of this ListRestorableInstancesDetailsRequest.
        :type restore_time: str
        """
        self._restore_time = restore_time

    @property
    def offset(self):
        r"""Gets the offset of this ListRestorableInstancesDetailsRequest.

        索引位置，偏移量。从第一条数据偏移offset条数据后开始查询，默认为0（偏移0条数据，表示从第一条数据开始查询），必须为数字，不能为负数。

        :return: The offset of this ListRestorableInstancesDetailsRequest.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ListRestorableInstancesDetailsRequest.

        索引位置，偏移量。从第一条数据偏移offset条数据后开始查询，默认为0（偏移0条数据，表示从第一条数据开始查询），必须为数字，不能为负数。

        :param offset: The offset of this ListRestorableInstancesDetailsRequest.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this ListRestorableInstancesDetailsRequest.

        查询记录数。默认为100，不能为负数，最小值为1，最大值为100。

        :return: The limit of this ListRestorableInstancesDetailsRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListRestorableInstancesDetailsRequest.

        查询记录数。默认为100，不能为负数，最小值为1，最大值为100。

        :param limit: The limit of this ListRestorableInstancesDetailsRequest.
        :type limit: int
        """
        self._limit = limit

    @property
    def backup_restore_type(self):
        r"""Gets the backup_restore_type of this ListRestorableInstancesDetailsRequest.

        **参数解释**: 查备份恢复的粒度。 **约束限制**: 不涉及。 **取值范围**:   - INSTANCE   - DATABASE_TABLE   - DATABASE **默认取值**: INSTANCE

        :return: The backup_restore_type of this ListRestorableInstancesDetailsRequest.
        :rtype: str
        """
        return self._backup_restore_type

    @backup_restore_type.setter
    def backup_restore_type(self, backup_restore_type):
        r"""Sets the backup_restore_type of this ListRestorableInstancesDetailsRequest.

        **参数解释**: 查备份恢复的粒度。 **约束限制**: 不涉及。 **取值范围**:   - INSTANCE   - DATABASE_TABLE   - DATABASE **默认取值**: INSTANCE

        :param backup_restore_type: The backup_restore_type of this ListRestorableInstancesDetailsRequest.
        :type backup_restore_type: str
        """
        self._backup_restore_type = backup_restore_type

    @property
    def source_backup_schema(self):
        r"""Gets the source_backup_schema of this ListRestorableInstancesDetailsRequest.

        **参数解释**: 源实例的备份类型。 **约束限制**: 不涉及。 **取值范围**:   - INSTANCE   - DATABASE_TABLE **默认取值**: INSTANCE

        :return: The source_backup_schema of this ListRestorableInstancesDetailsRequest.
        :rtype: str
        """
        return self._source_backup_schema

    @source_backup_schema.setter
    def source_backup_schema(self, source_backup_schema):
        r"""Sets the source_backup_schema of this ListRestorableInstancesDetailsRequest.

        **参数解释**: 源实例的备份类型。 **约束限制**: 不涉及。 **取值范围**:   - INSTANCE   - DATABASE_TABLE **默认取值**: INSTANCE

        :param source_backup_schema: The source_backup_schema of this ListRestorableInstancesDetailsRequest.
        :type source_backup_schema: str
        """
        self._source_backup_schema = source_backup_schema

    @property
    def target_instance_id(self):
        r"""Gets the target_instance_id of this ListRestorableInstancesDetailsRequest.

        **参数解释**: 目标实例ID，通过此参数过滤实例列表。 **约束限制**: 不涉及。 **取值范围**: 不涉及。 **默认取值**: 不涉及。

        :return: The target_instance_id of this ListRestorableInstancesDetailsRequest.
        :rtype: str
        """
        return self._target_instance_id

    @target_instance_id.setter
    def target_instance_id(self, target_instance_id):
        r"""Sets the target_instance_id of this ListRestorableInstancesDetailsRequest.

        **参数解释**: 目标实例ID，通过此参数过滤实例列表。 **约束限制**: 不涉及。 **取值范围**: 不涉及。 **默认取值**: 不涉及。

        :param target_instance_id: The target_instance_id of this ListRestorableInstancesDetailsRequest.
        :type target_instance_id: str
        """
        self._target_instance_id = target_instance_id

    @property
    def instance_name(self):
        r"""Gets the instance_name of this ListRestorableInstancesDetailsRequest.

        **参数解释**: 目标实例名称，通过此参数过滤实例列表。 **约束限制**: 不涉及。 **取值范围**: 不涉及。 **默认取值**: 不涉及。

        :return: The instance_name of this ListRestorableInstancesDetailsRequest.
        :rtype: str
        """
        return self._instance_name

    @instance_name.setter
    def instance_name(self, instance_name):
        r"""Sets the instance_name of this ListRestorableInstancesDetailsRequest.

        **参数解释**: 目标实例名称，通过此参数过滤实例列表。 **约束限制**: 不涉及。 **取值范围**: 不涉及。 **默认取值**: 不涉及。

        :param instance_name: The instance_name of this ListRestorableInstancesDetailsRequest.
        :type instance_name: str
        """
        self._instance_name = instance_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListRestorableInstancesDetailsRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
