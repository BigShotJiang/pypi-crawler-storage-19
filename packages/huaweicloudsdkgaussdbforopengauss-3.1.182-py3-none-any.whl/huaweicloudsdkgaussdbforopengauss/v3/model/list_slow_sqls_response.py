# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListSlowSqlsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total': 'int',
        'slow_sql_infos': 'list[SlowSQLInfoResult]'
    }

    attribute_map = {
        'total': 'total',
        'slow_sql_infos': 'slow_sql_infos'
    }

    def __init__(self, total=None, slow_sql_infos=None):
        r"""ListSlowSqlsResponse

        The model defined in huaweicloud sdk

        :param total: **参数解释**: 总数。 **取值范围**: 不涉及。
        :type total: int
        :param slow_sql_infos: **参数解释**: 慢SQL列表。
        :type slow_sql_infos: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.SlowSQLInfoResult`]
        """
        
        super().__init__()

        self._total = None
        self._slow_sql_infos = None
        self.discriminator = None

        if total is not None:
            self.total = total
        if slow_sql_infos is not None:
            self.slow_sql_infos = slow_sql_infos

    @property
    def total(self):
        r"""Gets the total of this ListSlowSqlsResponse.

        **参数解释**: 总数。 **取值范围**: 不涉及。

        :return: The total of this ListSlowSqlsResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListSlowSqlsResponse.

        **参数解释**: 总数。 **取值范围**: 不涉及。

        :param total: The total of this ListSlowSqlsResponse.
        :type total: int
        """
        self._total = total

    @property
    def slow_sql_infos(self):
        r"""Gets the slow_sql_infos of this ListSlowSqlsResponse.

        **参数解释**: 慢SQL列表。

        :return: The slow_sql_infos of this ListSlowSqlsResponse.
        :rtype: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.SlowSQLInfoResult`]
        """
        return self._slow_sql_infos

    @slow_sql_infos.setter
    def slow_sql_infos(self, slow_sql_infos):
        r"""Sets the slow_sql_infos of this ListSlowSqlsResponse.

        **参数解释**: 慢SQL列表。

        :param slow_sql_infos: The slow_sql_infos of this ListSlowSqlsResponse.
        :type slow_sql_infos: list[:class:`huaweicloudsdkgaussdbforopengauss.v3.SlowSQLInfoResult`]
        """
        self._slow_sql_infos = slow_sql_infos

    def to_dict(self):
        import warnings
        warnings.warn("ListSlowSqlsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListSlowSqlsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
