# Notifications for Django projects
