import logging

from django.apps import AppConfig

logger = logging.getLogger(__name__)


class NotificationsConfig(AppConfig):
    name = "notifications"

    def ready(self):
        from . import tasks  # NOQA:F401
