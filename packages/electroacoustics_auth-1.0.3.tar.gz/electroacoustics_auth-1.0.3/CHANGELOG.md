# electroacoustics v1.0.3 (2026-01-11)

## Changed

- Towncrier release log initiated. (#1)
