"""Core layer - fundamental components."""
