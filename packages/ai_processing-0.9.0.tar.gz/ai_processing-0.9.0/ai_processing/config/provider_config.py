#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: zibuyu_library
file: provider_config.py
description: 多提供方（API Key/模型）配置
--------------------------------------------
"""

from dataclasses import dataclass
from typing import Literal, Optional


@dataclass
class ProviderConfig:
    """单个提供方配置（凭据与模型信息）"""

    api_key: str
    base_url: str
    model: str
    model_type: Literal["claude", "openai", "azure"] = "openai"
    api_version: Optional[str] = None  # Azure OpenAI 需要，如 2024-08-01-preview
    name: Optional[str] = None  # 可选命名，便于日志标识
