from dataclasses import dataclass, field
from typing import Optional, Dict, Any
import os

@dataclass
class DatabaseConfig:
    """数据库配置类"""
    
    db_type: str = "sqlite"  # sqlite, postgresql, mysql, sqlserver
    
    # SQLite 配置
    database_path: Optional[str] = None
    
    # 通用配置
    host: Optional[str] = None
    port: Optional[int] = None
    database: Optional[str] = None
    user: Optional[str] = None
    password: Optional[str] = None
    
    # 连接池配置
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: int = 30
    
    # 额外选项
    extra_options:  Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_env(cls, prefix: str = "DB_") -> "DatabaseConfig":
        """从环境变量加载配置
        
        Args:
            prefix: 环境变量前缀，默认 "DB_"
            
        Returns:
            DatabaseConfig: 配置实例
            
        Examples:
            环境变量示例:
            DB_TYPE=postgresql
            DB_HOST=localhost
            DB_PORT=5432
            DB_DATABASE=mydb
            DB_USER=postgres
            DB_PASSWORD=secret
            DB_POOL_SIZE=10
        """
        db_type = os.getenv(f"{prefix}TYPE", "sqlite").lower()
        
        config = cls(db_type=db_type)
        
        # SQLite 配置
        if db_type == "sqlite":
            config.database_path = os.getenv(f"{prefix}PATH", "database.db")
        else:
            # 通用配置
            config.host = os.getenv(f"{prefix}HOST", "localhost")
            # 默认端口
            default_port = "5432" if db_type in ("postgresql", "postgres") else "3306"
            config.port = int(os.getenv(f"{prefix}PORT", default_port))
            config.database = os.getenv(f"{prefix}DATABASE", "ai_processing")
            config.user = os.getenv(f"{prefix}USER", "postgres" if db_type in ("postgresql", "postgres") else "root")
            config.password = os.getenv(f"{prefix}PASSWORD", "")
        
        # 连接池配置
        config.pool_size = int(os.getenv(f"{prefix}POOL_SIZE", "5"))
        config.max_overflow = int(os.getenv(f"{prefix}MAX_OVERFLOW", "10"))
        config.pool_timeout = int(os.getenv(f"{prefix}POOL_TIMEOUT", "30"))
        
        return config
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "db_type": self.db_type,
            "database_path": self.database_path,
            "host": self.host,
            "port": self.port,
            "database": self.database,
            "user": self.user,
            "password": self.password,
            "pool_size": self.pool_size,
            "max_overflow": self.max_overflow,
            "pool_timeout": self.pool_timeout,
            **self.extra_options
        }
    
    def validate(self) -> bool:
        """验证配置的完整性
        
        Returns:
            bool: 配置是否有效
            
        Raises:
            ValueError: 配置无效时
        """
        if self.db_type == "sqlite":
            if not self.database_path:
                raise ValueError("SQLite requires 'database_path'")
        elif self.db_type in ("postgresql", "postgres", "mysql", "mariadb"):
            if not all([self.host, self.database, self.user]):
                raise ValueError(f"{self.db_type} requires host, database, and user")
        else:
            raise ValueError(f"Unsupported database type: {self.db_type}")
        
        return True
