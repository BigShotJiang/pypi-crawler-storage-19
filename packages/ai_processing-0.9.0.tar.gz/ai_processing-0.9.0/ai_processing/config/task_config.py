"""
--------------------------------------------
project: ai_processing_framework
file: task_config.py
author: 子不语
date: 2025/11/2
--------------------------------------------
"""
from dataclasses import dataclass, field
from typing import Dict, Any
from ..monitoring.types import EventPayload

@dataclass
class TaskConfig:
    """任务特定配置"""
    prompt_template: str
    db_table: str
    db_columns: list[str]
    # 租约批量钩子（最小化 SQL 字符串）
    id_column: str = "id"
    filter_sql: str | None = None
    order_by_sql: str | None = None
    extra_params: EventPayload = field(default_factory=dict)
