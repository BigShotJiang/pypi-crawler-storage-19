"""
--------------------------------------------
project: ai_processing_framework
file: system_config.py
author: 子不语
description: 系统配置管理
--------------------------------------------
"""

from dataclasses import dataclass, field
from typing import Literal, Dict, List
from typing import Literal, Dict, List, Optional
from .provider_config import ProviderConfig
from .database_config import DatabaseConfig
from ai_processing.security.key_manager import key_manager

@dataclass
class SystemConfig:
    """系统配置类"""

    # API配置
    api_key: str = ""
    base_url: str = ""
    model: str = ""
    model: str = ""
    model_type: Literal["claude", "openai"] = "openai"
    
    # 多提供方配置
    providers: List[ProviderConfig] = field(default_factory=list)

    # 数据库配置
    database_config: Optional[DatabaseConfig] = None
    database_path: str = "database.db"

    # 并发配置
    per_task_num: int = 5
    async_num: int = 1
    task_sleep_time: int = 30
    max_concurrency_increment: int = 32

    # 提交模式配置
    commit_mode: Literal["per_item", "per_batch"] = "per_item"

    # 排空模式护栏配置（limit = -1 时生效）
    empty_rounds: int = 3
    empty_sleep_seconds: int = 2
    max_runtime_seconds: int = 60 * 60 * 17.5
    max_batches: int = 1000000
    max_items: int = 500000

    # 无成功自动终止配置
    no_success_timeout_seconds: int = 60 * 30
    no_success_grace_seconds: int = 5 * 60
    no_success_min_attempts: int = 3

    # 重试配置
    max_retries: int = 1
    timeout: int = 300
    allow_error_count: int = 3

    # 数据库自动维护配置
    auto_maintain_enabled: bool = True
    auto_maintain_dry_run: bool = False
    light_maint_interval_seconds: int = 6 * 60 * 60
    heavy_maint_quiet_timeout_seconds: int = 600
    heavy_maint_max_duration_seconds: int = 1800
    wal_max_bytes: int = 512 * 1024 * 1024
    wal_post_checkpoint_max_bytes: int = 256 * 1024 * 1024
    fragmentation_threshold: float = 0.20
    error_burst_threshold: int = 10
    maint_retry_max_attempts: int = 5
    maint_retry_base_seconds: int = 1
    revert_timeout_seconds: int = 3600

    # PRAGMA 节流配置
    pragma_default_min_interval_seconds: int = 30 * 60
    pragma_min_intervals: Dict[str, int] = field(
        default_factory=lambda: {
            "PRAGMA optimize;": 6 * 60 * 60,
            "PRAGMA quick_check;": 24 * 60 * 60,
            "PRAGMA wal_checkpoint(FULL);": 30 * 60,
            "PRAGMA wal_checkpoint(TRUNCATE);": 30 * 60,
        }
    )

    # 文件锁超时配置
    jsonl_lock_timeout_seconds: int = 5
    persistence_lock_timeout_seconds: int = 10

    # 日志配置
    log_enabled: bool = True
    log_base_path: str = "logs"

    def __post_init__(self):
        # 如果没有提供 database_config，使用 database_path 创建 SQLite 配置
        if self.database_config is None:
            self.database_config = DatabaseConfig(
                db_type="sqlite",
                database_path=self.database_path
            )
            
        if self.per_task_num < 1:
            raise ValueError("per_task_num 必须大于0")
        if self.max_retries < 0:
            raise ValueError("max_retries 不能为负数")
        if self.commit_mode not in ("per_item", "per_batch"):
            raise ValueError("commit_mode 必须是 'per_item' 或 'per_batch'")
            
        # 使用 KeyManager 处理 API Key
        if self.api_key:
            self.api_key = key_manager.get_key("API_KEY", self.api_key)
            
        # 处理 Provider 中的 API Key
        for provider in self.providers:
            if provider.api_key:
                # 尝试作为 key_name 查找 (如果看起来像环境变量名)
                if provider.api_key.isupper() and "_" in provider.api_key:
                     decrypted = key_manager.get_key(provider.api_key)
                     if decrypted:
                         provider.api_key = decrypted
                     else:
                         # 尝试直接解密值
                         provider.api_key = key_manager._decrypt_if_needed(provider.api_key)
                else:
                    # 直接解密值
                    provider.api_key = key_manager._decrypt_if_needed(provider.api_key)
