#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional
from ..monitoring.types import EventPayload

from ..core.retry_policy import RetryPolicy


@dataclass
class JsonTaskSpec:
    """
    JSON 任务规格定义
    - schema: JSON Schema (Draft 2020-12)
    - strict_mode: 严格模式（严格校验，不做宽松修复）
    - retry_policy: 重试策略（默认使用系统配置的策略时可传 None）
    - prompt_template_key: 仅输出 JSON 的提示模板键（用于从 TaskConfig 中获取）
    - postprocess: 通过校验后的后处理函数（如字段补全/类型规范化）
    """
    schema: EventPayload
    strict_mode: bool = True
    retry_policy: Optional[RetryPolicy] = None
    prompt_template_key: Optional[str] = None
    postprocess: Optional[Callable[[EventPayload], EventPayload]] = None