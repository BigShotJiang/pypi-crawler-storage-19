#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: ai_processing_framework
file: types.py
author: 子不语
description: 监控相关的类型定义
--------------------------------------------
"""

from typing import Any, Dict

EventPayload = Dict[str, Any]
MetricsPayload = Dict[str, Any]
