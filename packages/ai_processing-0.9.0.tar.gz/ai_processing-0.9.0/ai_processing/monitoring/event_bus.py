#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
内存事件总线：队列 + 后台分发线程；支持订阅器（日志/Webhook）
- 发布：publish(event_type, payload)
- 订阅：subscribe(event_type, handler)
- 监控：队列满丢弃最新，计数 on_event_dropped；投递失败计数 on_event_delivery_failure
"""

from __future__ import annotations

import queue
import threading
from dataclasses import dataclass
from time import sleep
from typing import Any, Callable, Dict, List, Optional
from .types import EventPayload


@dataclass
class Event:
    type: str
    payload: EventPayload


class InMemoryEventBus:
    def __init__(self, capacity: int = 10000, metrics_sink: Optional[object] = None) -> None:
        self._q: "queue.Queue[Event]" = queue.Queue(maxsize=max(1, capacity))
        self._subs: Dict[str, List[Callable[[EventPayload], None]]] = {}
        self._stop = threading.Event()
        self._worker: Optional[threading.Thread] = None
        self.metrics = metrics_sink

    def start(self) -> None:
        if self._worker and self._worker.is_alive():
            return
        self._stop.clear()
        self._worker = threading.Thread(target=self._run, name="event-bus", daemon=True)
        self._worker.start()

    def stop(self, drain: bool = False) -> None:
        if drain:
            self._q.join()
        self._stop.set()
        if self._worker:
            self._worker.join(timeout=1.0)

    def subscribe(self, event_type: str, handler: Callable[[EventPayload], None]) -> None:
        self._subs.setdefault(event_type, []).append(handler)

    def publish(self, event_type: str, payload: EventPayload) -> None:
        ev = Event(event_type, payload)
        try:
            self._q.put_nowait(ev)
        except queue.Full:
            if self.metrics and hasattr(self.metrics, "on_event_dropped"):
                try:
                    self.metrics.on_event_dropped({"event": event_type, "reason": "queue_full"})
                except Exception:
                    pass

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                ev = self._q.get(timeout=0.2)
            except queue.Empty:
                continue

            handlers = list(self._subs.get(ev.type, []))
            for h in handlers:
                try:
                    h(ev.payload)
                except Exception:
                    if self.metrics and hasattr(self.metrics, "on_event_delivery_failure"):
                        try:
                            self.metrics.on_event_delivery_failure({"event": ev.type})
                        except Exception:
                            pass
            try:
                self._q.task_done()
            except Exception:
                pass


class LoggingSubscriber:
    def __init__(self, logger) -> None:
        self.logger = logger

    def handle(self, payload: EventPayload) -> None:
        self.logger.info(f"event: {payload}")


class WebhookSubscriber:
    def __init__(self, endpoint: str, push_sink_factory: Callable[[str], Any]) -> None:
        self.endpoint = endpoint
        self._factory = push_sink_factory
        self._sink = self._factory(self.endpoint)
        try:
            self._sink.start()
        except Exception:
            pass

    def handle(self, payload: EventPayload) -> None:
        # 简单重试：最多3次，指数退避，失败则静默降级
        for attempt in range(3):
            try:
                self._sink.push({"event": payload})
                return
            except Exception:
                sleep(min(2.0, 2 ** attempt))
        # 最终失败：静默降级，避免影响主流程
        return
