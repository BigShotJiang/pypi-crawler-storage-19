#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
指标采集接口与简单日志实现
"""

from typing import Protocol, Dict, Any
from .types import MetricsPayload
import logging


class MetricsSink(Protocol):
    # 批次级指标/信息
    def on_batch(self, metrics: MetricsPayload) -> None:
        ...

    # 任务粒度事件/指标
    def on_task_start(self, info: MetricsPayload) -> None:
        ...

    def on_task_complete(self, info: MetricsPayload) -> None:
        ...

    def on_rate_limited(self, info: MetricsPayload) -> None:
        ...

    # JSON 校验相关指标（可选实现）
    def on_json_validation_fail(self, info: MetricsPayload) -> None:
        ...

    def on_json_validation_success(self, info: MetricsPayload) -> None:
        ...

    # 事件总线与监控扩展（可选实现）
    def on_event_dropped(self, info: MetricsPayload) -> None:
        ...

    def on_event_delivery_failure(self, info: MetricsPayload) -> None:
        ...

    # 任务控制（可选实现）
    def on_task_cancel(self, info: MetricsPayload) -> None:
        ...

    def on_task_timeout(self, info: MetricsPayload) -> None:
        ...


class LoggerMetricsSink(MetricsSink):
    def __init__(self, logger: logging.Logger) -> None:
        self.logger = logger

    def on_batch(self, metrics: MetricsPayload) -> None:
        self.logger.info(f"metrics: {metrics}")

    def on_task_start(self, info: MetricsPayload) -> None:
        self.logger.info(f"task_start: {info}")

    def on_task_complete(self, info: MetricsPayload) -> None:
        self.logger.info(f"task_complete: {info}")

    def on_rate_limited(self, info: MetricsPayload) -> None:
        self.logger.warning(f"rate_limited: {info}")

    def on_json_validation_fail(self, info: MetricsPayload) -> None:
        self.logger.warning(f"json_validation_fail: {info}")

    def on_json_validation_success(self, info: MetricsPayload) -> None:
        self.logger.info(f"json_validation_success: {info}")

    def on_event_dropped(self, info: MetricsPayload) -> None:
        self.logger.warning(f"event_dropped: {info}")

    def on_event_delivery_failure(self, info: MetricsPayload) -> None:
        self.logger.error(f"event_delivery_failure: {info}")

    def on_task_cancel(self, info: MetricsPayload) -> None:
        self.logger.warning(f"task_cancel: {info}")

    def on_task_timeout(self, info: MetricsPayload) -> None:
        self.logger.error(f"task_timeout: {info}")
