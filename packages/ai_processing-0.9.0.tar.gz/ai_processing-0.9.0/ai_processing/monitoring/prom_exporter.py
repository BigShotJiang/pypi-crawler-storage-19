#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Prometheus 指标导出端点封装
- 条件导出：根据配置决定是否启动 HTTP server
- 提供 register_default_metrics 钩子以便后续注册指标
"""

from typing import Optional, Callable

try:
    from prometheus_client import start_http_server  # type: ignore
    PROM_AVAILABLE = True
except Exception:  # pragma: no cover
    PROM_AVAILABLE = False


def start_prometheus_if_enabled(enabled: bool, port: int) -> bool:
    """在启用且依赖可用时启动导出端点，返回是否成功启动"""
    if not enabled:
        return False
    if not PROM_AVAILABLE:
        # 依赖未安装时，不抛异常，返回 False 以便上层降级到日志
        return False
    try:
        start_http_server(port)
        return True
    except Exception:
        return False


# 预留：可在此注册默认指标构造函数，供后续扩展使用
RegisterMetricsFn = Callable[[], None]
DEFAULT_REGISTER_FN: Optional[RegisterMetricsFn] = None


def register_default_metrics(fn: RegisterMetricsFn) -> None:
    global DEFAULT_REGISTER_FN
    DEFAULT_REGISTER_FN = fn
