#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
可选的 Prometheus 指标打点（无 prometheus_client 时自动降级为 no-op）。
"""
from __future__ import annotations

from typing import Optional

try:
    from prometheus_client import Counter, Histogram
except Exception:  # pragma: no cover - 环境无包时降级
    Counter = None  # type: ignore
    Histogram = None  # type: ignore


_scheduler_events: Optional[Counter] = None
_worker_events: Optional[Counter] = None
_job_duration: Optional[Histogram] = None
_task_duration: Optional[Histogram] = None


def _ensure_metrics_initialized() -> None:
    global _scheduler_events, _worker_events, _job_duration, _task_duration
    if Counter is None or Histogram is None:
        return
    if _scheduler_events is None:
        _scheduler_events = Counter(
            "aip_scheduler_events_total",
            "Scheduler events",
            labelnames=("event_type",),
        )
    if _worker_events is None:
        _worker_events = Counter(
            "aip_worker_events_total",
            "Worker events",
            labelnames=("event_type",),
        )
    if _job_duration is None:
        _job_duration = Histogram(
            "aip_job_duration_seconds",
            "Scheduler job duration",
            buckets=(0.01, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10),
        )
    if _task_duration is None:
        _task_duration = Histogram(
            "aip_task_duration_seconds",
            "Worker task duration",
            buckets=(0.01, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10),
        )


def record_scheduler_event(event_type: str) -> None:
    _ensure_metrics_initialized()
    if _scheduler_events is not None:
        _scheduler_events.labels(event_type=event_type).inc()


def observe_job_duration(seconds: float) -> None:
    _ensure_metrics_initialized()
    if _job_duration is not None:
        _job_duration.observe(max(0.0, float(seconds)))


def record_worker_event(event_type: str) -> None:
    _ensure_metrics_initialized()
    if _worker_events is not None:
        _worker_events.labels(event_type=event_type).inc()


def observe_task_duration(seconds: float) -> None:
    _ensure_metrics_initialized()
    if _task_duration is not None:
        _task_duration.observe(max(0.0, float(seconds)))
