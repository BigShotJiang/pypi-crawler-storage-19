#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
结构化 JSON 日志工具
- 提供 JSONFormatter：将日志记录为结构化 JSON（包含 metric/labels/value 等字段时也能良好展示）
- 提供 build_json_logger：快速构建输出到控制台的 JSON 日志器
"""

import json
import logging
from datetime import datetime
from typing import Any, Dict, Optional
from .types import EventPayload


class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: EventPayload = {
            "level": record.levelname,
            "time": datetime.fromtimestamp(record.created, datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
            "logger": record.name,
            "message": record.getMessage(),
        }
        # 附加额外属性
        if hasattr(record, "extra_data") and isinstance(record.extra_data, dict):
            payload.update(record.extra_data)
        return json.dumps(payload, ensure_ascii=False)


def build_json_logger(name: str = "aip", level: int = logging.INFO, handler: Optional[logging.Handler] = None) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)
    if not logger.handlers:
        stream_handler = handler or logging.StreamHandler()
        stream_handler.setFormatter(JSONFormatter())
        logger.addHandler(stream_handler)
    logger.propagate = False
    return logger
