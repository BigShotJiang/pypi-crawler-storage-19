#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""指标命名常量与建议标签集合"""

# 前缀
AIP_PREFIX = "aip_"

# Counter / Histogram / Gauge 名称（建议）
AIP_BATCHES_TOTAL = AIP_PREFIX + "batches_total"  # {task_type,status}
AIP_BATCH_DURATION_SECONDS = AIP_PREFIX + "batch_duration_seconds"  # histogram
AIP_CONCURRENCY = AIP_PREFIX + "concurrency"  # gauge

AIP_JSON_ATTEMPTS_TOTAL = AIP_PREFIX + "json_attempts_total"  # {status}
AIP_JSON_DURATION_SECONDS = AIP_PREFIX + "json_duration_seconds"  # histogram

AIP_TOKENS_TOTAL = AIP_PREFIX + "tokens_total"  # {type=prompt|completion}

AIP_EVENTS_DROPPED_TOTAL = AIP_PREFIX + "events_dropped_total"
AIP_EVENTS_DELIVERY_FAILURES_TOTAL = AIP_PREFIX + "events_delivery_failures_total"
AIP_PUSH_FAILURES_TOTAL = AIP_PREFIX + "push_failures_total"

# 建议标签集合
LABEL_TASK_TYPE = "task_type"
LABEL_STATUS = "status"
LABEL_PROVIDER = "provider"
LABEL_MODEL = "model"
LABEL_ATTEMPT = "attempt"
LABEL_BATCH_ID = "batch_id"
LABEL_TYPE = "type"
