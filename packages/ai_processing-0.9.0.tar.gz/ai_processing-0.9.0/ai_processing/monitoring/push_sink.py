#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
HTTP 指标/事件推送 Sink：后台线程推送，带指数退避与随机抖动，失败降级为日志
"""

from __future__ import annotations

import json
import queue
import random
import threading
import time
from typing import Any, Dict, Optional
from .types import EventPayload

try:
    import requests  # type: ignore
except Exception:  # pragma: no cover
    requests = None  # type: ignore


class HTTPPushSink:
    def __init__(
        self,
        endpoint: str,
        logger,
        metrics_sink: Optional[object] = None,
        timeout_seconds: float = 3.0,
        max_queue_size: int = 10000,
        max_retries: int = 3,
        backoff_base_ms: int = 400,
        backoff_jitter_ms: int = 200,
        batch_size: int = 1,
    ) -> None:
        self.endpoint = endpoint
        self.logger = logger
        self.metrics = metrics_sink
        self.timeout = timeout_seconds
        self.max_retries = max_retries
        self.backoff_base_ms = backoff_base_ms
        self.backoff_jitter_ms = backoff_jitter_ms
        self.batch_size = max(1, batch_size)
        self._q: "queue.Queue[EventPayload]" = queue.Queue(maxsize=max_queue_size)
        self._stop = threading.Event()
        self._worker: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._worker and self._worker.is_alive():
            return
        self._stop.clear()
        self._worker = threading.Thread(target=self._run, name="http-push-sink", daemon=True)
        self._worker.start()

    def stop(self, drain: bool = False) -> None:
        if drain:
            self._q.join()
        self._stop.set()
        if self._worker:
            self._worker.join(timeout=1.0)

    def push(self, data: EventPayload) -> None:
        try:
            self._q.put_nowait(data)
        except queue.Full:
            # 丢弃最新，计数并告警
            if self.metrics and hasattr(self.metrics, "on_event_dropped"):
                try:
                    self.metrics.on_event_dropped({"reason": "queue_full", "endpoint": self.endpoint})
                except Exception:
                    pass
            self.logger.warning("HTTPPushSink 队列已满，丢弃最新数据")

    def _compute_backoff(self, attempt: int) -> float:
        base = self.backoff_base_ms * (2 ** max(0, attempt - 1))
        jitter = random.randint(0, max(0, self.backoff_jitter_ms))
        return max(0.0, (base + jitter) / 1000.0)

    def _run(self) -> None:
        while not self._stop.is_set():
            items = []
            try:
                item = self._q.get(timeout=0.2)
                items.append(item)
                while len(items) < self.batch_size:
                    try:
                        items.append(self._q.get_nowait())
                    except queue.Empty:
                        break
            except queue.Empty:
                continue

            payload = items if self.batch_size > 1 else items[0]
            body = json.dumps(payload, ensure_ascii=False)

            ok = False
            for attempt in range(1, self.max_retries + 1):
                try:
                    if requests is None:
                        raise RuntimeError("requests 未安装")
                    resp = requests.post(self.endpoint, data=body.encode("utf-8"), headers={"Content-Type": "application/json"}, timeout=self.timeout)
                    if 200 <= resp.status_code < 300:
                        ok = True
                        break
                    raise RuntimeError(f"status={resp.status_code}")
                except Exception as e:
                    if attempt >= self.max_retries:
                        break
                    time.sleep(self._compute_backoff(attempt))
            # 标记队列任务完成
            for _ in items:
                try:
                    self._q.task_done()
                except Exception:
                    pass

            if not ok:
                # 失败计数 + 降级日志
                if self.metrics and hasattr(self.metrics, "on_event_delivery_failure"):
                    try:
                        self.metrics.on_event_delivery_failure({"endpoint": self.endpoint, "count": len(items)})
                    except Exception:
                        pass
                self.logger.error(f"HTTPPushSink 推送失败，endpoint={self.endpoint} items={len(items)}")
