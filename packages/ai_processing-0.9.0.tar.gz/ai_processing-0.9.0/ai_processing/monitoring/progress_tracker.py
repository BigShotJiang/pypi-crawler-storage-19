"""
--------------------------------------------
project: ai_processing_framework
file: progress_tracker.py
author: 子不语
description: 增强版进度跟踪器
--------------------------------------------
"""

import logging
import time
from typing import Union

class ProgressTracker:
    """进度跟踪器，跟踪和显示任务进度"""

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.task_name = ""  # 任务名称
        self.total_count = 0  # 总数据量
        self.limit = 0  # 处理限制
        self.start_time = 0  # 开始时间

    def initialize(self, task_name: str, total_count: int, limit: int) -> None:
        self.task_name = task_name
        self.total_count = total_count
        self.limit = limit
        self.start_time = time.time()

    def update(
        self,
        handled_count: int,
        success_count: int,
        total_tokens: int,
        per_task_num: int,
        average_time: float,
        sleep_time: int,
    ) -> None:
        total_time = time.time() - self.start_time
        remain_count = None if self.limit == -1 else (self.limit - handled_count)

        self.logger.warning(f"任务名称：【 {self.task_name} 】")
        self.logger.warning(f"已成功处理数：【 {success_count} 】")

        if remain_count is not None:
            if remain_count > 0:
                self.logger.warning(f"任务剩余数量：【 {remain_count} 】")
            else:
                self.logger.warning(f"超额任务数量：【 {abs(remain_count)} 】")
        else:
            self.logger.warning("任务剩余数量：【 不适用（无限制） 】")

        self.logger.warning(f"单次处理数量：【 {per_task_num} 】")
        self.logger.warning(f"已消耗时间：【 {self.format_time(total_time)} 】")
        self.logger.warning(f"已消耗tokens数：【 {total_tokens} 】")

        if handled_count > 0:
            avg_tokens = int(total_tokens / handled_count)
            self.logger.warning(f"平均单次消耗tokens数量：【 {avg_tokens} 】")
            self.logger.warning(f"平均单次消耗时间：【 {self.format_time(average_time)} 】")

            if self.limit != -1 and self.limit > 0:
                est_total_tokens = int(total_tokens / handled_count * self.limit)
                self.logger.warning(f"预计任务总tokens数量：【 {est_total_tokens} 】")

                if handled_count < self.limit:
                    est_total_time = self.limit / handled_count * total_time
                    est_remaining_time = (
                        (self.limit - handled_count) / handled_count * total_time
                    )
                    self.logger.warning(f"预计任务总耗时：【 {self.format_time(est_total_time)} 】")
                    self.logger.warning(
                        f"预计任务剩余耗时：【 {self.format_time(est_remaining_time)} 】"
                    )

                progress = round((handled_count / self.limit * 100), 2)
                self.logger.warning(f"任务完成进度：【 {progress}% 】")
            else:
                self.logger.warning("任务总量/剩余耗时/进度：【 不适用（无限制） 】")

        self.logger.warning(f"暂停 {sleep_time} 秒中...")

    @staticmethod
    def format_time(second_time: Union[int, float]) -> str:
        # 临时的 format_time 实现
        m, s = divmod(second_time, 60)
        h, m = divmod(m, 60)
        return f"{int(h):02d}:{int(m):02d}:{int(s):02d}"

