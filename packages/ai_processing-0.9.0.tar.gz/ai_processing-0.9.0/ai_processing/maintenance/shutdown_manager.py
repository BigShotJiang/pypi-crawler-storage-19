"""
--------------------------------------------
project: ai_processing_framework
file: shutdown_manager.py
author: 子不语
date: 2025/11/09
description: 跨线程优雅关机协调器（Ctrl+C / IDE 停止 / 控制台事件）
--------------------------------------------
"""

import threading
import time
from typing import Optional

# 可选依赖的导入在方法内进行，避免非支持平台报错

class ShutdownManager:
    """
    全局单例的关机协调器。
    - 将外部停止请求（信号/控制台事件/退出钩子）转换为“关机请求”标志；
    - 由执行器在领取新批次前检查该标志，完成当前批次后退出；
    - 支持跨线程安全访问；
    - 提供统一的安装方法，将项目层面的处理内聚到基础设施层。
    """

    _instance: Optional["ShutdownManager"] = None
    _lock = threading.Lock()

    def __init__(self) -> None:
        self._event = threading.Event()
        self.reason: Optional[str] = None
        self.request_time: Optional[float] = None
        self._handlers_installed: bool = False
        self._handlers_lock = threading.Lock()
        # 持有回调引用，防止被 GC
        self._win_handler_ref = None

    @classmethod
    def get_instance(cls) -> "ShutdownManager":
        with cls._lock:
            if cls._instance is None:
                cls._instance = ShutdownManager()
            return cls._instance

    def request_shutdown(self, reason: str = "SIGINT") -> None:
        if not self._event.is_set():
            self.reason = reason
            self.request_time = time.time()
            self._event.set()

    def is_shutdown(self) -> bool:
        return self._event.is_set()

    def wait(self, timeout: Optional[float] = None) -> bool:
        return self._event.wait(timeout)

    def install_handlers(self, logger) -> None:
        """
        在项目内部统一安装停止信号、Windows 控制台事件与 atexit 兜底。
        - 仅安装一次；重复调用会被忽略。
        - 不抛出致命异常，尽最大可能注册可用处理器。
        """
        with self._handlers_lock:
            if self._handlers_installed:
                return
            self._handlers_installed = True

        # 统一信号处理器
        def _signal_handler(signum, frame):
            try:
                reason = "SIGINT"
                try:
                    import signal as _sig
                    if signum == getattr(_sig, "SIGTERM", None):
                        reason = "SIGTERM"
                    elif signum == getattr(_sig, "SIGBREAK", None):
                        reason = "SIGBREAK"
                except Exception:
                    pass
                self.request_shutdown(reason)
            finally:
                try:
                    logger.warning("收到停止信号：进入优雅关机模式（将完成当前批次后退出）")
                except Exception:
                    pass

        # 注册常见信号（按平台可用性）
        try:
            import signal
            for _sig_name in ("SIGINT", "SIGTERM", "SIGBREAK"):
                try:
                    if hasattr(signal, _sig_name):
                        signal.signal(getattr(signal, _sig_name), _signal_handler)
                except Exception:
                    pass
        except Exception:
            pass

        # atexit 兜底：在可捕获的正常退出路径上设置关机标志
        try:
            import atexit

            @atexit.register
            def _graceful_exit_atexit():
                try:
                    self.request_shutdown("atexit")
                except Exception:
                    pass
        except Exception:
            pass

        # Windows 控制台事件处理：尽可能覆盖 IDE 停止的场景
        try:
            import sys
            if sys.platform.startswith("win"):
                import ctypes
                import ctypes.wintypes as wt

                HandlerRoutine = ctypes.WINFUNCTYPE(wt.BOOL, wt.DWORD)
                kernel32 = ctypes.windll.kernel32

                CTRL_C_EVENT = 0
                CTRL_BREAK_EVENT = 1
                CTRL_CLOSE_EVENT = 2
                CTRL_LOGOFF_EVENT = 5
                CTRL_SHUTDOWN_EVENT = 6

                def _console_ctrl_handler(ctrl_type: int) -> bool:
                    reason_map = {
                        CTRL_C_EVENT: "CTRL_C_EVENT",
                        CTRL_BREAK_EVENT: "CTRL_BREAK_EVENT",
                        CTRL_CLOSE_EVENT: "CTRL_CLOSE_EVENT",
                        CTRL_LOGOFF_EVENT: "CTRL_LOGOFF_EVENT",
                        CTRL_SHUTDOWN_EVENT: "CTRL_SHUTDOWN_EVENT",
                    }
                    reason = reason_map.get(ctrl_type, f"CTRL_{ctrl_type}")
                    try:
                        self.request_shutdown(reason)
                        try:
                            logger.warning("收到控制台事件：%s，进入优雅关机模式（完成当前批次后退出）", reason)
                        except Exception:
                            pass
                    except Exception:
                        pass
                    # 返回 True 尝试声明事件已处理，具体行为由宿主决定
                    return True

                # 必须持有回调的引用，否则会被 GC，导致处理器失效
                self._win_handler_ref = HandlerRoutine(_console_ctrl_handler)
                kernel32.SetConsoleCtrlHandler(self._win_handler_ref, True)
        except Exception:
            pass
