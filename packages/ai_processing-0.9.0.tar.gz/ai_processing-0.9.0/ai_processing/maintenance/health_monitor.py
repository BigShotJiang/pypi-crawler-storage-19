#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: ai_processing_framework
file: health_monitor.py
author: 子不语
description: 数据库健康监控器
--------------------------------------------
"""

import asyncio
import logging
import os
import time
from typing import Dict, Any
from ..monitoring.types import MetricsPayload

# 注意：这些导入将在后续步骤中得到满足
from ..config.system_config import SystemConfig
from ..infrastructure.database_adapter import DatabaseAdapter
from ..utils import write_jsonl
from .scheduler import MaintenanceScheduler

class HealthMonitor:
    """数据库健康监控器，定期采样指标并触发维护任务。"""

    def __init__(
        self,
        config: "SystemConfig",
        db_adapter: "DatabaseAdapter",
        scheduler: MaintenanceScheduler,
        logger: logging.Logger,
    ):
        self.config = config
        self.db_adapter = db_adapter
        self.scheduler = scheduler
        self.logger = logger
        self.running = False
        self._last_analyze_time = 0
        self._last_heavy_maint_time = 0

        # 状态跟踪，用于判断指标是否“持续”超过阈值
        self._wal_exceed_start_time = 0
        self._frag_exceed_start_time = 0

    async def start(self):
        """启动监控循环。"""
        if not self.config.auto_maintain_enabled:
            self.logger.info("数据库自动维护功能已禁用，HealthMonitor 不启动。")
            return

        self.running = True
        self.logger.info("数据库健康监控器已启动，采样周期: 60s。")
        while self.running:
            try:
                await self.check_and_maintain()
            except Exception as e:
                self.logger.error(f"健康监控检查失败: {e}", exc_info=True)
            await asyncio.sleep(60)  # 每60秒采样一次

    def stop(self):
        """停止监控循环。"""
        self.running = False
        self.logger.info("数据库健康监控器正在停止...")

    async def check_and_maintain(self):
        """执行一次健康检查和维护决策。"""
        metrics = await self.collect_metrics()
        if not metrics:
            return

        self._log_metrics(metrics)

        if self.config.auto_maintain_dry_run:
            self.logger.info("[Dry Run] 正在评估维护需求...")

        now = time.time()

        if metrics["wal_size"] > self.config.wal_max_bytes:
            if self._wal_exceed_start_time == 0:
                self._wal_exceed_start_time = now
            if now - self._wal_exceed_start_time >= 600:
                self.logger.warning(f"WAL 文件大小 ({metrics['wal_size_mb']:.2f}MB) 持续超过阈值，触发 checkpoint。")
                await self.scheduler.schedule_light_maintenance("wal_checkpoint")
                self._wal_exceed_start_time = 0
        else:
            self._wal_exceed_start_time = 0

        if metrics["fragmentation_ratio"] > self.config.fragmentation_threshold:
            if self._frag_exceed_start_time == 0:
                self._frag_exceed_start_time = now
            if now - self._frag_exceed_start_time >= 600:
                self.logger.warning(f"数据库碎片率 ({metrics['fragmentation_ratio']:.2%}) 持续超过阈值，触发重维护。")
                await self.scheduler.schedule_heavy_maintenance("vacuum")
                self._frag_exceed_start_time = 0
        else:
            self._frag_exceed_start_time = 0

        error_count = self.db_adapter.get_recent_busy_errors(15 * 60)
        if error_count >= self.config.error_burst_threshold:
            self.logger.warning(f"最近15分钟内数据库繁忙/锁定错误达到 {error_count} 次，超过阈值，触发轻量维护。")
            await self.scheduler.schedule_light_maintenance("optimize")

        if now - self._last_analyze_time > self.config.light_maint_interval_seconds:
            self.logger.info("执行例行轻量级维护 (ANALYZE)。")
            await self.scheduler.schedule_light_maintenance("analyze")
            self._last_analyze_time = now

    async def collect_metrics(self) -> MetricsPayload:
        """采集所有相关的数据库健康指标（非阻塞）。"""
        try:
        try:
            metrics = await asyncio.to_thread(self.db_adapter.collect_metrics)
            
            if not metrics:
                return None
                
            quick_check = metrics.get("quick_check", "ok")

            if quick_check != 'ok':
                self.logger.error(f"数据库 quick_check 失败，返回: {quick_check}。暂停所有维护活动！")
                self.scheduler.pause_all_maintenance()
                return None

            # Add timestamp and busy errors which are tracked by adapter
            metrics["timestamp"] = time.time()
            metrics["busy_errors_last_15m"] = self.db_adapter.get_recent_busy_errors(15 * 60)
            
            return metrics
        except Exception as e:
            self.logger.error(f"采集数据库指标失败: {e}", exc_info=True)
            return None

    def _log_metrics(self, metrics: MetricsPayload):
        """将指标以jsonl格式写入日志文件。"""
        log_path = os.path.join(self.config.log_base_path or 'log', 'maintenance.jsonl')
        try:
            write_jsonl(log_path, [metrics], lock_timeout=self.config.jsonl_lock_timeout_seconds)
        except Exception as e:
            self.logger.error(f"写入维护指标日志失败: {e}")
