#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: ai_processing_framework
file: scheduler.py
author: 子不语
description: 数据库维护任务调度器
--------------------------------------------
"""

import asyncio
import logging
import time
import os

# 注意：这些导入将在后续步骤中得到满足
# from ..config import SystemConfig
# from ..infrastructure import DatabaseAdapter
from .coordinator import MaintenanceCoordinator

class MaintenanceScheduler:
    """管理和执行数据库维护任务的调度器。"""

    def __init__(
        self,
        config: "SystemConfig",
        db_adapter: "DatabaseAdapter",
        coordinator: MaintenanceCoordinator,
        logger: logging.Logger,
    ):
        self.config = config
        self.db_adapter = db_adapter
        self.coordinator = coordinator
        self.logger = logger
        self.task_queue = asyncio.Queue()
        self.running = False
        self._maintenance_lock = asyncio.Lock()  # 确保同一时间只有一个维护任务在执行
        self._paused = False # 紧急暂停开关

    async def start(self):
        """启动调度器，处理维护任务队列。"""
        if not self.config.auto_maintain_enabled:
            self.logger.info("数据库自动维护功能已禁用，MaintenanceScheduler 不启动。")
            return

        self.running = True
        self.logger.info("数据库维护调度器已启动。")
        while self.running:
            try:
                task_type, task_name = await self.task_queue.get()
                if task_type is None:
                    break

                if self.config.auto_maintain_dry_run:
                    self.logger.info(f"[Dry Run] 收到维护任务 '{task_name}'，但不执行。")
                    self.task_queue.task_done()
                    continue

                if self._paused:
                    self.logger.warning(f"调度器当前处于暂停状态，忽略任务 '{task_name}'。")
                    self.task_queue.task_done()
                    continue

                async with self._maintenance_lock:
                    if task_type == "light":
                        await self._run_light_maintenance(task_name)
                    elif task_type == "heavy":
                        await self._run_heavy_maintenance(task_name)
                self.task_queue.task_done()
            except asyncio.CancelledError:
                self.logger.info("维护调度器被取消。")
                break
            except Exception as e:
                self.logger.error(f"处理维护任务时发生错误: {e}", exc_info=True)

    def stop(self):
        """停止调度器。""" 
        self.running = False
        self.task_queue.put_nowait((None, None))
        self.logger.info("数据库维护调度器正在停止...")

    def pause_all_maintenance(self):
        """紧急暂停所有维护活动。"""
        self.logger.warning("已触发紧急暂停，所有新的维护任务将被忽略！")
        self._paused = True

    async def schedule_light_maintenance(self, task_name: str):
        """安排一个轻量级维护任务。"""
        await self.task_queue.put(("light", task_name))

    async def schedule_heavy_maintenance(self, task_name: str):
        """安排一个重量级维护任务。"""
        await self.task_queue.put(("heavy", task_name))

    async def _run_light_maintenance(self, task_name: str):
        """执行轻量级维护操作（非阻塞）。"""
        self.logger.info(f"开始执行轻量维护任务: {task_name}")
        start_time = time.time()
        try:
            if task_name == "wal_checkpoint":
                await asyncio.to_thread(self.db_adapter.perform_maintenance, "checkpoint")
                
                # WAL size check is now part of metrics collection, but here we need it immediately
                # We can use collect_metrics to get the size
                metrics = await asyncio.to_thread(self.db_adapter.collect_metrics)
                post_size = metrics.get("wal_size", 0)

                if post_size > self.config.wal_post_checkpoint_max_bytes:
                    self.logger.warning(f"wal_checkpoint 后，WAL 文件大小 ({post_size / 1024**2:.2f}MB) 仍大于阈值，可能需要重维护。")
                    await self.schedule_heavy_maintenance("vacuum_due_to_wal")

            elif task_name == "optimize":
                await asyncio.to_thread(self.db_adapter.perform_maintenance, "optimize")
            elif task_name == "analyze":
                await asyncio.to_thread(self.db_adapter.perform_maintenance, "analyze")
            else:
                self.logger.warning(f"未知的轻量维护任务: {task_name}")
            
            duration = time.time() - start_time
            self.logger.info(f"轻量维护任务 {task_name} 完成，耗时 {duration:.2f} 秒。")
        except Exception as e:
            self.logger.error(f"执行轻量维护任务 {task_name} 失败: {e}", exc_info=True)

    async def _run_heavy_maintenance(self, task_name: str):
        """执行重量级维护操作，包含暂停和恢复执行器的逻辑。"""
        self.logger.info(f"准备执行重维护任务: {task_name}。将尝试暂停业务执行器。")
        start_time = time.time()

        # 1. 请求暂停
        success = await self.coordinator.pause_for_maintenance(
            quiet_timeout_seconds=self.config.heavy_maint_quiet_timeout_seconds
        )
        if not success:
            self.logger.error("未能获取安静窗口，跳过重维护")
            return

        self.logger.info("业务执行器已成功暂停，开始执行维护操作。")

        try:
            # 2. 执行维护，带重试逻辑
            await self._execute_with_retry(task_name)

            # 3. 维护后操作（非阻塞）
            # Checkpoint is usually good after heavy maintenance
            await asyncio.to_thread(self.db_adapter.perform_maintenance, "checkpoint")
            
            # Quick check via metrics
            metrics = await asyncio.to_thread(self.db_adapter.collect_metrics)
            check_result = metrics.get("quick_check", "ok")
            if check_result != 'ok':
                self.logger.error(f"重维护后 quick_check 失败: {check_result}！")

            duration = time.time() - start_time
            self.logger.info(f"重维护任务 {task_name} 完成，总耗时 {duration:.2f} 秒。")

        except Exception as e:
            self.logger.error(f"执行重维护任务 {task_name} 期间发生严重错误: {e}", exc_info=True)
        finally:
            # 4. 确保恢复执行器
            await self.coordinator.resume_after_maintenance()
            self.logger.info("业务执行器已恢复。")

    async def _execute_with_retry(self, task_name: str):
        """带指数退避重试的执行逻辑。"""
        for attempt in range(self.config.maint_retry_max_attempts):
            try:
                if task_name.startswith("vacuum"):
                    await asyncio.wait_for(
                        asyncio.to_thread(self.db_adapter.perform_maintenance, "vacuum"),
                        timeout=self.config.heavy_maint_max_duration_seconds
                    )
                elif task_name == "reindex":
                     await asyncio.wait_for(
                        asyncio.to_thread(self.db_adapter.perform_maintenance, "reindex"),
                        timeout=self.config.heavy_maint_max_duration_seconds
                    )
                else:
                    self.logger.warning(f"未知的重维护任务: {task_name}")
                return  # 成功则退出循环
            except asyncio.TimeoutError:
                self.logger.error(f"重维护任务 '{task_name}' 执行超时（超过 {self.config.heavy_maint_max_duration_seconds} 秒）！")
                break # 超时后不再重试
            except Exception as e:
                if "locked" in str(e) or "busy" in str(e):
                    if attempt < self.config.maint_retry_max_attempts - 1:
                        wait_time = self.config.maint_retry_base_seconds * (2 ** attempt)
                        self.logger.warning(f"执行 '{task_name}' 时数据库繁忙，将在 {wait_time} 秒后重试... (尝试 {attempt + 1}/{self.config.maint_retry_max_attempts})")
                        await asyncio.sleep(wait_time)
                    else:
                        self.logger.error(f"执行 '{task_name}' 因数据库持续繁忙而最终失败。")
                        raise
                else:
                    raise # 其他类型的异常直接抛出
