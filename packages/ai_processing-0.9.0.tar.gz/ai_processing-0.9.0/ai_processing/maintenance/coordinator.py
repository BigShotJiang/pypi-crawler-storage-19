#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: ai_processing_framework
file: coordinator.py
author: 子不语
description: 维护窗口协调器
--------------------------------------------
"""

import asyncio
import logging

class MaintenanceCoordinator:
    """为单个事件循环协调业务执行器和维护任务。"""

    def __init__(self, logger: logging.Logger):
        """
        使用 asyncio 同步原语初始化协调器。
        """
        self.logger = logger
        # 此事件控制 AsyncExecutor 是否可以领取新任务。
        # Set (绿灯): 执行器可以领取新批次。
        # Clear (红灯): 执行器必须暂停并等待。
        self.can_claim_event = asyncio.Event()
        self.can_claim_event.set()  # 默认为绿灯 (允许领取)

        self._active_workers = 0
        self._state_lock = asyncio.Lock()

    async def pause_for_maintenance(self, quiet_timeout_seconds: int = 600) -> bool:
        """
        请求暂停以进行维护。

        此方法将：
        1. 清除事件，以示执行器停止领取新任务。
        2. 等待所有活跃的工作者完成其当前批次。

        返回:
            如果在超时内系统变为空闲，则返回 True，否则返回 False。
        """
        # 1. 发出信号，让执行器停止领取新任务 (红灯)
        self.logger.info("请求暂停业务执行器以进行维护...")
        self.can_claim_event.clear()

        # 2. 等待所有活跃的工作者完成
        deadline = asyncio.get_running_loop().time() + quiet_timeout_seconds
        while asyncio.get_running_loop().time() < deadline:
            async with self._state_lock:
                if self._active_workers == 0:
                    self.logger.info("所有活跃工作者均已完成，系统进入安静状态。")
                    return True
            await asyncio.sleep(0.5)

        # 如果到达这里，说明超时了。我们必须恢复，以防系统被永久阻塞。
        self.logger.warning(f"等待安静窗口超时 ({quiet_timeout_seconds}秒)，维护被取消。")
        self.can_claim_event.set()
        return False

    async def resume_after_maintenance(self):
        """
        维护完成后，通过设置事件来恢复正常操作。
        """
        self.logger.info("维护完成，恢复业务执行器。")
        self.can_claim_event.set()

    async def worker_enter(self):
        """
        由执行器在开始处理批处理之前调用。
        增加活跃工作者计数。
        """
        async with self._state_lock:
            self._active_workers += 1

    async def worker_exit(self):
        """
        由执行器在完成批处理后调用。
        减少活跃工作者计数。
        """
        async with self._state_lock:
            if self._active_workers > 0:
                self._active_workers -= 1
