"""
--------------------------------------------
project: ai_processing_framework
file: maintenance_scheduler.py
author: 子不语
date: 2025/11/2
--------------------------------------------
"""
import asyncio
import logging
from typing import Callable

class MaintenanceScheduler:
    """后台维护任务调度器"""

    def __init__(
        self,
        maintenance_fn: Callable[[], None],
        interval_seconds: int,
        logger: logging.Logger,
    ):
        self.maintenance_fn = maintenance_fn
        self.interval = interval_seconds
        self.logger = logger
        self._task = None

    def start(self):
        """启动调度器"""
        if not self._task:
            self._task = asyncio.create_task(self._run())

    def stop(self):
        """停止调度器"""
        if self._task:
            self._task.cancel()
            self._task = None

    async def _run(self):
        """调度器主循环"""
        while True:
            try:
                await asyncio.sleep(self.interval)
                self.logger.info("开始执行后台维护任务...")
                if asyncio.iscoroutinefunction(self.maintenance_fn):
                    await self.maintenance_fn()
                else:
                    self.maintenance_fn()
                self.logger.info("后台维护任务执行完毕。")
            except asyncio.CancelledError:
                self.logger.info("后台维护调度器已停止。")
                break
            except Exception as e:
                self.logger.error("后台维护任务执行失败", exc_info=True)
