#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
并发策略插件（Concurrency Strategies）

该模块定义了并发调节的插件式接口与一组内置策略，供执行器在运行期
根据上一次批次的结果（成功/失败/限流等）动态调整 `per_task_num`。

核心概念
- ConcurrencyStrategy：一个协议（接口），暴露 `compute_next_per_task_num(context, last_batch_stats)`
  - context：`TaskContext`，包含本轮外部可见的运行时状态，如 `per_task_num_snapshot`、
    `concurrent_cumulative_quantity`、`rate_limited` 等
  - last_batch_stats：上一批执行的统计数据，至少包含：
    - `batch_size`：上一批处理的条目数
    - `success_count`：上一批成功的条目数

内置策略
- FixedConcurrency(fixed_value: int)
  - 固定并发，不随批次结果变化
- ExponentialIncreaseOnSuccess(base_increase: int = 1)
  - 上一批全部成功时提升并发，否则保持不变
  - 增量与 `TaskContext.concurrent_cumulative_quantity` 挂钩（呈指数式累积）
- DecreaseOnRateLimited()
  - 如果出现速率限制（`context.rate_limited=True`），则在上一轮并发基础上减 1
- ExponentialBackoff(
    decrease_rate: float = 0.5,
    increase_on_full_success: bool = True,
    min_per_task: int = 1,
    max_per_task: Optional[int] = None,
    failure_threshold_ratio: float = 0.0,
  )
  - 指数退避：当限流或成功率低于阈值时按比例退避；全部成功时小幅提升；其余保持

配置与工厂
- 使用 `build_strategy(name, params)` 根据名称+参数构建策略实例
  - 支持的名称别名：
    - "fixed", "fixed_concurrency"
    - "exp_increase", "exponential_increase", "exponential_increase_on_success"
    - "decrease_on_rate_limited", "rate_limit_decrease"
    - "backoff", "exponential_backoff", "exp_backoff"

与执行器协作
- `AsyncExecutor` 将在每轮批次开始时记录 `context.per_task_num_snapshot`
- 批次完成后调用策略计算下一轮 `per_task_num`
- 限流出现时优先以策略为准，失败则回退到内置降档逻辑

示例
>>> # 代码显式传入策略
>>> strategy = ExponentialBackoff(decrease_rate=0.6, max_per_task=32)
>>> executor = AsyncExecutor(..., concurrency_strategy=strategy)

>>> # 配置化方式（无需传入实例）
>>> config = SystemConfig(
...     ..., concurrency_strategy_name="exponential_backoff",
...     concurrency_strategy_params={"decrease_rate": 0.6, "max_per_task": 32},
... )
>>> executor = AsyncExecutor(config=config, ...)
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, Optional, Dict, Any


class ConcurrencyStrategy(Protocol):
    def compute_next_per_task_num(self, context, last_batch_stats: dict) -> int:
        """
        计算下一轮的 `per_task_num`。

        参数
        - context：TaskContext，需至少包含：
          - per_task_num_snapshot：上一轮生效的并发值
          - concurrent_cumulative_quantity：并发累计量（用于加速增长）
          - rate_limited：是否触发了速率限制
        - last_batch_stats：上一批统计信息，如：
          - batch_size：上一批数量
          - success_count：上一批成功数量

        返回值
        - 下一轮 `per_task_num`（需>=1）
        """
        ...


@dataclass
class FixedConcurrency:
    """
    固定并发策略：
    - 无论上一批的执行结果如何，始终返回固定的并发值

    参数
    - fixed_value：固定并发值（>=1）
    """
    fixed_value: int
    def compute_next_per_task_num(self, context, last_batch_stats: dict) -> int:
        return max(1, int(self.fixed_value))


@dataclass
class ExponentialIncreaseOnSuccess:
    """
    成功指数提升策略：
    - 当上一批全部成功时，按指数方式（结合 `concurrent_cumulative_quantity`）提升并发
    - 否则保持不变

    参数
    - base_increase：基础增量（预留参数，当前实现以 `concurrent_cumulative_quantity` 为主）
    """
    base_increase: int = 1
    def compute_next_per_task_num(self, context, last_batch_stats: dict) -> int:
        prev = max(1, int(getattr(context, "per_task_num_snapshot", 1)))
        total = int(last_batch_stats.get("batch_size", 0))
        success = int(last_batch_stats.get("success_count", 0))
        if success >= total and total > 0:
            inc = max(1, int(getattr(context, "concurrent_cumulative_quantity", 1)))
            return prev + inc
        return prev


@dataclass
class DecreaseOnRateLimited:
    """
    限流降档策略：
    - 若触发速率限制（`context.rate_limited=True`），则在上一轮基础上 `-1`
    - 否则保持不变
    """
    def compute_next_per_task_num(self, context, last_batch_stats: dict) -> int:
        prev = max(1, int(getattr(context, "per_task_num_snapshot", 1)))
        if getattr(context, "rate_limited", False):
            return max(1, prev - 1)
        return prev


@dataclass
class ExponentialBackoff:
    """
    指数退避策略：
    - 当限流或成功率过低时，按比例降低并发（乘以 `decrease_rate`，并结合 `min_per_task/max_per_task`）
    - 当上一批全部成功时，小幅提升并发（结合 `concurrent_cumulative_quantity`）
    - 其余情况保持不变

    参数
    - decrease_rate：退避比例（0-1），数值越小，退避越激进
    - increase_on_full_success：是否在全成功时尝试提升
    - min_per_task：最小并发下限
    - max_per_task：最大并发上限（None 表示不限制）
    - failure_threshold_ratio：成功率阈值，若 success/total <= 阈值则退避
    """
    decrease_rate: float = 0.5  # 退避比例（0-1）
    increase_on_full_success: bool = True
    min_per_task: int = 1
    max_per_task: Optional[int] = None
    failure_threshold_ratio: float = 0.0  # 成功率小于等于该阈值则退避

    def compute_next_per_task_num(self, context, last_batch_stats: dict) -> int:
        prev = max(1, int(getattr(context, "per_task_num_snapshot", 1)))
        total = int(last_batch_stats.get("batch_size", 0))
        success = int(last_batch_stats.get("success_count", 0))
        success_ratio = (success / total) if total > 0 else 1.0

        # 限流或成功率过低 -> 退避
        if getattr(context, "rate_limited", False) or success_ratio <= self.failure_threshold_ratio:
            next_val = max(self.min_per_task, int(max(1, prev) * max(0.1, min(self.decrease_rate, 0.99))))
        # 全部成功 -> 小幅提升
        elif self.increase_on_full_success and total > 0 and success == total:
            inc = max(1, int(getattr(context, "concurrent_cumulative_quantity", 1)))
            next_val = prev + inc
        else:
            next_val = prev

        if self.max_per_task is not None:
            next_val = min(next_val, int(self.max_per_task))
        return max(self.min_per_task, int(next_val))


def build_strategy(name: str, params: Optional[Dict[str, Any]] = None) -> ConcurrencyStrategy:
    """
    根据名称与参数构建并发策略实例。

    参数
    - name：策略名称或别名，如 "fixed"、"exponential_backoff"
    - params：传递给策略构造函数的参数字典

    返回
    - 一个实现了 ConcurrencyStrategy 协议的实例

    兼容性
    - 未知名称将回退到 `ExponentialIncreaseOnSuccess`，保证执行不中断
    """
    params = params or {}
    key = (name or "").strip().lower()
    if key in ("fixed", "fixed_concurrency"):
        return FixedConcurrency(**params)  # expects fixed_value
    if key in ("exp_increase", "exponential_increase", "exponential_increase_on_success"):
        return ExponentialIncreaseOnSuccess(**params)
    if key in ("decrease_on_rate_limited", "rate_limit_decrease"):
        return DecreaseOnRateLimited(**params)  # no params required
    if key in ("backoff", "exponential_backoff", "exp_backoff"):
        return ExponentialBackoff(**params)
    # 默认回退到指数提升策略，避免中断
    return ExponentialIncreaseOnSuccess(**params)
