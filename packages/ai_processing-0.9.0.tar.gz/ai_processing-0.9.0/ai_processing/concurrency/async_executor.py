"""
--------------------------------------------
project: ai_processing_framework
file: async_executor.py
author: 子不语
date: 2025/11/09
description: 增强版异步执行器
--------------------------------------------
"""

import asyncio
import logging
import time
from typing import Any, Callable, List, Tuple

# 注意：这些导入将在后续步骤中得到满足
# from ..config import SystemConfig
# from ..core.base_task_processor import BaseTaskProcessor
# from ..core.task_context import TaskContext
# from ..infrastructure import DatabaseAdapter, PersistenceManager
# from ..monitoring import ProgressTracker
# from ..maintenance.coordinator import MaintenanceCoordinator
# from ..maintenance.shutdown_manager import ShutdownManager

class AsyncExecutor:
    """异步执行器，管理批量任务的异步执行"""

    def __init__(
        self,
        config: Any, # SystemConfig
        processor: Any, # BaseTaskProcessor
        db_adapter: Any, # DatabaseAdapter
        context: Any, # TaskContext
        persistence: Any, # PersistenceManager
        progress_tracker: Any, # ProgressTracker
        logger: logging.Logger,
        coordinator: Any,  # MaintenanceCoordinator
    ):
        self.config = config
        self.processor = processor
        self.db_adapter = db_adapter
        self.context = context
        self.persistence = persistence
        self.progress_tracker = progress_tracker
        self.logger = logger
        self.coordinator = coordinator
        self.per_task_num = config.per_task_num
        self.task_sleep_time = config.task_sleep_time

    async def execute_task(self, task_type: str, limit: int = 0) -> None:
        filter_condition = None
        try:
            mode, limit, total_count, filter_condition = (
                await self._initialize_task_execution(task_type, limit)
            )
            await self._main_processing_loop(
                task_type, mode, limit, total_count, filter_condition
            )
        except asyncio.CancelledError:
            self.logger.warning("任务被取消，正在进行最后的清理...")
            await self._handle_cancellation(task_type)
            raise
        except Exception as e:
            self.logger.error(
                f"执行任务【{task_type}】时发生未处理的异常: {e}", exc_info=True
            )
            await self._handle_exception(task_type)
            raise
        finally:
            if filter_condition is not None:
                await self._finalize_task_execution(task_type, filter_condition)

    async def _initialize_task_execution(self, task_type: str, limit: int):
        from ..utils import format_time as format_time_util
        # format_time_util = lambda x: str(x)
        
        self._load_exclude_data(task_type)

        model_class = self.processor.get_model_class()
        filter_condition = self.processor.get_filter_condition(task_type)
        total_count = await self.db_adapter.count(model_class, filter_condition)

        mode = "snapshot" if limit == 0 else ("drain" if limit == -1 else "bounded")
        if mode == "snapshot":
            limit = total_count
        elif mode == "bounded" and limit > total_count:
            limit = total_count

        self.progress_tracker.initialize(
            task_type,
            total_count if mode != "drain" else -1,
            limit if mode != "drain" else -1,
        )
        self.logger.info(
            f"开始执行【{task_type}】任务，模式：{mode}，需处理的数据总量是：【{total_count}】"
        )

        self.logger.info(
            f"提交模式：{self.config.commit_mode}（per_item=每条提交，per_batch=批次提交）"
        )

        if mode == "drain":
            self.logger.info(
                "排空模式护栏：empty_rounds=%s, empty_sleep=%s（%s）, max_runtime=%s（%s）, max_batches=%s, max_items=%s",
                self.config.empty_rounds,
                self.config.empty_sleep_seconds,
                format_time_util(self.config.empty_sleep_seconds),
                self.config.max_runtime_seconds,
                format_time_util(self.config.max_runtime_seconds),
                self.config.max_batches,
                self.config.max_items,
            )
        return mode, limit, total_count, filter_condition

    async def _main_processing_loop(
        self,
        task_type: str,
        mode: str,
        limit: int,
        total_count: int,
        filter_condition: Any,
    ):
        max_id, handled_count, batches_count, empty_counter = 0, 0, 0, 0
        time_list = []
        worker_id = f"worker_{id(self)}"
        start_time = last_success_time = time.time()
        no_success_attempts = 0

        while (mode != "drain" and handled_count < limit) or (mode == "drain"):
            single_start_time = time.time()

            if await self._perform_pre_batch_checks():
                break

            batch_items = await self._fetch_data_batch(
                task_type, filter_condition, max_id, handled_count, worker_id
            )

            if not batch_items:
                if await self._handle_empty_batch(mode, empty_counter):
                    break
                else:
                    empty_counter += 1
                    continue
            empty_counter = 0

            batch_max_id = max(item.id for item in batch_items)
            self.logger.info(
                f"【{task_type}】批次领取完成：batch_size={len(batch_items)}，当前并发={self.per_task_num}"
            )

            success_count = await self._process_batch_concurrently(
                task_type, batch_items
            )

            if len(batch_items) > 0:
                if success_count > 0:
                    last_success_time = time.time()
                    no_success_attempts = 0
                else:
                    no_success_attempts += 1

            now_time = time.time()
            time_list.append(now_time - single_start_time)
            handled_count += len(batch_items)
            batches_count += 1
            max_id = batch_max_id if batch_max_id < total_count else 0

            average_time = sum(time_list) / len(time_list) if time_list else 0
            self._update_progress_and_rate_limit(task_type, handled_count, average_time)

            if self._check_exit_conditions(
                mode,
                start_time,
                batches_count,
                handled_count,
                last_success_time,
                no_success_attempts,
            ):
                break

            if await self._sleep_if_needed(mode, handled_count, limit):
                break

    async def _perform_pre_batch_checks(self) -> bool:
        from ..maintenance.shutdown_manager import ShutdownManager
        shutdown = ShutdownManager.get_instance()
        if shutdown.is_shutdown():
            self.logger.warning("检测到关机请求：停止领取新批次，准备优雅退出")
            return True

        if not self.coordinator.can_claim_event.is_set():
            self.logger.info("检测到维护信号，暂停领取新批次，等待维护完成...")
            await self.coordinator.can_claim_event.wait()
            self.logger.info("维护已完成，恢复领取新批次。")

        return False

    async def _fetch_data_batch(
        self,
        task_type: str,
        filter_condition: Any,
        max_id: int,
        handled_count: int,
        worker_id: str,
    ) -> List[Any]:
        try:
            model_class = self.processor.get_model_class()
            order_by = self.processor.get_order_by(task_type)

            return await self.db_adapter.claim_and_fetch_batch(
                model_class=model_class,
                filter_condition=filter_condition,
                order_by=order_by,
                worker_id=worker_id,
                limit=self.per_task_num,
            )
        except Exception as e:
            self.logger.error(f"抢占批次失败: {e}", exc_info=True)
            await asyncio.sleep(1)
            return []

    async def _handle_empty_batch(self, mode: str, empty_counter: int) -> bool:
        if mode == "drain":
            if empty_counter + 1 >= self.config.empty_rounds:
                self.logger.info("排空模式：队列稳定为空，退出执行")
                return True
            else:
                self.logger.info(
                    "排空模式：空批次（%s/%s），休眠 %s 秒后重试…",
                    empty_counter + 1,
                    self.config.empty_rounds,
                    self.config.empty_sleep_seconds,
                )
                await asyncio.sleep(self.config.empty_sleep_seconds)
                return False
        else:
            return True

    async def _process_batch_concurrently(
        self, task_type: str, batch_items: List[Any]
    ) -> int:
        try:
            await self.coordinator.worker_enter()
            tasks = [
                self.processor.process_item(item, task_type) for item in batch_items
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            success_count = sum(
                1 for r in results if not isinstance(r, Exception) and r
            )

            self._adjust_concurrency(task_type, success_count, len(batch_items))
            await self._update_batch_status(batch_items, results)

            return success_count
        except Exception as e:
            self.logger.error(f"批量处理【{task_type}】任务时出错: {e}", exc_info=True)
            await self.db_adapter.rollback()
            return 0
        finally:
            await self.coordinator.worker_exit()

    def _adjust_concurrency(self, task_type: str, success_count: int, batch_size: int):
        if success_count == batch_size and batch_size > 0:
            inc_cap = getattr(self.config, "max_concurrency_increment", 32)
            inc = min(self.context.concurrent_cumulative_quantity, inc_cap)
            before = self.per_task_num
            self.per_task_num = before + inc
            self.logger.info(
                f"【{task_type}】本批次全部成功，应用并发增量 +{inc}（并发 {before} → {self.per_task_num}；累计量={self.context.concurrent_cumulative_quantity}；cap={inc_cap}）"
            )
            if self.context.concurrent_cumulative_quantity < inc_cap:
                self.context.increase_concurrency()
        elif success_count < batch_size:
            self.context.reset_concurrency()
            self.logger.info(f"【{task_type}】本批次非全成功，累计并发增量已重置为 1")

    def _update_progress_and_rate_limit(
        self, task_type: str, handled_count: int, average_time: float
    ):
        self._save_progress(task_type)

        self.task_sleep_time = max(int(60 - average_time), 2)

        if getattr(self.context, "rate_limited", False):
            self.adjust_rate_limit()
            if hasattr(self.context, "clear_rate_limit_flag"):
                self.context.clear_rate_limit_flag()

        self.progress_tracker.update(
            handled_count,
            self.context.success_count,
            self.context.total_token,
            self.per_task_num,
            average_time,
            self.task_sleep_time,
        )

    def _check_exit_conditions(
        self,
        mode: str,
        start_time: float,
        batches_count: int,
        handled_count: int,
        last_success_time: float,
        no_success_attempts: int,
    ) -> bool:
        from ..utils import format_time as format_time_util
        # format_time_util = lambda x: str(x)
        now_ts = time.time()

        if mode == "drain":
            runtime = now_ts - start_time
            if (
                self.config.max_runtime_seconds > 0
                and runtime >= self.config.max_runtime_seconds
            ):
                self.logger.warning("排空模式：达到最大运行时间，退出执行")
                return True
            if self.config.max_batches > 0 and batches_count >= self.config.max_batches:
                self.logger.warning("排空模式：达到最大批次数，退出执行")
                return True
            if self.config.max_items > 0 and handled_count >= self.config.max_items:
                self.logger.warning("排空模式：达到最大处理条数，退出执行")
                return True

        no_success_timeout = getattr(self.config, "no_success_timeout_seconds", 0)
        if (
            no_success_timeout > 0
            and (now_ts - last_success_time) >= no_success_timeout
            and (now_ts - start_time)
            >= getattr(self.config, "no_success_grace_seconds", 0)
            and no_success_attempts
            >= getattr(self.config, "no_success_min_attempts", 1)
        ):
            self.logger.error(
                "无成功超时：过去 %s 未产生成功结果，尝试批次数=%s，自动终止执行（阈值=%s，宽限=%s）",
                format_time_util(now_ts - last_success_time),
                no_success_attempts,
                format_time_util(no_success_timeout),
                format_time_util(
                    getattr(self.config, "no_success_grace_seconds", 0)
                ),
            )
            return True

        return False

    async def _sleep_if_needed(self, mode: str, handled_count: int, limit: int) -> bool:
        from ..maintenance.shutdown_manager import ShutdownManager
        if mode == "drain" or (mode == "bounded" and handled_count < limit):
            total_sleep = self.task_sleep_time
            slept = 0
            step = 1 if total_sleep >= 1 else total_sleep
            shutdown = ShutdownManager.get_instance()
            while slept < total_sleep:
                if shutdown.is_shutdown():
                    self.logger.warning("检测到关机请求：跳过剩余休眠")
                    return True
                await asyncio.sleep(step)
                slept += step
        return False

    async def _finalize_task_execution(self, task_type: str, filter_condition: Any):
        self.logger.info(f"任务【{task_type}】主循环已结束，正在执行最后的清理工作...")
        self._save_progress(task_type)

        try:
            model_class = self.processor.get_model_class()
            db_total_count = await self.db_adapter.count(model_class, None)
            db_handled_count = await self.db_adapter.count(model_class, filter_condition)
            completion = (
                int((db_total_count - db_handled_count) / db_total_count * 100)
                if db_total_count > 0
                else 100
            )
            self.logger.info(f"数据库完成进度：【 {completion}% 】")
        except Exception as e:
            self.logger.warning(f"获取最终数据库进度时出错: {e}", exc_info=True)

        await self._close_api_client()
        await self.db_adapter.close()
        self.logger.info(f"任务【{task_type}】已彻底完成并清理了资源。")

    async def _handle_cancellation(self, task_type: str):
        try:
            self._save_progress(task_type)
        finally:
            await self.db_adapter.close()

    async def _handle_exception(self, task_type: str):
        try:
            self._save_progress(task_type)
        finally:
            await self.db_adapter.close()

    async def _close_api_client(self):
        try:
            api_client = getattr(self.processor, "api_client", None)
            if api_client:
                close_method = getattr(api_client, "close", None)
                if callable(close_method):
                    if asyncio.iscoroutinefunction(close_method):
                        await close_method()
                    else:
                        close_method()
        except Exception as e:
            self.logger.warning(f"关闭 API 客户端时出现异常：{e}", exc_info=True)

    def _load_exclude_data(self, task_type: str = "") -> None:
        filename = f"{task_type}_exclude_data.json"
        data = self.persistence.load_json(filename)
        if data and isinstance(data, dict):
            self.context.exclude_data = data
            self.logger.info(f"成功加载排除数据文件: {filename}")
        else:
            self.logger.info("没有排除数据文件，排除数据设置为空")

    def _save_progress(self, task_type: str) -> None:
        # 保存排除数据
        self.persistence.merge_and_save_json(
            f"{task_type}_exclude_data.json",
            self.context.exclude_data,
            lock_timeout=self.config.persistence_lock_timeout_seconds,
        )

    def adjust_rate_limit(self) -> None:
        before = self.per_task_num
        self.per_task_num = max(1, before - 1)
        self.context.reset_concurrency()
        self.logger.warning(
            f"触发请求频率限制：并发 {before}→{self.per_task_num}；累计并发增量已重置为 1"
        )

    async def _update_batch_status(self, batch_items: List[Any], results: List[Any]) -> None:
        """批量更新任务状态"""
        if not batch_items or not results:
            return
        
        if len(batch_items) != len(results):
            self.logger.error(f"batch_items 和 results 长度不匹配: {len(batch_items)} vs {len(results)}")
            return
        
        model_class = self.processor.get_model_class()
        max_retries = getattr(self.config, "max_retries", 3)
        
        success_ids = []
        retry_ids = []
        failed_ids = []
        
        for item, result in zip(batch_items, results):
            # 判断任务是否成功
            is_success = not isinstance(result, Exception) and result
            
            if is_success:
                success_ids.append(item.id)
            else:
                # 任务失败,检查重试次数
                current_attempts = getattr(item, "attempts", 0) or 0
                
                # 注意: attempts 会在 mark_batch_retry 中自动 +1
                # 所以这里判断的是当前值是否已经达到 max_retries - 1
                if current_attempts + 1 >= max_retries:
                    failed_ids.append(item.id)
                    self.logger.warning(
                        f"任务 {item.id} 达到最大重试次数 ({current_attempts + 1}/{max_retries}),标记为失败"
                    )
                else:
                    retry_ids.append(item.id)
                    self.logger.info(
                        f"任务 {item.id} 失败,将重试 (当前第 {current_attempts + 1} 次,最大 {max_retries} 次)"
                    )
        
        # 批量更新状态
        try:
            if success_ids:
                await self.db_adapter.mark_batch_done(model_class, success_ids)
                self.logger.debug(f"标记 {len(success_ids)} 个任务为完成")
                
            if retry_ids:
                await self.db_adapter.mark_batch_retry(retry_ids, model_class)
                self.logger.debug(f"标记 {len(retry_ids)} 个任务为重试")
                
            if failed_ids:
                await self.db_adapter.mark_batch_failed(
                    failed_ids, 
                    model_class, 
                    reason="max_retries_exceeded"
                )
                self.logger.warning(f"标记 {len(failed_ids)} 个任务为最终失败")
                
        except Exception as e:
            self.logger.error(f"批量更新任务状态失败: {e}", exc_info=True)

