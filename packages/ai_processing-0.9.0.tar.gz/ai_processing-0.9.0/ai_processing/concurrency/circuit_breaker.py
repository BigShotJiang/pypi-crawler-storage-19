#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
简单熔断器（Circuit Breaker）实现：支持 关闭(CLOSED) / 打开(OPEN) / 半开(HALF_OPEN)
- 失败达到阈值 -> 打开，进入冷却
- 冷却期结束 -> 半开，允许有限的探测请求
- 探测成功达到上限 -> 关闭（恢复）
- 探测失败 -> 重新打开并进入冷却
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Literal

State = Literal["CLOSED", "OPEN", "HALF_OPEN"]


@dataclass
class CircuitBreaker:
    failure_threshold: int = 5
    cooldown_seconds: int = 60
    half_open_probe_limit: int = 1

    state: State = "CLOSED"
    consecutive_failures: int = 0
    opened_at: float = 0.0
    half_open_probes: int = 0

    def allow_request(self) -> bool:
        """当前是否允许处理请求"""
        now = time.time()
        if self.state == "CLOSED":
            return True
        if self.state == "OPEN":
            # 是否进入半开探测阶段
            if now - self.opened_at >= max(1, int(self.cooldown_seconds)):
                self.state = "HALF_OPEN"
                self.half_open_probes = 0
                return True
            return False
        if self.state == "HALF_OPEN":
            # 半开允许有限探测
            return self.half_open_probes < max(1, int(self.half_open_probe_limit))
        return True

    def record_success(self) -> None:
        if self.state in ("CLOSED", "HALF_OPEN"):
            if self.state == "HALF_OPEN":
                self.half_open_probes += 1
                # 达到探测上限 -> 关闭（恢复）
                if self.half_open_probes >= max(1, int(self.half_open_probe_limit)):
                    self._reset()
                    return
            # 成功将连续失败清零
            self.consecutive_failures = 0

    def record_failure(self) -> None:
        if self.state == "CLOSED":
            self.consecutive_failures += 1
            if self.consecutive_failures >= max(1, int(self.failure_threshold)):
                self._open()
        elif self.state == "HALF_OPEN":
            # 探测失败 -> 重新打开并冷却
            self._open()
        else:  # OPEN
            # 打开状态下失败不改变状态，等待冷却
            pass

    def _open(self) -> None:
        self.state = "OPEN"
        self.opened_at = time.time()
        self.half_open_probes = 0

    def _reset(self) -> None:
        self.state = "CLOSED"
        self.consecutive_failures = 0
        self.half_open_probes = 0
