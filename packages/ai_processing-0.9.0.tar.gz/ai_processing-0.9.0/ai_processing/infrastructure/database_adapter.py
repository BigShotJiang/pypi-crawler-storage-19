"""
--------------------------------------------
project: ai_processing_framework
file: database_adapter.py
author: 子不语
date: 2025/11/09
--------------------------------------------
"""
import asyncio
import logging
import time
from collections import deque
from typing import Any, List, Optional, Literal, Dict, Union, Tuple

from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import DeclarativeBase

from .db_handler import DatabaseHandler
from .db_utils import commit_with_retry
from .db_backends import create_backend, DatabaseBackend

class DatabaseAdapter:
    """
    数据库适配器，提供统一的数据库操作接口，并集成了租约机制、自动维护、优雅关机等高级功能。
    """

    def __init__(
        self,
        database_config: Any, # DatabaseConfig object
        logger: logging.Logger,
        pragma_default_min_interval_seconds: Optional[int] = None,
        pragma_min_intervals: Optional[Dict[str, int]] = None,
    ):
        self.db_lock = asyncio.Lock()
        self._throttle_lock = asyncio.Lock()
        self._last_pragma_exec_at: Dict[str, float] = {}
        self._default_min_interval_sec: int = (
            int(pragma_default_min_interval_seconds)
            if isinstance(pragma_default_min_interval_seconds, int)
            else 1800
        )
        self._pragma_min_intervals: Dict[str, int] = (
            dict(pragma_min_intervals)
            if isinstance(pragma_min_intervals, dict)
            else {
                "PRAGMA optimize;": 6 * 3600,
                "PRAGMA quick_check;": 24 * 3600,
                "PRAGMA wal_checkpoint(FULL);": 1800,
                "PRAGMA wal_checkpoint(TRUNCATE);": 1800,
            }
        )
        self.database_config = database_config
        self.logger = logger
        
        # 初始化后端
        self.backend: DatabaseBackend = create_backend(
            db_type=database_config.db_type,
            config=database_config.to_dict(),
            logger=logger
        )
        
        self._db_handler: Optional["DatabaseHandler"] = None
        self.busy_errors = deque(maxlen=200)
        self.error_counter_lock = asyncio.Lock()

    async def _record_busy_error(self):
        async with self.error_counter_lock:
            self.busy_errors.append(time.time())

    async def get_recent_busy_errors(self, time_window_seconds: int) -> int:
        now = time.time()
        cutoff = now - time_window_seconds
        async with self.error_counter_lock:
            count = sum(1 for ts in self.busy_errors if ts > cutoff)
        return count

    @property
    def handler(self) -> DatabaseHandler:
        if not self._db_handler:
            self._db_handler = DatabaseHandler(backend=self.backend, logger=self.logger)
        return self._db_handler

    async def commit(self) -> bool:
        """
        兼容性方法：由于现在使用上下文管理器管理事务，此方法主要用于占位或特殊用途。
        如果需要在外部控制事务，应直接使用 handler.session。
        """
        return True

    async def rollback(self) -> None:
        """
        兼容性方法。
        """
        pass

    async def close(self) -> None:
        if self._db_handler:
            try:
                await self._db_handler.close()
            except Exception as e:
                self.logger.error(f"关闭数据库连接失败: {e}")

    async def execute(self, sql: str, params: Optional[Union[tuple, dict]] = None) -> None:
        """执行原生 SQL（自动提交）"""
        async with self.db_lock:
            async with self.handler.session as session:
                try:
                    await session.execute(text(sql), params)
                    await commit_with_retry(session)
                except Exception as e:
                    self.logger.error(f"执行 SQL 失败: {sql}, params: {params}, error: {e}")
                    raise

    async def perform_maintenance(self, command_type: str, table_name: str = None) -> None:
        """执行数据库维护操作 (Backend Agnostic)"""
        async with self.db_lock:
            async with self.handler.session as session:
                try:
                    self.logger.info(f"执行维护操作: {command_type} (table={table_name})")
                    await self.backend.execute_maintenance(session, command_type, table_name)
                    await commit_with_retry(session)
                except Exception as e:
                    self.logger.error(f"执行维护操作 '{command_type}' 失败: {e}", exc_info=True)
                    raise

    async def collect_metrics(self) -> Dict[str, Any]:
        """收集数据库指标 (Backend Agnostic)"""
        async with self.handler.session as session:
            try:
                return await self.backend.collect_metrics(session)
            except Exception as e:
                self.logger.error(f"收集指标失败: {e}", exc_info=True)
                return {}

    async def execute_maintenance_command(self, command: str) -> None:
        async with self.db_lock:
            # 维护命令通常需要独立连接或特殊处理，这里使用 session 执行
            async with self.handler.session as session:
                try:
                    self.logger.info(f"执行维护命令: {command}")
                    await session.execute(text(command))
                    await session.commit()
                except OperationalError as e:
                    if "locked" in str(e) or "busy" in str(e):
                        self.logger.warning(f"数据库在执行维护命令时繁忙或锁定，记录错误: {e}")
                        await self._record_busy_error()
                    self.logger.error(f"执行维护命令 '{command}' 失败: {e}", exc_info=True)
                    raise
                except Exception as e:
                    self.logger.error(f"执行维护命令 '{command}' 失败: {e}", exc_info=True)
                    raise

    async def execute_pragma(
        self,
        command: str,
        fetch: Literal['one', 'all', 'none'] = 'none',
        min_interval_sec: Optional[int] = None,
        skip_if_recent: bool = True,
    ) -> Optional[Union[Tuple, List[Tuple]]]:
        effective_interval = (
            min_interval_sec
            if isinstance(min_interval_sec, int) and min_interval_sec >= 0
            else self._pragma_min_intervals.get(command, self._default_min_interval_sec)
        )
        now_monotonic = time.monotonic()
        should_skip = False
        if effective_interval and skip_if_recent:
            async with self._throttle_lock:
                last_at = self._last_pragma_exec_at.get(command, 0.0)
                if now_monotonic - last_at < float(effective_interval):
                    should_skip = True
                else:
                    self._last_pragma_exec_at[command] = now_monotonic
        if should_skip:
            self.logger.debug(f"跳过 PRAGMA（节流命中 {effective_interval}s）: {command}")
            return None

        async with self.db_lock:
            # PRAGMA 通常需要在连接级别执行
            async with self.handler.engine.connect() as conn:
                try:
                    self.logger.debug(f"执行 PRAGMA: {command}")
                    result_proxy = await conn.execute(text(command))
                    
                    result = None
                    if fetch == 'one':
                        result = result_proxy.fetchone()
                    elif fetch == 'all':
                        result = result_proxy.fetchall()
                    
                    if effective_interval:
                        async with self._throttle_lock:
                            self._last_pragma_exec_at[command] = time.monotonic()
                    return result
                except OperationalError as e:
                    if "locked" in str(e) or "busy" in str(e):
                        self.logger.warning(f"数据库在执行 PRAGMA 时繁忙或锁定，记录错误: {e}")
                        await self._record_busy_error()
                    if effective_interval:
                        async with self._throttle_lock:
                            last_at = self._last_pragma_exec_at.get(command)
                            if last_at and (time.monotonic() - last_at) < 1.0:
                                self._last_pragma_exec_at.pop(command, None)
                    self.logger.error(f"执行 PRAGMA '{command}' 失败: {e}", exc_info=True)
                    raise
                except Exception as e:
                    if effective_interval:
                        async with self._throttle_lock:
                            last_at = self._last_pragma_exec_at.get(command)
                            if last_at and (time.monotonic() - last_at) < 1.0:
                                self._last_pragma_exec_at.pop(command, None)
                    self.logger.error(f"执行 PRAGMA '{command}' 失败: {e}", exc_info=True)
                    raise

    async def _begin_immediate_if_needed(self, session: AsyncSession) -> bool:
        # aiosqlite/SQLAlchemy 异步模式下，通常不需要手动 BEGIN IMMEDIATE，
        # 但为了防止死锁，可以尝试显式开启事务
        try:
            if session.in_transaction():
                return False
            await session.execute(text("BEGIN IMMEDIATE"))
            return True
        except OperationalError as e:
            if "locked" in str(e) or "busy" in str(e):
                await self._record_busy_error()
            return False
        except Exception:
            return False

    async def reset_all_states(
        self,
        model_class: Any,
        include_done_reset: bool = True,
        owner: Optional[str] = None,
        dry_run: bool = False,
        reset_scope: Literal['non_null', 'all'] = 'non_null',
    ) -> int:
        """重置数据库中的并发状态字段"""
        async with self.handler.session as session:
            # 构建查询
            # 注意：SQLAlchemy 1.4+ 异步查询语法略有不同，使用 select/update
            from sqlalchemy import select, update
            
            # 构造 where 条件
            conditions = []
            if reset_scope == 'non_null':
                conditions.append(model_class.processing.isnot(None))
            if owner:
                conditions.append(model_class.lock_owner == owner)

            if dry_run:
                stmt = select(model_class)
                if conditions:
                    stmt = stmt.where(*conditions)
                # count
                from sqlalchemy import func
                count_stmt = select(func.count()).select_from(model_class)
                if conditions:
                    count_stmt = count_stmt.where(*conditions)
                
                result = await session.execute(count_stmt)
                count = result.scalar()
                self.logger.info(f"[Dry Run] 将重置 {count} 条记录的状态。")
                return count

            update_values = {
                "processing": None,
                "lock_owner": None,
                "lock_at": None
            }
            if include_done_reset:
                update_values["done"] = None

            stmt = update(model_class)
            if conditions:
                stmt = stmt.where(*conditions)
            stmt = stmt.values(**update_values)
            
            # execution_options(synchronize_session=False) 在 update() 中通常默认
            result = await session.execute(stmt)
            affected_rows = result.rowcount
            await commit_with_retry(session)
            self.logger.info(f"重置了 {affected_rows} 条记录的状态。")
            return affected_rows

    async def claim_and_fetch_batch(
        self,
        model_class: Any,
        filter_condition: Any,
        order_by: Optional[Any],
        worker_id: str,
        limit: int,
    ) -> List[Any]:
        """通用的批次抢占方法,支持任意模型"""
        if not isinstance(limit, int) or limit <= 0:
            limit = 100
        
        async with self.handler.session as session:
            try:
                from sqlalchemy import select, update
                from datetime import datetime, UTC
                
                # 1. 构建查询条件 - 获取未处理的任务
                base_conditions = [
                    model_class.processing.is_(None),
                    model_class.done.is_(None)
                ]
                
                # 排除失败状态的任务 (如果模型有 status 字段)
                if hasattr(model_class, 'status'):
                    base_conditions.append(model_class.status != 'failed')
                
                # 添加用户自定义过滤条件
                if filter_condition is not None:
                    base_conditions.append(filter_condition)
                
                # 2. 查询候选任务
                stmt = select(model_class).where(*base_conditions)
                if order_by is not None:
                    stmt = stmt.order_by(order_by)
                stmt = stmt.limit(limit)
                
                result = await session.execute(stmt)
                candidates = result.scalars().all()
                
                if not candidates:
                    return []
                
                # 3. 批量更新为 processing 状态
                candidate_ids = [item.id for item in candidates]
                lock_time = datetime.now(UTC).isoformat()
                
                update_stmt = (
                    update(model_class)
                    .where(model_class.id.in_(candidate_ids))
                    .values(
                        processing=1,
                        lock_owner=worker_id,
                        lock_at=lock_time
                    )
                )
                await session.execute(update_stmt)
                await commit_with_retry(session)
                
                # 4. 重新查询已锁定的任务 (确保获取最新状态)
                fetch_stmt = select(model_class).where(model_class.id.in_(candidate_ids))
                fetch_result = await session.execute(fetch_stmt)
                locked_items = fetch_result.scalars().all()
                
                return locked_items
                
            except Exception as e:
                self.logger.error(f"批量抢占任务失败: {e}", exc_info=True)
                await session.rollback()
                return []
        
    async def count(self, model_class: Any, filter_condition: Optional[Any]) -> int:
        """统计记录数量。若提供 filter_condition 则统计未完成数量，否则统计总数。"""
        async with self.handler.session as session:
            try:
                from sqlalchemy import select, func
                stmt = select(func.count()).select_from(model_class)
                if filter_condition is not None:
                    stmt = stmt.where(filter_condition)
                result = await session.execute(stmt)
                return int(result.scalar() or 0)
            except Exception:
                self.logger.error("统计数量失败", exc_info=True)
                return 0

    async def mark_batch_done(self, model_class: Any, ids: List[int]) -> None:
        """标记任务为完成状态"""
        if not ids:
            return
        
        async with self.handler.session as session:
            try:
                from sqlalchemy import update
                
                update_values = {
                    "done": 1,
                    "processing": None,
                    "lock_owner": None,
                    "lock_at": None
                }
                
                # 如果模型有 status 字段,也更新为 done
                if hasattr(model_class, 'status'):
                    update_values["status"] = "done"
                
                stmt = (
                    update(model_class)
                    .where(model_class.id.in_(ids))
                    .values(**update_values)
                )
                await session.execute(stmt)
                await commit_with_retry(session)
                self.logger.debug(f"标记 {len(ids)} 个任务为完成")
                
            except Exception as e:
                self.logger.error(f"标记任务完成失败: {e}", exc_info=True)
                await session.rollback()
                raise

    async def mark_batch_retry(self, ids: List[int], model_class: Any = None) -> None:
        """标记任务为重试状态 (释放锁,增加attempts)"""
        if not ids:
            return
        
        async with self.handler.session as session:
            try:
                from sqlalchemy import update
                
                # 基础更新: 释放锁
                update_values = {
                    "processing": None,
                    "lock_owner": None,
                    "lock_at": None
                }
                
                # 如果模型有 attempts 字段,增加重试计数
                if model_class and hasattr(model_class, 'attempts'):
                    # 使用 SQL 表达式增加计数
                    stmt = (
                        update(model_class)
                        .where(model_class.id.in_(ids))
                        .values(
                            attempts=model_class.attempts + 1,
                            **update_values
                        )
                    )
                else:
                    stmt = (
                        update(model_class)
                        .where(model_class.id.in_(ids))
                        .values(**update_values)
                    )
                
                await session.execute(stmt)
                await commit_with_retry(session)
                self.logger.debug(f"标记 {len(ids)} 个任务为重试状态")
                
            except Exception as e:
                self.logger.error(f"标记任务重试失败: {e}", exc_info=True)
                await session.rollback()
                raise

    async def mark_batch_failed(self, ids: List[int], model_class: Any = None, reason: str = None) -> None:
        """标记任务为最终失败状态 (达到最大重试次数)"""
        if not ids:
            return
        
        async with self.handler.session as session:
            try:
                from sqlalchemy import update
                
                update_values = {
                    "processing": None,
                    "lock_owner": None,
                    "lock_at": None
                }
                
                # 如果模型有 status 字段,设置为 failed
                if model_class and hasattr(model_class, 'status'):
                    update_values["status"] = "failed"
                
                # 如果模型有 blocked_reason 字段,记录失败原因
                if model_class and hasattr(model_class, 'blocked_reason') and reason:
                    update_values["blocked_reason"] = reason
                
                # 如果模型有 attempts 字段,也增加计数 (记录最后一次失败)
                if model_class and hasattr(model_class, 'attempts'):
                    stmt = (
                        update(model_class)
                        .where(model_class.id.in_(ids))
                        .values(
                            attempts=model_class.attempts + 1,
                            **update_values
                        )
                    )
                else:
                    stmt = (
                        update(model_class)
                        .where(model_class.id.in_(ids))
                        .values(**update_values)
                    )
                
                await session.execute(stmt)
                await commit_with_retry(session)
                self.logger.warning(f"标记 {len(ids)} 个任务为失败状态 (原因: {reason})")
                
            except Exception as e:
                self.logger.error(f"标记任务失败失败: {e}", exc_info=True)
                await session.rollback()
                raise

    async def revert_stale_locks(self, model_class: Any, timeout_seconds: int) -> int:
        """
        回收超时的租约（processing=1 且 lock_at 超时）。
        采用两阶段策略：优先 SQL 批量回收，必要时 Python 兜底解析。
        返回释放的记录数估计值。
        """
        async with self.handler.session as session:
            try:
                # 规范化 lock_at 为 epoch 秒的 SQL 片段
                normalized_lock_at = (
                    "COALESCE(strftime('%s', SUBSTR(REPLACE(REPLACE(REPLACE(TRIM(COALESCE(lock_at,'')),'T',' '),'Z',''),'/','-'),1,19)), 0)"
                )
                delta_param = f"-{int(timeout_seconds)} seconds"
                table_name = getattr(model_class, "__tablename__", None)
                
                if not table_name:
                    # 回退到 ORM 方式
                    from sqlalchemy import select, update
                    stmt = select(model_class).where(model_class.processing == 1)
                    result = await session.execute(stmt)
                    stale = result.scalars().all()
                    
                    to_revert = []
                    now_epoch = int(time.time())
                    for row in stale:
                        lock_at_text = getattr(row, "lock_at", None)
                        epoch = self._parse_lock_at_to_epoch(lock_at_text)
                        if epoch <= now_epoch - int(timeout_seconds):
                            to_revert.append(row.id)
                    
                    if to_revert:
                        stmt_upd = (
                            update(model_class)
                            .where(model_class.id.in_(to_revert))
                            .values(processing=None, lock_owner=None, lock_at=None)
                        )
                        await session.execute(stmt_upd)
                        await commit_with_retry(session)
                    return len(to_revert)

                # SQL 统计
                timeout_condition = self.backend.get_timeout_condition(timeout_seconds)
                
                # 注意：get_timeout_condition 返回的是 text 对象，需要转换为字符串或者直接使用
                # 这里我们假设 get_timeout_condition 返回的是完整的 WHERE 子句的一部分
                
                # 由于 SQLAlchemy 的 update() 语句对于复杂 WHERE 子句的支持可能有限，
                # 我们这里尝试使用 select 先查出来再更新，或者使用 backend 特定的 SQL
                
                # 为了兼容性，我们先使用 select + update 方式，利用 backend.parse_lock_timestamp
                
                # 实际上，我们可以尝试构建一个通用的 UPDATE 语句，但不同数据库的 UPDATE ... FROM 语法不同
                # 最稳妥的方式是先查后改，或者让 backend 提供清理的 SQL
                
                # 这里我们使用 Python 兜底逻辑作为主要逻辑，因为它已经很健壮了
                # 并且利用 backend.parse_lock_timestamp 来处理时间解析
                
                from sqlalchemy import select, update
                stmt = select(model_class).where(model_class.processing == 1)
                result = await session.execute(stmt)
                stale = result.scalars().all()
                
                to_revert = []
                now_epoch = int(time.time())
                for row in stale:
                    lock_at_text = getattr(row, "lock_at", None)
                    epoch = self.backend.parse_lock_timestamp(lock_at_text)
                    if epoch > 0 and epoch <= now_epoch - int(timeout_seconds):
                        to_revert.append(row.id)
                
                if to_revert:
                    stmt_upd = (
                        update(model_class)
                        .where(model_class.id.in_(to_revert))
                        .values(processing=None, lock_owner=None, lock_at=None)
                    )
                    await session.execute(stmt_upd)
                    await commit_with_retry(session)
                return len(to_revert)
            except Exception:
                self.logger.error("回收超时租约失败", exc_info=True)
                await session.rollback()
                return 0
            except Exception:
                self.logger.error("SQL 回收超时租约失败，尝试 Python 兜底", exc_info=True)
                try:
                    # Python 兜底
                    from sqlalchemy import select, update
                    stmt = select(model_class).where(model_class.processing == 1)
                    result = await session.execute(stmt)
                    remaining = result.scalars().all()
                    
                    now_epoch = int(time.time())
                    to_revert_ids = []
                    for row in remaining:
                        epoch = self._parse_lock_at_to_epoch(getattr(row, "lock_at", None))
                        if epoch <= now_epoch - int(timeout_seconds):
                            to_revert_ids.append(row.id)
                    if to_revert_ids:
                        stmt_upd = (
                            update(model_class)
                            .where(model_class.id.in_(to_revert_ids))
                            .values(processing=None, lock_owner=None, lock_at=None)
                        )
                        await session.execute(stmt_upd)
                        await commit_with_retry(session)
                    return len(to_revert_ids)
                except Exception:
                    self.logger.error("Python 兜底回收也失败", exc_info=True)
                    await session.rollback()
                    return 0


