from datetime import datetime
from urllib.parse import quote_plus
from typing import Dict, Any, Optional
from sqlalchemy import text
from .base import DatabaseBackend

class PostgreSQLBackend(DatabaseBackend):
    """PostgreSQL 数据库后端"""
    
    def get_engine_url(self) -> str:
        host = self.config.get("host") or "localhost"
        port = self.config.get("port") or 5432
        database = self.config.get("database") or "ai_processing"
        user = self.config.get("user") or "postgres"
        password = self.config.get("password") or ""
        
        # URL 编码密码中的特殊字符
        safe_password = quote_plus(password) if password else ""
        
        if safe_password:
            return f"postgresql+asyncpg://{user}:{safe_password}@{host}:{port}/{database}"
        else:
            return f"postgresql+asyncpg://{user}@{host}:{port}/{database}"
    
    def get_current_timestamp_expr(self) -> text:
        return text("CURRENT_TIMESTAMP")
    
    def parse_lock_timestamp(self, timestamp_str: str) -> int:
        """解析 PostgreSQL 时间戳字符串
        
        PostgreSQL 存储格式: "2025-11-20T10:30:00+00:00" 或 "2025-11-20 10:30:00"
        """
        if not timestamp_str:
            return 0
            
        try:
            ts_str = str(timestamp_str)
            # PostgreSQL 返回 ISO 格式
            # 移除时区信息（如果有）
            cleaned = ts_str.split('+')[0].split('-', 2)  # 只分割时区的 '-'
            if len(cleaned) == 3:
                # 重新组合日期部分，处理可能的时区后缀
                date_part = '-'.join(cleaned[:3])
                if '+' in date_part:
                     date_part = date_part.split('+')[0]
                cleaned = date_part.split('.')[0]  # 移除微秒
            else:
                cleaned = ts_str.split('.')[0]  # 移除微秒
            
            # 尝试解析 ISO 格式
            if 'T' in cleaned:
                dt = datetime.fromisoformat(cleaned)
            else:
                dt = datetime.strptime(cleaned, '%Y-%m-%d %H:%M:%S')
            
            return int(dt.timestamp())
        except (ValueError, AttributeError) as e:
            self.logger.warning(f"Failed to parse PostgreSQL timestamp '{timestamp_str}': {e}")
            return 0
    
    async def execute_maintenance(self, session, command_type: str, table_name: str = None):
        """执行 PostgreSQL 维护命令
        
        注意: VACUUM 和 REINDEX 不能在事务中执行
        """
        if command_type == "vacuum":
            # VACUUM 需要在事务外执行，这里可能需要特殊处理，或者假设调用者已处理
            # SQLAlchemy async session 默认在事务中，需要 commit 后执行，或者使用 autocommit 模式
            # 简单起见，这里只记录日志，实际执行可能需要独立连接
            self.logger.warning("PostgreSQL VACUUM requires execution outside transaction block. Skipping.")
            
        elif command_type == "analyze":
            if table_name:
                await session.execute(text(f"ANALYZE {table_name};"))
            else:
                await session.execute(text("ANALYZE;"))
            self.logger.info(f"Executed PostgreSQL ANALYZE on {table_name or 'database'}")
            
        elif command_type == "reindex":
            if table_name:
                await session.execute(text(f"REINDEX TABLE {table_name};"))
                self.logger.info(f"Executed PostgreSQL REINDEX on table {table_name}")
    
    def get_timeout_condition(self, timeout_seconds: int) -> text:
        """PostgreSQL 超时条件"""
        return text(f"lock_at <= CURRENT_TIMESTAMP - INTERVAL '{timeout_seconds} seconds'")
    
    async def collect_metrics(self, session) -> Dict[str, Any]:
        """收集 PostgreSQL 指标"""
        # TODO: Implement PostgreSQL specific metrics
        return {
            "wal_size": 0,
            "wal_size_mb": 0,
            "page_count": 0,
            "freelist_count": 0,
            "fragmentation_ratio": 0,
            "quick_check": "ok"
        }
    
    def get_engine_options(self) -> Dict[str, Any]:
        return {
            **super().get_engine_options(),
            "pool_size": self.config.get("pool_size", 10),
            "max_overflow": self.config.get("max_overflow", 20),
            "pool_timeout": self.config.get("pool_timeout", 30)
        }
