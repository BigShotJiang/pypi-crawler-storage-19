from abc import ABC, abstractmethod
from typing import Optional, Dict, Any
from sqlalchemy import text
import logging

class DatabaseBackend(ABC):
    """数据库后端抽象基类
    
    所有数据库后端必须继承此类并实现所有抽象方法。
    """
    
    def __init__(self, config: Dict[str, Any], logger: logging.Logger):
        """初始化数据库后端
        
        Args:
            config: 数据库配置字典
            logger: 日志记录器
        """
        self.config = config
        self.logger = logger
    
    @abstractmethod
    def get_engine_url(self) -> str:
        """返回 SQLAlchemy 引擎 URL
        
        Returns:
            str: 数据库连接 URL，如 "postgresql+asyncpg://user:pass@host/db"
        """
        pass
    
    @abstractmethod
    def get_current_timestamp_expr(self) -> text:
        """返回当前时间戳的 SQL 表达式
        
        Returns:
            text: SQLAlchemy text 对象，表示当前时间戳
        """
        pass
    
    @abstractmethod
    def parse_lock_timestamp(self, timestamp_str: str) -> int:
        """解析锁定时间戳为 epoch 秒
        
        Args:
            timestamp_str: 时间戳字符串
            
        Returns:
            int: Unix epoch 时间戳（秒）
        """
        pass
    
    @abstractmethod
    async def execute_maintenance(self, session, command_type: str, table_name: str = None):
        """执行数据库维护命令
        
        Args:
            session: 数据库会话
            command_type: 命令类型，如 "optimize", "vacuum", "checkpoint"
            table_name: 表名（可选，某些数据库如 MySQL 需要）
        """
        pass
    
    @abstractmethod
    def get_timeout_condition(self, timeout_seconds: int) -> text:
        """返回租约超时的 SQL 条件
        
        Args:
            timeout_seconds: 超时秒数
            
        Returns:
            text: SQL WHERE 条件，用于查找超时的租约
        """
        pass
    
    @abstractmethod
    async def collect_metrics(self, session) -> Dict[str, Any]:
        """收集数据库指标
        
        Args:
            session: 数据库会话
            
        Returns:
            dict: 指标字典
        """
        pass
    
    def get_engine_options(self) -> Dict[str, Any]:
        """返回引擎配置选项
        
        Returns:
            dict: SQLAlchemy 引擎配置选项
        """
        options = {
            "pool_pre_ping": True,
            "pool_recycle": 3600,
            "echo": False
        }
        # 合并配置中的额外选项
        # 排除非 SQLAlchemy 选项的键
        exclude_keys = {
            "db_type", "database_path", "host", "port", "database", "user", "password",
            "pool_size", "max_overflow", "pool_timeout"
        }
        for key, value in self.config.items():
            if key not in exclude_keys:
                options[key] = value
                
        return options
    
    def get_safe_connection_string(self) -> str:
        """返回脱敏的连接字符串用于日志记录
        
        Returns:
            str: 脱敏后的连接字符串
        """
        url = self.get_engine_url()
        # 隐藏密码
        if "@" in url and "://" in url:
            protocol, rest = url.split("://", 1)
            if "@" in rest:
                credentials, host_part = rest.split("@", 1)
                if ":" in credentials:
                    user = credentials.split(":")[0]
                    return f"{protocol}://{user}:****@{host_part}"
        return url
