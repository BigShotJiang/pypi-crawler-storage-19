from datetime import datetime
from urllib.parse import quote_plus
from typing import Dict, Any, Optional
from sqlalchemy import text
from .base import DatabaseBackend

class MySQLBackend(DatabaseBackend):
    """MySQL 数据库后端"""
    
    def get_engine_url(self) -> str:
        host = self.config.get("host") or "localhost"
        port = self.config.get("port") or 3306
        database = self.config.get("database") or "ai_processing"
        user = self.config.get("user") or "root"
        password = self.config.get("password") or ""
        
        # URL 编码密码
        safe_password = quote_plus(password) if password else ""
        
        if safe_password:
            return f"mysql+aiomysql://{user}:{safe_password}@{host}:{port}/{database}"
        else:
            return f"mysql+aiomysql://{user}@{host}:{port}/{database}"
    
    def get_current_timestamp_expr(self) -> text:
        return text("CURRENT_TIMESTAMP")
    
    def parse_lock_timestamp(self, timestamp_str: str) -> int:
        """解析 MySQL 时间戳字符串
        
        MySQL 存储格式: "2025-11-20 10:30:00"
        """
        if not timestamp_str:
            return 0
            
        try:
            ts_str = str(timestamp_str)
            dt = datetime.strptime(ts_str, '%Y-%m-%d %H:%M:%S')
            return int(dt.timestamp())
        except (ValueError, AttributeError) as e:
            self.logger.warning(f"Failed to parse MySQL timestamp '{timestamp_str}': {e}")
            return 0
    
    async def execute_maintenance(self, session, command_type: str, table_name: str = None):
        """执行 MySQL 维护命令"""
        if not table_name:
            self.logger.warning("MySQL maintenance requires table_name")
            return
            
        commands = {
            "optimize": f"OPTIMIZE TABLE {table_name};",
            "analyze": f"ANALYZE TABLE {table_name};",
            "check": f"CHECK TABLE {table_name};"
        }
        
        if command_type in commands:
            await session.execute(text(commands[command_type]))
            self.logger.info(f"Executed MySQL {command_type} on table {table_name}")
    
    def get_timeout_condition(self, timeout_seconds: int) -> text:
        """MySQL 超时条件"""
        return text(f"UNIX_TIMESTAMP(lock_at) <= UNIX_TIMESTAMP() - {timeout_seconds}")
    
    async def collect_metrics(self, session) -> Dict[str, Any]:
        """收集 MySQL 指标"""
        # TODO: Implement MySQL specific metrics
        return {
            "wal_size": 0,
            "wal_size_mb": 0,
            "page_count": 0,
            "freelist_count": 0,
            "fragmentation_ratio": 0,
            "quick_check": "ok"
        }
    
    def get_engine_options(self) -> Dict[str, Any]:
        return {
            **super().get_engine_options(),
            "pool_size": self.config.get("pool_size", 5),
            "max_overflow": self.config.get("max_overflow", 10),
            "pool_timeout": self.config.get("pool_timeout", 30)
        }
