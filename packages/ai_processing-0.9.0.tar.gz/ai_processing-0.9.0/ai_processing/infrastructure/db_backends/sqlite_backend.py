from datetime import datetime
from typing import Dict, Any, Optional
from sqlalchemy import text
from .base import DatabaseBackend

class SQLiteBackend(DatabaseBackend):
    """SQLite 数据库后端"""
    
    def get_engine_url(self) -> str:
        db_path = self.config.get("database_path", "database.db")
        return f"sqlite+aiosqlite:///{db_path}"
    
    def get_current_timestamp_expr(self) -> text:
        return text("strftime('%Y-%m-%d %H:%M:%S','now')")
    
    def parse_lock_timestamp(self, timestamp_str: str) -> int:
        """解析 SQLite 时间戳字符串为 epoch 秒
        
        SQLite 存储格式: "2025-11-20 10:30:00"
        """
        if not timestamp_str:
            return 0
            
        try:
            # 清理时间戳字符串
            cleaned = str(timestamp_str).strip()
            # 移除可能的 'T' 和 'Z'
            cleaned = cleaned.replace('T', ' ').replace('Z', '')
            # 替换 '/' 为 '-'
            cleaned = cleaned.replace('/', '-')
            # 截取前19个字符
            cleaned = cleaned[:19]
            
            # 解析时间
            dt = datetime.strptime(cleaned, '%Y-%m-%d %H:%M:%S')
            return int(dt.timestamp())
        except (ValueError, AttributeError) as e:
            self.logger.warning(f"Failed to parse timestamp '{timestamp_str}': {e}")
            return 0
    
    async def execute_maintenance(self, session, command_type: str, table_name: str = None):
        """执行 SQLite 维护命令"""
        commands = {
            "optimize": "PRAGMA optimize;",
            "check": "PRAGMA quick_check;",
            "checkpoint": "PRAGMA wal_checkpoint(FULL);",
            "vacuum": "VACUUM;"
        }
        if command_type in commands:
            await session.execute(text(commands[command_type]))
            self.logger.info(f"Executed SQLite maintenance: {command_type}")
    
    def get_timeout_condition(self, timeout_seconds: int) -> text:
        """SQLite 特定的超时条件"""
        return text(f"""
            CAST(strftime('%s', lock_at) AS INTEGER) <= 
            CAST(strftime('%s','now', '-{timeout_seconds} seconds') AS INTEGER)
        """)

    async def collect_metrics(self, session) -> Dict[str, Any]:
        """收集 SQLite 指标"""
        import os
        metrics = {}
        try:
            # WAL size
            db_path = self.config.get("database_path", "database.db")
            wal_path = db_path + "-wal"
            if os.path.exists(wal_path):
                metrics["wal_size"] = os.path.getsize(wal_path)
            else:
                metrics["wal_size"] = 0
            
            metrics["wal_size_mb"] = metrics["wal_size"] / (1024 * 1024)
            
            # Page count
            res = await session.execute(text("PRAGMA page_count;"))
            page_count = res.scalar()
            metrics["page_count"] = page_count
            
            # Freelist count
            res = await session.execute(text("PRAGMA freelist_count;"))
            freelist_count = res.scalar()
            metrics["freelist_count"] = freelist_count
            
            # Fragmentation
            metrics["fragmentation_ratio"] = freelist_count / max(page_count, 1) if page_count else 0
            
            # Quick check (might be slow, maybe skip or make optional?)
            # For now we keep it as it was in HealthMonitor
            res = await session.execute(text("PRAGMA quick_check;"))
            metrics["quick_check"] = res.scalar()
            
        except Exception as e:
            self.logger.error(f"Failed to collect SQLite metrics: {e}")
        
        return metrics
