from .base import DatabaseBackend
from .sqlite_backend import SQLiteBackend
from .postgresql_backend import PostgreSQLBackend
from .mysql_backend import MySQLBackend
import logging

__all__ = [
    "DatabaseBackend",
    "SQLiteBackend",
    "PostgreSQLBackend",
    "MySQLBackend",
    "create_backend"
]

def create_backend(
    db_type: str,
    config: dict,
    logger: logging.Logger = None
) -> DatabaseBackend:
    """创建数据库后端实例的工厂函数
    
    Args:
        db_type: 数据库类型 ("sqlite", "postgresql", "mysql")
        config: 配置字典
        logger: 日志记录器（可选）
        
    Returns:
        DatabaseBackend: 对应的后端实例
        
    Raises:
        ValueError: 不支持的数据库类型
        
    Examples:
        >>> backend = create_backend("postgresql", {
        ...     "host": "localhost",
        ...     "database": "mydb",
        ...     "user": "postgres",
        ...     "password": "secret"
        ... })
    """
    if logger is None:
        logger = logging.getLogger(__name__)
    
    db_type = db_type.lower()
    
    backends = {
        "sqlite": SQLiteBackend,
        "postgresql": PostgreSQLBackend,
        "postgres": PostgreSQLBackend,  # 别名
        "mysql": MySQLBackend,
        "mariadb": MySQLBackend,  # 别名
    }
    
    if db_type not in backends:
        raise ValueError(
            f"Unsupported database type: {db_type}. "
            f"Supported types: {', '.join(backends.keys())}"
        )
    
    backend_class = backends[db_type]
    return backend_class(config, logger)
