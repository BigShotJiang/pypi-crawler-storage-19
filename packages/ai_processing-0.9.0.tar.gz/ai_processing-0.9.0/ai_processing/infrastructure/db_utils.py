#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: ai_processing_framework
file: db_utils.py
author: 子不语
description: 数据库工具函数
--------------------------------------------
"""

import asyncio
import random
from typing import Optional

from sqlalchemy.exc import OperationalError, PendingRollbackError
from sqlalchemy.ext.asyncio import AsyncSession


LOCK_ERR_KEYWORDS = (
    "database is locked",
    "locked",
)


def _is_lock_error(exc: Exception) -> bool:
    """检查异常是否为数据库锁错误"""
    msg = str(exc) if exc else ""
    msg = msg.lower()
    return any(k in msg for k in LOCK_ERR_KEYWORDS)


async def commit_with_retry(
    session: AsyncSession,
    max_retries: int = 8,
    base_delay: float = 0.1,
    jitter: float = 0.1,
) -> None:
    """
    提交带指数退避 + 抖动的重试策略；失败将抛出最后一次异常。
    """
    attempt = 0
    while True:
        try:
            await session.commit()
            return
        except Exception as exc:
            # 对锁相关/挂起回滚异常做退避
            if _is_lock_error(exc) or isinstance(exc, (OperationalError, PendingRollbackError)):
                try:
                    await session.rollback()
                except Exception:
                    pass
                if attempt >= max_retries:
                    raise
                delay = (base_delay * (2 ** attempt)) * (1 + random.uniform(0, jitter))
                await asyncio.sleep(delay)
                attempt += 1
                continue
            # 其他异常直接抛出
            raise
