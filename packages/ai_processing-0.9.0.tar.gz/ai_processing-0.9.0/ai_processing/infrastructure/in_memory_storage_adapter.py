"""
--------------------------------------------
project: ai_processing_framework
file: in_memory_storage_adapter.py
author: 子不语
date: 2025/11/2
--------------------------------------------
"""
import logging
import threading
from typing import Any, Dict, List, Optional
from ..types import ProcessItem

class InMemoryStorageAdapter:
    """
    内存存储适配器：零数据/无表情况下提供可运行的租约式批量机制。
    """

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self._items: List[ProcessItem] = []
        self._lock = threading.Lock()

    def seed(self, items: List[ProcessItem]) -> None:
        """注入初始数据列表，每个 item 应包含唯一 id"""
        with self._lock:
            self._items = [dict(x) for x in items]
            for x in self._items:
                x.setdefault("processing", 0)
                x.setdefault("done", 0)
                x.setdefault("lock_owner", None)

    async def claim_and_fetch_batch(
        self,
        worker_id: str,
        limit: int,
        filter_fn: Optional[callable] = None,
        order_fn: Optional[callable] = None,
    ) -> List[ProcessItem]:
        """
        线程安全地在内存中打标并返回一批数据。
        """
        with self._lock:
            candidates = [x for x in self._items if (x.get("processing") == 0 and x.get("done") == 0)]
            if filter_fn:
                candidates = [x for x in candidates if filter_fn(x)]
            if order_fn:
                candidates.sort(key=order_fn)
            batch = candidates[:limit]
            for x in batch:
                x["processing"] = 1
                x["lock_owner"] = worker_id
            return [dict(x) for x in batch]

    async def mark_batch_done(self, ids: List[int]) -> None:
        with self._lock:
            id_set = set(ids)
            for x in self._items:
                if x.get("id") in id_set:
                    x["done"] = 1
                    x["processing"] = 0
                    x["lock_owner"] = None

    async def mark_batch_revert(self, ids: List[int]) -> None:
        with self._lock:
            id_set = set(ids)
            for x in self._items:
                if x.get("id") in id_set:
                    x["processing"] = 0
                    x["lock_owner"] = None
