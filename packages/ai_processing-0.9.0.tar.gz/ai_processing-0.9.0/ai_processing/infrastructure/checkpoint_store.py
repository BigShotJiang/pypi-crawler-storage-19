#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
检查点存储接口与文件实现
"""

from typing import Protocol, Optional
import os
import json


class CheckpointStore(Protocol):
    def load(self, name: str) -> Optional[dict]:
        ...
    def save(self, name: str, data: dict) -> None:
        ...


class FileCheckpointStore(CheckpointStore):
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        os.makedirs(self.base_dir, exist_ok=True)

    def _path(self, name: str) -> str:
        return os.path.join(self.base_dir, f"{name}.checkpoint.json")

    def load(self, name: str) -> Optional[dict]:
        path = self._path(name)
        if not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def save(self, name: str, data: dict) -> None:
        path = self._path(name)
        tmp_path = f"{path}.tmp"
        # 原子写入：先写入临时文件，再替换
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        try:
            os.replace(tmp_path, path)
        except Exception:
            # 回退为直接写入，保证不抛出影响主流程
            with open(path, "w", encoding="utf-8") as f2:
                json.dump(data, f2, ensure_ascii=False, indent=2)
