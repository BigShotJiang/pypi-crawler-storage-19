#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
失败存档（SQLite 实现）
"""

from __future__ import annotations

import json
import os
import aiosqlite
from dataclasses import dataclass
from typing import Dict, Iterable, Iterator, Optional, AsyncIterator


class FailureStore:
    """失败存档协议"""

    async def save_json_failure(
        self,
        item_id: int | str,
        task_type: str,
        raw_text: str,
        reason: str,
        parsed_json: Optional[Dict] = None,
        attempts: int = 1,
    ) -> None:
        raise NotImplementedError

    def iter_failures(self, task_type: Optional[str] = None) -> AsyncIterator[Dict]:
        raise NotImplementedError


@dataclass
class SQLiteFailureStore(FailureStore):
    db_path: str

    async def initialize(self) -> None:
        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
        await self._init_db()

    def _connect(self) -> aiosqlite.Connection:
        return aiosqlite.connect(self.db_path)

    async def _init_db(self) -> None:
        async with self._connect() as conn:
            await conn.execute(
                """
                CREATE TABLE IF NOT EXISTS json_failures (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_type TEXT NOT NULL,
                    item_id TEXT NOT NULL,
                    raw_text TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    parsed_json TEXT,
                    attempts INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            await conn.commit()

    async def save_json_failure(
        self,
        item_id: int | str,
        task_type: str,
        raw_text: str,
        reason: str,
        parsed_json: Optional[Dict] = None,
        attempts: int = 1,
    ) -> None:
        payload = json.dumps(parsed_json, ensure_ascii=False) if parsed_json is not None else None
        async with self._connect() as conn:
            await conn.execute(
                "INSERT INTO json_failures(task_type, item_id, raw_text, reason, parsed_json, attempts) VALUES (?,?,?,?,?,?)",
                (task_type, str(item_id), raw_text, reason, payload, int(attempts)),
            )
            await conn.commit()

    async def iter_failures(self, task_type: Optional[str] = None) -> AsyncIterator[Dict]:
        sql = "SELECT id, task_type, item_id, raw_text, reason, parsed_json, attempts, created_at FROM json_failures"
        params: tuple = ()
        if task_type:
            sql += " WHERE task_type = ?"
            params = (task_type,)
        
        async with self._connect() as conn:
            conn.row_factory = aiosqlite.Row
            async with conn.execute(sql, params) as cursor:
                async for row in cursor:
                    rec = dict(row)
                    if rec.get("parsed_json"):
                        try:
                            rec["parsed_json"] = json.loads(rec["parsed_json"])  # type: ignore
                        except Exception:
                            pass
                    yield rec
