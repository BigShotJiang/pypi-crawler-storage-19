#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Anthropic Claude 客户端实现，满足 LLMClient 协议。
- 使用官方 anthropic 异步 SDK（如果不可用，可切换为 HTTP 请求）。
- 将通用 messages [{role, content}] 转换为 Claude 的 messages 结构。
"""

import asyncio
import logging
from typing import Dict, List, Optional, Tuple

from ..config.provider_config import ProviderConfig
from ..core.llm_client import LLMClient

try:
    # anthropic>=0.34 支持 AsyncAnthropic
    from anthropic import AsyncAnthropic
except Exception:  # pragma: no cover
    AsyncAnthropic = None  # type: ignore


class ClaudeClient(LLMClient):
    def __init__(
        self,
        provider: ProviderConfig,
        timeout: int,
        max_retries: int,
        logger: logging.Logger,
        context: Optional[object] = None,
    ) -> None:
        self.provider = provider
        self.timeout = timeout
        self.max_retries = max_retries
        self.logger = logger
        self.context = context
        self._client: Optional[AsyncAnthropic] = None

    @property
    def client(self) -> AsyncAnthropic:
        if self._client is None:
            if AsyncAnthropic is None:
                raise RuntimeError("anthropic SDK 未安装，请先 pip install anthropic")
            # Claude 使用 api_key 即可；base_url 可用于私有代理
            self._client = AsyncAnthropic(api_key=self.provider.api_key)
        return self._client

    async def call_with_retry(
        self, messages: List[Dict[str, str]], response_format: Optional[Dict] = None
    ) -> Tuple[Optional[object], bool]:
        # 将 OpenAI 风格 messages 转换为 Claude content
        system_prompts = [m["content"] for m in messages if m.get("role") == "system"]
        system_text = "\n\n".join(system_prompts) if system_prompts else None
        user_and_assistant: List[Dict[str, str]] = [
            {"role": m["role"], "content": m["content"]}
            for m in messages
            if m.get("role") in ("user", "assistant")
        ]

        # 构造请求
        for attempt in range(self.max_retries):
            try:
                kwargs = {}
                if response_format and response_format.get("type") == "json_object":
                    # Claude 需要 system 中提示或 tools 来约束 JSON；这里简单要求 json 输出
                    if system_text:
                        system_text += "\n\n请仅输出严格的 JSON。"
                    else:
                        system_text = "请仅输出严格的 JSON。"

                resp = await self.client.messages.create(
                    model=self.provider.model,
                    max_tokens=4096,
                    system=system_text,
                    messages=user_and_assistant,
                    timeout=self.timeout,
                )
                return resp, False
            except Exception as e:
                err = str(e).lower()
                if "rate" in err or "limit" in err:
                    if self.context and hasattr(self.context, "mark_rate_limited"):
                        self.context.mark_rate_limited()
                    self.logger.warning("Claude 触发速率限制")
                    return None, True
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(min(8, 2 ** attempt))
                else:
                    self.logger.error(f"Claude API 调用失败: {e}")
                    return None, False

    def extract_content(self, response: object) -> str:
        try:
            # anthropic 返回结构: response.content 为 list，元素可能是 {type: 'text', text: '...'}
            blocks = getattr(response, "content", [])
            for blk in blocks:
                if isinstance(blk, dict) and blk.get("type") == "text":
                    return blk.get("text", "")
                # SDK 对象形式
                if hasattr(blk, "type") and blk.type == "text":
                    return getattr(blk, "text", "")
            return ""
        except Exception:
            return getattr(response, "content", "") or ""

    async def close(self) -> None:
        # anthropic Async 客户端无需显式关闭；此处兼容接口
        self._client = None
