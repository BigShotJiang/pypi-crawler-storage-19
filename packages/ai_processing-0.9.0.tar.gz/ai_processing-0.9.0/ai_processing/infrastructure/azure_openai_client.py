#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Azure OpenAI 客户端实现，满足 LLMClient 协议。
- 使用 azure-openai 兼容的 OpenAI SDK 路径（openai>=1.0 已支持 base_url+api_version）。
- 需在 ProviderConfig 中提供 api_version，例如 "2024-08-01-preview"。
- base_url 需为 https://{resource}.openai.azure.com/ (或 /openai/deployments/{deployment} 由 SDK 处理)
- model 字段传入部署名 deployment_name。
"""

import asyncio
import logging
from typing import Dict, List, Optional, Tuple

from ..config.provider_config import ProviderConfig
from ..core.llm_client import LLMClient

try:
    from openai import AsyncOpenAI, APIError, RateLimitError
    from openai.types.chat.chat_completion import ChatCompletion
except Exception:  # pragma: no cover
    AsyncOpenAI = None  # type: ignore
    APIError = Exception  # type: ignore
    RateLimitError = Exception  # type: ignore
    ChatCompletion = object  # type: ignore


class AzureOpenAIClient(LLMClient):
    def __init__(
        self,
        provider: ProviderConfig,
        timeout: int,
        max_retries: int,
        logger: logging.Logger,
        context: Optional[object] = None,
    ) -> None:
        self.provider = provider
        self.timeout = timeout
        self.max_retries = max_retries
        self.logger = logger
        self.context = context
        self._client: Optional[AsyncOpenAI] = None

    @property
    def client(self) -> AsyncOpenAI:
        if self._client is None:
            if AsyncOpenAI is None:
                raise RuntimeError("openai SDK 未安装，请先 pip install openai>=1.0.0")
            if not self.provider.api_version:
                raise ValueError("Azure OpenAI 需要在 ProviderConfig.api_version 指定 API 版本")
            self._client = AsyncOpenAI(
                api_key=self.provider.api_key,
                base_url=self.provider.base_url,
                timeout=self.timeout,
                default_query={"api-version": self.provider.api_version},
            )
        return self._client

    async def call_with_retry(
        self, messages: List[Dict[str, str]], response_format: Optional[Dict] = None
    ) -> Tuple[Optional[ChatCompletion], bool]:
        for attempt in range(self.max_retries):
            try:
                kwargs = {"response_format": response_format} if response_format else {}
                # 在 Azure 中，model 传 deployment 名
                response = await self.client.chat.completions.create(
                    messages=messages,
                    model=self.provider.model,
                    timeout=self.timeout,
                    **kwargs,
                )
                return response, False
            except RateLimitError:
                self.logger.warning("Azure OpenAI 触发速率限制")
                if self.context and hasattr(self.context, "mark_rate_limited"):
                    self.context.mark_rate_limited()
                return None, True
            except APIError as e:
                if attempt == self.max_retries - 1:
                    self.logger.error(f"Azure OpenAI API 调用失败，已达最大重试次数: {e}")
                    return None, False
                self.logger.warning(
                    f"Azure OpenAI API 调用失败，即将重试... (尝试 {attempt + 1}/{self.max_retries})"
                )
                await asyncio.sleep(min(8, 2 ** attempt))
            except Exception as e:
                error_msg = str(e)
                if "rate" in error_msg.lower() or "throttle" in error_msg.lower():
                    self.logger.warning("检测到速率限制相关错误(Azure)")
                    if self.context and hasattr(self.context, "mark_rate_limited"):
                        self.context.mark_rate_limited()
                    return None, True
                self.logger.error(f"未知错误(Azure): {error_msg}")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(min(8, 2 ** attempt))
        return None, False

    def extract_content(self, response: ChatCompletion) -> str:
        try:
            return response.choices[0].message.content
        except Exception:
            return getattr(response, "content", "")

    async def close(self) -> None:
        if self._client:
            await self._client.close()
            self._client = None
