#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
API 客户端池：支持多提供方轮询与速率限制隔离
"""

import asyncio
import logging
import time
from typing import Dict, List, Optional, Tuple

from ..config.provider_config import ProviderConfig
from ..config.system_config import SystemConfig
from ..core.llm_client import LLMClient
from .api_client import ApiClient
from .anthropic_client import ClaudeClient
from .azure_openai_client import AzureOpenAIClient

try:
    from openai.types.chat.chat_completion import ChatCompletion
except Exception:  # pragma: no cover
    ChatCompletion = object


class _ClientState:
    def __init__(self, name: str | None = None) -> None:
        self.name = name or "provider"
        self.rate_limited_until: float = 0.0
        self.failure_cooldown_until: float = 0.0  # 失败冷却期，用于半开恢复探测
        self.consecutive_failures: int = 0
        self.open: bool = True  # 熔断器当前是否开放（允许正常调用）
        self.half_open: bool = False  # 半开状态标记：允许一次探测调用

    def is_available(self) -> bool:
        now = time.time()
        # 正常开放并且不在冷却；或处于半开探测期
        return (self.open and now >= self.rate_limited_until and now >= self.failure_cooldown_until) or self.half_open

    def mark_rate_limited(self, cool_down_seconds: int) -> None:
        self.rate_limited_until = time.time() + max(1, cool_down_seconds)

    def mark_failure(self, threshold: int = 5, cool_down_seconds: int = 30) -> None:
        self.consecutive_failures += 1
        if self.consecutive_failures >= threshold:
            # 进入熔断并设置失败冷却期，冷却后进入半开探测态
            self.open = False
            self.half_open = False
            self.failure_cooldown_until = time.time() + max(1, cool_down_seconds)

    def enter_half_open(self) -> None:
        # 失败冷却期结束后允许一次探测调用
        self.half_open = True

    def on_probe_success(self) -> None:
        # 探测成功，恢复开放并清零失败计数
        self.reset_failures()
        self.half_open = False
        self.open = True

    def on_probe_failure(self, cool_down_seconds: int = 30) -> None:
        # 探测失败，重新进入冷却等待下一次半开机会
        self.half_open = False
        self.open = False
        self.failure_cooldown_until = time.time() + max(1, cool_down_seconds)

    def reset_failures(self) -> None:
        self.consecutive_failures = 0
        self.open = True
        self.half_open = False
        self.failure_cooldown_until = 0.0


class ApiClientPool(LLMClient):
    def __init__(
        self,
        config: SystemConfig,
        logger: logging.Logger,
        context: Optional[object] = None,
        cool_down_seconds: int = 30,
        failure_threshold: int = 5,
    ) -> None:
        """
        构建客户端池
        - cool_down_seconds: 单客户端速率限制冷却时间
        - failure_threshold: 连续失败触发熔断的阈值
        """
        self.logger = logger
        self.context = context
        self.cool_down_seconds = cool_down_seconds
        self.failure_threshold = failure_threshold

        # 构建各客户端（按 model_type 选择具体实现）
        self.clients: List[LLMClient] = []
        for p in config.providers:
            if p.model_type == "openai":
                self.clients.append(
                    ApiClient(provider=p, timeout=config.timeout, max_retries=config.max_retries, logger=logger, context=context)
                )
            elif p.model_type == "claude":
                self.clients.append(
                    ClaudeClient(provider=p, timeout=config.timeout, max_retries=config.max_retries, logger=logger, context=context)
                )
            elif p.model_type == "azure":
                self.clients.append(
                    AzureOpenAIClient(provider=p, timeout=config.timeout, max_retries=config.max_retries, logger=logger, context=context)
                )
            else:
                # 默认回退到 OpenAI 兼容客户端
                self.clients.append(
                    ApiClient(provider=p, timeout=config.timeout, max_retries=config.max_retries, logger=logger, context=context)
                )
        self.states: List[_ClientState] = [
            _ClientState(name=p.name) for p in config.providers
        ]
        self._rr_index: int = 0  # 轮询索引
        self._last_client_index: Optional[int] = None  # 记录最近一次成功调用的客户端索引

    def _next_available_index(self) -> Optional[int]:
        n = len(self.clients)
        if n == 0:
            return None
        now = time.time()
        # 失败冷却到期的客户端进入半开态，允许一次探测
        for s in self.states:
            if (not s.open) and (not s.half_open) and now >= s.failure_cooldown_until:
                s.enter_half_open()
        # 轮询选择可用或半开的客户端
        for i in range(n):
            idx = (self._rr_index + i) % n
            if self.states[idx].is_available():
                self._rr_index = (idx + 1) % n
                return idx
        return None

    async def call_with_retry(
        self, messages: List[Dict[str, str]], response_format: Optional[Dict] = None
    ) -> Tuple[Optional[object], bool]:
        # 尝试所有可用客户端
        tried = 0
        n = len(self.clients)
        while tried < n:
            idx = self._next_available_index()
            if idx is None:
                # 全部不可用（受限或熔断）
                self.logger.warning("所有提供方当前不可用（速率限制或熔断），建议降并发并等待冷却")
                # 通知执行器进行降并发
                if hasattr(self.context, "mark_rate_limited") and callable(self.context.mark_rate_limited):
                    self.context.mark_rate_limited()
                return None, True

            client = self.clients[idx]
            state = self.states[idx]
            try:
                response, need_retry = await client.call_with_retry(messages, response_format)
                if need_retry:
                    # 该客户端触发速率限制，冷却后再试其它客户端
                    state.mark_rate_limited(self.cool_down_seconds)
                    tried += 1
                    continue
                # 成功，重置失败计数；若为半开探测则转为开放态
                if state.half_open:
                    state.on_probe_success()
                else:
                    state.reset_failures()
                # 记录最近一次成功的客户端索引，以便精确内容提取
                self._last_client_index = idx
                return response, False
            except Exception as e:
                self.logger.error(f"提供方[{state.name}] 调用异常: {e}")
                if state.half_open:
                    state.on_probe_failure(self.cool_down_seconds)
                else:
                    state.mark_failure(self.failure_threshold, self.cool_down_seconds)
                tried += 1
                continue

        # 尝试完所有客户端均失败或受限
        if hasattr(self.context, "mark_rate_limited") and callable(self.context.mark_rate_limited):
            self.context.mark_rate_limited()
        return None, True

    def extract_content(self, response: object) -> str:
        # 使用最近一次成功调用的具体客户端来提取（可更准确处理不同 SDK 返回）
        try:
            if self._last_client_index is not None:
                client = self.clients[self._last_client_index]
                return client.extract_content(response)  # type: ignore
            # 回退：OpenAI 风格
            return response.choices[0].message.content
        except Exception:
            return getattr(response, "content", "")

    async def close(self) -> None:
        # 关闭所有底层客户端
        for c in self.clients:
            await c.close()
