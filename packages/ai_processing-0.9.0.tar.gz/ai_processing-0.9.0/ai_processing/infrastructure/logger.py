#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import datetime
import logging
import os


def get_logger(
    log_name: str = "app_log", fmt: str | None = None, if_console: bool = True, base_path: str | None = None
) -> logging.Logger:
    """
    获取日志记录对象
    :param log_name: 日志记录对象名称
    :param fmt: 日志格式
    :param if_console: 是否输出到终端
    :param base_path: 日志文件存放目录
    :return: 日志记录对象
    """

    today = datetime.date.today()
    formatted_date = today.strftime("%Y%m%d")

    if not fmt:
        fmt = (
            "%(asctime)s.%(msecs)04d | %(levelname)8s | %(filename)s:%(lineno)d | %(message)s"
        )

    # 创建一个Logger，名称是app_log
    logger = logging.getLogger(log_name)

    # 设置为日志输出级别
    logger.setLevel(logging.DEBUG)

    # 创建formatter，并设置formatter的格式
    formatter = logging.Formatter(
        fmt=fmt,
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # 创建终端输出handler，为其设置格式，并添加到logger中
    if if_console:
        try:
            # 使用coloredlogs打印更好看的日志，注册即可，无需创建终端handler
            import coloredlogs  # type: ignore

            # 自定义日志的级别颜色
            level_color_mapping = {
                "DEBUG": {"color": "blue"},
                "INFO": {"color": "green"},
                "WARNING": {"color": "yellow", "bold": True},
                "ERROR": {"color": "red"},
                "CRITICAL": {"color": "red", "bold": True},
            }

            # 自定义日志的字段颜色
            field_color_mapping = dict(
                asctime=dict(color="green"),
                hostname=dict(color="magenta"),
                levelname=dict(color="white", bold=True),
                name=dict(color="blue"),
                programname=dict(color="cyan"),
                username=dict(color="yellow"),
            )

            coloredlogs.install(
                level=logging.DEBUG,
                logger=logger,
                milliseconds=True,
                datefmt="%X",
                fmt=fmt,
                level_styles=level_color_mapping,
                field_styles=field_color_mapping,
            )
        except Exception:
            # 方式一：降级为标准终端输出
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)  # 设置终端的输出级别为info

            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)

    # 若传入base_path，即传入日志文件存放目录，则创建文件输出handler，为其设置格式，并添加到logger中
    if base_path:
        if not os.path.exists(base_path):
            raise FileNotFoundError(f"{base_path} does not exist")

        # 拼接路径
        log_dir = os.path.join(base_path, "log")

        # 判断路径是否存在，不存在则创建
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        file_path = os.path.join(log_dir, f"{formatted_date}.log")

        file_handler = logging.FileHandler(
            filename=file_path, mode="a", encoding="utf8", delay=False
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger
