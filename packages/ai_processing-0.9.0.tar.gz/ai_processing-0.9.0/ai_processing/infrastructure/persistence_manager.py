#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: zibuyu_library
file: persistence_manager.py  
description: 持久化管理器
--------------------------------------------
"""

import json
import logging
import os
from typing import Any, Dict, Optional

from filelock import FileLock, Timeout


class PersistenceManager:
    """持久化管理器，处理数据的保存和加载"""

    def __init__(self, data_dir: str, logger: logging.Logger):
        """
        初始化持久化管理器

        Args:
            data_dir: 数据目录路径
            logger: 日志记录器
        """
        self.data_dir = data_dir
        self.logger = logger

        # 确保数据目录存在
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)

    def save_json(self, filename: str, data: Dict) -> bool:
        """
        保存JSON数据到文件

        Args:
            filename: 文件名（不含路径）
            data: 要保存的数据

        Returns:
            是否保存成功
        """
        try:
            filepath = os.path.join(self.data_dir, filename)
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self.logger.debug(f"成功保存数据到 {filename}")
            return True
        except Exception as e:
            self.logger.error(f"保存数据失败 {filename}: {e}")
            return False

    def load_json(self, filename: str) -> Optional[Dict]:
        """
        从文件加载JSON数据

        Args:
            filename: 文件名（不含路径）

        Returns:
            加载的数据字典，失败返回None
        """
        try:
            filepath = os.path.join(self.data_dir, filename)
            if not os.path.exists(filepath):
                self.logger.info(f"文件不存在: {filename}")
                return None

            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.logger.debug(f"成功加载数据从 {filename}")
            return data
        except Exception as e:
            self.logger.error(f"加载数据失败 {filename}: {e}")
            return None

    def save_text(self, filename: str, content: str) -> bool:
        """
        保存文本内容到文件

        Args:
            filename: 文件名（不含路径）
            content: 要保存的文本内容

        Returns:
            是否保存成功
        """
        try:
            filepath = os.path.join(self.data_dir, filename)
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(content)
            return True
        except Exception as e:
            self.logger.error(f"保存文本失败 {filename}: {e}")
            return False

    def load_text(self, filename: str) -> Optional[str]:
        """
        从文件加载文本内容

        Args:
            filename: 文件名（不含路径）

        Returns:
            文本内容，失败返回None
        """
        try:
            filepath = os.path.join(self.data_dir, filename)
            if not os.path.exists(filepath):
                return None

            with open(filepath, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            self.logger.error(f"加载文本失败 {filename}: {e}")
            return None

    def append_or_update_int(self, filename: str, value: int) -> bool:
        """
        追加或更新整数值（如token统计）

        Args:
            filename: 文件名
            value: 要追加的值

        Returns:
            是否成功
        """
        try:
            filepath = os.path.join(self.data_dir, filename)
            existing = 0

            if os.path.exists(filepath):
                with open(filepath, "r") as f:
                    try:
                        existing = int(f.read().strip())
                    except ValueError:
                        existing = 0

            with open(filepath, "w") as f:
                f.write(str(existing + value))
            return True
        except Exception as e:
            self.logger.error(f"更新整数值失败 {filename}: {e}")
            return False

    def merge_and_save_json(
        self,
        filename: str,
        new_data: Dict[str, Any],
        lock_timeout: int = 10
    ) -> None:
        """
        原子地合并并保存 JSON（用于排除集等）。
        
        流程：
        1. 获取文件锁
        2. 读取现有数据
        3. 合并 new_data（update 语义）
        4. 写回文件
        5. 释放锁
        """
        filepath = os.path.join(self.data_dir, filename)
        lock_path = f"{filepath}.lock"
        lock = FileLock(lock_path, timeout=lock_timeout)
        
        try:
            with lock:
                # 1. 读取现有数据
                existing_data = {}
                if os.path.exists(filepath):
                    try:
                        with open(filepath, "r", encoding="utf-8") as f:
                            content = f.read()
                            if content:
                                existing_data = json.loads(content)
                    except (json.JSONDecodeError, FileNotFoundError):
                        self.logger.warning(f"无法读取 {filename}，将创建新文件")
                        existing_data = {}
                
                # 2. 合并数据（update 语义）
                existing_data.update(new_data)
                
                # 3. 写回
                with open(filepath, "w", encoding="utf-8") as f:
                    json.dump(existing_data, f, ensure_ascii=False, indent=4)
        
        except Timeout:
            self.logger.error(f"获取文件锁 {lock_path} 超时（{lock_timeout}s）")
        except Exception as e:
            self.logger.error(f"合并保存 {filename} 失败: {e}")
