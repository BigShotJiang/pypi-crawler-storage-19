#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: ai_processing_framework
file: db_handler.py
author: 子不语
description: 数据库处理器，用于管理数据库连接和会话
--------------------------------------------
"""

import logging
import logging
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from .db_backends.base import DatabaseBackend

class DatabaseHandler:
    def __init__(self, backend: DatabaseBackend, logger: logging.Logger):
        self.backend = backend
        self.logger = logger
        
        # 使用 backend 提供的 URL 和选项
        engine_url = backend.get_engine_url()
        engine_options = backend.get_engine_options()
        
        self.logger.info(f"Creating database engine: {backend.get_safe_connection_string()}")
        
        self.engine = create_async_engine(engine_url, **engine_options)
        self.session_factory = async_sessionmaker(bind=self.engine, class_=AsyncSession, expire_on_commit=False)

    @property
    def session(self) -> AsyncSession:
        """获取一个新的异步会话"""
        return self.session_factory()

    async def close(self):
        await self.engine.dispose()
