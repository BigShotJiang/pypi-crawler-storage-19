"""
--------------------------------------------
project: ai_processing_framework
file: api_client.py
author: 子不语
date: 2025/11/2
--------------------------------------------
"""
import asyncio
import logging
from typing import Dict, Any, Optional, List, Tuple
from ..monitoring.types import EventPayload
from ..config.provider_config import ProviderConfig
from ..core.llm_client import LLMClient

import aiohttp
from tenacity import retry, stop_after_attempt, wait_random_exponential, retry_if_exception_type

class CircuitBreaker:
    """断路器，防止在服务故障时持续请求"""
    def __init__(self, failure_threshold: int = 3, recovery_timeout: int = 60):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failure_count = 0
        self.state = "closed"
        self.last_failure_time = None

    async def __aenter__(self):
        if self.state == "open":
            if asyncio.get_event_loop().time() - self.last_failure_time > self.recovery_timeout:
                self.state = "half-open"
            else:
                raise RuntimeError("Circuit is open")
        return self

    async def __aexit__(self, exc_type, exc_val, traceback):
        if exc_type:
            self.failure_count += 1
            if self.failure_count >= self.failure_threshold:
                self.state = "open"
                self.last_failure_time = asyncio.get_event_loop().time()
        else:
            if self.state == "half-open":
                self.state = "closed"
                self.failure_count = 0

class ApiClient(LLMClient):
    """
    异步API客户端，内置重试和断路器。
    实现了 LLMClient 接口，适配 OpenAI 格式的 API。
    """

    def __init__(
        self, 
        provider: ProviderConfig, 
        logger: logging.Logger,
        timeout: int = 300,
        max_retries: int = 3,
        context: Optional[Any] = None
    ):
        self.provider = provider
        self.logger = logger
        self.timeout = timeout
        self.max_retries = max_retries
        self.context = context
        self.circuit_breaker = CircuitBreaker()
        self._session = aiohttp.ClientSession()

    async def close(self):
        """关闭 aiohttp.ClientSession"""
        if self._session and not self._session.closed:
            await self._session.close()

    async def call_with_retry(
        self, messages: List[Dict[str, str]], response_format: Optional[Dict] = None
    ) -> Tuple[Optional[object], bool]:
        """
        调用 LLM API，返回 (response, need_retry)
        """
        payload = {
            "model": self.provider.model,
            "messages": messages,
        }
        if response_format:
            payload["response_format"] = response_format

        try:
            response_data = await self._post("/chat/completions", payload)
            return response_data, False
        except aiohttp.ClientResponseError as e:
            if e.status == 429:
                return None, True
            self.logger.error(f"API 调用失败: {e}")
            return None, False
        except Exception as e:
            self.logger.error(f"API 调用异常: {e}")
            return None, False

    def extract_content(self, response: object) -> str:
        """从响应中提取内容"""
        try:
            if isinstance(response, dict):
                return response["choices"][0]["message"]["content"]
            return getattr(response, "content", "")
        except Exception:
            return ""

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_random_exponential(multiplier=1, max=10),
        retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError))
    )
    async def _post(self, endpoint: str, payload: EventPayload) -> Optional[Dict[str, Any]]:
        """发送 POST 请求"""
        headers = {
            "Authorization": f"Bearer {self.provider.api_key}",
            "Content-Type": "application/json"
        }
        url = f"{self.provider.base_url}{endpoint}"

        async with self.circuit_breaker:
            try:
                async with self._session.post(url, json=payload, headers=headers, timeout=self.timeout) as response:
                    if response.status == 429:
                        raise aiohttp.ClientResponseError(
                            request_info=response.request_info,
                            history=response.history,
                            status=response.status,
                            message="Rate limit",
                            headers=response.headers,
                        )
                    response.raise_for_status()
                    return await response.json()
            except aiohttp.ClientResponseError as e:
                if e.status == 429:
                    raise
                raise
            except Exception:
                raise
