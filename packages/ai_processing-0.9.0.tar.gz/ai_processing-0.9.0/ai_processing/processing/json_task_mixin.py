#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

from typing import Any
from ..types import ProcessItem

from ..core.json_response import JsonTaskEngine
from ..config import TaskConfig


class JsonTaskMixin:
    async def process_json_item(self, item: ProcessItem, task_type: str, engine: JsonTaskEngine) -> bool:
        """
        通用 JSON 任务处理：
        - 通过 TaskConfig 取提示模板构造 messages
        - 调用 JsonTaskEngine 执行（解析/校验/重试）
        - 成功后将结果交由具体处理器持久化，失败返回 False
        备注：具体持久化由处理器子类实现（如写入数据库等）
        """
        prompt = TaskConfig.get_prompt(task_type)
        content = prompt.format(**getattr(item, "to_dict", lambda: {})()) if hasattr(item, "to_dict") else prompt
        messages = [
            {"role": "system", "content": "你是一个严格的 JSON 生成器，只输出符合 Schema 的 JSON。"},
            {"role": "user", "content": content},
        ]
        result = await engine.run(messages, task_type)
        if result.success:
            return await self.on_json_success(item, task_type, result.data, result)  # type: ignore
        return await self.on_json_failure(item, task_type, result)  # type: ignore

    async def on_json_success(self, item: ProcessItem, task_type: str, data: dict, result) -> bool:  # noqa: D401
        """处理成功（子类实现：入库/落盘）"""
        raise NotImplementedError

    async def on_json_failure(self, item: ProcessItem, task_type: str, result) -> bool:  # noqa: D401
        """处理失败（子类实现：记录、或标记）"""
        return False
