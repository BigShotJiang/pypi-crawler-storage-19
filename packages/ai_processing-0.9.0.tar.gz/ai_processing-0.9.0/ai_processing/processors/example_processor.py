"""
--------------------------------------------
project: ai_processing_framework
file: example_processor.py
author: 子不语
date: 2025/11/2
--------------------------------------------
"""
from typing import Dict, Any
from ..types import ProcessItem

from ai_processing.core.base_task_processor import BaseTaskProcessor

class ExampleProcessor(BaseTaskProcessor):
    """示例任务处理器"""

    async def process_item(self, item: ProcessItem, task_type: str = "") -> bool:
        """处理单个数据项"""
        # 1. 构建 prompt
        prompt = self.task_config.prompt_template.format(**item)

        # 2. 调用 API
        payload = {
            "model": self.api_client.model,
            "messages": [{"role": "user", "content": prompt}]
        }
        # 捕获 429 限流并标记，上层会自适应降低批量
        import aiohttp
        try:
            response = await self.api_client.post("/chat/completions", payload)
        except aiohttp.ClientResponseError as e:
            if e.status == 429:
                self.context.mark_rate_limited()
                item_id = item.get("id")
                if item_id is not None:
                    self.context.add_to_process(item)
                return False
            # 其他响应错误上抛，由执行器捕获
            raise

        if response is None:
            # 请求失败但非 429：若能获取 id，加入重试队列
            item_id = item.get("id")
            if item_id is not None:
                self.context.add_to_process(item)
            return False

        # 3. 解析结果
        processed_content = response["choices"][0]["message"]["content"]

        # 4. 更新数据库
        await self.db_adapter.execute(
            f"UPDATE {self.task_config.db_table} SET processed_content = ? WHERE id = ?",
            (processed_content, item["id"])
        )
        # 累加 token（若返回包含）
        try:
            self.context.add_tokens(int(response["usage"]["total_tokens"]))
        except Exception:
            pass
        return True
