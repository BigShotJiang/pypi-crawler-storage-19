#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

from typing import Awaitable, Callable, Dict

JobFactory = Callable[[], Awaitable[None]]
_REGISTRY: Dict[str, JobFactory] = {}


def register_job(name: str, factory: JobFactory) -> None:
    _REGISTRY[name] = factory


def get_job(name: str) -> JobFactory:
    if name not in _REGISTRY:
        raise KeyError(f"job 未注册: {name}")
    return _REGISTRY[name]
