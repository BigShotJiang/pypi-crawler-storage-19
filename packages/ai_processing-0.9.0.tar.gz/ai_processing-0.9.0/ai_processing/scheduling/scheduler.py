#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional
from ..monitoring.types import EventPayload

try:
    from ai_processing.monitoring.metrics_prom import record_scheduler_event, observe_job_duration
except ImportError:
    def record_scheduler_event(event_type: str) -> None: pass
    def observe_job_duration(seconds: float) -> None: pass


JobCallable = Callable[[], Awaitable[None]]


@dataclass
class ScheduledJob:
    name: str
    kind: str  # "interval" | "once"
    coro_factory: Callable[[], Awaitable[None]]
    interval_seconds: Optional[float] = None
    run_at_ts: Optional[float] = None
    next_run_ts: float = field(default_factory=lambda: time.time())
    enabled: bool = True


class MinimalScheduler:
    def __init__(self, logger, event_bus: Optional[object] = None, metrics_sink: Optional[object] = None, poll_interval: float = 0.2) -> None:
        self._logger = logger
        self._event_bus = event_bus
        self._metrics = metrics_sink
        self._poll = max(0.05, float(poll_interval))
        self._jobs: Dict[str, ScheduledJob] = {}
        self._stop = False
        self._task: Optional[asyncio.Task] = None

    def add_interval_job(self, name: str, seconds: float, coro_factory: Callable[[], Awaitable[None]]) -> None:
        now = time.time()
        self._jobs[name] = ScheduledJob(name=name, kind="interval", coro_factory=coro_factory, interval_seconds=max(0.1, float(seconds)), next_run_ts=now + max(0.1, float(seconds)))
        self._emit("job_scheduled", {"name": name, "kind": "interval", "interval_seconds": seconds})

    def add_once_job(self, name: str, run_after_seconds: float, coro_factory: Callable[[], Awaitable[None]]) -> None:
        run_ts = time.time() + max(0.0, float(run_after_seconds))
        self._jobs[name] = ScheduledJob(name=name, kind="once", coro_factory=coro_factory, run_at_ts=run_ts, next_run_ts=run_ts)
        self._emit("job_scheduled", {"name": name, "kind": "once", "run_at_ts": int(run_ts)})

    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._stop = False
        self._logger.info("MinimalScheduler 启动")
        self._emit("scheduler_start", {})
        self._task = asyncio.create_task(self._run_loop())

    async def stop(self) -> None:
        self._stop = True
        if self._task:
            try:
                await self._task
            except Exception:
                pass
        self._emit("scheduler_stop", {})
        self._logger.info("MinimalScheduler 停止")

    async def _run_loop(self) -> None:
        while not self._stop:
            now = time.time()
            due: List[ScheduledJob] = []
            for job in list(self._jobs.values()):
                if not job.enabled:
                    continue
                if now + 1e-9 >= job.next_run_ts:
                    due.append(job)
            # 逐个触发（避免长任务阻塞调度，将作业放入任务）
            for job in due:
                asyncio.create_task(self._run_job(job))
                # 计算下次运行时间或禁用（once）
                if job.kind == "interval" and job.interval_seconds:
                    job.next_run_ts = time.time() + job.interval_seconds
                else:
                    job.enabled = False
            await asyncio.sleep(self._poll)

    async def _run_job(self, job: ScheduledJob) -> None:
        t0 = time.time()
        self._emit("job_start", {"name": job.name})
        record_scheduler_event("job_start")
        try:
            await job.coro_factory()
            dt = time.time() - t0
            self._emit("job_finish", {"name": job.name, "duration": dt})
            observe_job_duration(dt)
            record_scheduler_event("job_finish")
            self._logger.info(f"[scheduler] job {job.name} 完成，用时 {dt:.3f}s")
        except Exception as e:
            dt = time.time() - t0
            self._emit("job_error", {"name": job.name, "error": str(e)})
            record_scheduler_event("job_error")
            self._logger.error(f"[scheduler] job {job.name} 异常：{e} （{dt:.3f}s）", exc_info=True)

    def _emit(self, event_type: str, payload: EventPayload) -> None:
        if self._event_bus:
            try:
                self._event_bus.publish(event_type, payload)
            except Exception:
                pass
        # 可扩展 metrics，如有需要在此桥接
