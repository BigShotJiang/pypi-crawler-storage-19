#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
框架错误层次定义：用于在解析、校验与模型调用链路中进行精确异常分类
"""

class FrameworkError(Exception):
    """框架基类异常"""


class ModelCallError(FrameworkError):
    """模型调用失败（非速率限制）"""


class RateLimitedError(FrameworkError):
    """触发速率限制"""


class ParsingError(FrameworkError):
    """模型输出解析失败（无法提取有效 JSON）"""


class SchemaValidationError(FrameworkError):
    """JSON 通过解析但未通过 Schema 校验"""