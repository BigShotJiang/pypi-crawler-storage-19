#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

from typing import Optional

from .task_context import TaskContext


class ControlAPI:
    """简易控制平面：提供取消与状态查询接口（内存实现）"""

    def __init__(self, context: TaskContext, logger, event_bus: Optional[object] = None, metrics_sink: Optional[object] = None) -> None:
        self.context = context
        self.logger = logger
        self.event_bus = event_bus
        self.metrics = metrics_sink

    def cancel(self, reason: str = "") -> None:
        try:
            setattr(self.context, "cancel_requested", True)
            if reason:
                setattr(self.context, "cancel_reason", reason)
        except Exception:
            pass
        self.logger.warning(f"收到取消请求：{reason}")
        if self.event_bus:
            try:
                self.event_bus.publish("task_cancel_requested", {"reason": reason})
            except Exception:
                pass
        if self.metrics and hasattr(self.metrics, "on_task_cancel"):
            try:
                self.metrics.on_task_cancel({"reason": reason})
            except Exception:
                pass

    def status(self) -> dict:
        return {
            "cancel_requested": bool(getattr(self.context, "cancel_requested", False)),
            "cancel_reason": getattr(self.context, "cancel_reason", None),
        }
