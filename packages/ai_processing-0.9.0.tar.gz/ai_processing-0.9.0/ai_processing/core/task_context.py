"""
--------------------------------------------
project: ai_processing_framework
file: task_context.py
description: 任务执行上下文，管理运行时状态
--------------------------------------------
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List
from ..types import ProcessItem

@dataclass
class TaskContext:
    """任务执行上下文，管理所有运行时状态"""

    # 排除数据：键为需排除的id，值为失败次数
    exclude_data: Dict[int, int] = field(default_factory=dict)

    # 待重试数据：存放因触碰请求速率限制而失败的数据
    process_data: List[ProcessItem] = field(default_factory=list)

    # 缓存数据：如作者信息缓存
    cache: Dict[str, Any] = field(default_factory=dict)

    # 统计信息
    total_token: int = 0
    success_count: int = 0
    failed_count: int = 0 # 新增失败计数

    # 动态调节速率相关
    concurrent_cumulative_quantity: int = 1  # 累计并发数

    # 速率限制标志
    rate_limited: bool = False

    def add_exclude(self, item_id: int) -> None:
        """添加排除数据"""
        self.exclude_data[item_id] = self.exclude_data.get(item_id, 0) + 1

    def should_exclude(self, item_id: int, threshold: int) -> bool:
        """判断是否应该排除"""
        return self.exclude_data.get(item_id, 0) >= threshold

    def add_to_process(self, item: ProcessItem) -> None:
        """添加到待重试队列"""
        self.process_data.append(item)

    def get_cache(self, key: str, default: Any = None) -> Any:
        """获取缓存"""
        return self.cache.get(key, default)

    def set_cache(self, key: str, value: Any) -> None:
        """设置缓存"""
        self.cache[key] = value

    def increment_success(self) -> None:
        """增加成功计数"""
        self.success_count += 1

    def increment_failed(self) -> None:
        """增加失败计数"""
        self.failed_count += 1

    def add_tokens(self, tokens: int) -> None:
        """累加token数量"""
        self.total_token += tokens

    def increase_concurrency(self) -> None:
        """增加并发累计量"""
        self.concurrent_cumulative_quantity *= 2

    def reset_concurrency(self) -> None:
        """重置并发累计量"""
        self.concurrent_cumulative_quantity = 1

    def mark_rate_limited(self) -> None:
        """标记触发了速率限制"""
        self.rate_limited = True

    def clear_rate_limit_flag(self) -> None:
        """清除速率限制标志"""
        self.rate_limited = False
