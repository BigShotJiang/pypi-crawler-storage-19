#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import threading
import time
from typing import Optional


class CancelToken:
    """线程/协程安全的取消令牌，用于外部请求优雅取消任务"""

    def __init__(self) -> None:
        self._flag = threading.Event()
        self._reason: Optional[str] = None
        self._ts: Optional[float] = None

    def cancel(self, reason: Optional[str] = None) -> None:
        self._reason = reason
        self._ts = time.time()
        self._flag.set()

    def is_cancelled(self) -> bool:
        return self._flag.is_set()

    @property
    def reason(self) -> Optional[str]:
        return self._reason

    @property
    def timestamp(self) -> Optional[float]:
        return self._ts
