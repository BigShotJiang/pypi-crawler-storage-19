"""
--------------------------------------------
project: ai_processing_framework
file: context_persister.py
author: 子不语
date: 2025/11/21
description: 累积上下文持久化接口及实现
--------------------------------------------
"""
from abc import ABC, abstractmethod
from typing import Any, Optional
import logging

from .accumulated_context import AccumulatedContext

logger = logging.getLogger(__name__)


class ContextPersister(ABC):
    """累积上下文持久化接口"""
    
    @abstractmethod
    async def save(self, context: AccumulatedContext, key: str) -> None:
        """
        保存上下文
        
        Args:
            context: 累积上下文实例
            key: 持久化键(如 book_id, project_id 等)
        
        Raises:
            ValueError: 保存失败时抛出
        """
        pass
    
    @abstractmethod
    async def load(self, key: str, context_class: type) -> Optional[AccumulatedContext]:
        """
        加载上下文
        
        Args:
            key: 持久化键
            context_class: 上下文类(用于反序列化)
            
        Returns:
            累积上下文实例,如果不存在或反序列化失败则返回 None
        """
        pass
    
    @abstractmethod
    async def exists(self, key: str) -> bool:
        """
        检查上下文是否存在
        
        Args:
            key: 持久化键
            
        Returns:
            如果存在返回 True,否则返回 False
        """
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> None:
        """
        删除上下文
        
        Args:
            key: 持久化键
        """
        pass


class DatabasePersister(ContextPersister):
    """
    基于数据库字段的持久化实现
    
    将上下文序列化为 JSON 存储到指定的数据库字段
    """
    
    def __init__(self, db_adapter, model_class, key_field: str = 'id', context_field: str = 'other'):
        """
        Args:
            db_adapter: DatabaseAdapter 实例
            model_class: ORM 模型类(如 Book)
            key_field: 键字段名(默认 'id')
            context_field: 上下文存储字段名(默认 'other')
        """
        self.db_adapter = db_adapter
        self.model_class = model_class
        self.key_field = key_field
        self.context_field = context_field
    
    async def save(self, context: AccumulatedContext, key: str) -> None:
        from sqlalchemy import update
        from ai_processing.infrastructure.db_utils import commit_with_retry
        
        async with self.db_adapter.handler.session as session:
            try:
                # 更新上下文字段
                stmt = (
                    update(self.model_class)
                    .where(getattr(self.model_class, self.key_field) == key)
                    .values({self.context_field: context.to_json()})
                )
                result = await session.execute(stmt)
                
                if result.rowcount == 0:
                    raise ValueError(f"Entity with {self.key_field}={key} not found")
                
                await commit_with_retry(session)
                logger.debug(f"Saved context to database for key={key}")
            except Exception as e:
                await session.rollback()
                raise ValueError(f"Failed to save context: {e}") from e
    
    async def load(self, key: str, context_class: type) -> Optional[AccumulatedContext]:
        from sqlalchemy import select
        
        async with self.db_adapter.handler.session as session:
            stmt = select(self.model_class).where(
                getattr(self.model_class, self.key_field) == key
            )
            result = await session.execute(stmt)
            entity = result.scalar_one_or_none()
            
            if entity is None:
                logger.debug(f"Entity not found for key={key}")
                return None
            
            json_str = getattr(entity, self.context_field, None)
            if not json_str or json_str.strip() == '':
                logger.debug(f"Context field is empty for key={key}")
                return None
            
            try:
                loaded_context = context_class.from_json(json_str)
                logger.debug(f"Loaded context from database for key={key}")
                return loaded_context
            except Exception as e:
                # 反序列化失败,记录日志但返回 None(让调用方创建新实例)
                logger.error(f"Failed to deserialize context for key={key}: {e}")
                return None
    
    async def exists(self, key: str) -> bool:
        from sqlalchemy import select, func
        
        async with self.db_adapter.handler.session as session:
            stmt = (
                select(func.count())
                .select_from(self.model_class)
                .where(getattr(self.model_class, self.key_field) == key)
            )
            result = await session.execute(stmt)
            count = result.scalar()
            return count > 0
    
    async def delete(self, key: str) -> None:
        from sqlalchemy import update
        from ai_processing.infrastructure.db_utils import commit_with_retry
        
        async with self.db_adapter.handler.session as session:
            try:
                stmt = (
                    update(self.model_class)
                    .where(getattr(self.model_class, self.key_field) == key)
                    .values({self.context_field: None})
                )
                await session.execute(stmt)
                await commit_with_retry(session)
                logger.debug(f"Deleted context from database for key={key}")
            except Exception as e:
                await session.rollback()
                raise ValueError(f"Failed to delete context: {e}") from e


class FilePersister(ContextPersister):
    """
    基于文件的持久化实现
    
    将上下文保存为 JSON 文件
    """
    
    def __init__(self, storage_dir: str):
        """
        Args:
            storage_dir: 存储目录路径
        """
        self.storage_dir = storage_dir
        import os
        os.makedirs(storage_dir, exist_ok=True)
    
    def _get_file_path(self, key: str) -> str:
        import os
        import re
        # 清理 key 中的所有非法字符(Windows: < > : " / \ | ? *)
        safe_key = re.sub(r'[<>:"/\\|?*]', '_', key)
        return os.path.join(self.storage_dir, f"{safe_key}.json")
    
    def _write_file_sync(self, path: str, content: str) -> None:
        """同步文件写入(在线程池中执行)"""
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
    
    def _read_file_sync(self, path: str) -> str:
        """同步文件读取(在线程池中执行)"""
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    
    async def save(self, context: AccumulatedContext, key: str) -> None:
        import asyncio
        file_path = self._get_file_path(key)
        content = context.to_json()
        await asyncio.to_thread(self._write_file_sync, file_path, content)
        logger.debug(f"Saved context to file: {file_path}")
    
    async def load(self, key: str, context_class: type) -> Optional[AccumulatedContext]:
        import asyncio
        import os
        
        file_path = self._get_file_path(key)
        if not os.path.exists(file_path):
            logger.debug(f"Context file not found: {file_path}")
            return None
        
        try:
            content = await asyncio.to_thread(self._read_file_sync, file_path)
            loaded_context = context_class.from_json(content)
            logger.debug(f"Loaded context from file: {file_path}")
            return loaded_context
        except Exception as e:
            logger.error(f"Failed to load context from file {file_path}: {e}")
            return None
    
    async def exists(self, key: str) -> bool:
        import os
        file_path = self._get_file_path(key)
        return os.path.exists(file_path)
    
    async def delete(self, key: str) -> None:
        import asyncio
        import os
        
        file_path = self._get_file_path(key)
        if os.path.exists(file_path):
            await asyncio.to_thread(os.remove, file_path)
            logger.debug(f"Deleted context file: {file_path}")


# 便捷工厂函数
def create_database_persister(
    db_adapter,
    model_class: type,
    key_field: str = 'id',
    context_field: str = 'other'
) -> DatabasePersister:
    """
    创建数据库持久化器的便捷函数
    
    Args:
        db_adapter: DatabaseAdapter 实例
        model_class: ORM 模型类
        key_field: 键字段名
        context_field: 上下文存储字段名
        
    Returns:
        DatabasePersister 实例
    """
    return DatabasePersister(db_adapter, model_class, key_field, context_field)


def create_file_persister(storage_dir: str) -> FilePersister:
    """
    创建文件持久化器的便捷函数
    
    Args:
        storage_dir: 存储目录路径
        
    Returns:
        FilePersister 实例
    """
    return FilePersister(storage_dir)
