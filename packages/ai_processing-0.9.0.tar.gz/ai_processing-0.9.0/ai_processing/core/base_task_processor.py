"""
--------------------------------------------
project: ai_processing_framework
file: base_task_processor.py
author: 子不语
date: 2025/11/2
--------------------------------------------
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Dict, Any, List, TYPE_CHECKING, Optional
import logging

from ai_processing.config.task_config import TaskConfig
from ai_processing.types import TaskContext, ProcessItem

if TYPE_CHECKING:
    from ai_processing.infrastructure.api_client import ApiClient
    from ai_processing.infrastructure.database_adapter import DatabaseAdapter
    from ai_processing.core.accumulated_context import AccumulatedContext
    from ai_processing.core.context_persister import ContextPersister

class BaseTaskProcessor(ABC):
    """任务处理器基类"""

    def __init__(
        self,
        task_config: TaskConfig,
        api_client: ApiClient,
        db_adapter: DatabaseAdapter,
        context: TaskContext,
        logger: logging.Logger = None,
    ):
        self.task_config = task_config
        self.api_client = api_client
        self.db_adapter = db_adapter
        self.context = context
        self.logger = logger or logging.getLogger(__name__)
        
        # 累积上下文支持(可选)
        self._accumulated_context: Optional['AccumulatedContext'] = None
        self._context_persister: Optional['ContextPersister'] = None

    @abstractmethod
    async def process_item(self, item: ProcessItem, task_type: str = "") -> bool:
        """处理单个数据项，返回 True 表示成功，False 表示失败"""
        pass

    def get_model_class(self) -> Any:
        """获取数据模型类"""
        # 默认尝试从 task_config 获取，或者由子类实现
        if hasattr(self.task_config, "model_class"):
            return self.task_config.model_class
        raise NotImplementedError("Processor must implement get_model_class or provide model_class in config")

    def get_filter_condition(self, task_type: str = "") -> Any:
        """获取过滤条件"""
        # 默认自动检测是否需要依赖过滤
        return self.get_dependency_filter()

    def get_order_by(self, task_type: str = "") -> Any:
        """获取排序条件"""
        return None

    def get_dependency_filter(self) -> Any:
        """
        获取依赖过滤条件
        如果模型包含 previous_task_id 字段,则只获取 previous_task_id 为空 或 前置任务已完成的任务
        """
        try:
            model_class = self.get_model_class()
            if hasattr(model_class, "previous_task_id") and hasattr(model_class, "done"):
                from sqlalchemy import or_, select
                from sqlalchemy.orm import aliased
                
                # Use alias for the previous task table to avoid ambiguity
                previous = aliased(model_class)
                
                # previous_task_id is NULL OR (previous task is done)
                previous_done = (
                    select(previous.done)
                    .where(previous.id == model_class.previous_task_id)
                    .scalar_subquery()
                )
                return or_(model_class.previous_task_id.is_(None), previous_done == 1)
        except Exception as e:
            self.logger.warning(f"Error creating dependency filter: {e}")
        return None
    
    # === 累积上下文支持 ===
    
    def get_accumulated_context_class(self) -> Optional[type]:
        """
        返回累积上下文类
        
        子类重写此方法以启用累积上下文功能
        
        Returns:
            累积上下文类,如果不需要则返回 None
        """
        return None
    
    def get_context_persister(self) -> Optional['ContextPersister']:
        """
        返回上下文持久化器
        
        子类可重写此方法自定义持久化策略
        默认检查 task_config 的属性
        
        Returns:
            持久化器实例,如果不需要则返回 None
        """
        from ai_processing.core.context_persister import create_database_persister, create_file_persister
        
        # 默认实现: 检查 task_config 属性
        config = getattr(self.task_config, 'context_persistence', None)
        if config is None:
            return None
        
        if isinstance(config, dict):
            if config.get('type') == 'database':
                return create_database_persister(
                    db_adapter=self.db_adapter,
                    model_class=config['model_class'],
                    key_field=config.get('key_field', 'id'),
                    context_field=config.get('context_field', 'other')
                )
            elif config.get('type') == 'file':
                return create_file_persister(storage_dir=config['storage_dir'])
        
        return None
    
    def get_context_key(self) -> Optional[str]:
        """
        返回当前处理的上下文键
        
        子类必须重写此方法以指定持久化键(如 book_id)
        
        Returns:
            上下文键,如果无法确定则返回 None
        """
        # 尝试从 task_config 或 context 获取
        if hasattr(self.task_config, 'context_key'):
            return str(self.task_config.context_key)
        if hasattr(self.context, 'get_cache'):
            key = self.context.get_cache('context_key')
            if key is not None:
                return str(key)
        return None
    
    async def load_accumulated_context(self) -> Optional['AccumulatedContext']:
        """
        加载累积上下文
        
        调用时机: 在处理器开始处理前手动调用(如在 run() 方法开始时)
        
        Returns:
            累积上下文实例,如果不存在或未配置则返回新实例
        """
        context_class = self.get_accumulated_context_class()
        if context_class is None:
            return None
        
        persister = self.get_context_persister()
        context_key = self.get_context_key()
        
        if persister is None or context_key is None:
            # 没有持久化配置,创建新实例
            self._accumulated_context = context_class()
            self.logger.info("Created new accumulated context (no persistence)")
            return self._accumulated_context
        
        # 尝试加载
        self._context_persister = persister
        try:
            loaded = await persister.load(context_key, context_class)
            if loaded is None:
                # 不存在,创建新实例
                loaded = context_class()
                self.logger.info(f"Created new accumulated context for key: {context_key}")
            else:
                self.logger.info(f"Loaded accumulated context for key: {context_key}")
            
            self._accumulated_context = loaded
            return loaded
        except Exception as e:
            # 加载失败,创建新实例
            self.logger.error(f"Failed to load accumulated context: {e}", exc_info=True)
            self._accumulated_context = context_class()
            return self._accumulated_context
    
    async def save_accumulated_context(self) -> None:
        """
        保存累积上下文
        
        调用时机: 在每个 process_item() 成功后手动调用,或在处理器结束时调用
        
        错误策略: 保存失败时记录日志但不抛出异常(不中断任务处理)
        """
        if self._accumulated_context is None or self._context_persister is None:
            return
        
        context_key = self.get_context_key()
        if context_key is None:
            self.logger.warning("Cannot save accumulated context: context_key is None")
            return
        
        try:
            await self._context_persister.save(self._accumulated_context, context_key)
            self.logger.debug(f"Accumulated context saved for key: {context_key}")
        except Exception as e:
            # 保存失败不中断任务,仅记录日志
            self.logger.error(f"Failed to save accumulated context: {e}", exc_info=True)
    
    def get_accumulated_context(self) -> Optional['AccumulatedContext']:
        """
        获取当前累积上下文
        
        子类在 process_item() 中使用此方法访问累积上下文
        
        Returns:
            累积上下文实例,如果未加载则返回 None
        """
        return self._accumulated_context
    
    async def finalize_accumulated_context(self) -> None:
        """
        处理器结束时调用,确保上下文已保存
        
        调用时机: 在处理器的 run() 方法结束前调用
        """
        if self._accumulated_context is not None:
            await self.save_accumulated_context()
            self.logger.info("Accumulated context finalized")
