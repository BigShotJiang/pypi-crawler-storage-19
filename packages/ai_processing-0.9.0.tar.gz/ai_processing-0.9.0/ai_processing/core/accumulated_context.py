"""
--------------------------------------------
project: ai_processing_framework
file: accumulated_context.py
author: 子不语
date: 2025/11/21
description: 累积上下文抽象基类，用于跨任务累积和传递数据
--------------------------------------------
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, TypeVar, Optional
import json

T = TypeVar('T')

class AccumulatedContext(ABC, Generic[T]):
    """
    累积上下文抽象基类
    
    用于跨任务累积和传递数据。每种任务类型可以定义自己的上下文结构。
    
    Example:
        >>> @dataclass
        >>> class MyContext(AccumulatedContext):
        >>>     counter: int = 0
        >>>     
        >>>     def update(self, task_result: Dict, task_id: Any) -> None:
        >>>         self.counter += 1
        >>>     
        >>>     def to_dict(self) -> Dict[str, Any]:
        >>>         return {"counter": self.counter}
        >>>     
        >>>     @classmethod
        >>>     def from_dict(cls, data: Dict[str, Any]) -> 'MyContext':
        >>>         return cls(counter=data.get('counter', 0))
    """
    
    @abstractmethod
    def update(self, task_result: T, task_id: Any) -> None:
        """
        根据任务结果更新累积上下文
        
        Args:
            task_result: 任务处理的输出结果(通常是 AI 返回的解析后数据)
            task_id: 任务唯一标识(如 chapter.id)
        """
        pass
    
    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """
        序列化为字典,用于持久化
        
        Returns:
            包含所有上下文数据的字典
        """
        pass
    
    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AccumulatedContext':
        """
        从字典反序列化
        
        实现时应处理字段缺失情况,提供默认值以确保向后兼容
        
        Args:
            data: 序列化的上下文数据
            
        Returns:
            累积上下文实例
        """
        pass
    
    def to_json(self) -> str:
        """
        序列化为 JSON 字符串
        
        Returns:
            JSON 格式的上下文数据
        """
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'AccumulatedContext':
        """
        从 JSON 字符串反序列化
        
        Args:
            json_str: JSON 格式的上下文数据
            
        Returns:
            累积上下文实例
            
        Raises:
            json.JSONDecodeError: JSON 解析失败
        """
        data = json.loads(json_str)
        return cls.from_dict(data)
    
    def get_metadata(self, key: str, default: Any = None) -> Any:
        """
        获取元数据(通用方法,子类可重写)
        
        Args:
            key: 元数据键
            default: 默认值
            
        Returns:
            元数据值,如果不存在则返回默认值
        """
        if hasattr(self, 'metadata') and isinstance(self.metadata, dict):
            return self.metadata.get(key, default)
        return default
    
    def set_metadata(self, key: str, value: Any) -> None:
        """
        设置元数据(通用方法,子类可重写)
        
        Args:
            key: 元数据键
            value: 元数据值
        """
        if not hasattr(self, 'metadata'):
            self.metadata = {}
        self.metadata[key] = value
    
    def get_stats(self) -> Dict[str, Any]:
        """
        获取上下文统计信息(子类可重写,用于监控)
        
        Returns:
            包含统计信息的字典
        """
        return {
            "class": self.__class__.__name__,
            "total_processed": self.get_metadata('total_chapters_processed', 0),
            "last_updated": self.get_metadata('last_updated', None),
        }
