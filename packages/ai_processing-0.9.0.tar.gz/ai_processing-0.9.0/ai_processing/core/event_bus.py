#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
事件总线协议与简单实现
"""

from typing import Protocol, Callable, Dict, Any, List
from ..monitoring.types import EventPayload


class EventPublisher(Protocol):
    def publish(self, event_type: str, payload: EventPayload) -> None:
        ...


class SimpleEventBus(EventPublisher):
    def __init__(self) -> None:
        self._subscribers: Dict[str, List[Callable[[EventPayload], None]]] = {}

    def subscribe(self, event_type: str, handler: Callable[[EventPayload], None]) -> None:
        self._subscribers.setdefault(event_type, []).append(handler)

    def publish(self, event_type: str, payload: EventPayload) -> None:
        for handler in self._subscribers.get(event_type, []):
            try:
                handler(payload)
            except Exception:
                # 忽略单个订阅者异常，避免影响主流程
                pass
