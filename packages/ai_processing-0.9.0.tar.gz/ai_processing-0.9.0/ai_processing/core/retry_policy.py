#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from dataclasses import dataclass


@dataclass
class RetryPolicy:
    """
    JSON 任务的重试策略
    - max_attempts: 最大尝试次数（包含首次）
    - backoff_base_ms: 指数退避基数（毫秒）
    - backoff_jitter_ms: 抖动范围（毫秒）
    - escalate_prompt: 是否在重试时升级系统提示（加入上轮错误原因与更严格要求）
    """
    max_attempts: int = 3
    backoff_base_ms: int = 500
    backoff_jitter_ms: int = 200
    escalate_prompt: bool = True