#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
JSON 解析与校验中台：
- JsonSanitizer: 从 LLM 文本输出中稳健提取 JSON
- JsonValidator: 基于 jsonschema 的校验器（带编译缓存）
- JsonTaskEngine: 串起调用/抽取/解析/校验/重试
"""

from __future__ import annotations

import asyncio
import json
import random
import re
import time
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING
from ..monitoring.types import EventPayload

from ..config import SystemConfig, TaskConfig
if TYPE_CHECKING:
    from ..config import JsonTaskSpec
from ..core.llm_client import LLMClient
from ..core.retry_policy import RetryPolicy
from ..core.errors import ParsingError, SchemaValidationError

try:
    import jsonschema  # type: ignore
except Exception as e:  # pragma: no cover
    jsonschema = None  # type: ignore


class JsonSanitizer:
    CODE_BLOCK_PATTERN = re.compile(r"```[a-zA-Z0-9]*\n(.*?)```", re.DOTALL)

    @staticmethod
    def extract(raw_text: str) -> Tuple[Optional[EventPayload], Optional[str]]:
        """
        尝试从文本中提取 JSON：
        - 优先提取代码块中的内容
        - 否则从全文中定位首个 {...} 或 [...] 片段
        返回 (data, error_msg)
        """
        text = raw_text.strip()
        # 1) 代码块中查找
        m = JsonSanitizer.CODE_BLOCK_PATTERN.search(text)
        candidates = []
        if m:
            candidates.append(m.group(1).strip())
        candidates.append(text)

        for cand in candidates:
            data, err = JsonSanitizer._parse_first_json(cand)
            if data is not None:
                return data, None
        return None, err or "未找到可解析的 JSON 片段"

    @staticmethod
    def _parse_first_json(text: str) -> Tuple[Optional[EventPayload], Optional[str]]:
        # 寻找首个大括号或中括号起止位置，做一次保守切片
        start = min([i for i in [text.find("{"), text.find("[")] if i != -1] or [len(text)])
        end = max(text.rfind("}"), text.rfind("]"))
        if start == len(text) or end <= start:
            return None, "未检测到 JSON 边界"
        snippet = text[start : end + 1]
        try:
            obj = json.loads(snippet)
            if isinstance(obj, dict):
                return obj, None
            if isinstance(obj, list):
                return {"_root": obj}, None  # 以 _root 包裹数组，便于统一 schema
            return None, "JSON 顶层不是对象或数组"
        except Exception as e:
            return None, f"JSON 解析失败: {e}"


class JsonValidator:
    def __init__(self, schema: EventPayload):
        """
        初始化 JSON 校验器

        Args:
            schema: JSON Schema 定义
        """
        self.schema = schema

    @staticmethod
    @lru_cache(maxsize=128)
    def _compiled(schema_json: str):
        if jsonschema is None:
            raise RuntimeError("请安装依赖 jsonschema：pip install jsonschema")
        schema = json.loads(schema_json)
        return jsonschema.Draft202012Validator(schema)  # type: ignore

    @staticmethod
    def validate_with_schema(data: EventPayload, schema: EventPayload) -> Tuple[bool, Optional[str]]:
        """
        静态方法：验证数据是否符合 schema

        Args:
            data: 要验证的数据
            schema: JSON Schema 定义

        Returns:
            (是否有效, 错误信息)
        """
        return JsonValidator._validate_data(data, schema)

    def validate(self, data: EventPayload) -> Tuple[bool, Optional[str]]:
        """
        实例方法：验证数据是否符合 schema

        Args:
            data: 要验证的数据

        Returns:
            (是否有效, 错误信息)
        """
        return JsonValidator._validate_data(data, self.schema)

    @staticmethod
    def _validate_data(data: EventPayload, schema: EventPayload) -> Tuple[bool, Optional[str]]:
        """
        内部方法：验证数据是否符合 schema

        Args:
            data: 要验证的数据
            schema: JSON Schema 定义

        Returns:
            (是否有效, 错误信息)
        """
        try:
            validator = JsonValidator._compiled(json.dumps(schema, sort_keys=True))
            errors = sorted(validator.iter_errors(data), key=lambda e: e.path)
            if errors:
                msgs = [f"{'/'.join(map(str, e.path)) or '<root>'}: {e.message}" for e in errors]
                return False, "; ".join(msgs)
            return True, None
        except Exception as e:
            return False, f"Schema 校验异常: {e}"


@dataclass
class JsonTaskResult:
    success: bool
    data: Optional[EventPayload]
    raw_text: str
    errors: List[str]
    attempts: int
    duration_ms: int


class JsonTaskEngine:
    def __init__(
        self,
        client: LLMClient,
        config: SystemConfig,
        logger,
        event_bus: Optional[object] = None,
        metrics_sink: Optional[object] = None,
        failure_store: Optional[object] = None,
    ) -> None:
        self.client = client
        self.config = config
        self.logger = logger
        self.event_bus = event_bus
        self.metrics = metrics_sink
        self.failure_store = failure_store

    async def run(self, messages: List[Dict[str, str]], task_type: str) -> JsonTaskResult:
        spec: Optional[JsonTaskSpec] = TaskConfig.get_json_spec(task_type)
        if not spec:
            raise ValueError(f"任务 {task_type} 未注册 JSON 规格")
        if not self.config.json_enable:
            raise ValueError("系统未开启 JSON 任务能力（json_enable=False）")

        retry: RetryPolicy = spec.retry_policy or self.config.default_retry_policy
        attempts = 0
        errors: List[str] = []
        t0 = time.time()
        last_raw = ""
        parsed: Optional[EventPayload] = None

        base_messages = list(messages)

        while attempts < max(1, retry.max_attempts):
            attempts += 1
            # 强制要求 JSON 输出
            response, need_retry = await self.client.call_with_retry(base_messages, {"type": "json_object"})
            if need_retry:
                # 由上层速率限制联动处理；此处简单记录
                errors.append("rate_limited_or_transient")
                backoff_ms = self._compute_backoff_ms(retry, attempts)
                self._emit_event("json_retry", {"task_type": task_type, "reason": "rate_limited_or_transient", "attempt": attempts, "next_backoff_ms": backoff_ms})
                await asyncio.sleep(backoff_ms / 1000.0)
                continue

            content = self.client.extract_content(response) if response is not None else ""
            last_raw = content or ""
            data, parse_err = JsonSanitizer.extract(last_raw)
            if data is None:
                msg = f"parse_error: {parse_err}"
                errors.append(msg)
                self._emit_event("json_invalid", {"task_type": task_type, "reason": msg, "attempt": attempts})
                self._metrics_fail(task_type, attempts, msg)
                if retry.escalate_prompt:
                    base_messages = self._escalate_messages(messages, msg)
                backoff_ms = self._compute_backoff_ms(retry, attempts)
                self._emit_event("json_retry", {"task_type": task_type, "reason": msg, "attempt": attempts, "next_backoff_ms": backoff_ms})
                await asyncio.sleep(backoff_ms / 1000.0)
                continue

            # 通过后处理
            if spec.postprocess:
                try:
                    data = spec.postprocess(data)
                except Exception as e:
                    errors.append(f"postprocess_error: {e}")

            ok, val_err = JsonValidator.validate_with_schema(data, spec.schema)
            if ok:
                dt = int((time.time() - t0) * 1000)
                self._emit_event("json_valid", {"task_type": task_type, "attempt": attempts})
                self._metrics_success(task_type, attempts, dt)
                # 指标：成功计时与尝试数（如有 tokens 可在此扩展）
                return JsonTaskResult(True, data, last_raw, errors, attempts, dt)

            # 校验失败 -> 重试
            msg = f"schema_invalid: {val_err}"
            errors.append(msg)
            self._emit_event("json_invalid", {"task_type": task_type, "reason": msg, "attempt": attempts})
            self._metrics_fail(task_type, attempts, msg)
            if retry.escalate_prompt:
                base_messages = self._escalate_messages(messages, msg)
            backoff_ms = self._compute_backoff_ms(retry, attempts)
            self._emit_event("json_retry", {"task_type": task_type, "reason": msg, "attempt": attempts, "next_backoff_ms": backoff_ms})
            await asyncio.sleep(backoff_ms / 1000.0)

        # 放弃
        dt = int((time.time() - t0) * 1000)
        self._emit_event("json_giveup", {"task_type": task_type, "reasons": errors, "attempts": attempts})
        if self.failure_store is not None:
            try:
                item_id = "unknown"
                self.failure_store.save_json_failure(item_id=item_id, task_type=task_type, raw_text=last_raw, reason="; ".join(errors), parsed_json=parsed, attempts=attempts)
            except Exception as e:
                self.logger.warning(f"保存失败样本异常: {e}")
        return JsonTaskResult(False, None, last_raw, errors, attempts, dt)

    def _compute_backoff_ms(self, retry: RetryPolicy, attempt: int) -> int:
        base = retry.backoff_base_ms * (2 ** max(0, attempt - 1))
        jitter = random.randint(0, max(0, retry.backoff_jitter_ms))
        return max(0, base + jitter)

    def _escalate_messages(self, original: List[Dict[str, str]], last_err: str) -> List[Dict[str, str]]:
        # 在 system 中增加更严格要求
        new_msgs = []
        injected = False
        for m in original:
            if m.get("role") == "system" and not injected:
                text = (m.get("content") or "").strip()
                text += "\n\n请仅输出严格的 JSON。不要包含解释或多余文本。错误提示: " + last_err
                new_msgs.append({"role": "system", "content": text})
                injected = True
            else:
                new_msgs.append(m)
        if not injected:
            new_msgs.insert(0, {"role": "system", "content": "请仅输出严格的 JSON。不要包含解释或多余文本。"})
        return new_msgs

    def _emit_event(self, event_type: str, payload: EventPayload) -> None:
        if self.event_bus:
            try:
                self.event_bus.publish(event_type, payload)
            except Exception:
                pass

    def _metrics_fail(self, task_type: str, attempt: int, reason: str) -> None:
        if self.metrics and hasattr(self.metrics, "on_json_validation_fail"):
            try:
                self.metrics.on_json_validation_fail({"task_type": task_type, "attempt": attempt, "reason": reason})
            except Exception:
                pass

    def _metrics_success(self, task_type: str, attempt: int, duration_ms: int) -> None:
        if self.metrics and hasattr(self.metrics, "on_json_validation_success"):
            try:
                self.metrics.on_json_validation_success({"task_type": task_type, "attempt": attempt, "latency_ms": duration_ms})
            except Exception:
                pass
