#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LLM 客户端协议：统一处理器依赖的接口，便于多提供方/多 SDK 适配
"""

from typing import Any, Dict, Optional, Tuple, Protocol

class LLMClient(Protocol):
    async def call_with_retry(
        self, messages: list[Dict[str, str]], response_format: Optional[Dict] = None
    ) -> Tuple[Optional[Dict[str, Any]], bool]:
        """调用模型并带重试；返回 (响应, 是否需要重试)"""
        ...

    def extract_content(self, response: Dict[str, Any]) -> str:
        """从响应中抽取文本内容"""
        ...

    async def close(self) -> None:
        """关闭连接"""
        ...
