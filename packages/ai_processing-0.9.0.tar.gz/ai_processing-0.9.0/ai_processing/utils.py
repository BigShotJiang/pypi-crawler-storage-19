#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: ai_processing_framework
file: utils.py
author: 子不语
description: 通用工具函数
--------------------------------------------
"""

import json
import os
from typing import Any, Dict, List
from filelock import FileLock, Timeout
import logging

logger = logging.getLogger(__name__)

def write_jsonl(
    filename: str,
    data: List[Dict[str, Any]],
    mode: str = "a",
    lock_timeout: int = 5,
) -> bool:
    """
    将数据以 JSONL 格式追加写入文件，使用文件锁保证并发安全。
    """
    if not data:
        return True

    lock_path = f"{filename}.lock"
    lock = FileLock(lock_path, timeout=lock_timeout)

    try:
        with lock:
            with open(filename, mode, encoding="utf-8") as f:
                for item in data:
                    f.write(json.dumps(item, ensure_ascii=False) + "\n")
        return True
    except Timeout:
        logger.error(
            f"获取文件锁 {lock_path} 超时（{lock_timeout}s），JSONL 写入操作失败。"
        )
        return False
    except Exception as e:
        logger.error(f"写入 JSONL 文件 {filename} 失败: {e}", exc_info=True)
        return False

def format_time(seconds: float) -> str:
    """格式化时间为易读字符串"""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        return f"{seconds/60:.1f}m"
    else:
        return f"{seconds/3600:.1f}h"

import datetime

def get_logger(
    name: str, 
    level: int = logging.INFO,
    fmt: str = None, 
    if_console: bool = True, 
    base_path: str = None
) -> logging.Logger:
    """
    获取日志记录对象
    :param name: 日志记录对象名称
    :param level: 日志级别
    :param fmt: 日志格式
    :param if_console: 是否输出到终端
    :param base_path: 日志文件存放目录
    :return: 日志记录对象
    """
    today = datetime.date.today()
    formatted_date = today.strftime("%Y%m%d")

    if not fmt:
        fmt = f"%(asctime)s.%(msecs)04d | %(levelname)8s | %(name)s | %(filename)s:%(lineno)d | %(message)s"

    # 创建一个Logger
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # 如果已经有handler，说明已经配置过，直接返回避免重复添加
    if logger.handlers:
        return logger

    # 创建formatter
    formatter = logging.Formatter(
        fmt=fmt,
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # 创建终端输出handler
    if if_console:
        try:
            # 使用coloredlogs打印更好看的日志
            import coloredlogs

            # 自定义日志的级别颜色
            level_color_mapping = {
                "DEBUG": {"color": "blue"},
                "INFO": {"color": "green"},
                "WARNING": {"color": "yellow", "bold": True},
                "ERROR": {"color": "red"},
                "CRITICAL": {"color": "red", "bold": True},
            }

            # 自定义日志的字段颜色
            field_color_mapping = dict(
                asctime=dict(color="green"),
                hostname=dict(color="magenta"),
                levelname=dict(color="white", bold=True),
                name=dict(color="blue"),
                programname=dict(color="cyan"),
                username=dict(color="yellow"),
            )

            coloredlogs.install(
                level=level,
                logger=logger,
                milliseconds=True,
                datefmt="%X",
                fmt=fmt,
                level_styles=level_color_mapping,
                field_styles=field_color_mapping,
            )
        except ImportError:
            # 降级方案：普通控制台输出
            console_handler = logging.StreamHandler()
            console_handler.setLevel(level)
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)

    # 若传入base_path，则创建文件输出handler
    if base_path:
        if not os.path.exists(base_path):
            # 尝试创建 base_path
            try:
                os.makedirs(base_path, exist_ok=True)
            except Exception:
                pass

        # 拼接路径
        log_dir = os.path.join(base_path, "log") if os.path.isdir(base_path) else os.path.join(os.path.dirname(base_path), "log")
        
        # 如果 base_path 本身就是目录
        if os.path.exists(base_path) and os.path.isdir(base_path):
             log_dir = os.path.join(base_path, "log")
        
        # 判断路径是否存在，不存在则创建
        if not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)

        file_path = os.path.join(log_dir, f"{formatted_date}.log")

        file_handler = logging.FileHandler(
            filename=file_path, mode="a", encoding="utf8", delay=False
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger


# === 环境变量加载工具 ===

def load_single_env_file(file_name: str, env_dir_path: str = None) -> None:
    """按文件名加载 .env 目录中的单个配置文件。
    若传入不以 .env 开头的名称，则自动规范为 .env.<name>。
    """
    if not file_name:
        print("错误：请提供有效的 .env 文件名。")
        return
    normalized_name = file_name if file_name.startswith('.env') else f'.env.{file_name}'
    load_env_directory(env_dir_path=env_dir_path, only_files=[normalized_name])


def _parse_env_file(file_path: str) -> None:
    """解析单个 env 配置文件，将 KEY=VALUE 注入环境变量（不覆盖已有）。"""
    try:
        print(f"正在加载配置文件：【{file_path}】")
        with open(file_path, "r", encoding="utf-8") as f:
            for raw_line in f:
                line = raw_line.strip()
                if not line or line.startswith("#") or line.startswith("//"):
                    continue
                if "=" in line:
                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip().strip('"').strip("'")
                    if key and (key not in os.environ or os.environ.get(key) in (None, "")):
                        os.environ[key] = value
    except Exception:
        # 某个文件解析失败，不影响整体流程
        pass


def load_env_directory(env_dir_path: str = None, only_files: List[str] = None) -> None:
    """
    从项目的 .env 目录批量加载环境变量配置。
    - 支持多文件：逐个解析目录中的所有文本文件，按 KEY=VALUE 形式注入到 os.environ。
    - 已存在的环境变量不被覆盖（保守策略）。
    - 支持传入 only_files 指定只加载某几个文件名（不区分扩展名）。

    Args:
        env_dir_path: .env 目录的绝对路径；若为空，则按当前文件位置推断项目根目录并拼接 .env。
        only_files: 仅加载的文件名列表（如 ["dev", "prod.env"]）。
    """
    if env_dir_path is None:
        # 尝试推断项目根目录 (假设 utils.py 在 ai_processing/ai_processing/utils.py)
        # 向上 3 级: ai_processing/ai_processing/utils.py -> ai_processing/ai_processing -> ai_processing -> project_root
        # 但这取决于安装方式。更稳妥的是让调用者传入，或者尝试查找 .env 目录
        current_dir = os.path.dirname(os.path.abspath(__file__))
        # 简单策略：向上查找直到找到 .env 目录，或者到达根目录
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir))) # 假设在 site-packages 或源码目录
        
        # 如果是源码安装 d:\zibuyu_code\zibuyu_library\ai_processing\ai_processing\utils.py
        # -> d:\zibuyu_code\zibuyu_library\ai_processing\ai_processing
        # -> d:\zibuyu_code\zibuyu_library\ai_processing
        # -> d:\zibuyu_code\zibuyu_library
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
        env_dir_path = os.path.join(project_root, ".env")
        
        # 如果找不到，尝试当前工作目录
        if not os.path.isdir(env_dir_path):
             env_dir_path = os.path.join(os.getcwd(), ".env")

    if not os.path.isdir(env_dir_path):
        # 降级：如果 .env 目录不存在，尝试在当前目录查找 .env 文件
        if only_files:
             for name in only_files:
                 if os.path.isfile(name):
                     _parse_env_file(name)
        return

    # 标准化 only_files 名称（不含扩展名时也能匹配）
    normalized = set()
    if only_files:
        for name in only_files:
            if name.startswith('.env'):
                normalized.add(name.lower())
            else:
                base = os.path.splitext(name)[0]
                normalized.add(f'.env.{base}'.lower())

    for name in os.listdir(env_dir_path):
        file_path = os.path.join(env_dir_path, name)
        if not os.path.isfile(file_path):
            continue

        base, ext = os.path.splitext(name)

        # 优先支持以 .env 开头的文件名；其次支持常见扩展名或无扩展名文件
        should_parse = name.startswith('.env') or ext.lower() in (".env", ".txt", ".cfg", "")
        if not should_parse:
            # print(f"忽略文件：【{file_path}】")
            continue

        # 如果指定了仅加载文件名，则要求完整文件名匹配（忽略大小写）
        if normalized and name.lower() not in normalized:
            # print(f"忽略文件：【{file_path}】")
            continue

        _parse_env_file(file_path)
