"""
--------------------------------------------
project: ai_processing_framework
file: types.py
author: 子不语
date: 2025/11/2
--------------------------------------------
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Union, Literal, TypedDict

ProcessItem = Union[Dict[str, Any], object]


# === API 消息类型定义 ===

class Message(TypedDict):
    """
    API 消息类型
    
    用于构建发送给 LLM API 的消息列表
    """
    role: Literal["system", "user", "assistant"]
    content: str


Messages = List[Message]
"""消息列表类型"""

@dataclass
class Task:
    """
    任务定义
    
    ⚠️ DEPRECATED: 此类型仅供遗留代码使用（已删除的 TaskOrchestrator）。
    
    推荐使用方式:
    - 直接使用 AsyncExecutor.execute_task(task_type, limit) 
    - 无需定义 Task 对象
    """
    task_name: str
    task_num: int = -1  # -1 表示无限循环


@dataclass
class TaskContext:
    """
    任务执行上下文：跟踪运行态、支持限流与重试/排除队列
    """
    # 统计
    total_token: int = 0
    success_count: int = 0
    failed_count: int = 0
    total_count: int = 0

    # 限流与并发自适应
    rate_limited: bool = False
    concurrent_cumulative_quantity: int = 1  # 并发累计量（全成功时尝试提升批量）

    # 重试与排除
    exclude_data: Dict[int, int] = field(default_factory=dict)  # id -> 失败次数
    process_data: List["ProcessItem"] = field(default_factory=list)  # 待重试队列
    max_process_queue_size: int = 1000

    def add_exclude(self, item_id: int) -> None:
        count = self.exclude_data.get(item_id, 0)
        self.exclude_data[item_id] = count + 1

    def should_exclude(self, item_id: int, threshold: int) -> bool:
        return self.exclude_data.get(item_id, 0) >= threshold

    def add_to_process(self, item: "ProcessItem") -> None:
        # 去重（按 id）
        item_id = item.get("id")
        if item_id is not None:
            for x in self.process_data:
                if x.get("id") == item_id:
                    return
        # 容量限制
        if len(self.process_data) >= self.max_process_queue_size:
            self.process_data = self.process_data[1:]
        self.process_data.append(item)

    def increment_success(self) -> None:
        self.success_count += 1

    def add_tokens(self, tokens: int) -> None:
        self.total_token += tokens

    def increase_concurrency(self) -> None:
        self.concurrent_cumulative_quantity = max(1, self.concurrent_cumulative_quantity * 2)

    def reset_concurrency(self) -> None:
        self.concurrent_cumulative_quantity = 1

    def mark_rate_limited(self) -> None:
        self.rate_limited = True

    def clear_rate_limit_flag(self) -> None:
        self.rate_limited = False

@dataclass
class BatchContext:
    """批次上下文"""
    batch_id: str
    size: int
