#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import asyncio
import time
from typing import Optional, Callable, Dict, Any
from ..monitoring.types import EventPayload

from .queue import Broker


class Worker:
    def __init__(
        self,
        broker: Broker,
        task_type: str,
        handler: Callable[[EventPayload], asyncio.Future | Any],
        logger,
        event_bus: Optional[object] = None,
        metrics_sink: Optional[object] = None,
        poll_seconds: float = 0.2,
    ) -> None:
        self.broker = broker
        self.task_type = task_type
        self.handler = handler
        self.logger = logger
        self.event_bus = event_bus
        self.metrics = metrics_sink
        self.poll = max(0.05, float(poll_seconds))
        self._stop = False

    async def start(self) -> None:
        from ai_processing.monitoring.metrics_prom import record_worker_event, observe_task_duration  # 轻量可选导入
        self._emit("worker_start", {"task_type": self.task_type})
        record_worker_event("worker_start")
        self._stop = False
        try:
            while not self._stop:
                self.broker.heartbeat()
                item = self.broker.dequeue(self.task_type, timeout_seconds=self.poll)
                if item is None:
                    await asyncio.sleep(self.poll)
                    continue
                self._emit("task_claim", {"task_type": self.task_type})
                record_worker_event("task_claim")
                t0 = time.time()
                try:
                    res = self.handler(item)
                    if asyncio.iscoroutine(res):
                        await res  # type: ignore
                    self.broker.ack(self.task_type, item)
                    dt = time.time() - t0
                    self._emit("task_done", {"task_type": self.task_type, "duration": dt})
                    observe_task_duration(dt)
                    record_worker_event("task_done")
                except Exception as e:
                    self._emit("task_error", {"task_type": self.task_type, "error": str(e)})
                    record_worker_event("task_error")
        finally:
            self._emit("worker_stop", {"task_type": self.task_type})
            record_worker_event("worker_stop")

    def stop(self) -> None:
        self._stop = True

    def _emit(self, event_type: str, payload: EventPayload) -> None:
        if self.event_bus:
            try:
                self.event_bus.publish(event_type, payload)
            except Exception:
                pass
        # 可在此桥接 metrics
