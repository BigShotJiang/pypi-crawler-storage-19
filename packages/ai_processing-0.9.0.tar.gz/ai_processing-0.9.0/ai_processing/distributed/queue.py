#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

from typing import Protocol, Optional, Dict, Any
from ..monitoring.types import EventPayload


class Broker(Protocol):
    def enqueue(self, task_type: str, payload: EventPayload) -> None:
        ...

    def dequeue(self, task_type: str, timeout_seconds: float = 1.0) -> Optional[EventPayload]:
        ...

    def ack(self, task_type: str, payload: EventPayload) -> None:
        ...

    def heartbeat(self) -> None:
        ...
