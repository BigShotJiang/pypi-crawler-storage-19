#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import queue
from typing import Dict, Any, Optional
from ..monitoring.types import EventPayload

from .queue import Broker


class InMemoryBroker(Broker):
    def __init__(self, capacity_per_type: int = 10000) -> None:
        self._qs: Dict[str, queue.Queue] = {}
        self._cap = max(1, capacity_per_type)

    def _get(self, task_type: str) -> queue.Queue:
        if task_type not in self._qs:
            self._qs[task_type] = queue.Queue(maxsize=self._cap)
        return self._qs[task_type]

    def enqueue(self, task_type: str, payload: EventPayload) -> None:
        q = self._get(task_type)
        try:
            q.put_nowait(payload)
        except queue.Full:
            # 丢弃最新
            pass

    def dequeue(self, task_type: str, timeout_seconds: float = 1.0) -> Optional[EventPayload]:
        q = self._get(task_type)
        try:
            item = q.get(timeout=max(0.0, timeout_seconds))
            return item
        except queue.Empty:
            return None

    def ack(self, task_type: str, payload: EventPayload) -> None:
        # in-memory 无需显式 ack；这里占位
        try:
            self._get(task_type).task_done()
        except Exception:
            pass

    def heartbeat(self) -> None:
        # no-op
        return
