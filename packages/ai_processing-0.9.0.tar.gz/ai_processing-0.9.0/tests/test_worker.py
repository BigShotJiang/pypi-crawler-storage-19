#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio

from ai_processing.distributed.inmemory_broker import InMemoryBroker
from ai_processing.distributed.worker import Worker


async def _run_worker_once():
    b = InMemoryBroker()
    b.enqueue("t", {"x": 1})
    processed = {"n": 0}

    async def handle(payload):
        processed["n"] += 1

    w = Worker(broker=b, task_type="t", handler=handle, logger=type("L", (), {"info": print, "error": print}))
    task = asyncio.create_task(w.start())
    await asyncio.sleep(0.2)
    w.stop()
    await task
    return processed["n"]


def test_worker_basic_event_loop():
    n = asyncio.run(_run_worker_once())
    assert n >= 1
