#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from ai_processing.core.json_response import JsonValidator


def test_json_validator_success():
    schema = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["label", "score"],
        "properties": {
            "label": {"type": "string"},
            "score": {"type": "number"},
        },
        "additionalProperties": False,
    }
    validator = JsonValidator(schema)
    ok, err = validator.validate({"label": "POS", "score": 0.9})
    assert ok and err is None


def test_json_validator_fail():
    schema = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "required": ["label"],
        "properties": {"label": {"type": "string"}},
        "additionalProperties": False,
    }
    validator = JsonValidator(schema)
    ok, err = validator.validate({"label": 123, "x": 1})
    assert not ok and isinstance(err, str)
