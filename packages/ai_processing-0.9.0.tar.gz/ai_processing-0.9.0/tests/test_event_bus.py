#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
from ai_processing.monitoring import InMemoryEventBus


def test_event_bus_basic_delivery():
    bus = InMemoryEventBus(capacity=100)
    received = {"count": 0}

    def handler(payload):
        received["count"] += 1

    bus.subscribe("ping", handler)
    bus.start()
    try:
        for _ in range(5):
            bus.publish("ping", {"hello": "world"})
        time.sleep(0.2)
    finally:
        bus.stop(drain=True)
    assert received["count"] >= 5


def test_event_bus_drop_on_full():
    # capacity=1，快速填满以触发丢弃路径
    bus = InMemoryEventBus(capacity=1)
    delivered = {"count": 0}

    def slow_handler(payload):
        time.sleep(0.05)
        delivered["count"] += 1

    bus.subscribe("x", slow_handler)
    bus.start()
    try:
        for _ in range(50):
            bus.publish("x", {"i": _})
        time.sleep(0.5)
    finally:
        bus.stop(drain=False)
    assert delivered["count"] >= 1
