"""
--------------------------------------------
project: ai_processing_framework
file: test_accumulated_context.py
author: 子不语
date: 2025/11/21
description: 累积上下文功能的单元测试
--------------------------------------------
"""
import pytest
import json
import tempfile
import os
from dataclasses import dataclass, field, asdict
from typing import Dict, Any

from ai_processing.core.accumulated_context import AccumulatedContext
from ai_processing.core.context_persister import FilePersister


# 测试用的具体上下文类
@dataclass
class TestContext(AccumulatedContext):
    """测试用的累积上下文"""
    counter: int = 0
    items: list = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def update(self, task_result: Dict[str, Any], task_id: Any) -> None:
        """更新上下文"""
        self.counter += 1
        self.items.append(task_id)
        self.metadata['last_task_id'] = task_id
    
    def to_dict(self) -> Dict[str, Any]:
        """序列化"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TestContext':
        """反序列化,处理字段缺失"""
        return cls(
            counter=data.get('counter', 0),
            items=data.get('items', []),
            metadata=data.get('metadata', {})
        )


class TestAccumulatedContext:
    """测试 AccumulatedContext 基类功能"""
    
    def test_context_creation(self):
        """测试上下文创建"""
        context = TestContext()
        assert context.counter == 0
        assert context.items == []
        assert context.metadata == {}
    
    def test_context_update(self):
        """测试上下文更新"""
        context = TestContext()
        context.update({"value": 1}, task_id=1)
        
        assert context.counter == 1
        assert context.items == [1]
        assert context.metadata['last_task_id'] == 1
    
    def test_context_to_dict(self):
        """测试序列化为字典"""
        context = TestContext(counter=5, items=[1, 2, 3])
        data = context.to_dict()
        
        assert data['counter'] == 5
        assert data['items'] == [1, 2, 3]
        assert isinstance(data, dict)
    
    def test_context_from_dict(self):
        """测试从字典反序列化"""
        data = {'counter': 10, 'items': [1, 2, 3, 4], 'metadata': {'key': 'value'}}
        context = TestContext.from_dict(data)
        
        assert context.counter == 10
        assert context.items == [1, 2, 3, 4]
        assert context.metadata == {'key': 'value'}
    
    def test_context_from_dict_missing_fields(self):
        """测试从不完整的字典反序列化(向后兼容)"""
        incomplete_data = {'counter': 7}  # 缺少 items 和 metadata
        context = TestContext.from_dict(incomplete_data)
        
        # 应该使用默认值
        assert context.counter == 7
        assert context.items == []
        assert context.metadata == {}
    
    def test_context_to_json(self):
        """测试序列化为 JSON"""
        context = TestContext(counter=3, items=[1, 2])
        json_str = context.to_json()
        
        # 验证是有效的 JSON
        data = json.loads(json_str)
        assert data['counter'] == 3
        assert data['items'] == [1, 2]
    
    def test_context_from_json(self):
        """测试从 JSON 反序列化"""
        json_str = '{"counter": 8, "items": [5, 6, 7], "metadata": {}}'
        context = TestContext.from_json(json_str)
        
        assert context.counter == 8
        assert context.items == [5, 6, 7]
    
    def test_context_roundtrip(self):
        """测试序列化往返"""
        original = TestContext(counter=15, items=[1, 2, 3])
        original.metadata['test_key'] = 'test_value'
        
        # 序列化
        json_str = original.to_json()
        
        # 反序列化
        restored = TestContext.from_json(json_str)
        
        # 验证数据一致
        assert restored.counter == original.counter
        assert restored.items == original.items
        assert restored.metadata == original.metadata
    
    def test_get_metadata(self):
        """测试获取元数据"""
        context = TestContext()
        context.metadata['key1'] = 'value1'
        
        assert context.get_metadata('key1') == 'value1'
        assert context.get_metadata('nonexistent', 'default') == 'default'
    
    def test_set_metadata(self):
        """测试设置元数据"""
        context = TestContext()
        context.set_metadata('new_key', 'new_value')
        
        assert context.metadata['new_key'] == 'new_value'
    
    def test_get_stats(self):
        """测试获取统计信息"""
        context = TestContext(counter=5)
        context.set_metadata('total_chapters_processed', 10)
        context.set_metadata('last_updated', '2025-11-21')
        
        stats = context.get_stats()
        
        assert stats['class'] == 'TestContext'
        assert stats['total_processed'] == 10
        assert stats['last_updated'] == '2025-11-21'


class TestFilePersister:
    """测试文件持久化器"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir
    
    @pytest.mark.asyncio
    async def test_save_and_load(self, temp_dir):
        """测试保存和加载"""
        persister = FilePersister(temp_dir)
        
        # 创建上下文
        context = TestContext(counter=5, items=[1, 2, 3])
        context.metadata['key'] = 'value'
        
        # 保存
        await persister.save(context, key='test_key')
        
        # 加载
        loaded = await persister.load('test_key', TestContext)
        
        # 验证
        assert loaded is not None
        assert loaded.counter == 5
        assert loaded.items == [1, 2, 3]
        assert loaded.metadata['key'] == 'value'
    
    @pytest.mark.asyncio
    async def test_load_nonexistent(self, temp_dir):
        """测试加载不存在的上下文"""
        persister = FilePersister(temp_dir)
        
        loaded = await persister.load('nonexistent_key', TestContext)
        
        assert loaded is None
    
    @pytest.mark.asyncio
    async def test_exists(self, temp_dir):
        """测试检查上下文是否存在"""
        persister = FilePersister(temp_dir)
        
        # 初始不存在
        assert not await persister.exists('test_key')
        
        # 保存后存在
        context = TestContext(counter=1)
        await persister.save(context, key='test_key')
        assert await persister.exists('test_key')
    
    @pytest.mark.asyncio
    async def test_delete(self, temp_dir):
        """测试删除上下文"""
        persister = FilePersister(temp_dir)
        
        # 保存
        context = TestContext(counter=1)
        await persister.save(context, key='test_key')
        assert await persister.exists('test_key')
        
        # 删除
        await persister.delete('test_key')
        assert not await persister.exists('test_key')
    
    @pytest.mark.asyncio
    async def test_safe_key_handling(self, temp_dir):
        """测试键名清理(处理非法字符)"""
        persister = FilePersister(temp_dir)
        
        # 使用包含非法字符的键
        unsafe_key = 'test/key:with\\illegal*chars'
        context = TestContext(counter=99)
        
        # 应该能够保存和加载
        await persister.save(context, key=unsafe_key)
        loaded = await persister.load(unsafe_key, TestContext)
        
        assert loaded is not None
        assert loaded.counter == 99
    
    @pytest.mark.asyncio
    async def test_corrupted_file(self, temp_dir):
        """测试加载损坏的文件"""
        persister = FilePersister(temp_dir)
        
        # 手动创建损坏的 JSON 文件
        file_path = os.path.join(temp_dir, 'corrupted_key.json')
        with open(file_path, 'w') as f:
            f.write('{ invalid json }')
        
        # 加载应该返回 None(不抛出异常)
        loaded = await persister.load('corrupted_key', TestContext)
        assert loaded is None


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
