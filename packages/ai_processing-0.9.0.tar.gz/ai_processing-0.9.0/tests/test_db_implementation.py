#!/usr/bin/env python3
"""快速测试多数据库实现"""

import asyncio
import sys
import os

# 将项目根目录添加到 Python 路径
sys.path.insert(0, os.path.dirname(__file__))

from ai_processing.config.database_config import DatabaseConfig
from ai_processing.infrastructure.db_backends import (
    create_backend,
    SQLiteBackend,
    PostgreSQLBackend,
    MySQLBackend
)

async def test_config():
    """测试配置系统"""
    print("=" * 60)
    print("测试数据库配置系统")
    print("=" * 60)

    # 测试 SQLite 配置
    config_sqlite = DatabaseConfig(
        db_type="sqlite",
        database_path="test.db"
    )
    assert config_sqlite.validate() == True
    print("✓ SQLite 配置验证通过")

    # 测试 PostgreSQL 配置
    config_pg = DatabaseConfig(
        db_type="postgresql",
        host="localhost",
        port=5432,
        database="test",
        user="postgres",
        password="secret"
    )
    assert config_pg.validate() == True
    print("✓ PostgreSQL 配置验证通过")

    # 测试 MySQL 配置
    config_mysql = DatabaseConfig(
        db_type="mysql",
        host="localhost",
        port=3306,
        database="test",
        user="root",
        password="secret"
    )
    assert config_mysql.validate() == True
    print("✓ MySQL 配置验证通过")

    # 测试 to_dict
    config_dict = config_sqlite.to_dict()
    assert "db_type" in config_dict
    print("✓ to_dict() 方法正常")

    print("\n✅ 数据库配置系统测试全部通过！\n")

async def test_backend_creation():
    """测试后端创建"""
    print("=" * 60)
    print("测试数据库后端创建")
    print("=" * 60)

    # 测试 SQLite 后端
    config_sqlite = DatabaseConfig(db_type="sqlite", database_path="test.db")
    backend_sqlite = create_backend(config_sqlite.db_type, config_sqlite.to_dict())
    assert isinstance(backend_sqlite, SQLiteBackend)
    print("✓ SQLite 后端创建成功")

    # 测试 PostgreSQL 后端
    config_pg = DatabaseConfig(
        db_type="postgresql",
        host="localhost", database="test", user="postgres", password=""
    )
    backend_pg = create_backend(config_pg.db_type, config_pg.to_dict())
    assert isinstance(backend_pg, PostgreSQLBackend)
    print("✓ PostgreSQL 后端创建成功")

    # 测试 MySQL 后端
    config_mysql = DatabaseConfig(
        db_type="mysql",
        host="localhost", database="test", user="root", password=""
    )
    backend_mysql = create_backend(config_mysql.db_type, config_mysql.to_dict())
    assert isinstance(backend_mysql, MySQLBackend)
    print("✓ MySQL 后端创建成功")

    # 测试工厂函数别名
    backend_pg_alias = create_backend("postgres", config_pg.to_dict())
    assert isinstance(backend_pg_alias, PostgreSQLBackend)
    print("✓ PostgreSQL 别名 (postgres) 工作正常")

    backend_mysql_alias = create_backend("mariadb", config_mysql.to_dict())
    assert isinstance(backend_mysql_alias, MySQLBackend)
    print("✓ MySQL 别名 (mariadb) 工作正常")

    print("\n✅ 后端创建测试全部通过！\n")

async def test_backend_api():
    """测试后端API方法"""
    print("=" * 60)
    print("测试数据库后端API")
    print("=" * 60)

    # 测试 SQLite
    config_sqlite = DatabaseConfig(db_type="sqlite", database_path="test.db")
    backend = create_backend(config_sqlite.db_type, config_sqlite.to_dict())

    # 测试 get_engine_url
    url = backend.get_engine_url()
    assert "sqlite+aiosqlite://" in url
    print(f"✓ SQLite URL: {url}")

    # 测试 get_current_timestamp_expr
    from sqlalchemy import text
    ts_expr = backend.get_current_timestamp_expr()
    assert isinstance(ts_expr, text)
    print(f"✓ SQLite 时间戳表达式: {ts_expr.text}")

    # 测试 parse_lock_timestamp
    ts = backend.parse_lock_timestamp("2025-11-20 10:30:00")
    assert ts > 0
    print(f"✓ SQLite 时间戳解析: {ts}")

    # 测试 get_timeout_condition
    condition = backend.get_timeout_condition(3600)
    assert isinstance(condition, text)
    print(f"✓ SQLite 超时条件正确")

    # 测试 get_safe_connection_string (脱敏)
    safe_url = backend.get_safe_connection_string()
    assert "****" not in safe_url  # SQLite没有密码
    print(f"✓ SQLite 脱敏字符串: {safe_url}")

    print("\n✅ 后端API测试全部通过！\n")

async def test_postgresql_password_encoding():
    """测试PostgreSQL密码编码"""
    print("=" * 60)
    print("测试 PostgreSQL 密码编码")
    print("=" * 60)

    config = DatabaseConfig(
        db_type="postgresql",
        host="localhost",
        database="test",
        user="postgres",
        password="p@ss!word#123"
    )
    backend = create_backend(config.db_type, config.to_dict())

    url = backend.get_engine_url()
    # 密码应该被URL编码
    assert "p%40ss%21word%23123" in url
    print(f"✓ 密码特殊字符被正确编码")

    safe_url = backend.get_safe_connection_string()
    assert "postgres:****@" in safe_url
    print(f"✓ 脱敏连接字符串正确: {safe_url}")

    print("\n✅ 密码编码测试通过！\n")

async def test_mysql_password_encoding():
    """测试MySQL密码编码"""
    print("=" * 60)
    print("测试 MySQL 密码编码")
    print("=" * 60)

    config = DatabaseConfig(
        db_type="mysql",
        host="localhost",
        database="test",
        user="root",
        password="p@ss!word#123"
    )
    backend = create_backend(config.db_type, config.to_dict())

    url = backend.get_engine_url()
    # 密码应该被URL编码
    assert "p%40ss%21word%23123" in url
    print(f"✓ 密码特殊字符被正确编码")

    safe_url = backend.get_safe_connection_string()
    assert "root:****@" in safe_url
    print(f"✓ 脱敏连接字符串正确: {safe_url}")

    print("\n✅ 密码编码测试通过！\n")

async def test_error_handling():
    """测试错误处理"""
    print("=" * 60)
    print("测试错误处理")
    print("=" * 60)

    try:
        # 测试不支持的数据库类型
        create_backend("oracle", {})
        assert False, "应该抛出 ValueError"
    except ValueError as e:
        assert "Unsupported database type" in str(e)
        print("✓ 不支持的数据库类型抛出正确错误")

    # 测试无效配置
    config = DatabaseConfig(db_type="postgresql", host=None, database=None, user=None)
    try:
        config.validate()
        assert False, "应该抛出 ValueError"
    except ValueError as e:
        assert "requires host, database, and user" in str(e)
        print("✓ 无效配置验证抛出正确错误")

    print("\n✅ 错误处理测试通过！\n")

async def main():
    """运行所有测试"""
    try:
        await test_config()
        await test_backend_creation()
        await test_backend_api()
        await test_postgresql_password_encoding()
        await test_mysql_password_encoding()
        await test_error_handling()

        print("=" * 60)
        print("🎉 所有测试通过！多数据库实现完整且功能完备。")
        print("=" * 60)
        return 0
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
