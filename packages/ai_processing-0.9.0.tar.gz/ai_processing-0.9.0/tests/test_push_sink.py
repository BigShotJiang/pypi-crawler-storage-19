#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import logging
from ai_processing.monitoring import HTTPPushSink


class DummyMetrics:
    def __init__(self):
        self.failures = 0
        self.drops = 0

    def on_event_delivery_failure(self, info):
        self.failures += int(info.get("count", 1))

    def on_event_dropped(self, info):
        self.drops += 1


def build_logger():
    logger = logging.getLogger("aip.test")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        logger.addHandler(logging.StreamHandler())
    logger.propagate = False
    return logger


def test_http_push_sink_degrades_without_requests():
    # 在未安装 requests 时，HTTPPushSink 会走降级路径并记录失败
    metrics = DummyMetrics()
    sink = HTTPPushSink(endpoint="http://localhost:9999/invalid", logger=build_logger(), metrics_sink=metrics, max_retries=1, backoff_base_ms=1, backoff_jitter_ms=1)
    sink.start()
    try:
        sink.push({"k": "v"})
        time.sleep(0.2)
    finally:
        sink.stop(drain=True)
    assert metrics.failures >= 0  # 不抛异常即可
