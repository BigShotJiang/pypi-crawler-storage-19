#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# 目的：确保示例处理器可被导入（结构正确），不运行实际数据库逻辑

def test_can_import_examples():
    import importlib

    for mod in [
        "ai_processing.examples.classification_processor",
        "ai_processing.examples.review_processor",
        "ai_processing.examples.summarization_processor",
        "ai_processing.examples.qa_processor",
    ]:
        m = importlib.import_module(mod)
        assert m is not None
