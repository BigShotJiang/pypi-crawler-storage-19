import asyncio
import os
import pytest
import logging
from sqlalchemy import Column, Integer, String, Text, text
from sqlalchemy.orm import DeclarativeBase
from ai_processing.infrastructure.database_adapter import DatabaseAdapter
from ai_processing.config.database_config import DatabaseConfig

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_db")

class Base(DeclarativeBase):
    pass

class TaskModel(Base):
    __tablename__ = "test_tasks"
    id = Column(Integer, primary_key=True)
    content = Column(Text)
    processing = Column(Integer, nullable=True)
    done = Column(Integer, nullable=True)
    lock_owner = Column(String, nullable=True)
    lock_at = Column(String, nullable=True)

@pytest.mark.asyncio
async def test_database_adapter_flow():
    db_path = "test_async.db"
    if os.path.exists(db_path):
        os.remove(db_path)
    
    db_config = DatabaseConfig(db_type="sqlite", database_path=db_path)
    adapter = DatabaseAdapter(database_config=db_config, logger=logger)
    
    try:
        # 1. Create table
        await adapter.execute(
            """
            CREATE TABLE test_tasks (
                id INTEGER PRIMARY KEY,
                content TEXT,
                processing INTEGER,
                done INTEGER,
                lock_owner TEXT,
                lock_at TEXT
            )
            """
        )
        
        # 2. Insert data
        await adapter.execute("INSERT INTO test_tasks (content) VALUES ('task1')")
        await adapter.execute("INSERT INTO test_tasks (content) VALUES ('task2')")
        
        count = await adapter.count(TaskModel, None)
        assert count == 2
        
        # 3. Claim batch
        items = await adapter.claim_and_fetch_batch(
            model_class=TaskModel,
            filter_condition=None,
            order_by=TaskModel.id,
            worker_id="worker1",
            limit=1
        )
        assert len(items) == 1
        assert items[0].content == 'task1'
        assert items[0].processing == 1
        assert items[0].lock_owner == "worker1"
        
        # 4. Mark done
        await adapter.mark_batch_done(TaskModel, [items[0].id])
        
        # Verify done
        async with adapter.handler.session as session:
            result = await session.execute(text("SELECT done FROM test_tasks WHERE id = 1"))
            done_val = result.scalar()
            assert done_val == 1
            
        # 5. Revert stale locks (simulate)
        # Lock task2
        await adapter.execute(
            "UPDATE test_tasks SET processing=1, lock_owner='worker2', lock_at='2000-01-01 00:00:00' WHERE id=2"
        )
        
        reverted = await adapter.revert_stale_locks(TaskModel, timeout_seconds=3600)
        assert reverted == 1
        
        # Verify reverted
        async with adapter.handler.session as session:
            result = await session.execute(text("SELECT processing FROM test_tasks WHERE id = 2"))
            proc_val = result.scalar()
            assert proc_val is None

    finally:
        await adapter.close()
        if os.path.exists(db_path):
            os.remove(db_path)

if __name__ == "__main__":
    asyncio.run(test_database_adapter_flow())
