"""
--------------------------------------------
project: ai_processing_framework
file: test_serial_execution.py
author: 子不语
date: 2025/11/20
description: 串行任务执行逻辑测试脚本
    验证基于 previous_task_id 的任务依赖机制:
    1. 当前置任务未完成时,后续任务应被过滤条件阻塞
    2. 当前置任务完成后,后续任务应解除阻塞
--------------------------------------------
"""

import asyncio
import logging
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import declarative_base
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy import select, update

# 导入被测试的组件
from ai_processing.core.base_task_processor import BaseTaskProcessor
from ai_processing.types import ProcessItem

# 定义测试用的 ORM 模型
Base = declarative_base()

class TestTask(Base):
    """测试用任务表模型"""
    __tablename__ = 'test_tasks'
    id = Column(Integer, primary_key=True)
    content = Column(String)
    previous_task_id = Column(Integer, nullable=True)  # 依赖的前置任务 ID
    done = Column(Integer, default=0)           # 0: 未完成, 1: 已完成
    processing = Column(Integer, nullable=True) # 处理状态标记
    lock_owner = Column(String, nullable=True)  # 锁持有者
    lock_at = Column(String, nullable=True)     # 锁时间

class MockProcessor(BaseTaskProcessor):
    """模拟处理器,用于暴露 get_dependency_filter 方法"""
    def __init__(self):
        # 初始化 logger
        self.logger = logging.getLogger("MockProcessor")
        # 模拟 task_config,提供 model_class
        self.task_config = type("Config", (), {"model_class": TestTask})()

    async def process_item(self, item: ProcessItem, task_type: str = "") -> bool:
        return True

async def test_serial_execution():
    """
    测试串行执行逻辑的主函数
    """
    # 1. 初始化内存数据库
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async_session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    # 2. 插入测试数据
    async with async_session() as session:
        # 任务 1: 独立任务
        task1 = TestTask(id=1, content="Task 1", done=0)
        # 任务 2: 依赖任务 1 (previous_task_id=1)
        task2 = TestTask(id=2, content="Task 2 (depends on 1)", previous_task_id=1, done=0)
        # 任务 3: 独立任务
        task3 = TestTask(id=3, content="Task 3 (independent)", done=0)
        
        session.add_all([task1, task2, task3])
        await session.commit()

    # 3. 获取依赖过滤条件
    processor = MockProcessor()
    filter_condition = processor.get_dependency_filter()
    
    print(f"生成的过滤条件 SQL 片段: {filter_condition}")

    # 4. 测试场景一:前置任务未完成
    async with async_session() as session:
        # 使用过滤条件查询任务
        stmt = select(TestTask).where(filter_condition).order_by(TestTask.id)
        result = await session.execute(stmt)
        tasks = result.scalars().all()
        ids = [t.id for t in tasks]
        print(f"场景一 [前置任务未完成] 可获取的任务 ID: {ids}")
        
        # 验证预期:
        # 任务 1 (无前置任务) -> 可见
        # 任务 3 (无前置任务) -> 可见
        # 任务 2 (前置任务 id=1 未完成) -> 不可见 (被阻塞)
        assert 1 in ids, "Task 1 应该可见"
        assert 3 in ids, "Task 3 应该可见"
        assert 2 not in ids, "Task 2 应该被阻塞"
        print("PASS: 任务 2 成功被阻塞。")

        # 5. 修改状态:将任务 1 标记为完成
        await session.execute(
            update(TestTask).where(TestTask.id == 1).values(done=1)
        )
        await session.commit()

    # 6. 测试场景二:前置任务已完成
    async with async_session() as session:
        stmt = select(TestTask).where(filter_condition).order_by(TestTask.id)
        result = await session.execute(stmt)
        tasks = result.scalars().all()
        ids = [t.id for t in tasks]
        print(f"场景二 [前置任务已完成] 可获取的任务 ID: {ids}")
        
        # 验证预期:
        # 任务 2 (前置任务 id=1 已完成) -> 可见 (解除阻塞)
        # 注意: BaseTaskProcessor 的 get_dependency_filter 只负责依赖关系,
        # 任务是否已完成 (done=1) 的过滤通常由 AsyncExecutor 的 claim 逻辑处理,
        # 这里我们只验证依赖逻辑是否放行。
        
        assert 2 in ids, "Task 2 应该解除阻塞"
        print("PASS: 任务 2 成功解除阻塞。")

    print("\n所有测试用例通过!")

if __name__ == "__main__":
    asyncio.run(test_serial_execution())
