#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: ai_processing_framework
file: test_retry_logic.py
author: 子不语
date: 2025/11/21
description: 重试逻辑单元测试
--------------------------------------------
"""

import os
import pytest
import logging
from sqlalchemy import Column, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase
from ai_processing.infrastructure.database_adapter import DatabaseAdapter
from ai_processing.config.database_config import DatabaseConfig

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_retry")


class Base(DeclarativeBase):
    pass


class RetryTaskModel(Base):
    """测试用任务模型"""
    __tablename__ = "retry_tasks"
    id = Column(Integer, primary_key=True)
    content = Column(Text)
    status = Column(String, default="pending")
    attempts = Column(Integer, default=0)
    processing = Column(Integer, nullable=True)
    done = Column(Integer, nullable=True)
    lock_owner = Column(String, nullable=True)
    lock_at = Column(String, nullable=True)
    blocked_reason = Column(String, nullable=True)


@pytest.mark.asyncio
async def test_mark_batch_retry():
    """测试标记任务为重试状态"""
    db_path = "test_retry.db"
    if os.path.exists(db_path):
        os.remove(db_path)
    
    db_config = DatabaseConfig(db_type="sqlite", database_path=db_path)
    adapter = DatabaseAdapter(database_config=db_config, logger=logger)
    
    try:
        # 1. 创建表
        await adapter.execute(
            """
            CREATE TABLE retry_tasks (
                id INTEGER PRIMARY KEY,
                content TEXT,
                status TEXT DEFAULT 'pending',
                attempts INTEGER DEFAULT 0,
                processing INTEGER,
                done INTEGER,
                lock_owner TEXT,
                lock_at TEXT,
                blocked_reason TEXT
            )
            """
        )
        
        # 2. 插入测试数据
        await adapter.execute(
            "INSERT INTO retry_tasks (content, processing, lock_owner, attempts) VALUES ('task1', 1, 'worker1', 0)"
        )
        
        # 3. 标记为重试
        await adapter.mark_batch_retry([1], RetryTaskModel)
        
        # 4. 验证
        async with adapter.handler.session as session:
            from sqlalchemy import select
            stmt = select(RetryTaskModel).where(RetryTaskModel.id == 1)
            result = await session.execute(stmt)
            task = result.scalar_one()
            
            assert task.processing is None, "processing 应该被清除"
            assert task.lock_owner is None, "lock_owner 应该被清除"
            assert task.attempts == 1, "attempts 应该增加到 1"
            
    finally:
        await adapter.close()
        if os.path.exists(db_path):
            os.remove(db_path)


@pytest.mark.asyncio
async def test_mark_batch_failed():
    """测试标记任务为失败状态"""
    db_path = "test_failed.db"
    if os.path.exists(db_path):
        os.remove(db_path)
    
    db_config = DatabaseConfig(db_type="sqlite", database_path=db_path)
    adapter = DatabaseAdapter(database_config=db_config, logger=logger)
    
    try:
        # 1. 创建表
        await adapter.execute(
            """
            CREATE TABLE retry_tasks (
                id INTEGER PRIMARY KEY,
                content TEXT,
                status TEXT DEFAULT 'pending',
                attempts INTEGER DEFAULT 0,
                processing INTEGER,
                done INTEGER,
                lock_owner TEXT,
                lock_at TEXT,
                blocked_reason TEXT
            )
            """
        )
        
        # 2. 插入测试数据
        await adapter.execute(
            "INSERT INTO retry_tasks (content, processing, lock_owner, attempts) VALUES ('task1', 1, 'worker1', 3)"
        )
        
        # 3. 标记为失败
        await adapter.mark_batch_failed([1], RetryTaskModel, reason="max_retries_exceeded")
        
        # 4. 验证
        async with adapter.handler.session as session:
            from sqlalchemy import select
            stmt = select(RetryTaskModel).where(RetryTaskModel.id == 1)
            result = await session.execute(stmt)
            task = result.scalar_one()
            
            assert task.processing is None, "processing 应该被清除"
            assert task.lock_owner is None, "lock_owner 应该被清除"
            assert task.status == "failed", "status 应该是 failed"
            assert task.blocked_reason == "max_retries_exceeded", "应该记录失败原因"
            
    finally:
        await adapter.close()
        if os.path.exists(db_path):
            os.remove(db_path)


@pytest.mark.asyncio
async def test_claim_excludes_failed_tasks():
    """测试 claim_and_fetch_batch 排除失败任务"""
    db_path = "test_claim.db"
    if os.path.exists(db_path):
        os.remove(db_path)
    
    db_config = DatabaseConfig(db_type="sqlite", database_path=db_path)
    adapter = DatabaseAdapter(database_config=db_config, logger=logger)
    
    try:
        # 1. 创建表
        await adapter.execute(
            """
            CREATE TABLE retry_tasks (
                id INTEGER PRIMARY KEY,
                content TEXT,
                status TEXT DEFAULT 'pending',
                attempts INTEGER DEFAULT 0,
                processing INTEGER,
                done INTEGER,
                lock_owner TEXT,
                lock_at TEXT,
                blocked_reason TEXT
            )
            """
        )
        
        # 2. 插入测试数据
        await adapter.execute("INSERT INTO retry_tasks (content, status) VALUES ('task1', 'pending')")
        await adapter.execute("INSERT INTO retry_tasks (content, status) VALUES ('task2', 'failed')")
        await adapter.execute("INSERT INTO retry_tasks (content, status) VALUES ('task3', 'pending')")
        
        # 3. 抢占任务
        tasks = await adapter.claim_and_fetch_batch(
            model_class=RetryTaskModel,
            filter_condition=None,
            order_by=RetryTaskModel.id,
            worker_id="worker1",
            limit=10
        )
        
        # 4. 验证 - 应该只获取到 task1 和 task3
        assert len(tasks) == 2, "应该只获取到 2 个任务 (排除失败的)"
        assert tasks[0].content == "task1"
        assert tasks[1].content == "task3"
        
    finally:
        await adapter.close()
        if os.path.exists(db_path):
            os.remove(db_path)


@pytest.mark.asyncio
async def test_retry_flow():
    """测试完整的重试流程"""
    db_path = "test_retry_flow.db"
    if os.path.exists(db_path):
        os.remove(db_path)
    
    db_config = DatabaseConfig(db_type="sqlite", database_path=db_path)
    adapter = DatabaseAdapter(database_config=db_config, logger=logger)
    
    try:
        # 1. 创建表
        await adapter.execute(
            """
            CREATE TABLE retry_tasks (
                id INTEGER PRIMARY KEY,
                content TEXT,
                status TEXT DEFAULT 'pending',
                attempts INTEGER DEFAULT 0,
                processing INTEGER,
                done INTEGER,
                lock_owner TEXT,
                lock_at TEXT,
                blocked_reason TEXT
            )
            """
        )
        
        # 2. 插入测试任务
        await adapter.execute("INSERT INTO retry_tasks (content) VALUES ('retry_task')")
        
        max_retries = 3
        
        # 3. 模拟重试流程
        for attempt in range(max_retries):
            # 抢占任务
            tasks = await adapter.claim_and_fetch_batch(
                model_class=RetryTaskModel,
                filter_condition=None,
                order_by=RetryTaskModel.id,
                worker_id=f"worker{attempt}",
                limit=1
            )
            
            assert len(tasks) == 1, f"第 {attempt + 1} 次应该能抢到任务"
            task = tasks[0]
            assert task.attempts == attempt, f"attempts 应该是 {attempt}"
            
            # 模拟任务失败
            if attempt < max_retries - 1:
                # 还未达到最大重试次数,标记为重试
                await adapter.mark_batch_retry([task.id], RetryTaskModel)
            else:
                # 达到最大重试次数,标记为失败
                await adapter.mark_batch_failed([task.id], RetryTaskModel, reason="max_retries_exceeded")
        
        # 4. 验证最终状态
        async with adapter.handler.session as session:
            from sqlalchemy import select
            stmt = select(RetryTaskModel).where(RetryTaskModel.id == 1)
            result = await session.execute(stmt)
            task = result.scalar_one()
            
            assert task.status == "failed", "最终状态应该是 failed"
            assert task.attempts == max_retries, f"attempts 应该是 {max_retries}"
            assert task.blocked_reason == "max_retries_exceeded"
        
        # 5. 再次尝试抢占 - 应该抢不到 (因为已经是 failed 状态)
        tasks = await adapter.claim_and_fetch_batch(
            model_class=RetryTaskModel,
            filter_condition=None,
            order_by=RetryTaskModel.id,
            worker_id="worker_final",
            limit=1
        )
        assert len(tasks) == 0, "失败的任务不应该被再次抢占"
        
    finally:
        await adapter.close()
        if os.path.exists(db_path):
            os.remove(db_path)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
