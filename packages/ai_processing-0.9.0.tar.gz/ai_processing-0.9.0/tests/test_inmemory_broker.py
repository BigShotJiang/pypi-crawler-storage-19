#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from ai_processing.distributed.inmemory_broker import InMemoryBroker


def test_inmemory_broker_enqueue_dequeue_ack():
    b = InMemoryBroker(capacity_per_type=2)
    b.enqueue("t", {"x": 1})
    b.enqueue("t", {"x": 2})
    item1 = b.dequeue("t", timeout_seconds=0.01)
    item2 = b.dequeue("t", timeout_seconds=0.01)
    assert item1 is not None and item2 is not None
    b.ack("t", item1)
    b.ack("t", item2)
