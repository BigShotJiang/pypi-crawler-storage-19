#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from ai_processing.core import ControlAPI


class _DummyBus:
    def __init__(self):
        self.events = []
    def publish(self, et, payload):
        self.events.append((et, payload))


class _DummyLogger:
    def warning(self, *args, **kwargs):
        pass


def test_control_api_cancel_sets_flag_and_emits():
    from ai_processing.core.task_context import TaskContext
    ctx = TaskContext()
    bus = _DummyBus()
    api = ControlAPI(ctx, _DummyLogger(), bus, metrics_sink=None)
    api.cancel("reason-x")
    assert getattr(ctx, "cancel_requested", False) is True
    assert tuple(e[0] for e in bus.events).count("task_cancel_requested") >= 1
