#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import time

from ai_processing.scheduling.scheduler import MinimalScheduler
from ai_processing.monitoring import build_json_logger, InMemoryEventBus


async def _run_sched():
    logger = build_json_logger("aip.test.scheduler")
    bus = InMemoryEventBus(); bus.start()
    count = {"interval": 0, "once": 0}

    async def interval_job():
        count["interval"] += 1

    async def once_job():
        count["once"] += 1

    sched = MinimalScheduler(logger=logger, event_bus=bus, poll_interval=0.05)
    sched.add_interval_job("i", seconds=0.1, coro_factory=interval_job)
    sched.add_once_job("o", run_after_seconds=0.05, coro_factory=once_job)

    await sched.start()
    try:
        await asyncio.sleep(0.35)
    finally:
        await sched.stop()
        bus.stop()
    return count


def test_scheduler_runs_jobs():
    count = asyncio.run(_run_sched())
    assert count["once"] >= 1
    assert count["interval"] >= 2
