#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
--------------------------------------------
project: ai_processing_framework
file: test_key_manager.py
author: 子不语
date: 2025/11/21
description: KeyManager 单元测试
--------------------------------------------
"""

import os
import pytest
from ai_processing.security.key_manager import KeyManager


class TestKeyManager:
    """KeyManager 加解密功能测试"""
    
    def test_encrypt_decrypt(self):
        """测试加密和解密功能"""
        raw_key = "sk-1234567890abcdef"
        
        # 加密
        encrypted = KeyManager.encrypt(raw_key)
        assert encrypted.startswith("enc:")
        assert encrypted != raw_key
        
        # 解密
        km = KeyManager()
        decrypted = km._decrypt_if_needed(encrypted)
        assert decrypted == raw_key
    
    def test_plaintext_compatibility(self):
        """测试明文密钥兼容性"""
        plaintext_key = "sk-plaintext-key"
        
        km = KeyManager()
        result = km._decrypt_if_needed(plaintext_key)
        
        # 明文密钥应该原样返回
        assert result == plaintext_key
    
    def test_empty_key(self):
        """测试空密钥"""
        km = KeyManager()
        
        # 空字符串
        assert km._decrypt_if_needed("") == ""
        
        # None
        assert km._decrypt_if_needed(None) == None
    
    def test_get_key_from_env(self, monkeypatch):
        """测试从环境变量获取密钥"""
        # 设置环境变量
        test_key = "sk-test-key-from-env"
        encrypted_key = KeyManager.encrypt(test_key)
        monkeypatch.setenv("TEST_API_KEY", encrypted_key)
        
        # 创建新的 KeyManager 实例 (会重新加载环境变量)
        km = KeyManager()
        
        # 获取密钥
        result = km.get_key("TEST_API_KEY")
        assert result == test_key
    
    def test_get_key_default(self):
        """测试获取不存在的密钥时返回默认值"""
        km = KeyManager()
        
        # 不存在的密钥
        result = km.get_key("NON_EXISTENT_KEY", default="default_value")
        assert result == "default_value"
    
    def test_encrypt_special_characters(self):
        """测试包含特殊字符的密钥"""
        special_key = "sk-!@#$%^&*()_+-=[]{}|;':\",./<>?"
        
        encrypted = KeyManager.encrypt(special_key)
        km = KeyManager()
        decrypted = km._decrypt_if_needed(encrypted)
        
        assert decrypted == special_key
    
    def test_encrypt_unicode(self):
        """测试包含 Unicode 字符的密钥"""
        unicode_key = "sk-密钥-🔑-key"
        
        encrypted = KeyManager.encrypt(unicode_key)
        km = KeyManager()
        decrypted = km._decrypt_if_needed(encrypted)
        
        assert decrypted == unicode_key


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
