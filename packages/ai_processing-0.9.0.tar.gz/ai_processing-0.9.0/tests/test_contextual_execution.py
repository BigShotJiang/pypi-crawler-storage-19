"""
--------------------------------------------
project: ai_processing_framework
file: test_contextual_execution.py
author: 子不语
date: 2025/11/20
description: 上下文串行执行测试脚本
    验证后续任务能够正确读取前置任务的 processed_content
--------------------------------------------
"""

import asyncio
import logging
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import declarative_base
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

# 导入被测试的组件
from ai_processing.examples.contextual_processor import ContextualExampleProcessor
from ai_processing.infrastructure.database_adapter import DatabaseAdapter
from ai_processing.config.database_config import DatabaseConfig

# 定义测试用的 ORM 模型
Base = declarative_base()

class ContextTask(Base):
    """测试用任务表模型"""
    __tablename__ = 'context_tasks'
    id = Column(Integer, primary_key=True)
    content = Column(String)
    previous_task_id = Column(Integer, nullable=True)
    processed_content = Column(String, nullable=True)
    done = Column(Integer, default=0)
    processing = Column(Integer, nullable=True)
    lock_owner = Column(String, nullable=True)
    lock_at = Column(String, nullable=True)

async def test_contextual_execution():
    # 1. 初始化环境
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("TestContextual")
    
    # 使用文件数据库以便 DatabaseAdapter 能够正确连接(内存数据库在不同连接间不共享)
    # 或者使用 shared cache: sqlite+aiosqlite:///file:memdb1?mode=memory&cache=shared
    # 为了简单起见,这里使用本地文件 db
    db_path = "test_contextual.db"
    db_config = DatabaseConfig(db_type="sqlite", database_path=db_path)
    
    # 清理旧文件
    import os
    if os.path.exists(db_path):
        os.remove(db_path)

    # 初始化 Adapter
    adapter = DatabaseAdapter(db_config, logger)
    
    # 创建表
    async with adapter.handler.engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # 2. 插入数据
    async with adapter.handler.session as session:
        # 任务 1: 根任务
        task1 = ContextTask(id=1, content="Start", done=1, processed_content="[Result of Task 1]")
        # 任务 2: 依赖任务 1
        task2 = ContextTask(id=2, content="Step 2", previous_task_id=1, done=0)
        
        session.add_all([task1, task2])
        await session.commit()

    # 3. 初始化 Processor
    processor = ContextualExampleProcessor(
        task_config=type("Config", (), {"model_class": ContextTask})(),
        api_client=None, # Mocked
        db_adapter=adapter,
        context=None, # Mocked
        logger=logger
    )

    # 4. 执行任务 2
    item = {"id": 2, "content": "Step 2", "previous_task_id": 1}
    logger.info("开始处理任务 2...")
    await processor.process_item(item)
    
    # 5. 验证结果
    async with adapter.handler.session as session:
        from sqlalchemy import select
        stmt = select(ContextTask).where(ContextTask.id == 2)
        result = await session.execute(stmt)
        task2_updated = result.scalar()
        
        logger.info(f"任务 2 处理结果: {task2_updated.processed_content}")
        
        expected_context = "[Result of Task 1]"
        assert expected_context in task2_updated.processed_content
        assert "Step 2" in task2_updated.processed_content
        print("PASS: 任务 2 成功获取了任务 1 的上下文并生成了结果")

    # 清理
    await adapter.close()
    if os.path.exists(db_path):
        os.remove(db_path)

if __name__ == "__main__":
    asyncio.run(test_contextual_execution())
