#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ai-processing",
    version="0.9.0",
    author="子不语",
    author_email="zibuyu2015831@qq.com",
    description="AI并发处理框架(可嵌入、可扩展)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.10",
    install_requires=[
        "aiohttp>=3.9.0",
        "aiosqlite>=0.19.0",
        "sqlalchemy>=2.0.0",
        "tenacity>=8.2.0",
        "pydantic>=2.0.0",
        "python-dotenv>=1.0.0",
        "filelock>=3.12.0",
        "openai>=1.0.0",
    ],
    extras_require={
        "postgresql": ["asyncpg>=0.29.0"],
        "mysql": ["aiomysql>=0.2.0"],
        "anthropic": ["anthropic>=0.7.0"],
        "prometheus": ["prometheus-client>=0.16.0"],
        "http": ["requests>=2.28.0"],
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "mypy>=1.0.0",
            "ruff>=0.1.0",
            "types-requests>=2.28.0",
        ],
        "all": [
            "asyncpg>=0.29.0",
            "aiomysql>=0.2.0",
            "anthropic>=0.7.0",
            "prometheus-client>=0.16.0",
            "requests>=2.28.0",
        ],
    },
)