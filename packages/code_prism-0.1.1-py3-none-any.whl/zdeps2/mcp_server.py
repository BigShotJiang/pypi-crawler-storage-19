#!/usr/bin/env python3
"""
ZDeps MCP Server - Codebase Snapshot & Query Tool for AI Agents

This MCP server wraps SnapshotManager to provide AI agents with:
1. Instant dependency snapshots (no AI inference needed)
2. Parallel question answering (ask 10 questions at once)
3. Structured dependency maps alongside code
4. Cached AI analysis for fast exploration

The snapshot is a "magnifying glass" - load a controlled subset of code
with full dependency info, query it multiple times, then dispose/regenerate.
"""

import os
import sys
import uuid
from pathlib import Path
from typing import Any, Sequence, Dict

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp.server import Server
from mcp.types import Tool, TextContent
import mcp.server.stdio

from zdeps2.core.snapshot_manager import SnapshotManager


# Initialize MCP server
server = Server("prism")

# Global snapshot manager instance
manager: SnapshotManager = None

# Global snapshot cache - stores snapshots by ID
snapshot_cache: Dict[str, Dict[str, Any]] = {}


def get_manager() -> SnapshotManager:
    """Get or create snapshot manager instance."""
    global manager
    if manager is None:
        api_key = os.getenv("ANTHROPIC_API_KEY")
        # Use ZDEPS_PROJECT_ROOT env var if set, otherwise use current working directory
        project_root_str = os.getenv("ZDEPS_PROJECT_ROOT")
        project_root = Path(project_root_str) if project_root_str else Path.cwd()
        manager = SnapshotManager(project_root=project_root, api_key=api_key)
    return manager


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools for AI agents."""
    return [
        Tool(
            name="list_entry_points",
            description="""List all configured entry points (main files where execution begins: API routes, CLI commands, etc.).

**When to use:**
- At the start of codebase exploration to understand main entry points
- Before creating snapshots to choose which entry point to explore
- To understand the high-level architecture

**Fast & free:** No computation needed, just returns configured entry points.""",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="preview_snapshot",
            description="""DRY RUN - Preview snapshot size before generating. FAST & FREE (no file reading or AI calls).

**When to use:** ALWAYS run this before create_snapshot to see size.

**Best practice:** Start with defaults (depth=999 for full tree), only reduce depth if preview shows >100k tokens.

**Returns:** File list, estimated tokens, cost estimate, and recommendations.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Target file path",
                    },
                    "parent_depth": {
                        "type": "integer",
                        "description": "How many levels up to traverse (who imports this). Default: 999 (all parents). Only reduce if preview shows >100k tokens.",
                        "default": 999,
                    },
                    "child_depth": {
                        "type": "integer",
                        "description": "How many levels down to traverse (what this imports). Default: 999 (all children). Only reduce if preview shows >100k tokens.",
                        "default": 999,
                    },
                    "include_chain": {
                        "type": "boolean",
                        "description": "Include chain to entry points. Default: false",
                        "default": False,
                    },
                    "include_frontend": {
                        "type": "boolean",
                        "description": "Include frontend (default: false)",
                        "default": False,
                    },
                },
                "required": ["file_path"],
            },
        ),
        Tool(
            name="query_codebase",
            description="""**THE MAIN TOOL** - Understand any part of the codebase in ONE call. This is your primary way to explore code.

**What it does:**
1. Creates dependency snapshot (full source code + dependency map)
2. Auto-generates AI overview (file structure, architecture, patterns)
3. Answers questions with configurable detail level
4. **SUGGESTS** which files to read fully - YOU decide via read_files parameter

**Detail Levels (detail_level parameter):**
- `"concise"`: 1-2 sentence answers, minimal snippets - FAST
- `"normal"`: Balanced 2-4 sentence answers with examples (default)
- `"verbose"`: Comprehensive explanations with architecture details

**File Reading (read_files parameter):**
- Prism SUGGESTS files via `primary_files` in response
- YOU CONTROL what to read by passing `read_files=["file1.py", "file2.py"]`
- Read files get included as COMPLETE SOURCE (all imports, setup, full context)
- All in ONE call - no extra tool uses needed

**Example - Concise exploration:**
```python
query_codebase(
  file_path="api/routes.py",
  questions=["What routes exist?", "How is auth handled?"],
  detail_level="concise"  # Fast, brief answers
)
# Returns: Brief answers + file suggestions (no full source)
```

**Example - Deep dive with full source:**
```python
query_codebase(
  file_path="api/routes.py",
  questions=["How does authentication work?", "What's the middleware pipeline?"],
  detail_level="verbose",  # Comprehensive answers
  read_files=["api/routes.py", "middleware/auth.py"]  # Get these in full
)
# Returns: Detailed answers + COMPLETE source of routes.py and auth.py
```

**Typical workflow:**
1. Start with `detail_level="concise"` to explore (no read_files)
2. See suggested files in response
3. Make another call with `read_files=[...]` to get full source

**Returns:** Overview + answers + file suggestions + optional complete source

**Power:** Full dependency tree by default (depth=999). Parallel question processing.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Target file path (relative to project root)",
                    },
                    "questions": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional: List of questions to ask (5-10 recommended). Leave empty for just overview.",
                        "default": [],
                    },
                    "parent_depth": {
                        "type": "integer",
                        "description": "How many levels up to traverse (who imports this). Default: 999 (all parents). Only reduce if preview shows >100k tokens.",
                        "default": 999,
                    },
                    "child_depth": {
                        "type": "integer",
                        "description": "How many levels down to traverse (what this imports). Default: 999 (all children). Only reduce if preview shows >100k tokens.",
                        "default": 999,
                    },
                    "include_chain": {
                        "type": "boolean",
                        "description": "Include chain to entry points. Default: false",
                        "default": False,
                    },
                    "include_frontend": {
                        "type": "boolean",
                        "description": "Include frontend files (templates, JS, CSS). Default: false",
                        "default": False,
                    },
                    "detail_level": {
                        "type": "string",
                        "enum": ["concise", "normal", "verbose"],
                        "description": "Answer detail level: 'concise' (1-2 sentences), 'normal' (balanced), 'verbose' (comprehensive). Default: normal",
                        "default": "normal",
                    },
                    "read_files": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional: List of specific files to read in full (e.g., ['api/routes.py', 'core/auth.py']). Prism will suggest files via primary_files, but YOU decide what to read.",
                        "default": [],
                    },
                },
                "required": ["file_path"],
            },
        ),
        Tool(
            name="query_snapshot_batch",
            description="""Ask MULTIPLE questions about an EXISTING snapshot IN PARALLEL.

**When to use:** For follow-up questions after query_codebase. Reuses existing snapshot for efficiency.

**What it does:**
1. Answers 5-10 questions in parallel with full snapshot context
2. Configurable detail level per batch (concise/normal/verbose)
3. **SUGGESTS** files to read - YOU control via read_files parameter
4. Deduplicates file suggestions across all questions

**Detail Levels (detail_level parameter):**
- `"concise"`: 1-2 sentence answers, minimal snippets - FAST
- `"normal"`: Balanced answers with examples (default)
- `"verbose"`: Comprehensive explanations with architecture context

**File Reading (read_files parameter):**
- Prism SUGGESTS files via `primary_files` across ALL questions
- Suggestions are automatically deduplicated
- YOU decide what to read via `read_files=["file1.py"]`
- All in ONE call

**Example - Quick answers only:**
```python
query_snapshot_batch(
  snapshot_id="abc123",
  questions=["What's the auth flow?", "Where is caching?", "How are errors handled?"],
  detail_level="concise"  # Fast exploration
)
# Returns: Brief answers + deduplicated file suggestions
```

**Example - Deep dive with source:**
```python
query_snapshot_batch(
  snapshot_id="abc123",
  questions=["How does the auth middleware work?", "What's the session management?"],
  detail_level="verbose",
  read_files=["middleware/auth.py", "core/session.py"]
)
# Returns: Comprehensive answers + COMPLETE source of auth.py and session.py
```

**Smart deduplication:**
- If Q1, Q2, Q3 all suggest `auth.py`, it appears ONCE in suggestions
- You can read all suggested files in next call, or pick specific ones

**Recommended:** Ask 5-10 questions covering different aspects

**Efficiency:** All questions processed in parallel. Much faster than sequential.

**Requires:** snapshot_id from query_codebase.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "snapshot_id": {
                        "type": "string",
                        "description": "Snapshot ID from query_codebase",
                    },
                    "questions": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of questions to ask (up to 10 recommended)",
                    },
                    "detail_level": {
                        "type": "string",
                        "enum": ["concise", "normal", "verbose"],
                        "description": "Answer detail level: 'concise' (1-2 sentences), 'normal' (balanced), 'verbose' (comprehensive). Default: normal",
                        "default": "normal",
                    },
                    "read_files": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional: List of specific files to read in full. Prism suggests files via primary_files, YOU decide what to actually read.",
                        "default": [],
                    },
                },
                "required": ["snapshot_id", "questions"],
            },
        ),
        Tool(
            name="analyze_snapshot",
            description="""Generate AI summaries for all files in a snapshot (Tier 1: one sentence, Tier 2: detailed paragraph).

**When to use:** When snapshot doesn't have cached AI analysis yet. Creates a semantic layer for faster querying.

**Note:** Most snapshots already have cached analysis. Try query_snapshot_batch first - if results are poor, then run analyze_snapshot to generate fresh analysis.

**Cost:** Uses AI inference (unlike create_snapshot which is free). Results are cached for future use.

**Requires:** snapshot_id from create_snapshot.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "snapshot_id": {
                        "type": "string",
                        "description": "Snapshot ID from create_snapshot",
                    },
                },
                "required": ["snapshot_id"],
            },
        ),
        Tool(
            name="get_dependency_info",
            description="""Quick dependency lookup for a single file (no snapshot needed).

**When to use:** For rapid exploration when you just need to see:
- What this file imports (children)
- Who imports this file (parents)
- Chain to entry points

**Limitation:** Only shows dependency structure, not actual code. For deeper understanding, use create_snapshot + query_snapshot_batch.

**Fast & free:** No snapshot generation or AI calls needed.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "File path to inspect",
                    },
                },
                "required": ["file_path"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: Any) -> Sequence[TextContent]:
    """Handle tool calls from AI agents."""
    mgr = get_manager()

    if name == "preview_snapshot":
        file_path = arguments["file_path"]
        parent_depth = arguments.get("parent_depth", 999)
        child_depth = arguments.get("child_depth", 999)
        include_chain = arguments.get("include_chain", False)
        include_frontend = arguments.get("include_frontend", False)

        preview = mgr.preview_snapshot(
            file_path=file_path,
            parent_depth=parent_depth,
            child_depth=child_depth,
            include_chain=include_chain,
            include_frontend=include_frontend,
        )

        if "error" in preview:
            return [TextContent(type="text", text=f"Error: {preview['error']}")]

        # Format response
        metrics = preview["metrics"]
        cost = preview["cost_estimate"]
        config = preview["config"]

        result = f"""# Snapshot Preview (DRY RUN): {file_path}

## Configuration
- Parent depth: {config['parent_depth']}
- Child depth: {config['child_depth']}
- Include chain: {config['include_chain']}
- Include frontend: {config['include_frontend']}

## Size Estimate
- Total files: {metrics['total_files']}
- Total lines: {metrics['total_lines']:,}
- Estimated input tokens: ~{metrics['estimated_input_tokens']:,}
- Estimated output tokens: ~{metrics['estimated_output_tokens']:,}
- **Total tokens: ~{metrics['estimated_total_tokens']:,}**

## Cost Estimate (Claude Sonnet 3.5)
- Input cost: ${cost['input_cost']:.4f}
- Output cost: ${cost['output_cost']:.4f}
- **Total per query: ${cost['total_cost']:.4f}**

## Files That Would Be Included
"""

        for file_info in preview["files"]:
            file_type = file_info["type"]
            result += f"- [{file_type:8}] {file_info['path']:50} {file_info['lines']:5} lines (~{file_info['estimated_tokens']:,} tokens)\n"

        if preview["recommendations"]:
            result += "\n## Recommendations\n"
            for rec in preview["recommendations"]:
                result += f"{rec}\n"

        result += "\n---\n**This is a preview only. Use create_snapshot to generate the actual snapshot.**"

        return [TextContent(type="text", text=result)]

    elif name == "list_entry_points":
        entry_points = mgr.get_entry_points()
        if not entry_points:
            return [TextContent(type="text", text="No entry points configured.")]

        result = "# Entry Points\n\n"
        for ep in entry_points:
            result += f"- **{ep['label']}**: `{ep['path']}`\n"
        result += f"\nTotal: {len(entry_points)} entry points\n"

        return [TextContent(type="text", text=result)]

    elif name == "query_codebase":
        file_path = arguments["file_path"]
        questions = arguments.get("questions", [])
        parent_depth = arguments.get("parent_depth", 999)
        child_depth = arguments.get("child_depth", 999)
        include_chain = arguments.get("include_chain", False)
        include_frontend = arguments.get("include_frontend", False)
        detail_level = arguments.get("detail_level", "normal")
        read_files = arguments.get("read_files", [])

        # Step 1: Create snapshot
        snapshot = mgr.create_snapshot(
            file_path=file_path,
            parent_depth=parent_depth,
            child_depth=child_depth,
            include_chain=include_chain,
            include_frontend=include_frontend,
        )

        if "error" in snapshot:
            return [TextContent(type="text", text=f"Error: {snapshot['error']}")]

        # Generate unique snapshot ID and store in cache
        snapshot_id = str(uuid.uuid4())
        snapshot_cache[snapshot_id] = snapshot

        # Step 2: Generate overview (always)
        overview = mgr.get_snapshot_overview(snapshot)

        # Step 3: Answer questions if provided
        answers = {}
        if questions:
            answers = mgr.query_snapshot_batch(snapshot, questions, detail_level)

        # Format response
        dep_map = snapshot["dependency_map"]
        metrics = snapshot["metrics"]

        result = f"""# Codebase Query Results: {file_path}

**Snapshot ID:** `{snapshot_id}` (use for follow-up questions)

## Snapshot Info
- Total Files: {dep_map['stats']['total_files']}
- Total Lines: {metrics['total_lines']:,}
- Estimated Tokens: ~{metrics['token_estimate']:,}

---

{overview}

"""

        # Collect all primary_files from all answers (deduplicated)
        all_primary_files = set()

        if answers:
            result += "\n---\n\n# Answers to Your Questions\n\n"

            # Add clear notice if no files were requested
            if not read_files:
                result += "ℹ️ **Note**: Answers below include CODE SNIPPETS only. For COMPLETE source code, see suggested files at the end.\n\n"

            for i, question in enumerate(questions, 1):
                answer_data = answers[question]
                result += f"## Question {i}: {question}\n\n"

                # Handle both JSON and fallback text formats
                if isinstance(answer_data, dict):
                    result += f"{answer_data.get('answer', '')}\n\n"

                    # Collect primary_files for later (deduplicated)
                    primary_files = answer_data.get('primary_files', [])
                    if primary_files:
                        all_primary_files.update(primary_files)

                    # Add code references with actual code snippets
                    code_refs = answer_data.get('code_references', [])
                    if code_refs:
                        result += "**Code References:**\n\n"
                        for ref in code_refs:
                            path = ref.get('path', '')
                            start = ref.get('start', '')
                            end = ref.get('end', '')
                            context = ref.get('context', '')

                            result += f"### {path}:{start}-{end}\n"
                            result += f"*{context}*\n\n"

                            # Fetch the actual code snippet
                            try:
                                from pathlib import Path
                                full_path = Path(mgr.project_root) / path
                                if full_path.exists():
                                    with open(full_path, 'r') as f:
                                        lines = f.readlines()
                                        # Extract the relevant lines (convert to 0-indexed)
                                        snippet_lines = lines[start-1:end]
                                        snippet = ''.join(snippet_lines)
                                        result += f"```python\n{snippet}```\n\n"
                                else:
                                    result += f"*File not found: {full_path}*\n\n"
                            except Exception as e:
                                result += f"*Error reading file: {e}*\n\n"
                else:
                    # Fallback for old text format
                    result += f"{answer_data}\n\n"

                result += "---\n\n"

            # Show suggested files (primary_files)
            if all_primary_files:
                result += "\n" + "="*80 + "\n"
                result += "# 📚 FILES TO READ FOR COMPLETE UNDERSTANDING\n\n"
                result += "⚠️ **IMPORTANT**: The answers above show SNIPPETS only. To get COMPLETE source code\n"
                result += "(with all imports, setup, helpers, comments), you must REQUEST these files:\n\n"
                for pf in sorted(all_primary_files):
                    result += f"  • {pf}\n"
                result += f"\n💡 **To read these NOW, add this parameter:**\n"
                result += f"```python\nread_files={sorted(list(all_primary_files))}\n```\n\n"
                result += "Or cherry-pick specific files you need.\n\n"

        # Read requested files (if any)
        if read_files:
            result += "\n" + "="*80 + "\n"
            result += f"# COMPLETE SOURCE ({len(read_files)} files requested)\n\n"

            for file_path in read_files:
                try:
                    from pathlib import Path
                    full_path = Path(mgr.project_root) / file_path
                    if full_path.exists():
                        with open(full_path, 'r') as f:
                            content = f.read()
                            line_count = content.count('\n') + 1

                        result += f"## {file_path} ({line_count} lines)\n\n"
                        result += f"```python\n{content}```\n\n"
                    else:
                        result += f"## {file_path}\n*File not found: {full_path}*\n\n"
                except Exception as e:
                    result += f"## {file_path}\n*Error reading file: {e}*\n\n"

        result += f"""
**Next steps:**
- Use snapshot_id `{snapshot_id}` with query_snapshot_batch for follow-up questions
- Or query a different file with query_codebase
"""

        return [TextContent(type="text", text=result)]

    elif name == "query_snapshot_batch":
        snapshot_id = arguments["snapshot_id"]
        questions = arguments["questions"]
        detail_level = arguments.get("detail_level", "normal")
        read_files = arguments.get("read_files", [])

        # Retrieve snapshot from cache
        if snapshot_id not in snapshot_cache:
            return [TextContent(type="text", text=f"Error: Snapshot ID '{snapshot_id}' not found. Please create a snapshot first using query_codebase.")]

        snapshot = snapshot_cache[snapshot_id]
        results = mgr.query_snapshot_batch(snapshot, questions, detail_level)

        # Collect all primary_files from all questions (deduplicated)
        all_primary_files = set()

        # Format results with snapshot context
        dep_map = snapshot.get("dependency_map", {})
        metrics = snapshot.get("metrics", {})

        output = f"# Batch Query Results ({len(questions)} questions)\n\n"
        output += f"**Snapshot**: `{snapshot_id}`\n\n"

        # Add snapshot context
        if dep_map and metrics:
            output += "## Snapshot Context\n"
            output += f"- Target: `{dep_map.get('target', 'N/A')}`\n"
            output += f"- Total Files: {dep_map.get('stats', {}).get('total_files', 'N/A')}\n"
            output += f"- Total Lines: {metrics.get('total_lines', 'N/A'):,}\n"
            output += f"- Estimated Tokens: ~{metrics.get('token_estimate', 'N/A'):,}\n\n"

        output += "---\n\n"

        # Add clear notice if no files were requested
        if not read_files:
            output += "ℹ️ **Note**: Answers below include CODE SNIPPETS only. For COMPLETE source code, see suggested files at the end.\n\n"

        for i, question in enumerate(questions, 1):
            result = results[question]
            output += f"## Question {i}: {question}\n\n"

            # Handle both JSON and fallback text formats
            if isinstance(result, dict):
                output += f"{result.get('answer', '')}\n\n"

                # Collect primary_files for later (deduplicated)
                primary_files = result.get('primary_files', [])
                if primary_files:
                    all_primary_files.update(primary_files)

                # Add code references with actual code snippets
                code_refs = result.get('code_references', [])
                if code_refs:
                    output += "**Code References:**\n\n"
                    for ref in code_refs:
                        path = ref.get('path', '')
                        start = ref.get('start', '')
                        end = ref.get('end', '')
                        context = ref.get('context', '')

                        output += f"### {path}:{start}-{end}\n"
                        output += f"*{context}*\n\n"

                        # Fetch the actual code snippet
                        try:
                            from pathlib import Path
                            full_path = Path(mgr.project_root) / path
                            if full_path.exists():
                                with open(full_path, 'r') as f:
                                    lines = f.readlines()
                                    # Extract the relevant lines (convert to 0-indexed)
                                    snippet_lines = lines[start-1:end]
                                    snippet = ''.join(snippet_lines)
                                    output += f"```python\n{snippet}```\n\n"
                            else:
                                output += f"*File not found: {full_path}*\n\n"
                        except Exception as e:
                            output += f"*Error reading file: {e}*\n\n"
            else:
                # Fallback for old text format
                output += f"{result}\n\n"

            output += "---\n\n"

        # Show suggested files (primary_files)
        if all_primary_files:
            output += "\n" + "="*80 + "\n"
            output += "# 📚 FILES TO READ FOR COMPLETE UNDERSTANDING\n\n"
            output += "⚠️ **IMPORTANT**: The answers above show SNIPPETS only. To get COMPLETE source code\n"
            output += "(with all imports, setup, helpers, comments), you must REQUEST these files:\n\n"
            for pf in sorted(all_primary_files):
                output += f"  • {pf}\n"
            output += f"\n💡 **To read these NOW, add this parameter:**\n"
            output += f"```python\nread_files={sorted(list(all_primary_files))}\n```\n\n"
            output += "Or cherry-pick specific files you need.\n\n"

        # Read requested files (if any)
        if read_files:
            output += "\n" + "="*80 + "\n"
            output += f"# COMPLETE SOURCE ({len(read_files)} files requested)\n\n"

            for file_path in read_files:
                try:
                    from pathlib import Path
                    full_path = Path(mgr.project_root) / file_path
                    if full_path.exists():
                        with open(full_path, 'r') as f:
                            content = f.read()
                            line_count = content.count('\n') + 1

                        output += f"## {file_path} ({line_count} lines)\n\n"
                        output += f"```python\n{content}```\n\n"
                    else:
                        output += f"## {file_path}\n*File not found: {full_path}*\n\n"
                except Exception as e:
                    output += f"## {file_path}\n*Error reading file: {e}*\n\n"

        return [TextContent(type="text", text=output)]

    elif name == "analyze_snapshot":
        snapshot_id = arguments["snapshot_id"]

        # Retrieve snapshot from cache
        if snapshot_id not in snapshot_cache:
            return [TextContent(type="text", text=f"Error: Snapshot ID '{snapshot_id}' not found. Please create a snapshot first using query_codebase.")]

        snapshot = snapshot_cache[snapshot_id]
        result = mgr.analyze_snapshot(snapshot)

        if "error" in result:
            return [TextContent(type="text", text=f"Error: {result['error']}")]

        # Format response
        output = "# Analysis Complete\n\n"

        if result.get("overview"):
            overview = result["overview"]
            output += "## System Overview\n"
            output += f"- Architecture: {overview.get('architecture', 'N/A')}\n"
            output += f"- Entry Points: {', '.join(overview.get('entry_points', []))}\n"
            output += f"- Key Patterns: {', '.join(overview.get('key_patterns', []))}\n\n"

        if result.get("files"):
            output += f"## File Summaries\n\n"
            output += f"Analyzed {len(result['files'])} files:\n\n"
            for file_path, analysis in result["files"].items():
                output += f"### {file_path}\n"
                output += f"- Layer: {analysis.get('layer', 'unknown')}\n"
                output += f"- Tier 1: {analysis.get('tier1', 'N/A')}\n"
                output += f"- Tier 2: {analysis.get('tier2', 'N/A')}\n\n"

        output += "\nAnalysis cached. Regenerate snapshot to include in queries.\n"

        return [TextContent(type="text", text=output)]

    elif name == "get_dependency_info":
        file_path = arguments["file_path"]

        info = mgr.get_dependency_info(file_path)

        if "error" in info:
            return [TextContent(type="text", text=f"Error: {info['error']}")]

        # Format response
        output = f"# Dependency Info: {file_path}\n\n"

        output += f"## Target File\n"
        output += f"- Lines: {info['target']['lines']}\n"
        output += f"- Tokens: ~{info['target']['tokens']}\n\n"

        if info.get("parents"):
            output += f"## Parents ({len(info['parents'])} files import this)\n"
            for p in info["parents"][:10]:  # Limit to first 10
                output += f"- {p['path']} ({p['lines']} lines)\n"
            if len(info["parents"]) > 10:
                output += f"... and {len(info['parents']) - 10} more\n"
            output += "\n"

        if info.get("chains"):
            output += f"## Chains to Entry Points\n"
            for chain in info["chains"]:
                output += f"- {chain['emoji']} {chain['label']}: {len(chain['files'])} hops\n"
            output += "\n"

        if info.get("children_tree"):
            tree = info["children_tree"]
            child_count = len(tree.get("children", []))
            output += f"## Children ({child_count} direct imports)\n"
            for child in tree.get("children", [])[:10]:
                output += f"- {child['path']} ({child['lines']} lines)\n"
            if child_count > 10:
                output += f"... and {child_count - 10} more\n"

        return [TextContent(type="text", text=output)]

    else:
        raise ValueError(f"Unknown tool: {name}")


async def async_main():
    """Run the MCP server."""
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


def main():
    """Entry point for the prism MCP server (used by setuptools)."""
    import asyncio
    asyncio.run(async_main())


if __name__ == "__main__":
    main()
