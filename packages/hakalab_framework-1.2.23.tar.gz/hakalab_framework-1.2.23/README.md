# 🚀 **Hakalab Framework**

Un framework completo y profesional de pruebas funcionales que utiliza **Playwright** para automatización web moderna y **Behave** para BDD (Behavior Driven Development). Diseñado para casos de uso empresariales con capacidades avanzadas de simulación humana y procesamiento de datos.

## ✨ **Características Principales v1.2.14**

### 🎯 **Core Features**
- **🎭 Playwright**: Automatización web moderna, rápida y confiable
- **🥒 Behave**: Framework BDD para Python con soporte completo para Gherkin
- **🌍 Multiidioma**: Soporte para pasos en inglés, español o mixto
- **📋 Page Object Model**: Elementos organizados en archivos JSON
- **🔤 Variables Dinámicas**: Sistema completo de manejo y generación de variables
- **📊 Reportes HTML**: Reportes HTML personalizados con screenshots integrados
- **🎨 Scenario Outlines**: Soporte completo para pruebas parametrizadas

### 🆕 **Nuevas Funcionalidades v1.2.14**
- **📊 Procesamiento CSV**: Carga, análisis, filtrado y manipulación de archivos CSV
- **⌨️ Entrada Avanzada**: Simulación de escritura humana con errores y velocidades variables
- **⏱️ Control de Tiempos**: Cronómetros, esperas inteligentes y medición de rendimiento
- **🔤 Variables Mejoradas**: Generación automática de texto, números, fechas y timestamps
- **🎭 Simulación Realista**: Comportamiento humano con delays aleatorios y errores simulados
- **📈 Medición de Rendimiento**: Cronometraje de operaciones críticas
- **🎯 Drag & Drop Mejorado**: Sistema rediseñado con múltiples fallbacks y timing preciso

### 🔧 **Capacidades Avanzadas**
- **🎯 Drag & Drop**: Arrastrar y soltar elementos con precisión y confiabilidad mejorada
- **🚨 Alerts & Modales**: Manejo completo de diálogos y ventanas emergentes
- **🖼️ iFrames**: Navegación y interacción con contenido embebido
- **📁 File Upload/Download**: Gestión completa de archivos con validación
- **🔍 Búsquedas Avanzadas**: Múltiples estrategias de localización de elementos
- **📱 Responsive Testing**: Pruebas en diferentes resoluciones y dispositivos
- **🎬 Video Recording**: Grabación automática de ejecuciones de prueba

## 🚀 **Instalación Rápida**

### Opción 1: Instalación desde PyPI (Recomendada)
```bash
pip install hakalab-framework
python -m playwright install
hakalab-init my-project
cd my-project
behave
```

### Opción 2: Instalación desde Código Fuente
```bash
git clone https://github.com/your-org/hakalab-framework.git
cd hakalab-framework
pip install -e .
python -m playwright install
behave
```

## 📁 **Estructura del Proyecto**

```
my-project/
├── 📂 features/
│   ├── 📄 example_login.feature    # Feature de ejemplo
│   ├── 📄 environment.py           # Configuración de Behave
│   └── 📂 steps/
│       └── 📄 custom_steps.py      # Steps personalizados
├── 📂 json_poms/
│   ├── 📄 LOGIN.json              # Page Objects en JSON
│   └── 📄 DASHBOARD.json          # Elementos de dashboard
├── 📂 hakalab_framework/
│   ├── 📂 core/                   # Núcleo del framework
│   ├── 📂 steps/                  # Steps predefinidos
│   │   ├── 📄 navigation_steps.py  # Navegación y URLs
│   │   ├── 📄 interaction_steps.py # Clicks, hover, formularios
│   │   ├── 📄 assertion_steps.py   # Verificaciones
│   │   ├── 📄 wait_steps.py        # Esperas y timing
│   │   ├── 📄 window_steps.py      # Ventanas y pestañas
│   │   ├── 📄 advanced_steps.py    # JavaScript y screenshots
│   │   ├── 📄 drag_drop_steps.py   # Arrastrar y soltar (MEJORADO v1.2.14)
│   │   ├── 📄 modal_steps.py       # Modales y diálogos
│   │   ├── 📄 combobox_steps.py    # Selects y dropdowns
│   │   ├── 📄 iframe_steps.py      # Interacción con iframes
│   │   ├── 📄 file_steps.py        # Upload y download
│   │   ├── 📄 table_steps.py       # Tablas avanzadas
│   │   ├── 📄 keyboard_mouse_steps.py # Interacciones avanzadas
│   │   ├── 📄 salesforce_steps.py  # Automatización Salesforce
│   │   ├── 📄 environment_steps.py # Variables de entorno
│   │   ├── 📄 data_extraction_steps.py # Extracción de datos
│   │   ├── 📄 csv_file_steps.py    # Procesamiento CSV (NUEVO v1.2.12)
│   │   ├── 📄 timing_steps.py      # Control avanzado de tiempos (NUEVO v1.2.12)
│   │   ├── 📄 advanced_input_steps.py # Entrada sofisticada (NUEVO v1.2.12)
│   │   └── 📄 variable_steps.py    # Variables dinámicas (NUEVO v1.2.12)
│   └── 📂 utils/                  # Utilidades y helpers
├── 📂 html-reports/               # Reportes HTML generados
├── 📂 screenshots/                # Capturas de pantalla
├── 📂 videos/                     # Grabaciones de video
├── 📂 downloads/                  # Archivos descargados
├── 📄 .env                        # Variables de entorno
├── 📄 behave.ini                  # Configuración de Behave
└── 📚 Documentación/
    ├── 📄 GUIA_COMPLETA_STEPS.md      # Guía completa de steps
    ├── 📄 FUNCIONALIDADES_AVANZADAS_v1.2.14.md # Nuevas funcionalidades
    ├── 📄 GUIA_INSTALACION.md         # Guía de instalación
    ├── 📄 STEPS_AVANZADOS.md          # Steps avanzados
    ├── 📄 STEPS_SALESFORCE.md         # Automatización Salesforce
    ├── 📄 VARIABLES_ENTORNO.md        # Variables de entorno
    └── 📄 GUIA_STEPS_PERSONALIZADOS.md # Crear steps personalizados
```

## 🎯 **Steps Disponibles (300+)**

### 🧭 **Navigation Steps** - Navegación y URLs
```gherkin
Given voy a la url "https://example.com"
When recargo la página
When voy hacia atrás
When espero 5 segundos
When abro una nueva pestaña
```

### 🖱️ **Interaction Steps** - Clicks, hover, formularios
```gherkin
When hago click en el elemento "button_login" con identificador "id"
When relleno el campo "username" con "admin" con identificador "name"
When selecciono la opción "España" del dropdown "country" con identificador "name"
When marco el checkbox "terms" con identificador "id"
```

### ✅ **Assertion Steps** - Verificaciones y validaciones
```gherkin
Then debería ver el texto "Bienvenido"
Then el título de la página debería ser "Dashboard"
Then el elemento "welcome_message" debería estar visible con identificador "id"
Then la url actual debería contener "dashboard"
```

### 🎯 **Drag & Drop Steps** - Arrastrar y soltar (MEJORADO v1.2.14)
```gherkin
# Drag & Drop básico con timing mejorado
When arrastro el elemento "source_item" al elemento "target_area" con identificadores "id" y "class"

# Drag & Drop lento para elementos sensibles (20 pasos incrementales)
When arrastro lentamente el elemento "delicate_slider" al elemento "target" con identificadores "css" y "id"

# Hover antes de arrastrar (para elementos que requieren activación)
When paso el mouse sobre el elemento antes de arrastrar "menu_item" con identificador "class"

# Drag & Drop avanzado con múltiples fallbacks (API nativa + manual + HTML5)
When realizo drag and drop avanzado desde "complex_element" hasta "target" con identificadores "xpath" y "css"

# Verificación de drag & drop exitoso
Then verifico que el drag and drop fue exitoso comprobando la posición del elemento "moved_item" con identificador "id"

# Drag & Drop de archivos
When arrastro y suelto el archivo "test_document.pdf" al elemento "upload_zone" con identificador "id"

# Drag & Drop por coordenadas específicas
When arrastro el elemento "item" a las coordenadas x="300" y="200" con identificador "id"

# Drag & Drop por desplazamiento relativo
When arrastro el elemento "box" por desplazamiento x="100" y="-50" con identificador "class"
```

### 📋 **Combobox Steps** - Selects y dropdowns avanzados
```gherkin
When selecciono por texto visible "Opción 1" del elemento "dropdown" con identificador "id"
When escribo y selecciono "Madrid" en el combobox buscable "city" con identificador "id"
```

### 💬 **Modal Steps** - Modales y diálogos
```gherkin
When espero a que aparezca el modal
When cierro el modal haciendo clic en el botón de cerrar
Then el modal debería contener el texto "Confirmar acción"
```

### 📁 **File Steps** - Upload, download y archivos
```gherkin
When subo el archivo "documents/test.pdf" al campo "file_upload" con identificador "id"
Then el archivo "report.pdf" debería estar descargado
Then el archivo descargado "data.csv" debería contener "usuario,email"
```

## 🔧 **Configuración**

### Variables de Entorno (.env)
```bash
# === CONFIGURACIÓN DEL NAVEGADOR ===
BROWSER=chromium              # chromium, firefox, webkit
HEADLESS=false               # true/false
TIMEOUT=30000                # Timeout en milisegundos
WINDOW_SIZE=1920,1080        # Tamaño de ventana

# === RUTAS Y DIRECTORIOS ===
JSON_POMS_PATH=json_poms     # Carpeta de Page Objects
SCREENSHOTS_DIR=screenshots   # Directorio de screenshots
HTML_REPORTS_DIR=html-reports # Directorio de reportes HTML
DOWNLOADS_DIR=downloads       # Directorio de descargas
VIDEOS_DIR=videos            # Directorio de videos

# === FUNCIONALIDADES AVANZADAS ===
HTML_REPORT_CAPTURE_ALL_STEPS=true  # Screenshots en cada step
SCREENSHOT_FULL_PAGE=true            # Screenshots de página completa
VIDEO_RECORDING=false                # Grabación de video
CLEANUP_OLD_FILES=true               # Limpieza automática
CLEANUP_MAX_AGE_HOURS=24            # Edad máxima de archivos

# === VARIABLES DE PRUEBA ===
BASE_URL=https://example.com
TEST_EMAIL=test@example.com
TEST_PASSWORD=password123
API_KEY=your-api-key-here
DATABASE_URL=postgresql://localhost/testdb
```

## 🎬 **Ejemplos de Uso**

### 1. Feature Básico
```gherkin
# language: es
Feature: Login de usuario
  Como usuario del sistema
  Quiero poder iniciar sesión
  Para acceder a mi cuenta

  Background:
    Given voy a la url "${BASE_URL}/login"

  Scenario: Login exitoso
    When relleno el campo "email" con "${TEST_EMAIL}" con identificador "$.LOGIN.email_field"
    And relleno el campo "password" con "${TEST_PASSWORD}" con identificador "$.LOGIN.password_field"
    And hago click en el elemento "login_button" con identificador "$.LOGIN.login_button"
    Then debería ver el elemento "welcome_message" con identificador "$.DASHBOARD.welcome_message"
    And la url actual debería contener "dashboard"
```

### 2. Procesamiento de CSV (NUEVO v1.2.12)
```gherkin
Feature: Pruebas con datos CSV
  
  Scenario: Procesamiento de empleados desde CSV
    Given cargo el archivo CSV "test_data/empleados.csv" en la variable "empleados"
    And muestro un resumen del CSV "empleados"
    When filtro el CSV "empleados" donde "departamento" contiene "Desarrollo" y guardo como "desarrolladores"
    And obtengo el valor de la fila 0 columna "nombre" del CSV "desarrolladores" y lo guardo en "mejor_dev"
    Then verifico que la variable "mejor_dev" contiene "Juan"
```

### 3. Drag & Drop Mejorado (NUEVO v1.2.14)
```gherkin
Feature: Drag and Drop avanzado
  
  Scenario: Reordenamiento de elementos con verificación
    Given voy a la url "https://example.com/sortable-list"
    When paso el mouse sobre el elemento antes de arrastrar "item_1" con identificador "css:.sortable-item:first-child"
    And arrastro lentamente el elemento "item_1" al elemento "drop_zone" con identificadores "css:.sortable-item:first-child" y "css:.drop-zone"
    Then verifico que el drag and drop fue exitoso comprobando la posición del elemento "item_1" con identificador "css:.sortable-item:first-child"
```

## 📊 **Reportes**

### Reportes HTML Automáticos
- **Generación automática**: Reportes HTML se crean en cada ejecución
- **Screenshots integrados**: Capturas automáticas en fallos y steps críticos
- **Navegación intuitiva**: Interface web para revisar resultados
- **Estadísticas detalladas**: Tiempos, éxitos, fallos por feature y scenario

### Comandos de Reporte
```bash
# Ejecutar con reporte HTML
behave -f html -o html-reports/report.html

# Abrir reporte generado
open html-reports/report.html  # Mac
start html-reports/report.html # Windows
xdg-open html-reports/report.html # Linux
```

## 🔄 **Changelog**

### **v1.2.14** - 2026-01-06 ⭐ **NUEVA VERSIÓN MAYOR**

#### ✨ **Nuevas Funcionalidades**
- **📊 Manejo Avanzado de CSV**: 15+ steps para procesamiento completo de archivos CSV
- **🔤 Variables Dinámicas**: 20+ steps para generación y manipulación automática de variables
- **⏱️ Control de Tiempos**: 15+ steps para cronómetros, esperas inteligentes y medición de rendimiento
- **⌨️ Entrada Avanzada**: 25+ steps para simulación de escritura humana y manipulación sofisticada de texto
- **🎯 Drag & Drop Mejorado**: Sistema completamente rediseñado con múltiples métodos de fallback

#### 🔧 **Mejoras Técnicas**
- Sistema de variables completamente rediseñado con resolución automática
- Integración completa con pandas para procesamiento de datos CSV
- Cronómetros de alta precisión para medición de rendimiento
- Simulación realista de comportamiento humano con errores y delays variables
- **Drag & Drop robusto** con mouse down/up, timing delays y verificación de posición

#### 🎯 **Mejoras Específicas de Drag & Drop v1.2.14**
- ✅ Secuencias mouse down/up apropiadas con timing delays (100-500ms)
- ✅ Método de arrastre lento con 20 pasos incrementales para elementos sensibles
- ✅ Hover antes de arrastrar para activar elementos que requieren interacción previa
- ✅ API nativa de Playwright como método primario con fallback manual
- ✅ Simulación HTML5 drag & drop con JavaScript completamente funcional con soporte CSS y XPath (v1.2.20)
- ✅ Verificación automática de posición después del drag & drop
- ✅ Manejo robusto de errores con múltiples métodos de retry
- ✅ Soporte para arrastre por coordenadas específicas y desplazamientos relativos

#### 📁 **Archivos Nuevos**
- `hakalab_framework/steps/csv_file_steps.py` - Procesamiento de CSV
- `hakalab_framework/steps/timing_steps.py` - Control avanzado de tiempos
- `hakalab_framework/steps/advanced_input_steps.py` - Entrada sofisticada
- `hakalab_framework/steps/enhanced_variable_steps.py` - Variables dinámicas

#### 📝 **Archivos Mejorados**
- `hakalab_framework/steps/drag_drop_steps.py` - **Drag & drop completamente rediseñado**

## 📖 **Documentación Completa**

### 📖 **Guías Disponibles**
- **[GUIA_COMPLETA_STEPS.md](GUIA_COMPLETA_STEPS.md)** - Referencia completa de todos los steps (300+)
- **[FUNCIONALIDADES_AVANZADAS_v1.2.14.md](FUNCIONALIDADES_AVANZADAS_v1.2.14.md)** - Nuevas funcionalidades detalladas
- **[GUIA_INSTALACION.md](GUIA_INSTALACION.md)** - Guía detallada de instalación
- **[STEPS_AVANZADOS.md](STEPS_AVANZADOS.md)** - Steps avanzados y casos de uso
- **[STEPS_SALESFORCE.md](STEPS_SALESFORCE.md)** - Automatización específica de Salesforce
- **[VARIABLES_ENTORNO.md](VARIABLES_ENTORNO.md)** - Configuración de variables de entorno
- **[GUIA_STEPS_PERSONALIZADOS.md](GUIA_STEPS_PERSONALIZADOS.md)** - Crear steps personalizados

### 🎬 **Ejemplos Prácticos**
- **features/advanced_features_demo.feature** - Demostración de funcionalidades avanzadas
- **features/csv_handling_demo.feature** - Ejemplos de procesamiento CSV
- **features/example_login.feature** - Login básico
- **features/example_forms.feature** - Formularios complejos

## 🤝 **Contribuir**

### Proceso de Contribución
1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit tus cambios (`git commit -am 'Agregar nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Crea un Pull Request

### Desarrollo Local
```bash
git clone https://github.com/your-org/hakalab-framework.git
cd hakalab-framework
pip install -e .
python -m pytest tests/
behave features/
```

## 📄 **Licencia**

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para detalles.

## 🚀 **¡Comienza Ahora!**

```bash
# Instalación rápida
pip install hakalab-framework
python -m playwright install

# Crear proyecto
hakalab-init mi-proyecto
cd mi-proyecto

# Ejecutar primera prueba
behave
```

**El Hakalab Framework está listo para llevar tus pruebas automatizadas al siguiente nivel!**

Con 300+ steps reales, simulación de comportamiento humano, procesamiento de CSV, cronómetros de rendimiento, variables dinámicas y **drag & drop mejorado**, tienes todo lo necesario para crear automatizaciones de nivel empresarial.