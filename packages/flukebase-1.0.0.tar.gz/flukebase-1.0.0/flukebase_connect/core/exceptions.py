"""Custom exceptions for flukebase_connect.

Provides rich error classes with:
- Error codes for programmatic handling
- Human-readable messages
- Root cause identification
- Actionable solution suggestions
"""

from dataclasses import dataclass
from typing import List, Optional

DOCS_BASE_URL = "https://flukebase.me/docs"


@dataclass
class Solution:
    """An actionable solution for an error."""

    description: str
    command: Optional[str] = None
    priority: int = 0


class FlukeBaseError(Exception):
    """Base exception with rich error support."""

    code: str = "ERR_000"
    docs_path: Optional[str] = None

    def __init__(
        self,
        message: str,
        *,
        code: Optional[str] = None,
        cause: Optional[str] = None,
        solutions: Optional[List[Solution]] = None,
        docs_path: Optional[str] = None,
    ):
        self.message = message
        if code:
            self.code = code
        self.cause = cause
        self.solutions = solutions or []
        if docs_path:
            self.docs_path = docs_path
        super().__init__(message)

    @property
    def docs_url(self) -> Optional[str]:
        """Full documentation URL."""
        if self.docs_path:
            return f"{DOCS_BASE_URL}/{self.docs_path}"
        return None

    def format(self, verbose: bool = False, color: bool = True) -> str:
        """Format error for display."""
        RED = "\033[91m" if color else ""
        YELLOW = "\033[93m" if color else ""
        CYAN = "\033[96m" if color else ""
        BOLD = "\033[1m" if color else ""
        RESET = "\033[0m" if color else ""

        lines = [f"{RED}{BOLD}Error [{self.code}]{RESET}: {self.message}"]

        if self.cause:
            lines.append(f"\n{YELLOW}Cause:{RESET} {self.cause}")

        if self.solutions:
            lines.append(f"\n{CYAN}Solutions:{RESET}")
            sorted_solutions = sorted(self.solutions, key=lambda s: -s.priority)
            for i, sol in enumerate(sorted_solutions, 1):
                lines.append(f"  {i}. {sol.description}")
                if sol.command:
                    lines.append(f"     → {BOLD}{sol.command}{RESET}")

        if self.docs_url and verbose:
            lines.append(f"\n{CYAN}Docs:{RESET} {self.docs_url}")

        return "\n".join(lines)

    def __str__(self) -> str:
        return self.format(color=False)


class AuthError(FlukeBaseError):
    """Authentication error."""

    code = "AUTH_001"
    docs_path = "auth/troubleshooting"

    def __init__(
        self,
        message: str = "Authentication failed",
        *,
        cause: Optional[str] = None,
        **kwargs,
    ):
        solutions = [
            Solution("Run 'fbc login' to refresh your token", "fbc login", 3),
            Solution("Check your token at https://flukebase.me/settings/tokens", priority=2),
        ]
        super().__init__(message, cause=cause, solutions=solutions, **kwargs)


class NotFoundError(FlukeBaseError):
    """Resource not found error."""

    code = "NOT_FOUND_001"


class ApiConnectionError(FlukeBaseError):
    """Connection error."""

    code = "CONN_001"
    docs_path = "troubleshooting/connection"

    def __init__(
        self,
        message: str = "Failed to connect to FlukeBase API",
        *,
        cause: Optional[str] = None,
        **kwargs,
    ):
        solutions = [
            Solution("Check your internet connection", priority=3),
            Solution("Verify FlukeBase API status", "fbc status", 2),
        ]
        super().__init__(message, cause=cause, solutions=solutions, **kwargs)


class ToolExecutionError(FlukeBaseError):
    """Remote tool execution error."""

    code = "TOOL_001"

    def __init__(
        self,
        tool_name: str,
        message: str,
        *,
        cause: Optional[str] = None,
        **kwargs,
    ):
        self.tool_name = tool_name
        solutions = [
            Solution("Check your connection status", "fbc status", 3),
            Solution("Verify the tool exists", "fbc tools", 2),
        ]
        super().__init__(
            f"Tool '{tool_name}' execution failed: {message}",
            cause=cause,
            solutions=solutions,
            **kwargs,
        )


class PythonVersionError(FlukeBaseError):
    """Python version requirement error."""

    code = "PY_001"
    docs_path = "troubleshooting/python"

    def __init__(
        self,
        current_version: str,
        required_version: str = "3.11+",
        *,
        cause: Optional[str] = None,
        **kwargs,
    ):
        self.current_version = current_version
        self.required_version = required_version
        solutions = [
            Solution("Upgrade Python to 3.11 or later", priority=3),
            Solution("Use pyenv to manage Python versions", "pyenv install 3.12", 2),
            Solution("Use a virtual environment with the correct Python", priority=1),
        ]
        super().__init__(
            f"Python {current_version} found, but {required_version} is required",
            cause=cause,
            solutions=solutions,
            **kwargs,
        )


class DependencyError(FlukeBaseError):
    """Missing dependency error."""

    code = "DEP_001"
    docs_path = "troubleshooting/dependencies"

    def __init__(
        self,
        package: str,
        *,
        cause: Optional[str] = None,
        **kwargs,
    ):
        self.package = package
        solutions = [
            Solution(f"Install the missing package", f"pip install {package}", 3),
            Solution("Reinstall flukebase-connect with all dependencies", "pip install --force-reinstall flukebase-connect", 2),
        ]
        super().__init__(
            f"Required dependency '{package}' is not installed",
            cause=cause,
            solutions=solutions,
            **kwargs,
        )


class ConfigurationError(FlukeBaseError):
    """Configuration error."""

    code = "CFG_001"
    docs_path = "troubleshooting/configuration"

    def __init__(
        self,
        message: str = "Invalid configuration",
        *,
        config_key: Optional[str] = None,
        cause: Optional[str] = None,
        **kwargs,
    ):
        self.config_key = config_key
        solutions = [
            Solution("Check your configuration file", priority=3),
            Solution("Run 'fbc doctor' to diagnose issues", "fbc doctor", 2),
            Solution("Reset configuration by removing ~/.flukebase-connect/config.toml", priority=1),
        ]
        if config_key:
            message = f"Configuration error for '{config_key}': {message}"
        super().__init__(message, cause=cause, solutions=solutions, **kwargs)


class OfflineError(FlukeBaseError):
    """Offline mode error when network is required."""

    code = "OFFLINE_001"
    docs_path = "troubleshooting/offline"

    def __init__(
        self,
        message: str = "This operation requires network connectivity",
        *,
        cause: Optional[str] = None,
        **kwargs,
    ):
        solutions = [
            Solution("Check your internet connection", priority=3),
            Solution("Try again later when online", priority=2),
            Solution("Use cached data if available", priority=1),
        ]
        super().__init__(message, cause=cause, solutions=solutions, **kwargs)


class ProjectNotFoundError(FlukeBaseError):
    """Project detection error."""

    code = "PROJ_001"
    docs_path = "troubleshooting/project"

    def __init__(
        self,
        message: str = "No project detected in current directory",
        *,
        cause: Optional[str] = None,
        **kwargs,
    ):
        solutions = [
            Solution("Navigate to a project directory", priority=3),
            Solution("Initialize a new project", "fbc init", 2),
            Solution("Specify project explicitly", "--project <id>", 1),
        ]
        super().__init__(message, cause=cause, solutions=solutions, **kwargs)


class RateLimitError(FlukeBaseError):
    """API rate limit exceeded error."""

    code = "RATE_001"
    docs_path = "troubleshooting/rate-limits"

    def __init__(
        self,
        retry_after: Optional[int] = None,
        *,
        cause: Optional[str] = None,
        **kwargs,
    ):
        self.retry_after = retry_after
        message = "API rate limit exceeded"
        if retry_after:
            message += f" (retry after {retry_after} seconds)"
        solutions = [
            Solution("Wait before retrying", priority=3),
            Solution("Reduce request frequency", priority=2),
        ]
        super().__init__(message, cause=cause, solutions=solutions, **kwargs)
