"""Diagnostics module for FlukeBase Connect client.

Provides comprehensive system checks, Python version manager detection,
and support bundle generation for troubleshooting.
"""

import os
import platform
import shutil
import socket
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

from flukebase_connect import __version__
from flukebase_connect.config import (
    DEV_HOST,
    DEV_PORT,
    PROD_API_URL,
    get_config,
)


@dataclass
class DiagnosticResult:
    """Result of a single diagnostic check."""

    name: str
    status: Literal["ok", "warn", "error"]
    message: str
    fix_command: Optional[str] = None
    details: Optional[Dict[str, Any]] = None


@dataclass
class PythonEnvironment:
    """Detected Python environment information."""

    manager: str = "global"  # pyenv, asdf, conda, uv, venv, global
    python_path: str = ""
    version: str = ""
    version_file: Optional[str] = None
    venv_path: Optional[str] = None
    is_active_venv: bool = False


class SystemDiagnostics:
    """Comprehensive system diagnostics for FlukeBase Connect."""

    def __init__(self):
        self.config = get_config()
        self._python_env: Optional[PythonEnvironment] = None

    def detect_python_manager(self) -> PythonEnvironment:
        """Detect Python version manager and environment."""
        if self._python_env:
            return self._python_env

        env = PythonEnvironment(
            python_path=sys.executable,
            version=f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        )

        # Check for active virtual environment
        if os.environ.get("VIRTUAL_ENV"):
            env.manager = "venv"
            env.venv_path = os.environ["VIRTUAL_ENV"]
            env.is_active_venv = True
        elif os.environ.get("CONDA_PREFIX"):
            env.manager = "conda"
            env.venv_path = os.environ["CONDA_PREFIX"]
            env.is_active_venv = True

        # Check for version manager files (project-specific)
        cwd = Path.cwd()
        python_version_file = cwd / ".python-version"
        tool_versions_file = cwd / ".tool-versions"

        if python_version_file.exists():
            env.version_file = str(python_version_file)
            if not env.is_active_venv:
                env.manager = "pyenv"
        elif tool_versions_file.exists():
            try:
                content = tool_versions_file.read_text()
                if "python" in content:
                    env.version_file = str(tool_versions_file)
                    if not env.is_active_venv:
                        env.manager = "asdf"
            except Exception:
                pass

        # Detect installed version managers
        if env.manager == "global":
            if shutil.which("pyenv") and os.environ.get("PYENV_ROOT"):
                env.manager = "pyenv"
            elif shutil.which("asdf"):
                env.manager = "asdf"
            elif shutil.which("uv"):
                env.manager = "uv"

        self._python_env = env
        return env

    def check_python_version(self) -> DiagnosticResult:
        """Check if Python version meets requirements."""
        env = self.detect_python_manager()
        version_info = sys.version_info

        if version_info >= (3, 11):
            return DiagnosticResult(
                name="Python Version",
                status="ok",
                message=f"Python {env.version} ({env.manager})",
                details={
                    "version": env.version,
                    "manager": env.manager,
                    "path": env.python_path,
                },
            )
        else:
            return DiagnosticResult(
                name="Python Version",
                status="error",
                message=f"Python {env.version} found, 3.11+ required",
                fix_command=self._get_python_upgrade_command(env.manager),
                details={
                    "version": env.version,
                    "manager": env.manager,
                    "required": "3.11+",
                },
            )

    def _get_python_upgrade_command(self, manager: str) -> str:
        """Get the appropriate Python upgrade command for the manager."""
        commands = {
            "pyenv": "pyenv install 3.12 && pyenv global 3.12",
            "asdf": "asdf install python 3.12.0 && asdf global python 3.12.0",
            "conda": "conda install python=3.12",
            "uv": "uv python install 3.12",
            "global": "Visit https://python.org/downloads/",
        }
        return commands.get(manager, commands["global"])

    def check_dependencies(self) -> List[DiagnosticResult]:
        """Check required and optional dependencies."""
        results = []

        # Required dependencies
        required = [
            ("httpx", "HTTP client"),
            ("mcp", "MCP protocol"),
            ("typer", "CLI framework"),
            ("rich", "Terminal formatting"),
        ]

        for package, description in required:
            try:
                __import__(package)
                results.append(DiagnosticResult(
                    name=f"Dependency: {package}",
                    status="ok",
                    message=f"{description} available",
                ))
            except ImportError:
                results.append(DiagnosticResult(
                    name=f"Dependency: {package}",
                    status="error",
                    message=f"{description} missing",
                    fix_command=f"pip install {package}",
                ))

        # Optional dependencies
        optional = [
            ("tomli", "TOML parser"),
        ]

        for package, description in optional:
            try:
                __import__(package)
                results.append(DiagnosticResult(
                    name=f"Optional: {package}",
                    status="ok",
                    message=f"{description} available",
                ))
            except ImportError:
                results.append(DiagnosticResult(
                    name=f"Optional: {package}",
                    status="warn",
                    message=f"{description} not installed (optional)",
                    fix_command=f"pip install {package}",
                ))

        return results

    def check_network(self) -> DiagnosticResult:
        """Check network connectivity to FlukeBase API."""
        # Check if localhost dev server is available
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1.0)
            result = sock.connect_ex((DEV_HOST, DEV_PORT))
            sock.close()
            if result == 0:
                return DiagnosticResult(
                    name="Network",
                    status="ok",
                    message=f"Local dev server available at {DEV_HOST}:{DEV_PORT}",
                    details={"mode": "development", "host": DEV_HOST, "port": DEV_PORT},
                )
        except Exception:
            pass

        # Check production API
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3.0)
            result = sock.connect_ex(("flukebase.me", 443))
            sock.close()
            if result == 0:
                return DiagnosticResult(
                    name="Network",
                    status="ok",
                    message="FlukeBase API reachable",
                    details={"mode": "production", "url": PROD_API_URL},
                )
        except Exception as e:
            return DiagnosticResult(
                name="Network",
                status="error",
                message=f"Cannot reach FlukeBase API: {e}",
                fix_command="Check your internet connection",
            )

        return DiagnosticResult(
            name="Network",
            status="error",
            message="Cannot reach FlukeBase API",
            fix_command="Check your internet connection or firewall settings",
        )

    def check_auth(self) -> DiagnosticResult:
        """Check authentication status."""
        if self.config.flukebase.api_token:
            # Mask token for display
            token = self.config.flukebase.api_token
            masked = f"{token[:7]}...{token[-4:]}" if len(token) > 15 else "****"
            return DiagnosticResult(
                name="Authentication",
                status="ok",
                message=f"Authenticated (token: {masked})",
                details={"has_token": True},
            )
        else:
            return DiagnosticResult(
                name="Authentication",
                status="error",
                message="Not authenticated",
                fix_command="fbc login",
                details={"has_token": False},
            )

    def check_config(self) -> DiagnosticResult:
        """Check configuration status."""
        config_file = self.config.home / "config.toml"

        if config_file.exists():
            return DiagnosticResult(
                name="Configuration",
                status="ok",
                message=f"Config file: {config_file}",
                details={
                    "path": str(config_file),
                    "api_url": self.config.flukebase.api_url,
                },
            )
        else:
            return DiagnosticResult(
                name="Configuration",
                status="warn",
                message="No config file (using defaults)",
                fix_command="fbc login",
                details={
                    "path": str(config_file),
                    "api_url": self.config.flukebase.api_url,
                },
            )

    def check_mcp_integration(self) -> DiagnosticResult:
        """Check MCP server integration status."""
        try:
            from flukebase_connect import server
            # Check if the main function exists
            if hasattr(server, 'main'):
                return DiagnosticResult(
                    name="MCP Integration",
                    status="ok",
                    message="MCP server module available",
                    details={"command": "fbc mcp"},
                )
            else:
                return DiagnosticResult(
                    name="MCP Integration",
                    status="warn",
                    message="MCP server module loaded but may be incomplete",
                    details={"command": "fbc mcp"},
                )
        except ImportError as e:
            return DiagnosticResult(
                name="MCP Integration",
                status="error",
                message=f"MCP module not available: {e}",
                fix_command="pip install flukebase-connect",
            )

    def collect_all(self) -> List[DiagnosticResult]:
        """Run all diagnostic checks."""
        results = [
            self.check_python_version(),
            self.check_config(),
            self.check_auth(),
            self.check_network(),
            self.check_mcp_integration(),
        ]
        results.extend(self.check_dependencies())
        return results


def generate_support_bundle() -> Dict[str, Any]:
    """Generate a support bundle for troubleshooting.

    Returns a dictionary with system info, diagnostics, and config
    that can be shared with support or used for debugging.
    """
    diagnostics = SystemDiagnostics()
    python_env = diagnostics.detect_python_manager()
    config = get_config()

    # Collect diagnostic results
    checks = diagnostics.collect_all()

    bundle = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "version": __version__,
        "system": {
            "platform": platform.system(),
            "platform_release": platform.release(),
            "platform_version": platform.version(),
            "architecture": platform.machine(),
            "hostname": platform.node(),
        },
        "python": {
            "version": python_env.version,
            "executable": python_env.python_path,
            "manager": python_env.manager,
            "version_file": python_env.version_file,
            "venv_path": python_env.venv_path,
            "is_venv": python_env.is_active_venv,
        },
        "config": {
            "home": str(config.home),
            "api_url": config.flukebase.api_url,
            "has_token": bool(config.flukebase.api_token),
            "config_exists": (config.home / "config.toml").exists(),
        },
        "diagnostics": [
            {
                "name": r.name,
                "status": r.status,
                "message": r.message,
                "fix_command": r.fix_command,
            }
            for r in checks
        ],
        "environment": {
            key: value
            for key, value in os.environ.items()
            if key.startswith(("FLUKEBASE_", "PYTHON", "VIRTUAL_ENV", "CONDA", "PYENV", "ASDF"))
        },
    }

    return bundle


def format_diagnostic_result(result: DiagnosticResult, use_color: bool = True) -> str:
    """Format a diagnostic result for terminal display."""
    if use_color:
        icons = {"ok": "\033[92m✓\033[0m", "warn": "\033[93m!\033[0m", "error": "\033[91m✗\033[0m"}
    else:
        icons = {"ok": "✓", "warn": "!", "error": "✗"}

    line = f"  {icons[result.status]} {result.name}: {result.message}"
    if result.fix_command and result.status != "ok":
        line += f"\n    → {result.fix_command}"
    return line
