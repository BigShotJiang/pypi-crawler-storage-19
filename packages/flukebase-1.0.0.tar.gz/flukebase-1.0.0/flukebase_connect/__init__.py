"""FlukeBase - CLI and MCP client for AI-assisted development.

This is the open-source client that communicates with the FlukeBase
platform for AI memory, task management, and environment sync.

Install: pip install flukebase
CLI: fbc --help
"""

__version__ = "1.0.0"
__all__ = ["__version__"]
