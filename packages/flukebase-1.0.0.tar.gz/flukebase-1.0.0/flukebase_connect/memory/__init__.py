"""Memory module - local SQLite storage for offline caching."""

__all__ = []
