"""CLI for FlukeBase Connect client."""

import asyncio
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from flukebase_connect import __version__
from flukebase_connect.config import get_config
from flukebase_connect.flukebase.client import FlukeBaseClient

# Import command groups
from flukebase_connect.commands.memory import app as mem_app
from flukebase_connect.commands.wedo import app as wedo_app
from flukebase_connect.commands.env import app as env_app
from flukebase_connect.commands.session import app as session_app
from flukebase_connect.commands.team import app as team_app

app = typer.Typer(
    name="fbc",
    help="FlukeBase Connect - AI-assisted development CLI",
    no_args_is_help=True,
)
console = Console()

# Register command groups
app.add_typer(mem_app, name="mem", help="Memory commands")
app.add_typer(wedo_app, name="wedo", help="WeDo task commands")
app.add_typer(env_app, name="env", help="Environment commands")
app.add_typer(session_app, name="session", help="Session commands")
app.add_typer(team_app, name="team", help="Team/dashboard commands")


@app.command()
def version():
    """Show version information."""
    console.print(f"FlukeBase Connect v{__version__}")
    console.print(f"Python: {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")


@app.command()
def login(
    token: Optional[str] = typer.Option(None, "--token", "-t", help="API token"),
):
    """Authenticate with FlukeBase."""
    config = get_config()

    if not token:
        console.print("[yellow]Get your API token from:[/yellow] https://flukebase.me/user_settings/api_tokens")
        token = typer.prompt("Enter your API token", hide_input=True)

    if not token or not token.startswith("fbk_"):
        console.print("[red]Invalid token format. Token should start with 'fbk_'[/red]")
        raise typer.Exit(1)

    # Validate token
    config.flukebase.api_token = token
    client = FlukeBaseClient(config)

    try:
        result = asyncio.run(_validate_and_save(client, config, token))
        if result:
            console.print("[green]Successfully authenticated![/green]")
        else:
            console.print("[red]Authentication failed[/red]")
            raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


async def _validate_and_save(client: FlukeBaseClient, config, token: str) -> bool:
    """Validate token and save config."""
    try:
        user = await client.get_current_user()
        console.print(f"Logged in as: [cyan]{user.email}[/cyan]")

        config.flukebase.api_token = token
        config.save()
        return True
    except Exception as e:
        console.print(f"[red]Validation failed: {e}[/red]")
        return False
    finally:
        await client.close()


@app.command()
def status():
    """Check FlukeBase connection status."""
    config = get_config()
    client = FlukeBaseClient(config)

    try:
        result = asyncio.run(_get_status(client))

        if result.get("connected"):
            console.print(Panel(
                f"[green]Connected[/green]\n"
                f"User: {result.get('user_email', 'Unknown')}\n"
                f"Projects: {result.get('project_count', 0)}",
                title="FlukeBase Status",
            ))
        else:
            console.print(Panel(
                "[red]Not connected[/red]\n\n"
                "Run [cyan]fbc login[/cyan] to authenticate.",
                title="FlukeBase Status",
            ))
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


async def _get_status(client: FlukeBaseClient) -> dict:
    """Get status asynchronously."""
    try:
        return await client.get_status()
    finally:
        await client.close()


@app.command()
def projects():
    """List your FlukeBase projects."""
    config = get_config()
    client = FlukeBaseClient(config)

    try:
        result = asyncio.run(_list_projects(client))

        if not result:
            console.print("[yellow]No projects found.[/yellow]")
            return

        table = Table(title="Your Projects")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="green")
        table.add_column("Framework")
        table.add_column("Stage")

        for project in result:
            table.add_row(
                str(project.id),
                project.name,
                project.framework or "-",
                project.stage or "-",
            )

        console.print(table)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


async def _list_projects(client: FlukeBaseClient):
    """List projects asynchronously."""
    try:
        return await client.list_projects()
    finally:
        await client.close()


@app.command()
def doctor(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed information"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Check installation health and diagnose issues."""
    from flukebase_connect.diagnostics import (
        SystemDiagnostics,
        format_diagnostic_result,
        generate_support_bundle,
    )

    diagnostics = SystemDiagnostics()
    python_env = diagnostics.detect_python_manager()

    if json_output:
        import json
        bundle = generate_support_bundle()
        console.print(json.dumps(bundle, indent=2))
        return

    # Header
    console.print(Panel(
        f"[cyan]FlukeBase Connect v{__version__}[/cyan]\n"
        f"Python: {python_env.version} ({python_env.manager})\n"
        f"Path: {python_env.python_path}",
        title="Installation Check",
    ))

    # Run all diagnostics
    results = diagnostics.collect_all()

    # Group by status
    errors = [r for r in results if r.status == "error"]
    warnings = [r for r in results if r.status == "warn"]
    passed = [r for r in results if r.status == "ok"]

    console.print("\n[bold]Diagnostics:[/bold]")
    for result in results:
        icon = {"ok": "[green]✓[/green]", "warn": "[yellow]![/yellow]", "error": "[red]✗[/red]"}[result.status]
        console.print(f"  {icon} {result.name}: {result.message}")
        if result.fix_command and result.status != "ok":
            console.print(f"    [dim]→ {result.fix_command}[/dim]")
        if verbose and result.details:
            for key, value in result.details.items():
                console.print(f"    [dim]{key}: {value}[/dim]")

    # Summary
    console.print()
    if errors:
        console.print(f"[red]✗ {len(errors)} error(s)[/red] | ", end="")
    if warnings:
        console.print(f"[yellow]! {len(warnings)} warning(s)[/yellow] | ", end="")
    console.print(f"[green]✓ {len(passed)} passed[/green]")

    if errors:
        console.print("\n[yellow]Run 'fbc support' to generate a troubleshooting bundle.[/yellow]")
        raise typer.Exit(1)


@app.command()
def support(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    save: Optional[str] = typer.Option(None, "--save", "-s", help="Save to file"),
):
    """Generate a support bundle for troubleshooting."""
    import json
    from flukebase_connect.diagnostics import generate_support_bundle

    bundle = generate_support_bundle()

    if save:
        path = Path(save)
        path.write_text(json.dumps(bundle, indent=2))
        console.print(f"[green]Support bundle saved to:[/green] {path}")
        console.print("\n[dim]Share this file with support for troubleshooting.[/dim]")
    elif json_output:
        console.print(json.dumps(bundle, indent=2))
    else:
        # Pretty print summary
        console.print(Panel(
            f"[cyan]Support Bundle[/cyan]\n"
            f"Generated: {bundle['generated_at']}\n"
            f"Version: {bundle['version']}",
            title="FlukeBase Connect",
        ))

        console.print("\n[bold]System:[/bold]")
        for key, value in bundle["system"].items():
            console.print(f"  {key}: {value}")

        console.print("\n[bold]Python:[/bold]")
        for key, value in bundle["python"].items():
            if value:
                console.print(f"  {key}: {value}")

        console.print("\n[bold]Configuration:[/bold]")
        for key, value in bundle["config"].items():
            console.print(f"  {key}: {value}")

        console.print("\n[bold]Diagnostics:[/bold]")
        for diag in bundle["diagnostics"]:
            icon = {"ok": "[green]✓[/green]", "warn": "[yellow]![/yellow]", "error": "[red]✗[/red]"}[diag["status"]]
            console.print(f"  {icon} {diag['name']}: {diag['message']}")

        if bundle["environment"]:
            console.print("\n[bold]Environment Variables:[/bold]")
            for key, value in bundle["environment"].items():
                # Mask sensitive values
                if "TOKEN" in key or "SECRET" in key:
                    value = "****"
                console.print(f"  {key}={value}")

        console.print("\n[dim]Use --json for machine-readable output or --save to export.[/dim]")


@app.command()
def mcp():
    """Start MCP server (for AI assistant integration)."""
    from flukebase_connect.server import main as run_server
    run_server()


@app.command()
def tools():
    """List available MCP tools."""
    config = get_config()
    client = FlukeBaseClient(config)

    try:
        result = asyncio.run(_list_tools(client))

        if not result:
            console.print("[yellow]No tools available. Check your connection.[/yellow]")
            return

        table = Table(title="Available Tools")
        table.add_column("Name", style="cyan")
        table.add_column("Description")

        for tool in result:
            table.add_row(
                tool.get("name", ""),
                tool.get("description", "")[:60] + "..." if len(tool.get("description", "")) > 60 else tool.get("description", ""),
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(result)} tools[/dim]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


async def _list_tools(client: FlukeBaseClient):
    """List tools asynchronously."""
    try:
        return await client.list_available_tools()
    finally:
        await client.close()


def main():
    """Main entry point."""
    app()


if __name__ == "__main__":
    main()
