"""Plugins module - plugin framework for user extensions."""

__all__ = []
