"""Command modules for FlukeBase Connect CLI.

These commands proxy tool calls to the FlukeBase API, enabling power users
to use CLI commands that map to MCP tools without running a full MCP server.
"""

import asyncio
from typing import Any, Dict, Optional

from rich.console import Console

from flukebase_connect.config import get_config
from flukebase_connect.flukebase.client import FlukeBaseClient

console = Console()


async def _proxy_tool_async(
    tool_name: str,
    params: Optional[Dict[str, Any]] = None,
    client: Optional[FlukeBaseClient] = None,
) -> Dict[str, Any]:
    """Execute a tool via the FlukeBase API asynchronously."""
    should_close = client is None
    if client is None:
        config = get_config()
        client = FlukeBaseClient(config)

    try:
        result = await client.execute_tool(tool_name, params or {})
        return result
    finally:
        if should_close:
            await client.close()


def proxy_tool(
    tool_name: str,
    params: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Execute a tool via the FlukeBase API.

    This is the main helper function for CLI commands to proxy MCP tool calls
    through the FlukeBase API.

    Args:
        tool_name: Name of the MCP tool to execute (e.g., "mem_remember")
        params: Parameters to pass to the tool

    Returns:
        Tool execution result as a dictionary
    """
    return asyncio.run(_proxy_tool_async(tool_name, params))


def format_result(result: Dict[str, Any], style: str = "default") -> None:
    """Format and print tool result to console.

    Args:
        result: Tool execution result
        style: Output style ("default", "json", "table")
    """
    if style == "json":
        import json
        console.print(json.dumps(result, indent=2, default=str))
    elif "error" in result:
        console.print(f"[red]Error:[/red] {result.get('error', 'Unknown error')}")
        if "message" in result:
            console.print(f"[dim]{result['message']}[/dim]")
    else:
        # Default: pretty print the result
        if isinstance(result, dict):
            for key, value in result.items():
                if isinstance(value, (list, dict)):
                    console.print(f"[bold]{key}:[/bold]")
                    console.print(f"  {value}")
                else:
                    console.print(f"[bold]{key}:[/bold] {value}")
        else:
            console.print(result)


def require_auth() -> bool:
    """Check if user is authenticated, show error if not."""
    config = get_config()
    if not config.flukebase.api_token:
        console.print("[red]Not authenticated.[/red]")
        console.print("Run [cyan]fbc login[/cyan] first.")
        return False
    return True
