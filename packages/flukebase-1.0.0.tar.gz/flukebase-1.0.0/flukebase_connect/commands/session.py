"""Session commands for FlukeBase Connect CLI.

Provides CLI access to session tools:
- fbc session health - Real-time health indicators
- fbc session metrics - Session metrics summary
- fbc session history - View session history
"""

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from flukebase_connect.commands import format_result, proxy_tool, require_auth

app = typer.Typer(
    name="session",
    help="Session commands - monitor session health and metrics",
    no_args_is_help=True,
)
console = Console()


@app.command()
def health(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed breakdown"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show real-time session health indicators."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("session_health", {"verbose": verbose})

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        # Overall status
        status = result.get("status", "unknown")
        status_color = {"healthy": "green", "warning": "yellow", "critical": "red"}.get(status, "white")
        console.print(f"\n[bold]Session Health:[/bold] [{status_color}]{status.upper()}[/{status_color}]")

        # Success rate
        success_rate = result.get("success_rate", 0)
        rate_color = "green" if success_rate >= 0.95 else "yellow" if success_rate >= 0.8 else "red"
        console.print(f"  Success Rate: [{rate_color}]{success_rate * 100:.1f}%[/{rate_color}]")

        # Token usage
        tokens = result.get("tokens_used", 0)
        console.print(f"  Tokens Used: {tokens:,}")

        # Active tasks
        active = result.get("active_tasks", 0)
        console.print(f"  Active Tasks: {active}")

        # Alerts
        alerts = result.get("alerts", [])
        if alerts:
            console.print("\n[yellow]Alerts:[/yellow]")
            for alert in alerts:
                console.print(f"  [yellow]![/yellow] {alert}")

        if verbose and "breakdown" in result:
            console.print("\n[bold]Breakdown:[/bold]")
            for key, value in result["breakdown"].items():
                console.print(f"  {key}: {value}")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def metrics(
    period: str = typer.Option("session", "--period", "-p", help="Period: session, today, week"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show session metrics summary."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("metrics_summary", {"period": period})

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        console.print(f"\n[bold]Metrics Summary ({period})[/bold]\n")

        table = Table(show_header=False)
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right")

        metrics_map = {
            "tool_calls": "Tool Calls",
            "success_rate": "Success Rate",
            "total_tokens": "Total Tokens",
            "input_tokens": "Input Tokens",
            "output_tokens": "Output Tokens",
            "tasks_completed": "Tasks Completed",
            "memories_created": "Memories Created",
            "session_duration": "Duration",
        }

        for key, label in metrics_map.items():
            if key in result:
                value = result[key]
                if key == "success_rate":
                    value = f"{value * 100:.1f}%"
                elif "tokens" in key:
                    value = f"{value:,}"
                elif key == "session_duration":
                    if isinstance(value, (int, float)):
                        mins = int(value / 60)
                        secs = int(value % 60)
                        value = f"{mins}m {secs}s"
                table.add_row(label, str(value))

        console.print(table)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def history(
    days: int = typer.Option(7, "--days", "-d", help="Days to look back"),
    limit: int = typer.Option(10, "--limit", "-l", help="Max sessions to show"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """View session history."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("session_history", {"days": days, "limit": limit})

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        sessions = result.get("sessions", [])
        if not sessions:
            console.print("[yellow]No sessions found.[/yellow]")
            return

        table = Table(title=f"Session History (last {days} days)")
        table.add_column("Date", style="cyan")
        table.add_column("Duration")
        table.add_column("Tool Calls")
        table.add_column("Tasks")
        table.add_column("Status")

        for session in sessions:
            duration = session.get("duration", 0)
            if isinstance(duration, (int, float)):
                mins = int(duration / 60)
                duration_str = f"{mins}m"
            else:
                duration_str = str(duration)

            status = session.get("status", "completed")
            status_color = {"completed": "green", "active": "yellow", "error": "red"}.get(status, "white")

            table.add_row(
                session.get("date", session.get("started_at", ""))[:16],
                duration_str,
                str(session.get("tool_calls", 0)),
                str(session.get("tasks_completed", 0)),
                f"[{status_color}]{status}[/{status_color}]",
            )

        console.print(table)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def score(
    session_id: Optional[str] = typer.Option(None, "--session", "-s", help="Session ID (default: current)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Calculate productivity score for session."""
    if not require_auth():
        raise typer.Exit(1)

    params = {"include_breakdown": True}
    if session_id:
        params["session_id"] = session_id

    try:
        result = proxy_tool("session_productivity_score", params)

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        score = result.get("score", 0)
        score_color = "green" if score >= 80 else "yellow" if score >= 60 else "red"

        console.print(f"\n[bold]Productivity Score:[/bold] [{score_color}]{score}/100[/{score_color}]")

        breakdown = result.get("breakdown", {})
        if breakdown:
            console.print("\n[bold]Breakdown:[/bold]")
            for category, value in breakdown.items():
                bar_len = int(value / 5)
                bar = "█" * bar_len + "░" * (20 - bar_len)
                console.print(f"  {category:15} [{bar}] {value}")

        recommendations = result.get("recommendations", [])
        if recommendations:
            console.print("\n[cyan]Recommendations:[/cyan]")
            for rec in recommendations[:3]:
                console.print(f"  • {rec}")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
