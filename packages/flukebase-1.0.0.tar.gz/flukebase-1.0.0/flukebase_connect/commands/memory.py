"""Memory commands for FlukeBase Connect CLI.

Provides CLI access to memory tools:
- fbc mem remember - Store knowledge
- fbc mem recall - Search memories
- fbc mem search - Advanced search
- fbc mem forget - Remove memory
- fbc mem sync - Sync memories
"""

from typing import List, Optional

import typer
from rich.console import Console
from rich.table import Table

from flukebase_connect.commands import format_result, proxy_tool, require_auth

app = typer.Typer(
    name="mem",
    help="Memory commands - store and recall knowledge",
    no_args_is_help=True,
)
console = Console()


@app.command()
def remember(
    content: str = typer.Argument(..., help="Content to remember"),
    memory_type: str = typer.Option("fact", "--type", "-t", help="Type: fact, convention, gotcha, decision"),
    scope: str = typer.Option("global", "--scope", "-s", help="Scope: global or project name"),
    tags: Optional[List[str]] = typer.Option(None, "--tag", help="Tags for categorization"),
):
    """Store knowledge for future sessions."""
    if not require_auth():
        raise typer.Exit(1)

    params = {
        "content": content,
        "type": memory_type,
        "scope": scope,
    }
    if tags:
        params["tags"] = tags

    try:
        result = proxy_tool("mem_remember", params)
        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)
        console.print(f"[green]Remembered:[/green] {content[:50]}...")
        if "id" in result:
            console.print(f"[dim]ID: {result['id']}[/dim]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def recall(
    query: str = typer.Argument(..., help="Search query"),
    scope: str = typer.Option("all", "--scope", "-s", help="Scope to search"),
    memory_type: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type"),
    limit: int = typer.Option(10, "--limit", "-l", help="Max results"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Search stored memories."""
    if not require_auth():
        raise typer.Exit(1)

    params = {
        "query": query,
        "scope": scope,
        "limit": limit,
    }
    if memory_type:
        params["type"] = memory_type

    try:
        result = proxy_tool("mem_recall", params)

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        memories = result.get("memories", [])
        if not memories:
            console.print("[yellow]No memories found.[/yellow]")
            return

        table = Table(title=f"Memories matching '{query}'")
        table.add_column("ID", style="dim")
        table.add_column("Type", style="cyan")
        table.add_column("Content")
        table.add_column("Scope")

        for mem in memories:
            table.add_row(
                str(mem.get("id", ""))[:8],
                mem.get("type", ""),
                mem.get("content", "")[:60] + ("..." if len(mem.get("content", "")) > 60 else ""),
                mem.get("scope", ""),
            )

        console.print(table)
        console.print(f"\n[dim]Found {len(memories)} memories[/dim]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def search(
    query: str = typer.Argument(..., help="Search query"),
    scope: str = typer.Option("all", "--scope", "-s", help="Scope to search"),
    memory_type: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type"),
    page: int = typer.Option(1, "--page", "-p", help="Page number"),
    page_size: int = typer.Option(10, "--size", help="Results per page"),
    highlight: bool = typer.Option(False, "--highlight", "-H", help="Highlight matches"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Advanced memory search with pagination."""
    if not require_auth():
        raise typer.Exit(1)

    params = {
        "query": query,
        "scope": scope,
        "page": page,
        "page_size": page_size,
        "highlight": highlight,
    }
    if memory_type:
        params["type"] = memory_type

    try:
        result = proxy_tool("mem_search", params)

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        memories = result.get("memories", result.get("results", []))
        total = result.get("total", len(memories))

        if not memories:
            console.print("[yellow]No memories found.[/yellow]")
            return

        table = Table(title=f"Search Results (Page {page})")
        table.add_column("ID", style="dim")
        table.add_column("Type", style="cyan")
        table.add_column("Content")
        table.add_column("Tags", style="dim")

        for mem in memories:
            tags = ", ".join(mem.get("tags", [])) if mem.get("tags") else "-"
            table.add_row(
                str(mem.get("id", ""))[:8],
                mem.get("type", ""),
                mem.get("content", "")[:50] + ("..." if len(mem.get("content", "")) > 50 else ""),
                tags[:20],
            )

        console.print(table)
        console.print(f"\n[dim]Showing {len(memories)} of {total} results[/dim]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def forget(
    memory_id: str = typer.Argument(..., help="Memory ID to remove"),
    scope: str = typer.Option("all", "--scope", "-s", help="Scope to search"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Remove a stored memory."""
    if not require_auth():
        raise typer.Exit(1)

    if not force:
        confirm = typer.confirm(f"Remove memory {memory_id}?")
        if not confirm:
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit(0)

    try:
        result = proxy_tool("mem_forget", {"id": memory_id, "scope": scope})
        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)
        console.print(f"[green]Memory {memory_id} removed.[/green]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def sync(
    scope: str = typer.Argument(..., help="Scope to sync"),
    direction: str = typer.Option("pull", "--direction", "-d", help="Direction: pull, push, both"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Sync memories with FlukeBase remote."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        if direction in ("pull", "both"):
            console.print(f"[cyan]Pulling memories for scope '{scope}'...[/cyan]")
            result = proxy_tool("mem_pull", {"scope": scope})
            if json_output:
                format_result(result, "json")
            elif "error" not in result:
                count = result.get("count", result.get("pulled", 0))
                console.print(f"[green]Pulled {count} memories.[/green]")

        if direction in ("push", "both"):
            console.print(f"[cyan]Pushing memories for scope '{scope}'...[/cyan]")
            result = proxy_tool("mem_push", {"scope": scope})
            if json_output:
                format_result(result, "json")
            elif "error" not in result:
                count = result.get("count", result.get("pushed", 0))
                console.print(f"[green]Pushed {count} memories.[/green]")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
