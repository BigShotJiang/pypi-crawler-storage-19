"""Environment commands for FlukeBase Connect CLI.

Provides CLI access to environment tools:
- fbc env pull - Pull .env from FlukeBase
- fbc env show - Display current env vars
- fbc env diff - Compare local vs remote
- fbc env validate - Validate required vars
"""

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from flukebase_connect.commands import format_result, proxy_tool, require_auth

app = typer.Typer(
    name="env",
    help="Environment commands - manage environment variables",
    no_args_is_help=True,
)
console = Console()


@app.command()
def pull(
    environment: str = typer.Option("development", "--env", "-e", help="Environment: development, staging, production"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Pull .env file from FlukeBase remote."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("env_pull", {"environment": environment})

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        console.print(f"[green]Pulled environment:[/green] {environment}")
        if "path" in result:
            console.print(f"[dim]Saved to: {result['path']}[/dim]")
        if "count" in result:
            console.print(f"[dim]Variables: {result['count']}[/dim]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def show(
    reveal: bool = typer.Option(False, "--reveal", "-r", help="Show actual secret values"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Display current environment variables (secrets masked by default)."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("env_show", {"reveal": reveal})

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        variables = result.get("variables", result.get("env", {}))
        if not variables:
            console.print("[yellow]No environment variables found.[/yellow]")
            return

        table = Table(title="Environment Variables")
        table.add_column("Name", style="cyan")
        table.add_column("Value")

        for name, value in sorted(variables.items()):
            # Mask sensitive values unless reveal is True
            if not reveal and any(s in name.upper() for s in ["SECRET", "KEY", "TOKEN", "PASSWORD", "API"]):
                if value and len(str(value)) > 8:
                    value = str(value)[:4] + "****" + str(value)[-4:]
                else:
                    value = "****"
            table.add_row(name, str(value))

        console.print(table)
        console.print(f"\n[dim]Total: {len(variables)} variables[/dim]")
        if not reveal:
            console.print("[dim]Use --reveal to show secret values[/dim]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def diff(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Compare local .env with FlukeBase remote."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("env_diff", {})

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        added = result.get("added", [])
        removed = result.get("removed", [])
        changed = result.get("changed", [])

        if not added and not removed and not changed:
            console.print("[green]Environment is in sync.[/green]")
            return

        if added:
            console.print("\n[green]Added (remote has, local missing):[/green]")
            for var in added:
                console.print(f"  + {var}")

        if removed:
            console.print("\n[red]Removed (local has, remote missing):[/red]")
            for var in removed:
                console.print(f"  - {var}")

        if changed:
            console.print("\n[yellow]Changed (different values):[/yellow]")
            for var in changed:
                if isinstance(var, dict):
                    console.print(f"  ~ {var.get('name', var)}")
                else:
                    console.print(f"  ~ {var}")

        console.print("\n[dim]Run 'fbc env pull' to sync from remote.[/dim]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def validate(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Check if all required environment variables are set."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("env_validate", {})

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        valid = result.get("valid", True)
        missing = result.get("missing", [])
        present = result.get("present", [])

        if valid:
            console.print("[green]All required environment variables are set.[/green]")
            if present:
                console.print(f"[dim]Checked: {len(present)} variables[/dim]")
        else:
            console.print("[red]Missing required environment variables:[/red]")
            for var in missing:
                console.print(f"  [red]✗[/red] {var}")
            if present:
                console.print(f"\n[green]Present:[/green] {len(present)} variables")
            console.print("\n[dim]Run 'fbc env pull' to sync from remote.[/dim]")
            raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
