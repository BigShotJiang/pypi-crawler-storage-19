"""Team commands for FlukeBase Connect CLI.

Provides CLI access to team/dashboard tools:
- fbc team dashboard - Unified dashboard view
- fbc team agents - Show live agents
- fbc team activity - Activity stream
"""

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from flukebase_connect.commands import format_result, proxy_tool, require_auth

app = typer.Typer(
    name="team",
    help="Team commands - view dashboard, agents, and activity",
    no_args_is_help=True,
)
console = Console()


@app.command()
def dashboard(
    include_idle: bool = typer.Option(False, "--idle", "-i", help="Include idle agents"),
    activity_limit: int = typer.Option(10, "--limit", "-l", help="Activity entries to show"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show unified dashboard with summary, agents, and activity."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("fb_dashboard", {
            "include_idle": include_idle,
            "activity_limit": activity_limit,
            "sections": ["summary", "agents", "activity"],
        })

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        # Summary section
        summary = result.get("summary", {})
        if summary:
            console.print("\n[bold cyan]Dashboard Summary[/bold cyan]")
            console.print(f"  Active Agents: {summary.get('active_agents', 0)}")
            console.print(f"  Tasks In Progress: {summary.get('tasks_in_progress', 0)}")
            console.print(f"  Tasks Completed: {summary.get('tasks_completed_today', 0)}")
            console.print(f"  Tool Calls: {summary.get('total_tool_calls', 0)}")

        # Agents section
        agents = result.get("agents", [])
        if agents:
            console.print("\n[bold cyan]Active Agents[/bold cyan]")
            table = Table(show_header=True)
            table.add_column("Agent", style="cyan")
            table.add_column("Status")
            table.add_column("Task")
            table.add_column("Duration")

            for agent in agents:
                status = agent.get("status", "unknown")
                status_color = {"active": "green", "idle": "yellow", "offline": "dim"}.get(status, "white")
                table.add_row(
                    agent.get("name", agent.get("id", ""))[:15],
                    f"[{status_color}]{status}[/{status_color}]",
                    agent.get("current_task", "-")[:20],
                    agent.get("duration", "-"),
                )
            console.print(table)
        else:
            console.print("\n[dim]No active agents[/dim]")

        # Activity section
        activity = result.get("activity", [])
        if activity:
            console.print("\n[bold cyan]Recent Activity[/bold cyan]")
            for item in activity[:activity_limit]:
                agent = item.get("agent", "?")
                tool = item.get("tool", item.get("action", "?"))
                time = item.get("time", item.get("timestamp", ""))[:8]
                console.print(f"  [{time}] {agent}: {tool}")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def agents(
    include_idle: bool = typer.Option(False, "--idle", "-i", help="Include idle agents"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max agents to show"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show currently active agents with metrics."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("dashboard_agents_live", {
            "include_idle": include_idle,
            "limit": limit,
        })

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        agents = result.get("agents", [])
        if not agents:
            console.print("[yellow]No active agents.[/yellow]")
            return

        table = Table(title="Live Agents")
        table.add_column("ID", style="cyan")
        table.add_column("Name")
        table.add_column("Status")
        table.add_column("Current Task")
        table.add_column("Tool Calls")
        table.add_column("Active For")

        for agent in agents:
            status = agent.get("status", "unknown")
            status_color = {"active": "green", "idle": "yellow", "offline": "dim"}.get(status, "white")

            table.add_row(
                str(agent.get("id", ""))[:8],
                agent.get("name", "-"),
                f"[{status_color}]{status}[/{status_color}]",
                agent.get("current_task", "-")[:25],
                str(agent.get("tool_calls", 0)),
                agent.get("active_duration", "-"),
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(agents)} agents[/dim]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def activity(
    limit: int = typer.Option(20, "--limit", "-l", help="Max activities to show"),
    agent_filter: Optional[str] = typer.Option(None, "--agent", "-a", help="Filter by agent ID"),
    tool_filter: Optional[str] = typer.Option(None, "--tool", "-t", help="Filter by tool name"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show activity stream across all agents."""
    if not require_auth():
        raise typer.Exit(1)

    params = {"limit": limit}
    if agent_filter:
        params["agent_filter"] = agent_filter
    if tool_filter:
        params["tool_filter"] = tool_filter

    try:
        result = proxy_tool("dashboard_activity_stream", params)

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        activities = result.get("activities", result.get("stream", []))
        if not activities:
            console.print("[yellow]No recent activity.[/yellow]")
            return

        table = Table(title="Activity Stream")
        table.add_column("Time", style="dim")
        table.add_column("Agent", style="cyan")
        table.add_column("Tool")
        table.add_column("Status")
        table.add_column("Duration")

        for act in activities:
            status = act.get("status", "completed")
            status_color = {"completed": "green", "running": "yellow", "error": "red"}.get(status, "white")

            time_str = act.get("timestamp", act.get("time", ""))
            if len(time_str) > 8:
                time_str = time_str[11:19]  # Extract time portion

            table.add_row(
                time_str,
                act.get("agent", act.get("agent_id", "?"))[:12],
                act.get("tool", act.get("action", "?"))[:20],
                f"[{status_color}]{status}[/{status_color}]",
                act.get("duration", "-"),
            )

        console.print(table)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def workload(
    metric: str = typer.Option("tasks", "--metric", "-m", help="Metric: tasks, tokens, calls"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show workload distribution across agents."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("orchestration_workload", {"metric": metric})

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        agents = result.get("agents", result.get("workload", []))
        if not agents:
            console.print("[yellow]No workload data available.[/yellow]")
            return

        console.print(f"\n[bold]Workload Distribution ({metric})[/bold]\n")

        max_value = max(a.get("value", a.get(metric, 0)) for a in agents) or 1

        for agent in agents:
            name = agent.get("name", agent.get("id", "?"))[:15]
            value = agent.get("value", agent.get(metric, 0))
            bar_len = int((value / max_value) * 30)
            bar = "█" * bar_len + "░" * (30 - bar_len)
            console.print(f"  {name:15} [{bar}] {value}")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
