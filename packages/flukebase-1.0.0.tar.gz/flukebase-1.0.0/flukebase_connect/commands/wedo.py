"""WeDo task commands for FlukeBase Connect CLI.

Provides CLI access to WeDo protocol tools:
- fbc wedo create - Create task
- fbc wedo list - List tasks
- fbc wedo update - Update task status
- fbc wedo progress - View progress
- fbc wedo continue - Resume work session
"""

from typing import List, Optional

import typer
from rich.console import Console
from rich.table import Table

from flukebase_connect.commands import format_result, proxy_tool, require_auth

app = typer.Typer(
    name="wedo",
    help="WeDo task commands - manage tasks and progress",
    no_args_is_help=True,
)
console = Console()


@app.command()
def create(
    task_id: str = typer.Argument(..., help="Task ID (e.g., TASK-001)"),
    description: str = typer.Argument(..., help="Task description"),
    priority: str = typer.Option("normal", "--priority", "-p", help="Priority: low, normal, high, urgent"),
    scope: str = typer.Option("global", "--scope", "-s", help="Task scope"),
    tags: Optional[List[str]] = typer.Option(None, "--tag", "-t", help="Tags"),
    dependency: str = typer.Option("AGENT_CAPABLE", "--dep", help="USER_REQUIRED or AGENT_CAPABLE"),
    blocked_by: Optional[List[str]] = typer.Option(None, "--blocked-by", "-b", help="Blocked by task IDs"),
):
    """Create a new WeDo task."""
    if not require_auth():
        raise typer.Exit(1)

    params = {
        "task_id": task_id,
        "description": description,
        "priority": priority,
        "scope": scope,
        "dependency": dependency,
    }
    if tags:
        params["tags"] = tags
    if blocked_by:
        params["blocked_by"] = blocked_by

    try:
        result = proxy_tool("wedo_create_task", params)
        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)
        console.print(f"[green]Created task:[/green] {task_id}")
        console.print(f"[dim]{description}[/dim]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("list")
def list_tasks(
    scope: str = typer.Option("global", "--scope", "-s", help="Task scope"),
    status: Optional[str] = typer.Option(None, "--status", help="Filter by status"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List WeDo tasks."""
    if not require_auth():
        raise typer.Exit(1)

    params = {"scope": scope}
    if status:
        params["status"] = status

    try:
        result = proxy_tool("wedo_list_tasks", params)

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        tasks = result.get("tasks", [])
        if not tasks:
            console.print("[yellow]No tasks found.[/yellow]")
            return

        table = Table(title="WeDo Tasks")
        table.add_column("ID", style="cyan")
        table.add_column("Status")
        table.add_column("Priority")
        table.add_column("Description")

        status_colors = {
            "pending": "white",
            "in_progress": "yellow",
            "completed": "green",
            "blocked": "red",
        }

        for task in tasks:
            status_val = task.get("status", "pending")
            color = status_colors.get(status_val, "white")
            table.add_row(
                task.get("task_id", ""),
                f"[{color}]{status_val}[/{color}]",
                task.get("priority", "normal"),
                task.get("description", "")[:50] + ("..." if len(task.get("description", "")) > 50 else ""),
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(tasks)} tasks[/dim]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def update(
    task_id: str = typer.Argument(..., help="Task ID to update"),
    status: str = typer.Argument(..., help="New status: pending, in_progress, completed, blocked"),
    note: Optional[str] = typer.Option(None, "--note", "-n", help="Synthesis note"),
):
    """Update WeDo task status."""
    if not require_auth():
        raise typer.Exit(1)

    params = {
        "task_id": task_id,
        "status": status,
    }
    if note:
        params["synthesis_note"] = note

    try:
        result = proxy_tool("wedo_update_task", params)
        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)
        console.print(f"[green]Updated:[/green] {task_id} -> {status}")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def progress(
    scope: str = typer.Option("global", "--scope", "-s", help="Task scope"),
    milestone_id: Optional[str] = typer.Option(None, "--milestone", "-m", help="Filter by milestone"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """View task progress and completion stats."""
    if not require_auth():
        raise typer.Exit(1)

    params = {"scope": scope}
    if milestone_id:
        params["milestone_id"] = milestone_id

    try:
        result = proxy_tool("wedo_progress", params)

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        # Display progress
        total = result.get("total", 0)
        completed = result.get("completed", 0)
        in_progress = result.get("in_progress", 0)
        blocked = result.get("blocked", 0)
        pending = result.get("pending", 0)

        if total > 0:
            pct = (completed / total) * 100
            bar_filled = int(pct / 5)
            bar_empty = 20 - bar_filled
            progress_bar = f"[green]{'█' * bar_filled}[/green][dim]{'░' * bar_empty}[/dim]"

            console.print(f"\n[bold]Progress:[/bold] {progress_bar} {pct:.1f}%")
            console.print(f"  [green]Completed:[/green] {completed}")
            console.print(f"  [yellow]In Progress:[/yellow] {in_progress}")
            console.print(f"  [red]Blocked:[/red] {blocked}")
            console.print(f"  [dim]Pending:[/dim] {pending}")
            console.print(f"  [bold]Total:[/bold] {total}")
        else:
            console.print("[yellow]No tasks found.[/yellow]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("continue")
def continue_work(
    scope: str = typer.Option("global", "--scope", "-s", help="Task scope"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Resume work session - sync, check handoffs, show pending tasks."""
    if not require_auth():
        raise typer.Exit(1)

    try:
        result = proxy_tool("wedo_continue", {"scope": scope})

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        console.print("[bold cyan]WeDo Session Resumed[/bold cyan]\n")

        # Show connection status
        if result.get("connected"):
            console.print("[green]✓[/green] Connected to FlukeBase")
        else:
            console.print("[yellow]![/yellow] Offline mode")

        # Show pending handoffs
        handoffs = result.get("pending_handoffs", [])
        if handoffs:
            console.print(f"\n[yellow]Pending handoffs:[/yellow] {len(handoffs)}")
            for h in handoffs[:3]:
                console.print(f"  • {h.get('id', 'Unknown')}: {h.get('context', '')[:40]}")

        # Show pending tasks
        pending = result.get("pending_tasks", [])
        if pending:
            console.print(f"\n[bold]Pending tasks:[/bold] {len(pending)}")
            for task in pending[:5]:
                console.print(f"  • [{task.get('task_id', '')}] {task.get('description', '')[:40]}")

        # Show blocked tasks
        blocked = result.get("blocked_tasks", [])
        if blocked:
            console.print(f"\n[red]Blocked tasks:[/red] {len(blocked)}")
            for task in blocked[:3]:
                console.print(f"  • [{task.get('task_id', '')}] {task.get('description', '')[:40]}")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def search(
    query: str = typer.Argument(..., help="Search query"),
    scope: str = typer.Option("global", "--scope", "-s", help="Task scope"),
    status: Optional[str] = typer.Option(None, "--status", help="Filter by status"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Search WeDo tasks."""
    if not require_auth():
        raise typer.Exit(1)

    params = {
        "query": query,
        "scope": scope,
        "limit": limit,
    }
    if status:
        params["status"] = status

    try:
        result = proxy_tool("wedo_search_tasks", params)

        if json_output:
            format_result(result, "json")
            return

        if "error" in result:
            console.print(f"[red]Error:[/red] {result.get('error')}")
            raise typer.Exit(1)

        tasks = result.get("tasks", result.get("results", []))
        if not tasks:
            console.print("[yellow]No tasks found.[/yellow]")
            return

        table = Table(title=f"Tasks matching '{query}'")
        table.add_column("ID", style="cyan")
        table.add_column("Status")
        table.add_column("Description")

        for task in tasks:
            table.add_row(
                task.get("task_id", ""),
                task.get("status", ""),
                task.get("description", "")[:50],
            )

        console.print(table)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
