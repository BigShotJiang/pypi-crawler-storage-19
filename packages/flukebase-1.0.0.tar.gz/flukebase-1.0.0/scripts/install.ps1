# FlukeBase CLI Installer for Windows
# Usage: irm https://flukebase.me/install.ps1 | iex
# Or: .\install.ps1 [-Token <token>]

param(
    [string]$Token = ""
)

$ErrorActionPreference = "Stop"

# Package name on PyPI
$PACKAGE_NAME = "flukebase"
$INSTALL_DIR = if ($env:FLUKEBASE_CONNECT_HOME) { $env:FLUKEBASE_CONNECT_HOME } else { "$env:USERPROFILE\.flukebase-connect" }

# Colors
function Write-Header {
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Blue
    Write-Host "          FlukeBase CLI Installer               " -ForegroundColor Blue
    Write-Host "================================================" -ForegroundColor Blue
    Write-Host ""
}

function Write-Step {
    param([string]$Message)
    Write-Host "-> $Message" -ForegroundColor Green
}

function Write-Warning-Message {
    param([string]$Message)
    Write-Host "!  $Message" -ForegroundColor Yellow
}

function Write-Error-Message {
    param([string]$Message)
    Write-Host "X  $Message" -ForegroundColor Red
}

function Write-Success {
    param([string]$Message)
    Write-Host "[OK] $Message" -ForegroundColor Green
}

function Write-Info {
    param([string]$Message)
    Write-Host "[i] $Message" -ForegroundColor Cyan
}

# Detect Python version manager
function Get-PythonManager {
    $manager = "global"
    $pythonCmd = $null

    # Check for pyenv-win
    if ($env:PYENV_ROOT -or $env:PYENV) {
        $pyenvPython = & pyenv which python 2>$null
        if ($pyenvPython -and (Test-Path $pyenvPython)) {
            $manager = "pyenv"
            $pythonCmd = $pyenvPython
            Write-Info "Using pyenv-win Python"
            return @{ Manager = $manager; PythonCmd = $pythonCmd }
        }
    }

    # Check for conda
    if ($env:CONDA_PREFIX) {
        $condaPython = Join-Path $env:CONDA_PREFIX "python.exe"
        if (Test-Path $condaPython) {
            $manager = "conda"
            $pythonCmd = $condaPython
            Write-Info "Using Conda environment: $(Split-Path $env:CONDA_PREFIX -Leaf)"
            return @{ Manager = $manager; PythonCmd = $pythonCmd }
        }
    }

    # Check for active virtual environment
    if ($env:VIRTUAL_ENV) {
        $venvPython = Join-Path $env:VIRTUAL_ENV "Scripts\python.exe"
        if (Test-Path $venvPython) {
            $manager = "venv"
            $pythonCmd = $venvPython
            Write-Info "Using virtual environment: $(Split-Path $env:VIRTUAL_ENV -Leaf)"
            return @{ Manager = $manager; PythonCmd = $pythonCmd }
        }
    }

    # Check for global Python
    $pythonCmd = Get-Command python -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source
    if (-not $pythonCmd) {
        $pythonCmd = Get-Command python3 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source
    }

    if ($pythonCmd) {
        Write-Info "Using system Python"
        return @{ Manager = "global"; PythonCmd = $pythonCmd }
    }

    return @{ Manager = "none"; PythonCmd = $null }
}

# Check Python version
function Test-PythonVersion {
    param([string]$PythonCmd)

    if (-not $PythonCmd) {
        return $false
    }

    try {
        $versionOutput = & $PythonCmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        if ($versionOutput) {
            $parts = $versionOutput.Split('.')
            $major = [int]$parts[0]
            $minor = [int]$parts[1]

            if ($major -ge 3 -and $minor -ge 11) {
                return $true
            }
        }
    }
    catch {
        return $false
    }

    return $false
}

# Get Python version string
function Get-PythonVersion {
    param([string]$PythonCmd)

    try {
        $version = & $PythonCmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')" 2>$null
        return $version
    }
    catch {
        return "unknown"
    }
}

# Check requirements
function Test-Requirements {
    Write-Step "Checking requirements..."

    $pythonEnv = Get-PythonManager
    $script:PythonManager = $pythonEnv.Manager
    $script:PythonCmd = $pythonEnv.PythonCmd
    $script:HasPython = $false
    $script:Installer = "none"

    if ($pythonEnv.PythonCmd) {
        $version = Get-PythonVersion -PythonCmd $pythonEnv.PythonCmd
        if (Test-PythonVersion -PythonCmd $pythonEnv.PythonCmd) {
            Write-Success "Python $version ($($pythonEnv.Manager))"
            $script:HasPython = $true
        }
        else {
            Write-Warning-Message "Python $version found (3.11+ required)"
        }
    }
    else {
        Write-Warning-Message "Python not found"
    }

    # Check for package managers
    if (Get-Command uv -ErrorAction SilentlyContinue) {
        Write-Success "uv available (recommended)"
        $script:Installer = "uv"
    }
    elseif (Get-Command pipx -ErrorAction SilentlyContinue) {
        Write-Success "pipx available"
        $script:Installer = "pipx"
    }
    elseif (Get-Command pip -ErrorAction SilentlyContinue) {
        Write-Success "pip available"
        $script:Installer = "pip"
    }
}

# Install with uv
function Install-WithUv {
    Write-Step "Installing with uv from PyPI..."
    try {
        & uv tool install $PACKAGE_NAME
        if ($LASTEXITCODE -eq 0) {
            return $true
        }
    }
    catch { }
    Write-Warning-Message "uv install failed, trying alternative..."
    return $false
}

# Install with pipx
function Install-WithPipx {
    Write-Step "Installing with pipx from PyPI..."
    try {
        & pipx install $PACKAGE_NAME
        if ($LASTEXITCODE -eq 0) {
            return $true
        }
    }
    catch { }
    Write-Warning-Message "pipx install failed, trying alternative..."
    return $false
}

# Install with pip
function Install-WithPip {
    Write-Step "Installing with pip from PyPI..."
    try {
        & pip install --user $PACKAGE_NAME
        if ($LASTEXITCODE -eq 0) {
            return $true
        }
    }
    catch { }
    Write-Warning-Message "pip install failed, trying alternative..."
    return $false
}

# Install with venv
function Install-WithVenv {
    Write-Step "Installing in virtual environment..."
    $venvDir = Join-Path $INSTALL_DIR "venv"

    try {
        # Create install directory
        if (-not (Test-Path $INSTALL_DIR)) {
            New-Item -ItemType Directory -Path $INSTALL_DIR -Force | Out-Null
        }

        # Create venv
        & $script:PythonCmd -m venv $venvDir
        if ($LASTEXITCODE -ne 0) {
            return $false
        }

        # Install package
        $venvPip = Join-Path $venvDir "Scripts\pip.exe"
        & $venvPip install $PACKAGE_NAME
        if ($LASTEXITCODE -ne 0) {
            return $false
        }

        # Create wrapper script
        $binDir = Join-Path $INSTALL_DIR "bin"
        if (-not (Test-Path $binDir)) {
            New-Item -ItemType Directory -Path $binDir -Force | Out-Null
        }

        $wrapperPath = Join-Path $binDir "fbc.cmd"
        $venvFbc = Join-Path $venvDir "Scripts\fbc.exe"
        "@echo off`n`"$venvFbc`" %*" | Out-File -FilePath $wrapperPath -Encoding ASCII

        # Add to PATH for current session
        $env:PATH = "$binDir;$env:PATH"

        Write-Success "Installed in virtual environment"
        return $true
    }
    catch {
        Write-Warning-Message "venv install failed: $_"
        return $false
    }
}

# Setup PATH
function Set-PathEnvironment {
    Write-Step "Setting up PATH..."

    $binDir = Join-Path $INSTALL_DIR "bin"

    # Check if already in PATH
    $userPath = [Environment]::GetEnvironmentVariable("PATH", "User")
    if ($userPath -notlike "*$binDir*") {
        $newPath = "$binDir;$userPath"
        [Environment]::SetEnvironmentVariable("PATH", $newPath, "User")
        Write-Success "Added to user PATH"
        Write-Warning-Message "Restart your terminal for PATH changes to take effect"
    }
}

# Run setup
function Invoke-Setup {
    Write-Step "Running initial setup..."

    if ($Token) {
        $fbcCmd = Get-Command fbc -ErrorAction SilentlyContinue
        if ($fbcCmd) {
            try {
                & fbc login --token $Token 2>$null
            }
            catch { }
        }
    }
    else {
        Write-Host ""
        Write-Host "To complete setup, run:" -ForegroundColor White
        Write-Host ""
        Write-Host "    fbc login" -ForegroundColor Cyan
        Write-Host ""
    }
}

# Print completion message
function Write-Complete {
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Green
    Write-Host "  Installation Complete!" -ForegroundColor Green
    Write-Host "================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Commands:" -ForegroundColor White
    Write-Host "  fbc login      - Authenticate with FlukeBase"
    Write-Host "  fbc doctor     - Check installation health"
    Write-Host "  fbc projects   - List your projects"
    Write-Host "  fbc tools      - List available AI tools"
    Write-Host ""
    Write-Host "Documentation: https://flukebase.me/docs" -ForegroundColor Cyan
    Write-Host ""
}

# Print failure message
function Write-Failure {
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Red
    Write-Host "  Installation Failed" -ForegroundColor Red
    Write-Host "================================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please try manual installation:" -ForegroundColor White
    Write-Host ""
    Write-Host "  # With uv (recommended)" -ForegroundColor Cyan
    Write-Host "  uv tool install flukebase"
    Write-Host ""
    Write-Host "  # With pipx" -ForegroundColor Cyan
    Write-Host "  pipx install flukebase"
    Write-Host ""
    Write-Host "  # With pip in a virtual environment" -ForegroundColor Cyan
    Write-Host "  python -m venv .venv"
    Write-Host "  .venv\Scripts\pip install flukebase"
    Write-Host ""
    Write-Host "For help: https://docs.flukebase.me/connect/troubleshooting" -ForegroundColor Cyan
    Write-Host ""
}

# Print Python help
function Write-PythonHelp {
    Write-Host ""
    Write-Host "Python 3.11+ is required but not found." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Install Python using one of these methods:" -ForegroundColor White
    Write-Host ""
    Write-Host "  # Download from python.org" -ForegroundColor Cyan
    Write-Host "  https://www.python.org/downloads/"
    Write-Host ""
    Write-Host "  # Using winget" -ForegroundColor Cyan
    Write-Host "  winget install Python.Python.3.12"
    Write-Host ""
    Write-Host "  # Using scoop" -ForegroundColor Cyan
    Write-Host "  scoop install python"
    Write-Host ""
    Write-Host "  # Using chocolatey" -ForegroundColor Cyan
    Write-Host "  choco install python"
    Write-Host ""
    Write-Host "After installing Python, run this script again." -ForegroundColor White
    Write-Host ""
}

# Main function
function Main {
    Write-Header

    Write-Host "Detected: Windows ($env:PROCESSOR_ARCHITECTURE)"

    Test-Requirements

    Write-Host ""

    # Require Python 3.11+
    if (-not $script:HasPython) {
        Write-Error-Message "Python 3.11+ is required but not found"
        Write-PythonHelp
        exit 1
    }

    # Try installation methods
    $installed = $false

    if ($script:Installer -eq "uv") {
        $installed = Install-WithUv
    }

    if (-not $installed -and $script:Installer -eq "pipx") {
        $installed = Install-WithPipx
    }

    if (-not $installed -and $script:Installer -eq "pip") {
        $installed = Install-WithPip
    }

    # Fallback to venv
    if (-not $installed) {
        $installed = Install-WithVenv
        if ($installed) {
            Set-PathEnvironment
        }
    }

    if (-not $installed) {
        Write-Failure
        exit 1
    }

    Invoke-Setup
    Write-Complete
}

# Run main
Main
