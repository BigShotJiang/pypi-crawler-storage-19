"""Tests for diagnostics module."""

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from flukebase_connect.diagnostics import (
    DiagnosticResult,
    PythonEnvironment,
    SystemDiagnostics,
    format_diagnostic_result,
    generate_support_bundle,
)


class TestDiagnosticResult:
    """Tests for DiagnosticResult dataclass."""

    def test_create_ok_result(self):
        result = DiagnosticResult(
            name="Test",
            status="ok",
            message="All good",
        )
        assert result.name == "Test"
        assert result.status == "ok"
        assert result.message == "All good"
        assert result.fix_command is None

    def test_create_error_result_with_fix(self):
        result = DiagnosticResult(
            name="Python",
            status="error",
            message="Version too old",
            fix_command="pyenv install 3.12",
        )
        assert result.status == "error"
        assert result.fix_command == "pyenv install 3.12"


class TestPythonEnvironment:
    """Tests for PythonEnvironment dataclass."""

    def test_default_values(self):
        env = PythonEnvironment()
        assert env.manager == "global"
        assert env.python_path == ""
        assert env.version == ""
        assert env.is_active_venv is False


class TestSystemDiagnostics:
    """Tests for SystemDiagnostics class."""

    def test_init(self):
        diag = SystemDiagnostics()
        assert diag.config is not None

    def test_detect_python_manager_global(self):
        """Test detection defaults to global when no manager active."""
        diag = SystemDiagnostics()
        with patch.dict(os.environ, {}, clear=True):
            env = diag.detect_python_manager()
            assert env.python_path == sys.executable
            assert env.version != ""

    def test_detect_python_manager_venv(self):
        """Test detection of virtual environment."""
        diag = SystemDiagnostics()
        with patch.dict(os.environ, {"VIRTUAL_ENV": "/path/to/venv"}):
            # Reset cached env
            diag._python_env = None
            env = diag.detect_python_manager()
            # Will detect venv if env var is set
            if os.environ.get("VIRTUAL_ENV"):
                assert env.manager == "venv"

    def test_detect_python_manager_conda(self):
        """Test detection of conda environment."""
        diag = SystemDiagnostics()
        with patch.dict(os.environ, {"CONDA_PREFIX": "/path/to/conda/env"}):
            diag._python_env = None
            env = diag.detect_python_manager()
            # Will attempt conda detection

    def test_check_python_version_passes(self):
        """Test Python version check with current Python."""
        diag = SystemDiagnostics()
        result = diag.check_python_version()
        # Should pass since we require 3.11+ and tests run on 3.11+
        assert result.status == "ok"
        assert "Python" in result.name

    def test_check_config_with_existing(self):
        """Test config check."""
        diag = SystemDiagnostics()
        result = diag.check_config()
        assert result.name == "Configuration"
        assert result.status in ("ok", "warn")

    def test_check_auth_without_token(self):
        """Test auth check without token."""
        diag = SystemDiagnostics()
        # Temporarily remove token
        original_token = diag.config.flukebase.api_token
        diag.config.flukebase.api_token = None

        result = diag.check_auth()
        assert result.status == "error"
        assert "Not authenticated" in result.message
        assert result.fix_command == "fbc login"

        # Restore
        diag.config.flukebase.api_token = original_token

    def test_check_dependencies(self):
        """Test dependency checks."""
        diag = SystemDiagnostics()
        results = diag.check_dependencies()

        # Should have results for required deps
        assert len(results) > 0

        # httpx should be available
        httpx_result = next((r for r in results if "httpx" in r.name), None)
        assert httpx_result is not None
        assert httpx_result.status == "ok"

    def test_collect_all(self):
        """Test collecting all diagnostics."""
        diag = SystemDiagnostics()
        results = diag.collect_all()

        assert len(results) > 0
        assert all(isinstance(r, DiagnosticResult) for r in results)

        # Should have Python version check
        python_results = [r for r in results if "Python" in r.name]
        assert len(python_results) > 0


class TestSupportBundle:
    """Tests for support bundle generation."""

    def test_generate_support_bundle(self):
        bundle = generate_support_bundle()

        assert "generated_at" in bundle
        assert "version" in bundle
        assert "system" in bundle
        assert "python" in bundle
        assert "config" in bundle
        assert "diagnostics" in bundle

    def test_support_bundle_system_info(self):
        bundle = generate_support_bundle()

        assert "platform" in bundle["system"]
        assert "architecture" in bundle["system"]

    def test_support_bundle_python_info(self):
        bundle = generate_support_bundle()

        assert "version" in bundle["python"]
        assert "executable" in bundle["python"]
        assert "manager" in bundle["python"]

    def test_support_bundle_diagnostics(self):
        bundle = generate_support_bundle()

        assert isinstance(bundle["diagnostics"], list)
        assert len(bundle["diagnostics"]) > 0

        for diag in bundle["diagnostics"]:
            assert "name" in diag
            assert "status" in diag
            assert "message" in diag


class TestFormatDiagnosticResult:
    """Tests for result formatting."""

    def test_format_ok_result(self):
        result = DiagnosticResult(
            name="Test",
            status="ok",
            message="All good",
        )
        formatted = format_diagnostic_result(result, use_color=False)
        assert "Test" in formatted
        assert "All good" in formatted

    def test_format_error_with_fix(self):
        result = DiagnosticResult(
            name="Test",
            status="error",
            message="Failed",
            fix_command="fix it",
        )
        formatted = format_diagnostic_result(result, use_color=False)
        assert "Failed" in formatted
        assert "fix it" in formatted
