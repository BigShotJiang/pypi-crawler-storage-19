"""Pytest configuration and fixtures."""

import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def temp_dir():
    """Create a temporary directory for tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def mock_config():
    """Create a mock config for tests."""
    config = MagicMock()
    config.home = Path.home() / ".flukebase-connect"
    config.flukebase.api_url = "https://flukebase.me/api/v1"
    config.flukebase.api_token = "fbk_test_token_12345"
    return config


@pytest.fixture
def mock_client():
    """Create a mock FlukeBase client."""
    client = MagicMock()
    client.execute_tool = MagicMock(return_value={"result": "success"})
    client.close = MagicMock()
    return client
