"""Tests for config module."""

import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from flukebase_connect.config import (
    PROJECT_MARKERS,
    PYTHON_VERSION_FILES,
    Config,
    FlukeBaseConfig,
    detect_project_root,
    detect_python_version_file,
    get_project_context,
)


class TestProjectMarkers:
    """Test project marker constants."""

    def test_markers_include_common_files(self):
        assert ".git" in PROJECT_MARKERS
        assert "pyproject.toml" in PROJECT_MARKERS
        assert "package.json" in PROJECT_MARKERS
        assert "Gemfile" in PROJECT_MARKERS

    def test_python_version_files(self):
        assert ".python-version" in PYTHON_VERSION_FILES
        assert ".tool-versions" in PYTHON_VERSION_FILES


class TestDetectProjectRoot:
    """Tests for detect_project_root function."""

    def test_detect_git_directory(self):
        """Test detection of .git directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            git_dir = Path(tmpdir) / ".git"
            git_dir.mkdir()
            subdir = Path(tmpdir) / "src" / "app"
            subdir.mkdir(parents=True)

            result = detect_project_root(subdir)
            assert result == Path(tmpdir)

    def test_detect_pyproject_toml(self):
        """Test detection of pyproject.toml."""
        with tempfile.TemporaryDirectory() as tmpdir:
            pyproject = Path(tmpdir) / "pyproject.toml"
            pyproject.write_text("[project]\nname = 'test'")
            subdir = Path(tmpdir) / "src"
            subdir.mkdir()

            result = detect_project_root(subdir)
            assert result == Path(tmpdir)

    def test_no_project_found(self):
        """Test when no project markers found."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Empty directory with no markers
            result = detect_project_root(Path(tmpdir))
            # May return None or find a parent project
            # Just ensure it doesn't crash

    def test_respects_home_boundary(self):
        """Test that search stops at home directory."""
        # This is hard to test directly, but we can verify the function runs
        result = detect_project_root(Path.home())
        # Should return None or the home dir if it has markers


class TestDetectPythonVersionFile:
    """Tests for detect_python_version_file function."""

    def test_detect_python_version_file(self):
        """Test detection of .python-version file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            version_file = Path(tmpdir) / ".python-version"
            version_file.write_text("3.12.0")
            subdir = Path(tmpdir) / "src"
            subdir.mkdir()

            result = detect_python_version_file(subdir)
            assert result == version_file

    def test_detect_tool_versions_with_python(self):
        """Test detection of .tool-versions with python entry."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool_versions = Path(tmpdir) / ".tool-versions"
            tool_versions.write_text("python 3.12.0\nnodejs 20.0.0")
            subdir = Path(tmpdir) / "src"
            subdir.mkdir()

            result = detect_python_version_file(subdir)
            assert result == tool_versions

    def test_ignore_tool_versions_without_python(self):
        """Test that .tool-versions without python is ignored."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool_versions = Path(tmpdir) / ".tool-versions"
            tool_versions.write_text("nodejs 20.0.0\nruby 3.2.0")
            subdir = Path(tmpdir) / "src"
            subdir.mkdir()

            result = detect_python_version_file(subdir)
            # Should not find the tool-versions file
            assert result is None or result != tool_versions


class TestGetProjectContext:
    """Tests for get_project_context function."""

    def test_context_with_git_project(self):
        """Test context detection for git project."""
        with tempfile.TemporaryDirectory() as tmpdir:
            git_dir = Path(tmpdir) / ".git"
            git_dir.mkdir()

            context = get_project_context(Path(tmpdir))
            assert "project_root" in context
            assert "project_name" in context
            assert context["project_name"] == Path(tmpdir).name

    def test_context_with_pyproject(self):
        """Test framework hint for Python project."""
        with tempfile.TemporaryDirectory() as tmpdir:
            git_dir = Path(tmpdir) / ".git"
            git_dir.mkdir()
            pyproject = Path(tmpdir) / "pyproject.toml"
            pyproject.write_text("[project]\nname = 'test'")

            context = get_project_context(Path(tmpdir))
            assert context.get("framework_hint") == "python"

    def test_context_with_package_json(self):
        """Test framework hint for Node project."""
        with tempfile.TemporaryDirectory() as tmpdir:
            git_dir = Path(tmpdir) / ".git"
            git_dir.mkdir()
            package_json = Path(tmpdir) / "package.json"
            package_json.write_text('{"name": "test"}')

            context = get_project_context(Path(tmpdir))
            assert context.get("framework_hint") == "node"

    def test_context_with_virtual_env(self):
        """Test context includes virtual env info."""
        with patch.dict(os.environ, {"VIRTUAL_ENV": "/path/to/venv"}):
            context = get_project_context()
            assert context.get("virtual_env") == "/path/to/venv"

    def test_context_with_conda(self):
        """Test context includes conda env info."""
        with patch.dict(os.environ, {"CONDA_PREFIX": "/path/to/conda"}):
            context = get_project_context()
            assert context.get("conda_env") == "/path/to/conda"


class TestConfig:
    """Tests for Config class."""

    def test_config_creates_home_dir(self):
        """Test that config creates home directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            home = Path(tmpdir) / ".flukebase-connect"
            config = Config(home=home)
            assert home.exists()

    def test_config_save_and_load(self):
        """Test saving and loading config."""
        with tempfile.TemporaryDirectory() as tmpdir:
            home = Path(tmpdir) / ".flukebase-connect"
            config = Config(home=home)
            config.flukebase.api_token = "test_token"
            config.save()

            config_file = home / "config.toml"
            assert config_file.exists()

            content = config_file.read_text()
            assert "test_token" in content


class TestFlukeBaseConfig:
    """Tests for FlukeBaseConfig class."""

    def test_default_api_url(self):
        """Test default API URL detection."""
        config = FlukeBaseConfig()
        # Should be either dev or prod URL
        assert "flukebase" in config.api_url or "localhost" in config.api_url

    def test_no_default_token(self):
        """Test that token is None by default."""
        config = FlukeBaseConfig()
        assert config.api_token is None
