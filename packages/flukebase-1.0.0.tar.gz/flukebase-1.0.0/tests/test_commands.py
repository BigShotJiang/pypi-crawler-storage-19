"""Tests for commands module."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from flukebase_connect.commands import (
    format_result,
    proxy_tool,
    require_auth,
)


class TestRequireAuth:
    """Tests for require_auth function."""

    def test_returns_false_without_token(self):
        """Test that require_auth returns False when no token."""
        with patch("flukebase_connect.commands.get_config") as mock_config:
            mock_config.return_value.flukebase.api_token = None
            result = require_auth()
            assert result is False

    def test_returns_true_with_token(self):
        """Test that require_auth returns True when token present."""
        with patch("flukebase_connect.commands.get_config") as mock_config:
            mock_config.return_value.flukebase.api_token = "fbk_test_token"
            result = require_auth()
            assert result is True


class TestFormatResult:
    """Tests for format_result function."""

    def test_format_json(self):
        """Test JSON formatting."""
        result = {"key": "value", "number": 42}
        # This just prints, so we verify it doesn't crash
        with patch("flukebase_connect.commands.console") as mock_console:
            format_result(result, style="json")
            mock_console.print.assert_called()

    def test_format_error_result(self):
        """Test formatting error result."""
        result = {"error": "Something went wrong", "message": "Details"}
        with patch("flukebase_connect.commands.console") as mock_console:
            format_result(result)
            # Should print error message
            mock_console.print.assert_called()

    def test_format_dict_result(self):
        """Test formatting dictionary result."""
        result = {"status": "ok", "count": 5}
        with patch("flukebase_connect.commands.console") as mock_console:
            format_result(result)
            mock_console.print.assert_called()


class TestProxyTool:
    """Tests for proxy_tool function."""

    def test_proxy_tool_import(self):
        """Test that proxy_tool can be imported."""
        from flukebase_connect.commands import proxy_tool
        assert callable(proxy_tool)

    def test_proxy_tool_async_import(self):
        """Test that _proxy_tool_async can be imported."""
        from flukebase_connect.commands import _proxy_tool_async
        assert callable(_proxy_tool_async)


class TestMemoryCommands:
    """Tests for memory command module."""

    def test_import_memory_commands(self):
        """Test that memory commands can be imported."""
        from flukebase_connect.commands.memory import app, remember, recall, search, forget, sync
        assert app is not None

    def test_memory_functions_callable(self):
        """Test that memory functions are callable."""
        from flukebase_connect.commands.memory import remember, recall, search, forget, sync
        assert callable(remember)
        assert callable(recall)
        assert callable(search)
        assert callable(forget)
        assert callable(sync)


class TestWedoCommands:
    """Tests for wedo command module."""

    def test_import_wedo_commands(self):
        """Test that wedo commands can be imported."""
        from flukebase_connect.commands.wedo import app, create, list_tasks, update, progress
        assert app is not None

    def test_wedo_functions_callable(self):
        """Test that wedo functions are callable."""
        from flukebase_connect.commands.wedo import create, list_tasks, update, progress, continue_work
        assert callable(create)
        assert callable(list_tasks)
        assert callable(update)
        assert callable(progress)
        assert callable(continue_work)


class TestEnvCommands:
    """Tests for env command module."""

    def test_import_env_commands(self):
        """Test that env commands can be imported."""
        from flukebase_connect.commands.env import app, pull, show, diff, validate
        assert app is not None

    def test_env_functions_callable(self):
        """Test that env functions are callable."""
        from flukebase_connect.commands.env import pull, show, diff, validate
        assert callable(pull)
        assert callable(show)
        assert callable(diff)
        assert callable(validate)


class TestSessionCommands:
    """Tests for session command module."""

    def test_import_session_commands(self):
        """Test that session commands can be imported."""
        from flukebase_connect.commands.session import app, health, metrics, history, score
        assert app is not None

    def test_session_functions_callable(self):
        """Test that session functions are callable."""
        from flukebase_connect.commands.session import health, metrics, history, score
        assert callable(health)
        assert callable(metrics)
        assert callable(history)
        assert callable(score)


class TestTeamCommands:
    """Tests for team command module."""

    def test_import_team_commands(self):
        """Test that team commands can be imported."""
        from flukebase_connect.commands.team import app, dashboard, agents, activity, workload
        assert app is not None

    def test_team_functions_callable(self):
        """Test that team functions are callable."""
        from flukebase_connect.commands.team import dashboard, agents, activity, workload
        assert callable(dashboard)
        assert callable(agents)
        assert callable(activity)
        assert callable(workload)
