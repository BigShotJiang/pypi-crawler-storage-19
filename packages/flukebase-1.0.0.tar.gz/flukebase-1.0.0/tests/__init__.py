"""Tests for flukebase_connect client."""
