"""Tests for exceptions module."""

import pytest

from flukebase_connect.core.exceptions import (
    ApiConnectionError,
    AuthError,
    ConfigurationError,
    DependencyError,
    FlukeBaseError,
    NotFoundError,
    OfflineError,
    ProjectNotFoundError,
    PythonVersionError,
    RateLimitError,
    Solution,
    ToolExecutionError,
)


class TestSolution:
    """Tests for Solution dataclass."""

    def test_create_solution(self):
        sol = Solution(
            description="Run this command",
            command="fbc doctor",
            priority=3,
        )
        assert sol.description == "Run this command"
        assert sol.command == "fbc doctor"
        assert sol.priority == 3

    def test_solution_defaults(self):
        sol = Solution(description="Just a description")
        assert sol.command is None
        assert sol.priority == 0


class TestFlukeBaseError:
    """Tests for base FlukeBaseError."""

    def test_create_error(self):
        err = FlukeBaseError("Something went wrong")
        assert "Something went wrong" in str(err)
        assert err.code == "ERR_000"

    def test_error_with_code(self):
        err = FlukeBaseError("Error", code="CUSTOM_001")
        assert err.code == "CUSTOM_001"

    def test_error_with_cause(self):
        err = FlukeBaseError("Error", cause="Network failure")
        assert err.cause == "Network failure"

    def test_error_with_solutions(self):
        solutions = [Solution("Try again", priority=1)]
        err = FlukeBaseError("Error", solutions=solutions)
        assert len(err.solutions) == 1

    def test_format_error(self):
        err = FlukeBaseError(
            "Test error",
            code="TEST_001",
            cause="Something happened",
        )
        formatted = err.format(color=False)
        assert "TEST_001" in formatted
        assert "Test error" in formatted
        assert "Something happened" in formatted

    def test_docs_url(self):
        err = FlukeBaseError("Error", docs_path="guide/errors")
        assert err.docs_url == "https://flukebase.me/docs/guide/errors"


class TestAuthError:
    """Tests for AuthError."""

    def test_default_message(self):
        err = AuthError()
        assert "Authentication failed" in str(err)
        assert err.code == "AUTH_001"

    def test_has_solutions(self):
        err = AuthError()
        assert len(err.solutions) > 0
        commands = [s.command for s in err.solutions if s.command]
        assert "fbc login" in commands


class TestApiConnectionError:
    """Tests for ApiConnectionError."""

    def test_default_message(self):
        err = ApiConnectionError()
        assert "connect" in str(err).lower()
        assert err.code == "CONN_001"


class TestNotFoundError:
    """Tests for NotFoundError."""

    def test_create(self):
        err = NotFoundError("Resource not found")
        assert err.code == "NOT_FOUND_001"


class TestToolExecutionError:
    """Tests for ToolExecutionError."""

    def test_with_tool_name(self):
        err = ToolExecutionError("mem_recall", "Tool failed")
        assert "mem_recall" in str(err)
        assert err.tool_name == "mem_recall"
        assert err.code == "TOOL_001"

    def test_has_solutions(self):
        err = ToolExecutionError("test_tool", "Failed")
        assert len(err.solutions) > 0


class TestPythonVersionError:
    """Tests for PythonVersionError."""

    def test_version_info(self):
        err = PythonVersionError("3.9.0", "3.11+")
        assert "3.9.0" in str(err)
        assert "3.11+" in str(err)
        assert err.code == "PY_001"
        assert err.current_version == "3.9.0"
        assert err.required_version == "3.11+"

    def test_has_solutions(self):
        err = PythonVersionError("3.9.0")
        assert len(err.solutions) > 0


class TestDependencyError:
    """Tests for DependencyError."""

    def test_package_name(self):
        err = DependencyError("httpx")
        assert "httpx" in str(err)
        assert err.package == "httpx"
        assert err.code == "DEP_001"

    def test_fix_command_includes_package(self):
        err = DependencyError("missing-package")
        commands = [s.command for s in err.solutions if s.command]
        assert any("missing-package" in cmd for cmd in commands)


class TestConfigurationError:
    """Tests for ConfigurationError."""

    def test_default_message(self):
        err = ConfigurationError()
        assert err.code == "CFG_001"

    def test_with_config_key(self):
        err = ConfigurationError("Invalid value", config_key="api_url")
        assert "api_url" in str(err)
        assert err.config_key == "api_url"


class TestOfflineError:
    """Tests for OfflineError."""

    def test_default_message(self):
        err = OfflineError()
        assert "network" in str(err).lower() or "connectivity" in str(err).lower()
        assert err.code == "OFFLINE_001"


class TestProjectNotFoundError:
    """Tests for ProjectNotFoundError."""

    def test_default_message(self):
        err = ProjectNotFoundError()
        assert "project" in str(err).lower()
        assert err.code == "PROJ_001"

    def test_has_solutions(self):
        err = ProjectNotFoundError()
        assert len(err.solutions) > 0


class TestRateLimitError:
    """Tests for RateLimitError."""

    def test_without_retry_after(self):
        err = RateLimitError()
        assert "rate limit" in str(err).lower()
        assert err.code == "RATE_001"

    def test_with_retry_after(self):
        err = RateLimitError(retry_after=60)
        assert "60" in str(err)
        assert err.retry_after == 60
