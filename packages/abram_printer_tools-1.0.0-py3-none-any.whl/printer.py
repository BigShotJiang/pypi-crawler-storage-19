import time
def typewriter(text, speed=0.03):
    for char in text:
        print(char, end="", flush=True)
        time.sleep(speed)
def boxed(text):
    lenght=len(text)+2
    print("+" + "-"*lenght + "+")
    print("| " + text + " |")
    print("+" + "-"*lenght + "+")