"""
Tests for skene-growth.
"""
