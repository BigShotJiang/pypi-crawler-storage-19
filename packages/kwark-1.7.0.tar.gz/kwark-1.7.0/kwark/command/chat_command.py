from kwark.command import KwarkCommand


class ChatCommand(KwarkCommand):
    """Simple chat command to interact with AI.
    Takes input text and returns an AI response."""

    name = 'chat'

    @KwarkCommand.wrap
    def execute(self):
        initial_message = self.app.stream.text.strip() or None

        self.ai_service.chat(self.app.ui, initial_message=initial_message)

        self.status = "Chat session completed"
