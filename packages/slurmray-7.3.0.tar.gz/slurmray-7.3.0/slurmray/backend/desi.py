import os
import sys
import time
import re
import paramiko
import subprocess
import dill
import random
from typing import Any

from slurmray.backend.remote import RemoteMixin
from slurmray.utils import SSHTunnel, DependencyManager


class DesiBackend(RemoteMixin):
    """Backend for Desi server (ISIPOL09) execution"""

    # Constants for Desi environment
    SERVER_BASE_DIR = "/home/users/{username}/slurmray-server"  # Need to check where to write on Desi. assuming home.
    PYTHON_CMD = "/usr/bin/python3"  # To be verified

    def __init__(self, launcher):
        super().__init__(launcher)
        self.tunnel = None
        self._log_cursors = {}  # Store cursor position for each job_id

    def run(self, cancel_old_jobs: bool = True, wait: bool = True) -> Any:
        """Run the job on Desi"""
        self.logger.info("🔌 Connecting to Desi server...")
        self._connect()
        self.logger.info("✅ Connected successfully")

        # Setup pyenv Python version if available
        self.pyenv_python_cmd = None
        if hasattr(self.launcher, "local_python_version"):
            self.pyenv_python_cmd = self._setup_pyenv_python(
                self.ssh_client, self.launcher.local_python_version
            )

        # Check Python version compatibility (with pyenv if available)
        is_compatible = self._check_python_version_compatibility(
            self.ssh_client, self.pyenv_python_cmd
        )
        self.python_version_compatible = is_compatible

        sftp = self.get_sftp()

        # Base directory on server (organized by project name)
        base_dir = f"/home/{self.launcher.server_username}/slurmray-server/{self.launcher.project_name}"

        # --- LOCK MECHANISM START ---
        # Acquire lock to prevent race conditions during sync
        lock_dir = f"/home/{self.launcher.server_username}/slurmray-server/.{self.launcher.project_name}.lock"
        self.logger.info("Acquiring sync lock...")
        lock_acquired = False
        start_lock_time = time.time()
        timeout = 600 # 10 minutes timeout
        
        while not lock_acquired:
            try:
                # mkdir is atomic on POSIX
                self.ssh_client.exec_command(f"mkdir -p /home/{self.launcher.server_username}/slurmray-server") # Ensure parent exists
                stdin, stdout, stderr = self.ssh_client.exec_command(f"mkdir {lock_dir}")
                exit_status = stdout.channel.recv_exit_status()
                if exit_status == 0:
                    lock_acquired = True
                else:
                    # Check timeout
                    if time.time() - start_lock_time > timeout:
                        self.logger.warning("Timeout waiting for lock. Breaking lock (dangerous if another process is active).")
                        self.ssh_client.exec_command(f"rm -rf {lock_dir}")
                    time.sleep(2)
            except Exception as e:
                self.logger.warning(f"Error acquiring lock: {e}")
                time.sleep(2)
        
        self.logger.info("Sync lock acquired.")

        try:
            # Generate requirements first to check venv hash
            self._generate_requirements()

            # Add slurmray (unpinned for now to match legacy behavior, but could be pinned)
            req_file = f"{self.launcher.project_path}/requirements.txt"
            with open(req_file, "r") as f:
                content = f.read()
            if "slurmray" not in content.lower():
                with open(req_file, "a") as f:
                    f.write("slurmray\n")

            # Check if venv can be reused based on requirements hash
            dep_manager = DependencyManager(self.launcher.project_path, self.logger)
            req_file = os.path.join(self.launcher.project_path, "requirements.txt")

            should_recreate_venv = True
            if self.launcher.force_reinstall_venv:
                # Force recreation: remove venv if it exists
                self.logger.info("Force reinstall enabled: removing existing virtualenv...")
                self.ssh_client.exec_command(f"rm -rf {base_dir}/venv")
                should_recreate_venv = True
            elif os.path.exists(req_file):
                with open(req_file, "r") as f:
                    req_lines = f.readlines()
                # Check remote hash (if venv exists on remote)
                remote_hash_file = f"{base_dir}/.slogs/venv_hash.txt"
                stdin, stdout, stderr = self.ssh_client.exec_command(
                    f"test -f {remote_hash_file} && cat {remote_hash_file} || echo ''"
                )
                remote_hash = stdout.read().decode("utf-8").strip()
                current_hash = dep_manager.compute_requirements_hash(req_lines)

                if remote_hash and remote_hash == current_hash:
                    # Hash matches, check if venv exists
                    stdin, stdout, stderr = self.ssh_client.exec_command(
                        f"test -d {base_dir}/venv && echo exists || echo missing"
                    )
                    venv_exists = stdout.read().decode("utf-8").strip() == "exists"
                    if venv_exists:
                        should_recreate_venv = False

            # --- FORCE REINSTALL PROJECT LOGIC ---
            if self.launcher.force_reinstall_project:
                self.logger.warning(f"Force reinstall project enabled: cleaning {base_dir} (preserving venv if possible)...")
                cmd = f"find {base_dir} -mindepth 1 -maxdepth 1 ! -name 'venv' -exec rm -rf {{}} +"
                self.ssh_client.exec_command(cmd)
                self.ssh_client.exec_command(f"rm -f {base_dir}/.slogs/.remote_file_hashes.json")

            # Smart cleanup: preserve venv if hash matches
            self.ssh_client.exec_command(f"mkdir -p {base_dir}/.slogs/server")
            if should_recreate_venv:
                 # Clean server logs only (venv will be recreated by script if needed)
                self.ssh_client.exec_command(f"rm -rf {base_dir}/.slogs/server/*")
                if self.launcher.force_reinstall_venv:
                    self.ssh_client.exec_command(f"touch {base_dir}/.force_reinstall")
            else:
                 # Clean server logs only, preserve venv
                 # Unlike previous Desi logic which cleaned everything, we now match Slurm logic: prevent deletion of project files.
                self.ssh_client.exec_command(f"rm -rf {base_dir}/.slogs/server/*")
                self.ssh_client.exec_command(f"rm -f {base_dir}/.force_reinstall")

            # Generate Python script (spython.py) that will run on Desi
            self._write_python_script(base_dir)

            # Optimize requirements
            venv_cmd = (
                f"source {base_dir}/venv/bin/activate &&"
                if not should_recreate_venv
                else ""
            )
            req_file_to_push = self._optimize_requirements(self.ssh_client, venv_cmd)

            # Prepare files to push
            # Include generated files in list
            files_to_sync = self.launcher.files.copy()
            
            # generated files handling
            generated_files = []
            for f in os.listdir(self.launcher.project_path):
                if (f.endswith(".py") or f.endswith(".pkl") or f.endswith(".txt")) and f != "requirements.txt":
                       generated_files.append(f)

            # Fail-fast: check func_name.txt
            func_name_txt = "func_name.txt"
            func_name_path = os.path.join(self.launcher.project_path, func_name_txt)
            if not os.path.exists(func_name_path):
                error_msg = f"❌ ERROR: func_name.txt not found locally at {func_name_path}."
                self.logger.error(error_msg)
                raise FileNotFoundError(error_msg)
            
            # Add generated files to sync list doesn't work easily because they are in project_path, not pwd_path
            # We will push them manually as before for now, BUT INSIDE THE LOCK.

            # Filter valid files from launcher.files
            valid_files = []
            for file in self.launcher.files:
                 if (not file or file == "." or file == ".." or file.startswith("./") or file.startswith("../")):
                      continue
                 valid_files.append(file)

            # Sync local files (incremental)
            if valid_files:
                self._sync_local_files_incremental(sftp, base_dir, valid_files)

            # Push generated/critical files (always overwrite)
            if generated_files:
                self.logger.info(f"📤 Uploading {len(generated_files)} generated file(s) to server...")
                for file in generated_files:
                    sftp.put(
                        os.path.join(self.launcher.project_path, file), f"{base_dir}/{file}"
                    )

            # Verify func_name.txt uploaded
            stdin, stdout, stderr = self.ssh_client.exec_command(
                f"test -f {base_dir}/{func_name_txt} && echo 'exists' || echo 'missing'"
            )
            stdout.channel.recv_exit_status()
            if "missing" in stdout.read().decode("utf-8").strip():
                raise FileNotFoundError(f"func_name.txt upload failed.")

            # Push requirements
            if os.path.exists(req_file_to_push):
                sftp.put(req_file_to_push, f"{base_dir}/requirements.txt")
            else:
                 try: sftp.remove(f"{base_dir}/requirements.txt")
                 except IOError: pass

            # Store venv hash
            if os.path.exists(req_file):
                with open(req_file, "r") as f:
                    req_lines = f.readlines()
                current_hash = dep_manager.compute_requirements_hash(req_lines)
                self.ssh_client.exec_command(f"mkdir -p {base_dir}/.slogs")
                self.ssh_client.exec_command(f"echo '{current_hash}' > {base_dir}/.slogs/venv_hash.txt")
                dep_manager.store_venv_hash(current_hash)

            # Update retention
            self._update_retention_timestamp(
                self.ssh_client, base_dir, self.launcher.retention_days
            )

            # Create runner script
            runner_script = "run_desi.sh"
            self._write_runner_script(runner_script, base_dir)
            sftp.put(
                os.path.join(self.launcher.project_path, runner_script),
                f"{base_dir}/{runner_script}",
            )
            self.ssh_client.exec_command(f"chmod +x {base_dir}/{runner_script}")

            # Desi Wrapper
            desi_wrapper_script = "desi_wrapper.py"
            self._write_desi_wrapper(desi_wrapper_script)
            sftp.put(
                os.path.join(self.launcher.project_path, desi_wrapper_script),
                f"{base_dir}/{desi_wrapper_script}",
            )
        
        finally:
            # RELEASE LOCK
            try:
                self.ssh_client.exec_command(f"rm -rf {lock_dir}")
                self.logger.info("Sync lock released.")
            except Exception as e:
                self.logger.warning(f"Failed to release lock: {e}")

        # Run the script
        self.logger.info("🚀 Starting job execution...")
        
        # Determine command based on wait mode
        if wait:
            cmd = f"cd {base_dir} && ./run_desi.sh"
            stdin, stdout, stderr = self.ssh_client.exec_command(cmd, get_pty=True)
            
            # Stream output
            ray_started = False

            # Read output line by line
            while True:
                line = stdout.readline()
                if not line:
                    break

                # Filter out noisy messages and format nicely
                line_stripped = line.strip()
                if not line_stripped:
                    continue

                # Skip pkill errors (already handled silently)
                if "pkill:" in line_stripped:
                    continue

                # Detect Ray startup
                if (
                    "Started a local Ray instance" in line_stripped
                    or "View the dashboard at" in line_stripped
                ) and not ray_started:
                    ray_started = True
                    # Extract dashboard URL if present
                    if "http://" in line_stripped:
                        # Extract URL from line
                        import re

                        url_match = re.search(r"http://[^\s]+", line_stripped)
                        if url_match:
                            dashboard_url = url_match.group(0)
                            self.logger.info(f"📊 Ray dashboard started at {dashboard_url}")

                    # Start SSH Tunnel
                    if not self.tunnel:
                        try:
                            self.tunnel = SSHTunnel(
                                ssh_host=self.launcher.server_ssh,
                                ssh_username=self.launcher.server_username,
                                ssh_password=self.launcher.server_password,
                                remote_host="127.0.0.1",
                                local_port=0, # Dynamic port to avoid contention
                                remote_port=8265,
                                logger=self.logger,
                            )
                            self.tunnel.__enter__()
                            self.logger.info(
                                f"🌐 Dashboard accessible locally at http://localhost:{self.tunnel.local_port}"
                            )
                        except Exception as e:
                            self.logger.warning(f"⚠️  Could not establish SSH tunnel: {e}")
                            self.tunnel = None
                    continue

                # Print all output (user's print statements and important messages)
                # Filter out only very noisy system messages
                if not any(noise in line_stripped for noise in ["pkill:", "WARNING:"]):
                    # Always print user output
                    print(line, end="", flush=True)

                    # Log important system messages with emojis
                    if (
                        "Error" in line_stripped
                        or "Traceback" in line_stripped
                        or "Exception" in line_stripped
                    ):
                        self.logger.error(f"❌ {line_stripped}")
                    elif "Lock acquired" in line_stripped:
                        self.logger.info(f"🔒 {line_stripped}")
                    elif "Starting Payload" in line_stripped:
                        self.logger.info(f"🚀 {line_stripped}")
                    elif "Loaded function" in line_stripped:
                        self.logger.info(f"📦 {line_stripped}")
                    elif "Job started" in line_stripped or "Sleeping" in line_stripped:
                        self.logger.info(f"▶️  {line_stripped}")
                    elif "Result written" in line_stripped:
                        self.logger.info(f"💾 {line_stripped}")
                    elif (
                        "Releasing lock" in line_stripped
                        or "Lock released" in line_stripped
                    ):
                        self.logger.info(f"🔓 {line_stripped}")

            # Read any remaining stderr
            stderr_output = stderr.read().decode("utf-8")
            if stderr_output.strip():
                self.logger.error(f"Script errors:\n{stderr_output}")
                print(stderr_output, end="")

            exit_status = stdout.channel.recv_exit_status()

            # Check if script failed - fail-fast immediately
            if exit_status != 0:
                # Collect error information
                error_msg = f"Job script exited with non-zero status: {exit_status}"
                if stderr_output.strip():
                    error_msg += f"\nScript errors:\n{stderr_output}"

                # Log the error
                self.logger.error(error_msg)

                # Close tunnel if open
                if self.tunnel:
                    try:
                        self.tunnel.__exit__(None, None, None)
                    except Exception:
                        pass
                    self.tunnel = None

                # Raise exception immediately (fail-fast)
                raise RuntimeError(error_msg)

            # Wait a bit for file system to sync
            # Keep tunnel open during job execution - it will be closed at the end of run()
            time.sleep(2)

            # Wait for result file to be created on remote (with timeout)
            self.logger.info("⏳ Waiting for job completion...")
            max_wait = 300  # 5 minutes max
            wait_start = time.time()
            result_available = False

            while time.time() - wait_start < max_wait:
                try:
                    # Check if result.pkl exists on remote
                    stdin, stdout, stderr = self.ssh_client.exec_command(
                        f"test -f {base_dir}/result.pkl && echo exists || echo missing"
                    )
                    stdout.channel.recv_exit_status()  # Wait for command to complete
                    output = stdout.read().decode("utf-8").strip()
                    if output == "exists":
                        result_available = True
                        break
                except Exception as e:
                    self.logger.debug(f"Error checking for result file: {e}")
                
                time.sleep(5)

            if not result_available:
                self.logger.error("❌ Timeout waiting for result file.")
                raise TimeoutError("Timeout waiting for result file on Desi.")

            # Download result
            self.logger.info("📥 Downloading result...")
            local_result_path = os.path.join(self.launcher.project_path, "result.pkl")
            sftp.get(f"{base_dir}/result.pkl", local_result_path)

            # Load result
            with open(local_result_path, "rb") as f:
                result = dill.load(f)

            self.logger.info("✅ Result received!")

            # Close tunnel now that job is complete
            if self.tunnel:
                self.tunnel.__exit__(None, None, None)
                self.tunnel = None

            return result

        else:
             # Async mode: Run with nohup and redirect to log file
             log_file = "desi.log"
             cmd = f"cd {base_dir} && nohup ./run_desi.sh > {log_file} 2>&1 & echo $!"
             stdin, stdout, stderr = self.ssh_client.exec_command(cmd)
             pid = stdout.read().decode("utf-8").strip()
             self.logger.info(f"Async mode: Job started with PID {pid}. Log file: {base_dir}/{log_file}")
             
             return pid

    def _cleanup_local_temp_files(self):
        """Clean up local temporary files after successful execution"""
        temp_files = [
            "func_source.py",
            "func_name.txt",
            "func.pkl",
            "args.pkl",
            "result.pkl",
            "spython.py",
            "run_desi.sh",
            "desi_wrapper.py",
            "requirements_to_install.txt",
        ]

        for temp_file in temp_files:
            file_path = os.path.join(self.launcher.project_path, temp_file)
            if os.path.exists(file_path):
                os.remove(file_path)
                self.logger.debug(f"Removed temporary file: {temp_file}")

    def cancel(self, job_id: str):
        """Cancel job on Desi"""
        self.logger.info(f"Canceling Desi job {job_id}...")
        self._connect()
        try:
             # Try to kill the process and process group
             # job_id is PID from nohup
             # Use negative PID to kill process group
             self.ssh_client.exec_command(f"kill -TERM -{job_id}")
             self.logger.info(f"Sent kill signal to process group {job_id}")
             
             # Also kill the specific PID just in case
             self.ssh_client.exec_command(f"kill -9 {job_id}")
        except Exception as e:
             self.logger.warning(f"Failed to cancel Desi job: {e}")

    def get_result(self, job_id: str) -> Any:
        """Get result for Desi execution"""
        self._connect()
        base_dir = f"/home/{self.launcher.server_username}/slurmray-server/{self.launcher.project_name}"
        local_path = os.path.join(self.launcher.project_path, "result.pkl")
        
        try:
            sftp = self.get_sftp()
            sftp.stat(f"{base_dir}/result.pkl")
            sftp.get(f"{base_dir}/result.pkl", local_path)
            with open(local_path, "rb") as f:
                return dill.load(f)
        except Exception:
            return None

    def get_logs(self, job_id: str) -> Any:
        """Get logs for Desi execution"""
        self._connect()
        base_dir = f"/home/{self.launcher.server_username}/slurmray-server/{self.launcher.project_name}"
        log_file = "desi.log" # Assumed from async execution
        remote_log = f"{base_dir}/{log_file}"
        # print(f"DEBUG: Trying to access log at {remote_log}")
        
        try:
            sftp = self.get_sftp()
            
            # Use seek if we have a cursor
            cursor = self._log_cursors.get(job_id, 0)
            
            try:
                with sftp.file(remote_log, 'r') as f:
                    # Move to last position
                    f.seek(cursor)
                    
                    # Read new content
                    new_content = f.read()
                    
                    if new_content:
                        # Update cursor
                        self._log_cursors[job_id] = f.tell()
                        
                        # Yield lines
                        if isinstance(new_content, bytes):
                            new_content = new_content.decode('utf-8')
                            
                        # Split by lines, but careful with partial lines?
                        # For simplicity, we just yield the chunk or split lines.
                        # RayLauncher expects lines.
                        for line in new_content.splitlines(keepends=True):
                            yield line
            except FileNotFoundError:
                 yield "Log file not found (yet)."
            except IOError:
                 pass
                 
        except Exception as e:
             yield f"Error reading remote log: {e}"

    def _write_python_script(self, base_dir):
        """Write the python script (spython.py) that will be executed by the job"""
        self.logger.info("Writing python script...")

        # Remove the old python script
        for file in os.listdir(self.launcher.project_path):
            if file.endswith(".py") and "spython" in file:
                os.remove(os.path.join(self.launcher.project_path, file))

        # Write the python script
        with open(
            os.path.join(self.launcher.module_path, "assets", "spython_template.py"),
            "r",
        ) as f:
            text = f.read()

        text = text.replace(
            "{{PROJECT_PATH}}", f'"{base_dir}"'
        )  # On remote, we use absolute path

        # Desi is a single machine (or we treat it as such for now).
        # Ray should run in local mode or with address='auto' but without Slurm specifics.
        # It's basically local execution on a remote machine.
        # Use port 0 to let Ray choose a free port to avoid "address already in use" errors if previous run didn't clean up
        # However, we need to know the port for the tunnel.
        # Better strategy: Try to clean up previous ray instances before starting
        # Add Ray warning suppression to runtime_env if not already present
        runtime_env = self.launcher.runtime_env.copy()
        if "env_vars" not in runtime_env:
            runtime_env["env_vars"] = {}
        if "RAY_ACCEL_ENV_VAR_OVERRIDE_ON_ZERO" not in runtime_env["env_vars"]:
            runtime_env["env_vars"]["RAY_ACCEL_ENV_VAR_OVERRIDE_ON_ZERO"] = "0"

        # Generate a random port to avoid conflicts and allow concurrency
        dashboard_port = random.randint(15000, 45000)
        self.logger.info(f"Using random dashboard port: {dashboard_port}")

        local_mode = f"\n\tinclude_dashboard=True,\n\tdashboard_host='0.0.0.0',\n\tdashboard_port={dashboard_port},\nruntime_env = {runtime_env},\n"

        text = text.replace(
            "{{LOCAL_MODE}}",
            local_mode,
        )

        # Pre-import logic for dill compatibility
        pre_import = ""
        if hasattr(self.launcher, "func") and self.launcher.func:
            func_module = self.launcher.func.__module__
            self.logger.info(f"DEBUG: Detected func_module: {func_module}")
            if func_module and func_module != "__main__":
                root_pkg = func_module.split(".")[0]
                self.logger.info(f"DEBUG: injecting pre-import for {root_pkg}")
                pre_import = f"try:\n    import {root_pkg}\n    print(f'Imported {root_pkg} for dill compatibility')\nexcept ImportError as e:\n    print(f'Pre-import of {root_pkg} failed: {{e}}')\n"
        
        text = text.replace("{{PRE_IMPORT}}", pre_import)

        with open(os.path.join(self.launcher.project_path, "spython.py"), "w") as f:
            f.write(text)

    def _write_runner_script(self, filename, base_dir):
        """Write bash script to set up env and run wrapper"""
        # Determine Python command
        if self.pyenv_python_cmd:
            # Use pyenv: the command already includes eval and pyenv shell
            python_cmd = self.pyenv_python_cmd.split(" && ")[
                -1
            ]  # Extract just "python" from the command
            python3_cmd = python_cmd.replace("python", "python3")
            pyenv_setup = self.pyenv_python_cmd.rsplit(" && ", 1)[
                0
            ]  # Get "eval ... && pyenv shell X.Y.Z"
            use_pyenv = True
        else:
            # Fallback to system Python
            python_cmd = "python"
            python3_cmd = "python3"
            pyenv_setup = ""
            use_pyenv = False

        content = f"""#!/bin/bash
# Desi Runner Script
set -e  # Exit immediately if a command exits with a non-zero status

# Clean up any previous Ray instances (silently)
# pkill -f ray 2>/dev/null || true
# disabled to allow concurrency

# Setup pyenv if available
"""

        if use_pyenv:
            content += f"""# Using pyenv for Python version management
export PATH="$HOME/.pyenv/bin:/usr/local/bin:/opt/pyenv/bin:$PATH"
{pyenv_setup}
"""
        else:
            content += """# pyenv not available, using system Python
"""

        content += f"""
# Check for force reinstall flag
if [ -f ".force_reinstall" ]; then
    echo "🔄 Force reinstall detected: removing existing virtualenv..."
    rm -rf venv
    rm -f .force_reinstall
fi

# Create venv if it doesn't exist
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
"""

        if use_pyenv:
            content += f"""    {pyenv_setup} && {python3_cmd} -m venv venv
"""
        else:
            content += f"""    {python3_cmd} -m venv venv
"""

        content += f"""else
    echo "✅ Using existing virtual environment"
    VENV_EXISTED=true
fi

# Activate venv
source venv/bin/activate

# Install dependencies if requirements file exists and is not empty
if [ -f requirements.txt ]; then
    # Check if requirements.txt is empty (only whitespace)
    if [ -s requirements.txt ]; then
        echo "📥 Installing dependencies from requirements.txt..."
        
        # Create temp files safely
        TMP_INSTALLED=$(mktemp)
        TMP_SEEN=$(mktemp)
        TMP_TO_INSTALL=$(mktemp)
        TMP_ERRORS=$(mktemp)
        
        # Get installed packages once (fast, single command) - create lookup file
        uv pip list --format=freeze 2>/dev/null | sed 's/==/ /' | awk '{{print $1" "$2}}' > "$TMP_INSTALLED" || touch "$TMP_INSTALLED"
        
        # Process requirements: filter duplicates and check what needs installation
        INSTALL_ERRORS=0
        SKIPPED_COUNT=0
        > "$TMP_TO_INSTALL"  # Clear file
        
        while IFS= read -r line || [ -n "$line" ]; do
            # Skip empty lines and comments
            line=$(echo "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            if [ -z "$line" ] || [ "${{line#"#"}}" != "$line" ]; then
                continue
            fi
            
            # Extract package name (remove version specifiers and extras)
            pkg_name=$(echo "$line" | sed 's/[<>=!].*//' | sed 's/\\[.*\\]//' | sed 's/[[:space:]]*//' | tr '[:upper:]' '[:lower:]')
            if [ -z "$pkg_name" ]; then
                continue
            fi
            
            # Skip duplicates (check if we've already processed this package)
            if grep -qi "^$pkg_name$" "$TMP_SEEN" 2>/dev/null; then
                continue
            fi
            echo "$pkg_name" >> "$TMP_SEEN"
            
            # Extract required version if present
            required_version=""
            if echo "$line" | grep -q "=="; then
                required_version=$(echo "$line" | sed 's/.*==\\([^;]*\\).*/\\1/' | sed 's/[[:space:]]*//')
            fi
            
            # Check if package is already installed with correct version
            installed_version=$(grep -i "^$pkg_name " "$TMP_INSTALLED" 2>/dev/null | awk '{{print $2}}' | head -1)
            
            if [ -n "$installed_version" ]; then
                if [ -z "$required_version" ] || [ "$installed_version" = "$required_version" ]; then
                    echo "  ⏭️  $pkg_name==$installed_version (already installed)"
                    SKIPPED_COUNT=$((SKIPPED_COUNT + 1))
                    continue
                fi
            fi
            
            # Package not installed or version mismatch, add to install list
            echo "$line" >> "$TMP_TO_INSTALL"
        done < requirements.txt
        
        # Install packages that need installation
        if [ -s "$TMP_TO_INSTALL" ]; then
            > "$TMP_ERRORS"  # Track errors
            while IFS= read -r line; do
                pkg_name=$(echo "$line" | sed 's/[<>=!].*//' | sed 's/\\[.*\\]//' | sed 's/[[:space:]]*//')
                if uv pip install --quiet "$line" >/dev/null 2>&1; then
                    echo "  ✅ $pkg_name"
                else
                    echo "  ❌ $pkg_name"
                    echo "1" >> "$TMP_ERRORS"
                    # Show error details
                    uv pip install "$line" 2>&1 | grep -E "(error|Error|ERROR|failed|Failed|FAILED)" | head -3 | sed 's/^/      /' || true
                fi
            done < "$TMP_TO_INSTALL"
            INSTALL_ERRORS=$(wc -l < "$TMP_ERRORS" 2>/dev/null | tr -d ' ' || echo "0")
            rm -f "$TMP_ERRORS"
        fi
        
        # Count newly installed packages before cleanup
        NEWLY_INSTALLED=0
        if [ -s "$TMP_TO_INSTALL" ]; then
            NEWLY_INSTALLED=$(wc -l < "$TMP_TO_INSTALL" 2>/dev/null | tr -d ' ' || echo "0")
        fi
        
        # Cleanup temp files
        rm -f "$TMP_INSTALLED" "$TMP_SEEN" "$TMP_TO_INSTALL"
        
        if [ $INSTALL_ERRORS -eq 0 ]; then
            if [ $SKIPPED_COUNT -gt 0 ]; then
                echo "✅ All dependencies up to date ($SKIPPED_COUNT already installed, $NEWLY_INSTALLED newly installed)"
            else
                echo "✅ All dependencies installed successfully"
            fi
        else
            echo "❌ Failed to install $INSTALL_ERRORS package(s)" >&2
            echo "⚠️  Continuing execution despite installation errors..."
            # exit 1  <-- Disabled to allow flexible execution
        fi
    else
        if [ "$VENV_EXISTED" = "true" ]; then
            echo "✅ All dependencies already installed (requirements.txt is empty)"
        else
            echo "⚠️  requirements.txt is empty, skipping dependency installation"
        fi
    fi
else
    echo "⚠️  No requirements.txt found, skipping dependency installation"
fi

# Add current directory to PYTHONPATH to make 'slurmray' importable
export PYTHONPATH=$PYTHONPATH:.

# Run wrapper (Smart Lock + Script execution)
echo "🔒 Acquiring Smart Lock and starting job..."
# Use venv Python (venv is already activated above)
"""

        # After venv activation, use the venv's python, not the system/pyenv python
        content += """python desi_wrapper.py
"""

        with open(os.path.join(self.launcher.project_path, filename), "w") as f:
            f.write(content)

    def _write_desi_wrapper(self, filename):
        """Write python wrapper for Smart Lock with Resource Management"""
        
        # Resource Limits (Hardcoded for Desi based on audit)
        # 24 CPUs, 125GB RAM -> Safety margin: 24 CPUs, 120GB RAM
        # 2 GPUs
        
        content = f"""
import os
import sys
import time
import fcntl
import subprocess
import json
import random

# Configuration
LOCK_FILE = "/tmp/slurmray_desi_resources.lock"
STATE_FILE = "/tmp/slurmray_desi_resources.json"

# Hardware Limits (Desi specific)
LIMITS = {{
    "cpu": 24,
    "ram": 120, # GB
    "gpu": [0, 1] # GPU IDs
}}

# Job Requirements (Injected)
REQ_CPU = {self.launcher.num_cpus}
REQ_RAM = {self.launcher.memory}
REQ_GPU = {self.launcher.num_gpus}

MAX_RETRIES = 10000 # Wait for a long time if needed
RETRY_DELAY = 10 # Check every 10 seconds

def get_lock(fd):
    '''Acquire exclusive lock on state file'''
    fcntl.lockf(fd, fcntl.LOCK_EX)

def release_lock(fd):
    '''Release lock'''
    fcntl.lockf(fd, fcntl.LOCK_UN)

def load_state():
    '''Load state from JSON file'''
    if not os.path.exists(STATE_FILE):
        return {{"jobs": []}}
    try:
        with open(STATE_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {{"jobs": []}}

def save_state(state):
    '''Save state to JSON file'''
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)

def is_pid_running(pid):
    '''Check if PID is running using /proc'''
    try:
        # Check if /proc/PID folder exists
        return os.path.exists(f"/proc/{{pid}}")
    except Exception:
        return False

def clean_stale_jobs(state):
    '''Remove jobs that are no longer running'''
    active_jobs = []
    
    dirty = False
    for job in state.get("jobs", []):
        pid = job["pid"]
        if is_pid_running(pid):
            active_jobs.append(job)
        else:
            print(f"🧹 Cleaning stale job {{pid}} from registry")
            dirty = True
            
    state["jobs"] = active_jobs
    return state, dirty

def check_resources(state):
    '''Check if resources are available'''
    used_cpu = sum(job["cpu"] for job in state["jobs"])
    used_ram = sum(job["ram"] for job in state["jobs"])
    used_gpus = []
    for job in state["jobs"]:
        used_gpus.extend(job["gpu_ids"])
    
    available_cpu = LIMITS["cpu"] - used_cpu
    available_ram = LIMITS["ram"] - used_ram
    available_gpus = [g for g in LIMITS["gpu"] if g not in used_gpus]
    
    print(f"📊 Resources: CPU {{used_cpu}}/{{LIMITS['cpu']}}, RAM {{used_ram}}/{{LIMITS['ram']}} GB, GPUs Used {{used_gpus}}", flush=True)
    
    if REQ_CPU > available_cpu:
        return False, None, "Not enough CPU"
        
    if REQ_RAM > available_ram:
        return False, None, "Not enough RAM"
        
    if REQ_GPU > 0:
        if len(available_gpus) < REQ_GPU:
            return False, None, "Not enough GPU"
        # Allocate specific GPUs
        allocated_gpus = available_gpus[:REQ_GPU]
        return True, allocated_gpus, "OK"
    
    return True, [], "OK"

def main():
    print(f"🔒 Requesting resources: {{REQ_CPU}} CPU, {{REQ_RAM}} GB RAM, {{REQ_GPU}} GPU", flush=True)
    
    # Ensure lock file exists
    if not os.path.exists(LOCK_FILE):
        open(LOCK_FILE, 'w').close()
        
    lock_fd = open(LOCK_FILE, 'w')
    
    allocated_gpu_ids = []
    
    # Resource Acquisition Loop
    for attempt in range(MAX_RETRIES):
        get_lock(lock_fd)
        try:
            state = load_state()
            state, dirty = clean_stale_jobs(state)
            
            allowed, gpus, reason = check_resources(state)
            
            if allowed:
                # Register job
                my_pid = os.getpid()
                new_job = {{
                    "pid": my_pid,
                    "cpu": REQ_CPU,
                    "ram": REQ_RAM,
                    "gpu_ids": gpus,
                    "start_time": time.time()
                }}
                state["jobs"].append(new_job)
                save_state(state)
                allocated_gpu_ids = gpus
                print(f"✅ Resources acquired! Job registered (PID {{my_pid}}). GPUs: {{gpus}}", flush=True)
                break
            else:
                if attempt % 6 == 0: # Log every minute
                    print(f"⏳ Waiting for resources... Reason: {{reason}}", flush=True)
        finally:
            release_lock(lock_fd)
            
        time.sleep(RETRY_DELAY)
    else:
        print("❌ Timeout waiting for resources.", flush=True)
        sys.exit(1)
        
    # Set CUDA_VISIBLE_DEVICES if validated
    if allocated_gpu_ids:
        os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(map(str, allocated_gpu_ids))
        print(f"🔧 Set CUDA_VISIBLE_DEVICES={{os.environ['CUDA_VISIBLE_DEVICES']}}", flush=True)
    elif REQ_GPU == 0:
        # Hide GPUs if not requested to prevent incidental usage?
        # Standard behavior: if 0 requested, we often leave it visible but tell Ray 0.
        # But to be safe on shared machine:
        os.environ["CUDA_VISIBLE_DEVICES"] = ""

    # Execute Runtime
    # Use venv Python if available, otherwise fallback to sys.executable
    venv_python = os.path.join(os.path.dirname(__file__), "venv", "bin", "python")
    if os.path.exists(venv_python):
        python_cmd = venv_python
    else:
        python_cmd = sys.executable

    try:
        # Run the actual workload
        # Run the actual workload with stdout/stderr streaming
        process = subprocess.Popen(
            [python_cmd, "spython.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,  # Interleave stderr into stdout
            text=True,
            bufsize=1  # Line buffered
        )

        # Stream output in real-time
        for line in process.stdout:
            print(line, end='', flush=True)
            
        process.wait()
        
        if process.returncode != 0:
            raise subprocess.CalledProcessError(process.returncode, process.args)

    except subprocess.CalledProcessError as e:
        # Error already printed via stdout streaming
        sys.exit(e.returncode)
    except Exception as e:
        print(f"❌ Job failed: {{e}}", flush=True)
        sys.exit(1)
    finally:
        # Cleanup State
        print("🧹 Cleaning up resource registration...", flush=True)
        get_lock(lock_fd)
        try:
            state = load_state()
            # Remove my PID
            my_pid = os.getpid()
            state["jobs"] = [j for j in state["jobs"] if j["pid"] != my_pid]
            save_state(state)
            print("✅ Resources released.", flush=True)
        finally:
            release_lock(lock_fd)
            lock_fd.close()

if __name__ == "__main__":
    main()
"""
        with open(os.path.join(self.launcher.project_path, filename), "w") as f:
            f.write(content)

