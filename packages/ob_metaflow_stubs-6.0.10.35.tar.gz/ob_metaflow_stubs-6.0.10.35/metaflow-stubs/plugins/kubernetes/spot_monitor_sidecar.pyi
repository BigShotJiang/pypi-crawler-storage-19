######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.1+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-07T23:00:29.077674                                                            #
######################################################################################################

from __future__ import annotations



class SpotTerminationMonitorSidecar(object, metaclass=type):
    def __init__(self):
        ...
    def process_message(self, msg):
        ...
    @classmethod
    def get_worker(cls):
        ...
    ...

