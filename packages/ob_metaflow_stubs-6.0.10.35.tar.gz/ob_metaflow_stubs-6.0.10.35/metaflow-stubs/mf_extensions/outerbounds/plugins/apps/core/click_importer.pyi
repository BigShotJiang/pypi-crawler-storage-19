######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.1+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-07T23:00:29.057540                                                            #
######################################################################################################

from __future__ import annotations


from ......_vendor import click as metaflow_click
from ......_vendor import click as click

