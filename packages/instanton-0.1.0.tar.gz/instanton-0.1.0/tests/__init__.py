"""Instanton tests."""
