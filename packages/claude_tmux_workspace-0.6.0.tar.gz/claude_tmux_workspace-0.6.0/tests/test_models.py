"""Tests for cli.models."""

from datetime import datetime
from pathlib import Path

import pytest
from claude_tmux_core.models import Agent, AgentStatus, WorktreeInfo


class TestWorktreeInfo:
    """Tests for WorktreeInfo dataclass."""

    def test_to_dict(self) -> None:
        """Test serialization to dictionary."""
        info = WorktreeInfo(
            repo_path=Path("/home/user/project"),
            worktree_path=Path("/home/user/.local/share/claude-tmux/worktrees/project/feature"),
            branch_name="claude-tmux/feature",
            base_branch="main",
            base_commit_sha="abc123def456",
        )

        result = info.to_dict()

        assert result["repo_path"] == "/home/user/project"
        assert result["worktree_path"] == "/home/user/.local/share/claude-tmux/worktrees/project/feature"
        assert result["branch_name"] == "claude-tmux/feature"
        assert result["base_branch"] == "main"
        assert result["base_commit_sha"] == "abc123def456"

    def test_from_dict(self) -> None:
        """Test deserialization from dictionary."""
        data = {
            "repo_path": "/home/user/project",
            "worktree_path": "/home/user/.local/share/worktrees",
            "branch_name": "claude-tmux/test",
            "base_branch": "develop",
            "base_commit_sha": "xyz789",
        }

        info = WorktreeInfo.from_dict(data)

        assert info.repo_path == Path("/home/user/project")
        assert info.branch_name == "claude-tmux/test"
        assert info.base_branch == "develop"

    def test_round_trip(self) -> None:
        """Test serialization round-trip preserves data."""
        original = WorktreeInfo(
            repo_path=Path("/repo"),
            worktree_path=Path("/worktree"),
            branch_name="branch",
            base_branch="main",
            base_commit_sha="commit",
        )

        restored = WorktreeInfo.from_dict(original.to_dict())

        assert restored.repo_path == original.repo_path
        assert restored.worktree_path == original.worktree_path
        assert restored.branch_name == original.branch_name
        assert restored.base_branch == original.base_branch
        assert restored.base_commit_sha == original.base_commit_sha


class TestAgent:
    """Tests for Agent dataclass."""

    @pytest.fixture
    def sample_agent(self) -> Agent:
        """Create a sample agent for testing."""
        return Agent(
            name="test-agent",
            window_id="@5",
            window_name="ct_test-agent",
            session_name="myrepo",
            working_dir=Path("/home/user/project"),
            created_at=datetime(2024, 1, 15, 10, 30, 0),
            updated_at=datetime(2024, 1, 15, 10, 35, 0),
        )

    def test_to_dict_without_worktree(self, sample_agent: Agent) -> None:
        """Test serialization without worktree."""
        result = sample_agent.to_dict()

        assert result["name"] == "test-agent"
        assert result["window_id"] == "@5"
        assert result["window_name"] == "ct_test-agent"
        assert result["session_name"] == "myrepo"
        assert result["working_dir"] == "/home/user/project"
        assert result["worktree"] is None

    def test_to_dict_with_worktree(self, sample_agent: Agent) -> None:
        """Test serialization with worktree."""
        sample_agent.worktree = WorktreeInfo(
            repo_path=Path("/repo"),
            worktree_path=Path("/worktree"),
            branch_name="branch",
            base_branch="main",
            base_commit_sha="sha",
        )

        result = sample_agent.to_dict()

        assert result["worktree"] is not None
        assert result["worktree"]["branch_name"] == "branch"

    def test_from_dict(self) -> None:
        """Test deserialization from dictionary."""
        data = {
            "name": "restored-agent",
            "window_id": "@10",
            "window_name": "ct_restored-agent",
            "session_name": "myrepo",
            "working_dir": "/tmp/test",
            "created_at": "2024-01-15T12:00:00",
            "updated_at": "2024-01-15T12:30:00",
            "worktree": None,
        }

        agent = Agent.from_dict(data)

        assert agent.name == "restored-agent"
        assert agent.window_id == "@10"
        assert agent.working_dir == Path("/tmp/test")
        assert agent.worktree is None

    def test_round_trip(self, sample_agent: Agent) -> None:
        """Test serialization round-trip preserves data."""
        restored = Agent.from_dict(sample_agent.to_dict())

        assert restored.name == sample_agent.name
        assert restored.window_id == sample_agent.window_id
        assert restored.session_name == sample_agent.session_name


class TestAgentStatus:
    """Tests for AgentStatus enum."""

    def test_status_values(self) -> None:
        """Test status enum values."""
        assert AgentStatus.RUNNING.value == "running"
        assert AgentStatus.STOPPED.value == "stopped"
        assert AgentStatus.STALE.value == "stale"
