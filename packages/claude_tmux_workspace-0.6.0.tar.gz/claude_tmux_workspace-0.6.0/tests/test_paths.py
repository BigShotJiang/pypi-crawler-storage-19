"""Tests for cli.paths."""

from claude_tmux_core.paths import (
    DATA_DIR,
    WINDOW_NAME_PREFIX,
    WORKTREES_DIR,
    get_worktree_path,
    sanitize_name,
)
from claude_tmux_core.visual import CLAUDE_LOGO_CHAR


class TestPathConstants:
    """Tests for path constants."""

    def test_data_dir_in_home(self) -> None:
        """Test DATA_DIR is under home directory."""
        assert DATA_DIR.parts[-3:] == (".local", "share", "claude-tmux")

    def test_worktrees_dir_in_data_dir(self) -> None:
        """Test WORKTREES_DIR is in DATA_DIR."""
        assert WORKTREES_DIR.parent == DATA_DIR
        assert WORKTREES_DIR.name == "worktrees"

    def test_window_name_prefix(self) -> None:
        """Test window name prefix uses logo char with trailing space."""
        assert f"{CLAUDE_LOGO_CHAR} " == WINDOW_NAME_PREFIX


class TestGetWorktreePath:
    """Tests for get_worktree_path function."""

    def test_returns_path_with_repo_and_agent(self) -> None:
        """Test path includes repo and agent name."""
        result = get_worktree_path("myrepo", "feature-auth")

        assert result.parent.name == "myrepo"
        assert result.name == "feature-auth"
        assert result.parent.parent == WORKTREES_DIR

    def test_different_repos_different_paths(self) -> None:
        """Test different repos produce different paths."""
        path1 = get_worktree_path("repo1", "agent")
        path2 = get_worktree_path("repo2", "agent")

        assert path1 != path2
        assert path1.parent.name == "repo1"
        assert path2.parent.name == "repo2"


class TestSanitizeName:
    """Tests for sanitize_name function."""

    def test_lowercase(self) -> None:
        """Test converts to lowercase."""
        assert sanitize_name("MyAgent") == "myagent"

    def test_spaces_to_hyphens(self) -> None:
        """Test replaces spaces with hyphens."""
        assert sanitize_name("my agent") == "my-agent"

    def test_special_chars_to_hyphens(self) -> None:
        """Test replaces special characters with hyphens."""
        assert sanitize_name("fix/bug#123") == "fix-bug-123"
        assert sanitize_name("test@feature") == "test-feature"

    def test_collapse_multiple_hyphens(self) -> None:
        """Test collapses multiple hyphens."""
        assert sanitize_name("a--b---c") == "a-b-c"
        assert sanitize_name("test//feature") == "test-feature"

    def test_strip_leading_trailing_hyphens(self) -> None:
        """Test strips leading and trailing hyphens."""
        assert sanitize_name("-test-") == "test"
        assert sanitize_name("---agent---") == "agent"

    def test_complex_name(self) -> None:
        """Test complex name sanitization."""
        assert sanitize_name("Feature: Add User Auth!") == "feature-add-user-auth"
