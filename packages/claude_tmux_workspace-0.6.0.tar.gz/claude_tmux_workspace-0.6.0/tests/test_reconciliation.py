"""Tests for cli reconciliation logic."""

from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

from claude_tmux_core.db.database import Agent as DbAgent
from claude_tmux_core.db.database import Worktree as DbWorktree
from claude_tmux_core.models import Agent, ReconciliationResult


class TestReconciliationResult:
    """Tests for ReconciliationResult dataclass."""

    def test_empty_result(self) -> None:
        """Test creating an empty reconciliation result."""
        result = ReconciliationResult(
            orphan_worktrees=[],
            zombie_agents=[],
            stale_agents=[],
        )

        assert len(result.orphan_worktrees) == 0
        assert len(result.zombie_agents) == 0
        assert len(result.stale_agents) == 0

    def test_with_issues(self) -> None:
        """Test creating a result with issues."""
        orphan = Path("/tmp/orphan")
        zombie = Agent(
            name="zombie",
            window_id="@1",
            window_name="ct_zombie",
            session_name="test",
            working_dir=Path("/tmp"),
        )
        stale = Agent(
            name="stale",
            window_id="@2",
            window_name="ct_stale",
            session_name="test",
            working_dir=Path("/tmp"),
        )

        result = ReconciliationResult(
            orphan_worktrees=[orphan],
            zombie_agents=[zombie],
            stale_agents=[stale],
        )

        assert len(result.orphan_worktrees) == 1
        assert result.orphan_worktrees[0] == orphan
        assert len(result.zombie_agents) == 1
        assert result.zombie_agents[0].name == "zombie"
        assert len(result.stale_agents) == 1
        assert result.stale_agents[0].name == "stale"


class TestFindOrphanWorktrees:
    """Tests for find_orphan_worktrees function."""

    @patch("claude_tmux_cli.core.get_all_managed_worktrees_on_disk")
    @patch("claude_tmux_cli.core.db.list_worktrees")
    def test_no_orphans_when_empty(
        self,
        mock_list_worktrees: MagicMock,
        mock_get_worktrees: MagicMock,
    ) -> None:
        """Test returns empty list when no worktrees exist."""
        from claude_tmux_cli.core import find_orphan_worktrees

        mock_list_worktrees.return_value = []
        mock_get_worktrees.return_value = {}

        result = find_orphan_worktrees()

        assert result == []

    @patch("claude_tmux_cli.core.get_all_managed_worktrees_on_disk")
    @patch("claude_tmux_cli.core.db.list_worktrees")
    def test_no_orphans_when_all_tracked(
        self,
        mock_list_worktrees: MagicMock,
        mock_get_worktrees: MagicMock,
    ) -> None:
        """Test returns empty when all worktrees are tracked."""
        from claude_tmux_cli.core import find_orphan_worktrees

        worktree_path = Path("/tmp/worktrees/repo/agent1")
        db_worktree = DbWorktree(
            pane_id="%1",
            repo_path="/tmp/repo",
            worktree_path=str(worktree_path),
            branch_name="claude-tmux/agent1",
            base_branch="main",
            base_commit_sha="abc123",
        )
        mock_list_worktrees.return_value = [db_worktree]
        mock_get_worktrees.return_value = {"repo": [worktree_path]}

        result = find_orphan_worktrees()

        assert result == []

    @patch("claude_tmux_cli.core.get_all_managed_worktrees_on_disk")
    @patch("claude_tmux_cli.core.db.list_worktrees")
    def test_detects_orphan_worktree(
        self,
        mock_list_worktrees: MagicMock,
        mock_get_worktrees: MagicMock,
    ) -> None:
        """Test detecting worktree on disk but not in database."""
        from claude_tmux_cli.core import find_orphan_worktrees

        orphan_path = Path("/tmp/worktrees/repo/orphan")
        mock_list_worktrees.return_value = []
        mock_get_worktrees.return_value = {"repo": [orphan_path]}

        result = find_orphan_worktrees()

        assert len(result) == 1
        assert result[0] == orphan_path


def _make_db_agent(
    name: str,
    pane_id: str = "%1",
    window_id: str = "@1",
    session_name: str = "test",
) -> DbAgent:
    """Create a database Agent for testing."""
    now = datetime.now()
    return DbAgent(
        pane_id=pane_id,
        window_id=window_id,
        session_name=session_name,
        working_dir="/tmp",
        status="working",
        created_at=now,
        updated_at=now,
        name=name,
        window_name=f"ct_{name}",
    )


class TestFindZombieAgents:
    """Tests for find_zombie_agents function."""

    @patch("claude_tmux_cli.core.worktree_exists")
    @patch("claude_tmux_cli.core.db.get_worktree")
    @patch("claude_tmux_cli.core.db.list_agents")
    def test_no_zombies_when_no_agents(
        self,
        mock_list_agents: MagicMock,
        mock_get_worktree: MagicMock,
        mock_worktree_exists: MagicMock,
    ) -> None:
        """Test returns empty when no agents exist."""
        from claude_tmux_cli.core import find_zombie_agents

        mock_list_agents.return_value = []

        result = find_zombie_agents()

        assert result == []
        mock_worktree_exists.assert_not_called()

    @patch("claude_tmux_cli.core.worktree_exists")
    @patch("claude_tmux_cli.core.db.get_worktree")
    @patch("claude_tmux_cli.core.db.list_agents")
    def test_no_zombies_when_worktrees_exist(
        self,
        mock_list_agents: MagicMock,
        mock_get_worktree: MagicMock,
        mock_worktree_exists: MagicMock,
    ) -> None:
        """Test returns empty when all agent worktrees exist."""
        from claude_tmux_cli.core import find_zombie_agents

        db_agent = _make_db_agent("agent1")
        db_worktree = DbWorktree(
            pane_id="%1",
            repo_path="/tmp/repo",
            worktree_path="/tmp/worktree",
            branch_name="branch",
            base_branch="main",
            base_commit_sha="abc",
        )
        mock_list_agents.return_value = [db_agent]
        mock_get_worktree.return_value = db_worktree
        mock_worktree_exists.return_value = True

        result = find_zombie_agents()

        assert result == []

    @patch("claude_tmux_cli.core.worktree_exists")
    @patch("claude_tmux_cli.core.db.get_worktree")
    @patch("claude_tmux_cli.core.db.list_agents")
    def test_detects_zombie_agent(
        self,
        mock_list_agents: MagicMock,
        mock_get_worktree: MagicMock,
        mock_worktree_exists: MagicMock,
    ) -> None:
        """Test detecting agent with missing worktree."""
        from claude_tmux_cli.core import find_zombie_agents

        db_agent = _make_db_agent("zombie")
        db_worktree = DbWorktree(
            pane_id="%1",
            repo_path="/tmp/repo",
            worktree_path="/tmp/missing",
            branch_name="branch",
            base_branch="main",
            base_commit_sha="abc",
        )
        mock_list_agents.return_value = [db_agent]
        mock_get_worktree.return_value = db_worktree
        mock_worktree_exists.return_value = False

        result = find_zombie_agents()

        assert len(result) == 1
        assert result[0].name == "zombie"

    @patch("claude_tmux_cli.core.worktree_exists")
    @patch("claude_tmux_cli.core.db.get_worktree")
    @patch("claude_tmux_cli.core.db.list_agents")
    def test_agents_without_worktree_not_zombies(
        self,
        mock_list_agents: MagicMock,
        mock_get_worktree: MagicMock,
        mock_worktree_exists: MagicMock,
    ) -> None:
        """Test agents without worktree are not considered zombies."""
        from claude_tmux_cli.core import find_zombie_agents

        db_agent = _make_db_agent("no-worktree")
        mock_list_agents.return_value = [db_agent]
        mock_get_worktree.return_value = None  # No worktree

        result = find_zombie_agents()

        assert result == []
        mock_worktree_exists.assert_not_called()


class TestFullReconcile:
    """Tests for full_reconcile function."""

    @patch("claude_tmux_cli.core.find_zombie_agents")
    @patch("claude_tmux_cli.core.find_orphan_worktrees")
    @patch("claude_tmux_cli.core.reconcile_agents")
    def test_returns_combined_result(
        self,
        mock_reconcile: MagicMock,
        mock_find_orphans: MagicMock,
        mock_find_zombies: MagicMock,
    ) -> None:
        """Test full_reconcile combines all detection results."""
        from claude_tmux_cli.core import AgentView, full_reconcile
        from claude_tmux_core.models import AgentStatus

        stale = Agent(
            name="stale",
            window_id="@1",
            window_name="ct_stale",
            session_name="test",
            working_dir=Path("/tmp"),
        )
        zombie = Agent(
            name="zombie",
            window_id="@2",
            window_name="ct_zombie",
            session_name="test",
            working_dir=Path("/tmp"),
        )
        orphan = Path("/tmp/orphan")

        mock_reconcile.return_value = [
            AgentView(agent=stale, status=AgentStatus.STOPPED),
        ]
        mock_find_orphans.return_value = [orphan]
        mock_find_zombies.return_value = [zombie]

        result = full_reconcile()

        assert len(result.stale_agents) == 1
        assert result.stale_agents[0].name == "stale"
        assert len(result.zombie_agents) == 1
        assert result.zombie_agents[0].name == "zombie"
        assert len(result.orphan_worktrees) == 1
        assert result.orphan_worktrees[0] == orphan


class TestCleanupZombieAgents:
    """Tests for cleanup_zombie_agents function.

    Note: With database as source of truth, CLI has read-only access.
    cleanup_zombie_agents only reports zombies, it doesn't remove them.
    """

    @patch("claude_tmux_cli.core.find_zombie_agents")
    def test_returns_zombies(
        self,
        mock_find_zombies: MagicMock,
    ) -> None:
        """Test returns zombies found by find_zombie_agents."""
        from claude_tmux_cli.core import cleanup_zombie_agents

        zombie = Agent(
            name="zombie",
            window_id="@1",
            window_name="ct_zombie",
            session_name="test",
            working_dir=Path("/tmp"),
        )
        mock_find_zombies.return_value = [zombie]

        result = cleanup_zombie_agents(dry_run=True)

        assert len(result) == 1
        assert result[0].name == "zombie"

    @patch("claude_tmux_cli.core.find_zombie_agents")
    def test_dry_run_flag_ignored(
        self,
        mock_find_zombies: MagicMock,
    ) -> None:
        """Test dry_run flag is ignored (CLI has read-only db access)."""
        from claude_tmux_cli.core import cleanup_zombie_agents

        zombie = Agent(
            name="zombie",
            window_id="@1",
            window_name="ct_zombie",
            session_name="test",
            working_dir=Path("/tmp"),
        )
        mock_find_zombies.return_value = [zombie]

        # Both calls should return the same result
        result_dry = cleanup_zombie_agents(dry_run=True)
        result_not_dry = cleanup_zombie_agents(dry_run=False)

        assert len(result_dry) == 1
        assert len(result_not_dry) == 1


class TestCleanupOrphanWorktrees:
    """Tests for cleanup_orphan_worktrees function."""

    @patch("claude_tmux_cli.core.remove_orphan_worktree")
    def test_removes_clean_worktrees(
        self,
        mock_remove: MagicMock,
    ) -> None:
        """Test successfully removes clean orphan worktrees."""
        from claude_tmux_cli.core import cleanup_orphan_worktrees

        orphan = Path("/tmp/orphan")

        result = cleanup_orphan_worktrees([orphan], force=False)

        assert len(result) == 1
        assert result[0] == orphan
        mock_remove.assert_called_once_with(orphan, force=False)

    @patch("claude_tmux_cli.core.remove_orphan_worktree")
    def test_skips_failed_removals(
        self,
        mock_remove: MagicMock,
    ) -> None:
        """Test skips worktrees that fail to remove."""
        from claude_tmux_cli.core import cleanup_orphan_worktrees
        from claude_tmux_core.exceptions import WorktreeDirtyError

        clean = Path("/tmp/clean")
        dirty = Path("/tmp/dirty")

        def side_effect(path: Path, force: bool) -> None:
            if path == dirty:
                raise WorktreeDirtyError(str(dirty), 1)

        mock_remove.side_effect = side_effect

        result = cleanup_orphan_worktrees([dirty, clean], force=False)

        assert len(result) == 1
        assert result[0] == clean

    @patch("claude_tmux_cli.core.remove_orphan_worktree")
    def test_force_removes_dirty(
        self,
        mock_remove: MagicMock,
    ) -> None:
        """Test force flag is passed through."""
        from claude_tmux_cli.core import cleanup_orphan_worktrees

        orphan = Path("/tmp/orphan")

        cleanup_orphan_worktrees([orphan], force=True)

        mock_remove.assert_called_once_with(orphan, force=True)
