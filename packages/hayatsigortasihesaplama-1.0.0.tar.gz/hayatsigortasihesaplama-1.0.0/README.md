# 📊 Hayat Sigortası Matematiği ve NTP Hesaplayıcı:

**Geliştirici:** AYŞE SELÇUK

**Pozisyon:** Selçuk Üniversitesi Fen Fakültesi Aktüerya Bilimleri Bölümü

--------



### 🎯 Proje Amacı

Bu projenin temel amacı, "Hayat Sigortası Matematiği" dersi müfredatında yer alan aktüeryal hesaplama metodolojilerini profesyonel bir yazılım kütüphanesine dönüştürmektir. Proje; teorik ders notlarında işlenen komütasyon fonksiyonlarını ($D_x, N_x, S_x, C_x, M_x, R_x$) dinamik bir hesaplama motoruyla birleştirerek şu hedefleri gerçekleştirmektedir:

**Yaşam Sigortaları:** Saf yaşam ($nE_x$), ömür boyu ve süreli anüiteler ($\ddot{a}_x, \ddot{a}_{x:\overline{n}|}$) ile birikimli gelecek değer (Forborne Anüite - $s_{x:\overline{n}|}$) modelleri üzerinden hesaplamalar yapılır.

**Ölüm Sigortaları:** Ömür boyu ($A_x$), dönemsel ve aritmetik biçimde artan vefat teminatlarının ($(IA)_x$) prim değerlemesi gerçekleştirilir.

**Karma Sigortalar:** Yaşam ve vefat risklerini matematiksel olarak birleştiren ($A_{x:\overline{n}|}$), dönemsel ve ertelenmiş hibrit poliçe modellerini kapsar.

**Dinamik Aktüeryal Motor (Highlight):** Statik sonuçlar yerine; teknik faiz, yaş veya süre gibi giriş parametreleri değiştiğinde tüm komütasyon tablosunu ve bağımlı tüm değerleri milisaniyeler içinde yeniden hesaplayan esnek bir çekirdek yapı kurulmuştur.

**Müfredat Ötesi Analizler ($P$ ve $V$):** Temel NTP hesaplamaları bir adım öteye taşınarak; yıllık net prim taksitlendirmeleri ($P$) ve poliçe süresince oluşan matematiksel rezervlerin ($V$) prospektif yöntemle hesaplanması sisteme entegre edilmiştir.

**Akademik Güvenilirlik (19 Unit Tests):** Aktüeryal hesaplamalarda sıfır hata toleransı prensibiyle; $N_x = D_x + N_{x+1}$ gibi temel özdeşlikler ve sınır değer analizlerini kapsayan 19 farklı birim test ile sistemin matematiksel tutarlılığı mühürlenmiştir.


Bu kütüphane, aktüerya biliminin karmaşık hesaplama yükünü otomatize ederek, ders kapsamında işlenen tüm sigorta ürünleri için dinamik bir analiz platformu sunmaktadır.



---------


 ### 🚀 Proje Hakkında (Teknik Parametreler)

**• Hesaplama Metodolojisi:** Proje, hayat sigortası matematiğinin temelini oluşturan Komütasyon Fonksiyonları yöntemini kullanır. Yaşam tablosu verilerinden yola çıkarak $D_x, N_x, M_x, S_x, R_x$ ve $C_x$ sütunlarını dinamik olarak oluşturur. Tüm Net Tek Prim (NTP) ve Rezerv hesaplamaları bu değerler üzerinden aktüeryal denklik prensibine göre yapılır.

**• Veri Seti:** Hesaplamalar, ders notlarından referans alınarak dijitalleştirilen 1980 CSO Mortalite Tablosu üzerinden dinamik olarak gerçekleştirilmektedir.

**• Teknik Faiz Oranı:** Tüm iskonto ve bugünkü değer hesaplamalarında ders standartlarına uygun olarak $i = \%10$ ($0.10$) faiz oranı varsayılmıştır.

**• Sıfır Bağımlılık (Zero-Dependency):** Proje; Pandas veya Numpy gibi harici kütüphanelere ihtiyaç duymadan, tamamen saf Python algoritmalarıyla geliştirilmiştir. Bu, hesaplama motorunun her ortamda ek bir yükleme gerektirmeden çalışmasını sağlar.

**• Veri Uyumluluğu:** `data/` klasöründeki mortalite tablosu için noktalı virgül (;) ayracı ve ondalık virgül (,) kullanımına tam uyumlu özel veri temizleme motoru içermektedir.

**•Taşınabilir Veri Yapısı:** MANIFEST.in yapılandırması sayesinde, mortalite verisi paketle bütünleşik hale getirilmiştir. Bu sayede kütüphane başka sistemlere kurulduğunda veri yolu hatası almadan çalışabilmektedir.


> [!IMPORTANT]
Mortalite Tablosu Hakkında: Projede kullanılan 1980 CSO Mortalite Tablosu, ders kapsamında iletilen basılı kaynaklar referans alınarak dijitalleştirilmiş olup; veri okuma motoru bu tablonun `data/` klasöründeki özel formatına (noktalı virgül ayracı ve ondalık virgül kullanımı) göre optimize edilmiştir.



--------


### 🛡️ Proje Kapsamı

Bu kütüphane, hayat sigortaları matematiğinin temel direkleri olan üç ana sigorta grubunu ve ilgili tüm Net Tek Prim (NTP) hesaplamalarını tam olarak desteklemektedir:

1.**Yaşam Sigortaları:** Hayatta kalma şartına bağlı birikim ve irat modelleri. Saf yaşam ($nE_x$), ömür boyu ve süreli anüiteler ($a_x, \ddot{a}_x$) ile birikimli gelecek değer (Forborne Anüite) modelleri üzerinden hesaplamalar yapılır.

2.**Ölüm Sigortaları:** Vefat riski karşılığında sunulan teminatların prim değerlemesi. Ömür boyu ($A_x$), dönemsel ve aritmetik biçimde artan vefat teminatlarının prim değerlemesi gerçekleştirilir.

3.**Karma Sigortalar:** Hem yaşam hem vefat riskini birleştiren hibrit ürünler.Yaşam ve vefat risklerini matematiksel olarak birleştiren, dönemsel ve ertelenmiş hibrit poliçe modellerini kapsar.

4.**Aktüeryal Analizler:** Primlerin taksitlendirilmesi ve poliçe birikimlerinin değerlemesi. Verilen bir NTP'nin yıllık net primlere ($P$) dönüştürülmesi ve poliçe süresi içindeki matematiksel rezervlerin ($tV_x$) prospektif yöntemle hesaplanmasını kapsar.

5.**Otomatik Komütasyon Motoru:** Ham mortalite verilerini ($l_x$) kullanarak $D_x, N_x, M_x, S_x, R_x$ ve $C_x$ sütunlarını tanımlı teknik faize göre dinamik olarak türeten çekirdek algoritma.6. Kalite Güvence ve Birim Testleri: Yazılımın matematiksel doğruluğunu denetleyen, müfredat özdeşliklerini (örneğin $N_x = D_x + N_{x+1}$) baz alan 19 farklı senaryo ile gerçekleştirilen otomatik test süreçleri.7. Veri Entegrasyonu ve Paketleme: MANIFEST.in ve setup.py yapılandırmalarıyla veritabanı (CSV) ve kod bütünlüğünün sağlandığı, taşınabilir ve kurulabilir bir kütüphane mimarisi.

---------


### 📁 Proje Dizin Yapısı

Proje, modüler bir kütüphane mimarisine uygun olarak şu şekilde organize edilmiştir:

```text          
HayatSigortasiHesaplama/
├── data/                 # 1980 CSO Mortalite Tablosu (CSV formatında)
├── src/                  # Aktüeryal hesaplama motoru ve çekirdek kodlar 
│   ├── __init__.py       # Paket giriş dosyası
│   └── hesaplayici.py    # HayatSigortasiHesaplayici sınıfı
├── tests/                # Matematiksel doğruluğu denetleyen birim testleri 
│   ├── __init__.py
│   └── test_hesaplayici.py
├── .gitignore            # Git takibine girmeyecek dosyalar
├── deneme.py             # Sistemin çalışmasını kanıtlayan demo scripti
├── MANIFEST.in           # CSV verilerinin pakete dahil edilmesini sağlayan yapılandırma
├── README.md             # Proje dökümantasyonu ve kullanım kılavuzu
└── setup.py              # PyPI paketleme ve kurulum yapılandırması
```


-------


### 💻 Kurulum ve Çalıştırma

1. Projeyi Klonlayın ve Dizine Girin:
```bash 
git clone https://github.com/ayseselcuk/HayatSigortasiHesaplama.git
cd HayatSigortasiHesaplama
```

2. Sanal Ortam Oluşturun (Önerilen):
 ```bash   
python -m venv venv
# Windows için:
venv\Scripts\activate
# Mac/Linux için:
source venv/bin/activate
``` 

3. Paketi Kurun:
   
  •Yerel Geliştirme İçin:
```bash
pip install .
 ```
  •Doğrudan PyPI Üzerinden (Yayınlandıktan Sonra):
```bash
pip install HayatSigortasiHesaplama
 ```

4. Sistemi Test Edin: Kurulumun ve matematiksel hesaplamaların doğruluğunu teyit etmek için:
```bash
python -m unittest tests/test_hesaplayici.py
```


----------



### 🚀 Örnek Kullanım ve Doğrulama 

Sistemin verileri doğru okuduğunu ve hesaplama yaptığını hızlıca test etmek için ana dizindeki `deneme.py` dosyasını çalıştırabilirsiniz. Aşağıda temel ve ileri düzey hesaplama örnekleri yer almaktadır:

```python
from src import HayatSigortasiHesaplayici

# 1. Kütüphaneyi Başlat (%10 teknik faiz ve tablo yolu ile)
hesap = HayatSigortasiHesaplayici("data/1980CSO_MortaliteTablosu.csv", 0.10)

# --- İleri Düzey Aktüeryal Hesaplamalar ---

# a) Karma Sigorta NTP ve Yıllık Taksit (Prim) Hesabı
# 35 yaşında, 10 yıl süreli bir karma sigortanın peşin ve taksitli maliyeti
ntp_karma = hesap.karma_donemsel_ntp(x=35, n=10)
yillik_p = hesap.yillik_net_prim_hesapla(ntp_karma, yas=35, sure=10)

print(f"Karma Sigorta Peşin Maliyet (NTP): {ntp_karma:.6f}")
print(f"10 Yıl Boyunca Ödenecek Yıllık Net Prim (P): {yillik_p:.6f}")

# b) Aktüeryal Rezerv Hesabı (Prospektif Metot)
# Yukarıdaki poliçenin 5. yılı sonundaki birikmiş matematiksel rezervi
rezerv = hesap.prospektif_rezerv_hesapla(yas=35, n=10, t=5, yillik_prim=yillik_p)
print(f"Poliçenin 5. Yılındaki Prospektif Rezervi (5V): {rezerv:.6f}")

# c) Aritmetik Artan Ölüm Sigortası
# Vefat tazminatının her yıl 1 birim arttığı model
artan_vefat = hesap.olum_aritmetik_artan_ntp(x=40)
print(f"Artan Vefat Teminatı NTP ((IA)x): {artan_vefat:.6f}")

# d) Beklenen Kalan Ömür Hesabı
e35 = hesap.beklenen_omur_hesapla(35)
print(f"35 Yaşındaki Kişinin Beklenen Kalan Ömrü (ex): {e35:.2f} yıl")
```
------



## 📊 Örnek Çıktılar ve Analiz Raporu

Sistem çalıştırıldığında, 1980 CSO Mortalite tablosu üzerinden otomatik olarak komütasyon sütunlarını hesaplar ve terminale aşağıdaki gibi kapsamlı bir rapor sunar:

### 1. Aktüeryal Komütasyon Tablosu
Sistem, girilen teknik faiz oranına göre tüm temel aktüeryal değerleri ($D_x, N_x, M_x, R_x$ vb.) anlık olarak türetir:

| Yaş | $D_x$ | $C_x$ | $N_x$ | $S_x$ | $M_x$ | $R_x$ |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 0 | 1000000.00 | 3800.00 | 10832803.92 | 116637970.55 | 15199.64 | 229352.05 |
| 1 | 905290.90 | 880.60 | 9832803.92 | 105805166.63 | 11399.64 | 214152.40 |
| ... | ... | ... | ... | ... | ... | ... |

### 2. Analiz Raporu (Örnek: 35 Yaş)
`deneme.py` üzerinden alınan örnek bir poliçe analiz çıktısı:
* **Saf Yaşam ($nE_x$):** 0.374112
* **Ömür Boyu Yaşam ($\ddot{a}_x$):** 10.371314
* **Dönemsel Karma ($A_{x:n}$):** 0.391297
* **Yıllık Net Prim:** 0.058440

---


### 🛠️ Desteklenen Aktüeryal Fonksiyonlar

**1. Yaşam Sigortaları (NTP)**

• `yasam_tek_odemeli_ntp(x, n)`: $n$ yıl hayatta kalma şartına bağlı peşin ödeme ($nE_x$).

• `yasam_omur_boyu_ntp(x, donem_basi)`: Ömür boyu süren irat ödemeleri ($a_x / \ddot{a}_x$).

• `yasam_donemsel_ntp(x, n, donem_basi)`: Belirli bir yaşta başlayan $n$ yıl süreli geçici annüite ($n|a_x$).

• `yasam_ertelenmis_ntp(x, m, donem_basi)`: $m$ yıl ertelenmiş ömür boyu anüitedir ($m|a_x$).

• `yasam_ertelenmis_donemsel_ntp(x, m, n, donem_basi)`: $m$ yıl ertelenmiş ve $n$ yıl sürecek geçici anüite modelidir ($m|n|a_x$).

• `forborne_anuite(x, n, donem_basi)`: Geçmiş dönem ödemelerinin birikimli gelecek değeri ($s_{x:n}$, $S_{x:\overline{n}}$).

• `yasam_aritmetik_artan_ntp(x)`: Ödemelerin her yıl aritmetik olarak arttığı yaşam sigortası modelleridir ($(Ia)_x$).

• `yasam_cok_odemeli_ntp(x, m)`: Yılda birden fazla ($m$) ödemeli iratlar için yaklaşık hesaplama.


**2. Ölüm Sigortaları (NTP)**

• `olum_omur_boyu_ntp(x)`: Süresiz vefat teminatı primi ($A_x$).

• `olum_donemsel_ntp(x, n)`: Belirli bir süre ($n$) içindeki vefat riskini kapsayan primdir ($nA_x$).

• `olum_ertelenmis_ntp(x, m)`: $m$ yıl ertelenmiş ömür boyu vefat teminatı ($m|A_x$).

• `olum_ertelenmis_donemsel_ntp(x, m, n)`: $m$ yıl ertelenmiş, $n$ yıl süreli vefat teminatı ($m|nA_x$).

• `olum_aritmetik_artan_ntp(x)`: Aritmetik olarak artan vefat tazminatlarının peşin değeridir ($(IA)_x$).


**3. Karma Sigortalar (NTP)**

• `karma_donemsel_ntp(x, n)`: Vade sonu hayatta kalma veya vade içi vefat risklerini kapsayan birleşik prim ($nA_{x:n}$).

• `karma_ertelenmis_donemsel_ntp(x, m, n)`: Ertelenmiş dönemsel karma sigorta primi ($m|nA_{x:n}$).


**4. İleri Düzey Aktüeryal Hesaplamalar**

• `yillik_net_prim_hesapla(ntp, yas, sure)`: Net Tek Primin yıllık eşit taksitlere ($P$) dönüştürülmesi.

• `prospektif_rezerv_hesapla(yas, n, t, yillik_prim)`: Prospektif yöntemle $t$. yıldaki matematiksel rezerv hesabı (${}^tV_x$).

• `beklenen_omur_hesapla(x)`: $x$ yaşındaki bireyin beklenen kalan yaşam süresi ($e_x$).

• `teknik_faiz_guncelle(yeni_faiz)`: Teknik faiz değiştiğinde tüm komütasyon sütunlarını ($D, N, M, S, R$) otomatik yeniden hesaplayan dinamik motor.


---------------



📊 Dinamik Komütasyon Motoru

Proje, ölüm tablosundaki ham verileri x ve l_x kullanarak , tanımlı teknik faiz oranına bağlı olarak komütasyon sütunlarını dinamik şekilde üretir.
Teknik faiz değiştirildiğinde tüm aktüeryal değerler otomatik olarak güncellenir.

🔹 Temel Komütasyon Değerleri

	•	D_x
İskonto edilmiş yaşayan sayısı:


$$ D_x = l_x \cdot v^x $$


	•	C_x
İskonto edilmiş ölen sayısı:

$$ C_x = d_x \cdot v^{x+1} $$

> Not: $d_x$, $x$ yaşında ölen kişi sayısını temsil eder ve $d_x = l_x - l_{x+1}$ formülüyle türetilmektedir.


🔹 Yaşam ve İrat Toplamları

	•	N_x
($D_x$ değerlerinin sondan başa kümülatif toplamı):
Anüite ve irat hesaplamalarında temel teşkil eder.

$$ N_x = \sum_{k=x}^{\omega} D_k $$


	•	S_x
 ($N_x$ değerlerinin kümülatif toplamı):
Aritmetik artan ödemeli anüiteler için kullanılır.

$$ S_x = \sum_{k=x}^{\omega} N_k $$


🔹 Vefat ve Tazminat Toplamları

	•	M_x
	
 ($C_x$ değerlerinin kümülatif toplamı):
Standart vefat sigortalarının prim hesaplamalarında kullanılır.

$$ M_x = \sum_{k=x}^{\omega} C_k $$


	•	R_x
 ($M_x$ değerlerinin kümülatif toplamı):
Aritmetik artan vefat teminatlarının değerlemesinde kullanılır.

 $$ R_x = \sum_{k=x}^{\omega} M_k $$


--------




### 🛡️ Hata Yönetimi ve Kısıtlamalar

* **Yaş Sınırı (Omega):** Sistem, mortalite tablosundaki maksimum yaşın ($\omega$) üzerindeki girişleri ve poliçe süresinin tablo sınırlarını aştığı durumları tespit ederek kullanıcıyı uyarır.
  
* **Parametre Validasyonu:** Sigorta süresi ($n$), erteleme süresi ($m$) veya yaş ($x$) gibi girdilerin negatif veya mantıksız (float) girilmesi durumunda otomatik doğrulama mekanizması devreye girer.
  
* **Veri Bütünlüğü:** `data/` klasöründeki kaynak tabloda oluşabilecek eksik veri veya hatalı karakter (karakter/sayı karışıklığı) durumları için `try-except` hata yakalama motoru entegre edilmiştir.


---------------


## 🧪 Test Metodolojisi ve Güvenilirlik

Projenin matematiksel doğruluğu, `unittest` kütüphanesi kullanılarak hazırlanan **19 farklı senaryo** ile mühürlenmiştir. Bu testler, hesaplamaların akademik aktüerya müfredatıyla %100 uyumlu olduğunu garanti eder.

### Test Kapsamı:

* **Komütasyon Zinciri:** $N_x = D_x + N_{x+1}$ ve $M_x = C_x + M_{x+1}$ özdeşliklerinin her yaş için doğrulanması.

* **Sınır Değer Analizi:** Tablo sonu (Omega yaş), negatif yaş girişleri ve %0 faiz durumu gibi uç senaryolar.

* **Rezerv Kontrolü:** Prospektif rezervlerin poliçe başında 0, vade sonunda teminat tutarına (1.0) ulaşmasının testi.

* **Aktüeryal Mantık:** Ertelenmiş, anüite ve artan teminatlı poliçelerin fiyatlandırma tutarlılığı.

**Testleri Çalıştırmak İçin:**
```bash
python -m unittest tests/test_hesaplayici.py
```

--------


### 📜 Lisans

Bu proje eğitim amaçlı geliştirilmiştir , MIT Lisansı ile lisanslanmıştır. Akademik amaçlarla özgürce kullanılabilir.


---------


### 🎓 Teşekkür ve Veri Kaynağı

Bu proje, Dr. Öğr. Ü. Demet Hocamızın "Hayat Sigortası Matematiği" dersi kapsamında paylaştığı değerli bilgiler ve akademik notlar ışığında geliştirilmiştir.

•Veri Seti: Hesaplamalarda kullanılan 1980 CSO Mortalite Tablosu, Demet Hocamızın ders notlarından referans alınarak dijitalleştirilmiştir.

•Metodoloji: Kod içerisindeki tüm aktüeryal algoritmalar ve komütasyon fonksiyonları (D_x, N_x, M_x vb.), derste işlenen teorik müfredat ile tam uyumlu şekilde kurgulanmıştır.