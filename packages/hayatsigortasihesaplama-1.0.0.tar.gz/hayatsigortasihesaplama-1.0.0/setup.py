from setuptools import setup, find_packages

setup(
    name="HayatSigortasiHesaplama", # Paketi 'pip install .' ile kurmak için isim
    version="1.0.0",
    author="AYŞE SELÇUK",
    author_email="ayseselcuk484@gmail.com", 
    description="Hayat Sigortası Matematiği NTP Hesaplama Paketi",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/ayseselcuk/HayatSigortasiHesaplama",
    
    # KOD YAPISI: Kodların src klasörü altında olduğunu belirtir
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    
    # VERİ DOSYALARI: data klasöründeki CSV dosyasının paketle birlikte gitmesi için
    include_package_data=True,
    package_data={
        # Herhangi bir paket içindeki data klasöründeki csv dosyalarını dahil et
        "": ["data/*.csv"],
    },
    
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Mathematics",
    ],
    python_requires='>=3.6', # Minimum Python sürümü gereksinimi
)