import unittest
import sys
import os

# Proje ana dizinini Python yoluna ekleyerek modül import hatasını engelliyoruz.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.hesaplayici import HayatSigortasiHesaplayici

class TestHayatSigortasi(unittest.TestCase):
    """
    Hayat Sigortası hesaplama motorunun tüm müfredat fonksiyonlarını 
    denetleyen kapsamlı test sınıfı.
    """

    @classmethod
    def setUpClass(cls):
        """Mortalite tablosunu bir kez yükler."""
        cls.dosya_yolu = "data/1980CSO_MortaliteTablosu.csv"
        cls.varsayilan_faiz = 0.10
        cls.hesaplayici = HayatSigortasiHesaplayici(cls.dosya_yolu, cls.varsayilan_faiz)

    def setUp(self):
        """
        Her testten önce faiz oranını %10'a sıfırlar. 
        Testlerin birbirinden etkilenmesini önler (State Management).
        """
        self.hesaplayici.teknik_faiz_guncelle(self.varsayilan_faiz)

    # --- 1. VERİ VE SİSTEM TESTLERİ ---
    def test_veritabani_yukleme(self):
        """Tablonun başarıyla yüklenip yüklenmediğini denetler."""
        self.assertTrue(len(self.hesaplayici.tablo) > 0, "Mortalite tablosu okunamadı!")

    def test_yas_siniri_hatasi(self):
        """99 yaş sınırının aşıldığı durumlarda hata fırlatıldığını denetler."""
        with self.assertRaises(ValueError):
            # 90 yaşındaki birine 15 yıllık sigorta (90+15=105 > 99)
            self.hesaplayici.yasam_donemsel_ntp(x=90, n=15)

    # --- 2. YAŞAM SİGORTALARI (ANÜİTE) TESTLERİ ---
    def test_yasam_donemsel_ntp(self):
        """35 yaş 10 yıl süreli geçici anüite değerini doğrular."""
        sonuc = self.hesaplayici.yasam_donemsel_ntp(x=35, n=10, donem_basi=True)
        # 1980 CSO %10 için beklenen yaklaşık değer
        self.assertAlmostEqual(sonuc, 6.695736, places=5)

    def test_cok_odemeli_irat_mantigi(self):
        """Yılda m defa ödemeli iratların yıllık irattan küçük olduğunu doğrular."""
        yillik = self.hesaplayici.yasam_omur_boyu_ntp(x=40, donem_basi=True)
        aylik = self.hesaplayici.yasam_cok_odemeli_ntp(x=40, m=12)
        self.assertLess(aylik, yillik, "Aylık ödemeler yıllık peşin değerden küçük olmalı.")

    # --- 3. ÖLÜM VE KARMA SİGORTA TESTLERİ ---
    def test_karma_sigorta_esitligi(self):
        """Karma Sigorta = Vefat Sigortası + Saf Yaşam Sigortası eşitliğini denetler."""
        x, n = 35, 15
        karma = self.hesaplayici.karma_donemsel_ntp(x, n)
        olum = self.hesaplayici.olum_donemsel_ntp(x, n)
        yasam = self.hesaplayici.yasam_tek_odemeli_ntp(x, n)
        self.assertAlmostEqual(karma, olum + yasam, places=7)

    # --- 4. YILLIK PRİM VE REZERV TESTLERİ (Yeni Kapsam) ---
    def test_yillik_prim_mantigi(self):
        """Yıllık net primin her zaman Net Tek Prim'den küçük olduğunu doğrular."""
        ntp = self.hesaplayici.olum_omur_boyu_ntp(x=30)
        yillik_p = self.hesaplayici.yillik_net_prim_hesapla(ntp, yas=30)
        self.assertLess(yillik_p, ntp, "Taksit tutarı peşin ödemeden (NTP) düşük olmalı.")

    def test_rezerv_pozitiflik(self):
        """Poliçe ortasındaki rezervin mantıklı sınırlar içinde olduğunu denetler."""
        x, n, t = 30, 20, 10
        ntp = self.hesaplayici.karma_donemsel_ntp(x, n)
        p = self.hesaplayici.yillik_net_prim_hesapla(ntp, x, n)
        rezerv = self.hesaplayici.prospektif_rezerv_hesapla(x, n, t, p)
        self.assertGreater(rezerv, 0, "Rezerv değeri pozitif bir birikim olmalıdır.")

    # --- 5. ANALİZ VE FAİZ TESTLERİ ---
    def test_faiz_guncelleme_etkisi(self):
        """Faiz oranı değişince primlerin güncellendiğini teyit eder."""
        ilk_sonuc = self.hesaplayici.olum_omur_boyu_ntp(40)
        self.hesaplayici.teknik_faiz_guncelle(0.05) # Faiz düşürülürse
        yeni_sonuc = self.hesaplayici.olum_omur_boyu_ntp(40) # Prim artmalı
        self.assertGreater(yeni_sonuc, ilk_sonuc, "Düşük faizde risk maliyeti artmalıdır.")

    def test_beklenen_omur_mantigi(self):
        """Beklenen ömür hesabının mantıklı sonuç verdiğini denetler."""
        e35 = self.hesaplayici.beklenen_omur_hesapla(35)
        self.assertTrue(0 < e35 < 100, "Beklenen ömür değeri gerçek dışı.")

    # --- 6. ERTELENMİŞ VE ARİTMETİK ARTAN TESTLERİ (Eksik Kısımlar) ---
    def test_ertelenmis_yasam_mantigi(self):
        """Ertelenmiş yaşam sigortasının peşin değerden küçük olduğunu doğrular."""
        pesin = self.hesaplayici.yasam_omur_boyu_ntp(x=35)
        ertelenmis = self.hesaplayici.yasam_ertelenmis_ntp(x=35, m=5)
        self.assertLess(ertelenmis, pesin, "Ertelenmiş sigorta peşinden ucuz olmalıdır.")

    def test_aritmetik_artan_mantigi(self):
        """Artan sigortanın normal sigortadan pahalı olduğunu doğrular."""
        normal = self.hesaplayici.olum_omur_boyu_ntp(x=40)
        artan = self.hesaplayici.olum_aritmetik_artan_ntp(x=40)
        self.assertGreater(artan, normal, "Artan teminatlı sigorta daha pahalı olmalıdır.")

    def test_forborne_anuite_mantigi(self):
        """Birikimli anüite (sx:n) değerinin 1'den büyük olduğunu doğrular."""
        sonuc = self.hesaplayici.forborne_anuite(x=30, n=10)
        self.assertGreater(sonuc, 1, "Birikimli değer 1'den büyük olmalıdır.")

    # --- 7. HİBRİT VE KARMAŞIK MODELLER TESTİ ---
    def test_ertelenmis_donemsel_mantigi(self):
        """Ertelenmiş dönemsel sigortaların (m|nAx) mantığını doğrular."""
        # m|nAx:n (Ertelenmiş Karma) her zaman nAx:n (Peşin Karma) değerinden küçük olmalıdır (Zaman Değeri)
        pesin_karma = self.hesaplayici.karma_donemsel_ntp(x=35, n=10)
        ertelenmis_karma = self.hesaplayici.karma_ertelenmis_donemsel_ntp(x=35, m=5, n=10)
        
        self.assertLess(ertelenmis_karma, pesin_karma, "Ertelenmiş poliçe peşin poliçeden ucuz olmalıdır.")

    def test_yasam_aritmetik_artan_dogrulama(self):
        """Artan yaşam sigortasının (Ia)x normal anüiteden büyük olduğunu doğrular."""
        normal_ax = self.hesaplayici.yasam_omur_boyu_ntp(x=40)
        artan_ax = self.hesaplayici.yasam_aritmetik_artan_ntp(x=40)
        
        self.assertGreater(artan_ax, normal_ax, "Artan ödemeli anüite normalden pahalı olmalıdır.")

    def test_komutasyon_turetme_iliskisi(self):
        """Nx = Dx + Nx+1 ilişkisini rastgele bir yaş için doğrular."""
        x = 45
        s_x = self.hesaplayici._get_s(x)
        s_next = self.hesaplayici._get_s(x + 1)
        self.assertAlmostEqual(s_x['Nx'], s_x['Dx'] + s_next['Nx'], places=5)

    def test_omega_yasi_siniri(self):
        """Tablonun son yaşındaki (omega) hesaplama davranışını denetler."""
        max_yas = self.hesaplayici.tablo[-1]['yas']
        # Son yaşta ömür boyu vefat sigortası 1'e (veya iskonto edilmiş haline) yaklaşmalı
        ntp = self.hesaplayici.olum_omur_boyu_ntp(max_yas)
        self.assertGreater(ntp, 0)
        self.assertLessEqual(ntp, 1.1) # İskonto faktörü dahil

    def test_sifir_faiz_durumu(self):
        """Faiz %0 olduğunda Dx değerinin lx değerine eşitliğini doğrular."""
        self.hesaplayici.teknik_faiz_guncelle(0.0)
        x = 20
        s = self.hesaplayici._get_s(x)
        self.assertEqual(s['Dx'], s['lx'], "Faiz 0 iken Dx = lx olmalıdır.")

    def test_negatif_parametre_hatasi(self):
        """Negatif yaş veya süre girildiğinde ValueError fırlatılmasını denetler."""
        with self.assertRaises(ValueError):
            self.hesaplayici.yasam_tek_odemeli_ntp(x=-5, n=10)

    def test_beklenen_omur_azalma_egilimi(self):
        """Yaş arttıkça beklenen ömrün azaldığını doğrular."""
        e20 = self.hesaplayici.beklenen_omur_hesapla(20)
        e60 = self.hesaplayici.beklenen_omur_hesapla(60)
        self.assertGreater(e20, e60, "Genç birinin beklenen ömrü yaşlı birinden fazla olmalıdır.")                   


if __name__ == '__main__':
    unittest.main()