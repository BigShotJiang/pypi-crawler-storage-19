"""
ModelAutopsy: Enterprise ML Debugging Library.
"""
from .debugger import watch
from .debugger import analyze as _internal_analyze

# Engine Detection
ENGINE_STATUS = "Unknown"

try:
    # Try to import Rust module
    import modelautopsy_rust
    ENGINE_STATUS = "Rust Safety Core"
except ImportError:
    # Try C++ Module
    try:
        import _core_cpp
        ENGINE_STATUS = "C++ Speed Core"
    except ImportError:
        ENGINE_STATUS = "Pure Python (Slow)"

# Expose Analyze
def analyze(tensor):
    """Public API. Analyzes tensor using best available engine."""
    return _internal_analyze(tensor)

__all__ = ["watch", "analyze", "ENGINE_STATUS"]
