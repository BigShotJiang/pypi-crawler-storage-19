# ModelAutopsy

ModelAutopsy is a high-performance, hybrid-engine (Rust & C++) Machine Learning debugging library. It acts as a real-time diagnostic tool for Deep Learning pipelines, instantly detecting NaN, Infinity, Vanishing, and Exploding gradients.

## Features

*   Rust Safety Core: Uses Rust's memory safety guarantees to prevent Python crashes (Segfaults) during inspection.
*   C++ Speed Core: Uses OpenMP SIMD instructions to analyze 1M+ parameters in milliseconds.
*   Zero-Overhead: Uses direct memory access to NumPy buffers, avoiding Python GIL.
*   IDE-Style Debugging: Includes a `@watch` decorator that acts like a live breakpoint for your training loops.
*   Advanced Metrics: Calculates Variance, L2 Norm, Mean, Min/Max in a single pass.

## Installation

```bash
pip install modelautopsy
