import uuid

from fastapi import Header
from starlette.requests import Request


async def get_request_id(x_request_id: str = Header(..., alias="x-request-id")):
    """
    使用示例

    @app.post("/example/help")
    async def run(body: Body, reqid=Depends(get_request_id)):
        ...

    如果请求头中没有x-request-id，则会触发validate_interceptor的检验
    """
    return x_request_id


def gen_random_request_id():
    return str(uuid.uuid4())


def extract_reqid(reqeust: Request):
    return reqeust.headers.get("x-request-id", None)


def extract_url(reqeust: Request):
    try:
        url = reqeust.url.path
    except Exception:
        url = ""

    return url
