from typing import List, Optional, Any

from pydantic import BaseModel, field_validator


class HuizeQwen32bAwqDto(BaseModel):
    class Message(BaseModel):
        content: str
        role: str = "user"

    Action: str = "NormalChat"
    Messages: List[Message] = []


class HuizeQwen32bAwqVo(BaseModel):
    Output: Optional[str]
    TokenProbs: Optional[List[float]]

    @field_validator("Output")
    @classmethod
    def check_output_not_empty(cls, v: str) -> str:
        if v is None or not v.strip():
            raise ValueError("Output cannot be empty")
        return v


class MindleDs32bAwqDto(BaseModel):
    class Message(BaseModel):
        role: str = "user"
        content: str  # 消息内容

    model: str = "huize"
    messages: List[Message] = []


class MindleDs32bAwqVo(BaseModel):
    id: Optional[str] = None
    choices: List["Choice"] = []
    created: Optional[int] = None
    model: Optional[str] = None
    object: Optional[Any] = None
    usage: Optional["Usage"] = None

    class Choice(BaseModel):
        finish_reason: Optional[str] = None
        index: Optional[int] = None
        message: Optional["Message"] = None
        logprobs: Optional[dict] = None

        class Message(BaseModel):
            role: Optional[str] = None
            content: Optional[str] = None
            function_call: Optional[dict] = None
            tool_calls: Optional[List[dict]] = None

    class Usage(BaseModel):
        prompt_tokens: int
        total_tokens: int
        completion_tokens: int
