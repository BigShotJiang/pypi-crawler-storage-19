from typing import Optional, Dict, List, Generic, TypeVar

from pydantic import BaseModel


T = TypeVar("T")


class BidBackendBaseVo(BaseModel, Generic[T]):
    code: int
    message: str
    requestId: str
    result: T

    def is_success(self):
        return self.code == 0 and self.message == "success"


class BidBackendFileParseSubmitDto(BaseModel):
    """
    提交文件解析任务
    """

    class PdfPath(BaseModel):
        pdf_name: Optional[str] = None
        pdf_link: Optional[str] = None

    class DocxPath(BaseModel):
        docx_name: Optional[str] = None
        docx_link: Optional[str] = None

    pdf_path: PdfPath = PdfPath()
    docx_path: DocxPath = DocxPath()


class ParseResultVo(BaseModel):
    """
    获取文件解析结果
    """

    status: str
    finished: bool
    result: Optional[Dict | List] = None
