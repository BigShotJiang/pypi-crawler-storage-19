from typing import List, Union, Optional

from pydantic import BaseModel


class EmbedRespVo(BaseModel):
    Embedding: List[List[float]]
    Count: int
    Dim: Optional[Union[int, List[int]]]
