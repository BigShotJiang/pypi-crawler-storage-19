from typing import List, Optional, Union
from pydantic import BaseModel, Field


# region 入库


class AddDocDto(BaseModel):
    class DocDataObj(BaseModel):
        UserName: str
        DbName: str
        FileID: Union[int, str]
        FileName: str

    class ChunkData(BaseModel):
        Question: str
        Answer: str

    DocType: str = "qa"
    DocData: DocDataObj
    ChunkDatas: List[ChunkData] = []


class AddDocVo(BaseModel):
    """添加QA响应VO模型"""

    Status: str
    ChunkIds: List[int]

    def success(self) -> bool:
        return self.Status == "success"


# endregion


# region 搜索


class SearchQaDto(BaseModel):
    class DocData(BaseModel):
        UserName: str
        DbName: str

    class VectorRepresent(BaseModel):
        DenseVector: Optional[list] = None

    DocType: Optional[str] = "qa"
    DocDatas: List[DocData] = []
    Query: Optional[str] = None
    Limit: Optional[int] = 100
    SearchLimit: Optional[int] = 100
    VectorRepresentation: Optional[VectorRepresent] = None

class SearchQaVo(BaseModel):
    """搜索响应VO模型"""

    class MatchItem(BaseModel):
        """匹配项模型"""

        Answer: Optional[str] = None
        AnswerType: Optional[str] = None
        DbName: Optional[str] = None
        FileId: Optional[str] = None
        FileName: Optional[str] = None
        From: Optional[str] = None
        Id: Optional[int] = None
        Question: Optional[str] = None
        Score: Optional[float] = None
        SimilarFlag: Optional[int] = None
        UserName: Optional[str] = Field(..., description="用户名")

    Count: Optional[int] = Field(..., description="匹配结果数量")
    MatchList: Optional[List[MatchItem]] = Field(..., description="匹配结果列表")


# endregion


# region 查询


class ReadQaDto(BaseModel):
    """查询请求的DTO模型"""

    class doc_data(BaseModel):
        UserName: str
        DbName: str
        FileID: str

    DocType: Optional[str] = "qa"
    ReturnVector: Optional[bool] = True
    DocData: Optional[doc_data] = None
    page: Optional[int] = 1
    pageSize: Optional[int] = 10000


class ReadQaVo(BaseModel):
    """查询响应VO模型"""

    class ListItem(BaseModel):
        """匹配项模型"""

        Id: Optional[int] = None
        Question: Optional[str] = None
        Answer: Optional[str] = None
        AnswerType: Optional[str] = None
        SimilarFlag: Optional[int] = None
        DenseVector: Optional[float] = None
        SparseVector: Optional[dict] = None

    total: Optional[int] = Field(..., description="总记录数")
    page: Optional[int] = Field(..., description="页码")
    pageSize: Optional[int] = Field(..., description="每页数量")
    list: Optional[List[ListItem]] = Field(..., description="查询到的问答对列表")


# endregion