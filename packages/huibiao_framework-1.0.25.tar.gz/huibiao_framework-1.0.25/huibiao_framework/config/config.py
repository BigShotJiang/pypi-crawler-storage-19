from typing import List
from urllib.parse import urljoin

from huibiao_framework.utils.meta_class import OsAttrMeta, ConstantClass
import os


class ErrorCodeConfig:
    SERVICE_PREFIX: int = os.getenv("ERROR_CODE_SERVICE_PREFIX", "0")


class MetricsConfig(metaclass=OsAttrMeta):
    """后端服务配置"""
    IGNORE_REQUEST_OPERATION_METRICS: bool = False
    IGNORE_CLIENT_OPERATION_METRICS: bool = False


class ServiceConfig(metaclass=OsAttrMeta):
    HTTP_PORT: int = 8100
    TIMEOUT_KEEP_ALIVE: int  = 1000
    PROCESS_NUM: int = 1


class LogConfig(metaclass=OsAttrMeta):
    LOGGER_PATH: str = "/logger"
    LOG_RETENTION_DAY: int = 60
    DISABLE_LOG_PKG: str = ""
    LOG_ADD_CONTAINED_ID: bool = False
    SAVE_INFO_LEVEL: bool = False
    SAVE_DEBUG_LOG: bool = True

    @classmethod
    def get_disable_log_pkg(cls) -> List[str]:
        if cls.DISABLE_LOG_PKG:
            return cls.DISABLE_LOG_PKG.split(",")
        else:
            return []


class MinioConfig(metaclass=OsAttrMeta):
    ENDPOINT: str
    AK: str
    SK: str
    BUCKET_NAME: str = "huibiao"
    OSS_SECURE: bool = False


class LlmModelNameConstant(ConstantClass):
    HuiZeQwen32bAwq = "HuiZeQwen32bAwq"
    MindileDs32bAwq = "MindileDs32bAwq"


class ModelConfig(metaclass=OsAttrMeta):
    """
    大语言模型的参数
    HuiZeQwen32bQwq
    内蒙环境 182.42.234.26  http://vllm-qwen-32b.model.hhht.ctcdn.cn:9080/common/query
    MindileDs32bAwq
    上海910b智能体环境 61.172.167.158 http://mindie-ds-32b-awq.office.sh.ctyun.cn:9080/v1/chat/completions
    """
    LLM_MODEL_TYPE: str = LlmModelNameConstant.HuiZeQwen32bAwq
    REQUEST_URL: str = "http://vllm-qwen-32b.model.hhht.ctcdn.cn:9080/common/query"
    OPEN_AI_MODEL_TYPE: str = "huize"
    VLLM_BEAR_TOKEN: str = ""

class ClientConfig(metaclass=OsAttrMeta):
    SEARCH_URL: str = "http://huibiao-omni-retrieve-engine-dev.zz.ctyun.cn:9080"
    EMBED_URL: str = "http://dmx.model.zz.ctcdn.cn:9080/bas-bge-large-zhengwu-0329/embedding"
    CHUNK_URL: str = (
        "http://dmx.model.dev.zz.ctcdn.cn:9080/text-content-chunk-tools-dev/chunk"
    )
    BID_BACKEND_URL: str = "http://huize-bid-backend-dev.ctyun.cn:9080"


class OcrDocumentParseClientConfig:
    """
    tender-document-parser的配置
    """
    TENDER_DOCUMENT_PARSER_URL = os.getenv(
        "TENDER_DOCUMENT_PARSER_URL",
        "http://tender-document-parser-dev.hhht.ctcdn.cn:9080",
    )

    # 各服务地址配置 - 支持独立指定不同服务地址
    IMAGE_OCR_TYY_URL = os.getenv(
        "IMAGE_OCR_TYY_URL", urljoin(TENDER_DOCUMENT_PARSER_URL, "image_ocr")
    )
    LAYOUT_DETECTION_TYY_URL = os.getenv(
        "LAYOUT_DETECTION_TYY_URL",
        urljoin(TENDER_DOCUMENT_PARSER_URL, "image_layout"),
    )
    DOCUMENT_PARSER_TYY_URL = os.getenv(
        "DOCUMENT_PARSER_TYY_URL", urljoin(TENDER_DOCUMENT_PARSER_URL, "upload")
    )
    CONVERT_TO_PDF_URL = os.getenv(
        "CONVERT_TO_PDF_URL", urljoin(TENDER_DOCUMENT_PARSER_URL, "convert")
    )
    DOCUMENT_PARSER_TYY_ASYNC_UPLOAD_URL = os.getenv(
        "DOCUMENT_PARSER_TYY_ASYNC_UPLOAD_URL",
        urljoin(TENDER_DOCUMENT_PARSER_URL, "async_upload"),
    )
    DOCUMENT_PARSER_TYY_ASYNC_PULL_URL = os.getenv(
        "DOCUMENT_PARSER_TYY_ASYNC_PULL_URL",
        urljoin(TENDER_DOCUMENT_PARSER_URL, "async_pull"),
    )