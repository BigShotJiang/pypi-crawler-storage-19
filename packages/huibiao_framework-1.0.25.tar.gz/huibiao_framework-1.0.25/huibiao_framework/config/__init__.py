from dotenv import load_dotenv

load_dotenv(".env")

from .config import MinioConfig, ClientConfig, ModelConfig, OcrDocumentParseClientConfig, LogConfig, ServiceConfig

__all__ = ["MinioConfig", "ClientConfig", "ModelConfig", "OcrDocumentParseClientConfig", "LogConfig", "ServiceConfig"]
