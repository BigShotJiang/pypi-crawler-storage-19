import asyncio
from typing import List

from huibiao_framework.utils.file_manage import JsonAsyncFile
from huibiao_framework.utils.url_utils import UrlUtils


async def get_local_or_http_json(url_or_path: str) -> JsonAsyncFile:
    """
    如果传入http下载路径，则只会下载到内存中，但不会落盘
    如果传入本地路径，则直接从本地加载json
    :param url_or_path:
    :return:
    """
    async_file: JsonAsyncFile
    if UrlUtils.is_http_url(url_or_path):
        async_file = JsonAsyncFile(
            wget_link=url_or_path,
        )
        await async_file.wget()
    else:
        async_file = JsonAsyncFile(local_path=url_or_path)
        await async_file.load()

    return async_file


async def get_local_or_http_json_batch(*urls_or_paths: str) -> List[JsonAsyncFile]:
    """
    批量获取json
    """
    return await asyncio.gather(
        *[get_local_or_http_json(url_or_path) for url_or_path in urls_or_paths]
    )
