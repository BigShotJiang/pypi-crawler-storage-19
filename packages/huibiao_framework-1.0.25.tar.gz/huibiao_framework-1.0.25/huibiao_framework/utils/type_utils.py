from typing import List, Optional, TypeVar
from pydantic import BeforeValidator
from typing_extensions import Annotated

# 自定义注解，自动将None转换为空列表
T = TypeVar("T")
EmptyListIfNone = Annotated[Optional[List[T]], BeforeValidator(lambda v: [] if v is None else v)]