import os
import shutil
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional


class LocalAbstractFileInfo(ABC):
    def __init__(self, path: str):
        self.path: str = path
        self.create_time: Optional[datetime] = None
        self.modify_time: Optional[datetime] = None
        self.access_time: Optional[datetime] = None
        self.init()

    def exists(self) -> bool:
        return os.path.exists(self.path)

    def init(self) -> 'LocalAbstractFileInfo':
        if self.exists():
            self.create_time = datetime.fromtimestamp(os.path.getctime(self.path))
            self.modify_time = datetime.fromtimestamp(os.path.getmtime(self.path))
            self.access_time = datetime.fromtimestamp(os.path.getatime(self.path))
        return self

    @abstractmethod
    def size(self):
        pass

    @abstractmethod
    def delete(self):
        pass

    def __repr__(self):
        return f"FileInfo(path={self.path})"


class FileInfo(LocalAbstractFileInfo):
    def __init__(self, path: str):
        super().__init__(path)

    @abstractmethod
    def size(self):
        return os.path.getsize(self.path)

    @abstractmethod
    def delete(self):
        if self.exists():
            os.remove(self.path)


class DirectoryInfo(LocalAbstractFileInfo):
    def __init__(self, path: str):
        super().__init__(path)

    def delete(self):
        """
        删除文件夹
        """
        if self.exists():
            shutil.rmtree(self.path)

    def size(self):
        """
        获取文件夹大小，待实现
        """
        pass