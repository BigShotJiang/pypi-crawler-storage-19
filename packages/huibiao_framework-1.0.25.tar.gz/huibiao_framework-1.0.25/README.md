# 标书框架

- 为了减少每个标书项目重复开发的问题，创建了此框架，后续每个标书项目只需要导入框架即可
    ```bash
    pip install -i  https://pypi-readonly:*****@devops.ctcdn.cn/nexus/repository/group-pypi/simple huibiao-framework
    ```
- 注意：不要把huibiao-framework包固定到某个镜像中，然后基于该镜像打包，这种做法导致标书项目无法获取最新的huibiao-framework功能

## 开发规范
### 依赖
- 建议使用uv管理依赖
- pyproject.toml记录了依赖包
- 开发未来版本时，打包可以加入rc后缀，避免与正式版本冲突，例如1.0.19rc
- 上一个正式版本的包，修复bug时，版本号采用格式，例如1.0.18.1

### 目录
- test代码放在test目录！！！！！

### 包构建和推送
  ```bash
  uv build
  uv publish --index ctcdn-pypi-upload
  ```