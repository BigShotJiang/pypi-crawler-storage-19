"""Tests for TimeSmith."""

