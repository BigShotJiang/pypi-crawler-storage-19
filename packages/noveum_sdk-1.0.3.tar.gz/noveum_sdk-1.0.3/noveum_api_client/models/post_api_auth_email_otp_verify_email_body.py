from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="PostApiAuthEmailOtpVerifyEmailBody")


@_attrs_define
class PostApiAuthEmailOtpVerifyEmailBody:
    """
    Attributes:
        email (str): Email address to verify
        otp (str): OTP to verify
    """

    email: str
    otp: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        email = self.email

        otp = self.otp

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "email": email,
                "otp": otp,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        otp = d.pop("otp")

        post_api_auth_email_otp_verify_email_body = cls(
            email=email,
            otp=otp,
        )

        post_api_auth_email_otp_verify_email_body.additional_properties = d
        return post_api_auth_email_otp_verify_email_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
