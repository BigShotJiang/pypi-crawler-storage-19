# JSON Schemas

This directory contains all JSON schemas used for document processing and data extraction.

## Schemas

### `registry_schema.py`
Schema for document registry - identifies and categorizes documents in a batch.

**Used by:** `registry.py`

### `document_schema.py`
General document schema for extracting structured data from documents.

**Used by:** `document.py`

### `document_bank_schema.py`
Banking-specific document schema with financial fields and compliance requirements.

**Used by:** `document.py` for banking documents

### `master_records_bank_schema.py`
Schema for master records mapping - determines which document contains which field.

**Used by:** `master_records.py`

## Schema Structure

All schemas follow strict mode requirements:
- All properties must be in `required` array
- `additionalProperties` set to `false`
- Nested objects follow same rules

## Usage

Import schemas from this package:

```python
from realtimex_manifest_ai.schemas import Registry, Document, DocumentBank, MasterRecordsBank
```

Or import specific schema:

```python
from realtimex_manifest_ai.schemas.registry_schema import Registry
```

## Maintenance

When updating schemas:
1. Ensure strict mode compliance
2. Update both `*_schema.py` and `*_bank_schema.py` if changes affect banking documents
3. Run `scripts/update_schemas.py` to apply `fix_schema_strict()`
4. Test with actual document processing
