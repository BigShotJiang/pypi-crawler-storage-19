# from pydantic import BaseModel, Field
import json
DocumentBank = json.loads("""
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "document_bank",
  "description": "Reduced schema for Payment Order and Customs Declaration Summary extraction.",
  "type": "object",
  "properties": {
    "metadata": {
      "type": "object",
      "properties": {
        "document_type": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string",
              "description": "Example: Commercial Invoice, Customs Declaration, Sales Contract,  Contract Annex, ..."
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "document_number": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "issue_date": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string",
              "format": "date"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "issuer_country": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string",
              "pattern": "^[A-Z]{2}$"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "document_language": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "page_count": {
          "type": "integer"
        },
        "is_digitally_signed": {
          "type": "boolean"
        },
        "extracted_at": {
          "type": "string",
          "format": "date-time"
        },
        "extractor_version": {
          "type": "string"
        }
      },
      "required": [
        "document_type",
        "document_number",
        "issue_date",
        "issuer_country",
        "document_language",
        "page_count",
        "is_digitally_signed",
        "extracted_at",
        "extractor_version"
      ],
      "additionalProperties": false
    },
    "entities": {
      "type": "object",
      "properties": {
        "exporter_shipper": {
          "type": "object",
          "description": "Corresponds to the Beneficiary/Exporter (Page 3)",
          "properties": {
            "name": {
              "type": "object",
              "properties": {
                "value": {
                  "type": "string"
                }
              },
              "required": [
                "value"
              ],
              "additionalProperties": false
            },
            "address": {
              "type": "object",
              "properties": {
                "raw_text": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                }
              },
              "required": [
                "raw_text"
              ],
              "additionalProperties": false
            },
            "bank_details": {
              "type": "object",
              "description": "Beneficiary Bank Details from Payment Order",
              "properties": {
                "bank_name": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                },
                "swift_bic": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                },
                "account_number": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                }
              },
              "required": [
                "bank_name",
                "swift_bic",
                "account_number"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "name",
            "address",
            "bank_details"
          ],
          "additionalProperties": false
        },
        "consignee_buyer": {
          "type": "object",
          "description": "Corresponds to the Importer (Page 3)",
          "properties": {
            "name": {
              "type": "object",
              "properties": {
                "value": {
                  "type": "string"
                }
              },
              "required": [
                "value"
              ],
              "additionalProperties": false
            },
            "address": {
              "type": "object",
              "properties": {
                "raw_text": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                }
              },
              "required": [
                "raw_text"
              ],
              "additionalProperties": false
            },
            "phone": {
              "type": "object",
              "description": "Contact telephone number",
              "properties": {
                "value": {
                  "type": "string"
                }
              },
              "required": [
                "value"
              ],
              "additionalProperties": false
            },
            "tax_id_eori_vat_ein": {
              "type": "object",
              "properties": {
                "value": {
                  "type": "string"
                }
              },
              "required": [
                "value"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "name",
            "address",
            "phone",
            "tax_id_eori_vat_ein"
          ],
          "additionalProperties": false
        },
        "applicant": {
          "type": "object",
          "description": "Ordering Customer (Page 1)",
          "properties": {
            "name": {
              "type": "object",
              "properties": {
                "value": {
                  "type": "string"
                }
              },
              "required": [
                "value"
              ],
              "additionalProperties": false
            },
            "address": {
              "type": "object",
              "properties": {
                "raw_text": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                }
              },
              "required": [
                "raw_text"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "name",
            "address"
          ],
          "additionalProperties": false
        },
        "beneficiary": {
          "type": "object",
          "description": "Payment beneficiary/recipient",
          "properties": {
            "name": {
              "type": "object",
              "properties": {
                "value": {
                  "type": "string"
                }
              },
              "required": [
                "value"
              ],
              "additionalProperties": false
            },
            "address": {
              "type": "object",
              "properties": {
                "raw_text": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                }
              },
              "required": [
                "raw_text"
              ],
              "additionalProperties": false
            },
            "bank_details": {
              "type": "object",
              "description": "Beneficiary Bank Details from Payment Order",
              "properties": {
                "bank_name": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                },
                "address": {
                  "type": "object",
                  "properties": {
                    "raw_text": {
                      "type": "object",
                      "properties": {
                        "value": {
                          "type": "string"
                        }
                      },
                      "required": [
                        "value"
                      ],
                      "additionalProperties": false
                    }
                  },
                  "required": [
                    "raw_text"
                  ],
                  "additionalProperties": false
                },
                "country": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                },
                "swift_bic": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                },
                "account_number": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                }
              },
              "required": [
                "bank_name",
                "swift_bic",
                "account_number"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "name",
            "address",
            "bank_details"
          ],
          "additionalProperties": false
        },
        "intermediary_bank": {
          "type": "object",
          "description": "Intermediary Bank",
          "properties": {
            "bank_name": {
              "type": "object",
              "properties": {
                "value": {
                  "type": "string"
                }
              },
              "required": [
                "value"
              ],
              "additionalProperties": false
            },
            "address": {
              "type": "object",
              "properties": {
                "raw_text": {
                  "type": "object",
                  "properties": {
                    "value": {
                      "type": "string"
                    }
                  },
                  "required": [
                    "value"
                  ],
                  "additionalProperties": false
                }
              },
              "required": [
                "raw_text"
              ],
              "additionalProperties": false
            },
            "country": {
              "type": "object",
              "properties": {
                "value": {
                  "type": "string"
                }
              },
              "required": [
                "value"
              ],
              "additionalProperties": false
            },
            "swift_bic": {
              "type": "object",
              "properties": {
                "value": {
                  "type": "string"
                }
              },
              "required": [
                "value"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "bank_name",
            "swift_bic"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "exporter_shipper",
        "consignee_buyer",
        "applicant",
        "beneficiary",
        "intermediary_bank"
      ],
      "additionalProperties": false
    },
    "references": {
      "type": "object",
      "properties": {
        "invoice_number": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "contract_number": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "customs_declaration_number": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "invoice_number",
        "contract_number",
        "customs_declaration_number"
      ],
      "additionalProperties": false
    },
    "dates": {
      "type": "object",
      "description": "Important dates related to the transaction",
      "properties": {
        "deal_date": {
          "type": "object",
          "description": "Deal date / foreign exchange transaction date",
          "properties": {
            "value": {
              "type": "string",
              "format": "date"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "value_date": {
          "type": "object",
          "description": "Value date of foreign exchange transaction",
          "properties": {
            "value": {
              "type": "string",
              "format": "date"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "payment_execution_date": {
          "type": "object",
          "description": "Date when payment order is executed",
          "properties": {
            "value": {
              "type": "string",
              "format": "date"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "deal_date",
        "payment_execution_date"
      ],
      "additionalProperties": false
    },
    "payment_details": {
      "type": "object",
      "description": "Payment transaction details",
      "properties": {
        "details_of_payment": {
          "type": "object",
          "description": "Description/purpose of payment",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "charges_type": {
          "type": "object",
          "description": "Type of charges: SHA (shared), OUR (sender pays all), or BEN (beneficiary pays all)",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "details_of_payment",
        "charges_type"
      ],
      "additionalProperties": false
    },
    "payment_source": {
      "type": "object",
      "description": "Source of payment funds",
      "properties": {
        "account_number": {
          "type": "object",
          "description": "Account number to debit from",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "payment_method": {
          "type": "object",
          "description": "Method of payment: debit_from_account, cash, buy_foreign_currency",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "payment_method"
      ],
      "additionalProperties": false
    },
    "financials_valuation": {
      "type": "object",
      "properties": {
        "currency": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string",
              "pattern": "^[A-Z]{3}$"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "total_invoice_value": {
          "type": "object",
          "properties": {
            "value": {
              "type": "number"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "exchange_rate": {
          "type": "object",
          "description": "Foreign exchange rate (e.g., VND/USD)",
          "properties": {
            "value": {
              "type": "number"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "other_charges_deductions": {
          "type": "array",
          "description": "Bank charges details (SHA/OUR/BEN)",
          "items": {
            "type": "object",
            "properties": {
              "description": {
                "type": "object",
                "properties": {
                  "value": {
                    "type": "string"
                  }
                },
                "required": [
                  "value"
                ],
                "additionalProperties": false
              }
            },
            "required": [
              "description"
            ],
            "additionalProperties": false
          }
        }
      },
      "required": [
        "currency",
        "total_invoice_value",
        "other_charges_deductions"
      ],
      "additionalProperties": false
    },
    "cargo_summary": {
      "type": "object",
      "properties": {
        "total_gross_weight_kg": {
          "type": "object",
          "properties": {
            "value": {
              "type": [
                "number",
                "null"
              ]
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "total_packages": {
          "type": "object",
          "properties": {
            "value": {
              "type": [
                "integer",
                "null"
              ]
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        },
        "total_packages_unit": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "total_gross_weight_kg",
        "total_packages",
        "total_packages_unit"
      ],
      "additionalProperties": false
    },
    "route_transport": {
      "type": "object",
      "properties": {
        "port_of_discharge": {
          "type": "object",
          "description": "Mapped to Border Gate / Customs Office (Cua Khau)",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "port_of_discharge"
      ],
      "additionalProperties": false
    },
    "origin_preference": {
      "type": "object",
      "properties": {
        "country_of_origin_preference": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string",
              "pattern": "^[A-Z]{2}$"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "country_of_origin_preference"
      ],
      "additionalProperties": false
    },
    "regulatory_oga": {
      "type": "object",
      "properties": {
        "customs_procedure_code": {
          "type": "object",
          "properties": {
            "value": {
              "type": "string"
            }
          },
          "required": [
            "value"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "customs_procedure_code"
      ],
      "additionalProperties": false
    },
    "risk_compliance": {
      "type": "object",
      "properties": {
        "sanction_screening_hits": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "entity": {
                "type": "string"
              },
              "list": {
                "type": "string"
              },
              "match_strength": {
                "type": "number"
              }
            },
            "required": [
              "entity",
              "list",
              "match_strength"
            ],
            "additionalProperties": false
          }
        },
        "red_flags": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "data_quality_score": {
          "type": "number",
          "minimum": 0,
          "maximum": 100
        },
        "ready_for_customs_filing": {
          "type": "boolean"
        },
        "missing_critical_fields": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "warnings": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      },
      "required": [
        "sanction_screening_hits",
        "red_flags",
        "data_quality_score",
        "ready_for_customs_filing",
        "missing_critical_fields",
        "warnings"
      ],
      "additionalProperties": false
    }
  },
  "required": [
    "metadata",
    "entities",
    "references",
    "dates",
    "payment_details",
    "payment_source",
    "financials_valuation",
    "cargo_summary",
    "route_transport",
    "origin_preference",
    "regulatory_oga",
    "risk_compliance"
  ],
  "additionalProperties": false
}
""")