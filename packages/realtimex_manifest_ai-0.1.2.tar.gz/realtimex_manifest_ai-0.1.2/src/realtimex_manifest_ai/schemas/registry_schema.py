# from pydantic import BaseModel, Field
import json
Registry = json.loads("""
{
    "$schema": "http://json-schema.org/draft-07/schema#",
    "description": "Registry Schema",
    "title": "registry",
    "type": "object",
    "properties": {
        "registry": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "doc_title": {
                        "type": "string",
                        "description": "Title of the document"
                    },
                    "doc_type": {
                        "type": "string",
                        "description": "Example: Commercial Invoice, Customs Declaration, Sales Contract,  Contract Annex, ..."
                    },
                    "page_start": {
                        "type": "integer"
                    },
                    "page_end": {
                        "type": "integer"
                    },
                    "key_identifiers": {
                        "type": "array",
                        "items": {
                            "type": "string"
                        }
                    }
                },
                "required": [
                    "doc_title",
                    "doc_type",
                    "page_start",
                    "page_end",
                    "key_identifiers"
                ],
                "additionalProperties": false
            }
            
        }
    },
    "required": [
        "registry"
    ],
    "additionalProperties": false
}
""")