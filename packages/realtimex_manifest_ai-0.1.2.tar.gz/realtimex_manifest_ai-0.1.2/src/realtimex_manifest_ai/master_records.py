import os
import json
from uuid import uuid4

from .litellm_utils import extract_data_to_json
from .schemas.master_records_bank_schema import MasterRecordsBank
from .registry import get_registry
from .utils import get_batch_dir, make_dir, push_messages

def get_master_records(batch_id):
    """
    Analyzes a batch of documents and determines which document should be the source
    for each field in the master records schema.

    Args:
        batch_id: The unique identifier for the document batch

    Returns:
        dict: Master records with doc_name assignments for each field

    Raises:
        ValueError: If batch_id is invalid or registry is empty
    """

    # Validate input
    if not batch_id:
        raise ValueError("batch_id cannot be empty")

    # Setup cache paths
    batch_dir = get_batch_dir(batch_id)
    master_records_file_path = f'{batch_dir}/master_records.json'

    # Create message ID for progress tracking
    message_id = str(uuid4())

    # Check cache first
    message_contents = [
        {
            "toolName": "Get Master Records",
            "toolIcon": "FileSearch",
            "mainTask": "Get Master Records",
            "task": "Getting master records from cache",
            "content": "Getting master records from cache",
            "status": "processing"
        }
    ]

    push_messages({
        "uuid": message_id,
        "type": "responseData",
        "dataType": "inlineOpen",
        "data": {
            "blockId": 1,
            "content": message_contents
        }
    })

    # Try to load from cache
    master_records = None
    if os.path.exists(master_records_file_path):
        with open(master_records_file_path, 'r', encoding='utf-8') as f:
            master_records = json.load(f)

    if master_records:
        message_contents = [
            {
                "toolName": "Get Master Records",
                "toolIcon": "FileSearch",
                "mainTask": "Get Master Records",
                "task": "Successfully loaded master records from cache",
                "content": "Successfully loaded master records from cache",
                "status": "completed"
            }
        ]
        push_messages({
            "uuid": message_id,
            "type": "responseData",
            "dataType": "inlineOpen",
            "data": {
                "blockId": 1,
                "content": message_contents
            }
        })
        return master_records

    # Get registry
    message_contents = [
        {
            "toolName": "Get Master Records",
            "toolIcon": "FileSearch",
            "mainTask": "Get Master Records",
            "task": "Loading document registry",
            "content": "Loading document registry",
            "status": "processing"
        }
    ]
    push_messages({
        "uuid": message_id,
        "type": "responseData",
        "dataType": "inlineOpen",
        "data": {
            "blockId": 1,
            "content": message_contents
        }
    })

    registry = get_registry(batch_id)

    if not registry or "registry" not in registry or len(registry["registry"]) == 0:
        raise ValueError(f"No documents found in registry for batch_id: {batch_id}")

    # Build enhanced system prompt
    system_prompt = """You are an expert document classifier specialized in international trade documentation,
including payment orders, invoices, customs declarations, bills of lading, packing lists, and commercial contracts.

### YOUR TASK
Analyze the list of documents in a batch and determine which document is the most appropriate source
for each field in the master records schema.

### DOCUMENT TYPE CHARACTERISTICS

**Payment Order / Wire Transfer Form:**
- Contains: Bank details (SWIFT codes, account numbers, bank names and addresses)
- Contains: Beneficiary information (payment recipient)
- Contains: Ordering customer information (payment initiator)
- Contains: Payment amounts, currency, exchange rates
- Contains: Payment dates (deal date, value date, execution date)
- Contains: Charge details (SHA/OUR/BEN)
- Contains: Payment purpose/description
- Contains: References to invoices and contracts

**Invoice / Commercial Invoice / Proforma Invoice:**
- Contains: Invoice number and date
- Contains: Line items with descriptions, quantities, unit prices
- Contains: Seller and buyer information
- Contains: Total amounts and currency
- Contains: Payment terms
- Contains: Incoterms (FOB, CIF, etc.)

**Customs Declaration / Import Declaration:**
- Contains: Customs declaration number
- Contains: HS codes for goods classification
- Contains: Customs procedure codes
- Contains: Border gate / port of discharge information
- Contains: Import duties and taxes
- Contains: Importer and exporter details
- Contains: Country of origin

**Bill of Lading (B/L) / Airway Bill (AWB):**
- Contains: Shipment tracking numbers
- Contains: Ports of loading and discharge
- Contains: Vessel/flight information
- Contains: Cargo description and weight
- Contains: Number of packages
- Contains: Consignee and shipper details

**Packing List:**
- Contains: Detailed package information (count, type)
- Contains: Net and gross weights
- Contains: Dimensions and volume
- Contains: Marks and numbers on packages
- Contains: Item-level packing details

**Sales Contract / Purchase Agreement:**
- Contains: Contract number and date
- Contains: Terms and conditions
- Contains: Buyer and seller obligations
- Contains: Delivery terms
- Contains: Payment terms
- Contains: Signatures and company seals

### CLASSIFICATION GUIDELINES

1. **Prioritize document types by field category:**
   - Bank details → Payment Order
   - Invoice references → Invoice or Payment Order
   - Customs info → Customs Declaration
   - Cargo details → Packing List or Bill of Lading
   - Contract references → Sales Contract or Payment Order

2. **When multiple documents could contain the same information:**
   - Prefer the PRIMARY source document for that type of information
   - Example: For invoice number, prefer "invoice.pdf" over "payment_order.pdf" even if both contain it
   - Example: For beneficiary bank details, prefer "payment_order.pdf" over "invoice.pdf"

3. **Entity mapping logic:**
   - **exporter_shipper**: Usually the seller/exporter - found in invoices, B/L, contracts
   - **consignee_buyer**: Usually the buyer/importer/ordering customer - found in payment orders, customs declarations
   - **applicant**: The party initiating the transaction - often same as consignee_buyer
   - **beneficiary**: Payment recipient (often the exporter/seller) - found in payment orders
   - **intermediary_bank**: Banking intermediary for international payments - found in payment orders

4. **Handle missing information gracefully:**
   - If no suitable document exists for a field, still assign the best available option
   - Prefer documents with related information even if not perfect match

5. **Be consistent:**
   - If multiple fields relate to the same entity, try to source them from the same document
   - Example: For beneficiary.name, beneficiary.address, beneficiary.bank_details - prefer all from payment_order.pdf

### OUTPUT REQUIREMENT
You must output strictly structured JSON matching the provided schema where each field has a "doc_name"
property containing the filename of the source document (e.g., "payment_order.pdf", "invoice.pdf").

### OPERATING PROTOCOLS
- Analyze all available documents in the batch
- Think carefully about which document type is most authoritative for each field
- Be systematic: go through each schema section and assign appropriate documents
- Ensure every required field has a document assignment
- Use the actual document filenames from the provided list
"""

    # Build field hints
    field_hints = """
### FIELD-LEVEL HINTS (Common Document Sources)

**entities.exporter_shipper:** invoice, commercial_invoice, bill_of_lading, contract
**entities.consignee_buyer:** payment_order, customs_declaration, invoice
**entities.applicant:** payment_order, application_form
**entities.beneficiary:** payment_order, wire_transfer_form
**entities.intermediary_bank:** payment_order, wire_transfer_form

**references.invoice_number:** invoice, commercial_invoice, proforma_invoice, payment_order
**references.contract_number:** contract, sales_agreement, payment_order
**references.customs_declaration_number:** customs_declaration, import_declaration

**dates.deal_date:** payment_order, wire_transfer_form
**dates.value_date:** payment_order, wire_transfer_form
**dates.payment_execution_date:** payment_order, wire_transfer_form

**payment_details.details_of_payment:** payment_order, wire_transfer_form
**payment_details.charges_type:** payment_order, wire_transfer_form

**payment_source.account_number:** payment_order, wire_transfer_form
**payment_source.payment_method:** payment_order, wire_transfer_form

**financials_valuation.currency:** invoice, payment_order, customs_declaration
**financials_valuation.total_invoice_value:** invoice, payment_order
**financials_valuation.exchange_rate:** payment_order, wire_transfer_form

**cargo_summary.total_gross_weight_kg:** packing_list, bill_of_lading, customs_declaration
**cargo_summary.total_packages:** packing_list, bill_of_lading
**cargo_summary.total_packages_unit:** packing_list, bill_of_lading

**route_transport.port_of_discharge:** bill_of_lading, customs_declaration
**origin_preference.country_of_origin_preference:** customs_declaration, certificate_of_origin
**regulatory_oga.customs_procedure_code:** customs_declaration, import_declaration
"""

    # Build document list with metadata
    documents_list = []
    for document in registry["registry"]:
        doc_name = document.get('doc_name', 'unknown')
        doc_type = document.get('doc_type', 'unknown')
        documents_list.append(f"- {doc_name} (Type: {doc_type})")

    documents_list_str = "\n".join(documents_list)

    # Construct messages
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"""Analyze the following documents and determine which document should be the source for each field in the master records schema.

### AVAILABLE DOCUMENTS IN THIS BATCH
{documents_list_str}

### INSTRUCTIONS
{field_hints}

For each field in the schema, assign the "doc_name" value to the most appropriate document filename from the list above.
Ensure you use the exact filenames as they appear in the document list.
"""},
    ]

    # Show progress: Analyzing documents
    message_contents = [
        {
            "toolName": "Get Master Records",
            "toolIcon": "FileSearch",
            "mainTask": "Get Master Records",
            "task": "Analyzing documents and mapping fields",
            "content": f"Analyzing {len(registry['registry'])} documents to determine field sources",
            "status": "processing"
        }
    ]
    push_messages({
        "uuid": message_id,
        "type": "responseData",
        "dataType": "inlineOpen",
        "data": {
            "blockId": 1,
            "content": message_contents
        }
    })

    # Extract master records using AI
    master_records = extract_data_to_json(
        model="gpt-4.1-mini",
        schema=MasterRecordsBank,
        messages=messages
    )

    # Show progress: Validating results
    message_contents = [
        {
            "toolName": "Get Master Records",
            "toolIcon": "FileSearch",
            "mainTask": "Get Master Records",
            "task": "Validating master records",
            "content": "Validating field assignments",
            "status": "processing"
        }
    ]
    push_messages({
        "uuid": message_id,
        "type": "responseData",
        "dataType": "inlineOpen",
        "data": {
            "blockId": 1,
            "content": message_contents
        }
    })

    # Validate results
    _validate_master_records(master_records, registry)

    # Save to cache
    with open(master_records_file_path, 'w', encoding='utf-8') as f:
        json.dump(master_records, f, indent=2, ensure_ascii=False)

    # Show completion
    message_contents = [
        {
            "toolName": "Get Master Records",
            "toolIcon": "FileSearch",
            "mainTask": "Get Master Records",
            "task": "Successfully generated master records",
            "content": "Successfully generated and cached master records",
            "status": "completed"
        }
    ]
    push_messages({
        "uuid": message_id,
        "type": "responseData",
        "dataType": "inlineOpen",
        "data": {
            "blockId": 1,
            "content": message_contents
        }
    })

    return master_records


def extract_master_records_data(batch_id):
    """
    Extracts actual data from documents based on master records mapping.

    This function:
    1. Loads the master records mapping (which document has which field)
    2. Reads actual data from document JSON files
    3. Extracts values for each field
    4. Saves complete master records with real data to data/bank/master_records.json

    Args:
        batch_id: The unique identifier for the document batch

    Returns:
        dict: Complete master records with actual data values
    """

    # Setup paths
    batch_dir = get_batch_dir(batch_id)
    master_records_mapping_path = f'{batch_dir}/master_records.json'
    data_dir = f'{batch_dir}/data'
    bank_dir = f'{data_dir}/bank'
    output_path = f'{bank_dir}/master_records.json'

    # Create message ID for progress tracking
    message_id = str(uuid4())

    # Check if final data already exists
    message_contents = [{
        "toolName": "Extract Master Records Data",
        "toolIcon": "Database",
        "mainTask": "Extract Master Records Data",
        "task": "Checking for cached master records data",
        "content": "Checking for cached master records data",
        "status": "processing"
    }]
    push_messages({
        "uuid": message_id,
        "type": "responseData",
        "dataType": "inlineOpen",
        "data": {"blockId": 1, "content": message_contents}
    })

    # Try to load from cache
    if os.path.exists(output_path):
        with open(output_path, 'r', encoding='utf-8') as f:
            master_records_data = json.load(f)

        message_contents = [{
            "toolName": "Extract Master Records Data",
            "toolIcon": "Database",
            "mainTask": "Extract Master Records Data",
            "task": "Successfully loaded master records data from cache",
            "content": "Successfully loaded master records data from cache",
            "status": "completed"
        }]
        push_messages({
            "uuid": message_id,
            "type": "responseData",
            "dataType": "inlineOpen",
            "data": {"blockId": 1, "content": message_contents}
        })
        return master_records_data

    # Load master records mapping
    message_contents = [{
        "toolName": "Extract Master Records Data",
        "toolIcon": "Database",
        "mainTask": "Extract Master Records Data",
        "task": "Loading master records mapping",
        "content": "Loading master records mapping",
        "status": "processing"
    }]
    push_messages({
        "uuid": message_id,
        "type": "responseData",
        "dataType": "inlineOpen",
        "data": {"blockId": 1, "content": message_contents}
    })

    if not os.path.exists(master_records_mapping_path):
        raise ValueError(f"Master records mapping not found. Please run get_master_records first.")

    with open(master_records_mapping_path, 'r', encoding='utf-8') as f:
        master_records_mapping = json.load(f)

    # Extract actual data
    message_contents = [{
        "toolName": "Extract Master Records Data",
        "toolIcon": "Database",
        "mainTask": "Extract Master Records Data",
        "task": "Extracting data from documents",
        "content": "Reading document data files and extracting values",
        "status": "processing"
    }]
    push_messages({
        "uuid": message_id,
        "type": "responseData",
        "dataType": "inlineOpen",
        "data": {"blockId": 1, "content": message_contents}
    })

    # Recursively extract data values based on mapping
    master_records_data = _extract_values_from_mapping(
        master_records_mapping,
        data_dir,
        doc_cache={},
        current_path=[]
    )

    # Save to bank directory
    make_dir(bank_dir)

    message_contents = [{
        "toolName": "Extract Master Records Data",
        "toolIcon": "Database",
        "mainTask": "Extract Master Records Data",
        "task": "Saving master records data",
        "content": f"Saving final master records to {output_path}",
        "status": "processing"
    }]
    push_messages({
        "uuid": message_id,
        "type": "responseData",
        "dataType": "inlineOpen",
        "data": {"blockId": 1, "content": message_contents}
    })

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(master_records_data, f, indent=2, ensure_ascii=False)

    message_contents = [{
        "toolName": "Extract Master Records Data",
        "toolIcon": "Database",
        "mainTask": "Extract Master Records Data",
        "task": "Successfully extracted master records data",
        "content": f"Successfully saved master records to {output_path}",
        "status": "completed"
    }]
    push_messages({
        "uuid": message_id,
        "type": "responseData",
        "dataType": "inlineOpen",
        "data": {"blockId": 1, "content": message_contents}
    })

    return master_records_data


def _extract_values_from_mapping(mapping, data_dir, doc_cache=None, current_path=None):
    """
    Recursively extracts actual values from document data files based on the mapping.

    Args:
        mapping: The master records mapping (with doc_name fields)
        data_dir: Path to the data directory containing document JSON files
        doc_cache: Cache of loaded document data (for performance)
        current_path: Current path in the structure (list of keys)

    Returns:
        dict/list: Data structure with actual values instead of doc_names
    """
    if doc_cache is None:
        doc_cache = {}
    if current_path is None:
        current_path = []

    if isinstance(mapping, dict):
        # Check if this is a field with doc_name
        if 'doc_name' in mapping:
            doc_name = mapping['doc_name']

            # Load document data if not cached
            if doc_name not in doc_cache:
                doc_path = os.path.join(data_dir, f"{doc_name}.json")
                if os.path.exists(doc_path):
                    with open(doc_path, 'r', encoding='utf-8') as f:
                        doc_cache[doc_name] = json.load(f)
                else:
                    print(f"Warning: Document data file not found: {doc_path}")
                    doc_cache[doc_name] = None

            # Return empty value structure if document not found
            if doc_cache[doc_name] is None:
                return {"value": None}

            # Navigate to the field in the document data using current_path
            doc_data = doc_cache[doc_name]
            try:
                # Navigate through the path to find the field
                for key in current_path:
                    if isinstance(doc_data, dict) and key in doc_data:
                        doc_data = doc_data[key]
                    else:
                        # Path not found in document
                        return {"value": None}

                # Extract the value
                if isinstance(doc_data, dict) and 'value' in doc_data:
                    return {"value": doc_data['value']}
                else:
                    return {"value": None}

            except (KeyError, TypeError) as e:
                print(f"Warning: Could not extract value from path {'.'.join(current_path)} in {doc_name}: {e}")
                return {"value": None}

        # Recursively process all fields in the object
        result = {}
        for key, value in mapping.items():
            # Add current key to path for nested traversal
            new_path = current_path + [key]
            result[key] = _extract_values_from_mapping(value, data_dir, doc_cache, new_path)
        return result

    elif isinstance(mapping, list):
        # Process array items
        return [_extract_values_from_mapping(item, data_dir, doc_cache, current_path) for item in mapping]

    else:
        # Primitive value, return as-is
        return mapping


def _validate_master_records(master_records, registry):
    """
    Validates that the master records have proper document assignments.

    Args:
        master_records: The generated master records dictionary
        registry: The document registry

    Raises:
        Warning: If suspicious assignments are detected
    """
    # Get list of valid document names
    valid_doc_names = set(doc['doc_name'] for doc in registry['registry'])

    # Track all assigned doc_names
    assigned_docs = set()

    def check_doc_name(obj, path=""):
        """Recursively check all doc_name fields"""
        if isinstance(obj, dict):
            if 'doc_name' in obj:
                doc_name = obj['doc_name']
                assigned_docs.add(doc_name)
                # Validate doc_name exists in registry
                if doc_name and doc_name not in valid_doc_names:
                    print(f"WARNING: Invalid doc_name '{doc_name}' at {path} - not found in registry")
            for key, value in obj.items():
                check_doc_name(value, f"{path}.{key}" if path else key)
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                check_doc_name(item, f"{path}[{i}]")

    check_doc_name(master_records)

    # Report statistics
    print(f"Master records validation complete:")
    print(f"- Total documents in batch: {len(valid_doc_names)}")
    print(f"- Documents assigned to fields: {len(assigned_docs)}")
    print(f"- Assigned documents: {', '.join(sorted(assigned_docs))}")

    # Check if any documents were not used
    unused_docs = valid_doc_names - assigned_docs
    if unused_docs:
        print(f"- Unused documents: {', '.join(sorted(unused_docs))}")