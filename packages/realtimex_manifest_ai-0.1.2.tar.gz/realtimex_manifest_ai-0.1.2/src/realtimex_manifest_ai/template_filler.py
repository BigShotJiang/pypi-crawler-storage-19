"""Template filling utility for HTML templates with master records data"""

import re
import json


def number_to_words(num):
    """Convert number to words (English)"""
    if num is None:
        return "N/A"

    if not isinstance(num, (int, float)):
        return str(num)

    num = int(num)

    ones = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]
    teens = ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
             "sixteen", "seventeen", "eighteen", "nineteen"]
    tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
    thousands = ["", "thousand", "million", "billion"]

    if num == 0:
        return "zero"

    def convert_hundreds(n):
        if n == 0:
            return ""
        elif n < 10:
            return ones[n]
        elif n < 20:
            return teens[n - 10]
        elif n < 100:
            return tens[n // 10] + (" " + ones[n % 10] if n % 10 != 0 else "")
        else:
            return ones[n // 100] + " hundred" + (" " + convert_hundreds(n % 100) if n % 100 != 0 else "")

    if num < 1000:
        return convert_hundreds(num)

    # Handle thousands, millions, etc.
    parts = []
    thousand_idx = 0

    while num > 0:
        if num % 1000 != 0:
            parts.append(convert_hundreds(num % 1000) + " " + thousands[thousand_idx])
        num //= 1000
        thousand_idx += 1

    return " ".join(reversed(parts)).strip()


def get_nested_value(data, path):
    """Get value from nested dict using dot notation path"""
    try:
        keys = path.split('.')
        value = data

        for key in keys:
            if isinstance(value, dict):
                value = value.get(key)
            else:
                return None

        return value
    except:
        return None


def fill_template(html_content, data):
    """
    Fill HTML template with data from master records.

    Args:
        html_content: HTML template string with ##$...## placeholders
        data: Master records data dictionary

    Returns:
        Filled HTML string
    """

    # Find all placeholders
    placeholders = re.findall(r'##\$\.(.*?)##', html_content)

    # Replace placeholders
    for placeholder in placeholders:
        # Remove .value suffix if present
        path = placeholder
        if path.endswith('.value'):
            path = path[:-6]  # Remove '.value'

        # Get the value from data
        value = get_nested_value(data, path)

        # If value is a dict with 'value' key, extract it
        if isinstance(value, dict) and 'value' in value:
            value = value['value']

        # Convert None to empty string
        if value is None:
            value = ""

        # Replace in template
        full_placeholder = f"##$.{placeholder}##"
        html_content = html_content.replace(full_placeholder, str(value))

    # Handle special functions (amount_in_words)
    amount_in_words_matches = re.findall(r'##amount_in_words\(\$\.(.*?)\)##', html_content)

    for match in amount_in_words_matches:
        # Get the amount value
        path = match
        if path.endswith('.value'):
            path = path[:-6]

        value = get_nested_value(data, path)
        if isinstance(value, dict) and 'value' in value:
            value = value['value']

        # Convert to words
        if value:
            words = number_to_words(value)
            full_placeholder = f"##amount_in_words($.{match})##"
            html_content = html_content.replace(full_placeholder, words.upper())
        else:
            full_placeholder = f"##amount_in_words($.{match})##"
            html_content = html_content.replace(full_placeholder, "N/A")

    # Fix currency field (currencyz -> currency)
    currency_value = get_nested_value(data, 'financials_valuation.currency')
    if isinstance(currency_value, dict) and 'value' in currency_value:
        currency_value = currency_value['value']

    html_content = html_content.replace(
        '##$.financials_valuation.currencyz.value##',
        str(currency_value or 'USD')
    )

    return html_content


def fill_template_file(template_path, data_path, output_path):
    """
    Fill HTML template file with data from JSON file.

    Args:
        template_path: Path to HTML template file
        data_path: Path to master records JSON file
        output_path: Path to save filled HTML

    Returns:
        Path to output file
    """
    # Load template
    with open(template_path, 'r', encoding='utf-8') as f:
        html_content = f.read()

    # Load data
    with open(data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # Fill template
    filled_html = fill_template(html_content, data)

    # Save filled template
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(filled_html)

    return output_path
