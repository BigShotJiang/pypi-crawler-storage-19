# /// script
# requires-python = ">=3.9"
# dependencies = [
#     "fastapi",
#     "uvicorn",
#     "pydantic",
#     "jinja2",
#     "python-multipart",
#     "pymupdf",
#     "google-cloud-vision",
#     "google-auth"
# ]
# ///

import os
import json
from typing import Optional
from uuid import uuid4

# Import our schema and LangChain libs
from .schemas.registry_schema import Registry

from .litellm_utils import extract_data_to_json
from .pdf import extract_pages
from .utils import to_snake, make_dir, get_batch_dir, remove_dir, push_messages

def get_registry(batch_id, file_path=None, message=None):
    batch_dir = get_batch_dir(batch_id)
    registry_file_path = f'{batch_dir}/registry.json'

    message_id = str(uuid4())
    message_contents = [
        {
            "toolName": "Get Document Registry",
            "toolIcon": "Terminal",
            
            "mainTask": "Get Document Registry",
            "task": "Getting document registry from cache",
            "content": "Getting document registry from cache",
            
            "status": "processing"
        }
    ]

    push_messages(
        {
            "uuid": message_id,
            "type": "responseData",
            "dataType": "inlineOpen",
            "data": {
                "blockId": 1,
                "content": message_contents
            }
        }
    )

    registry = None
    if os.path.exists(registry_file_path):
        with open(registry_file_path, 'r') as my_file:
            registry = json.load(my_file)

    if registry:
        message_contents = [
            {
                "toolName": "Get Document Registry",
                "toolIcon": "Terminal",
                
                "mainTask": "Get Document Registry",
                "task": "Successfully get document registry from cache",
                "content": "Successfully get document registry from cache",
                
                "status": "completed"
            }
        ]
        push_messages({
            
                "uuid": message_id,
                "type": "responseData",
                "dataType": "inlineOpen",
                "data": {
                    "blockId": 1,
                    "content": message_contents
                }
            
        })
        return registry

    system_prompt = f"""You are best at analyze documents.
Your task is to analyze a stream of documents.

### OUTPUT REQUIREMENT
You must output strictly structured JSON matching the provided schema.

### OPERATING PROTOCOLS: DYNAMIC CLASSIFICATION (`registry`)
- Page index ALWAYS starts from 0
- Scan the PDF text. Break it down into logical documents. Record start/end pages.
"""

    messages=[
    {"role": "system", "content": system_prompt},
        {"role": "user", "content": [
                {
                    "type": "file",
                    "file": f"file:{file_path}"
                }
            ]
        }
    ]

    message_contents = [
        {
            "toolName": "Get Document Registry",
            "toolIcon": "Terminal",
            
            "mainTask": "Get Document Registry",
            "task": "Extracting document registry",
            "content": "Extracting document registry",
            
            "status": "processing"
        }
    ]
    push_messages({
        
            "uuid": message_id,
            "type": "responseData",
            "dataType": "inlineOpen",
            "data": {
                "blockId": 1,
                "content": message_contents
            }
        
    })
  
    registry = extract_data_to_json(
        model="claude-sonnet-4-5",
        schema=Registry,
        messages=messages
    )


    message_contents = [
        {
            "toolName": "Get Document Registry",
            "toolIcon": "Terminal",
            
            "mainTask": "Get Document Registry",
            "task": "Spliting document by registry",
            "content": "Spliting document by registry",
            
            "status": "processing"
        }
    ]
    push_messages({
        
            "uuid": message_id,
            "type": "responseData",
            "dataType": "inlineOpen",
            "data": {
                "blockId": 1,
                "content": message_contents
            }
        
    })

    # Split document
    registry = split_document_by_registry(batch_id,file_path,registry)

    with open(registry_file_path, 'w') as my_file:
        my_file.write(json.dumps(registry))

    message_contents.pop()
    message_contents = [
        {
            "toolName": "Get Document Registry",
            "toolIcon": "Terminal",
            
            "mainTask": "Get Document Registry",
            "task": "Successfully document registry",
            "content": "Successfully document registry",
            
            "status": "completed"
        }
    ]
    push_messages({
        
            "uuid": message_id,
            "type": "responseData",
            "dataType": "inlineOpen",
            "data": {
                "blockId": 1,
                "content": message_contents
            }
        
    })

    return registry

def split_document_by_registry(batch_id,file_path,registry,reset=True):
    document_dir = os.path.join(get_batch_dir(batch_id), "documents")

    if reset:
        remove_dir(document_dir)

    make_dir(document_dir)

    segment_id = 0
    for segment in registry["registry"]:
        output_pdf = os.path.join(document_dir,f"{to_snake(segment['doc_type'])}.pdf")
        index = 1
        while os.path.exists(output_pdf):
            output_pdf = os.path.join(document_dir,f"{to_snake(segment['doc_type'])}_{index}.pdf")
            index = index + 1
        registry["registry"][segment_id]["doc_name"] = os.path.basename(output_pdf)
        segment_id = segment_id + 1
        extract_pages(file_path,output_pdf,segment["page_start"],segment["page_end"])

    return registry


