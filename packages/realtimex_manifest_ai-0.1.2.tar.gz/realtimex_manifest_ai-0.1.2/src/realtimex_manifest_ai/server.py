# /// script
# dependencies = [
#   "fastapi",
#   "uvicorn",
# ]
# requires-python = ">=3.10"
# ///

import os
import json
import shutil
from typing import Optional
from fastapi import FastAPI, Request, HTTPException, Query
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from .utils import get_batch_data_dir, get_manifest_cache_dir, get_this_app_dir

# Use cache directory for batch data (runtime data)
DATA_DIR = get_batch_data_dir()

# Templates will be copied to cache and served from there
PACKAGE_TEMPLATES_DIR = os.path.join(get_this_app_dir(), "templates")
CACHE_DIR = get_manifest_cache_dir()
CACHE_TEMPLATES_DIR = os.path.join(get_manifest_cache_dir(), "templates")

app = FastAPI(title="Document Validator API")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)

PORT = 8000

# --- Template Management ---

def prepare_templates():
    """
    Prepare templates in cache directory:
    1. Remove existing templates in cache (if any)
    2. Copy fresh templates from package to cache

    This ensures:
    - Users always get latest templates on server restart
    - Templates can be customized in cache between restarts
    - Fresh start with each server launch
    """
    print("🎨 Preparing templates...")

    # Remove old templates from cache if they exist
    if os.path.exists(CACHE_TEMPLATES_DIR):
        print(f"   Removing old templates from cache...")
        shutil.rmtree(CACHE_TEMPLATES_DIR)
        print(f"   ✓ Old templates removed")

    # Copy fresh templates from package to cache
    if not os.path.exists(PACKAGE_TEMPLATES_DIR):
        raise RuntimeError(f"Package templates not found: {PACKAGE_TEMPLATES_DIR}")

    print(f"   Copying templates to cache...")
    shutil.copytree(PACKAGE_TEMPLATES_DIR, CACHE_TEMPLATES_DIR)

    # Count files copied
    file_count = sum(1 for _, _, files in os.walk(CACHE_TEMPLATES_DIR) for _ in files)
    print(f"   ✓ Copied {file_count} template files to cache")
    print()

# --- Helper Functions ---

def get_user_data_dir(batch_id: Optional[str] = None):
    if batch_id:
        return os.path.join(DATA_DIR, batch_id, "user_data")
    return None

def get_user_data_file(filename: str, batch_id: Optional[str] = None):
    return os.path.join(get_user_data_dir(batch_id), filename)

def read_json_file(filename: str, batch_id: Optional[str], default):
    filepath = get_user_data_file(filename, batch_id)
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading {filename}: {e}")
    return default

def save_json_file(filename: str, data, batch_id: Optional[str]):
    user_data_dir = get_user_data_dir(batch_id)
    os.makedirs(user_data_dir, exist_ok=True)
    filepath = get_user_data_file(filename, batch_id)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"Saved {filename} to {filepath}")

# --- API Endpoints ---

@app.get("/api/overrides")
async def get_overrides(batch_id: Optional[str] = Query(None)):
    return read_json_file("overrides.json", batch_id, {})

@app.post("/api/overrides")
async def post_overrides(request: Request, batch_id: Optional[str] = Query(None)):
    try:
        data = await request.json()
        save_json_file("overrides.json", data.get('overrides', {}), batch_id)
        save_json_file("changelog.json", data.get('changelog', []), batch_id)
        save_json_file("dismissed_ai.json", data.get('dismissedAI', {}), batch_id)
        return {"success": True, "message": "Overrides saved successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/changelog")
async def get_changelog(batch_id: Optional[str] = Query(None)):
    return read_json_file("changelog.json", batch_id, [])

@app.get("/api/verifications")
async def get_verifications(batch_id: Optional[str] = Query(None)):
    return read_json_file("verifications.json", batch_id, {'verifications': {}, 'autoMarkOnEdit': None})

@app.post("/api/verifications")
async def post_verifications(request: Request, batch_id: Optional[str] = Query(None)):
    data = await request.json()
    save_json_file("verifications.json", data, batch_id)
    return {"success": True}

@app.get("/api/masters")
async def get_masters(batch_id: Optional[str] = Query(None)):
    return read_json_file("masters.json", batch_id, {})

@app.post("/api/masters")
async def post_masters(request: Request, batch_id: Optional[str] = Query(None)):
    data = await request.json()
    save_json_file("masters.json", data, batch_id)
    return {"success": True}

@app.get("/api/hidden-docs")
async def get_hidden_docs(batch_id: Optional[str] = Query(None)):
    return read_json_file("hidden_docs.json", batch_id, {})

@app.post("/api/hidden-docs")
async def post_hidden_docs(request: Request, batch_id: Optional[str] = Query(None)):
    data = await request.json()
    save_json_file("hidden_docs.json", data, batch_id)
    return {"success": True}

@app.get("/api/dismissed-ai")
async def get_dismissed_ai(batch_id: Optional[str] = Query(None)):
    return read_json_file("dismissed_ai.json", batch_id, {})

@app.get("/api/notes")
async def get_notes(batch_id: Optional[str] = Query(None)):
    filepath = get_user_data_file("notes.md", batch_id)
    content = ""
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    return PlainTextResponse(content)

@app.post("/api/notes")
async def post_notes(request: Request, batch_id: Optional[str] = Query(None)):
    body = await request.body()
    content = body.decode('utf-8')
    user_data_dir = get_user_data_dir(batch_id)
    os.makedirs(user_data_dir, exist_ok=True)
    filepath = get_user_data_file("notes.md", batch_id)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    return {"success": True}

@app.get("/api/annotations")
async def get_annotations(batch_id: Optional[str] = Query(None)):
    return read_json_file("annotations.json", batch_id, {"annotations": [], "markdown": ""})

@app.post("/api/annotations")
async def post_annotations(request: Request, batch_id: Optional[str] = Query(None)):
    data = await request.json()
    save_json_file("annotations.json", data, batch_id)
    return {"success": True}

@app.get("/api/batches")
async def get_batches():
    """List all batch folders in batch_data directory"""
    batch_dir = DATA_DIR
    batches = []
    if os.path.exists(batch_dir):
        for name in os.listdir(batch_dir):
            folder_path = os.path.join(batch_dir, name)
            if os.path.isdir(folder_path) and not name.startswith('.'):
                batches.append({
                    "id": name,
                    "name": name,
                    "path": folder_path
                })
    return {"batches": batches}

@app.post("/api/upload")
async def upload_file(request: Request):
    """Placeholder endpoint for file upload - TODO: Implement actual upload logic"""
    import asyncio
    # TODO: Implement file upload logic
    # - Accept multipart/form-data with python-multipart package
    # - Parse files from request: files = await request.form()
    # - Save file to appropriate location in batch_data/
    # - Process uploaded file (OCR, analysis, etc.)
    # - Create new batch folder structure
    
    # Simulate processing delay for UI testing
    await asyncio.sleep(2)
    
    return JSONResponse(
        status_code=200,
        content={"success": True, "message": "TODO: Implement file upload logic"}
    )
@app.get("/api/ai-enhanced/{doc_name}")
async def get_ai_enhanced(doc_name: str, batch_id: Optional[str] = Query(None)):
    if batch_id:
        enhanced_file = os.path.join(DATA_DIR, batch_id, 'enhanced_data', f'{doc_name}.json')
    else:
        enhanced_file = os.path.join('enhanced_data', f'{doc_name}.json')
    
    if os.path.exists(enhanced_file):
        with open(enhanced_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    raise HTTPException(status_code=404, detail="No AI enhanced data found")

# --- Static File Serving ---
# This must come AFTER API routes so it doesn't intercept them
# Serve templates from cache directory (copied fresh on startup)
app.mount("/", StaticFiles(directory=CACHE_DIR, html=True), name="static")

def main():
    print("=" * 80)
    print(f"🚀 Manifest AI Server Starting")
    print("=" * 80)
    print()

    # Prepare templates in cache (remove old, copy fresh)
    prepare_templates()

    print(f"📁 Batch Data Directory: {DATA_DIR}")
    print(f"📦 Package Templates: {PACKAGE_TEMPLATES_DIR}")
    print(f"🎨 Cache Templates (serving from): {CACHE_TEMPLATES_DIR}")
    print()

    # Check if batch data exists
    if not os.path.exists(DATA_DIR) or not os.listdir(DATA_DIR):
        print("⚠️  WARNING: No batch data found in cache directory!")
        print()
        print("To setup sample data, run:")
        print("  python examples/setup_samples.py")
        print()
        print("Or place your batch data in:")
        print(f"  {DATA_DIR}")
        print()
    else:
        batches = [d for d in os.listdir(DATA_DIR) if os.path.isdir(os.path.join(DATA_DIR, d)) and not d.startswith('.')]
        print(f"✓ Found {len(batches)} batch(es) in cache:")
        for batch_id in batches[:5]:  # Show first 5
            print(f"  - {batch_id}")
        if len(batches) > 5:
            print(f"  ... and {len(batches) - 5} more")
        print()

    print(f"🌐 Server URL: http://localhost:{PORT}")
    print(f"📊 Dashboard: http://localhost:{PORT}/templates?batch_id=<BATCH_ID>")
    print()
    print("=" * 80)

    uvicorn.run(app, host="0.0.0.0", port=PORT)

if __name__ == "__main__":
    main()

# def run_server():
#     """Starts the server in a background thread"""
#     import threading
#     # Define the thread
#     server_thread = threading.Thread(
#         target=uvicorn.run,
#         kwargs={
#             "app": app,
#             "host": "0.0.0.0",
#             "port": PORT,
#             "log_level": "info",
#         },
#         daemon=True  # Optional: Thread will exit automatically when main program exits
#     )
    
#     server_thread.start()
#     print(f"Server started in background thread at http://localhost:{PORT}")
#     return server_thread

# if __name__ == "__main__":
#     server_thread = run_server()
#     mcp.run()