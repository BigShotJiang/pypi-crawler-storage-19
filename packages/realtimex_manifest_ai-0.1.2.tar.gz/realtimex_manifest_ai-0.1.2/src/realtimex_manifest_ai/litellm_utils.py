import json
import base64
from .utils import get_file_mime_type
import requests

# --- AI ANALYSIS ENGINE ---
def extract_data_to_json(messages,schema,model="claude-sonnet-4-5"):

    clean_messages = []
    for message in messages:
        if not message:
            continue
        if isinstance(message['content'], str):
            clean_messages.append(message)
            continue
        clean_contents = []
        for content in message['content']:
            if content["type"] == "file":
                file_path = content["file"].replace("file:","")
                encoded_file = None
                with open(file_path, "rb") as file:
                    encoded_file = base64.b64encode(file.read()).decode("utf-8")
                if encoded_file:
                    content["file"] = {
                        "file_data": f"data:{get_file_mime_type(file_path)};base64,{encoded_file}"
                    }
            
            clean_contents.append(content)
        message['content'] = clean_contents
        clean_messages.append(message)


    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer sk-',
    }

    # print(schema)

    json_data = {
        'model': model,
        'messages': clean_messages,
        'response_format': {
            'type': 'json_schema',
            'json_schema': {
                'name': 'response',
                'strict': True,
                'schema': schema
            },
        },
    }

    response = requests.post('https://realtimexai-llm-provider.realtimex.ai/chat/completions', headers=headers, json=json_data)
    
    print(response.text)
    response = response.json()

    return json.loads(response["choices"][0]["message"]["content"])
