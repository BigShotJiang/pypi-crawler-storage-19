
def get_base_user_dir():
    import os
    return os.path.expanduser("~")

def get_realtimex_dir():
    """Get the base RealTimeX directory: ~/.realtimex.ai"""
    import os
    return os.path.join(get_base_user_dir(), ".realtimex.ai")

def get_this_app_dir():
    """Get the package installation directory (READ-ONLY after pip install)"""
    import os
    from pathlib import Path
    package_dir = Path(__file__).resolve().parent
    return package_dir

def get_manifest_cache_dir():
    """
    Get the cache directory for manifest-ai runtime data (READ-WRITE).
    This is where batch data should be stored.
    Returns: ~/.realtimex.ai/Resources/agent-resources/manifest-ai
    """
    import os
    cache_dir = os.path.join(
        get_realtimex_dir(),
        "Resources",
        "agent-resources",
        "manifest-ai"
    )
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir

def get_batch_data_dir():
    """
    Get the batch data directory (READ-WRITE).
    All runtime batch data should be stored here.
    Returns: ~/.realtimex.ai/Resources/agent-resources/manifest-ai/batch_data
    """
    import os
    batch_data_dir = os.path.join(get_manifest_cache_dir(), "batch_data")
    os.makedirs(batch_data_dir, exist_ok=True)
    return batch_data_dir

def get_batch_dir(batch_id):
    """
    Get the directory for a specific batch (READ-WRITE).
    Creates the directory if it doesn't exist.

    Args:
        batch_id: The batch ID

    Returns:
        Path to batch directory: ~/.realtimex.ai/Resources/agent-resources/manifest-ai/batch_data/{batch_id}
    """
    import os
    batch_dir = os.path.join(get_batch_data_dir(), batch_id)
    os.makedirs(batch_dir, exist_ok=True)
    return batch_dir

# Deprecated functions - kept for backward compatibility
def get_app_dir():
    """DEPRECATED: Use get_manifest_cache_dir() instead"""
    return get_manifest_cache_dir()

def get_cache_dir():
    """DEPRECATED: Use get_manifest_cache_dir() instead"""
    import os
    cache_dir = os.path.join(os.path.expanduser("~"), ".cache")
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir

def prepare_data_dir():
    """DEPRECATED: Sample data is now in examples/ directory. Use examples/setup_samples.py instead."""
    import os
    import warnings
    warnings.warn(
        "prepare_data_dir() is deprecated. "
        "Sample data is now in examples/ directory. "
        "Use 'python examples/setup_samples.py' to setup sample data.",
        DeprecationWarning
    )
    return get_batch_data_dir()

def prepare_templates_dir():
    """DEPRECATED: Templates are served from package directory"""
    import os
    import warnings
    warnings.warn(
        "prepare_templates_dir() is deprecated. "
        "Templates are now served directly from the package directory.",
        DeprecationWarning
    )
    return os.path.join(get_this_app_dir(), "templates")


def load_env_configs():
    from dotenv import dotenv_values
    import os

    env_file_path = os.path.join(get_realtimex_dir(),"Resources","server",".env.development")
    if os.path.exists(env_file_path):
        env_configs = dotenv_values(env_file_path)
        return env_configs
    return None

def to_snake(text: str) -> str:
    import re
    # Remove extra spaces
    text = text.strip()

    # If contains spaces, split into words first
    if " " in text:
        parts = text.split()
        text = "".join(word[0].upper() + word[1:] for word in parts)

    # Convert CamelCase → snake_case
    s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", text)
    s2 = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1)

    return s2.lower()


def get_file_hash(file_path):
    import sys
    import hashlib

    # BUF_SIZE is totally arbitrary, change for your app!
    BUF_SIZE = 65536  # lets read stuff in 64kb chunks!

    sha1 = hashlib.sha1()

    with open(file_path, 'rb') as f:
        while True:
            data = f.read(BUF_SIZE)
            if not data:
                break
            sha1.update(data)
    return str(sha1.hexdigest())

def make_dir(dir):
    import os
    if not os.path.exists(dir):
        os.makedirs(dir,exist_ok=True)
        
def remove_dir(dir):
    import os
    import shutil
    if os.path.exists(dir):
        shutil.rmtree(dir)

def get_file_mime_type(filename):
    import mimetypes
    """
    Guesses the MIME type of a file based on its filename extension.
    Returns the MIME type string, or 'application/octet-stream' if not found.
    """
    # guess_type returns a tuple (type, encoding). We only need the type.
    mime_type, _ = mimetypes.guess_type(filename)
    return mime_type or "application/octet-stream"

def push_messages(message_content):
    import os
    current_session_id = os.getenv("SESSION_ID")
    # current_session_id = "4230723f-2110-43f1-a540-0c5b419ff2a7"
    if not current_session_id:
        return None

    import redis
    import json

    if "uuid" not in message_content:
        from uuid import uuid4
        message_content['uuid'] = str(uuid4())

    pool = redis.ConnectionPool(host='127.0.0.1', port=6379, db=1)
    r = redis.Redis(connection_pool=pool)

    print("message_content_2",message_content)

    pub = r.publish(
        current_session_id,
        f'.message {json.dumps(message_content)}'
    )

def fix_schema_strict(schema):
    """
    Recursively fixes a JSON schema to comply with strict mode requirements:
    - For all objects with 'properties', ensures all property keys are in 'required'
    - Adds 'additionalProperties': false to all objects

    Args:
        schema: A JSON schema dictionary

    Returns:
        The fixed schema dictionary (modified in place)
    """
    if not isinstance(schema, dict):
        return schema

    # If this is an object type with properties
    if schema.get("type") == "object" and "properties" in schema:
        properties = schema["properties"]

        # Collect all property keys
        property_keys = list(properties.keys())

        # Set required to include all properties
        schema["required"] = property_keys

        # Add additionalProperties: false
        schema["additionalProperties"] = False

        # Recursively fix all nested properties
        for prop_key, prop_value in properties.items():
            fix_schema_strict(prop_value)

    # If this is an array type, fix the items schema
    elif schema.get("type") == "array" and "items" in schema:
        fix_schema_strict(schema["items"])

    # Recursively process all nested objects
    for key, value in schema.items():
        if isinstance(value, dict) and key not in ["properties", "items"]:
            fix_schema_strict(value)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    fix_schema_strict(item)

    return schema