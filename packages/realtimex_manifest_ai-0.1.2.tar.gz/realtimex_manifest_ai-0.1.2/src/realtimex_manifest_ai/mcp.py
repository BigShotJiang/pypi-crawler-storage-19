# /// script
# dependencies = [
#   "PyPDF2",
#   "fastapi",
#   "uvicorn",
#   "fastmcp",
#   "redis"
# ]
# requires-python = ">=3.10"
# ///

# server.py
# from server import run_server

from fastmcp import FastMCP, Client, Context

import os
import json
import asyncio
import pkgutil

from typing import List, Dict, Optional, Union

from .utils import get_manifest_cache_dir, push_messages

mcp = FastMCP("RealTimeX.AI Document Manifest Tools")

@mcp.tool
async def get_document_batch_id(file_path:str) -> str:
    """Get document batch id."""
    from .batch import get_batch_id
    return get_batch_id(file_path)

@mcp.tool
async def get_document_registry(batch_id:str, file_path:str) -> Dict:
    """Get registry of document."""
    from .registry import get_registry

    registry = get_registry(batch_id,file_path)

    files_content = []
    for doc in registry["registry"]:
        files_content.append({
            "type": "document",
            "url" : f"{get_manifest_cache_dir()}/batch_data/{batch_id}/documents/{doc['doc_name']}",
            "mime" :  "application/pdf",
        })


    message = {
        "type": "responseData",
        "dataType": "files",
        "data": {
            "content": files_content
        }
    }
    push_messages(message)

    return registry

@mcp.tool
async def get_master_records(batch_id:str) -> Dict:
    """Get master records mapping - determines which document contains each field."""
    from .master_records import get_master_records

    master_records = get_master_records(batch_id)

    return master_records

@mcp.tool
async def extract_master_records_data(batch_id:str) -> Dict:
    """Extract actual data from documents and create final master records with real values."""
    from .master_records import extract_master_records_data

    master_records_data = extract_master_records_data(batch_id)

    return master_records_data

@mcp.tool
async def show_manifest_dashboard(batch_id:str) -> Dict:
    """Show manifest result of document."""
    result = {
        "status": "success",
        "overall_analysis_status": "NEEDS_REVIEW",
        "insights": [
            "Third-Party Payment detected: Payment is routed to a Hong Kong entity while goods originate from Mainland China (Guangxi). This structure is often used for tax optimization or capital control evasion.",
            "Contract Appendix (Page 4) explicitly designates the third-party beneficiary, legally linking the discrepancy, but the KYC risk remains high.",
            "The Incoterm is DAF (Delivered At Frontier), consistent with the land border crossing at Huu Nghi / Pingxiang indicated in the address details."
        ],
        "recommended_actions": [
            "Verify the Third Party Payment Agreement specifically covers AML/CFT liability.",
            "Request UBO (Ultimate Beneficial Owner) confirmation for 'HONG KONG WIN - WIN INTERNATIONAL' to ensure no sanctioned links exist."
        ],
        "ui-components":[
            {
                "dataType": "mcpUi",
                "data": {
                    "content": [
                        {
                            "type": "resource",
                            "resource": {
                            "uri": f'ui://doc-manifest/{batch_id}',
                            "mimeType": "text/uri-list",
                            "text": f'http://localhost:8000/templates/summary.html?batch_id={batch_id}&theme=light',
                            }
                        }
                    ]
                }
            }
        ]
    }
    return result

@mcp.tool
async def analyze_with_bank_flow(batch_id:str) -> Dict:
    """Show manifest result of document."""
    result = {
        "status": "success",
        "overall_analysis_status": "NEEDS_REVIEW",
        "insights": [
            "Third-Party Payment detected: Payment is routed to a Hong Kong entity while goods originate from Mainland China (Guangxi). This structure is often used for tax optimization or capital control evasion.",
            "Contract Appendix (Page 4) explicitly designates the third-party beneficiary, legally linking the discrepancy, but the KYC risk remains high.",
            "The Incoterm is DAF (Delivered At Frontier), consistent with the land border crossing at Huu Nghi / Pingxiang indicated in the address details."
        ],
        "recommended_actions": [
            "Verify the Third Party Payment Agreement specifically covers AML/CFT liability.",
            "Request UBO (Ultimate Beneficial Owner) confirmation for 'HONG KONG WIN - WIN INTERNATIONAL' to ensure no sanctioned links exist."
        ],
        "ui-components":[
            {
                "dataType": "mcpUi",
                "data": {
                    "content": [
                        {
                            "type": "resource",
                            "resource": {
                            "uri": f'ui://doc-manifest/{batch_id}',
                            "mimeType": "text/uri-list",
                            "text": f'http://localhost:8000/templates/summary.html?batch_id={batch_id}&theme=light',
                            }
                        }
                    ]
                }
            }
        ]
    }
    return result

@mcp.tool
async def export_payment_order(batch_id:str) -> Dict:
    """Export the payment order filled with actual data from master records."""
    import os
    from .master_records import extract_master_records_data
    from .template_filler import fill_template_file
    from .utils import get_batch_dir

    # Setup paths
    batch_dir = get_batch_dir(batch_id)
    template_path = os.path.join(batch_dir, "outputs", "payment_order.html")
    data_path = os.path.join(batch_dir, "data", "bank", "master_records.json")
    output_path = os.path.join(batch_dir, "outputs", "payment_order_filled.html")

    # Ensure master records data exists
    if not os.path.exists(data_path):
        # Extract master records data if not exists
        extract_master_records_data(batch_id)

    # Fill template with data
    fill_template_file(template_path, data_path, output_path)

    # Return filled payment order
    result = {
        "status": "success",
        "message": "Payment order exported successfully with actual data",
        "ui-components":[
            {
                "dataType": "files",
                "data": {
                    "content": [
                        {
                            "type": "document",
                            "url": f"{get_manifest_cache_dir()}/batch_data/{batch_id}/outputs/payment_order_filled.html",
                            "mime": "text/html",
                        }
                    ]
                }
            }
        ]
    }
    return result

def main(): 
    mcp.run()

if __name__ == "__main__":
    pass
    # mcp.run()
    # batch_id = "c45cd2fbfa40c4663862ec723ef17a5fd17635dd"
    # file_path = "/Users/phuongnguyen/.realtimex.ai/Resources/agent-resources/manifest-ai/batch_data/c45cd2fbfa40c4663862ec723ef17a5fd17635dd/BATCH-VN-CN-2021-9982.pdf"
    # # from registry import get_registry
    # # registry = get_registry(batch_id,file_path)
    # from master_records import get_master_records
    # master_records = get_master_records(batch_id)
    # print(json.dumps(master_records,indent=2))