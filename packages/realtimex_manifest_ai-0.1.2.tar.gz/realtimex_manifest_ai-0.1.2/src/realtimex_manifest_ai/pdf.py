from PyPDF2 import PdfReader, PdfWriter

def extract_pages(input_pdf, output_pdf, start_page, end_page):
    """
    Extract pages from start_page to end_page (0-based index)
    and save to a new PDF.
    """
    reader = PdfReader(input_pdf)
    writer = PdfWriter()

    # Safety check
    end_page = min(end_page, len(reader.pages) - 1)

    for i in range(start_page, end_page + 1):
        writer.add_page(reader.pages[i])

    with open(output_pdf, "wb") as f:
        writer.write(f)

def export_pages_as_images(input_pdf,output_dir):
    import os
    import fitz

    os.makedirs(output_dir, exist_ok=True)

    doc = fitz.open(input_pdf)
    new_doc = fitz.open()

    for i, page in enumerate(doc):
        print(f"Processing page {i+1}/{len(doc)} ...")

        # Check if page has text
        text = page.get_text().strip()
        if text:
            # ---- TEXT PAGE → convert to image ----
            pix = page.get_pixmap(dpi=200)  # Render to image
            img_bytes = pix.tobytes("png")

            # Save image to folder
            img_path = os.path.join(output_dir, f"page_{i}.png")
            pix.save(img_path)

            # Add as new image-only page
            rect = fitz.Rect(0, 0, pix.width, pix.height)
            new_page = new_doc.new_page(width=pix.width, height=pix.height)
            new_page.insert_image(rect, stream=img_bytes)

        else:
            # ---- IMAGE PAGE → extract original images ----
            img_list = page.get_images(full=True)
            if not img_list:
                # No visible text + no images = probably blank page -> render as fallback
                pix = page.get_pixmap(dpi=200)
                img_bytes = pix.tobytes("png")

                img_path = os.path.join(output_dir, f"page_{i}.png")
                pix.save(img_path)

                rect = fitz.Rect(0, 0, pix.width, pix.height)
                new_page = new_doc.new_page(width=pix.width, height=pix.height)
                new_page.insert_image(rect, stream=img_bytes)
                continue

            # Usually the first image is the actual page scan
            xref = img_list[0][0]
            img = doc.extract_image(xref)
            img_bytes = img["image"]

            # Use image size as page size
            pix = fitz.Pixmap(img_bytes)
            rect = fitz.Rect(0, 0, pix.width, pix.height)

            img_path = os.path.join(output_dir, f"page_{i}.png")
            pix.save(img_path)

            new_page = new_doc.new_page(width=pix.width, height=pix.height)
            new_page.insert_image(rect, stream=img_bytes)

    # new_doc.save(output_pdf)
    new_doc.close()
    doc.close()