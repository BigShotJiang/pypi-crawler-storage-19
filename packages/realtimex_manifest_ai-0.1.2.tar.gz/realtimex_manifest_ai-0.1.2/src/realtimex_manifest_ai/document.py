# /// script
# requires-python = ">=3.9"
# dependencies = [
#     "fastapi",
#     "uvicorn",
#     "pydantic",
#     "jinja2",
#     "python-multipart",
#     "pymupdf",
#     "google-cloud-vision",
#     "google-auth"
# ]
# ///

import os
import json
from typing import Optional

# Import our schema and LangChain libs
from .schemas.registry_schema import Registry
from .schemas.document_schema import Document
from document_ai_schema import DocumentAI
from document_ai_bank_schema import DocumentAIBank
from ocr_texts_schema import OCRTexts
# from registry import get_registry

# from gemini import extract_data_to_json as extract_data_to_json_by_gemini
from litellm_utils import extract_data_to_json
from landingai import do_ocr

from utils import make_dir, get_batch_dir, push_messages

def get_documents(batch_id):
    document_dir = os.path.join(get_batch_dir(batch_id), "documents")
    documents = []
    for filename in os.listdir(document_dir):
        if not filename.lower().endswith(".pdf"):
            continue
        full_path = os.path.join(document_dir, filename)
        documents.append({
            "file_name": filename,
            "full_path": full_path
        })
    return documents

def parse_data(schema, message=None):
    system_prompt = f"""You are best at extracting data and bounding boxs from OCR raw text.
Your task is to do the best to extract data and its bounding box from OCR raw text.

MUST follow these rules:
### OUTPUT REQUIREMENT
You must output strictly structured JSON mathing the provided schema.

### OPERATING PROTOCOLS: DATA EXTRACTION
- Do the best to extract data and its page and bounding box
- ALWAYS extract ALL found line items, NOT ONLY some first items
- Bounding box is in normalized coordinates, DO NOT round up bounding box
- If text in a text block, ALWAYS use block's bounding box for text, DO NOT make up/calculate by yourself
- ONLY extract existing data, DO NOT make up or fill fake data
"""


    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"""Now extract this data:\n{message}"""},
    ]

  
    response = extract_data_to_json(
        model="claude-sonnet-4-5",
        schema=schema,
        messages=messages
    )

    return response

# def parse_data_with_ai(file_path, message=None):
    
#     system_prompt = f"""You are best at extract data from documents.
# Your task is to do the best to extract data from document.

# ### OUTPUT REQUIREMENT
# You must output strictly structured JSON matching the provided schema.

# ### OPERATING PROTOCOLS:
# - Understand the document, extract data correctly
# """
  
#     response = extract_data_to_json_by_gemini(
#         model="gemini-3-pro-preview",
#         schema=DocumentAI,
#         messages=[system_prompt,f"file:{file_path}",message]
#     )

#     return response

# def enhance_data_with_ai(file_path, message=None):
    
#     system_prompt = f"""You are best at extract data from documents.
# Your task is to do the best to extract data from document to provided data.

# ### OUTPUT REQUIREMENT
# You must output strictly structured JSON matching the provided schema.

# ### OPERATING PROTOCOLS:
# - Understand the document, extract data correctly
# - Enhance provided data correctly by understanding and extracting data from document
# - Provided data is a json, you ONLY enhance `text` field in json data, DO NOT touch the json structure, DO NOT add/remove JSON items
# """

#     messages = [
#         {"role": "system", "content": system_prompt},
#         {"role": "user", "content": f"""Now extract this data:\n{message}"""},
#     ]
  
#     response = extract_data_to_json_by_gemini(
#         model="gemini-3-pro-preview",
#         schema=schema,
#         messages=messages
#     )

#     return response

def enhance_data_with_ai(schema, message=None):
    
    system_prompt = f"""You are best at extract data from documents.
Your task is to do the best to extract data from provided documents.

### OUTPUT REQUIREMENT
You must output strictly structured JSON matching the provided schema.

### OPERATING PROTOCOLS:
- Understand provided json data on each documents
- Think carefully to decide to get data from which document for each fields
- ONLY allow to improve data with mistypings or mistakes by OCR, DO NOT make up/generate data out of provided json data
"""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": message},
    ]

    print(messages)
  
    response = extract_data_to_json(
        model="claude-sonnet-4-5",
        schema=schema,
        messages=messages
    )

    return response

from markdownify import markdownify as md

def get_table_text(text, grounding=None):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(text, "html.parser")

    chunk_text = ""
    for row in soup.find_all("tr"):
        cells = []
        for cell in row.find_all(['td', 'th']):
            cell_text = cell.get_text(strip=True)
            if cell.has_attr("id") and grounding:
                cell_box = grounding[cell["id"]]["box"]
                cell_page = grounding[cell["id"]]["page"]
                cell_text = f"{cell_text} [page={cell_page}] [boundbox=(left={cell_box['left']},top={cell_box['top']},right={cell_box['right']},bottom={cell_box['bottom']})]"
            cells.append(cell_text)
            cell.string = cell_text
        md_row = " | ".join(cells)
        chunk_text = f"{chunk_text}\n| {md_row} |"
    return md(str(soup))

def handle_ocr_data(ocr_data, with_bounding=True, ai_enhanced_ocr_texts=None):

    ai_enhanced_ocr_data = {}
    if ai_enhanced_ocr_texts:
        for ai_enhanced_ocr_text in ai_enhanced_ocr_texts["chunks"]:
            ai_enhanced_ocr_data[ai_enhanced_ocr_text["id"]] = ai_enhanced_ocr_text["text"]

    ocr_texts = []

    # ocr_data_file = "static/data/c45cd2fbfa40c4663862ec723ef17a5fd17635dd/ocr_data/commercial_invoice.pdf.json"
    # ocr_data = None
    # with open(ocr_data_file, "r") as file:
    #     ocr_data = json.load(file)

    grounding = ocr_data["grounding"]

    for chunk in ocr_data["chunks"]:
        chunk_text = chunk["markdown"]
        chunk_id = chunk["id"]
        chunk_type = chunk["type"]
        chunk_box = chunk["grounding"]["box"]
        chunk_page = chunk["grounding"]["page"]

        if with_bounding:
            ocr_texts.append(f"--- Begin {chunk_type.capitalize()} [page={chunk_page}] [boundbox=(left={chunk_box['left']},top={chunk_box['top']},right={chunk_box['right']},bottom={chunk_box['bottom']})] ---")
            chunk_texts = chunk_text.split("\n\n")
            chunk_texts.pop(0)
            chunk_text = "\n\n".join(chunk_texts)
            # chunk_text = md(chunk_text)
            if chunk_type == "table":
                # print(chunk_text)
                chunk_text = get_table_text(chunk_text, grounding)
            ocr_texts.append(chunk_text)
            ocr_texts.append(f"--- End {chunk_type.capitalize()} ---\n\n")
        else:
            ocr_texts.append(f"--- Begin {chunk_type.capitalize()} ---")
            if chunk_id in ai_enhanced_ocr_data:
                chunk_text = ai_enhanced_ocr_data[chunk_id]
            else:
                chunk_texts = chunk_text.split("\n\n")
                chunk_texts.pop(0)
                chunk_text = "\n\n".join(chunk_texts)
                # chunk_text = md(chunk_text)
                if chunk_type == "table":
                    # print(chunk_text)
                    chunk_text = get_table_text(chunk_text)
            ocr_texts.append(chunk_text)
            ocr_texts.append(f"--- End {chunk_type.capitalize()} ---\n\n")

    return "\n".join(ocr_texts)

def get_ocr_text_only(ocr_data):

    ocr_texts = []

    for chunk in ocr_data["chunks"]:
        chunk_text = chunk["markdown"]
        chunk_id = chunk["id"]
        chunk_type = chunk["type"]

        chunk_texts = chunk_text.split("\n\n")
        chunk_texts.pop(0)
        chunk_text = "\n\n".join(chunk_texts)
        if chunk_type == "table":
            chunk_text = get_table_text(chunk_text)

        ocr_texts.append({
            "id": chunk_id,
            "type": chunk_type,
            "text": chunk_text
        })

    return {"chunks":ocr_texts}

def get_ocr_data(batch_id,document_name):
    ocr_data_dir = f"static/data/{batch_id}/ocr_data"
    ocr_file_path = f'{ocr_data_dir}/{document_name}.json'
    if not os.path.exists(ocr_file_path):
        return None
    data = None
    with open(ocr_file_path, 'r') as my_file:
        data = json.load(my_file) 
    return data

def get_ai_enhanced_ocr_data(batch_id,document_name):
    ocr_data_dir = f"static/data/{batch_id}/ocr_data_ai"
    ocr_file_path = f'{ocr_data_dir}/{document_name}.json'
    print(ocr_file_path)
    if not os.path.exists(ocr_file_path):
        return None
    data = None
    with open(ocr_file_path, 'r') as my_file:
        data = json.load(my_file) 
    return data

def prepare_document_data(batch_id):
    data_dir = f"static/data/{batch_id}/data"
    make_dir(data_dir)

    data_ai_dir = f"static/data/{batch_id}/data_ai"
    make_dir(data_ai_dir)

    document_dir = f"static/data/{batch_id}/documents"
    ocr_data = {}
    for filename in os.listdir(document_dir):
        if not filename.lower().endswith(".pdf"):
            continue
        full_path = os.path.join(document_dir, filename)
        document_name = filename
        document_path = full_path
        data_file_path = f'{data_dir}/{document_name}.json'
        data_ai_file_path = f'{data_ai_dir}/{document_name}.json'

        ocr_data = get_ocr_data(batch_id,document_name)
        if not ocr_data:
            continue
        
        bare_ocr_data = handle_ocr_data(ocr_data)
        result = parse_data(Document, bare_ocr_data)
        with open(data_file_path, 'w') as my_file:
            my_file.write(json.dumps(result))
        
        # ai_enhanced_ocr_texts = get_ai_enhanced_ocr_data(batch_id,document_name)
        # ai_enhanced_ocr_data = handle_ocr_data(ocr_data, with_bounding=False, ai_enhanced_ocr_texts=ai_enhanced_ocr_texts)

        # result_ai = parse_data(DocumentAI, ai_enhanced_ocr_data)
        # with open(data_ai_file_path, 'w') as my_file:
        #     my_file.write(json.dumps(result_ai))
        
        # break

def prepare_document_ai_enhanced_data(batch_id,registry):
    data_dir = f"static/data/{batch_id}/data_ai"
    make_dir(data_dir)

    ai_enhanced_data = {}
    all_ocr_texts = []
    
    # registry = get_registry()
    for file in registry["registry"]:
        document_name = file["doc_name"]
        document_type = file["doc_type"]
        document_title = file["doc_title"]

        ocr_data = get_ocr_data(batch_id,document_name)
        ocr_texts = get_ocr_text_only(ocr_data)

        all_ocr_texts.append(f"--- Begin document {document_title} [name={document_name}] [type={document_type}]  ---")
        all_ocr_texts.append(json.dumps(ocr_texts))
        all_ocr_texts.append(f"--- End document ---\n")

    all_ocr_texts = "\n".join(all_ocr_texts)
    ai_enhanced_data = enhance_data_with_ai(DocumentAIBank,message=f"Here is provided documents:\n{all_ocr_texts}")

    for file in registry["registry"]:
        document_name = file["doc_name"]
        ai_file_path = f'{data_dir}/{document_name}.json'
        with open(ai_file_path, 'w') as my_file:
            my_file.write(json.dumps(ai_enhanced_data))

def prepare_ocr_data(batch_id):
    ocr_data_dir = f"static/data/{batch_id}/ocr_data"
    make_dir(ocr_data_dir)

    document_dir = f"static/data/{batch_id}/documents"
    ocr_data = {}
    for filename in os.listdir(document_dir):
        if not filename.lower().endswith(".pdf"):
            continue
        full_path = os.path.join(document_dir, filename)
        document_name = filename
        document_path = full_path
        ocr_file_path = f'{ocr_data_dir}/{document_name}.json'

        result = do_ocr(full_path)
    
        with open(ocr_file_path, 'w') as my_file:
            my_file.write(result.to_json())

# def prepare_data_ai(batch_id):
#     ocr_data_dir = f"static/data/{batch_id}/ocr_data_ai"
#     make_dir(ocr_data_dir)

#     document_dir = f"static/data/{batch_id}/documents"
#     ai_enhanced_data = {}
#     all_ocr_texts = []
    
#     registry = get_registry()
#     for file in registry:
#         # ocr_file_path = f'{ocr_data_dir}/{document_name}.json'
#         document_name = file["doc_name"]
#         document_type = file["doc_type"]
#         document_title = file["doc_title"]

#         ocr_data = get_ocr_data(batch_id,document_name)
#         ocr_texts = get_ocr_text_only(ocr_data)

#         all_ocr_texts.append(f"--- Begin document {document_title} [name={document_name}] [type={document_type}]  ---")
#         all_ocr_texts.append(json.dumps(ocr_texts))
#         all_ocr_texts.append(f"--- End document ---\n")

#     all_ocr_texts = "\n".join(all_ocr_texts)
#     ai_enhanced_data = enhance_data_with_ai(DocumentAI,message=f"Here is provided documents:\n{all_ocr_texts}")

#     for file in registry:
#         ai_file_path = f'{ocr_data_dir}/{document_name}.json'
#         with open(ocr_file_path, 'w') as my_file:
#             my_file.write(json.dumps(ai_enhanced_data))