from .utils import get_file_hash

def get_batch_id(file_path):
    batch_id = get_file_hash(file_path)

    return batch_id