// Home View Module
(function () {
    'use strict';

    // Check if batch_id exists in URL
    function hasBatchId() {
        const params = new URLSearchParams(window.location.search);
        return params.has('batch_id') && params.get('batch_id');
    }

    // Initialize home view
    async function initHomeView() {
        const homeView = document.getElementById('home-view');
        const appView = document.getElementById('app');
        const modalContainer = document.getElementById('modal-container');

        if (!homeView || !appView) return;

        if (hasBatchId()) {
            // Has batch_id - show validator view
            homeView.style.display = 'none';
            appView.style.display = 'flex';
            if (modalContainer) modalContainer.style.display = '';
        } else {
            // No batch_id - show home view
            homeView.style.display = 'flex';
            appView.style.display = 'none';
            if (modalContainer) modalContainer.style.display = 'none';
            await loadBatches();
            setupUploadZone();
        }
    }

    // Load and render batch list
    async function loadBatches() {
        const batchList = document.getElementById('batch-list');
        const batchCount = document.getElementById('batch-count');

        if (!batchList) return;

        // Show loading state
        batchList.innerHTML = `
            <div class="batch-loading">
                <div class="batch-loading-spinner"></div>
            </div>
        `;

        try {
            const response = await fetch('/api/batches');
            const data = await response.json();
            const batches = data.batches || [];

            if (batchCount) {
                batchCount.textContent = `(${batches.length})`;
            }

            if (batches.length === 0) {
                batchList.innerHTML = `
                    <div class="batch-empty">
                        <div class="batch-empty-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/>
                            </svg>
                        </div>
                        <div>No batch data found</div>
                        <div style="font-size: 0.85rem; margin-top: 0.5rem;">Upload files to create a new batch</div>
                    </div>
                `;
                return;
            }

            batchList.innerHTML = batches.map(batch => `
                <div class="batch-card" data-batch-id="${batch.id}" onclick="navigateToBatch('${batch.id}')">
                    <div class="batch-card-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/>
                        </svg>
                    </div>
                    <div class="batch-card-content">
                        <div class="batch-card-name">${batch.name}</div>
                        <div class="batch-card-path">${batch.path}</div>
                    </div>
                    <div class="batch-card-arrow">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M9 18l6-6-6-6"/>
                        </svg>
                    </div>
                </div>
            `).join('');

        } catch (error) {
            console.error('Failed to load batches:', error);
            batchList.innerHTML = `
                <div class="batch-empty">
                    <div style="color: var(--error);">Failed to load batches</div>
                    <div style="font-size: 0.85rem; margin-top: 0.5rem;">${error.message}</div>
                </div>
            `;
        }
    }

    // Navigate to batch (preserving existing URL params)
    window.navigateToBatch = function (batchId) {
        const params = new URLSearchParams(window.location.search);
        params.set('batch_id', batchId);
        window.location.href = `?${params.toString()}`;
    };

    // Go to home (remove only batch_id, keep other params)
    window.goHome = function () {
        const params = new URLSearchParams(window.location.search);
        params.delete('batch_id');
        const queryString = params.toString();
        window.location.href = queryString ? `?${queryString}` : window.location.pathname;
    };

    // Setup upload zone
    function setupUploadZone() {
        const uploadZone = document.getElementById('upload-zone');
        const uploadInput = document.getElementById('upload-input');

        if (!uploadZone || !uploadInput) return;

        // Click to upload
        uploadZone.addEventListener('click', () => {
            uploadInput.click();
        });

        // File input change
        uploadInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                handleFileUpload(e.target.files);
            }
        });

        // Drag and drop
        uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadZone.classList.add('drag-over');
        });

        uploadZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            uploadZone.classList.remove('drag-over');
        });

        uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadZone.classList.remove('drag-over');
            if (e.dataTransfer.files.length > 0) {
                handleFileUpload(e.dataTransfer.files);
            }
        });
    }

    // Handle file upload
    async function handleFileUpload(files) {
        const uploadZone = document.getElementById('upload-zone');
        const formData = new FormData();
        for (const file of files) {
            formData.append('files', file);
        }

        // Show loading state
        const originalContent = uploadZone.innerHTML;
        uploadZone.classList.add('uploading');
        uploadZone.innerHTML = `
            <div class="upload-status loading">
                <div class="upload-spinner"></div>
                <div class="upload-status-title">Uploading ${files.length} file(s)...</div>
                <div class="upload-status-desc">Please wait while we process your files</div>
            </div>
        `;

        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            // Show success state
            uploadZone.classList.remove('uploading');
            uploadZone.classList.add('upload-success');
            uploadZone.innerHTML = `
                <div class="upload-status success">
                    <div class="upload-status-icon success">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 6L9 17l-5-5"/>
                        </svg>
                    </div>
                    <div class="upload-status-title">${result.message || 'Upload complete!'}</div>
                    <div class="upload-status-desc">Click to upload more files</div>
                </div>
            `;

            // Reset after 3 seconds
            setTimeout(() => {
                uploadZone.classList.remove('upload-success');
                uploadZone.innerHTML = originalContent;
            }, 3000);

            // Reload batches
            await loadBatches();

        } catch (error) {
            console.error('Upload failed:', error);

            // Show error state
            uploadZone.classList.remove('uploading');
            uploadZone.classList.add('upload-error');
            uploadZone.innerHTML = `
                <div class="upload-status error">
                    <div class="upload-status-icon error">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <path d="M15 9l-6 6M9 9l6 6"/>
                        </svg>
                    </div>
                    <div class="upload-status-title">Upload failed</div>
                    <div class="upload-status-desc">${error.message}</div>
                </div>
            `;

            // Reset after 3 seconds
            setTimeout(() => {
                uploadZone.classList.remove('upload-error');
                uploadZone.innerHTML = originalContent;
            }, 3000);
        }

        // Reset file input
        document.getElementById('upload-input').value = '';
    }

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initHomeView);
    } else {
        initHomeView();
    }
})();
