// ============ EDITABLE VALUE RENDERING ============

function sanitizeForId(value) {
  if (value === null || value === undefined) return 'field'
  return String(value).replace(/[^a-zA-Z0-9_-]/g, '_')
}

// ============ HIDE/SHOW DOCUMENTS PER FIELD ============
function hideDocForField(fieldPath, docName) {
  if (!state.hiddenDocsPerField[fieldPath]) {
    state.hiddenDocsPerField[fieldPath] = new Set()
  }
  state.hiddenDocsPerField[fieldPath].add(docName)
  saveHiddenDocs()
  recalculateValidationStatus(fieldPath)
  if (typeof renderValidationList === 'function') renderValidationList()
  if (typeof updateTreeBadges === 'function') updateTreeBadges()
  renderModal()
}

function showDocForField(fieldPath, docName) {
  if (state.hiddenDocsPerField[fieldPath]) {
    state.hiddenDocsPerField[fieldPath].delete(docName)
    if (state.hiddenDocsPerField[fieldPath].size === 0) {
      delete state.hiddenDocsPerField[fieldPath]
    }
  }
  saveHiddenDocs()
  recalculateValidationStatus(fieldPath)
  if (typeof renderValidationList === 'function') renderValidationList()
  if (typeof updateTreeBadges === 'function') updateTreeBadges()
  renderModal()
}

function showAllDocsForField(fieldPath) {
  delete state.hiddenDocsPerField[fieldPath]
  saveHiddenDocs()
  recalculateValidationStatus(fieldPath)
  if (typeof renderValidationList === 'function') renderValidationList()
  if (typeof updateTreeBadges === 'function') updateTreeBadges()
  renderModal()
}

function isDocHiddenForField(fieldPath, docName) {
  return state.hiddenDocsPerField[fieldPath]?.has(docName) || false
}

function getHiddenDocsForField(fieldPath) {
  return state.hiddenDocsPerField[fieldPath] || new Set()
}

// Recalculate validation status based on visible documents only
function recalculateValidationStatus(fieldPath) {
  if (!analysisData || !analysisData.validations) return

  const validation = analysisData.validations.find(v => v.field_path === fieldPath)
  if (!validation || !validation.evidence) return

  // Filter visible evidence
  const visibleEvidence = validation.evidence.filter(ev => !isDocHiddenForField(fieldPath, ev.doc_name))

  // If less than 2 visible docs, can't compare - mark as PASS
  if (visibleEvidence.length < 2) {
    validation.status = 'PASS'
    validation.analysis = visibleEvidence.length === 1
      ? 'Only 1 document visible for comparison'
      : 'No documents visible for comparison'
    return
  }

  // Get master doc and its value for comparison
  const masterDoc = typeof getMasterDoc === 'function' ? getMasterDoc(fieldPath) : null
  const isMasterHidden = masterDoc && isDocHiddenForField(fieldPath, masterDoc)

  if (isMasterHidden || !masterDoc) {
    // No valid master, compare unique values among visible docs
    const uniqueValues = new Set(visibleEvidence.map(ev =>
      String(ev.value_found ?? '').trim().toUpperCase()
    ))

    if (uniqueValues.size > 1) {
      validation.status = 'FAIL'
      validation.analysis = `Found ${uniqueValues.size} different values across ${visibleEvidence.length} visible documents`
    } else {
      validation.status = 'PASS'
      validation.analysis = `All ${visibleEvidence.length} visible documents match`
    }
  } else {
    // Compare against master
    const masterEvidence = visibleEvidence.find(ev => ev.doc_name === masterDoc)
    if (!masterEvidence) {
      // Master not in visible set, compare unique values
      const uniqueValues = new Set(visibleEvidence.map(ev =>
        String(ev.value_found ?? '').trim().toUpperCase()
      ))
      validation.status = uniqueValues.size > 1 ? 'FAIL' : 'PASS'
    } else {
      const masterValue = String(masterEvidence.value_found ?? '').trim().toUpperCase()
      const mismatches = visibleEvidence.filter(ev => {
        if (ev.doc_name === masterDoc) return false
        return String(ev.value_found ?? '').trim().toUpperCase() !== masterValue
      })

      if (mismatches.length > 0) {
        validation.status = 'FAIL'
        validation.analysis = `${mismatches.length} of ${visibleEvidence.length - 1} visible documents differ from master`
      } else {
        validation.status = 'PASS'
        validation.analysis = `All ${visibleEvidence.length} visible documents match master`
      }
    }
  }

  // Keep summary dashboard in sync with the latest PASS/FAIL counts
  if (typeof generateSummaryData === 'function') {
    const updatedSummary = generateSummaryData()
    if (analysisData) {
      analysisData.summary = updatedSummary
    }
    window.summaryData = updatedSummary
  }
}

// Convert state.hiddenDocsPerField to JSON-serializable format
function serializeHiddenDocs() {
  const result = {}
  for (const [fieldPath, docSet] of Object.entries(state.hiddenDocsPerField)) {
    result[fieldPath] = Array.from(docSet)
  }
  return result
}

// Restore state.hiddenDocsPerField from JSON data
function deserializeHiddenDocs(data) {
  state.hiddenDocsPerField = {}
  for (const [fieldPath, docArray] of Object.entries(data || {})) {
    state.hiddenDocsPerField[fieldPath] = new Set(docArray)
  }
}

async function loadHiddenDocs() {
  if (state.readOnlyMode) {
    return
  }
  try {
    const batchId = getBatchId()
    const response = await fetch(`/api/hidden-docs?batch_id=${batchId}`)
    if (response.ok) {
      const data = await response.json()
      deserializeHiddenDocs(data)
      console.log('Loaded hidden docs from server')
    }
  } catch (err) {
    console.error('Failed to load hidden docs:', err)
  }
}

async function saveHiddenDocs() {
  if (state.readOnlyMode) {
    return
  }
  try {
    const batchId = getBatchId()
    const response = await fetch(`/api/hidden-docs?batch_id=${batchId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(serializeHiddenDocs())
    })
    if (response.ok) {
      console.log('Saved hidden docs to server')
    }
  } catch (err) {
    console.error('Failed to save hidden docs:', err)
  }
}

function formatEditableValue(value) {
  const stringValue = value === null || value === undefined ? '' : String(value)
  const displayValue = stringValue === '' ? '<em>(empty)</em>' : escapeHtml(stringValue)
  return { stringValue, displayValue }
}

function renderEditableField({ fieldId, docName, fieldPath, value, verificationPath = null, wrapperClass = 'grid-card-value', noteInfo = null }) {
  if (!docName || !fieldPath) {
    const safeValue = value === null || value === undefined ? '' : String(value)
    return `<span class="value-text">${escapeHtml(safeValue)}</span>`
  }

  const isReadOnly = state.readOnlyMode
  const { stringValue, displayValue } = formatEditableValue(value)
  const isOverridden = typeof isFieldOverridden === 'function' ? isFieldOverridden(docName, fieldPath) : false
  const overrideInfo = typeof getOverrideInfo === 'function' ? getOverrideInfo(docName, fieldPath) : null

  // Check for AI suggestion
  const aiSuggestion = typeof getAISuggestion === 'function' ? getAISuggestion(docName, fieldPath) : null
  const hasAI = aiSuggestion && typeof hasAISuggestion === 'function' ? hasAISuggestion(docName, fieldPath) : false
  const isAIApproved = typeof isAISuggestionApproved === 'function' ? isAISuggestionApproved(docName, fieldPath) : false
  const isAIDismissed = typeof isAISuggestionDismissed === 'function' ? isAISuggestionDismissed(docName, fieldPath) : false

  // Determine badge text and class based on action type (unified badge system)
  let badgeText = 'Edited'
  let badgeClass = 'override-badge badge-edited'
  let overrideTitle = 'Value has been edited'

  if (overrideInfo) {
    const action = overrideInfo.action || 'update'

    if (action === 'ai_enhancement') {
      badgeText = 'AI Enhanced'
      badgeClass = 'override-badge'
      overrideTitle = `AI Enhanced: ${overrideInfo.reason || 'AI enhancement'}&#10;Original: ${escapeHtml(String(overrideInfo.originalValue ?? ''))}`
    } else if (action === 'sync_from_master') {
      badgeText = 'Synced'
      badgeClass = 'override-badge badge-synced'
      overrideTitle = `Synced from master&#10;Original: ${escapeHtml(String(overrideInfo.originalValue ?? ''))}`
    } else if (action === 'restore') {
      badgeText = 'Restored'
      badgeClass = 'override-badge badge-restored'
      overrideTitle = `Restored from changelog&#10;Original: ${escapeHtml(String(overrideInfo.originalValue ?? ''))}`
    } else {
      overrideTitle = `Manually edited&#10;Original: ${escapeHtml(String(overrideInfo.originalValue ?? ''))}`
    }
  }

  const hasAISuggestionPending = hasAI && !isAIApproved && !isAIDismissed && !isReadOnly
  const fullWrapperClass = `${wrapperClass} ${isOverridden ? 'overridden' : ''}`.trim()
  const verificationTarget = verificationPath || fieldPath

  // Build AI suggestion row (simple structure like edit-actions)
  // Skip if AI value is empty or matches current value
  let aiSuggestionRow = ''
  const aiValue = aiSuggestion?.value
  const hasValidAIValue = aiValue !== null && aiValue !== undefined && String(aiValue).trim() !== ''
  const currentValueStr = String(stringValue ?? '').trim()
  const aiValueStr = String(aiValue ?? '').trim()
  const isDifferentFromCurrent = currentValueStr !== aiValueStr
  if (hasAISuggestionPending && hasValidAIValue && isDifferentFromCurrent) {
    const aiValueDisplay = escapeHtml(String(aiSuggestion.value))
    const reasonText = aiSuggestion.reason ? escapeHtml(aiSuggestion.reason) : 'AI suggestion'

    aiSuggestionRow = `
      <div class="ai-suggestion-row">
        <div class="ai-actions-wrapper">
          <span style="color: var(--success);font-weight: bold;">AI Enhanced:</span>
          <div class="ai-actions">
            <button class="btn-ai-approve" onclick="applyAISuggestion('${escapeHtml(docName)}', '${escapeHtml(fieldPath)}')" data-tooltip="Apply AI suggestion">
              ${icons.check} Accept
            </button>
            <button class="btn-ai-dismiss" onclick="dismissAISuggestion('${escapeHtml(docName)}', '${escapeHtml(fieldPath)}')" data-tooltip="Dismiss">
              ${icons.x}
            </button>
          </div>
        </div>
        <span class="ai-value" title="${reasonText}">${aiValueDisplay}</span>
        
      </div>
    `
  }

  // Main display with OCR value + edit actions + AI suggestion below
  return `
    <div class="${fullWrapperClass}">
      <div class="value-display" id="display_${fieldId}">
        <span class="value-text">${displayValue}</span>
        ${isOverridden ? `<span class="${badgeClass}" title="${overrideTitle}">${badgeText}</span>` : ''}
      </div>
      ${isReadOnly ? '' : `
        <div class="value-actions" id="actions_${fieldId}">
          ${noteInfo ? `<button class="btn-add-note" onclick="event.stopPropagation(); addFieldNote('${escapeHtml(noteInfo.docName)}', '${escapeHtml(fieldPath)}', ${noteInfo.pageIndex}, '${escapeHtml(noteInfo.label)}', ${noteInfo.boundingBox ? JSON.stringify(noteInfo.boundingBox).replace(/"/g, '&quot;') : 'null'})" data-tooltip="Add note">
            ${icons.messageSquare}
          </button>` : ''}
          <button class="btn-edit" onclick="enableEditMode('${fieldId}', '${escapeHtml(docName)}', '${escapeHtml(fieldPath)}', '${escapeHtml(stringValue)}', '${escapeHtml(verificationTarget)}')" data-tooltip="Edit value">
            ${icons.edit}
          </button>
          ${isOverridden ? `<button class="btn-revert" onclick="revertOverride('${escapeHtml(docName)}', '${escapeHtml(fieldPath)}')" data-tooltip="Revert to original">
            ${icons.rotateLeft}
          </button>` : ''}
        </div>
        <div class="value-edit" id="edit_${fieldId}" style="display: none;">
          <textarea class="edit-input" id="input_${fieldId}" rows="3">${escapeHtml(stringValue)}</textarea>
          <div class="edit-actions">
            <button class="btn-save" onclick="saveEdit('${fieldId}', '${escapeHtml(docName)}', '${escapeHtml(fieldPath)}', '${escapeHtml(stringValue)}', '${escapeHtml(verificationTarget)}')">
              ${icons.check}
            </button>
            <button class="btn-cancel" onclick="cancelEdit('${fieldId}')">
              ${icons.x}
            </button>
          </div>
        </div>
      `}
      ${aiSuggestionRow}
    </div>
  `
}

function renderEditableValue(evidence, validation, isMaster, masterValue, matchesMaster) {
  const docName = evidence.doc_name
  const fieldPath = validation.field_path
  const currentValue = evidence.value_found

  const fieldId = `field_${sanitizeForId(docName)}_${sanitizeForId(fieldPath)}`

  let valueClass = 'grid-card-value'
  if (isMaster) {
    valueClass += ' master'
  } else if (masterValue) {
    valueClass += matchesMaster ? ' match' : ' mismatch'
  }

  return renderEditableField({
    fieldId,
    docName,
    fieldPath,
    value: currentValue,
    verificationPath: validation.field_path,
    wrapperClass: valueClass,
  })
}

function renderSummaryDashboard() {
  const data = window.summaryData
  if (!data) return `
    <div class="welcome-state">
      <div class="welcome-icon">${icons.file}</div>
      <div class="welcome-title">Select an Item</div>
      <div class="welcome-desc">Select a validation item from the list to view details and comparison.</div>
    </div>
  `

  // Compute status dynamically from current analysis data (matching header status-badge)
  const failCount = analysisData?.failCount || data.validationSummary?.fail || 0
  const dynamicStatus = failCount > 0 ? `${failCount} Issues Found` : 'All Clear'
  const dynamicStatusColor = failCount > 0 ? 'danger' : 'success'

  const docCount = typeof data.documents === 'number'
    ? data.documents
    : Object.keys(registry || {}).length

  const exportButton = state.readOnlyMode ? '' : `
    <div class="summary-export">
      <button class="export-report-btn" onclick="exportReport()">
        Export Report
      </button>
      <div class="export-hint">Download a standalone HTML report with assets</div>
    </div>
  `

  return `
    <div class="summary-dashboard">
       <div class="summary-header">
         <div class="summary-title-group">
            <h2 class="summary-batch-id">${escapeHtml(data.batchId)}</h2>
            <span class="summary-status status-${dynamicStatusColor}">${escapeHtml(dynamicStatus)}</span>
         </div>
       </div>

       <div class="summary-stats">
          <div class="stat-card info clickable" onclick="handleStatCardClick('documents')" role="button">
             <div class="stat-value">${docCount || 0}</div>
             <div class="stat-label">Documents</div>
          </div>
          <div class="stat-card success clickable" onclick="handleStatCardClick('pass')" role="button">
             <div class="stat-value">${data.validationSummary?.pass || 0}</div>
             <div class="stat-label">Passed Checks</div>
          </div>
          <div class="stat-card danger clickable" onclick="handleStatCardClick('fail')" role="button">
             <div class="stat-value">${data.validationSummary?.fail || 0}</div>
             <div class="stat-label">Issues Found</div>
          </div>
          <div class="stat-card primary clickable" onclick="handleStatCardClick('verified')" role="button">
             <div class="stat-value">${data.validationSummary?.verified || 0}</div>
             <div class="stat-label">Verified Fields</div>
          </div>
       </div>

       <div class="summary-section">
          <h3 class="section-title">Key Insights</h3>
          <ul class="insight-list">
             ${(data.insights || []).map(text => `
               <li class="insight-item">
                 <span class="bullet-icon">${icons.info}</span>
                 <span>${escapeHtml(text)}</span>
               </li>
             `).join('')}
          </ul>
       </div>

       <div class="summary-section">
          <h3 class="section-title">Recommended Actions</h3>
          <ul class="action-list">
             ${(data.actions || []).map(text => `
               <li class="action-item">
                 <span class="bullet-icon warning">${icons.alertTriangle}</span>
                 <span>${escapeHtml(text)}</span>
               </li>
             `).join('')}
          </ul>
       </div>
       ${exportButton}
    </div>
  `
}

function normalizeFieldBoundingBox(rawBox) {
  if (!rawBox) return null
  if (Array.isArray(rawBox) && rawBox.length === 4 && typeof rawBox[0] === 'number') {
    return [
      { x: rawBox[0], y: rawBox[1] },
      { x: rawBox[2], y: rawBox[1] },
      { x: rawBox[2], y: rawBox[3] },
      { x: rawBox[0], y: rawBox[3] }
    ]
  }
  if (Array.isArray(rawBox) && rawBox.every(point => point && typeof point === 'object' && 'x' in point && 'y' in point)) {
    return rawBox
  }
  return null
}

function getDocumentFieldsForDoc(docName) {
  if (!docName || !documents[docName]) return []

  if (state.documentFieldCache[docName]) {
    return state.documentFieldCache[docName]
  }

  const docData = documents[docName]
  const pageOffset = registry[docName]?.page_start || 0
  const fields = []

  function traverse(node, path) {
    if (path && path.startsWith('metadata')) return
    if (!node) return
    if (Array.isArray(node)) {
      node.forEach((item, idx) => {
        const nextPath = path ? `${path}.${idx}` : `${idx}`
        traverse(item, nextPath)
      })
      return
    }

    if (typeof node !== 'object') return

    if ('value' in node) {
      const boundingBox = normalizeFieldBoundingBox(node.bound_box)
      const hasValidBox = boundingBox && boundingBox.some(point => point.x !== 0 || point.y !== 0)

      if (hasValidBox) {
        const rawLabel = path.split('.').pop() || path
        const sessionName = typeof getSessionName === 'function' ? getSessionName(path) : 'Fields'
        const lineItemMatch = path.match(/cargo_summary\.line_items(?:\.[^.]+)*\.items\.([^.]+)/)
        const lineItemKey = lineItemMatch ? lineItemMatch[1] : null

        fields.push({
          path,
          label: formatFieldName(rawLabel),
          value: node.value,
          pageIndex: (node.page ?? 0) + pageOffset,
          boundingBox,
          groupName: sessionName || 'Fields',
          lineItemKey,
          lineItemOrder: lineItemKey && /^\d+$/.test(lineItemKey) ? parseInt(lineItemKey, 10) : null
        })
      }
      return
    }

    Object.entries(node).forEach(([key, child]) => {
      const nextPath = path ? `${path}.${key}` : key
      traverse(child, nextPath)
    })
  }

  traverse(docData, '')

  fields.sort((a, b) => a.path.localeCompare(b.path))
  state.documentFieldCache[docName] = fields
  return fields
}

function renderDocumentFieldsPanel(docName, fields, collapsed = false) {
  const panelClasses = `document-fields-panel ${collapsed ? 'collapsed' : ''}`
  const count = fields.length

  fields.forEach((field, index) => {
    field.__index = index
  })

  const standardGroups = new Map()
  const lineItemGroups = new Map()

  fields.forEach(field => {
    if (field.lineItemKey) {
      if (!lineItemGroups.has(field.lineItemKey)) {
        lineItemGroups.set(field.lineItemKey, [])
      }
      lineItemGroups.get(field.lineItemKey).push(field)
    } else {
      const group = field.groupName || 'Fields'
      if (!standardGroups.has(group)) {
        standardGroups.set(group, [])
      }
      standardGroups.get(group).push(field)
    }
  })

  const standardSections = Array.from(standardGroups.entries())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([groupName, rows]) => {
      const rowsHtml = rows.map(field => {
        const editableId = `doc_field_${sanitizeForId(docName)}_${field.__index}`
        const editableField = renderEditableField({
          fieldId: editableId,
          docName,
          fieldPath: field.path,
          value: field.value ?? '',
          wrapperClass: 'document-field-value-editor',
          noteInfo: {
            docName: docName,
            label: field.label,
            pageIndex: field.pageIndex ?? 0,
            boundingBox: field.boundingBox || null
          }
        })
        return `
          <div class="document-field-row" onmouseenter="highlightDocumentField('${escapeHtml(docName)}', ${field.__index})" onmouseleave="clearDocumentFieldHighlight()">
            <div class="document-field-info">
              <div class="document-field-label">${escapeHtml(field.label)}</div>
            </div>
            <div class="document-field-value">
              ${editableField}
            </div>
          </div>
        `
      }).join('')
      return `
        <div class="session-header">${escapeHtml(groupName)}</div>
        <div class="document-field-section">
          ${rowsHtml}
        </div>
      `
    }).join('')

  const lineItemSection = lineItemGroups.size === 0 ? '' : `
    <div class="session-header">Cargo Summary</div>
    <div class="document-line-items">
      ${Array.from(lineItemGroups.entries()).sort((a, b) => {
    const orderA = a[1][0]?.lineItemOrder ?? 0
    const orderB = b[1][0]?.lineItemOrder ?? 0
    return orderA - orderB
  }).map(([itemKey, rows]) => {
    const sortedRows = rows.slice().sort((a, b) => a.label.localeCompare(b.label))
    const lineNoField = sortedRows.find(field => /line\s*no/i.test(field.label))
    const descriptionField = sortedRows.find(field => /description/i.test(field.label)) || sortedRows[0]
    const itemTitle = lineNoField?.value
      ? `Item #${escapeHtml(String(lineNoField.value))}`
      : `Item #${/^\d+$/.test(itemKey) ? Number(itemKey) + 1 : itemKey}`
    const displayPage = descriptionField?.pageIndex ?? sortedRows[0]?.pageIndex ?? 0
    const rowHtml = sortedRows.map(field => {
      const editableId = `doc_field_${sanitizeForId(docName)}_${field.__index}`
      const editableField = renderEditableField({
        fieldId: editableId,
        docName,
        fieldPath: field.path,
        value: field.value ?? '',
        wrapperClass: 'document-field-value-editor',
        noteInfo: {
          docName: docName,
          label: field.label,
          pageIndex: field.pageIndex ?? 0,
          boundingBox: field.boundingBox || null
        }
      })
      return `
            <div class="document-field-row" onmouseenter="highlightDocumentField('${escapeHtml(docName)}', ${field.__index})" onmouseleave="clearDocumentFieldHighlight()">
              <div class="document-field-info">
                <div class="document-field-label">${escapeHtml(field.label)}</div>
              </div>
              <div class="document-field-value">
                ${editableField}
              </div>
            </div>
          `
    }).join('')
    const isExpanded = state.expandedLineItems?.[docName] === itemKey
    return `
          <div class="document-line-item-card ${isExpanded ? 'expanded' : ''}" onmouseleave="clearDocumentFieldHighlight()">
            <div class="line-item-card-header" onclick="toggleDocumentLineItem('${escapeHtml(docName)}', '${escapeHtml(itemKey)}')" onmouseenter="highlightLineItemGroup('${escapeHtml(docName)}', '${escapeHtml(itemKey)}')">
              <div class="line-item-title">${itemTitle}</div>
            </div>
            <div class="line-item-fields-list" style="${isExpanded ? 'max-height: 1000px;' : ''}">
              ${rowHtml}
            </div>
          </div>
        `
  }).join('')}
    </div>
  `

  const content = count === 0
    ? `<div class="document-fields-empty">No captured fields with bounding boxes for this document.</div>`
    : `${standardSections}${lineItemSection}`

  // Check if document has AI enhanced data and banner not dismissed
  let aiBanner = ''
  const hasAIData = typeof hasDocumentAIData === 'function' && hasDocumentAIData(docName)
  const bannerDismissed = typeof isDocumentAIBannerDismissed === 'function' && isDocumentAIBannerDismissed(docName)
  const pendingCount = hasAIData && typeof countAISuggestions === 'function'
    ? countAISuggestions({ docName, onlyPending: true })
    : 0

  if (hasAIData && !bannerDismissed && pendingCount > 0) {
    aiBanner = `
      <div class="ai-banner">
        <div class="ai-banner-content">
          <span class="ai-banner-text">This document has AI suggestion${pendingCount > 1 ? 's' : ''}. Apply all?</span>
        </div>
        <div class="ai-banner-actions">
          <button class="btn-ai-approve" onclick="applyAllAISuggestions('${escapeHtml(docName)}')" title="Apply all AI suggestions">
            ${icons.check} Accept
          </button>
          <button class="btn-ai-dismiss" onclick="dismissDocumentAIBanner('${escapeHtml(docName)}')" title="Dismiss">
            ${icons.x}
          </button>
        </div>
      </div>
    `
  }

  return `
    <aside class="${panelClasses}">
      ${aiBanner}
      <div class="document-field-list">
        ${content}
      </div>
    </aside>
  `
}

function handleStatCardClick(statType) {
  const wasMobileSummary = window.innerWidth < 1024 && state.mobileSummaryActive
  if (wasMobileSummary) {
    state.mobileSummaryActive = false
    document.body.classList.remove('mobile-summary-active')
  }

  const applyFilter = (value) => {
    state.filterStatus = value
    const filterSelect = document.getElementById('filter-status')
    if (filterSelect) {
      filterSelect.value = value
    }
    if (typeof renderValidationList === 'function') {
      renderValidationList()
    }
  }

  const changeTab = (tab) => {
    if (typeof setActiveTab === 'function') {
      setActiveTab(tab)
    } else {
      state.activeTab = tab
      if (typeof renderValidationList === 'function') {
        renderValidationList()
      }
    }
  }

  if (statType === 'documents') {
    changeTab('documents')
    applyFilter('all')
  } else if (statType === 'pass') {
    changeTab('matches')
    applyFilter('all')
  } else if (statType === 'fail') {
    changeTab('mismatches')
    applyFilter('all')
  } else if (statType === 'verified') {
    changeTab('matches')
    applyFilter('verified')
  }

  if (wasMobileSummary) {
    render()
  }
}

// ============ EDIT MODE FUNCTIONS ============

function enableEditMode(fieldId, docName, fieldPath, currentValue, verificationPath = '') {
  if (state.readOnlyMode) {
    if (typeof showAlertDialog === 'function') {
      showAlertDialog('Editing is disabled in exported reports.', {
        title: 'Read-only Mode',
        type: 'warning'
      })
    }
    return
  }
  const displayEl = document.getElementById(`display_${fieldId}`)
  const editEl = document.getElementById(`edit_${fieldId}`)
  const actionsEl = document.getElementById(`actions_${fieldId}`)
  const inputEl = document.getElementById(`input_${fieldId}`)

  if (displayEl && editEl && actionsEl && inputEl) {
    displayEl.style.display = 'none'
    actionsEl.style.display = 'none'
    editEl.style.display = 'flex'
    inputEl.value = currentValue
    inputEl.focus()
    inputEl.select()

    // Handle Enter key to save
    inputEl.onkeydown = function (e) {
      if (e.key === 'Enter') {
        saveEdit(fieldId, docName, fieldPath, currentValue, verificationPath)
      } else if (e.key === 'Escape') {
        cancelEdit(fieldId)
      }
    }
  }
}

function cancelEdit(fieldId) {
  const displayEl = document.getElementById(`display_${fieldId}`)
  const editEl = document.getElementById(`edit_${fieldId}`)
  const actionsEl = document.getElementById(`actions_${fieldId}`)

  if (displayEl && editEl && actionsEl) {
    displayEl.style.display = 'flex'
    actionsEl.style.display = 'flex'
    editEl.style.display = 'none'
  }
}

async function saveEdit(fieldId, docName, fieldPath, originalValue, verificationPath = '') {
  if (state.readOnlyMode) return
  const inputEl = document.getElementById(`input_${fieldId}`)

  if (!inputEl) return

  const newValue = inputEl.value.trim()

  // If value hasn't changed, just cancel edit mode
  if (newValue === originalValue) {
    cancelEdit(fieldId)
    return
  }

  // Add override
  addOverride(docName, fieldPath, newValue, originalValue)

  // Note: addOverride will trigger reloadDataWithOverrides which will re-render everything
}

async function revertOverride(docName, fieldPath) {
  if (state.readOnlyMode) return
  const confirmed = await showConfirmDialog(
    `Revert this value to its original?\n\nDocument: ${docName}\nField: ${fieldPath}`,
    {
      title: 'Revert Override',
      confirmText: 'Revert',
      cancelText: 'Cancel',
      type: 'warning'
    }
  )
  if (!confirmed) {
    return
  }
  removeOverride(docName, fieldPath)
}

// ============ MAIN RENDER FUNCTION ============

function render() {
  if (!analysisData) return

  const mismatches = analysisData.validations.filter((v) => v.status === "FAIL")
  const matches = analysisData.validations.filter((v) => v.status === "PASS")

  document.getElementById("batch-id").textContent = `Batch: ${analysisData.batch_id}`

  document.getElementById("documents-badge").textContent = Object.keys(registry).length
  document.getElementById("mismatch-badge").textContent = mismatches.length
  document.getElementById("match-badge").textContent = matches.length

  renderValidationList()
  renderModal()
}

function renderValidationList() {
  const listEl = document.getElementById("validation-list")

  // Save scroll position before any re-rendering
  const scrollTop = listEl ? listEl.scrollTop : 0

  if (state.activeTab === "documents") {
    renderDocumentList()
    return
  }
  if (state.activeTab === "tree") {
    // Save scroll position before re-render
    const treeContent = document.querySelector('.tree-content')
    const scrollTop = treeContent ? treeContent.scrollTop : 0

    // Re-render tree to reflect data changes
    renderTreeView()

    // Restore scroll position after re-render
    const newTreeContent = document.querySelector('.tree-content')
    if (newTreeContent) {
      newTreeContent.scrollTop = scrollTop
    }
    return
  }

  // Filter out individual line item validations from main list
  const mismatches = analysisData.validations.filter((v) => v.status === "FAIL" && !v.isLineItem)
  const matches = analysisData.validations.filter((v) => v.status === "PASS" && !v.isLineItem)

  const filterFn = (v) => {
    const matchesSearch = v.check_name.toLowerCase().includes(state.searchQuery.toLowerCase())
    if (!matchesSearch) return false

    if (state.filterStatus === 'verified') {
      return typeof isFieldVerified === 'function' && isFieldVerified(v.field_path)
    }
    if (state.filterStatus === 'unverified') {
      return typeof isFieldVerified === 'function' && !isFieldVerified(v.field_path)
    }
    return true
  }

  const filteredMismatches = mismatches.filter(filterFn)
  const filteredMatches = matches.filter(filterFn)
  const filteredLineItemMismatches = analysisData.validations
    .filter(v => v.isLineItem && v.status === 'FAIL')
    .filter(filterFn)
  const filteredLineItemMatches = analysisData.validations
    .filter(v => v.isLineItem && v.status === 'PASS')
    .filter(filterFn)

  // Update badges with filtered counts
  const mismatchBadge = document.getElementById("mismatch-badge");
  if (mismatchBadge) mismatchBadge.textContent = filteredMismatches.length + filteredLineItemMismatches.length;

  const matchBadge = document.getElementById("match-badge");
  if (matchBadge) matchBadge.textContent = filteredMatches.length + filteredLineItemMatches.length;

  const currentList = state.activeTab === "mismatches" ? mismatches : matches
  const filtered = currentList.filter(filterFn)
  if (filtered.length === 0) {
    const isSearch = state.searchQuery.length > 0
    const isMismatchTab = state.activeTab === "mismatches"

    listEl.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon" style="background: ${isMismatchTab && !isSearch ? "var(--success-light)" : "var(--bg)"}; color: ${isMismatchTab && !isSearch ? "var(--success)" : "var(--text-muted)"}">
          ${isMismatchTab && !isSearch ? icons.checkCircle : icons.file}
        </div>
        <div class="empty-title">${isSearch ? "No results found" : isMismatchTab ? "No mismatches found" : "No matches found"}</div>
        <div class="empty-desc">${isSearch ? "Try a different search term" : isMismatchTab ? "All checked fields are matching" : "No matching fields found"}</div>
      </div>
    `
    return
  }

  // Group validations by session
  const grouped = groupValidationsBySession(filtered)

  // Render grouped validations with session headers
  let html = ''

  for (const [sessionName, validations] of grouped.entries()) {
    // Session header
    html += `<div class="session-header">${escapeHtml(sessionName)}</div>`

    // Render validations in this session
    html += validations.map((validation) => {
      const originalIndex = analysisData.validations.indexOf(validation);
      const isMismatch = validation.status === "FAIL"

      const isLineItemCard = validation.field_path === 'cargo_summary.line_items' || validation.check_name === 'Line Items';
      const clickAction = isLineItemCard
        ? `openLineItemTable()`
        : `openGridView(${originalIndex})`;

      const title = isLineItemCard
        ? 'Line Items'
        : formatFieldName(escapeHtml(validation.check_name));

      const activeClass = (isLineItemCard && state.lineItemViewOpen) || (!isLineItemCard && state.gridViewValidation === validation) ? 'active' : '';

      const isCardVerified = typeof isFieldVerified === 'function' ? isFieldVerified(validation.field_path) : false;
      const cardVerificationBadge = isCardVerified ? `<span class="verification-pill">Verified</span>` : '';

      // Check if this validation has any overrides
      let cardActionBadge = ''
      if (validation.evidence && validation.evidence.length > 0) {
        const overrideActions = new Set()
        for (const ev of validation.evidence) {
          const docName = ev.doc_name
          const fieldPath = validation.field_path
          if (typeof isFieldOverridden === 'function' && isFieldOverridden(docName, fieldPath)) {
            const overrideInfo = typeof getOverrideInfo === 'function' ? getOverrideInfo(docName, fieldPath) : null
            if (overrideInfo && overrideInfo.action) {
              overrideActions.add(overrideInfo.action)
            }
          }
        }

        if (overrideActions.size > 0) {
          // Show badge based on most prominent action
          let badgeText = 'Modified'
          let badgeClass = 'action-badge-update'

          if (overrideActions.has('sync_from_master')) {
            badgeText = 'Synced'
            badgeClass = 'action-badge-sync'
          } else if (overrideActions.has('restore')) {
            badgeText = 'Restored'
            badgeClass = 'action-badge-restore'
          } else if (overrideActions.has('update')) {
            badgeText = 'Edited'
            badgeClass = 'action-badge-update'
          } else if (overrideActions.has('ai_enhancement')) {
            badgeText = 'AI Enhanced'
            badgeClass = 'action-badge-update'
          }

          cardActionBadge = `<span class="override-badge ${badgeClass}" style="font-size: 0.65rem; padding: 0.15rem 0.4rem; margin-left: 0.25rem;">${badgeText}</span>`
        }
      }

      // Check for hidden documents
      const hiddenDocs = typeof getHiddenDocsForField === 'function' ? getHiddenDocsForField(validation.field_path) : new Set()
      const hiddenCount = hiddenDocs.size
      const hiddenBadge = hiddenCount > 0 ? `<span class="hidden-docs-badge" title="${hiddenCount} documents hidden" style=" display: inline-flex; align-items: center; gap: 0.25rem; font-size: 0.7rem; color: var(--text-muted); background: var(--bg-hover); padding: 0.1rem 0.4rem; border-radius: 4px;">${icons.eyeOff} ${hiddenCount}</span>` : ''

      // Get individual line item validations if this is line_items card
      let subItemsHtml = '';
      if (isLineItemCard && state.lineItemsExpanded) {
        const itemValidations = analysisData.validations.filter(v => v.isLineItem);
        subItemsHtml = itemValidations.map(itemVal => {
          const itemIndex = analysisData.validations.indexOf(itemVal);
          const itemMismatch = itemVal.status === 'FAIL';
          const itemActive = state.gridViewValidation === itemVal ? 'active' : '';
          const itemVerified = typeof isFieldVerified === 'function' ? isFieldVerified(itemVal.field_path) : false;
          const itemVerificationBadge = itemVerified ? `<span class="verification-pill">Verified</span>` : '';

          // Check for overrides in this line item
          let itemActionBadge = ''
          if (itemVal.evidence && itemVal.evidence.length > 0) {
            const itemOverrideActions = new Set()
            for (const ev of itemVal.evidence) {
              const docName = ev.doc_name
              // Use fieldValues from evidence which contains correct fieldPath format
              // (cargo_summary.line_items.items.N.field instead of description-based paths)
              if (ev.fieldValues && typeof dataOverrides !== 'undefined' && dataOverrides.overrides[docName]) {
                for (const fieldKey in ev.fieldValues) {
                  const fieldData = ev.fieldValues[fieldKey]
                  if (fieldData && fieldData.fieldPath) {
                    if (typeof isFieldOverridden === 'function' && isFieldOverridden(docName, fieldData.fieldPath)) {
                      const overrideInfo = typeof getOverrideInfo === 'function' ? getOverrideInfo(docName, fieldData.fieldPath) : null
                      if (overrideInfo && overrideInfo.action) {
                        itemOverrideActions.add(overrideInfo.action)
                      }
                    }
                  }
                }
              }
            }

            if (itemOverrideActions.size > 0) {
              let badgeText = 'Modified'
              let badgeClass = 'action-badge-update'

              if (itemOverrideActions.has('sync_from_master')) {
                badgeText = 'Synced'
                badgeClass = 'action-badge-sync'
              } else if (itemOverrideActions.has('restore')) {
                badgeText = 'Restored'
                badgeClass = 'action-badge-restore'
              } else if (itemOverrideActions.has('update')) {
                badgeText = 'Edited'
                badgeClass = 'action-badge-update'
              } else if (itemOverrideActions.has('ai_enhancement')) {
                badgeText = 'AI Enhanced'
                badgeClass = 'action-badge-update'
              }

              itemActionBadge = `<span class="override-badge ${badgeClass}" style="font-size: 0.7rem; padding: 0.125rem 0.375rem; margin-left: 0.25rem;">${badgeText}</span>`
            }
          }

          // Check for hidden docs for sub-item
          const itemHiddenDocs = typeof getHiddenDocsForField === 'function' ? getHiddenDocsForField(itemVal.field_path) : new Set()
          const itemHiddenCount = itemHiddenDocs.size
          const itemHiddenBadge = itemHiddenCount > 0 ? `<span class="hidden-docs-badge" title="${itemHiddenCount} documents hidden" style="display: inline-flex; align-items: center; gap: 0.25rem; font-size: 0.6rem; color: var(--text-muted); background: var(--bg-hover); padding: 0.1rem 0.3rem; border-radius: 4px;">${icons.eyeOff} ${itemHiddenCount}</span>` : ''

          return `
            <div class="validation-card-subitem ${itemMismatch ? 'mismatch' : 'match'} ${itemActive}" onclick="openGridView(${itemIndex})">
              <div class="subitem-content">
                <div class="subitem-left">
                  <span class="subitem-icon">${icons.file}</span>
                  <span class="subitem-label">${escapeHtml(itemVal.check_name)}</span>
                  ${itemActionBadge}
                  ${itemVerificationBadge}
                  ${itemHiddenBadge}
                  <span class="tree-status-badge ${itemVal.status.toLowerCase()}">${itemVal.status}</span>
                </div>
              </div>
            </div>
          `;
        }).join('');
      }

      return `
        <div class="validation-card ${isMismatch ? 'mismatch' : 'match'} ${activeClass}" id="card-${originalIndex}">
          <div class="card-header" onclick="${clickAction}">
            <div class="card-header-content">
              <div class="card-header-left">
                <div class="card-icon ${isMismatch ? 'mismatch' : 'match'}">
                  ${isLineItemCard ? icons.grid : (isMismatch ? icons.xCircle : icons.checkCircle)}
                </div>
              <div class="card-info">
                <div class="card-title">
                  ${title}
                  <div style="display: inline-flex; align-items: center;gap:0.1rem;">
                    ${cardActionBadge}
                    ${cardVerificationBadge}
                    ${hiddenBadge}
                  </div>
                </div>
                <div class="card-analysis">
                  ${validation.analysis}
                </div>
              </div>
              </div>
              <div class="card-header-right">
                ${isLineItemCard ? `
                  <button class="tree-view-btn" onclick="event.stopPropagation(); openLineItemTableDirect()" title="View table" style="margin-right: 8px;">
                    ${icons.table}
                  </button>
                ` : ''}

                ${isLineItemCard ? `
                  <button class="tree-toggle tree-view-btn ${state.lineItemsExpanded ? 'expanded' : ''}" onclick="event.stopPropagation(); toggleLineItemsExpand()" style="margin-right: 4px;">
                    ${icons.chevronRight}
                  </button>
                ` : ''}
              </div>
            </div>
          </div>
          ${subItemsHtml ? `<div class="validation-card-subitems">${subItemsHtml}</div>` : ''}
        </div>
      `
    }).join('')
  }

  listEl.innerHTML = html

  // Restore scroll position after re-rendering
  listEl.scrollTop = scrollTop
}

function renderDocumentList() {
  const listEl = document.getElementById("validation-list")
  const documents = Object.values(registry)

  if (documents.length === 0) {
    listEl.innerHTML = `
          <div class="empty-state">
            <div class="empty-icon">${icons.file}</div>
            <div class="empty-title">No Documents Found</div>
            <div class="empty-desc">The registry.json file appears to be empty or missing.</div>
          </div>
        `
    return
  }

  listEl.innerHTML = `
        <div class="document-list">
            ${documents.sort((a, b) => a.page_start - b.page_start).map(doc => {
    const pageText = doc.page_start === doc.page_end
      ? `Page ${doc.page_start + 1}`
      : `Pages ${doc.page_start + 1}-${doc.page_end + 1}`

    const isEnabled = state.enabledDocuments.has(doc.doc_name)
    // Use documentViewerDocName for active state when available
    const isActive = state.viewerOpen && (
      state.documentViewerDocName
        ? doc.doc_name === state.documentViewerDocName
        : (state.currentPage >= doc.page_start && state.currentPage <= doc.page_end)
    )

    return `
                    <div class="doc-card ${!isEnabled ? 'disabled' : ''} ${isActive ? 'active' : ''}">
                        <label class="doc-card-checkbox" onclick="event.stopPropagation()">
                            <input type="checkbox" 
                                ${isEnabled ? 'checked' : ''}
                                onchange="toggleDocumentEnabled('${escapeHtml(doc.doc_name)}')">
                        </label>
                        <div class="doc-card-clickable" data-doc="${escapeHtml(doc.doc_name)}" onclick="openDocumentFromList(this.dataset.doc, ${doc.page_start})">
                            <div class="doc-card-icon">
                                ${icons.file}
                            </div>
                            <div class="doc-card-info">
                                <div class="doc-card-name">${escapeHtml(doc.doc_name)}</div>
                                <div class="doc-card-type">${escapeHtml(doc.doc_type)}</div>
                            </div>
                            <div class="doc-card-right">
                                <span class="page-badge">${pageText}</span>
                            </div>
                        </div>
                    </div>
                `
  }).join('')}
        </div>
    `
}

// ============ MODAL RENDERING ============

function renderLineItemTable() {
  if (!lineItemTableData) {
    return '<div class="modal-body"><p>No line item data available.</p></div>';
  }

  const { headers, rows } = lineItemTableData;

  const headerHtml = headers.map(h => `<th>${escapeHtml(h)}</th>`).join('');

  const bodyHtml = rows.map((row, rowIndex) => {
    const hasDescriptions = row.descriptionValues && row.descriptionValues.length > 0
    const primaryDescription = hasDescriptions ? row.descriptionValues[0] : null
    const remainder = hasDescriptions ? row.descriptionValues.slice(1) : []
    const isExpanded = !!(state.descriptionExpanded && state.descriptionExpanded[rowIndex])

    const renderDescriptionItem = (descVal, valueIndex, collapsed = false) => {
      const editableId = `lineitem_table_desc_${sanitizeForId(rowIndex)}_${sanitizeForId(descVal.docName)}_${valueIndex}`
      const editableField = renderEditableField({
        fieldId: editableId,
        docName: descVal.docName,
        fieldPath: descVal.fieldPath,
        value: descVal.value ?? '',
        verificationPath: row.validationPath,
        wrapperClass: 'table-value-editor'
      })

      const viewButton = (descVal.boundBox && descVal.boundBox.length)
        ? `<button class="btn-doc-view" title="${escapeHtml(descVal.docName.replace(".pdf", ""))}" onclick="openViewer(${descVal.page}, ${encodeForAttribute(descVal.boundBox)}, '${escapeHtml(truncate(descVal.value || row.description || '', 20))}')">
            ${icons.eye}
          </button>`
        : ''

      return `<div class="table-cell-item ${collapsed ? 'collapsed' : ''}">
                ${editableField}
                ${viewButton}
              </div>`
    }

    const descriptionContent = hasDescriptions
      ? [
        renderDescriptionItem(primaryDescription, 0, false),
        remainder.map((descVal, idx) => renderDescriptionItem(descVal, idx + 1, !isExpanded)).join(''),
        remainder.length > 0
          ? `<button class="btn-toggle-desc ${isExpanded ? 'expanded' : ''}" data-row="${rowIndex}" onclick="toggleDescriptionExpand(${rowIndex})">
                <span class="toggle-label">${isExpanded ? 'Show Less' : `Show +${remainder.length} more`}</span>
                ${icons.chevronDown}
              </button>`
          : ''
      ].join('')
      : `<div class="table-cell-item"><em>(empty)</em></div>`

    const descriptionCell = `<td data-label="Item">${descriptionContent}</td>`;
    const fieldCells = headers.slice(1).map(header => {
      const field = row.fields[header];
      if (!field) return '<td></td>';

      const cellContent = field.values.map((v, valueIndex) => {
        const editableId = `lineitem_table_${sanitizeForId(rowIndex)}_${sanitizeForId(header)}_${sanitizeForId(v.docName)}_${valueIndex}`;
        const editableField = v.fieldPath
          ? renderEditableField({
            fieldId: editableId,
            docName: v.docName,
            fieldPath: v.fieldPath,
            value: v.value ?? '',
            verificationPath: row.validationPath,
            wrapperClass: 'table-value-editor'
          })
          : `<span class="value-text">${escapeHtml(String(v.value ?? ''))}</span>`;

        const viewButton = (v.boundBox && v.boundBox.length)
          ? `<button class="btn-doc-view" title="${escapeHtml(v.docName.replace(".pdf", ""))}" onclick="openViewer(${v.page}, ${encodeForAttribute(v.boundBox)}, '${escapeHtml(truncate(row.description, 20))}')">
              ${icons.eye}
            </button>`
          : '';

        return `<div class="table-cell-item ${!field.isConsistent ? 'inconsistent' : ''}">
                  ${editableField}
                  ${viewButton}
                </div>`;
      }).join('') || `<div class="table-cell-item"><em>(empty)</em></div>`;

      return `<td data-label="${escapeHtml(header)}">${cellContent}</td>`;
    }).join('');

    return `<tr>${descriptionCell}${fieldCells}</tr>`;
  }).join('');

  const fullscreenIcon = state.tableFullscreen ? icons.exitFullscreen : icons.fullscreen;

  return `
    <div class="modal-header">
      <div class="modal-header-left">
        <h3 class="modal-title">Line Items</h3>
      </div>
      <div class="modal-controls">
        <button class="btn-icon" onclick="closeViewer(true)" title="Back to Summary">
          ${icons.home}
        </button>
        <button class="btn-icon" onclick="toggleLineItemTableMode()" title="Switch to Grid View">
          ${icons.grid}
        </button>
        <button class="btn-icon" onclick="toggleFullscreenTable()" title="Toggle Fullscreen">
          ${fullscreenIcon}
        </button>
        <button class="btn-close" onclick="closeViewer()">${icons.x}</button>
      </div>
    </div>
    <div class="modal-body modal-body-table">
      <div class="table-wrapper">
        <table class="comparison-table">
          <thead>
            <tr>${headerHtml}</tr>
          </thead>
          <tbody>
            ${bodyHtml}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function toggleDescriptionExpand(rowIndex) {
  if (!state.descriptionExpanded) {
    state.descriptionExpanded = {}
  }
  state.descriptionExpanded[rowIndex] = !state.descriptionExpanded[rowIndex]
  renderModal()
}


function renderModal() {
  const modalContainer = document.getElementById("modal-container")
  if (!modalContainer) return

  // Save scroll positions before re-render
  const existingFieldList = modalContainer.querySelector('.document-field-list')
  if (existingFieldList) {
    state.documentFieldScrollTop = existingFieldList.scrollTop
  }
  const existingCanvas = modalContainer.querySelector('.document-viewer-canvas')
  if (existingCanvas) {
    state.documentCanvasScrollTop = existingCanvas.scrollTop
  }

  const isDesktop = window.innerWidth >= 1024
  const isMobileSummary = !isDesktop && state.mobileSummaryActive && !state.viewerOpen

  if (!state.viewerOpen) {
    if (isDesktop || isMobileSummary) {
      modalContainer.innerHTML = renderSummaryDashboard()
      if (isDesktop) {
        document.body.classList.add('split-view')
        document.body.classList.remove('mobile-summary-active')
      } else {
        document.body.classList.remove('split-view')
        document.body.classList.add('mobile-summary-active')
      }
    } else {
      modalContainer.innerHTML = ""
      document.body.classList.remove('split-view')
      document.body.classList.remove('mobile-summary-active')
    }
    return
  }

  document.body.classList.add('split-view');
  document.body.classList.remove('mobile-summary-active');

  let content = '';
  if (state.lineItemViewOpen && state.lineItemTableMode) {
    // Line items in table mode
    content = renderLineItemTable();
  } else if (state.gridViewOpen) {
    // Grid view (includes line items in grid mode)
    content = renderGridViewModal()
    setTimeout(drawCroppedCanvases, 200)
  } else {
    // Document viewer
    content = renderDocumentViewerModal()
    // Draw all pages
    setTimeout(drawAllPages, 100)
  }

  // In split view, we inject directly. In mobile, we wrap with an overlay.
  if (window.innerWidth < 1024) {
    modalContainer.innerHTML = `<div class="modal-overlay" onclick="closeViewer()"><div class="modal-container" onclick="event.stopPropagation()">${content}</div></div>`;
  } else {
    modalContainer.innerHTML = content;
  }

  // Restore scroll positions after re-render
  if (state.viewerOpen && !state.gridViewOpen && !state.lineItemViewOpen) {
    requestAnimationFrame(() => {
      // Restore field list scroll
      const listEl = modalContainer.querySelector('.document-field-list')
      if (listEl && typeof state.documentFieldScrollTop === 'number') {
        listEl.scrollTop = state.documentFieldScrollTop
      }
      // Restore canvas scroll
      const canvasEl = modalContainer.querySelector('.document-viewer-canvas')
      if (canvasEl && typeof state.documentCanvasScrollTop === 'number') {
        canvasEl.scrollTop = state.documentCanvasScrollTop
      }
    })
  }
}

function renderDocumentViewerModal() {
  // Find which document to display
  // Prioritize documentViewerDocName if set, otherwise find by current page
  let currentDoc = null;
  if (state.documentViewerDocName) {
    currentDoc = Object.values(registry).find(doc => doc.doc_name === state.documentViewerDocName);
  }
  if (!currentDoc) {
    currentDoc = Object.values(registry).find(doc =>
      state.currentPage >= doc.page_start && state.currentPage <= doc.page_end
    );
  }

  // Generate canvases for all pages in the document
  let canvasesHtml = ""
  if (currentDoc) {
    const totalDocPages = currentDoc.page_end - currentDoc.page_start + 1
    canvasesHtml = Array.from(
      { length: totalDocPages },
      (_, i) => {
        const pageIndex = currentDoc.page_start + i
        return `
          <div class="canvas-page-container" style="margin-bottom: 24px; position: relative;">
            <div class="page-label" style="text-align: center; font-size: 12px; color: var(--text-muted); margin-bottom: 8px;">Page ${pageIndex + 1}</div>
            <canvas id="page-canvas-${pageIndex}" class="page-canvas" data-page="${pageIndex}" style="box-shadow: var(--shadow-md); background: white; max-width: 100%; display: block; margin: 0 auto;"></canvas>
          </div>
        `
      }
    ).join("")
  } else {
    // Fallback if document not found
    canvasesHtml = `<div class="empty-state">Document not found for page ${state.currentPage}</div>`
  }

  const fieldLabel = state.selectedEvidence?.fieldName || "Document"
  const showBackButton = state.previousView === 'grid' || state.previousView === 'line-item-table'
  const showFieldPanel = state.documentViewerSource === 'document-list' && currentDoc
  const documentFields = showFieldPanel ? getDocumentFieldsForDoc(currentDoc.doc_name) : []
  const fieldPanelCollapsed = !!state.documentFieldPanelCollapsed
  const fieldPanelHtml = showFieldPanel ? `
    <div class="document-field-panel-wrapper ${fieldPanelCollapsed ? 'collapsed' : ''}">
      ${renderDocumentFieldsPanel(currentDoc.doc_name, documentFields, fieldPanelCollapsed)}
      <button class="document-field-panel-toggle" onclick="toggleDocumentFieldPanel()" title="${fieldPanelCollapsed ? 'Expand fields panel' : 'Collapse fields panel'}">
        ${fieldPanelCollapsed ? icons.chevronLeft : icons.chevronRight}
      </button>
    </div>
  ` : ""

  return `
    <div class="modal-header">
      <div class="modal-header-left">
        ${state.selectedEvidence ? `<span class="modal-title">${escapeHtml(fieldLabel)}</span>` : ""}
        ${currentDoc ? `<span class="modal-badge">${escapeHtml(currentDoc.doc_name)}</span>` : ""}
      </div>
      <div class="modal-controls">
        <button class="btn-icon btn-show-all-notes ${typeof isShowAllNotesEnabled === 'function' && isShowAllNotesEnabled() ? 'active' : ''}" 
                onclick="toggleShowAllNotes()" 
                data-tooltip="${typeof isShowAllNotesEnabled === 'function' && isShowAllNotesEnabled() ? 'Hide All Notes' : 'Show All Notes'}">
          ${icons.fileText || icons.file}
        </button>
        <button class="btn-icon" onclick="closeViewer(true)" data-tooltip="Back to Summary">
          ${icons.home}
        </button>
        <div class="zoom-controls">
          <button class="btn-icon" onclick="zoomOut()" data-tooltip="Zoom Out">${icons.zoomOut}</button>
          <span class="zoom-value">${Math.round(state.zoom * 100)}%</span>
          <button class="btn-icon" onclick="zoomIn()" data-tooltip="Zoom In">${icons.zoomIn}</button>
          <button class="btn-icon" onclick="resetZoom()" data-tooltip="Reset Zoom">${icons.reset}</button>
        </div>
        ${showBackButton ? `<button class="btn-back" onclick="backToGrid()" data-tooltip="Back to Previous">${icons.arrowLeft}</button>` : `
          <button class="btn-close" onclick="closeViewer()" data-tooltip="Close">${icons.x}</button>
        `}
      </div>
    </div>
    <div class="modal-body document-viewer-body">
      <div class="document-viewer-layout">
        <div class="document-viewer-canvas">
          <div class="canvas-wrapper" style="transform: translate(${state.panX || 0}px, ${state.panY || 0}px) scale(${state.zoom}); transform-origin: top center; padding: 2rem; display: flex; flex-direction: column; align-items: center;">
            ${canvasesHtml}
          </div>
        </div>
        ${fieldPanelHtml}
      </div>
    </div>
  `
}



function selectGridCard(cardElement) {
  // Remove active class from all other cards
  document.querySelectorAll('.grid-card').forEach(el => el.classList.remove('active'));
  // Add active class to clicked card
  cardElement.classList.add('active');
}

function renderGridViewModal() {
  const validation = state.gridViewValidation
  if (!validation) return '';

  // Check if this is a line item validation (individual item)
  const isLineItemChild = validation.isLineItem === true;
  const isLineItems = validation.check_name === 'Line Items' || validation.field_path === 'cargo_summary.line_items';

  // Get hidden documents for this field
  const hiddenDocs = getHiddenDocsForField(validation.field_path)
  const hiddenDocsArray = Array.from(hiddenDocs)

  // Filter out hidden documents from evidence - comparison only between visible docs
  const visibleEvidence = validation.evidence.filter(ev => !isDocHiddenForField(validation.field_path, ev.doc_name))

  // Determine master document and value for comparison (only from VISIBLE docs)
  const masterDoc = getMasterDoc(validation.field_path)
  // Master is only valid if it's visible (not hidden)
  const isMasterVisible = masterDoc && !isDocHiddenForField(validation.field_path, masterDoc)
  const masterEvidence = isMasterVisible ? visibleEvidence.find(ev => ev.doc_name === masterDoc) : null
  const masterValue = masterEvidence
    ? String(masterEvidence.value_found).trim().toUpperCase()
    : null

  // Get master field values for comparison (for line items)
  const masterFieldValues = masterEvidence?.fieldValues || null;

  // Check verification status
  const isVerified = typeof isFieldVerified === 'function' ? isFieldVerified(validation.field_path) : false

  // Build hidden section HTML
  let hiddenSectionHtml = ''
  if (hiddenDocsArray.length > 0) {
    const hiddenTags = hiddenDocsArray.map(docName => `
      <span class="hidden-doc-tag" onclick="showDocForField('${escapeHtml(validation.field_path)}', '${escapeHtml(docName)}')" title="Click to show this document">
        ${escapeHtml(docName)}
        <span class="hidden-doc-tag-icon">${icons.x}</span>
      </span>
    `).join('')

    hiddenSectionHtml = `
      <div class="hidden-docs-section">
        <div class="hidden-docs-header">
          <span class="hidden-docs-label">${icons.eyeOff} Hidden Documents (${hiddenDocsArray.length})</span>
          <button class="btn-show-all" onclick="showAllDocsForField('${escapeHtml(validation.field_path)}')" title="Show all hidden documents">
            Show All
          </button>
        </div>
        <div class="hidden-docs-tags">
          ${hiddenTags}
        </div>
      </div>
    `
  }

  return `
    <div class="modal-header">
      <div class="modal-header-left">
        <h3 class="modal-title">${formatFieldName(escapeHtml(validation.check_name))}</h3>
        ${isVerified ? `<span class="modal-badge" style="background: var(--primary-light); color: var(--primary);">Verified</span>` : ''}
      </div>
      <div class="modal-controls">
        <button class="btn-icon" onclick="closeViewer(true)" data-tooltip="Back to Summary">
          ${icons.home}
        </button>
        <label class="verification-toggle" data-tooltip="Mark as verified">
          <input type="checkbox" ${isVerified ? 'checked' : ''} onchange="toggleCurrentVerification()">
          <span class="verification-toggle-slider"></span>
          <span class="verification-toggle-label">Verified</span>
        </label>
        ${isLineItems ? `<button class="btn-icon" onclick="toggleLineItemTableMode()" data-tooltip="${state.lineItemTableMode ? 'Grid View' : 'Table View'}">${state.lineItemTableMode ? icons.grid : icons.table}</button>` : ''}
        <button class="btn-close" onclick="closeViewer()">${icons.x}</button>
      </div>
    </div>
    <div class="modal-body">
      ${hiddenSectionHtml}
      <div class="grid-view ${isLineItemChild ? 'line-item-grid' : ''}">
        ${visibleEvidence
      .map(
        (ev, idx) => {
          // Get original index in validation.evidence (not filtered array)
          const originalIdx = validation.evidence.findIndex(e => e.doc_name === ev.doc_name)

          const currentValue = String(ev.value_found).trim().toUpperCase()
          const isMaster = masterDoc && ev.doc_name === masterDoc
          const matchesMaster = masterValue && currentValue === masterValue

          // Determine card class based on master comparison
          let cardClass = 'grid-card'
          if (isMaster) {
            cardClass += ' master'
          } else if (masterValue) {
            cardClass += matchesMaster ? ' match' : ' mismatch'
          }

          // For line item children, add field info section
          let fieldInfoHtml = '';
          if (isLineItemChild && ev.fieldValues) {
            const labelMap = {
              description_exact: 'Description',
              line_no: 'Line Number',
              brand: 'Brand',
              hs_code: 'HS Code',
              country_of_origin: 'Origin',
              quantity: 'Quantity',
              unit: 'Unit',
              unit_price: 'Unit Price',
              line_total: 'Line Total',
              net_weight_kg: 'Net Weight (kg)'
            };

            const fieldRows = Object.entries(ev.fieldValues)
              .sort(([aKey], [bKey]) => {
                if (aKey === 'description_exact') return -1;
                if (bKey === 'description_exact') return 1;
                return aKey.localeCompare(bKey);
              })
              .map(([fieldKey, fieldData]) => {
                const label = labelMap[fieldKey] || formatFieldName(fieldKey);

                const value = fieldData.value ?? '';
                const isInconsistent = fieldData.isInconsistent;

                // Check if this value differs from master
                let differFromMaster = false;
                if (!isMaster && masterFieldValues && masterFieldValues[fieldKey] && fieldKey !== 'description_exact') {
                  const masterVal = String(masterFieldValues[fieldKey].value ?? '').trim().toUpperCase();
                  const currentVal = String(value).trim().toUpperCase();
                  differFromMaster = masterVal !== currentVal && currentVal !== '' && masterVal !== '';
                }

                const rowClass = isInconsistent || differFromMaster ? 'mismatch' : '';

                const inlineId = `lineitem_${sanitizeForId(ev.doc_name)}_${sanitizeForId(validation.field_path)}_${sanitizeForId(fieldKey)}`;
                const editable = fieldData.fieldPath
                  ? renderEditableField({
                    fieldId: inlineId,
                    docName: fieldData.docName || ev.doc_name,
                    fieldPath: fieldData.fieldPath,
                    value: value,
                    verificationPath: fieldData.validationPath || validation.field_path,
                    wrapperClass: 'line-item-editable'
                  })
                  : `<span class="value-text">${escapeHtml(String(value))}</span>`;

                return `<div class="field-row ${rowClass}">
                <span class="field-label">${escapeHtml(label)}</span>
                <div class="field-value">${editable}</div>
              </div>`;
              }).join('');

            fieldInfoHtml = `<div class="line-item-fields collapsed">
              <div class="fields-toggle" onclick="this.parentElement.classList.toggle('collapsed')">
                <span class="toggle-text">Show Details</span>
                <span class="toggle-icon">${icons.chevronDown}</span>
              </div>
              <div class="fields-content">${fieldRows}</div>
            </div>`;
          }

          // Prepare multi-box data for canvas
          const fieldBoxesData = ev.fieldBoxes ? JSON.stringify(ev.fieldBoxes) : '[]';

          const cardStatus = isMaster ? 'master' : (masterValue ? (matchesMaster ? 'match' : 'mismatch') : (validation.status === 'PASS' ? 'match' : 'mismatch'));

          let masterControl = ''
          if (!state.readOnlyMode) {
            masterControl = `
              <label class="master-checkbox">
                <input type="radio"
                  name="master-evidence"
                  ${isMaster ? 'checked' : ''}
                  onchange="setMasterEvidence(${originalIdx})">
                <span class="checkbox-label">Set as Master</span>
              </label>
            `
          } else if (isMaster) {
            masterControl = `
              <div class="master-chip" title="Master evidence">Master</div>
            `
          }

          const syncButton = state.readOnlyMode ? '' : (isMaster ? `
            <button class="btn-sync-master" onclick="syncMasterToOthers(state.gridViewValidation)" title="Sync this master value to all other files">
              ${icons.refreshCw} Sync to Other Files
            </button>
          ` : '')

          return `
              <div class="grid-card ${cardClass}" onclick="selectGridCard(this)" data-original-index="${originalIdx}">
                <div class="grid-card-header">
                  ${masterControl}
                  <div class="grid-card-actions">
                    ${syncButton}
                    <button class="btn-add-note" onclick="event.stopPropagation(); addFieldNote('${escapeHtml(ev.doc_name)}', '${escapeHtml(validation.field_path)}', ${ev.source_page_index}, '${escapeHtml(validation.check_name)}')" data-tooltip="Add note">
                      ${icons.messageSquare}
                    </button>
                    <button class="btn-hide-doc" onclick="hideDocForField('${escapeHtml(validation.field_path)}', '${escapeHtml(ev.doc_name)}')" data-tooltip="Hide document">
                      ${icons.eyeOff}
                    </button>
                  </div>
                </div>
                <div class="grid-card-canvas">
                  <canvas class="cropped-canvas ${isLineItemChild ? 'multi-box-canvas' : ''}" 
                    data-page="${ev.source_page_index}" 
                    data-box='${JSON.stringify(ev.bounding_box)}' 
                    data-field-boxes="${encodeForAttribute(ev.fieldBoxes || [])}"
                    data-status="${validation.status}"
                    data-card-type="${cardStatus}">
                  </canvas>
                  <button class="grid-card-zoom" onclick="openViewerFromGrid(${ev.source_page_index}, ${encodeForAttribute(ev.bounding_box)}, '${escapeHtml(validation.check_name)}', ${isLineItemChild ? encodeForAttribute(ev.fieldBoxes || []) : 'null'}, '${cardStatus}')" data-tooltip="View Full Page">
                    ${icons.fullscreen}
                  </button>
                </div>
                <div class="grid-card-info">
                  <div class="grid-card-doc">${escapeHtml(ev.doc_name)} - Page ${ev.source_page_index + 1}</div>
                  ${!isLineItemChild ? renderEditableValue(ev, validation, isMaster, masterValue, matchesMaster) : ''}
                </div>
                ${fieldInfoHtml}
              </div>
            `
        },
      )
      .join("")
    }
      </div >
    ${!validation.evidence || validation.evidence.length === 0
      ? `
            <div class="empty-state">
              <div class="empty-icon">${icons.file}</div>
              <div class="empty-title">No evidence found</div>
            </div>
          `
      : ""
    }
    </div >
    `
}
