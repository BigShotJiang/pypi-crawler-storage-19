// ============ EVENT HANDLERS ============
function toggleCard(cardId) {
  // Accordion behavior: if we are expanding a card, collapse all others
  if (!state.expandedCards[cardId]) {
    // Clear all expanded states
    state.expandedCards = {}
    // Expand the clicked one
    state.expandedCards[cardId] = true
  } else {
    // If clicking an already expanded card, just toggle it (collapse it)
    state.expandedCards[cardId] = false
  }
  renderValidationList()
}

function setActiveTab(tab) {
  state.activeTab = tab
  document.querySelectorAll(".tab-button").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.tab === tab)
  })
  renderValidationList()
}

function handleSearch(value) {
  state.searchQuery = value
  renderValidationList()
}

// ============ DOCUMENT TOGGLE HANDLERS ============
function toggleDocumentEnabled(docName) {
  if (state.enabledDocuments.has(docName)) {
    state.enabledDocuments.delete(docName)
  } else {
    state.enabledDocuments.add(docName)
  }

  // Re-run analysis with new document set
  performAnalysis()
  render()
}

// ============ INITIALIZATION ============
document.addEventListener("DOMContentLoaded", () => {
  // Theme support - priority: URL param > localStorage > system preference
  const params = new URLSearchParams(window.location.search)
  const urlTheme = params.get('theme')
  const storedTheme = localStorage.getItem('theme')

  let isDark = false
  if (urlTheme === 'dark' || urlTheme === 'light') {
    // URL param takes priority
    isDark = urlTheme === 'dark'
  } else if (storedTheme === 'dark' || storedTheme === 'light') {
    // Then localStorage
    isDark = storedTheme === 'dark'
  } else {
    // Fall back to system preference (if localStorage is empty or 'system')
    isDark = window.matchMedia('(prefers-color-scheme: dark)').matches
  }

  if (isDark) {
    document.body.classList.add('dark-theme')
  }

  document.querySelectorAll(".tab-button").forEach((btn) => {
    btn.addEventListener("click", () => setActiveTab(btn.dataset.tab))
  })

  const headerLeft = document.querySelector('.header-left')
  if (headerLeft) {
    headerLeft.addEventListener('click', () => handleHeaderLeftClick())
  }

  document.getElementById("search-input").addEventListener("input", (e) => {
    handleSearch(e.target.value)
  })

  document.getElementById("filter-status").addEventListener("change", (e) => {
    state.filterStatus = e.target.value
    renderValidationList()
  })

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && state.viewerOpen) {
      closeViewer()
    }
  })

  // Default split view on desktop
  if (window.innerWidth >= 1024) {
    document.body.classList.add('split-view')
    state.mobileSummaryActive = false
  } else {
    state.mobileSummaryActive = true
  }

  loadData().then(() => {
    // Data loaded, initialize changelog viewer
    initializeChangelogViewer()
    // Initialize notes panel
    if (typeof initializeNotesPanel === 'function') {
      initializeNotesPanel()
    }
  })

  window.addEventListener('resize', handleWindowResize)
})

let resizeTimeout = null
let previousWidth = window.innerWidth

function handleWindowResize() {
  // Debounce resize events
  if (resizeTimeout) clearTimeout(resizeTimeout)

  resizeTimeout = setTimeout(() => {
    const currentWidth = window.innerWidth
    const wasDesktop = previousWidth >= 1024
    const isDesktop = currentWidth >= 1024

    // Only re-render if crossing the breakpoint
    if (wasDesktop !== isDesktop) {
      if (isDesktop) {
        // Switched to desktop
        document.body.classList.add('split-view')
        document.body.classList.remove('mobile-summary-active')
        state.mobileSummaryActive = false
      } else {
        // Switched to mobile
        document.body.classList.remove('split-view')
        state.mobileSummaryActive = true
      }

      // Re-render modal to update layout
      if (typeof renderModal === 'function') {
        renderModal()
      }
    }

    previousWidth = currentWidth
  }, 150)
}

function handleHeaderLeftClick() {
  if (window.innerWidth >= 1024) return

  if (state.viewerOpen) {
    closeViewer(true)
    return
  }

  state.mobileSummaryActive = true
  renderModal()
}
