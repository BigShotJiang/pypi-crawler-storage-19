// ============ UTILITIES ============
function escapeHtml(str) {
  if (str === null || str === undefined) return ""
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
}

function truncate(str, n) {
  if (!str) return ""
  return (str.length > n) ? str.slice(0, n - 1) + '…' : str;
}

function formatFieldName(name) {
  return name
    .replace(/_/g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .split(" ")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(" ")
}

function encodeForAttribute(obj) {
  return JSON.stringify(obj).replace(/"/g, "&quot;")
}

function getNotificationIcon(type) {
  if (typeof icons === 'undefined') return ''
  if (type === 'success') return icons.checkCircle
  if (type === 'danger') return icons.alertTriangle
  if (type === 'warning') return icons.alertTriangle
  return icons.info
}

function createNotificationDialog(options = {}) {
  const {
    title = 'Notice',
    message = '',
    type = 'info',
    confirmText = 'OK',
    cancelText = 'Cancel',
    showCancel = false
  } = options

  return new Promise((resolve) => {
    const overlay = document.createElement('div')
    overlay.className = 'notification-overlay'

    const iconClass = ['notification-icon']
    if (type === 'warning' || type === 'danger' || type === 'success') {
      iconClass.push(type === 'danger' ? 'danger' : type === 'success' ? 'success' : 'warning')
    }

    const confirmClass = ['notification-btn', 'primary', type === 'danger' ? 'danger' : type === 'success' ? 'success' : type === 'warning' ? 'warning' : ''].join(' ').trim()
    const safeTitle = escapeHtml(title)
    const safeMessage = escapeHtml(String(message || '')).replace(/\n/g, '<br>')

    overlay.innerHTML = `
      <div class="notification-dialog">
        <div class="${iconClass.join(' ')}">${getNotificationIcon(type)}</div>
        <div class="notification-title">${safeTitle}</div>
        <div class="notification-message">${safeMessage}</div>
        <div class="notification-buttons">
          ${showCancel ? `<button class="notification-btn secondary" data-action="cancel">${escapeHtml(cancelText)}</button>` : ''}
          <button class="${confirmClass}" data-action="confirm">${escapeHtml(confirmText)}</button>
        </div>
      </div>
    `

    document.body.appendChild(overlay)

    const confirmBtn = overlay.querySelector('[data-action="confirm"]')
    const cancelBtn = overlay.querySelector('[data-action="cancel"]')

    function cleanup(result) {
      overlay.classList.remove('visible')
      document.removeEventListener('keydown', handleKeydown)
      resolve(result)
      setTimeout(() => overlay.remove(), 180)
    }

    function handleKeydown(e) {
      if (e.key === 'Escape' && showCancel) {
        cleanup(false)
      } else if (e.key === 'Enter') {
        cleanup(true)
      }
    }

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay && showCancel) {
        cleanup(false)
      }
    })

    confirmBtn.addEventListener('click', () => cleanup(true))
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => cleanup(false))
    }

    document.addEventListener('keydown', handleKeydown)
    requestAnimationFrame(() => overlay.classList.add('visible'))
    setTimeout(() => confirmBtn.focus(), 50)
  })
}

function showAlertDialog(message, options = {}) {
  return createNotificationDialog({
    ...options,
    message,
    showCancel: false
  })
}

function showConfirmDialog(message, options = {}) {
  return createNotificationDialog({
    title: options.title || 'Are you sure?',
    message,
    type: options.type || 'warning',
    confirmText: options.confirmText || 'Confirm',
    cancelText: options.cancelText || 'Cancel',
    showCancel: true
  })
}

function showToast(message, options = {}) {
  if (!message) return
  const { type = 'info', duration = 4000 } = options

  let container = document.getElementById('notification-toast-container')
  if (!container) {
    container = document.createElement('div')
    container.id = 'notification-toast-container'
    container.className = 'notification-toast-container'
    document.body.appendChild(container)
  }

  const toast = document.createElement('div')
  toast.className = `notification-toast ${type}`
  toast.innerHTML = `<div class="notification-toast-message">${escapeHtml(String(message))}</div>`
  container.appendChild(toast)

  requestAnimationFrame(() => toast.classList.add('visible'))

  setTimeout(() => {
    toast.classList.remove('visible')
    setTimeout(() => toast.remove(), 180)
  }, duration)
}

// ============ SMART TOOLTIP POSITIONING ============
// Calculates optimal tooltip position based on viewport boundaries

function calculateTooltipPosition(element) {
  const rect = element.getBoundingClientRect()
  const viewportWidth = window.innerWidth
  const viewportHeight = window.innerHeight

  // Estimated tooltip dimensions
  const tooltipWidth = 120
  const tooltipHeight = 30

  let posX = 'center'  // center, left, right
  let posY = 'bottom'  // top, bottom

  // Check horizontal position
  if (rect.left < tooltipWidth / 2) {
    posX = 'right'  // Tooltip should align right (appear to the right)
  } else if (rect.right + tooltipWidth / 2 > viewportWidth) {
    posX = 'left'   // Tooltip should align left (appear to the left)
  }

  // Check vertical position - if near bottom, show tooltip on top
  if (rect.bottom + tooltipHeight + 20 > viewportHeight) {
    posY = 'top'
  }

  // Combine positions
  if (posY === 'top' && posX === 'center') return 'top'
  if (posY === 'top' && posX === 'left') return 'top-left'
  if (posY === 'top' && posX === 'right') return 'top-right'
  if (posX === 'left') return 'left'
  if (posX === 'right') return 'right'

  return ''  // Default center-bottom
}

function initSmartTooltips() {
  // Add mouseenter listener to all elements with data-tooltip
  document.addEventListener('mouseenter', function (e) {
    const target = e.target.closest('[data-tooltip]')
    if (!target) return

    const pos = calculateTooltipPosition(target)
    if (pos) {
      target.setAttribute('data-tooltip-pos', pos)
    } else {
      target.removeAttribute('data-tooltip-pos')
    }
  }, true)
}

// Initialize smart tooltips when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initSmartTooltips)
} else {
  initSmartTooltips()
}
