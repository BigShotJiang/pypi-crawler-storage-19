// ============ SUMMARY DATA GENERATION ============
function generateSummaryData() {
  if (!analysisData) return null

  const totalValidations = analysisData.validations.length
  const passCount = analysisData.validations.filter(v => v.status === 'PASS').length
  const failCount = analysisData.validations.filter(v => v.status === 'FAIL').length
  const documentCount = Object.keys(registry || {}).length

  // Count verifications
  let verifiedCount = 0
  if (typeof getVerifications === 'function') {
    const verificationStore = getVerifications()
    const verificationEntries = Object.entries(verificationStore?.verifications || {})
    const fieldPaths = new Set(analysisData.validations.map(v => v.field_path))

    verifiedCount = verificationEntries.filter(([path, info]) =>
      fieldPaths.has(path) && info && info.verified === true
    ).length
  }

  // Determine overall status
  let status = 'Complete'
  let statusColor = 'success'
  if (failCount > 0) {
    status = 'Issues Found'
    statusColor = 'danger'
  } else if (passCount === totalValidations) {
    status = 'All Passed'
    statusColor = 'success'
  }

  // Generate insights/action fallbacks
  const fallbackInsights = []
  if (failCount > 0) {
    fallbackInsights.push(`${failCount} validation${failCount > 1 ? 's' : ''} failed and require${failCount === 1 ? 's' : ''} attention`)
  }
  if (verifiedCount > 0) {
    fallbackInsights.push(`${verifiedCount} field${verifiedCount > 1 ? 's' : ''} manually verified`)
  }
  if (passCount === totalValidations && totalValidations > 0) {
    fallbackInsights.push('All validations passed successfully')
  }

  const fallbackActions = []
  if (failCount > 0) {
    fallbackActions.push('Review and resolve validation failures')
    fallbackActions.push('Consider syncing values from master documents')
  }
  if (verifiedCount < totalValidations) {
    fallbackActions.push(`Verify remaining ${totalValidations - verifiedCount} fields`)
  }

  const summarySource = window.staticSummaryData || {}
  const summaryInsights = Array.isArray(summarySource.insights) && summarySource.insights.length > 0
    ? summarySource.insights
    : fallbackInsights
  const summaryActions = Array.isArray(summarySource.actions) && summarySource.actions.length > 0
    ? summarySource.actions
    : fallbackActions

  return {
    batchId: summarySource.batchId || analysisData.batch_id || 'Document Batch',
    status: summarySource.status || status,
    statusColor: summarySource.statusColor || statusColor,
    documents: typeof summarySource.documents === 'number' ? summarySource.documents : documentCount,
    validationSummary: {
      pass: passCount,
      fail: failCount,
      total: totalValidations,
      verified: verifiedCount
    },
    insights: summaryInsights,
    actions: summaryActions
  }
}

// ============ DATA LOADING ============

// Get batch_id from URL parameter
function getBatchIdFromUrl() {
  const urlParams = new URLSearchParams(window.location.search)
  return urlParams.get('batch_id')
}

// Get base path for batch data
function getBatchBasePath() {
  const batchId = getBatchIdFromUrl()
  if (batchId) {
    // Data is in batch_data/{batch_id}/
    return `../batch_data/${encodeURIComponent(batchId)}`
  }
  // Fallback to legacy path (parent directory)
  return '..'
}

// Store current batch info globally
let currentBatchId = null
let batchBasePath = '..'

async function loadData() {
  try {
    const usingEmbeddedData = !!(window.__embeddedRegistry && window.__embeddedDocuments)

    // Get batch ID and base path
    currentBatchId = getBatchIdFromUrl()
    batchBasePath = getBatchBasePath()

    // Store in state for other modules to access
    state.batchId = currentBatchId
    state.batchBasePath = batchBasePath

    if (usingEmbeddedData) {
      state.readOnlyMode = true
      window.staticSummaryData = window.__embeddedSummary || null
      window.summaryData = window.__embeddedSummary || null
    }

    // Initialize overrides, masters and verifications systems first
    await initializeOverrides()
    await initializeMasters()
    await initializeVerifications()

    let staticSummary = null
    if (!usingEmbeddedData) {
      // Add timestamp to prevent browser caching
      const cacheBuster = `?t=${Date.now()}`

      // Try to load static summary.json (optional)
      const summaryResp = await fetch(`${batchBasePath}/summary.json${cacheBuster}`).catch(e => null)
      staticSummary = summaryResp ? await summaryResp.json() : null
      window.staticSummaryData = staticSummary || null
      if (staticSummary) {
        window.summaryData = staticSummary
      }
    } else if (window.__embeddedSummary) {
      staticSummary = window.__embeddedSummary
    }

    let registryDocs = []
    if (usingEmbeddedData) {
      registryDocs = Array.isArray(window.__embeddedRegistry?.registry)
        ? window.__embeddedRegistry.registry
        : []
    } else {
      const cacheBuster = `?t=${Date.now()}`
      const regResp = await fetch(`${batchBasePath}/registry.json${cacheBuster}`)
      const regData = await regResp.json()
      registryDocs = Array.isArray(regData.registry) ? regData.registry : []
    }

    if (window.summaryData) {
      window.summaryData = { ...window.summaryData, documents: registryDocs.length }
    }

    registryDocs.forEach((doc) => {
      registry[doc.doc_name] = doc
    })

    totalPages = registryDocs.reduce((max, doc) => {
      const pageEnd = doc.page_end ?? doc.page_start ?? 0
      return Math.max(max, pageEnd + 1)
    }, 1)

    if (usingEmbeddedData) {
      const embeddedDocs = window.__embeddedDocuments || {}
      for (const doc of registryDocs) {
        const originalData = embeddedDocs[doc.doc_name]
        if (originalData) {
          documents[doc.doc_name] = originalData
        }
      }
    } else {
      // Parallel loading with error handling (8-10x faster than sequential)
      const cacheBuster = `?t=${Date.now()}`

      const docPromises = registryDocs.map(async (doc) => {
        try {
          const resp = await fetch(`${batchBasePath}/data/${doc.doc_name}.json${cacheBuster}`)
          if (!resp.ok) {
            console.error(`Failed to load ${doc.doc_name}: ${resp.status}`)
            return { doc, data: null, error: resp.status }
          }
          const data = await resp.json()
          return { doc, data, error: null }
        } catch (err) {
          console.error(`Error loading ${doc.doc_name}:`, err)
          return { doc, data: null, error: err.message }
        }
      })

      const results = await Promise.all(docPromises)

      // Process results and track failures
      const failedDocs = []
      results.forEach(({ doc, data, error }) => {
        if (data) {
          documents[doc.doc_name] = applyOverrides(doc.doc_name, data)
        } else {
          failedDocs.push(doc.doc_name)
        }
      })

      // Warn about failures
      if (failedDocs.length > 0) {
        console.warn(`Failed to load ${failedDocs.length} documents:`, failedDocs)
      }
    }

    state.documentFieldCache = {}

    // Initialize all documents as enabled by default
    state.enabledDocuments = new Set(Object.keys(documents))

    // Initialize AI enhancements after documents are loaded (if function exists)
    if (typeof initializeAIEnhancements === 'function') {
      await initializeAIEnhancements()
    }

    performAnalysis()

    // Apply hidden documents filter (recalculate status)
    // This must be done AFTER performAnalysis so analysisData is populated
    if (state.hiddenDocsPerField && typeof recalculateValidationStatus === 'function') {
      console.log('Applying hidden document filters...')
      Object.keys(state.hiddenDocsPerField).forEach(fieldPath => {
        recalculateValidationStatus(fieldPath)
      })
    }

    render()
  } catch (err) {
    console.error("Failed to load data:", err)
    document.getElementById("validation-list").innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">${icons.alertTriangle}</div>
        <div class="empty-title">Failed to Load Data</div>
        <div class="empty-desc">Make sure registry.json and data files are in the correct location.</div>
      </div>
    `
  }
}

// ============ ANALYSIS ============
function extractFieldValue(data, path) {
  const parts = path.split(".")
  let current = data
  for (const part of parts) {
    if (current && typeof current === "object") {
      current = current[part]
    } else {
      return [null, {}]
    }
  }
  if (current && typeof current === "object" && "value" in current) {
    return [current.value, current]
  }
  return [current, {}]
}

function discoverPaths(obj, prefix = "", paths = new Set()) {
  if (!obj || typeof obj !== "object") return paths

  for (const [key, val] of Object.entries(obj)) {
    const currentPath = prefix ? `${prefix}.${key}` : key
    if (currentPath.startsWith("metadata")) continue

    // Include all fields with value property, even if empty
    if (val && typeof val === "object" && "value" in val) {
      paths.add(currentPath)
    } else if (val && typeof val === "object" && !Array.isArray(val)) {
      // Note: This intentionally does not recurse into arrays like line_items
      discoverPaths(val, currentPath, paths)
    }
  }
  return paths
}

// Get session name for grouping validations
function getSessionName(fieldPath) {
  if (!fieldPath) return 'Other'

  const parts = fieldPath.split('.')

  if (parts[0] === 'entities' && parts.length >= 2) {
    // For entities, use the 1st child level (e.g., "shipper", "consignee")
    return formatFieldName(parts[1])
  } else if (parts.length >= 1) {
    // For others, use the parent level (e.g., "basic_info")
    return formatFieldName(parts[0])
  }

  return 'Other'
}

// Group validations by session
function groupValidationsBySession(validations) {
  const groups = new Map()

  for (const validation of validations) {
    const sessionName = getSessionName(validation.field_path)

    if (!groups.has(sessionName)) {
      groups.set(sessionName, [])
    }
    groups.get(sessionName).push(validation)
  }

  // Sort groups alphabetically
  return new Map([...groups.entries()].sort())
}

function analyzeLineItems() {
  const lineItemsByDesc = new Map();
  const fieldsToCompare = [
    'line_no',
    'brand',
    'hs_code',
    'country_of_origin',
    'quantity',
    'unit',
    'unit_price',
    'line_total',
    'net_weight_kg'
  ];
  const fieldLabels = {
    'line_no': 'Line no',
    'brand': 'Brand',
    'hs_code': 'HS code',
    'country_of_origin': 'Country of origin',
    'quantity': 'Quantity',
    'unit': 'Unit',
    'unit_price': 'Unit price',
    'line_total': 'Line total',
    'net_weight_kg': 'Net weight (kg)'
  };

  // 1. Gather and group items by normalized description
  // Only iterate over enabled documents
  const enabledDocs = Array.from(state.enabledDocuments);

  for (const docName of enabledDocs) {
    const docData = documents[docName];
    if (!docData) continue;

    const lineItemsData = docData?.cargo_summary?.line_items;
    const rawItems = lineItemsData?.items;
    if (!rawItems) continue;

    let items = [];
    if (Array.isArray(rawItems)) {
      items = rawItems.map((item, idx) => ({ item, pathSegment: idx }));
    } else if (typeof rawItems === 'object') {
      items = Object.entries(rawItems).map(([key, item]) => ({ item, pathSegment: key }));
    } else {
      continue;
    }

    const docInfo = {
      docName: docName,
      docType: registry[docName]?.doc_type || "Unknown",
      pageOffset: registry[docName]?.page_start || 0,
    };

    for (const { item, pathSegment } of items) {
      if (!item) continue;

      const desc = item.description_exact?.value?.trim();
      if (!desc) continue;

      const key = desc.toLowerCase().replace(/[.,:;()/\-]/g, " ").replace(/\s+/g, " ").trim();
      if (!lineItemsByDesc.has(key)) {
        lineItemsByDesc.set(key, { originalDesc: desc, items: [] });
      }
      lineItemsByDesc.get(key).items.push({
        ...item,
        ...docInfo,
        itemIndex: pathSegment,
        itemPath: `cargo_summary.line_items.items.${pathSegment}`,
      });
    }
  }

  if (lineItemsByDesc.size === 0) {
    return null;
  }

  // 2. Process grouped items into a table structure
  const tableData = {
    headers: ['Item', ...fieldsToCompare.map(f => fieldLabels[f] || f)],
    rows: []
  };
  let totalInconsistencies = 0;

  for (const [key, group] of lineItemsByDesc.entries()) {
    if (group.items.length < 1) continue;

    const validationPath = `cargo_summary.line_items.item.${key}`;

    const row = {
      description: group.originalDesc,
      fields: {},
      validationPath,
      descriptionValues: group.items.map(item => {
        const descValue = item.description_exact?.value ?? '';
        const descBox = item.description_exact?.bound_box || [];
        const descPage = (item.description_exact?.page ?? 0) + item.pageOffset;
        return {
          docName: item.docName,
          value: descValue,
          boundBox: descBox,
          page: descPage,
          fieldPath: `${item.itemPath}.description_exact`,
          validationPath
        };
      })
    };

    for (const field of fieldsToCompare) {
      const values = group.items.map(item => ({
        docName: item.docName,
        value: item[field]?.value,
        boundBox: item[field]?.bound_box || item.bound_box || [],
        page: (item[field]?.page ?? item.page ?? 0) + item.pageOffset,
        fieldPath: `${item.itemPath}.${field}`,
        validationPath
      }));

      const comparableValues = values.filter(v => v.value !== null && v.value !== undefined && v.value !== "");
      const uniqueValues = new Map();
      comparableValues.forEach(v => {
        const normalized = String(v.value).trim().toUpperCase();
        if (!uniqueValues.has(normalized)) {
          uniqueValues.set(normalized, 0);
        }
        uniqueValues.set(normalized, uniqueValues.get(normalized) + 1);
      });

      const nonEmptyCount = comparableValues.length;
      let isConsistent = true;

      if (nonEmptyCount === 0) {
        // No values - consistent (no data to compare)
        isConsistent = true;
      } else if (nonEmptyCount === 1) {
        // Only one value - consistent (no conflict possible)
        isConsistent = true;
      } else if (uniqueValues.size > 1) {
        // Multiple different values - inconsistent
        isConsistent = false;
      } else {
        // Multiple same values - consistent
        isConsistent = true;
      }

      if (!isConsistent) {
        totalInconsistencies++;
      }

      row.fields[fieldLabels[field]] = {
        isConsistent: isConsistent,
        values: values
      };
    }
    tableData.rows.push(row);
  }

  // 3. Create evidence array from line_items bounding boxes (only for files with items)
  const evidence = [];
  for (const docName of enabledDocs) {
    const docData = documents[docName];
    if (!docData) continue;

    const lineItemsData = docData?.cargo_summary?.line_items;
    // Only add to evidence if the file has items
    if (lineItemsData && lineItemsData.bound_box && lineItemsData.items) {
      // Normalize items to array to check length
      let items = lineItemsData.items;
      if (!Array.isArray(items)) {
        items = [items];
      }

      if (items.length > 0) {
        const pageOffset = registry[docName]?.page_start || 0;

        // Convert bounding box from [x1, y1, x2, y2] to [{x, y}, {x, y}, {x, y}, {x, y}] format
        let bbox = lineItemsData.bound_box;
        if (bbox && bbox.length === 4 && typeof bbox[0] === 'number') {
          bbox = [
            { x: bbox[0], y: bbox[1] },
            { x: bbox[2], y: bbox[1] },
            { x: bbox[2], y: bbox[3] },
            { x: bbox[0], y: bbox[3] }
          ];
        }

        evidence.push({
          doc_name: docName,
          doc_type: registry[docName]?.doc_type || 'Unknown',
          value_found: `${items.length} items`,
          source_page_index: (lineItemsData.page || 0) + pageOffset,
          bounding_box: bbox
        });
      }
    }
  }

  // 4. Create summary card
  // NOTE: We'll update this after itemValidations are created

  // 5. Create individual validations for each line item
  const itemValidations = [];
  for (const [key, group] of lineItemsByDesc.entries()) {
    if (group.items.length < 1) continue;

    const validationPath = `cargo_summary.line_items.item.${key}`;
    const inconsistentFields = new Set();
    const insufficientFields = new Set();

    for (const field of fieldsToCompare) {
      const values = group.items.map(item => {
        const val = item[field]?.value;
        if (val === null || val === undefined || val === "") return null;
        return String(val).trim().toUpperCase();
      }).filter(v => v !== null);

      if (values.length === 0) {
        continue;
      }

      if (values.length === 1) {
        insufficientFields.add(field);
        continue;
      }

      const uniqueValues = new Set(values);
      if (uniqueValues.size > 1) {
        inconsistentFields.add(field);
      }
    }

    let status = 'PASS';
    let analysis = 'All fields are consistent across documents.';

    if (inconsistentFields.size > 0) {
      status = 'FAIL';
      analysis = `${inconsistentFields.size} field(s) have inconsistent values across documents.`;
    } else if (insufficientFields.size > 0) {
      status = 'FAIL';
      analysis = `${insufficientFields.size} field(s) do not have enough values to compare.`;
    }

    // Create evidence array for this specific item from all documents
    const itemEvidence = [];
    for (const item of group.items) {
      // Collect ALL field bounding boxes for this item
      const fieldBoxes = [];
      const fieldValues = {};

      for (const field of fieldsToCompare) {
        const fieldData = item[field];
        if (fieldData && fieldData.bound_box) {
          let bbox = fieldData.bound_box;
          // Convert [x1, y1, x2, y2] to [{x,y}, ...] format
          if (bbox.length === 4 && typeof bbox[0] === 'number') {
            bbox = [
              { x: bbox[0], y: bbox[1] },
              { x: bbox[2], y: bbox[1] },
              { x: bbox[2], y: bbox[3] },
              { x: bbox[0], y: bbox[3] }
            ];
          }

          // Only add if bbox is valid (not all zeros)
          const isValidBox = bbox.some(p => p.x !== 0 || p.y !== 0);
          const isFieldInconsistent = inconsistentFields.has(field) || insufficientFields.has(field);

          if (isValidBox) {
            fieldBoxes.push({
              field: field,
              label: fieldLabels[field] || field,
              value: fieldData.value,
              bounding_box: bbox,
              page: (fieldData.page ?? 0) + item.pageOffset,
              isInconsistent: isFieldInconsistent
            });
          }

          fieldValues[field] = {
            value: fieldData.value,
            isInconsistent: isFieldInconsistent,
            docName: item.docName,
            fieldPath: `${item.itemPath}.${field}`,
            validationPath
          };
        }
      }

      // Include description field for editing support
      fieldValues.description_exact = {
        value: item.description_exact?.value,
        isInconsistent: false,
        docName: item.docName,
        fieldPath: `${item.itemPath}.description_exact`,
        validationPath
      };

      // Also add description_exact bounding box to fieldBoxes
      let descBbox = item.description_exact?.bound_box;
      if (descBbox && descBbox.length === 4 && typeof descBbox[0] === 'number') {
        descBbox = [
          { x: descBbox[0], y: descBbox[1] },
          { x: descBbox[2], y: descBbox[1] },
          { x: descBbox[2], y: descBbox[3] },
          { x: descBbox[0], y: descBbox[3] }
        ];
      }

      // Add description to fieldBoxes (always first, as it's the main identifier)
      if (descBbox && descBbox.some(p => p.x !== 0 || p.y !== 0)) {
        fieldBoxes.unshift({
          field: 'description_exact',
          label: 'Item',
          value: item.description_exact?.value,
          bounding_box: descBbox,
          page: (item.description_exact?.page ?? 0) + item.pageOffset,
          isInconsistent: false  // Description is used for matching, so not compared
        });
      }

      // Calculate combined bounding box covering all fields
      let allBoxes = [...fieldBoxes.map(f => f.bounding_box)].filter(b => b && b.length >= 4);
      let combinedBox = descBbox || [];
      if (allBoxes.length > 0) {
        const allPoints = allBoxes.flat();
        const minX = Math.min(...allPoints.map(p => p.x));
        const maxX = Math.max(...allPoints.map(p => p.x));
        const minY = Math.min(...allPoints.map(p => p.y));
        const maxY = Math.max(...allPoints.map(p => p.y));
        combinedBox = [
          { x: minX, y: minY },
          { x: maxX, y: minY },
          { x: maxX, y: maxY },
          { x: minX, y: maxY }
        ];
      }

      itemEvidence.push({
        doc_name: item.docName,
        doc_type: item.docType,
        value_found: group.originalDesc,
        source_page_index: (item.description_exact?.page || 0) + item.pageOffset,
        bounding_box: combinedBox,
        // NEW: Full field data for detailed display
        fieldBoxes: fieldBoxes,
        fieldValues: fieldValues,
        descriptionBox: descBbox
      });
    }

    itemValidations.push({
      check_name: group.originalDesc,
      field_path: validationPath,
      status: status,
      analysis: analysis,
      doc_count: group.items.length,
      evidence: itemEvidence,
      isLineItem: true,
      inconsistentFields: Array.from(new Set([...inconsistentFields, ...insufficientFields]))
    });
  }

  // 6. Create summary card AFTER itemValidations - status based on number of failed items
  const failedItemsCount = itemValidations.filter(v => v.status === 'FAIL').length;
  const totalItemsCount = itemValidations.length;

  const summaryCard = {
    check_name: 'Line Items',
    field_path: 'cargo_summary.line_items',
    status: failedItemsCount > 0 ? 'FAIL' : 'PASS',
    analysis: failedItemsCount > 0
      ? `Found ${failedItemsCount} of ${totalItemsCount} line item(s) with inconsistencies.`
      : 'All line item fields are consistent across all documents.',
    doc_count: enabledDocs.length,
    evidence: evidence
  };

  return { summaryCard, tableData, itemValidations };
}


function performAnalysis() {
  const validations = []
  const allPaths = new Set()

  // Only process enabled documents
  const enabledDocs = Object.fromEntries(
    Object.entries(documents).filter(([docName]) => state.enabledDocuments.has(docName))
  )

  Object.values(enabledDocs).forEach((doc) => {
    discoverPaths(doc, "", allPaths)
  })

  for (const path of allPaths) {
    const values = []

    for (const [docName, docData] of Object.entries(enabledDocs)) {
      const [value, metadata] = extractFieldValue(docData, path)

      if (value !== null && value !== "" && value !== undefined) {
        const pageOffset = registry[docName]?.page_start || 0
        const docPage = metadata.page || 0

        values.push({
          value: value,
          docName: docName,
          docType: registry[docName]?.doc_type || "Unknown",
          page: pageOffset + docPage,
          boundBox: metadata.bound_box || [],
        })
      }
    }

    if (values.length < 2) continue

    const uniqueValues = new Map()
    values.forEach((item) => {
      const normalized = String(item.value).trim().toUpperCase()
      if (!uniqueValues.has(normalized)) {
        uniqueValues.set(normalized, [])
      }
      uniqueValues.get(normalized).push(item)
    })

    const fieldLabel = path.split(".").pop()

    const evidence = values.map((item) => {
      let boundingBox = item.boundBox
      if (boundingBox && boundingBox.length === 4 && typeof boundingBox[0] === 'number') {
        boundingBox = [
          { x: boundingBox[0], y: boundingBox[1] },
          { x: boundingBox[2], y: boundingBox[1] },
          { x: boundingBox[2], y: boundingBox[3] },
          { x: boundingBox[0], y: boundingBox[3] }
        ]
      }
      return {
        doc_type: item.docType,
        doc_name: item.docName,
        source_page_index: item.page,
        value_found: String(item.value),
        bounding_box: boundingBox || [],
      }
    })

    if (uniqueValues.size > 1) {
      validations.push({
        check_name: fieldLabel,
        field_path: path,
        status: "FAIL",
        analysis: `Found ${uniqueValues.size} different values across ${values.length} documents`,
        evidence: evidence,
        doc_count: values.length,
      })
    } else {
      validations.push({
        check_name: fieldLabel,
        field_path: path,
        status: "PASS",
        analysis: `All ${values.length} documents match`,
        evidence: evidence,
        matching_value: values[0].value,
        doc_count: values.length,
      })
    }
  }

  // New: Handle Line Item Analysis
  const lineItemAnalysisResult = analyzeLineItems();
  if (lineItemAnalysisResult) {
    lineItemTableData = lineItemAnalysisResult.tableData;
    validations.push(lineItemAnalysisResult.summaryCard);
    // Add individual item validations
    if (lineItemAnalysisResult.itemValidations) {
      validations.push(...lineItemAnalysisResult.itemValidations);
    }
  }

  validations.sort((a, b) => {
    if (a.status === b.status) return a.check_name.localeCompare(b.check_name)
    return a.status === "FAIL" ? -1 : 1
  })

  const failCount = validations.filter((v) => v.status === "FAIL").length

  analysisData = {
    batch_id: getBatchId(),
    overall_status: failCount === 0 ? "CLEAN" : "REVIEW_REQUIRED",
    validations: validations,
    total: validations.length,
    passCount: validations.length - failCount,
    failCount: failCount,
    summary: null  // Filled after computing realtime summary
  }

  validations.forEach((v, i) => {
    if (v.status === "FAIL") {
      state.expandedCards[`${v.status}-${i}`] = false
    }
  })

  buildValidationIndexMap(validations)
  syncActiveGridValidation()
  if (!treeDocumentName && Object.keys(documents).length > 0) {
    treeDocumentName = findDocumentWithMostKeys(documents)
  }

  // Generate realtime summary data
  const realtimeSummary = generateSummaryData()
  analysisData.summary = realtimeSummary
  window.summaryData = realtimeSummary
}

// Helper function to count keys recursively
function countKeys(obj) {
  if (!obj || typeof obj !== 'object') return 0

  let count = 0
  for (const key in obj) {
    count++ // Count this key
    const value = obj[key]
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      // Recursively count nested object keys
      count += countKeys(value)
    } else if (Array.isArray(value)) {
      // For arrays, count keys in each item
      value.forEach(item => {
        if (item && typeof item === 'object') {
          count += countKeys(item)
        }
      })
    }
  }
  return count
}

// Find document with most keys
function findDocumentWithMostKeys(documents) {
  let maxKeys = 0
  let bestDoc = null

  for (const docName in documents) {
    const keyCount = countKeys(documents[docName])
    if (keyCount > maxKeys) {
      maxKeys = keyCount
      bestDoc = docName
    }
  }

  return bestDoc || Object.keys(documents)[0]
}

function buildValidationIndexMap(validations) {
  validationIndexMap.clear()
  validations.forEach((v, index) => {
    validationIndexMap.set(v.field_path, { status: v.status, index })
  })
}

function syncActiveGridValidation() {
  if (!state.gridViewValidation || !analysisData) {
    return
  }

  const currentPath = state.gridViewValidation.field_path
  const currentName = state.gridViewValidation.check_name

  const updatedValidation = analysisData.validations.find(
    (v) => v.field_path === currentPath && v.check_name === currentName,
  )

  if (updatedValidation) {
    state.gridViewValidation = updatedValidation
  } else {
    state.gridViewValidation = null
    state.gridViewOpen = false
  }
}

function getBatchId() {
  return getBatchIdFromUrl()
}
