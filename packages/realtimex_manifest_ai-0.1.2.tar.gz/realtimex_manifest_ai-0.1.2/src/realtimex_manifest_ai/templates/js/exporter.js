const EXPORT_CSS_FILES = [
  'css/base.css',
  'css/layout.css',
  'css/components.css',
  'css/validation.css',
  'css/modal.css',
  'css/tree.css',
  'css/table.css',
  'css/notes.css',
  'css/responsive.css'
]

const EXPORT_SCRIPT_FILES = [
  'js/state.js',
  'js/icons.js',
  'js/utils.js',
  'js/overrides.js',
  'js/masters.js',
  'js/verification.js',
  'js/analysis.js',
  'js/tree.js',
  'js/canvas.js',
  'js/notes.js',
  'js/render.js',
  'js/viewer.js',
  'js/changelog.js',
  'js/events.js'
]

// Function to get export user data files based on batch_id
function getExportUserDataFiles() {
  const batchId = getBatchId()
  const basePath = batchId ? `../batch_data/${batchId}/user_data` : '../user_data'
  return [
    { path: `${basePath}/overrides.json`, name: 'user_data/overrides.json', key: 'overrides' },
    { path: `${basePath}/changelog.json`, name: 'user_data/changelog.json', key: 'changelog' },
    { path: `${basePath}/masters.json`, name: 'user_data/masters.json', key: 'masters' },
    { path: `${basePath}/verifications.json`, name: 'user_data/verifications.json', key: 'verifications' },
    { path: `${basePath}/annotations.json`, name: 'user_data/annotations.json', key: 'annotations' }
  ]
}

const EXPORT_APP_TEMPLATE = `
    <div id="app">
        <header class="header">
            <div class="header-content">
                <div class="header-left" onclick="closeViewer(true)">
                    <h1 class="header-title">Document Validator</h1>
                    <p class="header-subtitle" id="batch-id">Loading...</p>
                </div>
            </div>
        </header>
        <main class="main-content">
            <div class="controls-container">
                <div class="search-container">
                    <svg class="search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.3-4.3"></path>
                    </svg>
                    <input type="text" class="search-input" id="search-input" placeholder="Search...">
                    <select id="filter-status" class="filter-select">
                        <option value="all">All Status</option>
                        <option value="verified">Verified</option>
                        <option value="unverified">Unverified</option>
                    </select>
                </div>
                <div class="tabs">
                    <button class="tab-button active" data-tab="documents">
                        Documents
                        <span class="tab-badge" id="documents-badge">0</span>
                    </button>
                    <button class="tab-button" data-tab="tree">
                        Tree View
                    </button>
                    <button class="tab-button" data-tab="mismatches">
                        Mismatches
                        <span class="tab-badge tab-badge-error" id="mismatch-badge">0</span>
                    </button>
                    <button class="tab-button" data-tab="matches">
                        Matches
                        <span class="tab-badge" id="match-badge">0</span>
                    </button>
                </div>
            </div>
            <div class="validation-list" id="validation-list">
                <div class="empty-state">
                    <div class="empty-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                        </svg>
                    </div>
                    <div class="empty-title">Loading documents...</div>
                    <div class="empty-desc">Please wait while we analyze your documents.</div>
                </div>
            </div>
        </main>
    </div>
    <div id="modal-container"></div>
`

let exportInProgress = false

async function exportReport() {
  if (state?.readOnlyMode) {
    if (typeof showAlertDialog === 'function') {
      await showAlertDialog('Export is unavailable in read-only mode.', {
        title: 'Export Disabled',
        type: 'warning'
      })
    }
    return
  }

  if (exportInProgress) return
  exportInProgress = true

  if (!analysisData || Object.keys(documents).length === 0) {
    if (typeof showAlertDialog === 'function') {
      await showAlertDialog('Please wait for the analysis to finish before exporting.', {
        title: 'Export Unavailable',
        type: 'warning'
      })
    }
    exportInProgress = false
    return
  }

  try {
    if (typeof showToast === 'function') {
      showToast('Preparing report...', { type: 'info' })
    }

    const [cssBundle, scriptContents, userDataSnapshots] = await Promise.all([
      combineTextAssets(EXPORT_CSS_FILES),
      loadScriptContents(EXPORT_SCRIPT_FILES),
      loadUserDataSnapshots()
    ])

    const registrySnapshot = { registry: Object.values(registry).sort((a, b) => (a.page_start || 0) - (b.page_start || 0)) }
    const documentsSnapshot = JSON.parse(JSON.stringify(documents))
    const summarySnapshot = window.summaryData || null

    // Collect images as base64
    const imagesBase64 = await collectPageImagesAsBase64()

    const embeddedScript = `
      window.__DOCUMENT_EXPORT_MODE = true;
      window.__embeddedRegistry = ${JSON.stringify(registrySnapshot)};
      window.__embeddedDocuments = ${JSON.stringify(documentsSnapshot)};
      window.__embeddedSummary = ${JSON.stringify(summarySnapshot)};
      window.__embeddedUserData = ${JSON.stringify(userDataSnapshots)};
      window.__embeddedImages = ${JSON.stringify(imagesBase64)};
      window.imageBasePath = 'data:';
      // Set read-only mode to prevent editing notes
      window.__EXPORT_READ_ONLY_MODE = true;
    `

    const htmlContent = minifyHtml(buildExportHtml(cssBundle, embeddedScript, scriptContents))

    // Download as single HTML file
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' })
    const link = document.createElement('a')
    const batchId = state.batchId || 'document'
    link.href = URL.createObjectURL(blob)
    link.download = `${batchId}_report.html`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(link.href)

    if (typeof showToast === 'function') {
      showToast('Report exported successfully.', { type: 'success' })
    }
  } catch (err) {
    console.error('Failed to export report', err)
    if (typeof showAlertDialog === 'function') {
      await showAlertDialog('Failed to export report. Check console for details.', {
        title: 'Export Failed',
        type: 'danger'
      })
    }
  } finally {
    exportInProgress = false
  }
}

async function combineTextAssets(files) {
  const parts = await Promise.all(files.map(async (path) => {
    const res = await fetch(path)
    if (!res.ok) throw new Error(`Failed to load ${path}`)
    return res.text()
  }))
  return parts.join('\n\n')
}

async function loadScriptContents(files) {
  const contents = []
  for (const path of files) {
    const res = await fetch(path)
    if (!res.ok) throw new Error(`Failed to load ${path}`)
    const text = await res.text()
    contents.push({
      name: path,
      content: sanitizeScriptContent(text)
    })
  }
  return contents
}

// Collect page images as base64 data URIs
async function collectPageImagesAsBase64() {
  if (!Number.isFinite(totalPages) || totalPages <= 0) return {}
  const images = {}
  // Get batch base path from state
  const basePath = state.batchBasePath || '..'

  for (let i = 0; i < totalPages; i++) {
    try {
      const res = await fetch(`${basePath}/images/page_${i}.png`)
      if (!res.ok) continue
      const buffer = await res.arrayBuffer()
      const base64 = arrayBufferToBase64(buffer)
      images[`page_${i}.png`] = `data:image/png;base64,${base64}`
    } catch (err) {
      console.warn('Failed to fetch image for export', i, err)
    }
  }
  return images
}

// Convert ArrayBuffer to base64 string
function arrayBufferToBase64(buffer) {
  let binary = ''
  const bytes = new Uint8Array(buffer)
  const len = bytes.byteLength
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i])
  }
  return btoa(binary)
}

async function loadUserDataSnapshots() {
  const snapshots = {}
  for (const file of getExportUserDataFiles()) {
    try {
      const res = await fetch(file.path)
      if (!res.ok || !file.key) continue
      const text = await res.text()
      try {
        snapshots[file.key] = JSON.parse(text || '{}')
      } catch (parseErr) {
        console.warn('Failed to parse user data snapshot', file.name, parseErr)
      }
    } catch (err) {
      console.warn('Failed to load user data snapshot', file.name, err)
    }
  }
  return snapshots
}

function buildExportHtml(cssText, embeddedScript, scriptContents) {
  // Minify CSS
  const minifiedCss = minifyCssContent(cssText)

  // Minify embedded script and all script contents
  const minifiedEmbeddedScript = minifyJsContent(embeddedScript)
  const scripts = [
    `<script>${sanitizeScriptContent(minifiedEmbeddedScript)}</script>`,
    ...scriptContents.map(script => `<script>${minifyJsContent(script.content)}</script>`)
  ].join('\n')

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document Validator Report</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>${minifiedCss}</style>
</head>
<body>
${EXPORT_APP_TEMPLATE}
${scripts}
</body>
</html>`
}

function sanitizeScriptContent(content) {
  return content.replace(/<\/script>/gi, '<\\/script>')
}

function minifyHtml(html) {
  const placeholders = []
  const placeholder = (type, content) => {
    const key = `__HTML_EXPORT__${type}_${placeholders.length}_${Math.random().toString(36).slice(2)}__`
    placeholders.push({ key, content })
    return key
  }

  let processed = html

  const preserveTags = ['pre', 'code', 'textarea']
  preserveTags.forEach(tag => {
    const regex = new RegExp(`<${tag}\\b[^>]*>[\\s\\S]*?<\\/${tag}>`, 'gi')
    processed = processed.replace(regex, match => placeholder(tag.toUpperCase(), match))
  })

  processed = processed.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, (match) => {
    return placeholder('SCRIPT', match)
  })

  processed = processed.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, (match) => {
    return placeholder('STYLE', match)
  })

  processed = processed
    .replace(/<!--(?!\s*\[if\b)[\s\S]*?-->/gi, '')
    .replace(/\r?\n+/g, ' ')
    .replace(/\t+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .replace(/>\s+</g, '><')
    .trim()

  placeholders.forEach(({ key, content }) => {
    processed = processed.split(key).join(content)
  })

  return processed
}

// Minify CSS content
function minifyCssContent(css) {
  if (!css) return css

  return css
    // Remove CSS comments
    .replace(/\/\*[\s\S]*?\*\//g, '')
    // Remove newlines and tabs
    .replace(/[\r\n\t]+/g, '')
    // Remove spaces around special characters
    .replace(/\s*([{};:,>+~])\s*/g, '$1')
    // Remove spaces before opening brace
    .replace(/\s+\{/g, '{')
    // Remove trailing semicolons before closing brace
    .replace(/;}/g, '}')
    // Remove multiple spaces
    .replace(/\s{2,}/g, ' ')
    // Remove leading/trailing whitespace
    .trim()
}

// Minify JavaScript content (safe minification - only removes comments and excess whitespace)
function minifyJsContent(code) {
  return code
}
