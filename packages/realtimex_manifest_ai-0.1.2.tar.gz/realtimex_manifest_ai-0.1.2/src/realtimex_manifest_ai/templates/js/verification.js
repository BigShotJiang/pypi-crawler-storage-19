// ============ VERIFICATION SYSTEM ============

// Store for verification tracking
const verificationData = {
  verifications: {} // Structure: { "validation_field_path": { verified: true/false, timestamp, user } }
}

function isReadOnlyVerification() {
  return typeof state !== 'undefined' && state.readOnlyMode
}

// Load verifications from server
async function loadVerifications() {
  if (isReadOnlyVerification()) {
    const embedded = window.__embeddedUserData?.verifications || {}
    verificationData.verifications = embedded.verifications || {}
    return
  }
  try {
    const batchId = getBatchId()
    const response = await fetch(`/api/verifications?batch_id=${batchId}`)
    if (response.ok) {
      const data = await response.json()
      verificationData.verifications = data.verifications || {}
      console.log('Loaded verifications from server:', Object.keys(verificationData.verifications).length, 'fields')
    } else {
      console.warn('No verifications file found, starting fresh')
      verificationData.verifications = {}
    }
  } catch (err) {
    console.error('Failed to load verifications from server:', err)
    verificationData.verifications = {}
  }
}

// Save verifications to server
async function saveVerifications() {
  if (isReadOnlyVerification()) {
    return
  }
  try {
    const batchId = getBatchId()
    const response = await fetch(`/api/verifications?batch_id=${batchId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(verificationData)
    })

    if (response.ok) {
      const result = await response.json()
      console.log('Saved verifications to server:', result.message)
    } else {
      const error = await response.json()
      console.error('Failed to save verifications:', error.error)
    }

    // Update UI if verification viewer exists
    if (typeof updateVerificationUI === 'function') {
      updateVerificationUI()
    }
  } catch (err) {
    console.error('Failed to save verifications to server:', err)
    await showAlertDialog('Failed to save verifications to server. Make sure the server is running.', {
      title: 'Save Failed',
      type: 'danger'
    })
  }
}

// Check if a field is verified
function isFieldVerified(fieldPath) {
  return verificationData.verifications[fieldPath]?.verified === true
}

// Get verification info for a field
function getVerificationInfo(fieldPath) {
  return verificationData.verifications[fieldPath] || null
}

// Get all verifications data
function getVerifications() {
  return verificationData
}

// Toggle verification for current grid view validation
function toggleCurrentVerification() {
  const validation = state.gridViewValidation
  if (!validation) return

  const fieldPath = validation.field_path
  const currentlyVerified = isFieldVerified(fieldPath)

  setVerification(fieldPath, !currentlyVerified)
}

// Set verification status for a field
function setVerification(fieldPath, verified) {
  if (verified) {
    verificationData.verifications[fieldPath] = {
      verified: true,
      timestamp: new Date().toISOString(),
      user: 'User'
    }
  } else {
    delete verificationData.verifications[fieldPath]
  }

  saveVerifications()

  // Update summary data
  if (typeof generateSummaryData === 'function') {
    window.summaryData = generateSummaryData()
  }

  // Update modal if it's open
  if (typeof renderModal === 'function') {
    renderModal()
  }

  // Update list and tree view
  if (typeof renderValidationList === 'function') renderValidationList()
  if (typeof updateTreeBadges === 'function') updateTreeBadges()
}

// Get verification statistics
function getVerificationStats() {
  const total = analysisData ? analysisData.validations.length : 0
  const verified = Object.keys(verificationData.verifications).filter(
    key => verificationData.verifications[key].verified
  ).length

  return { verified, total, percentage: total > 0 ? Math.round((verified / total) * 100) : 0 }
}

// Initialize verification system
async function initializeVerifications() {
  await loadVerifications()
}
