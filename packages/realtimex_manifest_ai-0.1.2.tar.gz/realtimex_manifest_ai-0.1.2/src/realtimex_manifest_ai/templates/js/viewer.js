function openDocumentFromList(docName, pageIndex) {
  state.pendingDocumentViewerDocName = docName;
  state.documentFieldHighlight = null;
  state.documentFieldScrollTop = 0;
  state.expandedLineItems = {};
  openViewer(pageIndex, [], docName);
}

function openViewer(pageIndex, boundingBox, fieldName) {
  console.log('openViewer called:', { pageIndex, fieldName, pendingDoc: state.pendingDocumentViewerDocName, currentDoc: state.documentViewerDocName })

  // Record where we came from
  if (state.lineItemViewOpen) {
    state.previousView = 'line-item-table';
  } else if (state.gridViewOpen) {
    state.previousView = 'grid';
  } else {
    state.previousView = null;
  }

  // Parse boundingBox if it's a string
  let box = boundingBox;
  if (typeof boundingBox === "string") {
    try {
      box = JSON.parse(boundingBox.replace(/&quot;/g, '"'));
    } catch (e) {
      box = [];
    }
  }

  // Convert [x1, y1, x2, y2] to [{x,y}, {x,y}, {x,y}, {x,y}] for drawing
  if (box && box.length === 4 && typeof box[0] === 'number') {
    box = [
      { x: box[0], y: box[1] }, { x: box[2], y: box[1] },
      { x: box[2], y: box[3] }, { x: box[0], y: box[3] }
    ];
  }

  state.viewerOpen = true;
  state.gridViewOpen = false;
  state.lineItemViewOpen = false;
  state.selectedEvidence = { pageIndex, boundingBox: box, fieldName };
  state.currentPage = pageIndex;
  state.zoom = 0.75;
  state.panX = 0;
  state.panY = 0;

  // Handle document navigation - always use pending if set
  const oldDocName = state.documentViewerDocName;
  let documentChanged = false;

  if (state.pendingDocumentViewerDocName) {
    documentChanged = oldDocName !== state.pendingDocumentViewerDocName;
    state.documentViewerSource = 'document-list';
    state.documentViewerDocName = state.pendingDocumentViewerDocName;
    state.pendingDocumentViewerDocName = null;
    state.documentFieldScrollTop = 0;
    console.log('Updated documentViewerDocName to:', state.documentViewerDocName, 'changed:', documentChanged)
  } else if (!state.documentViewerDocName) {
    // Only clear if no pending and no current
    state.documentViewerSource = null;
  }
  state.documentFieldHighlight = null;

  // Force clear canvas container when document changes to ensure proper re-render
  if (documentChanged) {
    const viewerCanvasContainer = document.querySelector('.document-viewer-canvas');
    if (viewerCanvasContainer) {
      viewerCanvasContainer.innerHTML = '';
      console.log('Cleared canvas container because document changed from', oldDocName, 'to', state.documentViewerDocName);
    }
  }

  console.log('Final state after openViewer:', { docName: state.documentViewerDocName, pageIndex: state.currentPage })

  renderModal();
  renderValidationList(); // Update list to show active state respecting tabs

  // Refresh notes panel to update button state
  if (typeof updateNotesPanel === 'function') {
    updateNotesPanel();
  }
}

function openLineItemTable() {
  // Find the line items validation index
  const lineItemIndex = analysisData.validations.findIndex(v =>
    v.check_name === 'Line Items' || v.field_path === 'cargo_summary.line_items'
  );

  if (lineItemIndex !== -1) {
    // Open in grid view with images and bounding boxes
    openGridView(lineItemIndex);
  }
}

function openLineItemTableDirect() {
  // Find the line items validation index
  const lineItemIndex = analysisData.validations.findIndex(v =>
    v.check_name === 'Line Items' || v.field_path === 'cargo_summary.line_items'
  );

  if (lineItemIndex !== -1) {
    const validation = analysisData.validations[lineItemIndex];

    state.viewerOpen = true;
    state.gridViewOpen = true;
    state.lineItemViewOpen = true;
    state.lineItemTableMode = true; // Open in table mode directly
    state.gridViewValidation = validation;

    renderModal();
    renderValidationList();
  }
}

function openGridView(validationIndex) {
  if (!analysisData || !analysisData.validations[validationIndex]) return;

  const validation = analysisData.validations[validationIndex];

  // Line items now open in grid view by default
  const isLineItems = validation.check_name === 'Line Items' || validation.field_path === 'cargo_summary.line_items';

  state.viewerOpen = true;
  state.gridViewOpen = true;
  state.lineItemViewOpen = isLineItems;
  state.lineItemTableMode = false; // Default to grid view
  state.gridViewValidation = validation;

  renderModal();
  renderValidationList(); // Update list to show active state
}

function openViewerFromGrid(pageIndex, boundingBox, fieldName, fieldBoxes, cardStatus) {
  state.documentViewerSource = null;
  state.documentViewerDocName = null;
  state.pendingDocumentViewerDocName = null;
  state.documentFieldHighlight = null;
  state.previousView = 'grid'; // We know we came from the grid

  let box = boundingBox;
  if (typeof boundingBox === "string") {
    try {
      box = JSON.parse(boundingBox.replace(/&quot;/g, '"'));
    } catch (e) {
      box = [];
    }
  }

  // Parse fieldBoxes if string
  let parsedFieldBoxes = fieldBoxes;
  if (typeof fieldBoxes === "string") {
    try {
      parsedFieldBoxes = JSON.parse(fieldBoxes.replace(/&quot;/g, '"'));
    } catch (e) {
      parsedFieldBoxes = null;
    }
  }

  // Convert for drawing, same as in openViewer
  if (box && box.length === 4 && typeof box[0] === 'number') {
    box = [
      { x: box[0], y: box[1] }, { x: box[2], y: box[1] },
      { x: box[2], y: box[3] }, { x: box[0], y: box[3] }
    ];
  }

  state.gridViewOpen = false;
  state.lineItemViewOpen = false;
  state.selectedEvidence = {
    pageIndex,
    boundingBox: box,
    fieldName,
    fieldBoxes: parsedFieldBoxes,  // Store field boxes for multi-box drawing
    cardStatus // Store status for highlight color
  };
  state.currentPage = pageIndex;
  state.zoom = 0.75;
  state.panX = 0;
  state.panY = 0;
  renderModal();
  renderValidationList();
}

function closeViewer(returnToSummary = false) {
  state.viewerOpen = false;
  state.gridViewOpen = false;
  state.lineItemViewOpen = false;
  state.selectedEvidence = null;
  state.gridViewValidation = null;
  state.previousView = null;
  state.tableFullscreen = false;
  state.documentViewerSource = null;
  state.documentViewerDocName = null;
  state.pendingDocumentViewerDocName = null;
  state.documentFieldHighlight = null;
  state.expandedLineItems = {};
  state.documentFieldScrollTop = 0;
  document.body.classList.remove('table-fullscreen-active');

  // Clear any active annotation when closing viewer
  if (typeof clearActiveAnnotation === 'function') {
    clearActiveAnnotation();
  }

  if (returnToSummary && window.innerWidth < 1024) {
    state.mobileSummaryActive = true;
  }
  renderModal();
  renderValidationList();

  // Refresh notes panel to update button state
  if (typeof updateNotesPanel === 'function') {
    updateNotesPanel();
  }
}

function toggleLineItemTableMode() {
  state.lineItemTableMode = !state.lineItemTableMode;
  renderModal();
}

function backToGrid() {
  if (state.previousView === 'line-item-table') {
    state.lineItemViewOpen = true;
    state.gridViewOpen = false;
  } else { // Default to grid view
    state.lineItemViewOpen = false;
    state.gridViewOpen = state.previousView === 'grid';
  }
  state.selectedEvidence = null;
  state.documentFieldHighlight = null;
  state.previousView = null;
  renderModal();
}

function toggleFullscreenTable() {
  state.tableFullscreen = !state.tableFullscreen;
  document.body.classList.toggle('table-fullscreen-active');
  render();
}

function zoomIn() {
  state.zoom = Math.min(state.zoom + 0.25, 3)
  renderModal()
}

function zoomOut() {
  state.zoom = Math.max(state.zoom - 0.25, 0.25)
  renderModal()
}

function resetZoom() {
  state.zoom = 0.75
  state.panX = 0
  state.panY = 0
  renderModal()
}

function highlightDocumentField(docName, fieldIndex) {
  const fields = state.documentFieldCache[docName];
  if (!fields || !fields[fieldIndex]) {
    return;
  }
  const entry = fields[fieldIndex];
  if (!entry || !entry.boundingBox) return;

  state.documentFieldHighlight = {
    pageIndex: entry.pageIndex,
    boundingBox: entry.boundingBox,
    fieldName: entry.label,
    cardStatus: 'PASS'
  };
  if (typeof drawAllPages === 'function') {
    drawAllPages();
  }
}

function clearDocumentFieldHighlight() {
  if (!state.documentFieldHighlight) return;
  state.documentFieldHighlight = null;
  if (typeof drawAllPages === 'function') {
    drawAllPages();
  }
}

function toggleDocumentLineItem(docName, itemKey) {
  if (!state.expandedLineItems) {
    state.expandedLineItems = {};
  }
  const currentKey = state.expandedLineItems[docName];
  if (currentKey === itemKey) {
    delete state.expandedLineItems[docName];
  } else {
    state.expandedLineItems[docName] = itemKey;
  }
  renderModal();
}

function highlightLineItemGroup(docName, itemKey) {
  let allFields = state.documentFieldCache[docName];
  if ((!allFields || allFields.length === 0) && typeof getDocumentFieldsForDoc === 'function') {
    allFields = getDocumentFieldsForDoc(docName);
  }
  if (!allFields) return;

  const matchingFields = allFields.filter(field => field.lineItemKey === itemKey && field.boundingBox);
  if (matchingFields.length === 0) return;

  const multiPageFieldBoxes = {};
  let firstPage = null;

  matchingFields.forEach(field => {
    const page = typeof field.pageIndex === 'number' ? field.pageIndex : 0;
    if (firstPage === null || page < firstPage) {
      firstPage = page;
    }
    if (!multiPageFieldBoxes[page]) {
      multiPageFieldBoxes[page] = [];
    }
    multiPageFieldBoxes[page].push({
      field: field.path,
      label: field.label,
      bounding_box: field.boundingBox,
      isInconsistent: false,
      groupHighlight: true
    });
  });

  state.documentFieldHighlight = {
    pageIndex: firstPage ?? 0,
    multiPageFieldBoxes,
    cardStatus: 'PASS'
  };
  if (typeof drawAllPages === 'function') {
    drawAllPages();
  }
}

function toggleDocumentFieldPanel() {
  state.documentFieldPanelCollapsed = !state.documentFieldPanelCollapsed
  renderModal()
}

// ============ MASTER EVIDENCE HANDLERS ============
function setMasterEvidence(evidenceIndex) {
  // Get current validation from grid view
  const validation = state.gridViewValidation
  if (!validation || !validation.field_path || !validation.evidence) {
    console.error('Cannot set master: no validation in grid view')
    return
  }

  // Get the evidence at the specified index
  const evidence = validation.evidence[evidenceIndex]
  if (!evidence) {
    console.error('Cannot set master: invalid evidence index')
    return
  }

  // Set master using field path + doc name
  setFieldMaster(
    validation.field_path,
    evidence.doc_name,
    evidence.value_found
  )

  renderModal()
}
