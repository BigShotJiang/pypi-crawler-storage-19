// ============ AI ENHANCEMENT SYSTEM ============

const aiEnhancements = {
    data: {}  // Structure: { "doc_name": { enhanced_data } }
}

// Load AI-enhanced data for a document
async function loadAIEnhancedData(docName) {
    if (state.readOnlyMode) return null

    try {
        // Get batch base path from state (set by loadData)
        const basePath = state.batchBasePath || '..'
        const cacheBuster = `?t=${Date.now()}`

        // Load from batch folder's enhanced_data directory
        const response = await fetch(`${basePath}/enhanced_data/${docName}.json${cacheBuster}`)
        if (response.ok) {
            const data = await response.json()
            aiEnhancements.data[docName] = data
            return data
        }
    } catch (err) {
        // Silently fail - AI enhancement is optional
    }
    return null
}

// Get AI suggestion for a field
function getAISuggestion(docName, fieldPath) {
    if (!aiEnhancements.data[docName]) return null

    const parts = fieldPath.split('.')
    let current = aiEnhancements.data[docName]

    for (const part of parts) {
        if (!current) return null

        // Handle array index (e.g., "0" in "items.0.brand")
        if (/^\d+$/.test(part) && Array.isArray(current)) {
            const index = parseInt(part, 10)
            current = current[index]
        } else if (current[part] !== undefined) {
            current = current[part]
        } else {
            return null
        }
    }

    // Check if this is an AI enhanced field (has value, confidence, reason)
    if (current && typeof current === 'object' && 'confidence' in current && 'value' in current) {
        return current
    }

    return null
}

// Check if field has AI suggestion that differs from OCR
function hasAISuggestion(docName, fieldPath) {
    const suggestion = getAISuggestion(docName, fieldPath)
    if (!suggestion) return false

    // Compare AI value with OCR value
    const ocrValue = getNestedValue(documents[docName], fieldPath)

    // Normalize for comparison
    const normalizeValue = (val) => {
        if (val === null || val === undefined) return ''
        return String(val).trim().toUpperCase()
    }

    return normalizeValue(suggestion.value) !== normalizeValue(ocrValue)
}

// Check if AI suggestion is approved (uses override system)
function isAISuggestionApproved(docName, fieldPath) {
    const overrideInfo = typeof getOverrideInfo === 'function' ? getOverrideInfo(docName, fieldPath) : null
    return overrideInfo?.action === 'ai_enhancement'
}

// Check if AI suggestion is dismissed (uses override system's dismissedAI)
function isAISuggestionDismissed(docName, fieldPath) {
    return dataOverrides.dismissedAI?.[docName]?.[fieldPath] === true
}

// Apply AI suggestion to a field (instant 1-click)
async function applyAISuggestion(docName, fieldPath) {
    const suggestion = getAISuggestion(docName, fieldPath)
    if (!suggestion) return

    const originalValue = getNestedValue(documents[docName], fieldPath)

    // Use override system to apply AI value with reason
    addOverride(docName, fieldPath, suggestion.value, originalValue, {
        action: 'ai_enhancement',
        reason: suggestion.reason || 'AI enhancement'
    })

    // Show success toast
    if (typeof showToast === 'function') {
        showToast('✓ AI suggestion applied', 'success')
    }
}

// Dismiss AI suggestion (stores in override system)
async function dismissAISuggestion(docName, fieldPath) {
    // Initialize dismissedAI structure if needed
    if (!dataOverrides.dismissedAI) {
        dataOverrides.dismissedAI = {}
    }
    if (!dataOverrides.dismissedAI[docName]) {
        dataOverrides.dismissedAI[docName] = {}
    }

    // Mark as dismissed
    dataOverrides.dismissedAI[docName][fieldPath] = true

    // Save overrides (which now includes dismissedAI)
    await saveOverrides()

    // Re-render to hide the suggestion
    if (typeof render === 'function') {
        render()
    }

    if (typeof showToast === 'function') {
        showToast('AI suggestion dismissed', 'info')
    }
}

// Get all fields with AI suggestions for a document
function getAllFieldsWithAI(docName) {
    const fields = []

    function traverse(data, path = '') {
        if (!data || typeof data !== 'object') return

        // Check if this is an AI enhanced field (has value, confidence, reason)
        if ('confidence' in data && 'value' in data) {
            const ocrValue = getNestedValue(documents[docName], path)
            fields.push({
                path,
                suggestion: data,
                currentValue: ocrValue
            })
            return
        }

        // Traverse into nested objects
        for (const key in data) {
            const nextPath = path ? `${path}.${key}` : key
            traverse(data[key], nextPath)
        }
    }

    if (aiEnhancements.data[docName]) {
        traverse(aiEnhancements.data[docName])
    }

    return fields
}

// Count AI suggestions
function countAISuggestions(options = {}) {
    const { docName = null, onlyPending = false, minConfidence = 0 } = options

    let count = 0
    const docsToCheck = docName ? [docName] : Object.keys(aiEnhancements.data)

    for (const doc of docsToCheck) {
        const fields = getAllFieldsWithAI(doc)

        for (const field of fields) {
            // Skip empty AI values
            const aiValue = field.suggestion?.value
            const hasValidValue = aiValue !== null && aiValue !== undefined && String(aiValue).trim() !== ''
            if (!hasValidValue) continue

            // Skip if AI value matches current value
            const override = typeof getOverrideValue === 'function' ? getOverrideValue(doc, field.path) : null
            const currentValue = override !== null ? override : getNestedValue(documents[doc], field.path)
            const currentValueStr = String(currentValue ?? '').trim()
            const aiValueStr = String(aiValue ?? '').trim()
            if (currentValueStr === aiValueStr) continue

            const isApproved = isAISuggestionApproved(doc, field.path)
            const isDismissed = isAISuggestionDismissed(doc, field.path)
            const meetsConfidence = field.suggestion.confidence >= minConfidence

            if (onlyPending) {
                if (!isApproved && !isDismissed && meetsConfidence) {
                    count++
                }
            } else {
                if (meetsConfidence) {
                    count++
                }
            }
        }
    }

    return count
}

// Initialize AI enhancement system
async function initializeAIEnhancements() {
    // Load AI data for all documents in registry
    const docNames = Object.keys(documents || {})
    const promises = docNames.map(docName => loadAIEnhancedData(docName))

    await Promise.all(promises)

    const totalSuggestions = countAISuggestions()
    const pendingSuggestions = countAISuggestions({ onlyPending: true })

    if (totalSuggestions > 0) {
        console.log(`AI: ${totalSuggestions} suggestions, ${pendingSuggestions} pending`)
    }
}

// Check if document has any AI enhanced data
function hasDocumentAIData(docName) {
    return aiEnhancements.data[docName] && Object.keys(aiEnhancements.data[docName]).length > 0
}

// Check if document AI banner was dismissed
function isDocumentAIBannerDismissed(docName) {
    return dataOverrides.dismissedAI?.[docName]?.['__banner__'] === true
}

// Dismiss the AI banner for a document
async function dismissDocumentAIBanner(docName) {
    if (!dataOverrides.dismissedAI) {
        dataOverrides.dismissedAI = {}
    }
    if (!dataOverrides.dismissedAI[docName]) {
        dataOverrides.dismissedAI[docName] = {}
    }
    dataOverrides.dismissedAI[docName]['__banner__'] = true

    await saveOverrides()

    // Re-render to hide banner
    if (typeof render === 'function') {
        render()
    }
}

// Apply all pending AI suggestions for a document
async function applyAllAISuggestions(docName) {
    const fields = getAllFieldsWithAI(docName)
    let appliedCount = 0

    for (const field of fields) {
        const isApproved = isAISuggestionApproved(docName, field.path)
        const isDismissed = isAISuggestionDismissed(docName, field.path)

        // Skip if already approved or dismissed
        if (isApproved || isDismissed) continue

        // Check if AI value differs from current
        const suggestion = field.suggestion
        const ocrValue = getNestedValue(documents[docName], field.path)

        const normalizeValue = (val) => {
            if (val === null || val === undefined) return ''
            return String(val).trim().toUpperCase()
        }

        if (normalizeValue(suggestion.value) !== normalizeValue(ocrValue)) {
            // Apply this suggestion
            addOverride(docName, field.path, suggestion.value, ocrValue, {
                action: 'ai_enhancement',
                reason: suggestion.reason || 'AI enhancement (bulk apply)'
            })
            appliedCount++
        }
    }

    // Also dismiss the banner after applying
    if (!dataOverrides.dismissedAI) {
        dataOverrides.dismissedAI = {}
    }
    if (!dataOverrides.dismissedAI[docName]) {
        dataOverrides.dismissedAI[docName] = {}
    }
    dataOverrides.dismissedAI[docName]['__banner__'] = true

    await saveOverrides()

    if (appliedCount > 0) {
        showToast(`Applied ${appliedCount} AI suggestions`, 'success')
    } else {
        showToast('No pending AI suggestions to apply', 'info')
    }
}

// Simple toast notification
function showToast(message, type = 'info') {
    const toast = document.createElement('div')
    toast.className = `toast toast-${type}`
    toast.textContent = message
    toast.style.cssText = `
    position: fixed;
    bottom: 24px;
    right: 24px;
    padding: 12px 24px;
    background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
    color: white;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 10000;
    animation: slideInUp 0.3s ease;
  `

    document.body.appendChild(toast)

    setTimeout(() => {
        toast.style.animation = 'slideOutDown 0.3s ease'
        setTimeout(() => toast.remove(), 300)
    }, 2000)
}

// Add CSS animations for toast
if (!document.getElementById('ai-toast-styles')) {
    const style = document.createElement('style')
    style.id = 'ai-toast-styles'
    style.textContent = `
    @keyframes slideInUp {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes slideOutDown {
      from { opacity: 1; transform: translateY(0); }
      to { opacity: 0; transform: translateY(20px); }
    }
  `
    document.head.appendChild(style)
}
