// ============ NOTES PANEL UI ============

let notesOpen = false
let notesEditMode = false
let notesContent = ''
let notesSaveTimeout = null

// Structured annotations data (with bounding boxes)
let annotationsData = {
    annotations: [],  // Array of annotation objects with boundingBox
    markdown: ''      // User's markdown content
}

// Track which annotation is currently being viewed
let activeAnnotationId = null

// Track editing state for cancel functionality
let editingState = {
    annotationId: null,
    isNew: false,
    originalData: null  // Copy of annotation before editing
}

// Free annotation mode - user draws bounding box on document
let freeAnnotationMode = false
let freeAnnotationDocName = null  // Current document being annotated

// Show all notes toggle - renders all annotation bounding boxes on canvas
let showAllNotes = false

// Toggle notes panel
function toggleNotesPanel() {
    notesOpen = !notesOpen
    if (notesOpen && !notesContent) {
        loadNotes()
    } else {
        renderNotesPanel()
    }
}

// Load notes from server
async function loadNotes() {
    // In export mode or read-only mode, load from embedded data
    const isReadOnly = (typeof state !== 'undefined' && state.readOnlyMode) || window.__EXPORT_READ_ONLY_MODE

    if (isReadOnly) {
        const embedded = window.__embeddedUserData || {}
        // Annotations are stored in embedded.annotations (matching annotations.json)
        annotationsData = embedded.annotations || { annotations: [], markdown: '' }
        notesContent = annotationsData.markdown || ''
        renderNotesPanel()
        return
    }

    try {
        const batchId = typeof getBatchId === 'function' ? getBatchId() : null

        // Load markdown notes
        const notesResponse = await fetch(`/api/notes?batch_id=${batchId}`)
        if (notesResponse.ok) {
            notesContent = await notesResponse.text()
            console.log('Loaded notes from server')
        } else {
            notesContent = ''
        }

        // Load structured annotations
        const annotationsResponse = await fetch(`/api/annotations?batch_id=${batchId}`)
        if (annotationsResponse.ok) {
            annotationsData = await annotationsResponse.json()
            console.log('Loaded annotations from server:', annotationsData.annotations?.length || 0, 'annotations')
        } else {
            annotationsData = { annotations: [], markdown: '' }
        }
    } catch (err) {
        console.error('Failed to load notes:', err)
        notesContent = ''
        annotationsData = { annotations: [], markdown: '' }
    }
    renderNotesPanel()
}

// Save notes to server
async function saveNotes() {
    // Don't save in read-only or export mode
    const isReadOnly = (typeof state !== 'undefined' && state.readOnlyMode) || window.__EXPORT_READ_ONLY_MODE
    if (isReadOnly) {
        return
    }

    try {
        const batchId = typeof getBatchId === 'function' ? getBatchId() : null

        // Sync annotations to notesContent before saving
        syncAnnotationsToNotes()

        // Save markdown (with synced annotations)
        await fetch(`/api/notes?batch_id=${batchId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain; charset=utf-8' },
            body: notesContent
        })

        // Save structured annotations (for bounding box rendering)
        await fetch(`/api/annotations?batch_id=${batchId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(annotationsData)
        })

        console.log('Saved notes and annotations to server')
        updateNotesToggleBadge()

        // Re-render canvas if document viewer is open
        if (typeof drawAllPages === 'function' && state.viewerOpen && !state.gridViewOpen) {
            setTimeout(drawAllPages, 100)
        }
    } catch (err) {
        console.error('Failed to save notes to server:', err)
    }
}

// Debounced save
function debouncedSaveNotes() {
    if (notesSaveTimeout) {
        clearTimeout(notesSaveTimeout)
    }
    notesSaveTimeout = setTimeout(() => {
        saveNotes()
    }, 1500)
}

// Get annotations for a specific page (optionally filtered by document)
function getAnnotationsForPage(pageIndex, docName) {
    if (!annotationsData || !annotationsData.annotations) return []

    // Use documentViewerDocName if no docName provided
    const currentDocName = docName || state.documentViewerDocName

    // If showAllNotes is enabled, return all annotations for this document and page
    if (showAllNotes && currentDocName) {
        return annotationsData.annotations.filter(a =>
            a.docName === currentDocName && a.pageIndex === pageIndex
        )
    }

    // If there's an active annotation, only return that one if it matches the page and document
    if (activeAnnotationId) {
        const activeAnno = annotationsData.annotations.find(a => a.id === activeAnnotationId)
        if (activeAnno && activeAnno.pageIndex === pageIndex &&
            (!currentDocName || activeAnno.docName === currentDocName)) {
            return [activeAnno]
        }
        return []
    }

    // Otherwise return empty - don't show annotations unless navigating to one
    return []
}

// Toggle show all notes on current document
function toggleShowAllNotes() {
    showAllNotes = !showAllNotes
    // Redraw canvas to show/hide all annotation boxes
    if (typeof drawAllPages === 'function') {
        drawAllPages()
    }
    // Update modal to reflect button state
    if (typeof renderModal === 'function') {
        renderModal()
    }
}

// Check if show all notes is enabled
function isShowAllNotesEnabled() {
    return showAllNotes
}

// Get all annotations
function getAllAnnotations() {
    return annotationsData?.annotations || []
}

// Simple markdown to HTML renderer
function renderMarkdown(md) {
    if (!md) return '<p class="notes-empty">No notes yet. Click "Edit" to add notes.</p>'

    let html = md
        // Escape HTML
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        // Headers
        .replace(/^### (.+)$/gm, '<h4>$1</h4>')
        .replace(/^## (.+)$/gm, '<h3>$1</h3>')
        .replace(/^# (.+)$/gm, '<h2>$1</h2>')
        // Bold and italic
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>')
        .replace(/__(.+?)__/g, '<strong>$1</strong>')
        .replace(/_(.+?)_/g, '<em>$1</em>')
        // Strikethrough
        .replace(/~~(.+?)~~/g, '<del>$1</del>')
        // Code
        .replace(/`([^`]+)`/g, '<code>$1</code>')
        // Horizontal rule
        .replace(/^---$/gm, '<hr>')
        // Checkbox lists
        .replace(/^- \[x\] (.+)$/gm, '<div class="note-checkbox checked"><input type="checkbox" checked disabled> $1</div>')
        .replace(/^- \[ \] (.+)$/gm, '<div class="note-checkbox"><input type="checkbox" disabled> $1</div>')
        // Unordered lists
        .replace(/^- (.+)$/gm, '<li>$1</li>')
        // Blockquotes
        .replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>')
        // Line breaks
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>')

    // Wrap in paragraph
    html = '<p>' + html + '</p>'

    // Fix list items
    html = html.replace(/(<li>.*?<\/li>)+/g, '<ul>$&</ul>')
        .replace(/<\/ul><ul>/g, '')

    return html
}

// Get notes count for badge
function getNotesCount() {
    const markdownCount = notesContent ? notesContent.split('\n').filter(line => line.trim().startsWith('- ')).length : 0
    const annotationCount = annotationsData?.annotations?.length || 0
    return Math.max(markdownCount, annotationCount)
}

// Update toggle button badge
function updateNotesToggleBadge() {
    const badge = document.querySelector('#notes-toggle .notes-badge')
    if (badge) {
        const count = getNotesCount()
        badge.textContent = count
        badge.style.display = count > 0 ? 'flex' : 'none'
    }
}

// Render annotations list in panel
function renderAnnotationsList() {
    const annotations = annotationsData?.annotations || []

    // Sort by createdAt descending (newest first)
    const sortedAnnotations = [...annotations].sort((a, b) => {
        const dateA = new Date(a.createdAt || 0)
        const dateB = new Date(b.createdAt || 0)
        return dateB - dateA
    })

    // Check if in read-only or export mode
    const isReadOnly = (typeof state !== 'undefined' && state.readOnlyMode) || window.__EXPORT_READ_ONLY_MODE

    // Check if document viewer is open (only allow adding annotations if not read-only)
    const canAddFreeAnnotation = !isReadOnly && state.viewerOpen && !state.gridViewOpen && state.documentViewerDocName

    const addButton = isReadOnly
        ? '' // No add button in read-only mode
        : canAddFreeAnnotation
            ? `<button class="btn-free-annotation ${freeAnnotationMode ? 'active' : ''}" onclick="toggleFreeAnnotationMode()">
            ${freeAnnotationMode ? 'Drawing Mode Active - Click to Exit' : '+ Draw Annotation on Document'}
           </button>`
            : `<div class="add-annotation-hint">Open a document to add notes with draw on document.</div>`

    const emptyMessage = isReadOnly
        ? '<div class="annotations-empty">No annotations in this document.</div>'
        : '<div class="annotations-empty">No annotations yet. Use 💬 on fields or draw on document.</div>'

    const listContent = annotations.length === 0
        ? emptyMessage
        : `<div class="annotations-list">
        ${sortedAnnotations.map((a, idx) => `
          <div class="annotation-item ${a.type || 'note'} ${activeAnnotationId === a.id ? 'active' : ''}" 
               data-id="${a.id}" 
               onclick="navigateToAnnotation('${a.id}')">
            <div class="annotation-item-header">
              <span class="annotation-field">${escapeHtml(a.fieldName || a.fieldPath)}</span>
              ${!isReadOnly ? `
                <button class="annotation-edit" onclick="event.stopPropagation(); startEditingAnnotation('${a.id}')" title="Edit">
                  ${icons.edit}
                </button>
                <button class="annotation-delete" onclick="event.stopPropagation(); deleteAnnotation('${a.id}')" title="Delete">×</button>
              ` : ''}
            </div>
            <div class="annotation-doc">${escapeHtml(a.docName)} - Page ${a.pageIndex + 1}</div>
            ${a.text ? `<div class="annotation-text">${escapeHtml(a.text)}</div>` : ''}
          </div>
        `).join('')}
      </div>`

    return `
    <div class="annotations-container">
      ${addButton}
      ${listContent}
    </div>
  `
}

// Navigate to annotation - opens document viewer and highlights the annotation
function navigateToAnnotation(annotationId) {
    const annotation = annotationsData.annotations?.find(a => a.id === annotationId)
    if (!annotation) return

    // Reset skipAutoScroll to allow scroll to annotation bounding box
    window.skipAutoScroll = false

    console.log('Navigating to annotation:', {
        id: annotation.id,
        docName: annotation.docName,
        pageIndex: annotation.pageIndex,
        fieldName: annotation.fieldName
    })

    // Set active annotation
    activeAnnotationId = annotationId

    // Close notes panel
    notesOpen = false
    renderNotesPanel()

    // Navigate to document viewer with the annotation's page and bounding box
    if (typeof openViewer === 'function') {
        // Set the document name so viewer knows which document to show
        state.pendingDocumentViewerDocName = annotation.docName
        console.log('Set pendingDocumentViewerDocName to:', annotation.docName)

        // Open viewer to the annotation's page with its bounding box
        openViewer(annotation.pageIndex, annotation.boundingBox, annotation.fieldName)
    }
}

// Clear active annotation (called when closing viewer)
function clearActiveAnnotation() {
    activeAnnotationId = null
}

// Toggle free annotation mode
function toggleFreeAnnotationMode() {
    freeAnnotationMode = !freeAnnotationMode

    if (freeAnnotationMode) {
        freeAnnotationDocName = state.documentViewerDocName
        document.body.classList.add('free-annotation-mode')

        // Set flag to prevent scroll reset during annotation mode
        window.skipAutoScroll = true

        // Clear any active annotation to remove its bounding box
        activeAnnotationId = null

        // Clear document field highlight and selected evidence to prevent old bounding boxes
        state.documentFieldHighlight = null
        state.selectedEvidence = null

        // Redraw canvas to clear the old annotation box
        if (typeof drawAllPages === 'function') {
            setTimeout(drawAllPages, 50)
        }
    } else {
        freeAnnotationDocName = null
        document.body.classList.remove('free-annotation-mode')
    }

    renderNotesPanel()
}

// Complete free annotation - called from canvas after user draws bounding box
function completeFreeAnnotation(pageIndex, boundingBox) {
    if (!freeAnnotationMode || !freeAnnotationDocName) return

    // Create new annotation with the drawn bounding box
    const annotation = {
        id: `anno_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        docName: freeAnnotationDocName,
        fieldPath: 'user_note',
        fieldName: 'User Note',
        pageIndex: pageIndex,
        boundingBox: boundingBox,
        type: 'note',
        text: '',
        createdAt: new Date().toISOString(),
        status: 'open'
    }

    // Add annotation
    if (!annotationsData.annotations) {
        annotationsData.annotations = []
    }
    annotationsData.annotations.push(annotation)

    // Set the new annotation as active so its bounding box is displayed
    activeAnnotationId = annotation.id

    // Exit free annotation mode
    freeAnnotationMode = false
    freeAnnotationDocName = null
    document.body.classList.remove('free-annotation-mode')

    // Open notes panel for editing
    notesOpen = true
    renderNotesPanel()

    // Redraw canvas to show the new annotation bounding box
    if (typeof drawAllPages === 'function') {
        drawAllPages()
    }

    // Start editing the new annotation (only scroll the notes panel, not the document)
    setTimeout(() => {
        const newItem = document.querySelector(`[data-id="${annotation.id}"]`)
        if (newItem) {
            newItem.scrollIntoView({ behavior: 'smooth', block: 'center' })
            startEditingAnnotation(annotation.id, true)
        }
    }, 100)
}

// Check if free annotation mode is active
function isFreeAnnotationMode() {
    return freeAnnotationMode
}

// Render notes panel
function renderNotesPanel() {
    let existingPanel = document.getElementById('notes-panel')

    if (existingPanel) existingPanel.remove()

    // Note: We allow panel rendering in read-only/export mode so users can view notes

    const notesCount = getNotesCount()

    // Create or update action toolbar
    let toolbar = document.getElementById('action-toolbar')
    if (!toolbar) {
        toolbar = document.createElement('div')
        toolbar.id = 'action-toolbar'
        toolbar.className = 'action-toolbar'
        document.body.appendChild(toolbar)
    }

    // Update notes button in toolbar
    let notesBtn = document.getElementById('action-btn-notes')
    if (!notesBtn) {
        notesBtn = document.createElement('button')
        notesBtn.id = 'action-btn-notes'
        notesBtn.className = 'action-toolbar-btn'
        notesBtn.setAttribute('data-tooltip', 'Notes')
        notesBtn.onclick = toggleNotesPanel
        // Insert at beginning
        toolbar.insertBefore(notesBtn, toolbar.firstChild)
    }
    notesBtn.innerHTML = `
    ${icons.fileText || icons.file}
    ${notesCount > 0 ? `<span class="toolbar-badge">${notesCount}</span>` : ''}
  `

    // Render panel if open
    if (notesOpen) {
        const panel = document.createElement('div')
        panel.id = 'notes-panel'
        panel.className = 'notes-panel'

        const editorContent = notesEditMode
            ? `<textarea id="notes-editor" class="notes-editor" placeholder="# Document Notes\n\n- Issue description\n- Question\n- Note">${escapeHtml(notesContent)}</textarea>`
            : `<div class="notes-preview">${renderMarkdown(notesContent)}</div>`

        panel.innerHTML = `
      <div class="notes-header">
        <div class="notes-title">
          ${icons.fileText || icons.file}
          <span>Notes</span>
          ${notesCount > 0 ? `<span class="notes-count-badge">${notesCount}</span>` : ''}
        </div>
        <div class="notes-toolbar">
          <button class="notes-mode-btn ${!notesEditMode ? 'active' : ''}" onclick="setNotesMode(false)" title="Annotations">
            ${icons.messageSquare}
          </button>
          <button class="notes-mode-btn ${notesEditMode ? 'active' : ''}" onclick="setNotesMode(true)" title="Markdown Notes">
            ${icons.edit}
          </button>
          <button class="notes-export-btn" onclick="exportNotes()" title="Export">
            ${icons.download || icons.externalLink}
          </button>
          <button class="btn-close-panel" onclick="toggleNotesPanel()">${icons.x}</button>
        </div>
      </div>
      <div class="notes-body">
        ${notesEditMode
                ? `<div class="markdown-toolbar">
                     <button type="button" class="md-btn" data-format="heading" onclick="formatText('heading')" data-tooltip="Heading">
                       H
                     </button>
                     <button type="button" class="md-btn" data-format="bold" onclick="formatText('bold')" data-tooltip="Bold">
                       <strong>B</strong>
                     </button>
                     <button type="button" class="md-btn" data-format="italic" onclick="formatText('italic')" data-tooltip="Italic">
                       <em>I</em>
                     </button>
                     <span class="md-separator"></span>
                     <button type="button" class="md-btn" data-format="bullet" onclick="formatText('bullet')" data-tooltip="Bullet List">
                       ${icons.list || '•'}
                     </button>
                     <button type="button" class="md-btn" data-format="numbered" onclick="formatText('numbered')" data-tooltip="Numbered List">
                       ${icons.listOrdered || '1.'}
                     </button>
                     <span class="md-separator"></span>
                     <button type="button" class="md-btn" data-format="quote" onclick="formatText('quote')" data-tooltip="Quote">
                       ${icons.quote || '"'}
                     </button>
                   </div>
                   <div id="notes-editor" class="notes-editor wysiwyg" contenteditable="true" data-placeholder="Write your notes here...">${markdownToHtml(notesContent)}</div>`
                : renderAnnotationsList()
            }
      </div>
    `

        document.body.appendChild(panel)

        if (notesEditMode) {
            const editor = document.getElementById('notes-editor')
            if (editor) {
                editor.addEventListener('input', (e) => {
                    // Convert HTML to markdown for storage
                    notesContent = htmlToMarkdown(editor.innerHTML)
                    debouncedSaveNotes()
                })

                // Update toolbar button active states on selection change
                document.addEventListener('selectionchange', updateToolbarState)
                editor.addEventListener('keyup', updateToolbarState)
                editor.addEventListener('mouseup', updateToolbarState)

                editor.focus()
            }
        }
    }
}

// Set edit mode
function setNotesMode(editMode) {
    notesEditMode = editMode
    renderNotesPanel()
}

// Update toolbar button active states based on current selection
function updateToolbarState() {
    const buttons = document.querySelectorAll('.md-btn[data-format]')
    if (!buttons.length) return

    buttons.forEach(btn => {
        const format = btn.dataset.format
        let isActive = false

        switch (format) {
            case 'bold':
                isActive = document.queryCommandState('bold')
                break
            case 'italic':
                isActive = document.queryCommandState('italic')
                break
            case 'bullet':
                isActive = document.queryCommandState('insertUnorderedList')
                break
            case 'numbered':
                isActive = document.queryCommandState('insertOrderedList')
                break
            case 'heading':
                // Check if in heading block
                const selection = window.getSelection()
                if (selection.rangeCount > 0) {
                    let node = selection.anchorNode
                    while (node && node !== document.getElementById('notes-editor')) {
                        if (node.nodeName && /^H[1-3]$/.test(node.nodeName)) {
                            isActive = true
                            break
                        }
                        node = node.parentNode
                    }
                }
                break
            case 'quote':
                // Check if in blockquote
                const sel = window.getSelection()
                if (sel.rangeCount > 0) {
                    let n = sel.anchorNode
                    while (n && n !== document.getElementById('notes-editor')) {
                        if (n.nodeName === 'BLOCKQUOTE') {
                            isActive = true
                            break
                        }
                        n = n.parentNode
                    }
                }
                break
        }

        btn.classList.toggle('active', isActive)
    })
}

// Convert markdown to HTML for WYSIWYG display
function markdownToHtml(markdown) {
    if (!markdown) return ''

    let html = markdown
        // Headers
        .replace(/^### (.+)$/gm, '<h3>$1</h3>')
        .replace(/^## (.+)$/gm, '<h2>$1</h2>')
        .replace(/^# (.+)$/gm, '<h1>$1</h1>')
        // Bold and italic
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>')
        // Lists
        .replace(/^- (.+)$/gm, '<li>$1</li>')
        .replace(/^(\d+)\. (.+)$/gm, '<li>$2</li>')
        // Blockquotes
        .replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>')
        // Links
        .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2">$1</a>')
        // Line breaks
        .replace(/\n/g, '<br>')

    // Wrap consecutive li in ul
    html = html.replace(/(<li>.*?<\/li>)(<br>)?/g, '$1')

    return html || '<br>'
}

// Convert HTML to markdown for storage
function htmlToMarkdown(html) {
    if (!html) return ''

    // Create temp element to parse HTML
    const temp = document.createElement('div')
    temp.innerHTML = html

    let markdown = ''

    function processNode(node) {
        if (node.nodeType === 3) { // Text node
            return node.textContent
        }
        if (node.nodeType !== 1) return ''

        const tag = node.tagName.toLowerCase()
        let content = Array.from(node.childNodes).map(processNode).join('')

        switch (tag) {
            case 'h1': return `# ${content}\n`
            case 'h2': return `## ${content}\n`
            case 'h3': return `### ${content}\n`
            case 'strong':
            case 'b': return `**${content}**`
            case 'em':
            case 'i': return `*${content}*`
            case 'li': return `- ${content}\n`
            case 'ul':
            case 'ol': return content
            case 'blockquote': return `> ${content}\n`
            case 'a': return `[${content}](${node.href || 'url'})`
            case 'br': return '\n'
            case 'div':
            case 'p': return content + '\n'
            default: return content
        }
    }

    markdown = Array.from(temp.childNodes).map(processNode).join('')

    // Clean up extra newlines
    return markdown.replace(/\n{3,}/g, '\n\n').trim()
}

// Format text in WYSIWYG editor using execCommand
function formatText(type) {
    const editor = document.getElementById('notes-editor')
    if (!editor) return

    editor.focus()

    switch (type) {
        case 'heading':
            document.execCommand('formatBlock', false, 'h2')
            break
        case 'bold':
            document.execCommand('bold', false, null)
            break
        case 'italic':
            document.execCommand('italic', false, null)
            break
        case 'bullet':
            document.execCommand('insertUnorderedList', false, null)
            break
        case 'numbered':
            document.execCommand('insertOrderedList', false, null)
            break
        case 'issue':
            document.execCommand('insertText', false, '🔴 ')
            break
        case 'question':
            document.execCommand('insertText', false, '🟡 ')
            break
        case 'note':
            document.execCommand('insertText', false, '📝 ')
            break
        case 'link':
            const selection = window.getSelection()
            const text = selection.toString() || 'link text'
            const url = prompt('Enter URL:', 'https://')
            if (url) {
                document.execCommand('insertHTML', false, `<a href="${url}">${text}</a>`)
            }
            break
        case 'quote':
            document.execCommand('formatBlock', false, 'blockquote')
            break
    }

    // Trigger save
    notesContent = htmlToMarkdown(editor.innerHTML)
    debouncedSaveNotes()
}

// Keep insertMarkdown for backward compatibility (no longer used in WYSIWYG mode)
function insertMarkdown(type) {
    const editor = document.getElementById('notes-editor')
    if (!editor) return

    const start = editor.selectionStart
    const end = editor.selectionEnd
    const selectedText = editor.value.substring(start, end)
    const beforeText = editor.value.substring(0, start)
    const afterText = editor.value.substring(end)

    let insertText = ''
    let cursorOffset = 0

    switch (type) {
        case 'heading':
            // Add heading at line start
            const lineStart = beforeText.lastIndexOf('\n') + 1
            const prefix = beforeText.substring(lineStart)
            if (prefix.startsWith('### ')) {
                // Remove heading
                insertText = selectedText || 'Heading'
            } else if (prefix.startsWith('## ')) {
                // Upgrade to h3
                insertText = `### ${selectedText || 'Heading'}`
            } else if (prefix.startsWith('# ')) {
                // Upgrade to h2
                insertText = `## ${selectedText || 'Heading'}`
            } else {
                insertText = `# ${selectedText || 'Heading'}`
            }
            cursorOffset = insertText.length
            break
        case 'bold':
            insertText = `**${selectedText || 'bold text'}**`
            cursorOffset = selectedText ? insertText.length : 2
            break
        case 'italic':
            insertText = `*${selectedText || 'italic text'}*`
            cursorOffset = selectedText ? insertText.length : 1
            break
        case 'bullet':
            insertText = `\n- ${selectedText || 'List item'}`
            cursorOffset = insertText.length
            break
        case 'numbered':
            insertText = `\n1. ${selectedText || 'List item'}`
            cursorOffset = insertText.length
            break
        case 'checkbox':
            insertText = `\n- [ ] ${selectedText || 'Task'}`
            cursorOffset = insertText.length
            break
        case 'issue':
            insertText = `\n- 🔴 ${selectedText || 'Issue description'}`
            cursorOffset = insertText.length
            break
        case 'question':
            insertText = `\n- 🟡 ${selectedText || 'Question'}`
            cursorOffset = insertText.length
            break
        case 'note':
            insertText = `\n- 📝 ${selectedText || 'Note'}`
            cursorOffset = insertText.length
            break
        case 'link':
            if (selectedText) {
                insertText = `[${selectedText}](url)`
                cursorOffset = insertText.length - 1
            } else {
                insertText = `[link text](url)`
                cursorOffset = 1
            }
            break
        case 'quote':
            insertText = `\n> ${selectedText || 'Quote'}`
            cursorOffset = insertText.length
            break
        default:
            return
    }

    editor.value = beforeText + insertText + afterText
    notesContent = editor.value

    // Set cursor position and restore scroll
    const scrollPos = editor.scrollTop
    editor.focus()
    const newPos = start + cursorOffset
    editor.setSelectionRange(newPos, newPos)

    // Keep scroll position near the cursor
    editor.scrollTop = scrollPos

    // Trigger save
    debouncedSaveNotes()
}

// Sync annotations to notesContent markdown
// This keeps both in sync so download has everything in one place
function syncAnnotationsToNotes() {
    const annotations = annotationsData?.annotations || []
    if (annotations.length === 0) return

    // Find existing annotations section
    const separator = '---'
    const sectionHeader = '## Field Annotations'

    // Get user's free-form notes (before the annotations section)
    let userNotes = notesContent || ''
    const sectionIndex = userNotes.indexOf(sectionHeader)
    if (sectionIndex !== -1) {
        // Find separator before section
        let sepIndex = userNotes.lastIndexOf(separator, sectionIndex)
        if (sepIndex !== -1) {
            userNotes = userNotes.substring(0, sepIndex).trim()
        }
    }

    // Build annotations markdown
    let annotationsMarkdown = '\n\n---\n\n## Field Annotations\n\n'
    annotations.forEach(a => {
        const icon = a.type === 'issue' ? '🔴' : a.type === 'question' ? '🟡' : '📝'
        annotationsMarkdown += `- ${icon} **${a.fieldName || a.fieldPath}** (${a.docName}, Page ${a.pageIndex + 1})\n`
        if (a.text) annotationsMarkdown += `  > ${a.text}\n`
    })

    // Combine user notes and annotations
    notesContent = userNotes + (userNotes.trim() ? '' : '') + annotationsMarkdown.trim()
}

// Export notes (annotations are already synced to notesContent via syncAnnotationsToNotes)
function exportNotes() {
    const batchId = typeof getBatchId === 'function' ? getBatchId() : 'notes'

    // Sync annotations to notes before export
    syncAnnotationsToNotes()

    const blob = new Blob([notesContent || ''], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `notes_${batchId}_${new Date().toISOString().split('T')[0]}.md`
    link.click()
    URL.revokeObjectURL(url)
}

// Add quick note for a field (called from grid card)
function addFieldNote(docName, fieldPath, pageIndex, fieldName, boundingBox) {
    // Get bounding box from the evidence if not provided
    let bbox = boundingBox
    if (!bbox && state.gridViewValidation) {
        const ev = state.gridViewValidation.evidence.find(e =>
            e.doc_name === docName && e.source_page_index === pageIndex
        )
        if (ev && ev.bounding_box) {
            bbox = ev.bounding_box
        }
    }

    // Create annotation object
    const annotation = {
        id: `anno_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        docName: docName,
        fieldPath: fieldPath,
        fieldName: fieldName || fieldPath,
        pageIndex: pageIndex,
        boundingBox: bbox || null,
        type: 'note',  // 'issue', 'question', 'note'
        text: '',
        createdAt: new Date().toISOString(),
        status: 'open'
    }

    // Add annotation to data
    if (!annotationsData.annotations) {
        annotationsData.annotations = []
    }
    annotationsData.annotations.push(annotation)

    // Open panel and render
    notesOpen = true
    notesEditMode = false
    renderNotesPanel()
    // Don't save yet - user needs to fill in details first

    // Focus on the new annotation for editing (mark as new)
    setTimeout(() => {
        const newItem = document.querySelector(`[data-id="${annotation.id}"]`)
        if (newItem) {
            newItem.scrollIntoView({ behavior: 'smooth', block: 'center' })
            // Make the text editable with isNew flag
            startEditingAnnotation(annotation.id, true)
        }
    }, 100)
}

// Start editing an annotation inline
function startEditingAnnotation(annotationId, isNew = false) {
    const annotation = annotationsData.annotations?.find(a => a.id === annotationId)
    if (!annotation) return

    const item = document.querySelector(`[data-id="${annotationId}"]`)
    if (!item) return

    // Store editing state for cancel
    editingState = {
        annotationId: annotationId,
        isNew: isNew,
        originalData: isNew ? null : { ...annotation }  // Copy for revert
    }

    // Mark as editing to prevent navigation
    item.classList.add('editing')

    // Remove the onclick to prevent navigation while editing
    item.onclick = null

    // Replace text div with input form
    item.innerHTML = `
    <div class="annotation-edit-form" onclick="event.stopPropagation()">
      <div class="annotation-type-select">
        <button class="type-btn ${annotation.type === 'issue' ? 'active' : ''}" data-type="issue" onclick="event.stopPropagation(); setAnnotationType('${annotationId}', 'issue')">Issue</button>
        <button class="type-btn ${annotation.type === 'note' ? 'active' : ''}" data-type="note" onclick="event.stopPropagation(); setAnnotationType('${annotationId}', 'note')">Note</button>
      </div>
      <div class="annotation-edit-field">
        <strong>${escapeHtml(annotation.fieldName)}</strong>
        <small>${escapeHtml(annotation.docName)} - Page ${annotation.pageIndex + 1}</small>
      </div>
      <textarea id="annotation-text-${annotationId}" class="annotation-textarea" placeholder="Enter note..." rows="2" onclick="event.stopPropagation()">${escapeHtml(annotation.text || '')}</textarea>
      <div class="annotation-edit-actions">
        <button class="btn-save-annotation" onclick="event.stopPropagation(); saveAnnotationEdit('${annotationId}')">Save</button>
        <button class="btn-cancel-annotation" onclick="event.stopPropagation(); cancelAnnotationEdit('${annotationId}')">Cancel</button>
      </div>
    </div>
  `

    // Focus textarea
    const textarea = document.getElementById(`annotation-text-${annotationId}`)
    if (textarea) {
        textarea.focus()
    }
}

// Cancel annotation edit
function cancelAnnotationEdit(annotationId) {
    if (editingState.isNew) {
        // If creating new, delete the annotation
        deleteAnnotation(annotationId)
    } else if (editingState.originalData) {
        // If editing existing, revert to original data
        const annotation = annotationsData.annotations?.find(a => a.id === annotationId)
        if (annotation) {
            Object.assign(annotation, editingState.originalData)
        }
        renderNotesPanel()
    } else {
        // Just re-render
        renderNotesPanel()
    }

    // Clear editing state
    editingState = { annotationId: null, isNew: false, originalData: null }
}

// Set annotation type
function setAnnotationType(annotationId, type) {
    const annotation = annotationsData.annotations?.find(a => a.id === annotationId)
    if (annotation) {
        annotation.type = type
    }
    // Update button states
    document.querySelectorAll(`[data-id="${annotationId}"] .type-btn`).forEach(btn => {
        btn.classList.toggle('active', btn.dataset.type === type)
    })
}

// Save annotation edit
function saveAnnotationEdit(annotationId) {
    const annotation = annotationsData.annotations?.find(a => a.id === annotationId)
    if (!annotation) return

    const textarea = document.getElementById(`annotation-text-${annotationId}`)
    if (textarea) {
        annotation.text = textarea.value.trim()
    }

    saveNotes()
    renderNotesPanel()

    // Re-render canvas if viewer is open
    if (typeof drawAllPages === 'function' && state.viewerOpen && !state.gridViewOpen) {
        setTimeout(drawAllPages, 100)
    }
}

// Show dialog to enter note text and type (legacy - kept for compatibility)
function showNoteDialog(annotation) {
    // Just use the inline edit instead
    addFieldNote(annotation.docName, annotation.fieldPath, annotation.pageIndex, annotation.fieldName, annotation.boundingBox)
}

// Show dialog for entering note details
function showNoteDialog(annotation) {
    // Remove existing dialog
    const existing = document.getElementById('note-dialog')
    if (existing) existing.remove()

    const dialog = document.createElement('div')
    dialog.id = 'note-dialog'
    dialog.className = 'note-dialog-overlay'
    dialog.innerHTML = `
    <div class="note-dialog">
      <div class="note-dialog-header">
        <span>Add Note: ${escapeHtml(annotation.fieldName)}</span>
        <button class="btn-close" onclick="closeNoteDialog()">${icons.x}</button>
      </div>
      <div class="note-dialog-body">
        <div class="note-dialog-field">
          <label>Type</label>
          <div class="note-type-buttons">
            <button class="note-type-btn issue" data-type="issue" onclick="selectNoteType(this)">Issue</button>
            <button class="note-type-btn note active" data-type="note" onclick="selectNoteType(this)">Note</button>
          </div>
        </div>
        <div class="note-dialog-field">
          <label>Note</label>
          <textarea id="note-dialog-text" placeholder="Enter your note here..." rows="3"></textarea>
        </div>
        <div class="note-dialog-info">
          <small>${escapeHtml(annotation.docName)} - Page ${annotation.pageIndex + 1}</small>
        </div>
      </div>
      <div class="note-dialog-footer">
        <button class="btn-cancel" onclick="closeNoteDialog()">Cancel</button>
        <button class="btn-save" onclick="saveNoteFromDialog()">Save Note</button>
      </div>
    </div>
  `

    document.body.appendChild(dialog)

    // Store annotation data for saving
    dialog.dataset.annotation = JSON.stringify(annotation)

    // Focus textarea
    document.getElementById('note-dialog-text').focus()
}

// Select note type in dialog
function selectNoteType(btn) {
    document.querySelectorAll('.note-type-btn').forEach(b => b.classList.remove('active'))
    btn.classList.add('active')
}

// Close note dialog
function closeNoteDialog() {
    const dialog = document.getElementById('note-dialog')
    if (dialog) dialog.remove()
}

// Save note from dialog
function saveNoteFromDialog() {
    const dialog = document.getElementById('note-dialog')
    if (!dialog) return

    const annotation = JSON.parse(dialog.dataset.annotation)
    const text = document.getElementById('note-dialog-text').value.trim()
    const typeBtn = document.querySelector('.note-type-btn.active')
    const type = typeBtn ? typeBtn.dataset.type : 'note'

    annotation.text = text
    annotation.type = type

    // Add to annotations
    if (!annotationsData.annotations) {
        annotationsData.annotations = []
    }
    annotationsData.annotations.push(annotation)

    // Also add to markdown content
    const icon = type === 'issue' ? '🔴' : type === 'question' ? '🟡' : '📝'
    const noteEntry = `- ${icon} **${annotation.fieldName}** \`(Page ${annotation.pageIndex + 1})\`${text ? ': ' + text : ''}\n`

    if (!notesContent.trim()) {
        notesContent = `# Document Notes\n\n## ${annotation.docName}\n\n${noteEntry}`
    } else if (notesContent.includes(`## ${annotation.docName}`)) {
        notesContent = notesContent.replace(`## ${annotation.docName}`, `## ${annotation.docName}\n\n${noteEntry}`)
    } else {
        notesContent += `\n\n## ${annotation.docName}\n\n${noteEntry}`
    }

    closeNoteDialog()
    saveNotes()
    renderNotesPanel()
}

// Delete annotation
function deleteAnnotation(id) {
    if (!annotationsData.annotations) return
    annotationsData.annotations = annotationsData.annotations.filter(a => a.id !== id)
    saveNotes()
    renderNotesPanel()

    // Re-render canvas if viewer is open
    if (typeof drawAllPages === 'function' && state.viewerOpen && !state.gridViewOpen) {
        setTimeout(drawAllPages, 100)
    }
}

// Initialize notes panel on page load
function initializeNotesPanel() {
    loadNotes().then(() => {
        renderNotesPanel()
    })
}

// Update notes panel
function updateNotesPanel() {
    if (notesOpen) {
        renderNotesPanel()
    }
}

// Make functions globally available
window.toggleNotesPanel = toggleNotesPanel
window.setNotesMode = setNotesMode
window.exportNotes = exportNotes
window.addFieldNote = addFieldNote
window.closeNoteDialog = closeNoteDialog
window.selectNoteType = selectNoteType
window.saveNoteFromDialog = saveNoteFromDialog
window.deleteAnnotation = deleteAnnotation
window.getAnnotationsForPage = getAnnotationsForPage
window.getAllAnnotations = getAllAnnotations
window.startEditingAnnotation = startEditingAnnotation
window.setAnnotationType = setAnnotationType
window.saveAnnotationEdit = saveAnnotationEdit
window.navigateToAnnotation = navigateToAnnotation
window.clearActiveAnnotation = clearActiveAnnotation
window.cancelAnnotationEdit = cancelAnnotationEdit
window.toggleFreeAnnotationMode = toggleFreeAnnotationMode
window.completeFreeAnnotation = completeFreeAnnotation
window.isFreeAnnotationMode = isFreeAnnotationMode

