function getStatusForPath(path) {
  if (validationIndexMap.has(path)) {
    return validationIndexMap.get(path).status
  }
  return null
}

function deriveStatusFromChildren(node) {
  if (node.status) return node.status
  if (!node.children || node.children.length === 0) return null

  let hasFail = false
  let hasPass = false

  for (const child of node.children) {
    const childStatus = deriveStatusFromChildren(child)
    if (childStatus === "FAIL") hasFail = true
    if (childStatus === "PASS") hasPass = true
  }

  if (hasFail) return "FAIL"
  if (hasPass) return "PASS"
  return null
}

function buildTreeDataForDocument(docName) {
  const docData = documents[docName]
  if (!docData) return []

  const rootNodes = []
  buildTreeNodes(docData, "", rootNodes)

  rootNodes.forEach(node => {
    node.derivedStatus = deriveStatusFromChildren(node)
  })

  return rootNodes
}

function buildTreeNodes(data, currentPath, nodes) {
  if (!data || typeof data !== "object") return

  const keys = Object.keys(data).sort()

  for (const key of keys) {
    if (key === "metadata" && currentPath === "") continue

    const value = data[key]
    const fullPath = currentPath ? `${currentPath}.${key}` : key

    const node = {
      id: fullPath,
      label: key,
      path: fullPath,
      children: [],
      value: null,
      status: getStatusForPath(fullPath),
      derivedStatus: null
    }

    // Special handling for line_items - add item validations as children
    if (key === 'line_items' && fullPath.includes('cargo_summary')) {
      node.status = getStatusForPath(fullPath);

      // Add individual line items as children
      if (analysisData && analysisData.validations) {
        const itemValidations = analysisData.validations.filter(v => v.isLineItem);
        itemValidations.forEach((itemVal, idx) => {
          const itemNode = {
            id: `${fullPath}.item_${idx}`,
            label: itemVal.check_name,
            path: itemVal.field_path,
            children: [],
            value: null,
            status: itemVal.status,
            derivedStatus: itemVal.status,
            isLineItemChild: true,
            validationIndex: analysisData.validations.indexOf(itemVal)
          };
          node.children.push(itemNode);
        });
      }
    } else if (value && typeof value === "object" && !Array.isArray(value)) {
      buildTreeNodes(value, fullPath, node.children)
    } else if (Array.isArray(value)) {
      value.forEach((item, index) => {
        if (item && typeof item === "object") {
          const arrayNode = {
            id: `${fullPath}[${index}]`,
            label: `${key}[${index}]`,
            path: `${fullPath}[${index}]`,
            children: [],
            value: null,
            status: null
          }
          buildTreeNodes(item, `${fullPath}[${index}]`, arrayNode.children)
          if (arrayNode.children.length > 0) {
            node.children.push(arrayNode)
          }
        }
      })
    } else {
      node.value = value
    }

    if (node.value !== null || node.children.length > 0) {
      nodes.push(node)
    }
  }
}

// ============ TREE VIEW RENDERING ============
function renderTreeView() {
  const listEl = document.getElementById("validation-list")

  // Save scroll position before re-rendering
  const scrollTop = listEl.scrollTop

  if (!treeDocumentName) {
    listEl.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">${icons.file}</div>
        <div class="empty-title">No Document Selected</div>
      </div>
    `
    return
  }

  const treeData = buildTreeDataForDocument(treeDocumentName)

  let html = `
    <div class="tree-view-container">
      <div class="tree-content">
        ${renderTreeNodes(treeData)}
      </div>
    </div>
  `

  listEl.innerHTML = html

  // Restore scroll position after re-rendering (use requestAnimationFrame to ensure DOM is updated)
  requestAnimationFrame(() => {
    listEl.scrollTop = scrollTop
  })
}

function renderTreeNodes(nodes, level = 0) {
  if (!nodes || nodes.length === 0) return ""

  return nodes.map(node => {
    // hasChildren should be true only if there are children with keys other than 'page' and 'value'
    const meaningfulChildren = node.children?.filter(child =>
      child.label !== 'page' && child.label !== 'value'
    ) || []
    const hasChildren = meaningfulChildren.length > 0

    // Check if this is a line_items node or line item child
    const isLineItemsNode = node.label === 'line_items' || node.path?.endsWith('.line_items')
    const isLineItemChild = node.isLineItemChild === true

    if (state.treeExpanded[node.id] === undefined) {
      state.treeExpanded[node.id] = level < 2 || isLineItemsNode
    }

    const expanded = state.treeExpanded[node.id]
    const status = node.status || node.derivedStatus
    const statusClass = status ? `status-${status.toLowerCase()}` : ""

    // Replace duplicate logic with helper
    const badgesHtml = getBadgesHtml(node.path, isLineItemChild, node.validationIndex)

    // Get validation index if this node has a direct validation
    const validationInfo = validationIndexMap.get(node.path)
    const hasValidation = validationInfo !== undefined || isLineItemChild

    // Check if this node corresponds to the active validation
    let isActive = false
    if (hasValidation && state.gridViewValidation) {
      if (isLineItemChild) {
        // For line item children, check by validation index
        const validation = analysisData.validations[node.validationIndex]
        if (validation === state.gridViewValidation) {
          isActive = true
        }
      } else {
        // Compare the validation object
        const validation = analysisData.validations[validationInfo.index]
        if (validation === state.gridViewValidation) {
          isActive = true
        }
      }
    }

    // For line_items node, check if line item table is open
    if (isLineItemsNode && state.lineItemViewOpen) {
      isActive = true
    }

    return `
      <div class="tree-node ${statusClass} ${isLineItemsNode ? 'line-items-node' : ''}"
           style="padding-left: ${level * 10}px"
           data-path="${node.path}"
           ${isLineItemChild ? `data-validation-index="${node.validationIndex}"` : ''}>
        <div class="tree-node-content ${isActive ? 'active' : ''}">
          ${hasChildren
        ? `<button class="tree-toggle ${expanded ? "expanded" : ""}" onclick="toggleTreeNode('${node.id}')">
                 ${icons.chevronRight}
               </button>`
        : ''
      }

          <div class="tree-label-wrapper">
            <div class="tree-label-section" onclick="handleTreeNodeClick(event, '${node.path}', ${isLineItemChild ? node.validationIndex : (validationInfo ? validationInfo.index : 'null')})">
              <span class="tree-icon">
                ${isLineItemsNode ? icons.grid : (isLineItemChild ? icons.file : (hasChildren ? icons.folder : icons.file))}
              </span>
              <span class="tree-label">${escapeHtml(node.label)}</span>
              ${status
        ? `<span class="tree-status-badge ${status.toLowerCase()}">${status}</span>`
        : ""}
              ${badgesHtml}
            </div>
            ${isLineItemsNode
        ? `<div class="tree-actions">
                <button class="tree-view-btn" onclick="event.stopPropagation(); openLineItemTableDirect()" title="View table">
                  ${icons.table}
                </button>
                <button class="tree-view-btn" onclick="event.stopPropagation(); openLineItemTable()" title="View grid with images">
                  ${icons.eye}
                </button>
              </div>`
        : isLineItemChild
          ? `<div class="tree-actions">
                <button class="tree-view-btn" onclick="handleTreeNodeClick(event, '${node.path}', ${node.validationIndex})" title="View comparison">
                  ${icons.eye}
                </button>
              </div>`
          : hasValidation
            ? `<div class="tree-actions">
                  <button class="tree-view-btn" onclick="handleTreeNodeClick(event, '${node.path}', ${validationInfo.index})" title="View comparison">
                    ${icons.eye}
                  </button>
                </div>`
            : ""}
          </div>
        </div>
        ${hasChildren && expanded
        ? `<div class="tree-children">
               ${renderTreeNodes(node.children, level + 1)}
             </div>`
        : ""}
      </div>
    `
  }).join("")
}

// ============ TREE VIEW EVENT HANDLERS ============
// Helper to find node in tree data
function findNodeInTree(nodes, id) {
  if (!nodes) return null
  for (const node of nodes) {
    if (node.id === id) return node
    if (node.children) {
      const found = findNodeInTree(node.children, id)
      if (found) return found
    }
  }
  return null
}

// ============ TREE VIEW EVENT HANDLERS ============
function toggleTreeNode(nodeId) {
  state.treeExpanded[nodeId] = !state.treeExpanded[nodeId]
  const isExpanded = state.treeExpanded[nodeId]

  // Try direct DOM update first to avoid scroll jump
  try {
    // Escape quotes for selector
    const safeId = nodeId.replace(/"/g, '\\"')
    const nodeEl = document.querySelector(`.tree-node[data-path="${safeId}"]`)

    if (nodeEl) {
      // Toggle button icon
      const toggleBtn = nodeEl.querySelector('.tree-toggle')
      if (toggleBtn) {
        if (isExpanded) toggleBtn.classList.add('expanded')
        else toggleBtn.classList.remove('expanded')
      }

      if (isExpanded) {
        // Need to render children
        // Get fresh tree data to ensure we have latest children
        const treeData = buildTreeDataForDocument(treeDocumentName)
        const nodeData = findNodeInTree(treeData, nodeId)

        if (nodeData && nodeData.children && nodeData.children.length > 0) {
          // Calculate level from current padding
          const paddingLeft = parseFloat(nodeEl.style.paddingLeft) || 0
          const currentLevel = paddingLeft / 10

          const childrenHtml = `<div class="tree-children">
                 ${renderTreeNodes(nodeData.children, currentLevel + 1)}
               </div>`

          nodeEl.insertAdjacentHTML('beforeend', childrenHtml)
        }
      } else {
        // Remove children
        const childrenContainer = nodeEl.querySelector('.tree-children')
        if (childrenContainer) {
          childrenContainer.remove()
        }
      }
      return // Success, skip full re-render
    }
  } catch (e) {
    console.warn('Direct tree update failed, falling back to full render', e)
  }

  // Fallback to full render if anything fails
  renderTreeView()
}

function toggleLineItemsExpand() {
  state.lineItemsExpanded = !state.lineItemsExpanded
  renderValidationList()
}

function changeTreeDocument(docName) {
  treeDocumentName = docName
  state.treeExpanded = {}
  renderTreeView()
}

function expandAllTree() {
  const traverse = (nodes) => {
    nodes.forEach(node => {
      state.treeExpanded[node.id] = true
      if (node.children) traverse(node.children)
    })
  }
  traverse(buildTreeDataForDocument(treeDocumentName))
  renderTreeView()
}

function collapseAllTree() {
  state.treeExpanded = {}
  renderTreeView()
}


// Helper to generate badges HTML - extracted to allow real-time updates without re-render
function getBadgesHtml(path, isLineItemChild, validationIndex) {
  if (!path || !treeDocumentName) return ''

  // 1. Verification Badge
  const isVerified = typeof isFieldVerified === 'function' ? isFieldVerified(path) : false
  const verificationBadge = isVerified ? `<span class="verification-pill">Verified</span>` : ''

  // 2. Action Badge
  let actionBadge = ''
  let checkPath = path
  let isOverridden = typeof isFieldOverridden === 'function' ? isFieldOverridden(treeDocumentName, checkPath) : false
  let foundAction = null

  // Debug log for specific path
  // if (path.includes('cargo_summary')) console.log('Checking badge for:', path, 'Overridden:', isOverridden)

  // If not found and path ends with common leaf keys, try parent path
  if (!isOverridden && (checkPath.endsWith('.value') || checkPath.endsWith('.raw_text'))) {
    const parentPath = checkPath.substring(0, checkPath.lastIndexOf('.'))
    isOverridden = typeof isFieldOverridden === 'function' ? isFieldOverridden(treeDocumentName, parentPath) : false
    if (isOverridden) {
      checkPath = parentPath
      // console.log('Found override at parent:', parentPath)
    }
  }

  // For line item children, check overrides using evidence.fieldValues
  if (!isOverridden && isLineItemChild && validationIndex !== undefined) {
    const vIndex = parseInt(validationIndex)
    const lineItemValidation = analysisData?.validations[vIndex]

    // Debug line items
    // console.log('Checking line item child:', path, vIndex, lineItemValidation)

    if (lineItemValidation && lineItemValidation.evidence) {
      for (const ev of lineItemValidation.evidence) {
        if (ev.doc_name !== treeDocumentName) continue

        if (ev.fieldValues && typeof dataOverrides !== 'undefined' && dataOverrides.overrides[treeDocumentName]) {
          for (const fieldKey in ev.fieldValues) {
            const fieldData = ev.fieldValues[fieldKey]
            // Strict check: fieldData.fieldPath must match the current node path logic
            // But wait, path in tree is description based... fieldPath is index based.
            // We need to match based on... what?
            // The tree node for line item child has validationIndex which points to the WHOLE line item validation.
            // But a line item validation has multiple fields (brand, quantity...).
            // We need to know WHICH field this node represents.

            // This logic here iterates ALL fields in the line item validation and checks if ANY is overridden.
            // This means if I edit 'brand', the 'quantity' node will also show 'Edited' if they share the same validationIndex?
            // YES! This is a potential bug. All siblings in the same line item row will show Edited?
            // Or does tree create separate nodes for each field?
            // Tree: line_items -> item 1 -> field nodes?
            // Let's check buildTreeData logic later.

            if (fieldData && fieldData.fieldPath) {
              // ... logic continues ...
              if (typeof isFieldOverridden === 'function' && isFieldOverridden(treeDocumentName, fieldData.fieldPath)) {
                // Compare path with field name (case-insensitive)
                const fieldName = fieldKey
                const lowerPath = path.toLowerCase()
                const lowerName = fieldName.toLowerCase()

                if (lowerPath.endsWith('.' + lowerName) || lowerPath.endsWith('.' + lowerName + '.value')) {
                  isOverridden = true
                  const overrideInfo = typeof getOverrideInfo === 'function' ? getOverrideInfo(treeDocumentName, fieldData.fieldPath) : null
                  if (overrideInfo) {
                    foundAction = overrideInfo.action || 'update'
                    // Break if we found the specific override for this field
                    break
                  }
                }
              }
            }
          }
        }
        if (foundAction) break
      }
    }
  }

  if (isOverridden) {
    let action = foundAction
    if (!action) {
      const overrideInfo = typeof getOverrideInfo === 'function' ? getOverrideInfo(treeDocumentName, checkPath) : null
      if (overrideInfo) {
        action = overrideInfo.action || 'update'
      }
    }
    if (action) {
      let badgeText = 'Edited'
      let badgeClass = 'action-badge-update'

      if (action === 'sync_from_master') {
        badgeText = 'Synced'
        badgeClass = 'action-badge-sync'
      } else if (action === 'restore') {
        badgeText = 'Restored'
        badgeClass = 'action-badge-restore'
      } else if (action === 'update') {
        badgeText = 'Edited'
        badgeClass = 'action-badge-update'
      }

      actionBadge = `<span class="override-badge ${badgeClass}" style="font-size: 0.7rem; padding: 0.125rem 0.375rem;">${badgeText}</span>`
    }
  }

  // Check for hidden documents
  let hiddenBadge = ''
  // For standard fields, checkPath is likely correct.
  // For line item fields, we need to ensure checkPath matches the validation field path.
  // The logic above for finding overrides already attempts to find the correct fieldPath (fieldData.fieldPath).
  // However, we can just check getHiddenDocsForField(checkPath) essentially, or iterate logic similar to override check?

  // Try direct check first (works for normal fields)
  let hiddenDocs = typeof getHiddenDocsForField === 'function' ? getHiddenDocsForField(checkPath) : new Set()

  // For line item children that might have complex paths
  if (validationIndex !== undefined && validationIndex !== null && hiddenDocs.size === 0) {
    // Try to find if any field on this line matches a hidden doc state?
    // Actually, hidden state is per FIELD, so we want the specific field badge.
    // If code above found a matching 'fieldData.fieldPath', we could use that.
    // But 'fieldData' variable scope is limited to the loop.

    // Let's rely on checkPath being correct or the loop logic if needed.
    // If checkPath is accurate (it should be for strict matching), then it works.
  }

  // If we are deeper in line items, checkPath might need adjustment or we trust it.
  // Let's stick to checkPath for now.

  const hiddenCount = hiddenDocs.size
  if (hiddenCount > 0) {
    hiddenBadge = `<span class="hidden-docs-badge" title="${hiddenCount} documents hidden" style="display: inline-flex; align-items: center; gap: 0.25rem; font-size: 0.6rem; color: var(--text-muted); background: var(--bg-hover); padding: 0.1rem 0.3rem; border-radius: 4px;">${icons.eyeOff} ${hiddenCount}</span>`
  }

  return `<span class="tree-node-badges">${actionBadge}${verificationBadge}${hiddenBadge}</span>`
}

// Handle tree node click to set active path and open view
function handleTreeNodeClick(event, path, validationIndex) {
  event.stopPropagation()
  state.activeNodePath = path

  // For line item children or regular validations
  if (validationIndex !== undefined && validationIndex !== null) {
    if (typeof openGridView === 'function') {
      openGridView(validationIndex)
    }
  }

  // Update UI immediately
  updateTreeActiveState()
}

function updateTreeActiveState() {
  const treeNodes = document.querySelectorAll('.tree-node')

  treeNodes.forEach(nodeEl => {
    const nodePath = nodeEl.dataset.path
    const nodeValidationIndex = nodeEl.dataset.validationIndex
    const contentEl = nodeEl.querySelector('.tree-node-content')

    if (!contentEl) return

    // Remove existing active class
    contentEl.classList.remove('active')

    // 1. Check strict path match first (Highest priority)
    if (state.activeNodePath && nodePath === state.activeNodePath) {
      contentEl.classList.add('active')
      return
    }

    // 2. Fallback validation match (Only/If activeNodePath not set, to avoid interference)
    if (!state.activeNodePath && state.gridViewValidation) {
      const validationInfo = validationIndexMap.get(nodePath)

      if (nodeValidationIndex !== undefined) {
        // Line item child - check by validation index
        const validation = analysisData.validations[parseInt(nodeValidationIndex)]
        if (validation === state.gridViewValidation) {
          contentEl.classList.add('active')
        }
      } else if (validationInfo) {
        // Regular validation - check by index
        const validation = analysisData.validations[validationInfo.index]
        if (validation === state.gridViewValidation) {
          contentEl.classList.add('active')
        }
      }
    }

    // Check for line items node
    if (nodeEl.classList.contains('line-items-node') && state.lineItemViewOpen && !state.activeNodePath) {
      contentEl.classList.add('active')
    }
  })
}

function updateTreeBadges() {
  document.querySelectorAll('.tree-node').forEach(nodeEl => {
    const path = nodeEl.dataset.path
    const validationIndex = nodeEl.dataset.validationIndex
    // Determine isLineItemChild based on validationIndex presence or class
    // In renderTreeNodes we added data-validation-index only for isLineItemChild
    const isLineItemChild = validationIndex !== undefined

    const badgesHtml = getBadgesHtml(path, isLineItemChild, validationIndex)

    // Update Badges (Action/Hidden/Verified)
    // Find existing badge container
    let badgeContainer = nodeEl.querySelector('.tree-node-badges')
    if (badgeContainer) {
      badgeContainer.outerHTML = badgesHtml
    } else {
      // Fallback: try to insert into tree-label-section if container not found
      const labelSection = nodeEl.querySelector('.tree-label-section')
      if (labelSection) {
        // Insert before status badge if exists, or at end
        const statusBadge = labelSection.querySelector('.tree-status-badge')
        if (statusBadge) {
          statusBadge.insertAdjacentHTML('afterend', badgesHtml)
        } else {
          labelSection.insertAdjacentHTML('beforeend', badgesHtml)
        }
      }
    }

    // Update Status Badge (PASS/FAIL) - New logic
    let currentStatus = null
    if (validationIndex !== undefined) {
      // Line item child
      const val = analysisData?.validations[parseInt(validationIndex)]
      if (val) currentStatus = val.status
    } else if (path && validationIndexMap && validationIndexMap.has(path)) {
      // Regular node
      const info = validationIndexMap.get(path)
      if (info && info.index !== undefined) {
        const val = analysisData?.validations[info.index]
        if (val) currentStatus = val.status
      }
    }

    if (currentStatus) {
      const statusBadge = nodeEl.querySelector('.tree-status-badge')
      if (statusBadge) {
        // Update text and class
        statusBadge.textContent = currentStatus
        statusBadge.className = `tree-status-badge ${currentStatus.toLowerCase()}`
      }
    }
  })
}

