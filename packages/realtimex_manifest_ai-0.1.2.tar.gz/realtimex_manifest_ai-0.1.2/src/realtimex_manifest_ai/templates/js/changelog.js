// ============ CHANGELOG VIEWER UI ============

let changelogOpen = false

// Toggle changelog viewer
function toggleChangelog() {
  changelogOpen = !changelogOpen
  renderChangelogViewer()
}

// Render changelog viewer
function renderChangelogViewer() {
  let existingViewer = document.getElementById('changelog-viewer')
  let existingToggle = document.getElementById('changelog-toggle')

  // Remove existing elements
  if (existingViewer) {
    existingViewer.remove()
  }
  if (existingToggle) {
    existingToggle.remove()
  }

  if (typeof state !== 'undefined' && state.readOnlyMode) {
    return
  }
  const changelog = getChangelog()

  // Create or update action toolbar (shared with notes)
  let toolbar = document.getElementById('action-toolbar')
  if (!toolbar) {
    toolbar = document.createElement('div')
    toolbar.id = 'action-toolbar'
    toolbar.className = 'action-toolbar'
    document.body.appendChild(toolbar)
  }

  // Add changelog button to toolbar
  let changelogBtn = document.getElementById('action-btn-changelog')
  if (!changelogBtn) {
    changelogBtn = document.createElement('button')
    changelogBtn.id = 'action-btn-changelog'
    changelogBtn.className = 'action-toolbar-btn'
    changelogBtn.setAttribute('data-tooltip', 'Change History')
    changelogBtn.onclick = toggleChangelog
    toolbar.appendChild(changelogBtn)
  }
  changelogBtn.innerHTML = `${icons.clock}`

  // Render viewer if open
  if (changelogOpen) {
    const viewer = document.createElement('div')
    viewer.id = 'changelog-viewer'
    viewer.className = 'changelog-viewer'

    let changelogItemsHtml = ''

    if (changelog.length === 0) {
      changelogItemsHtml = `
        <div class="changelog-empty">
          No changes yet. Edit values in the grid view to track changes.
        </div>
      `
    } else {
      changelogItemsHtml = changelog.map((item) => {
        const originalIndex = item.__index
        const time = new Date(item.timestamp).toLocaleString()

        // Determine action label and badge class
        let actionLabel = 'Updated'
        let actionBadgeClass = 'action-badge-update'
        let itemClass = ''

        switch (item.action) {
          case 'update':
            actionLabel = 'Edited'
            actionBadgeClass = 'action-badge-update'
            break
          case 'sync_from_master':
            actionLabel = 'Synced from Master'
            actionBadgeClass = 'action-badge-sync'
            itemClass = 'sync'
            break
          case 'restore':
            actionLabel = 'Restored'
            actionBadgeClass = 'action-badge-restore'
            itemClass = 'restore'
            break
          case 'revert':
            actionLabel = 'Reverted'
            actionBadgeClass = 'action-badge-revert'
            itemClass = 'revert'
            break
          case 'clear_all':
            actionLabel = 'Cleared All'
            actionBadgeClass = 'action-badge-clear'
            itemClass = 'clear'
            break
          case 'ai_enhancement':
            actionLabel = 'AI Enhanced'
            actionBadgeClass = 'action-badge-update'
            break
          default:
            actionLabel = 'Modified'
            actionBadgeClass = 'action-badge-update'
        }

        const canRestore = item.docName !== 'ALL' && item.fieldPath && item.action !== 'clear_all' && item.newValue !== undefined

        if (item.action === 'clear_all') {
          return `
            <div class="changelog-item ${itemClass}">
              <div class="changelog-item-header">
                <span class="changelog-action-badge ${actionBadgeClass}">${actionLabel}</span>
                <span class="changelog-time">${time}</span>
              </div>
              <div class="changelog-field">All overrides cleared</div>
            </div>
          `
        }

        return `
          <div class="changelog-item ${itemClass}">
            <div class="changelog-item-header">
              <span class="changelog-action-badge ${actionBadgeClass}">${actionLabel}</span>
              <span class="changelog-time">${time}</span>
            </div>
            <div class="changelog-field">${escapeHtml(item.docName)} • ${escapeHtml(item.fieldPath)}</div>
            <div class="changelog-values">
              <div class="changelog-value">
                <span class="changelog-value-label">Old:</span>
                <span class="changelog-value-text">${escapeHtml(String(item.oldValue || '-'))}</span>
              </div>
              <div class="changelog-value">
                <span class="changelog-value-label">New:</span>
                <span class="changelog-value-text">${escapeHtml(String(item.newValue || '-'))}</span>
              </div>
            </div>
            ${canRestore
            ? `<div class="changelog-item-actions">
                   <button class="btn-changelog" onclick="restoreChangelogEntry(${originalIndex})" title="Restore this version">
                     ${icons.rotateLeft}
                     <span>Revert to this</span>
                   </button>
                 </div>`
            : ''}
          </div>
        `
      }).join('')
    }

    viewer.innerHTML = `
      <div class="changelog-header">
        <div class="changelog-title">
          Change history
        </div>
        <button class="btn-close" onclick="toggleChangelog()">${icons.x}</button>
      </div>
      <div class="changelog-body">
        ${changelogItemsHtml}
      </div>
    `

    document.body.appendChild(viewer)
  }
}

// Trigger file input for import
function triggerImportOverrides() {
  const input = document.createElement('input')
  input.type = 'file'
  input.accept = '.json'
  input.onchange = function (e) {
    const file = e.target.files[0]
    if (file) {
      importOverrides(file)
    }
  }
  input.click()
}

// Initialize changelog viewer on page load
function initializeChangelogViewer() {
  renderChangelogViewer()
}

// Update changelog viewer when data changes
function updateChangelogViewer() {
  if (changelogOpen) {
    renderChangelogViewer()
  }
}
