// ============ OVERRIDE MANAGEMENT SYSTEM ============

// Store for data overrides and changelog
const dataOverrides = {
  overrides: {},    // Structure: { "doc_name": { "field_path": { value, timestamp, user } } }
  changelog: [],    // Array of change records
  dismissedAI: {}   // Structure: { "doc_name": { "field_path": true } } - tracks dismissed AI suggestions
}

// Debounce utility for reducing server requests
function debounce(func, delay) {
  let timeoutId
  return function (...args) {
    clearTimeout(timeoutId)
    timeoutId = setTimeout(() => {
      func.apply(this, args)
    }, delay)
  }
}

// Debounced save function - reduces requests by ~90% when editing multiple fields
const debouncedSave = debounce(async function () {
  await saveOverrides()

  // Update UI after save
  if (typeof updateChangelogViewer === 'function') {
    updateChangelogViewer()
  }
  if (typeof updateTreeBadges === 'function') {
    updateTreeBadges()
  }
}, 500)

function isReadOnlyEnvironment() {
  return typeof state !== 'undefined' && state.readOnlyMode
}

// Migrate old overrides to add missing action field
function migrateOverrides(overrides) {
  let migrated = false
  for (const docName in overrides) {
    for (const fieldPath in overrides[docName]) {
      const override = overrides[docName][fieldPath]
      if (!override.action) {
        override.action = 'update'  // Default old overrides to 'update'
        migrated = true
      }
    }
  }
  if (migrated) {
    console.log('[Migration] Added missing action fields to old overrides')
  }
  return overrides
}

// Load overrides from server
async function loadOverrides() {
  if (isReadOnlyEnvironment()) {
    const embedded = window.__embeddedUserData || {}
    dataOverrides.overrides = embedded.overrides || {}
    dataOverrides.changelog = Array.isArray(embedded.changelog) ? embedded.changelog : []
    dataOverrides.dismissedAI = embedded.dismissedAI || {}
    if (typeof updateChangelogViewer === 'function') {
      updateChangelogViewer()
    }
    return
  }
  if (isReadOnlyEnvironment()) {
    dataOverrides.overrides = {}
    dataOverrides.changelog = []
    return
  }

  // Load changelog
  try {
    const batchId = getBatchId()
    const response = await fetch(`/api/changelog?batch_id=${batchId}`)
    if (response.ok) {
      const data = await response.json()
      dataOverrides.changelog = Array.isArray(data) ? data : []
      console.log('Loaded changelog from server:', dataOverrides.changelog.length, 'entries')
      // Update changelog viewer UI after loading
      if (typeof updateChangelogViewer === 'function') {
        updateChangelogViewer()
      }
    } else {
      console.warn('No changelog file found, starting fresh')
      dataOverrides.changelog = []
    }
  } catch (err) {
    console.error('Failed to load changelog from server:', err)
    dataOverrides.changelog = []
  }

  try {
    const batchId = getBatchId()
    const response = await fetch(`/api/overrides?batch_id=${batchId}`)
    if (response.ok) {
      let data = await response.json()
      data = data || {}

      // Migrate old data to add action field
      data = migrateOverrides(data)

      dataOverrides.overrides = data
      console.log('Loaded overrides from server')

      // Save migrated data back to server
      if (Object.keys(data).length > 0) {
        await saveOverrides()
      }
    } else {
      console.warn('No overrides file found, starting fresh')
      dataOverrides.overrides = {}
    }
  } catch (err) {
    console.error('Failed to load overrides from server:', err)
    dataOverrides.overrides = {}
  }

  // Load dismissed AI suggestions
  try {
    const batchId = getBatchId()
    const response = await fetch(`/api/dismissed-ai?batch_id=${batchId}`)
    if (response.ok) {
      const data = await response.json()
      dataOverrides.dismissedAI = data || {}
    } else {
      dataOverrides.dismissedAI = {}
    }
  } catch (err) {
    dataOverrides.dismissedAI = {}
  }
}

// Save overrides to server
async function saveOverrides() {
  if (isReadOnlyEnvironment()) {
    return
  }
  try {
    const batchId = getBatchId()
    const response = await fetch(`/api/overrides?batch_id=${batchId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        overrides: dataOverrides.overrides,
        changelog: dataOverrides.changelog,
        dismissedAI: dataOverrides.dismissedAI
      })
    })

    if (response.ok) {
      const result = await response.json()
      console.log('Saved overrides to server:', result.message)
    } else {
      const error = await response.json()
      console.error('Failed to save overrides:', error.error)
      await showAlertDialog('Failed to save overrides to server. Please check console for details.', {
        title: 'Save Failed',
        type: 'danger'
      })
    }

    // Update changelog viewer if it exists
    if (typeof updateChangelogViewer === 'function') {
      updateChangelogViewer()
    }

    // Update tree badges if function exists
    if (typeof updateTreeBadges === 'function') {
      updateTreeBadges()
    }
  } catch (err) {
    console.error('Failed to save overrides to server:', err)
    await showAlertDialog('Failed to save overrides to server. Make sure the server is running.', {
      title: 'Server Error',
      type: 'danger'
    })
  }
}

// Deep clone utility with structuredClone optimization
function deepClone(obj) {
  if (typeof structuredClone === 'function') {
    try {
      return structuredClone(obj)
    } catch (e) {
      // Fall back to JSON method if structuredClone fails
    }
  }
  return JSON.parse(JSON.stringify(obj))
}

// Apply overrides to a document's data
function applyOverrides(docName, docData) {
  if (!dataOverrides.overrides[docName]) {
    return docData
  }

  // Deep clone to avoid mutating original
  const clonedData = deepClone(docData)

  const docOverrides = dataOverrides.overrides[docName]

  for (const [fieldPath, overrideData] of Object.entries(docOverrides)) {
    setNestedValue(clonedData, fieldPath, overrideData.value)
  }

  return clonedData
}

// Set a nested value in an object using dot notation path
function setNestedValue(obj, path, value) {
  const parts = path.split('.')
  let current = obj

  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i]
    if (!current[part]) {
      current[part] = {}
    }
    current = current[part]
  }

  const lastPart = parts[parts.length - 1]

  // If the target is an object with a 'value' property, update just the value
  if (current[lastPart] && typeof current[lastPart] === 'object' && 'value' in current[lastPart]) {
    current[lastPart].value = value
  } else {
    // Otherwise create/update the entire object
    if (typeof current[lastPart] === 'object' && current[lastPart] !== null) {
      current[lastPart].value = value
    } else {
      current[lastPart] = { value: value }
    }
  }
}

// Get nested value to check if it's overridden
function getNestedValue(obj, path) {
  const parts = path.split('.')
  let current = obj

  for (const part of parts) {
    if (current && typeof current === 'object') {
      current = current[part]
    } else {
      return null
    }
  }

  if (current && typeof current === 'object' && 'value' in current) {
    return current.value
  }
  return current
}

// Check if a field is overridden
function isFieldOverridden(docName, fieldPath) {
  return dataOverrides.overrides[docName] &&
    dataOverrides.overrides[docName][fieldPath] !== undefined
}

// Get override info for a field
function getOverrideInfo(docName, fieldPath) {
  if (!isFieldOverridden(docName, fieldPath)) {
    return null
  }
  return dataOverrides.overrides[docName][fieldPath]
}

// Add or update an override
function addOverride(docName, fieldPath, newValue, originalValue, options = {}) {
  if (isReadOnlyEnvironment()) {
    return
  }
  const action = options.action || 'update'
  const reason = options.reason || null

  // Initialize if needed
  if (!dataOverrides.overrides[docName]) {
    dataOverrides.overrides[docName] = {}
  }

  const timestamp = new Date().toISOString()
  const user = 'User' // Could be enhanced to support user names

  // Store override with action type and reason
  dataOverrides.overrides[docName][fieldPath] = {
    value: newValue,
    originalValue: originalValue,
    timestamp: timestamp,
    user: user,
    action: action,  // Store action: 'update', 'sync_from_master', 'restore', 'ai_enhancement'
    reason: reason   // Store reason (used for AI enhancements)
  }

  // Add to changelog
  dataOverrides.changelog.push({
    docName: docName,
    fieldPath: fieldPath,
    oldValue: originalValue,
    newValue: newValue,
    timestamp: timestamp,
    user: user,
    action: action,
    reason: reason
  })

  // Use debounced save to reduce server requests
  debouncedSave()

  // Re-apply overrides and re-analyze
  reloadDataWithOverrides()
}

async function restoreChangelogEntry(entryIndex) {
  if (isReadOnlyEnvironment()) {
    return
  }
  const entry = dataOverrides.changelog[entryIndex]
  if (!entry || entry.docName === 'ALL' || !entry.fieldPath) {
    await showAlertDialog('This entry cannot be restored.', {
      title: 'Unavailable',
      type: 'danger'
    })
    return
  }

  let targetValue = entry.oldValue
  if (targetValue === undefined) {
    targetValue = entry.newValue
  }

  if (targetValue === undefined) {
    await showAlertDialog('No value available to restore for this entry.', {
      title: 'Unavailable',
      type: 'danger'
    })
    return
  }

  const docName = entry.docName
  const fieldPath = entry.fieldPath

  if (!documents[docName]) {
    await showAlertDialog('Document not found. Unable to restore this entry.', {
      title: 'Document Missing',
      type: 'danger'
    })
    return
  }

  const confirmed = await showConfirmDialog(
    `Revert ${docName}\nField: ${fieldPath}\n\nApply the value from this log entry?`,
    {
      title: 'Restore Value',
      confirmText: 'Apply',
      cancelText: 'Cancel',
      type: 'warning'
    }
  )
  if (!confirmed) {
    return
  }

  const currentOverride = dataOverrides.overrides[docName]?.[fieldPath]
  let currentValue = currentOverride ? currentOverride.value : getNestedValue(documents[docName], fieldPath)
  if (currentValue === undefined || currentValue === null) {
    currentValue = ''
  }

  addOverride(docName, fieldPath, targetValue, currentValue, { action: 'restore' })
}

// Remove an override (revert to original)
function removeOverride(docName, fieldPath) {
  if (isReadOnlyEnvironment()) {
    return
  }
  if (!dataOverrides.overrides[docName] || !dataOverrides.overrides[docName][fieldPath]) {
    return
  }

  const overrideInfo = dataOverrides.overrides[docName][fieldPath]
  const timestamp = new Date().toISOString()

  // Add to changelog
  dataOverrides.changelog.push({
    docName: docName,
    fieldPath: fieldPath,
    oldValue: overrideInfo.value,
    newValue: overrideInfo.originalValue,
    timestamp: timestamp,
    user: 'User',
    action: 'revert'
  })

  // Remove override
  delete dataOverrides.overrides[docName][fieldPath]

  // Clean up empty doc entries
  if (Object.keys(dataOverrides.overrides[docName]).length === 0) {
    delete dataOverrides.overrides[docName]
  }

  // Use debounced save to reduce server requests
  debouncedSave()

  // Re-apply overrides and re-analyze
  reloadDataWithOverrides()
}

// Clear all overrides
async function clearAllOverrides() {
  if (isReadOnlyEnvironment()) {
    return
  }
  const confirmed = await showConfirmDialog('Are you sure you want to clear all overrides? This cannot be undone.', {
    title: 'Clear All Overrides',
    confirmText: 'Clear All',
    cancelText: 'Cancel',
    type: 'danger'
  })
  if (!confirmed) {
    return
  }

  const timestamp = new Date().toISOString()
  dataOverrides.changelog.push({
    docName: 'ALL',
    fieldPath: 'ALL',
    oldValue: null,
    newValue: null,
    timestamp: timestamp,
    user: 'User',
    action: 'clear_all'
  })

  dataOverrides.overrides = {}
  saveOverrides()

  // Update changelog viewer
  if (typeof updateChangelogViewer === 'function') {
    updateChangelogViewer()
  }

  reloadDataWithOverrides()
}

// Export overrides as backup (download current state)
function exportOverrides() {
  if (isReadOnlyEnvironment()) {
    return
  }
  const exportData = {
    overrides: dataOverrides.overrides,
    changelog: dataOverrides.changelog,
    exportDate: new Date().toISOString()
  }

  const dataStr = JSON.stringify(exportData, null, 2)
  const blob = new Blob([dataStr], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = `overrides_backup_${new Date().toISOString().split('T')[0]}.json`
  link.click()
  URL.revokeObjectURL(url)
}

// Import overrides from backup file
async function importOverrides(file) {
  if (isReadOnlyEnvironment()) {
    return
  }
  const reader = new FileReader()
  reader.onload = async function (e) {
    try {
      const imported = JSON.parse(e.target.result)
      if (imported.overrides && imported.changelog) {
        dataOverrides.overrides = imported.overrides
        dataOverrides.changelog = imported.changelog

        // Save to server
        await saveOverrides()

        // Update changelog viewer
        if (typeof updateChangelogViewer === 'function') {
          updateChangelogViewer()
        }

        // Reload and re-analyze
        await reloadDataWithOverrides()
        await showAlertDialog('Overrides imported successfully!', {
          title: 'Import Complete',
          type: 'success',
          confirmText: 'Great'
        })
      } else {
        await showAlertDialog('Invalid override file format.', {
          title: 'Import Failed',
          type: 'danger'
        })
      }
    } catch (err) {
      await showAlertDialog(`Failed to import overrides: ${err.message}`, {
        title: 'Import Failed',
        type: 'danger'
      })
    }
  }
  reader.readAsText(file)
}

// Reload all documents with overrides applied
async function reloadDataWithOverrides() {
  if (isReadOnlyEnvironment()) {
    return
  }
  try {
    // Add timestamp to prevent browser caching
    const cacheBuster = `?t=${Date.now()}`

    // Get batch base path from state (set by loadData)
    const basePath = state.batchBasePath || '..'

    // Re-fetch original data
    const regResp = await fetch(`${basePath}/registry.json${cacheBuster}`)
    const regData = await regResp.json()

    // Clear and reload registry
    for (const key in registry) {
      delete registry[key]
    }
    regData.registry.forEach((doc) => {
      registry[doc.doc_name] = doc
    })

    // Clear and reload documents with overrides
    for (const key in documents) {
      delete documents[key]
    }

    for (const doc of regData.registry) {
      const resp = await fetch(`${basePath}/data/${doc.doc_name}.json${cacheBuster}`)
      const originalData = await resp.json()
      // Apply overrides to the data
      documents[doc.doc_name] = applyOverrides(doc.doc_name, originalData)
    }

    state.documentFieldCache = {}

    // Re-run analysis
    performAnalysis()

    // Re-apply hidden documents filter (recalculate status)
    if (state.hiddenDocsPerField && typeof recalculateValidationStatus === 'function') {
      Object.keys(state.hiddenDocsPerField).forEach(fieldPath => {
        recalculateValidationStatus(fieldPath)
      })
    }

    render()
  } catch (err) {
    console.error("Failed to reload data with overrides:", err)
  }
}

// Get changelog entries
function getChangelog() {
  return dataOverrides.changelog
    .map((entry, index) => ({ ...entry, __index: index }))
    .reverse() // Most recent first
}

// Initialize overrides system
async function initializeOverrides() {
  await loadOverrides()
  // Load hidden docs state
  if (typeof loadHiddenDocs === 'function') {
    await loadHiddenDocs()
  }
}

window.restoreChangelogEntry = restoreChangelogEntry
