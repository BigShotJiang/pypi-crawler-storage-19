// ============ STATE ============
let analysisData = null
const registry = {}
const documents = {}
let totalPages = 0

const state = {
  activeTab: "documents",
  expandedCards: {},
  searchQuery: "",
  filterStatus: "all", // "all", "verified", "unverified"
  viewerOpen: false,
  gridViewOpen: false,
  lineItemViewOpen: false,
  lineItemTableMode: false, // Toggle between grid and table view for line items
  lineItemsExpanded: false, // Track if line items are expanded in validation list
  tableFullscreen: false,
  previousView: null, // Can be 'grid' or 'line-item-table'
  gridViewValidation: null,
  enabledDocuments: new Set(), // Track which documents are included in comparison
  hiddenDocsPerField: {}, // Track hidden documents per field_path: { 'field_path': Set(['doc1', 'doc2']) }
  selectedEvidence: null,
  currentPage: 0,
  zoom: 1,
  treeExpanded: {},
  descriptionExpanded: {},
  mobileSummaryActive: false, // Mobile landing shows summary dashboard
  documentFieldHighlight: null,
  documentFieldCache: {},
  documentViewerSource: null,
  documentViewerDocName: null,
  pendingDocumentViewerDocName: null,
  expandedLineItems: {},
  documentFieldScrollTop: 0,
  documentFieldPanelCollapsed: false,
  readOnlyMode: false,
}

let treeDocumentName = null
let validationIndexMap = new Map()
let lineItemTableData = null

if (typeof window !== 'undefined') {
  state.readOnlyMode = Boolean(window.__DOCUMENT_EXPORT_MODE)
}
