// ============ CONSTANTS & HELPERS ============

const CANVAS_COLORS = {
  MASTER: { stroke: '#3b82f6', fill: 'rgba(59, 130, 246, 0.15)' },
  MATCH: { stroke: '#22c55e', fill: 'rgba(34, 197, 94, 0.07)' },
  MISMATCH: { stroke: '#ef4444', fill: 'rgba(239, 68, 68, 0.07)' },
  INCONSISTENT: { stroke: '#ef4444', fill: 'rgba(239, 68, 68, 0.07)' },
  CONSISTENT: { stroke: '#22c55e', fill: 'rgba(34, 197, 94, 0.07)' },
  GROUP: { stroke: '#f97316', fill: 'rgba(249, 115, 22, 0.12)' }
}

// Canvas constants (extracted magic numbers for maintainability)
const CANVAS_CONFIG = Object.freeze({
  LABEL: Object.freeze({
    FONT: 'bold 12px sans-serif',
    HEIGHT: 18,
    PADDING: 8,
    Y_OFFSET: 18
  }),
  CORNER_SIZE: 10,
  LINE_WIDTH: 2,
  ERROR_PLACEHOLDER: Object.freeze({
    BACKGROUND: '#f8fafc',
    TEXT_COLOR: '#94a3b8',
    FONT: '14px sans-serif',
    PADDING: 20
  })
})

// Canvas caching system for performance optimization
const canvasCache = {
  rendered: new Map(),  // Track what's been rendered (canvasId -> cacheKey)
  images: new Map()     // Cache loaded images (url -> Image)
}

// Generate cache key for canvas state
function getCanvasCacheKey(pageIndex, evidenceId, highlightId, annotationCount) {
  return `${pageIndex}_${evidenceId || 'none'}_${highlightId || 'none'}_${annotationCount || 0}`
}

// Clear canvas cache (call when state changes significantly)
function clearCanvasCache() {
  canvasCache.rendered.clear()
}

// Flag to skip auto-scroll during annotation operations (global for cross-file access)
window.skipAutoScroll = false

function getImageBasePath() {
  // First check for explicit imageBasePath override
  if (typeof window !== 'undefined' && typeof window.imageBasePath === 'string' && window.imageBasePath.length > 0) {
    return window.imageBasePath.endsWith('/') ? window.imageBasePath : `${window.imageBasePath}/`
  }
  // Use batch base path from state if available
  if (typeof state !== 'undefined' && state.batchBasePath) {
    return `${state.batchBasePath}/images/`
  }
  // Fallback to legacy path
  return '../images/'
}

// Get image URL - supports both file paths and embedded base64
function getImageUrl(pageIndex) {
  // Check for embedded base64 images (export mode)
  if (typeof window !== 'undefined' && window.__embeddedImages) {
    const key = `page_${pageIndex}.png`
    if (window.__embeddedImages[key]) {
      return window.__embeddedImages[key]
    }
  }
  // Use regular path
  return `${getImageBasePath()}page_${pageIndex}.png`
}

function shouldUseCrossOrigin(url) {
  return /^https?:/i.test(url)
}

function getStyleForStatus(status) {
  if (status === 'master') return CANVAS_COLORS.MASTER
  if (status === 'match' || status === 'PASS') return CANVAS_COLORS.MATCH
  return CANVAS_COLORS.MISMATCH
}

function getStyleForFieldBox(fieldBox) {
  if (fieldBox.groupHighlight) return CANVAS_COLORS.GROUP
  return fieldBox.isInconsistent ? CANVAS_COLORS.INCONSISTENT : CANVAS_COLORS.CONSISTENT
}

/**
 * Draws a bounding box with style and optional label
 * Use normalized coordinates relative to the canvas size? 
 * No, this function expects absolute coordinates on the target canvas.
 */
function drawBoxOnCanvas(ctx, x, y, w, h, style, label = null) {
  // Fill
  ctx.fillStyle = style.fill
  ctx.fillRect(x, y, w, h)

  // Border
  ctx.strokeStyle = style.stroke
  ctx.lineWidth = CANVAS_CONFIG.LINE_WIDTH
  ctx.strokeRect(x, y, w, h)

  // Label
  if (label) {
    ctx.font = CANVAS_CONFIG.LABEL.FONT
    const textWidth = ctx.measureText(label).width

    ctx.fillStyle = style.stroke
    ctx.fillRect(x, y - CANVAS_CONFIG.LABEL.HEIGHT, textWidth + CANVAS_CONFIG.LABEL.PADDING, CANVAS_CONFIG.LABEL.HEIGHT)

    ctx.fillStyle = '#fff'
    ctx.fillText(label, x + 4, y - 5)
  }
}

/**
 * Draws corner accents for the selected box
 */
function drawCornerAccents(ctx, x, y, w, h, color) {
  const cornerSize = CANVAS_CONFIG.CORNER_SIZE
  ctx.fillStyle = color

  // Top-left
  ctx.fillRect(x - 2, y - 2, cornerSize, 4)
  ctx.fillRect(x - 2, y - 2, 4, cornerSize)

  // Top-right
  ctx.fillRect(x + w - cornerSize + 2, y - 2, cornerSize, 4)
  ctx.fillRect(x + w - 2, y - 2, 4, cornerSize)

  // Bottom-left
  ctx.fillRect(x - 2, y + h - 2, cornerSize, 4)
  ctx.fillRect(x - 2, y + h - cornerSize + 2, 4, cornerSize)

  // Bottom-right
  ctx.fillRect(x + w - cornerSize + 2, y + h - 2, cornerSize, 4)
  ctx.fillRect(x + w - 2, y + h - cornerSize + 2, 4, cornerSize)
}

function getBoxCoords(box, imgWidth, imgHeight) {
  if (!box || box.length < 4) return null
  const x1 = Math.min(...box.map(p => p.x)) * imgWidth
  const y1 = Math.min(...box.map(p => p.y)) * imgHeight
  const x2 = Math.max(...box.map(p => p.x)) * imgWidth
  const y2 = Math.max(...box.map(p => p.y)) * imgHeight
  return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 }
}

function drawErrorPlaceholder(canvas, ctx, width, height, message) {
  canvas.width = width
  canvas.height = height
  ctx.fillStyle = CANVAS_CONFIG.ERROR_PLACEHOLDER.BACKGROUND
  ctx.fillRect(0, 0, width, height)

  ctx.fillStyle = CANVAS_CONFIG.ERROR_PLACEHOLDER.TEXT_COLOR
  ctx.font = CANVAS_CONFIG.ERROR_PLACEHOLDER.FONT
  // Draw text
  ctx.fillText(message, CANVAS_CONFIG.ERROR_PLACEHOLDER.PADDING, height / 2)
}

// ============ MAIN FUNCTIONS ============

// Draw all overlays on canvas (bounding boxes, annotations, etc.)
function drawCanvasOverlays(canvas, ctx, img, pageIndex) {
  // Draw bounding box if selected evidence or field highlight is on this page
  const activeHighlight = state.documentFieldHighlight || state.selectedEvidence
  if (activeHighlight) {
    const multiPageBoxes = activeHighlight.multiPageFieldBoxes
    if (multiPageBoxes && multiPageBoxes[pageIndex]) {
      multiPageBoxes[pageIndex].forEach(fieldBox => {
        const coords = getBoxCoords(fieldBox.bounding_box, img.width, img.height)
        if (!coords) return
        const style = getStyleForFieldBox(fieldBox)
        const label = fieldBox.label || fieldBox.field
        drawBoxOnCanvas(ctx, coords.x, coords.y, coords.w, coords.h, style, label)
      })
    } else if (activeHighlight.pageIndex === pageIndex) {
      const { fieldBoxes, boundingBox, cardStatus } = activeHighlight
      if (fieldBoxes && fieldBoxes.length > 0) {
        fieldBoxes.forEach(fieldBox => {
          const coords = getBoxCoords(fieldBox.bounding_box, img.width, img.height)
          if (!coords) return
          const style = getStyleForFieldBox(fieldBox)
          const label = fieldBox.label || fieldBox.field
          drawBoxOnCanvas(ctx, coords.x, coords.y, coords.w, coords.h, style, label)
        })
      } else if (boundingBox && boundingBox.length >= 4) {
        const coords = getBoxCoords(boundingBox, img.width, img.height)
        if (coords) {
          const style = getStyleForStatus(cardStatus)
          drawBoxOnCanvas(ctx, coords.x, coords.y, coords.w, coords.h, style)
          drawCornerAccents(ctx, coords.x, coords.y, coords.w, coords.h, style.stroke)
        }
      }
    }
  }

  // Draw note annotations for this page
  if (typeof getAnnotationsForPage === 'function') {
    const annotations = getAnnotationsForPage(pageIndex)
    annotations.forEach(annotation => {
      if (annotation.boundingBox && annotation.boundingBox.length >= 4) {
        const coords = getBoxCoords(annotation.boundingBox, img.width, img.height)
        if (coords) {
          let style
          switch (annotation.type) {
            case 'issue':
              style = { stroke: '#ef4444', fill: 'rgba(239, 68, 68, 0.15)' }
              break
            case 'question':
              style = { stroke: '#f59e0b', fill: 'rgba(245, 158, 11, 0.15)' }
              break
            default:
              style = { stroke: '#3b82f6', fill: 'rgba(59, 130, 246, 0.15)' }
          }

          const label = `${annotation.fieldName || 'Note'}`
          drawBoxOnCanvas(ctx, coords.x, coords.y, coords.w, coords.h, style, label)

          // Draw note text if present
          if (annotation.text) {
            const fontSize = 14
            const padding = 6
            const maxWidth = Math.max(coords.w, 200)
            ctx.font = `${fontSize}px sans-serif`

            const words = annotation.text.split(' ')
            const lines = []
            let currentLine = ''

            words.forEach(word => {
              const testLine = currentLine ? currentLine + ' ' + word : word
              if (ctx.measureText(testLine).width > maxWidth - padding * 2) {
                if (currentLine) lines.push(currentLine)
                currentLine = word
              } else {
                currentLine = testLine
              }
            })
            if (currentLine) lines.push(currentLine)

            const displayLines = lines.slice(0, 3)
            if (lines.length > 3) displayLines[2] += '...'

            const textHeight = displayLines.length * (fontSize + 2) + padding * 2
            const textWidth = Math.min(maxWidth, Math.max(...displayLines.map(l => ctx.measureText(l).width)) + padding * 2)

            ctx.fillStyle = style.stroke
            ctx.globalAlpha = 0.9
            ctx.fillRect(coords.x, coords.y + coords.h + 2, textWidth, textHeight)
            ctx.globalAlpha = 1

            ctx.fillStyle = '#ffffff'
            displayLines.forEach((line, i) => {
              ctx.fillText(line, coords.x + padding, coords.y + coords.h + 2 + padding + (i + 1) * (fontSize + 2) - 4)
            })
          }
        }
      }
    })
  }
}

function drawAllPages() {
  const canvases = document.querySelectorAll(".page-canvas")
  if (canvases.length === 0) return

  canvases.forEach(canvas => {
    const pageIndex = parseInt(canvas.dataset.page)
    const ctx = canvas.getContext("2d")
    const imageUrl = getImageUrl(pageIndex)

    // Check if image is already cached
    let img = canvasCache.images.get(imageUrl)

    if (img && img.complete && img.naturalWidth > 0) {
      // Use cached image - immediate draw
      canvas.width = img.width
      canvas.height = img.height
      ctx.drawImage(img, 0, 0)
      drawCanvasOverlays(canvas, ctx, img, pageIndex)
    } else {
      // Load image and cache it
      img = new Image()
      if (shouldUseCrossOrigin(imageUrl)) {
        img.crossOrigin = "anonymous"
      }

      img.onload = () => {
        canvasCache.images.set(imageUrl, img)  // Cache loaded image
        canvas.width = img.width
        canvas.height = img.height
        ctx.drawImage(img, 0, 0)
        drawCanvasOverlays(canvas, ctx, img, pageIndex)
      }

      img.onerror = () => {
        drawErrorPlaceholder(canvas, ctx, 600, 800, `Page ${pageIndex + 1} image not found`)
      }

      img.src = imageUrl
    }
  })

  // Scroll to active page
  // Auto-scroll to active evidence (skip if flag is set or in free annotation mode)
  setTimeout(() => {
    // Skip scroll if flag is set or in free annotation mode
    if (window.skipAutoScroll) return
    const inFreeAnnotationMode = typeof isFreeAnnotationMode === 'function' && isFreeAnnotationMode()
    if (inFreeAnnotationMode) return // Don't auto-scroll during annotation drawing

    const scrollTarget = state.documentFieldHighlight || state.selectedEvidence
    if (scrollTarget && scrollTarget.pageIndex !== undefined) {
      const activeCanvas = document.getElementById(`page-canvas-${scrollTarget.pageIndex}`)
      if (activeCanvas) {
        activeCanvas.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }
    }
  }, 300)

  // Initialize zoom handlers for all page canvases
  setTimeout(() => {
    initCanvasZoom()
  }, 100)
}

function drawCroppedCanvases() {
  const canvases = document.querySelectorAll(".cropped-canvas")

  canvases.forEach((canvas) => {
    const boundingBox = JSON.parse(canvas.dataset.box || '[]')
    const ctx = canvas.getContext("2d")

    // Parse extra data
    const isMultiBox = canvas.classList.contains('multi-box-canvas')
    let fieldBoxes = []
    try {
      fieldBoxes = JSON.parse(canvas.dataset.fieldBoxes || '[]')
    } catch (e) { fieldBoxes = [] }

    // Status/Type for single box
    const cardType = canvas.dataset.cardType
    const status = canvas.dataset.status || "FAIL"

    if (!boundingBox || boundingBox.length < 4) {
      drawErrorPlaceholder(canvas, ctx, 300, 150, boundingBox ? "Invalid bounding box" : "No bounding box data")
      return
    }

    const img = new Image()

    img.onload = () => {
      // Calculate crop metrics
      const padding = 0.05
      const minX = Math.max(0, Math.min(...boundingBox.map((p) => p.x)) - padding)
      const maxX = Math.min(1, Math.max(...boundingBox.map((p) => p.x)) + padding)
      const minY = Math.max(0, Math.min(...boundingBox.map((p) => p.y)) - padding)
      const maxY = Math.min(1, Math.max(...boundingBox.map((p) => p.y)) + padding)

      const cropWidth = (maxX - minX) * img.width
      const cropHeight = (maxY - minY) * img.height

      // Scale canvas dimensions for display
      let displayWidth = cropWidth
      let displayHeight = cropHeight
      const maxCanvasWidth = isMultiBox ? 500 : 400
      const maxCanvasHeight = isMultiBox ? 400 : 300

      if (displayWidth > maxCanvasWidth) {
        const ratio = maxCanvasWidth / displayWidth
        displayWidth = maxCanvasWidth
        displayHeight = cropHeight * ratio
      }
      if (displayHeight > maxCanvasHeight) {
        const ratio = maxCanvasHeight / displayHeight
        displayHeight = maxCanvasHeight
        displayWidth = displayWidth * ratio
      }

      // Use devicePixelRatio for sharp rendering on HiDPI/Retina displays
      const dpr = window.devicePixelRatio || 1

      // Set actual canvas buffer size (higher resolution)
      canvas.width = displayWidth * dpr
      canvas.height = displayHeight * dpr

      // Set display size via CSS
      canvas.style.width = `${displayWidth}px`
      canvas.style.height = `${displayHeight}px`

      // Scale context to match DPR
      ctx.scale(dpr, dpr)

      // Enable image smoothing for better quality
      ctx.imageSmoothingEnabled = true
      ctx.imageSmoothingQuality = 'high'

      // Draw the image at display coordinates (context is scaled)
      const cropX = minX * img.width
      const cropY = minY * img.height
      ctx.drawImage(img, cropX, cropY, cropWidth, cropHeight, 0, 0, displayWidth, displayHeight)

      // Helper to transform normalized coordinate to display coordinate
      const transformX = (x) => ((x - minX) / (maxX - minX)) * displayWidth
      const transformY = (y) => ((y - minY) / (maxY - minY)) * displayHeight

      const getTransformedRect = (box) => {
        const bx = Math.min(...box.map(p => p.x))
        const by = Math.min(...box.map(p => p.y))
        const bMaxX = Math.max(...box.map(p => p.x))
        const bMaxY = Math.max(...box.map(p => p.y))

        const x = transformX(bx)
        const y = transformY(by)
        const w = transformX(bMaxX) - x
        const h = transformY(bMaxY) - y
        return { x, y, w, h }
      }

      if (isMultiBox && fieldBoxes.length > 0) {
        // Draw multiple boxes
        fieldBoxes.forEach(fieldBox => {
          if (!fieldBox.bounding_box) return
          const rect = getTransformedRect(fieldBox.bounding_box)
          const style = getStyleForFieldBox(fieldBox)
          const label = fieldBox.label || fieldBox.field

          // Use smaller font for cropped label? Or same?
          // Original used 10px. drawBoxOnCanvas uses 12px. 
          // I'll inline a slight modification or just use drawBoxOnCanvas as is (it's consistent)
          // But actually drawBoxOnCanvas uses bold 12px.
          // To be exactly same as before I might need to parametrise font size.
          // However, consistency is better. I'll use the shared function.

          drawBoxOnCanvas(ctx, rect.x, rect.y, rect.w, rect.h, style, label)
        })
      } else {
        // Draw single box
        const rect = getTransformedRect(boundingBox)
        let style

        if (cardType) {
          style = getStyleForStatus(cardType)
        } else {
          style = getStyleForStatus(status)
        }

        drawBoxOnCanvas(ctx, rect.x, rect.y, rect.w, rect.h, style)
      }
    }

    img.onerror = () => {
      drawErrorPlaceholder(canvas, ctx, 300, 150, "Image not found")
    }

    // Parse page index safely
    const pageIdx = Number.parseInt(canvas.dataset.page)
    const targetUrl = getImageUrl(isNaN(pageIdx) ? 0 : pageIdx)
    if (shouldUseCrossOrigin(targetUrl)) {
      img.crossOrigin = "anonymous"
    }
    img.src = targetUrl
  })

  // Initialize zoom handlers for cropped canvases
  setTimeout(() => {
    initCroppedCanvasZoom()
  }, 100)
}

// ============ VIEWER EVENT HANDLERS ============

// ============ PAGE CANVAS ZOOM & PAN ============
// Uses state.zoom, state.panX, state.panY from viewer.js

// Track drag state for document viewer
const pageCanvasDragState = {
  isDragging: false,
  dragEnabled: false,  // Set true after long press
  startX: 0,
  startY: 0,
  initialPanX: 0,
  initialPanY: 0,
  clickStartTime: 0,
  clickStartX: 0,
  clickStartY: 0,
  longPressTimer: null
}

const LONG_PRESS_DURATION = 200 // ms to hold before drag mode activates

// Free annotation drawing state
let freeAnnotationDrawState = {
  isDrawing: false,
  startX: 0,
  startY: 0,
  currentX: 0,
  currentY: 0,
  canvas: null,
  pageIndex: 0
}

function updatePageCanvasCursor() {
  const canvases = document.querySelectorAll('.page-canvas')
  let cursor = 'zoom-in'

  // Check if in free annotation mode
  if (typeof isFreeAnnotationMode === 'function' && isFreeAnnotationMode()) {
    cursor = 'crosshair'
  } else if (pageCanvasDragState.isDragging) {
    cursor = 'grabbing'
  } else if (pageCanvasDragState.dragEnabled) {
    cursor = 'grab'
  }

  canvases.forEach(canvas => {
    canvas.style.cursor = cursor
  })
}

// Draw preview rectangle while user is drawing free annotation
function drawFreeAnnotationPreview(canvas) {
  if (!freeAnnotationDrawState.isDrawing) return

  const ctx = canvas.getContext('2d')

  // Save canvas state and reload the base image, then draw selection
  const pageIndex = parseInt(canvas.dataset.page) || 0
  const imageUrl = getImageUrl(pageIndex)

  // Load image and redraw with selection overlay
  const img = new Image()
  if (shouldUseCrossOrigin(imageUrl)) {
    img.crossOrigin = "anonymous"
  }

  img.onload = () => {
    // Redraw the original image
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.drawImage(img, 0, 0)

    // Draw selection rectangle
    const x = Math.min(freeAnnotationDrawState.startX, freeAnnotationDrawState.currentX)
    const y = Math.min(freeAnnotationDrawState.startY, freeAnnotationDrawState.currentY)
    const w = Math.abs(freeAnnotationDrawState.currentX - freeAnnotationDrawState.startX)
    const h = Math.abs(freeAnnotationDrawState.currentY - freeAnnotationDrawState.startY)

    // Blue dashed border
    ctx.strokeStyle = '#3b82f6'
    ctx.lineWidth = 3
    ctx.setLineDash([8, 4])
    ctx.strokeRect(x, y, w, h)
    ctx.setLineDash([])

    // Semi-transparent blue fill
    ctx.fillStyle = 'rgba(59, 130, 246, 0.15)'
    ctx.fillRect(x, y, w, h)

    // Draw corner handles
    const handleSize = 8
    ctx.fillStyle = '#3b82f6'
    ctx.fillRect(x - handleSize / 2, y - handleSize / 2, handleSize, handleSize)
    ctx.fillRect(x + w - handleSize / 2, y - handleSize / 2, handleSize, handleSize)
    ctx.fillRect(x - handleSize / 2, y + h - handleSize / 2, handleSize, handleSize)
    ctx.fillRect(x + w - handleSize / 2, y + h - handleSize / 2, handleSize, handleSize)

    // Draw label showing "Drawing..." at top of selection
    if (w > 50 && h > 30) {
      const labelText = '📝 Release to create annotation'
      ctx.font = 'bold 14px system-ui, sans-serif'
      const textWidth = ctx.measureText(labelText).width
      const labelX = x + (w - textWidth) / 2
      const labelY = y - 10

      // Label background
      ctx.fillStyle = '#3b82f6'
      ctx.fillRect(labelX - 8, labelY - 16, textWidth + 16, 22)

      // Label text
      ctx.fillStyle = '#ffffff'
      ctx.fillText(labelText, labelX, labelY)
    }
  }

  img.src = imageUrl
}

function updateCanvasWrapperTransform() {
  const wrapper = document.querySelector('.canvas-wrapper')
  if (wrapper) {
    wrapper.style.transform = `translate(${state.panX || 0}px, ${state.panY || 0}px) scale(${state.zoom})`
  }
  updatePageCanvasCursor()
}

function initCanvasZoom() {
  const canvases = document.querySelectorAll('.page-canvas')
  const viewerCanvas = document.querySelector('.document-viewer-canvas')

  if (!viewerCanvas) return

  // Set initial cursor
  updatePageCanvasCursor()

  // No wheel zoom - let scroll work normally

  canvases.forEach((canvas, canvasIndex) => {
    // Store page index on canvas element for reference
    canvas.dataset.pageIndex = canvasIndex

    // Mouse down to start long press detection
    canvas.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return // Only left mouse button

      // Handle free annotation mode - start drawing bounding box
      if (typeof isFreeAnnotationMode === 'function' && isFreeAnnotationMode()) {
        e.preventDefault()
        const rect = canvas.getBoundingClientRect()
        // Account for canvas display scaling
        const scaleX = canvas.width / rect.width
        const scaleY = canvas.height / rect.height
        freeAnnotationDrawState.isDrawing = true
        freeAnnotationDrawState.startX = (e.clientX - rect.left) * scaleX
        freeAnnotationDrawState.startY = (e.clientY - rect.top) * scaleY
        freeAnnotationDrawState.currentX = freeAnnotationDrawState.startX
        freeAnnotationDrawState.currentY = freeAnnotationDrawState.startY
        freeAnnotationDrawState.canvas = canvas
        // Use global page index from data-page attribute (set in render.js)
        freeAnnotationDrawState.pageIndex = parseInt(canvas.dataset.page) || 0

        // Hide notes panel during drawing
        const notesPanel = document.querySelector('.notes-panel')
        if (notesPanel) {
          notesPanel.classList.add('drawing-hidden')
        }
        return
      }

      pageCanvasDragState.clickStartTime = Date.now()
      pageCanvasDragState.clickStartX = e.clientX
      pageCanvasDragState.clickStartY = e.clientY
      pageCanvasDragState.dragEnabled = false

      // Start long press timer
      pageCanvasDragState.longPressTimer = setTimeout(() => {
        // Long press detected - enable drag mode
        pageCanvasDragState.dragEnabled = true
        pageCanvasDragState.isDragging = true
        pageCanvasDragState.startX = e.clientX
        pageCanvasDragState.startY = e.clientY
        pageCanvasDragState.initialPanX = state.panX || 0
        pageCanvasDragState.initialPanY = state.panY || 0
        updatePageCanvasCursor()
      }, LONG_PRESS_DURATION)
    })

    canvas.addEventListener('mousemove', (e) => {
      // Handle free annotation drawing
      if (freeAnnotationDrawState.isDrawing && freeAnnotationDrawState.canvas === canvas) {
        e.preventDefault()
        const rect = canvas.getBoundingClientRect()
        // Account for canvas display scaling
        const scaleX = canvas.width / rect.width
        const scaleY = canvas.height / rect.height
        freeAnnotationDrawState.currentX = (e.clientX - rect.left) * scaleX
        freeAnnotationDrawState.currentY = (e.clientY - rect.top) * scaleY

        // Redraw canvas with selection rectangle
        drawFreeAnnotationPreview(canvas)
        return
      }

      // If moved too much before long press, cancel it
      if (pageCanvasDragState.longPressTimer) {
        const distX = Math.abs(e.clientX - pageCanvasDragState.clickStartX)
        const distY = Math.abs(e.clientY - pageCanvasDragState.clickStartY)
        if (distX > 5 || distY > 5) {
          clearTimeout(pageCanvasDragState.longPressTimer)
          pageCanvasDragState.longPressTimer = null
        }
      }

      if (!pageCanvasDragState.isDragging) return

      e.preventDefault()
      const deltaX = e.clientX - pageCanvasDragState.startX
      const deltaY = e.clientY - pageCanvasDragState.startY
      state.panX = pageCanvasDragState.initialPanX + deltaX
      state.panY = pageCanvasDragState.initialPanY + deltaY
      updateCanvasWrapperTransform()
    })

    canvas.addEventListener('mouseup', (e) => {
      // Handle free annotation drawing completion
      if (freeAnnotationDrawState.isDrawing && freeAnnotationDrawState.canvas === canvas) {
        e.preventDefault()
        const rect = canvas.getBoundingClientRect()
        // Account for canvas display scaling
        const scaleX = canvas.width / rect.width
        const scaleY = canvas.height / rect.height
        freeAnnotationDrawState.currentX = (e.clientX - rect.left) * scaleX
        freeAnnotationDrawState.currentY = (e.clientY - rect.top) * scaleY

        // Calculate normalized bounding box (0-1 range)
        const x1 = Math.min(freeAnnotationDrawState.startX, freeAnnotationDrawState.currentX) / canvas.width
        const y1 = Math.min(freeAnnotationDrawState.startY, freeAnnotationDrawState.currentY) / canvas.height
        const x2 = Math.max(freeAnnotationDrawState.startX, freeAnnotationDrawState.currentX) / canvas.width
        const y2 = Math.max(freeAnnotationDrawState.startY, freeAnnotationDrawState.currentY) / canvas.height

        // Only create annotation if box is big enough
        const minSize = 0.01 // 1% of canvas
        if (Math.abs(x2 - x1) > minSize && Math.abs(y2 - y1) > minSize) {
          const boundingBox = [
            { x: x1, y: y1 },
            { x: x2, y: y1 },
            { x: x2, y: y2 },
            { x: x1, y: y2 }
          ]

          if (typeof completeFreeAnnotation === 'function') {
            completeFreeAnnotation(freeAnnotationDrawState.pageIndex, boundingBox)
          }
        }

        // Reset drawing state
        freeAnnotationDrawState.isDrawing = false
        freeAnnotationDrawState.canvas = null

        // Show notes panel again after drawing
        const notesPanel = document.querySelector('.notes-panel')
        if (notesPanel) {
          notesPanel.classList.remove('drawing-hidden')
        }

        // Redraw canvas to remove preview
        if (typeof drawAllPages === 'function') {
          drawAllPages()
        }
        return
      }

      // Clear long press timer
      if (pageCanvasDragState.longPressTimer) {
        clearTimeout(pageCanvasDragState.longPressTimer)
        pageCanvasDragState.longPressTimer = null
      }

      const wasDragging = pageCanvasDragState.isDragging
      pageCanvasDragState.isDragging = false
      pageCanvasDragState.dragEnabled = false

      // Check if this was a short click (not a drag or long press)
      const timeDiff = Date.now() - pageCanvasDragState.clickStartTime
      const distX = Math.abs(e.clientX - pageCanvasDragState.clickStartX)
      const distY = Math.abs(e.clientY - pageCanvasDragState.clickStartY)
      const isClick = timeDiff < LONG_PRESS_DURATION && distX < 5 && distY < 5

      if (isClick && !wasDragging && e.button === 0) {
        // Zoom in on click - but not in free annotation mode
        if (typeof zoomIn === 'function' && !(typeof isFreeAnnotationMode === 'function' && isFreeAnnotationMode())) {
          zoomIn()
        }
      }

      updatePageCanvasCursor()
    })

    canvas.addEventListener('mouseleave', () => {
      if (pageCanvasDragState.longPressTimer) {
        clearTimeout(pageCanvasDragState.longPressTimer)
        pageCanvasDragState.longPressTimer = null
      }
      if (pageCanvasDragState.isDragging) {
        pageCanvasDragState.isDragging = false
        pageCanvasDragState.dragEnabled = false
        updatePageCanvasCursor()
      }
    })

    // Right click to zoom out
    canvas.addEventListener('contextmenu', (e) => {
      e.preventDefault()
      if (typeof zoomOut === 'function') {
        zoomOut()
      }
    })

    // Double click to reset zoom
    canvas.addEventListener('dblclick', (e) => {
      e.preventDefault()
      if (typeof resetZoom === 'function') {
        resetZoom()
      }
    })

    // Magnifier on hover (only when not zoomed and not in free annotation mode)
    canvas.addEventListener('mousemove', (e) => {
      // Don't show magnifier if zoomed in, dragging, or in free annotation mode
      if (state.zoom > 1 || pageCanvasDragState.isDragging ||
        (typeof isFreeAnnotationMode === 'function' && isFreeAnnotationMode()) ||
        freeAnnotationDrawState.isDrawing) {
        hideMagnifier()
        return
      }
      const rect = canvas.getBoundingClientRect()
      showMagnifier(canvas, e.clientX, e.clientY, rect)
    })

    canvas.addEventListener('mouseleave', () => {
      hideMagnifier()
    })

    canvas.addEventListener('mousedown', () => {
      hideMagnifier()
    })

    // Scroll wheel to zoom magnifier (only when magnifier is active)
    canvas.addEventListener('wheel', (e) => {
      // Only handle wheel for magnifier if not already zoomed
      if (state.zoom > 1 || pageCanvasDragState.isDragging) return
      if (!magnifierActiveCanvas) return

      e.preventDefault()
      const delta = e.deltaY < 0 ? 0.5 : -0.5  // Scroll up = zoom in, scroll down = zoom out
      adjustMagnifierZoom(delta)
    }, { passive: false })
  })
}

// ============ CROPPED CANVAS ZOOM & PAN ============
// Individual zoom & pan per canvas (not connected to global state.zoom)
const croppedCanvasZoomState = new WeakMap()

function getCroppedCanvasZoom(canvas) {
  if (!croppedCanvasZoomState.has(canvas)) {
    croppedCanvasZoomState.set(canvas, {
      scale: 1,
      translateX: 0,
      translateY: 0,
      isDragging: false,
      dragEnabled: false,
      startX: 0,
      startY: 0
    })
  }
  return croppedCanvasZoomState.get(canvas)
}

function updateCroppedCanvasTransform(canvas) {
  const zoom = getCroppedCanvasZoom(canvas)
  canvas.style.transform = `translate(${zoom.translateX}px, ${zoom.translateY}px) scale(${zoom.scale})`
  canvas.style.transformOrigin = 'center center'

  // Update cursor based on drag state
  if (zoom.isDragging) {
    canvas.style.cursor = 'grabbing'
  } else if (zoom.dragEnabled) {
    canvas.style.cursor = 'grab'
  } else {
    canvas.style.cursor = zoom.scale >= 4 ? 'zoom-out' : 'zoom-in'
  }
}

function zoomCroppedCanvas(canvas, delta, centerX, centerY) {
  const zoom = getCroppedCanvasZoom(canvas)
  const oldScale = zoom.scale
  zoom.scale = Math.max(0.5, Math.min(4, zoom.scale + delta))

  // If zooming out to 1 or below, reset translation
  if (zoom.scale <= 1) {
    zoom.translateX = 0
    zoom.translateY = 0
  } else if (centerX !== undefined && centerY !== undefined) {
    // Zoom towards mouse position
    const rect = canvas.getBoundingClientRect()
    const offsetX = centerX - rect.left - rect.width / 2
    const offsetY = centerY - rect.top - rect.height / 2

    const scaleChange = zoom.scale / oldScale
    zoom.translateX = zoom.translateX * scaleChange - offsetX * (scaleChange - 1)
    zoom.translateY = zoom.translateY * scaleChange - offsetY * (scaleChange - 1)
  }

  updateCroppedCanvasTransform(canvas)
}

function resetCroppedCanvasZoom(canvas) {
  const zoom = getCroppedCanvasZoom(canvas)
  zoom.scale = 1
  zoom.translateX = 0
  zoom.translateY = 0
  zoom.isDragging = false
  zoom.dragEnabled = false
  updateCroppedCanvasTransform(canvas)
}

function initCroppedCanvasZoom() {
  const canvases = document.querySelectorAll('.cropped-canvas')

  canvases.forEach(canvas => {
    // Skip if already initialized
    if (canvas.dataset.zoomInit) return
    canvas.dataset.zoomInit = 'true'

    // Set magnifier cursor
    canvas.style.cursor = 'zoom-in'

    // No wheel zoom - let scroll work normally

    // Track long press state per canvas
    let clickStartTime = 0
    let clickStartX = 0
    let clickStartY = 0
    let longPressTimer = null

    canvas.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return // Only left mouse button

      const zoom = getCroppedCanvasZoom(canvas)
      clickStartTime = Date.now()
      clickStartX = e.clientX
      clickStartY = e.clientY
      zoom.dragEnabled = false

      // Start long press timer
      longPressTimer = setTimeout(() => {
        // Long press detected - enable drag mode
        zoom.dragEnabled = true
        zoom.isDragging = true
        zoom.startX = e.clientX - zoom.translateX
        zoom.startY = e.clientY - zoom.translateY
        canvas.style.cursor = 'grabbing'
      }, LONG_PRESS_DURATION)
    })

    canvas.addEventListener('mousemove', (e) => {
      const zoom = getCroppedCanvasZoom(canvas)

      // If moved too much before long press, cancel it
      if (longPressTimer) {
        const distX = Math.abs(e.clientX - clickStartX)
        const distY = Math.abs(e.clientY - clickStartY)
        if (distX > 5 || distY > 5) {
          clearTimeout(longPressTimer)
          longPressTimer = null
        }
      }

      if (!zoom.isDragging) return

      e.preventDefault()
      zoom.translateX = e.clientX - zoom.startX
      zoom.translateY = e.clientY - zoom.startY
      updateCroppedCanvasTransform(canvas)
    })

    const handleMouseUp = (e) => {
      // Clear long press timer
      if (longPressTimer) {
        clearTimeout(longPressTimer)
        longPressTimer = null
      }

      const zoom = getCroppedCanvasZoom(canvas)
      const wasDragging = zoom.isDragging
      zoom.isDragging = false
      zoom.dragEnabled = false

      // Check if this was a short click (not a drag or long press)
      const timeDiff = Date.now() - clickStartTime
      const distX = Math.abs(e.clientX - clickStartX)
      const distY = Math.abs(e.clientY - clickStartY)
      const isClick = timeDiff < LONG_PRESS_DURATION && distX < 5 && distY < 5

      if (isClick && !wasDragging && e.button === 0) {
        // Zoom in on click
        zoomCroppedCanvas(canvas, 0.25, e.clientX, e.clientY)
      } else {
        updateCroppedCanvasTransform(canvas)
      }
    }

    canvas.addEventListener('mouseup', handleMouseUp)
    canvas.addEventListener('mouseleave', (e) => {
      if (longPressTimer) {
        clearTimeout(longPressTimer)
        longPressTimer = null
      }
      const zoom = getCroppedCanvasZoom(canvas)
      if (zoom.isDragging) {
        zoom.isDragging = false
        zoom.dragEnabled = false
        updateCroppedCanvasTransform(canvas)
      }
    })

    // Right click to zoom out
    canvas.addEventListener('contextmenu', (e) => {
      e.preventDefault()
      e.stopPropagation()
      zoomCroppedCanvas(canvas, -0.25, e.clientX, e.clientY)
    })
  })
}

// ============ HOVER MAGNIFIER FOR CROPPED CANVAS ============
const MAGNIFIER_WIDTH = 400  // Width of magnifier popup
const MAGNIFIER_HEIGHT = 150 // Height of magnifier popup
const MAGNIFIER_ZOOM_DEFAULT = 2.5   // Default zoom level for magnifier
const MAGNIFIER_ZOOM_MIN = 1.5
const MAGNIFIER_ZOOM_MAX = 6

let magnifierElement = null
let magnifierCanvas = null
let magnifierCtx = null
let magnifierZoom = MAGNIFIER_ZOOM_DEFAULT  // Current zoom level (mutable)
let magnifierActiveCanvas = null  // Track which canvas is currently being magnified
let magnifierLastMouseX = 0
let magnifierLastMouseY = 0
let magnifierLastCanvasRect = null

function createMagnifier() {
  if (magnifierElement) return magnifierElement

  magnifierElement = document.createElement('div')
  magnifierElement.id = 'canvas-magnifier'
  magnifierElement.style.cssText = `
    position: fixed;
    width: ${MAGNIFIER_WIDTH}px;
    height: ${MAGNIFIER_HEIGHT}px;
    border: 1px solid var(--border);
    border-radius: 8px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    pointer-events: none;
    z-index: 10000;
    display: none;
    overflow: hidden;
    background: var(--bg-primary, #fff);
  `

  magnifierCanvas = document.createElement('canvas')
  magnifierCanvas.width = MAGNIFIER_WIDTH * 2
  magnifierCanvas.height = MAGNIFIER_HEIGHT * 2
  magnifierCanvas.style.cssText = `
    width: 100%;
    height: 100%;
  `
  magnifierElement.appendChild(magnifierCanvas)
  magnifierCtx = magnifierCanvas.getContext('2d')

  // Add zoom label
  const zoomLabel = document.createElement('div')
  zoomLabel.id = 'magnifier-zoom-label'
  zoomLabel.style.cssText = `
    position: absolute;
    bottom: 4px;
    right: 6px;
    font-size: 10px;
    font-weight: 500;
    color: var(--text-secondary, #666);
    background: var(--bg-primary, rgba(255,255,255,0.85));
    padding: 1px 4px;
    border-radius: 3px;
    pointer-events: none;
    opacity: 0.5;
  `
  magnifierElement.appendChild(zoomLabel)

  document.body.appendChild(magnifierElement)
  return magnifierElement
}

function showMagnifier(sourceCanvas, mouseX, mouseY, canvasRect) {
  createMagnifier()

  // Calculate the scale ratio between canvas buffer size and display size
  const scaleX = sourceCanvas.width / canvasRect.width
  const scaleY = sourceCanvas.height / canvasRect.height

  // Use uniform scale for magnifier to avoid distortion
  // (cropped-canvas may have different scaleX/scaleY due to CSS constraints)
  const uniformScale = Math.max(scaleX, scaleY)

  // Calculate position on source canvas using actual scale
  const canvasX = (mouseX - canvasRect.left) * scaleX
  const canvasY = (mouseY - canvasRect.top) * scaleY

  // Save context for wheel zoom updates
  magnifierActiveCanvas = sourceCanvas
  magnifierLastMouseX = mouseX
  magnifierLastMouseY = mouseY
  magnifierLastCanvasRect = canvasRect

  // Calculate the source area to zoom (centered on cursor position)
  // Use uniform scale to maintain aspect ratio
  const sourceWidth = (MAGNIFIER_WIDTH / magnifierZoom) * uniformScale
  const sourceHeight = (MAGNIFIER_HEIGHT / magnifierZoom) * uniformScale
  const sourceX = canvasX - sourceWidth / 2
  const sourceY = canvasY - sourceHeight / 2

  // Clear and draw zoomed portion
  magnifierCtx.imageSmoothingEnabled = true
  magnifierCtx.imageSmoothingQuality = 'high'
  magnifierCtx.clearRect(0, 0, MAGNIFIER_WIDTH * 2, MAGNIFIER_HEIGHT * 2)

  try {
    magnifierCtx.drawImage(
      sourceCanvas,
      sourceX, sourceY, sourceWidth, sourceHeight,
      0, 0, MAGNIFIER_WIDTH * 2, MAGNIFIER_HEIGHT * 2
    )
  } catch (e) {
    // Canvas might be tainted
    console.warn('Cannot magnify canvas:', e)
    return
  }

  // Draw crosshair at exact center (represents cursor position)
  const centerX = MAGNIFIER_WIDTH   // Center of canvas buffer
  const centerY = MAGNIFIER_HEIGHT

  magnifierCtx.strokeStyle = 'rgba(239, 68, 68, 0.6)'
  magnifierCtx.lineWidth = 1
  magnifierCtx.beginPath()
  // Horizontal line
  magnifierCtx.moveTo(centerX - 12, centerY)
  magnifierCtx.lineTo(centerX + 12, centerY)
  // Vertical line
  magnifierCtx.moveTo(centerX, centerY - 12)
  magnifierCtx.lineTo(centerX, centerY + 12)
  magnifierCtx.stroke()

  // Small center dot
  magnifierCtx.fillStyle = 'rgba(239, 68, 68, 0.6)'
  magnifierCtx.beginPath()
  magnifierCtx.arc(centerX, centerY, 2, 0, Math.PI * 2)
  magnifierCtx.fill()

  // Position magnifier - on top of cursor
  let posX = mouseX - MAGNIFIER_WIDTH / 2
  let posY = mouseY - MAGNIFIER_HEIGHT - 10

  // Keep within viewport
  if (posX < 5) {
    posX = 5
  }
  if (posX + MAGNIFIER_WIDTH > window.innerWidth - 5) {
    posX = window.innerWidth - MAGNIFIER_WIDTH - 5
  }
  if (posY < 5) {
    // If not enough space on top, show below cursor
    posY = mouseY + 15
  }

  magnifierElement.style.left = `${posX}px`
  magnifierElement.style.top = `${posY}px`

  // Update zoom label
  const zoomLabel = document.getElementById('magnifier-zoom-label')
  if (zoomLabel) {
    const zoomPercent = Math.round(magnifierZoom * 100)
    zoomLabel.textContent = `${zoomPercent}%`
  }

  magnifierElement.style.display = 'block'
}

function hideMagnifier() {
  if (magnifierElement) {
    magnifierElement.style.display = 'none'
  }
  // Reset zoom when hiding
  magnifierZoom = MAGNIFIER_ZOOM_DEFAULT
  magnifierActiveCanvas = null
  magnifierLastCanvasRect = null
}

// Adjust magnifier zoom via scroll wheel
function adjustMagnifierZoom(delta) {
  const oldZoom = magnifierZoom
  magnifierZoom = Math.max(MAGNIFIER_ZOOM_MIN, Math.min(MAGNIFIER_ZOOM_MAX, magnifierZoom + delta))

  // Re-render magnifier if zoom changed and we have context
  if (magnifierZoom !== oldZoom && magnifierActiveCanvas && magnifierLastCanvasRect) {
    showMagnifier(magnifierActiveCanvas, magnifierLastMouseX, magnifierLastMouseY, magnifierLastCanvasRect)
  }
}

function initCroppedCanvasMagnifier() {
  const canvases = document.querySelectorAll('.cropped-canvas')

  canvases.forEach(canvas => {
    // Skip if already initialized for magnifier
    if (canvas.dataset.magnifierInit) return
    canvas.dataset.magnifierInit = 'true'

    canvas.addEventListener('mouseenter', () => {
      // Only show magnifier if not zoomed/dragging
      const zoom = getCroppedCanvasZoom(canvas)
      if (zoom.scale > 1 || zoom.isDragging) return
    })

    canvas.addEventListener('mousemove', (e) => {
      const zoom = getCroppedCanvasZoom(canvas)
      // Don't show magnifier if already zoomed or dragging
      if (zoom.scale > 1 || zoom.isDragging) {
        hideMagnifier()
        return
      }

      const rect = canvas.getBoundingClientRect()
      showMagnifier(canvas, e.clientX, e.clientY, rect)
    })

    canvas.addEventListener('mouseleave', () => {
      hideMagnifier()
    })

    canvas.addEventListener('mousedown', () => {
      hideMagnifier()
    })

    // Scroll wheel to zoom magnifier
    canvas.addEventListener('wheel', (e) => {
      const zoom = getCroppedCanvasZoom(canvas)
      // Only handle wheel for magnifier if not already zoomed
      if (zoom.scale > 1 || zoom.isDragging) return
      if (!magnifierActiveCanvas) return

      e.preventDefault()
      const delta = e.deltaY < 0 ? 0.5 : -0.5  // Scroll up = zoom in, scroll down = zoom out
      adjustMagnifierZoom(delta)
    }, { passive: false })
  })
}

// Extend drawCroppedCanvases to initialize magnifier
const originalDrawCroppedCanvases = drawCroppedCanvases
drawCroppedCanvases = function () {
  originalDrawCroppedCanvases.apply(this, arguments)
  setTimeout(() => {
    initCroppedCanvasMagnifier()
  }, 150)
}
