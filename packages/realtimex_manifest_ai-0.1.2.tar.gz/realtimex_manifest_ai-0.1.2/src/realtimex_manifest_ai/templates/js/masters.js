// ============ MASTER SELECTION MANAGEMENT SYSTEM ============

// Store for master selections
// Structure: { "field_path": { "masterDoc": "doc_name", "value": "...", "timestamp": "..." } }
const masterSelections = {}

function isReadOnlyMasters() {
  return typeof state !== 'undefined' && state.readOnlyMode
}

// Load masters from server
async function loadMasters() {
  if (isReadOnlyMasters()) {
    const embedded = window.__embeddedUserData || {}
    const masterData = embedded.masters || {}
    Object.keys(masterSelections).forEach(key => delete masterSelections[key])
    Object.assign(masterSelections, masterData)
    return
  }
  if (isReadOnlyMasters()) {
    return
  }
  try {
    const batchId = getBatchId()
    const response = await fetch(`/api/masters?batch_id=${batchId}`)
    if (response.ok) {
      const data = await response.json()
      Object.assign(masterSelections, data)
      console.log('Loaded master selections from server:', Object.keys(masterSelections).length, 'fields')
    } else {
      console.warn('No masters file found, starting fresh')
    }
  } catch (err) {
    console.error('Failed to load masters from server:', err)
  }
}

// Save masters to server
async function saveMasters() {
  if (isReadOnlyMasters()) {
    return
  }
  try {
    const batchId = getBatchId()
    const response = await fetch(`/api/masters?batch_id=${batchId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(masterSelections)
    })

    if (response.ok) {
      const result = await response.json()
      console.log('Saved master selections to server:', result.message)
    } else {
      const error = await response.json()
      console.error('Failed to save masters:', error.error)
      await showAlertDialog('Failed to save master selections to server. Please check console for details.', {
        title: 'Save Failed',
        type: 'danger'
      })
    }
  } catch (err) {
    console.error('Failed to save masters to server:', err)
    await showAlertDialog('Failed to save master selections to server. Make sure the server is running.', {
      title: 'Server Error',
      type: 'danger'
    })
  }
}

// Set master for a specific field
function setFieldMaster(fieldPath, docName, value) {
  if (isReadOnlyMasters()) {
    return
  }
  const timestamp = new Date().toISOString()

  masterSelections[fieldPath] = {
    masterDoc: docName,
    value: value,
    timestamp: timestamp
  }

  saveMasters()
  console.log(`Set master for ${fieldPath}: ${docName}`)
}

// Get master document for a field
function getMasterDoc(fieldPath) {
  const master = masterSelections[fieldPath]
  return master ? master.masterDoc : null
}

// Get full master info for a field
function getMasterInfo(fieldPath) {
  return masterSelections[fieldPath] || null
}

// Check if a document is master for a field
function isDocMaster(fieldPath, docName) {
  const master = masterSelections[fieldPath]
  return master && master.masterDoc === docName
}

// Initialize masters system
async function initializeMasters() {
  await loadMasters()
}

// Get master evidence for a validation based on field path
function getMasterEvidence(validation) {
  if (!validation || !validation.field_path || !validation.evidence) {
    return null
  }

  const masterDoc = getMasterDoc(validation.field_path)
  if (!masterDoc) {
    return null
  }

  // Find the evidence that matches the master document
  const masterEvidence = validation.evidence.find(ev => ev.doc_name === masterDoc)
  return masterEvidence || null
}

// Get master evidence index for a validation
function getMasterEvidenceIndex(validation) {
  if (!validation || !validation.field_path || !validation.evidence) {
    return null
  }

  const masterDoc = getMasterDoc(validation.field_path)
  if (!masterDoc) {
    return null
  }

  // Find the index of evidence that matches the master document
  const index = validation.evidence.findIndex(ev => ev.doc_name === masterDoc)
  return index >= 0 ? index : null
}

// Sync master value to all other documents
async function syncMasterToOthers(validation) {
  if (isReadOnlyMasters()) {
    if (typeof showAlertDialog === 'function') {
      await showAlertDialog('Sync is disabled in exported reports.', {
        title: 'Read-only Mode',
        type: 'warning'
      })
    }
    return
  }
  if (!validation || !validation.field_path || !validation.evidence) {
    await showAlertDialog('Cannot sync: no validation data available', {
      title: 'Sync Unavailable',
      type: 'danger'
    })
    return
  }

  // Get master evidence
  const masterEvidence = getMasterEvidence(validation)
  if (!masterEvidence) {
    await showAlertDialog('Please set a master first before syncing', {
      title: 'No Master Selected',
      type: 'danger'
    })
    return
  }

  const masterValue = masterEvidence.value_found
  const masterDoc = masterEvidence.doc_name
  const fieldPath = validation.field_path

  // Count how many files will be updated
  const otherEvidences = validation.evidence.filter(ev => ev.doc_name !== masterDoc)
  if (otherEvidences.length === 0) {
    await showAlertDialog('No other documents to sync to', {
      title: 'Sync Skipped',
      type: 'danger'
    })
    return
  }

  // Check if this is a line item (before confirm to show appropriate message)
  const isLineItemCheck = masterEvidence.fieldValues && Object.keys(masterEvidence.fieldValues).length > 0

  // Confirm with user
  let confirmMessage
  if (isLineItemCheck) {
    const fieldCount = Object.keys(masterEvidence.fieldValues).length
    confirmMessage = `Sync ALL fields from master line item to ${otherEvidences.length} other file(s)?\n\n` +
      `Master: ${masterDoc}\n` +
      `Item: ${fieldPath}\n` +
      `Description: ${masterValue}\n` +
      `Fields to sync: ${fieldCount} fields (description, quantity, price, etc.)\n\n` +
      `This will override ALL fields in:\n` +
      otherEvidences.map(ev => `- ${ev.doc_name}`).join('\n')
  } else {
    confirmMessage = `Sync master value to ${otherEvidences.length} other file(s)?\n\n` +
      `Master: ${masterDoc}\n` +
      `Field: ${fieldPath}\n` +
      `Value: ${masterValue}\n\n` +
      `This will override the field in:\n` +
      otherEvidences.map(ev => `- ${ev.doc_name}`).join('\n')
  }

  const confirmSync = await showConfirmDialog(confirmMessage, {
    title: 'Sync From Master',
    confirmText: 'Sync',
    cancelText: 'Cancel',
    type: 'warning'
  })
  if (!confirmSync) {
    return
  }

  // Check if this is a line item validation (has fieldValues)
  const isLineItem = masterEvidence.fieldValues && Object.keys(masterEvidence.fieldValues).length > 0

  // Sync to each document
  let syncCount = 0
  for (const evidence of otherEvidences) {
    const docName = evidence.doc_name

    if (isLineItem) {
      // For line items, sync all fields
      const masterFields = masterEvidence.fieldValues
      const targetFields = evidence.fieldValues || {}

      let fieldSyncCount = 0
      for (const [fieldKey, masterFieldData] of Object.entries(masterFields)) {
        const masterFieldValue = masterFieldData.value
        const targetFieldData = targetFields[fieldKey]

        if (targetFieldData && targetFieldData.fieldPath) {
          const currentFieldValue = targetFieldData.value
          const targetFieldPath = targetFieldData.fieldPath

          // Sync this field
          addOverride(docName, targetFieldPath, masterFieldValue, currentFieldValue, { action: 'sync_from_master' })
          fieldSyncCount++
        }
      }

      if (fieldSyncCount > 0) {
        syncCount++
      }
    } else {
      // For regular fields, sync just the value
      const currentValue = evidence.value_found
      addOverride(docName, fieldPath, masterValue, currentValue, { action: 'sync_from_master' })
      syncCount++
    }
  }

  if (isLineItem) {
    await showAlertDialog(`Successfully synced all fields from master line item to ${syncCount} file(s)`, {
      title: 'Sync Complete',
      type: 'success',
      confirmText: 'Done'
    })
  } else {
    await showAlertDialog(`Successfully synced master value to ${syncCount} file(s)`, {
      title: 'Sync Complete',
      type: 'success',
      confirmText: 'Done'
    })
  }
}
