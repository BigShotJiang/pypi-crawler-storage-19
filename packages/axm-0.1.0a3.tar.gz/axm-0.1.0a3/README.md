# AXM

**The Swiss Clock for Data Pipelines** — Data Governance at the Edge.

## Installation

```bash
pip install axm
```

## What's Included

This is the meta-package that installs all AXM components:

- **axm-cli** — Command-line interface (`axm init`, `axm run`, etc.)
- **axm-engine** — Pipeline orchestration and execution
- **axm-core** — Core data contracts and validation
- **axm-tabular** — Polars-based tabular data support
- **axm-image** — PIL-based image data support

## Quick Start

```bash
mkdir my-pipeline && cd my-pipeline
axm init .
axm run pipelines/daily_etl.axm
```

## Documentation

Full documentation: https://axm-protocols.github.io/axm/
