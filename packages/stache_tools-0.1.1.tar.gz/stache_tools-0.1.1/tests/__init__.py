"""Tests for stache-tools."""
