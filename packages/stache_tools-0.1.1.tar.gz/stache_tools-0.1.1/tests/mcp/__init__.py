"""Tests for MCP module."""
