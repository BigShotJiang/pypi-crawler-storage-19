"""Tests for loaders module."""
