# Copyright (C) 2023-2026 Sebastien Rousseau.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Comprehensive tests for pain.001.001.09 (ISO 20022 Payment Initiation v9).

This test suite validates:
- XML generation from Python data structures
- XML generation from CSV files
- XML generation from SQLite databases
- XSD schema validation
- Template rendering with Jinja2
- Data structure integrity
"""

import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

from pain001.xml.create_xml_v9 import create_xml_v9
from pain001.xml.validate_via_xsd import validate_via_xsd


class TestPain001V9XMLGeneration(unittest.TestCase):
    """Test XML generation for pain.001.001.09 format."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.root = ET.Element("Document")
        self.test_data = [
            {
                "id": "MSG001",
                "date": "2023-03-10T15:30:47.000Z",
                "nb_of_txs": "2",
                "initiator_name": "Test Corp V9",
                "payment_id": "PMT001",
                "payment_method": "TRF",
                "requested_execution_date": "2023-03-12",
                "debtor_name": "Acme Corp",
                "debtor_account_IBAN": "DE75512108001245126162",
                "debtor_agent_BIC": "DEUTDEFFXXX",
                "charge_bearer": "DEBT",
                "currency": "EUR",
                "payment_amount": "150.00",
                "creditor_agent_BIC": "DEUTDEFFXXX",
                "creditor_name": "Global Tech",
                "creditor_account_IBAN": "DE68210501700024690959",
                "remittance_information": "Invoice 2023-001",
            },
            {
                "id": "MSG001",
                "date": "2023-03-10T15:30:47.000Z",
                "nb_of_txs": "2",
                "initiator_name": "Test Corp V9",
                "payment_id": "PMT002",
                "payment_method": "TRF",
                "requested_execution_date": "2023-03-12",
                "debtor_name": "Acme Corp",
                "debtor_account_IBAN": "DE75512108001245126162",
                "debtor_agent_BIC": "DEUTDEFFXXX",
                "charge_bearer": "DEBT",
                "currency": "EUR",
                "payment_amount": "300.00",
                "creditor_agent_BIC": "DEUTDEFFXXX",
                "creditor_name": "Green Energy",
                "creditor_account_IBAN": "DE89370400440532013008",
                "remittance_information": "Invoice 2023-002",
            },
        ]

    def test_create_xml_v9_basic(self) -> None:
        """Test basic XML creation for pain.001.001.09."""
        result = create_xml_v9(self.root, self.test_data)

        # Check root element structure
        self.assertIsNotNone(result)
        self.assertEqual(result.tag, "Document")

        # Check CstmrCdtTrfInitn element was created
        cstmr_element = result.find("CstmrCdtTrfInitn")
        self.assertIsNotNone(cstmr_element)

    def test_create_xml_v9_with_template(self) -> None:
        """Test XML generation using Jinja2 template."""
        result = create_xml_v9(self.root, self.test_data)

        # Verify the XML structure
        xml_string = ET.tostring(result, encoding="unicode")

        # Check for expected structure elements
        self.assertIn("MSG001", xml_string)
        self.assertIn("CstmrCdtTrfInitn", xml_string)
        self.assertIn("GrpHdr", xml_string)
        self.assertIn("PmtInf", xml_string)
        self.assertIn("CdtTrfTxInf", xml_string)

    def test_create_xml_v9_namespace(self) -> None:
        """Test that correct namespace is used for pain.001.001.09."""
        result = create_xml_v9(self.root, self.test_data)
        xml_string = ET.tostring(result, encoding="unicode")

        # Verify pain.001.001.09 namespace is present
        self.assertIn("pain.001.001.09", xml_string)


class TestPain001V9XSDValidation(unittest.TestCase):
    """Test XSD validation for pain.001.001.09 format."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.template_dir = Path("pain001/templates/pain.001.001.09")
        self.xsd_path = self.template_dir / "pain.001.001.09.xsd"
        self.xml_example = self.template_dir / "pain.001.001.09.xml"

    def test_xsd_file_exists(self) -> None:
        """Test that XSD schema file exists."""
        self.assertTrue(
            self.xsd_path.exists(), f"XSD file not found: {self.xsd_path}"
        )

    def test_xml_example_exists(self) -> None:
        """Test that XML example file exists."""
        self.assertTrue(
            self.xml_example.exists(),
            f"XML example not found: {self.xml_example}",
        )

    def test_xml_example_well_formed(self) -> None:
        """Test that XML example is well-formed."""
        try:
            tree = ET.parse(self.xml_example)
            root = tree.getroot()
            self.assertIsNotNone(root)
        except ET.ParseError as e:
            self.fail(f"XML is not well-formed: {e}")

    def test_xml_has_correct_namespace(self) -> None:
        """Test that XML example uses correct namespace."""
        tree = ET.parse(self.xml_example)
        root = tree.getroot()

        # Check namespace
        self.assertIn("pain.001.001.09", root.tag)

    def test_xml_validates_against_xsd(self) -> None:
        """Test that XML example validates against XSD schema."""
        is_valid = validate_via_xsd(str(self.xml_example), str(self.xsd_path))
        self.assertTrue(
            is_valid, "XML example should validate against XSD schema"
        )


class TestPain001V9CSVIntegration(unittest.TestCase):
    """Test CSV file integration for pain.001.001.09."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.template_dir = Path("pain001/templates/pain.001.001.09")
        self.csv_template = self.template_dir / "template.csv"

    def test_csv_template_exists(self) -> None:
        """Test that CSV template file exists."""
        self.assertTrue(
            self.csv_template.exists(),
            f"CSV template not found: {self.csv_template}",
        )

    def test_csv_template_readable(self) -> None:
        """Test that CSV template is readable."""
        try:
            with open(self.csv_template) as f:
                content = f.read()
                self.assertGreater(len(content), 0)
                # Check for headers
                self.assertIn("id", content)
                self.assertIn("date", content)
                self.assertIn("nb_of_txs", content)
        except Exception as e:
            self.fail(f"Failed to read CSV template: {e}")

    def test_csv_has_required_columns(self) -> None:
        """Test that CSV has all required columns."""
        import csv

        with open(self.csv_template) as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames

            required_columns = [
                "id",
                "date",
                "nb_of_txs",
                "initiator_name",
                "payment_id",
                "payment_method",
                "requested_execution_date",
                "debtor_name",
                "debtor_account_IBAN",
                "debtor_agent_BIC",
                "charge_bearer",
                "payment_amount",
                "currency",
                "creditor_agent_BIC",
                "creditor_name",
                "creditor_account_IBAN",
            ]

            for col in required_columns:
                self.assertIn(
                    col, headers, f"Required column '{col}' not found in CSV"
                )


class TestPain001V9DatabaseIntegration(unittest.TestCase):
    """Test SQLite database integration for pain.001.001.09."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.template_dir = Path("pain001/templates/pain.001.001.09")
        self.db_template = self.template_dir / "template.db"

    def test_db_template_exists(self) -> None:
        """Test that database template file exists."""
        self.assertTrue(
            self.db_template.exists(),
            f"DB template not found: {self.db_template}",
        )

    def test_db_is_sqlite(self) -> None:
        """Test that database is a valid SQLite file."""
        import sqlite3

        try:
            conn = sqlite3.connect(self.db_template)
            cursor = conn.cursor()
            cursor.execute(
                "SELECT name FROM sqlite_master WHERE type='table';"
            )
            tables = cursor.fetchall()
            self.assertGreater(len(tables), 0, "Database has no tables")
            conn.close()
        except sqlite3.Error as e:
            self.fail(f"Invalid SQLite database: {e}")


class TestPain001V9Templates(unittest.TestCase):
    """Test template files for pain.001.001.09."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.template_dir = Path("pain001/templates/pain.001.001.09")
        self.xml_template = self.template_dir / "template.xml"

    def test_jinja2_template_exists(self) -> None:
        """Test that Jinja2 template exists."""
        self.assertTrue(
            self.xml_template.exists(),
            f"Jinja2 template not found: {self.xml_template}",
        )

    def test_jinja2_template_has_variables(self) -> None:
        """Test that Jinja2 template has expected variables."""
        with open(self.xml_template) as f:
            content = f.read()

            expected_vars = [
                "{{id}}",
                "{{date}}",
                "{{nb_of_txs}}",
                "{{initiator_name}}",
                "{{payment_id}}",
                "{{debtor_name}}",
                "{{debtor_account_IBAN}}",
                "{{tx.payment_amount}}",
                "{{tx.creditor_name}}",
            ]

            for var in expected_vars:
                self.assertIn(
                    var, content, f"Template variable '{var}' not found"
                )

    def test_jinja2_template_has_loop(self) -> None:
        """Test that Jinja2 template has transaction loop."""
        with open(self.xml_template) as f:
            content = f.read()
            self.assertIn("{% for tx in transactions %}", content)
            self.assertIn("{% endfor %}", content)


if __name__ == "__main__":
    unittest.main()
