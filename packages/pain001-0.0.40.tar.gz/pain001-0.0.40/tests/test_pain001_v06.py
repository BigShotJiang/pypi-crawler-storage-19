# Copyright (C) 2023-2026 Sebastien Rousseau.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Comprehensive tests for pain.001.001.06 (ISO 20022 Payment Initiation v06).

This test suite validates:
- XSD schema files
- XML example files
- CSV template files
- SQLite database templates
- Jinja2 template files
"""

import csv
import sqlite3
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

from pain001.xml.create_xml_v6 import create_xml_v6
from pain001.xml.validate_via_xsd import validate_via_xsd


class TestPain001V6XMLGeneration(unittest.TestCase):
    """Test XML generation for pain.001.001.06 format."""

    def setUp(self) -> None:
        """Set up test fixtures with data from CSV template."""
        self.root = ET.Element("Document")

        # Load test data from CSV template
        csv_path = Path("pain001/templates/pain.001.001.06/template.csv")
        with open(csv_path) as f:
            reader = csv.DictReader(f)
            self.test_data = list(reader)[:2]  # Use first 2 rows

    def test_create_xml_v6_basic(self) -> None:
        """Test basic XML creation for pain.001.001.06."""
        result = create_xml_v6(self.root, self.test_data)

        # Check root element structure
        self.assertIsNotNone(result)
        self.assertEqual(result.tag, "Document")

        # Check CstmrCdtTrfInitn element was created
        cstmr_element = result.find("CstmrCdtTrfInitn")
        self.assertIsNotNone(cstmr_element)

    def test_create_xml_v6_with_template(self) -> None:
        """Test XML generation using Jinja2 template."""
        result = create_xml_v6(self.root, self.test_data)

        # Verify the XML structure
        xml_string = ET.tostring(result, encoding="unicode")

        # Check for expected structure elements
        self.assertIn("CstmrCdtTrfInitn", xml_string)
        self.assertIn("GrpHdr", xml_string)
        self.assertIn("PmtInf", xml_string)

    def test_create_xml_v6_namespace(self) -> None:
        """Test that correct namespace is used for pain.001.001.06."""
        result = create_xml_v6(self.root, self.test_data)
        xml_string = ET.tostring(result, encoding="unicode")

        # Verify pain.001.001.06 namespace is present
        self.assertIn("pain.001.001.06", xml_string)


class TestPain001V6XSDValidation(unittest.TestCase):
    """Test XSD validation for pain.001.001.06 format."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.template_dir = Path("pain001/templates/pain.001.001.06")
        self.xsd_path = self.template_dir / "pain.001.001.06.xsd"
        self.xml_example = self.template_dir / "pain.001.001.06.xml"

    def test_xsd_file_exists(self) -> None:
        """Test that XSD schema file exists."""
        self.assertTrue(
            self.xsd_path.exists(), f"XSD file not found: {self.xsd_path}"
        )

    def test_xml_example_exists(self) -> None:
        """Test that XML example file exists."""
        self.assertTrue(
            self.xml_example.exists(),
            f"XML example not found: {self.xml_example}",
        )

    def test_xml_example_well_formed(self) -> None:
        """Test that XML example is well-formed."""
        try:
            tree = ET.parse(self.xml_example)
            root = tree.getroot()
            self.assertIsNotNone(root)
        except ET.ParseError as e:
            self.fail(f"XML is not well-formed: {e}")

    def test_xml_has_correct_namespace(self) -> None:
        """Test that XML example has correct namespace."""
        tree = ET.parse(self.xml_example)
        xml_string = ET.tostring(tree.getroot(), encoding="unicode")
        self.assertIn("pain.001.001.06", xml_string)

    def test_xml_validates_against_xsd(self) -> None:
        """Test that XML example validates against XSD schema."""
        is_valid = validate_via_xsd(str(self.xml_example), str(self.xsd_path))
        self.assertTrue(
            is_valid, "XML example should validate against XSD schema"
        )


class TestPain001V6CSVIntegration(unittest.TestCase):
    """Test CSV file integration for pain.001.001.06."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.template_dir = Path("pain001/templates/pain.001.001.06")
        self.csv_template = self.template_dir / "template.csv"

    def test_csv_template_exists(self) -> None:
        """Test that CSV template file exists."""
        self.assertTrue(
            self.csv_template.exists(),
            f"CSV template not found: {self.csv_template}",
        )

    def test_csv_template_readable(self) -> None:
        """Test that CSV template is readable."""
        with open(self.csv_template) as f:
            content = f.read()
            self.assertGreater(len(content), 0)
            self.assertIn("id", content)

    def test_csv_has_required_columns(self) -> None:
        """Test that CSV template has required columns."""
        with open(self.csv_template) as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames
            self.assertIsNotNone(headers)
            # All versions should have these basic columns
            required = ["id", "date", "nb_of_txs", "initiator_name"]
            for col in required:
                self.assertIn(col, headers, f"Missing required column: {col}")


class TestPain001V6DatabaseIntegration(unittest.TestCase):
    """Test SQLite database integration for pain.001.001.06."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.template_dir = Path("pain001/templates/pain.001.001.06")
        self.db_template = self.template_dir / "template.db"

    def test_db_template_exists(self) -> None:
        """Test that database template file exists."""
        self.assertTrue(
            self.db_template.exists(),
            f"DB template not found: {self.db_template}",
        )

    def test_db_is_sqlite(self) -> None:
        """Test that database template is a valid SQLite database."""
        try:
            conn = sqlite3.connect(self.db_template)
            cursor = conn.cursor()
            # Try to query sqlite_master table (exists in all SQLite DBs)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            conn.close()
            self.assertIsNotNone(tables)
        except sqlite3.Error as e:
            self.fail(f"Database is not a valid SQLite database: {e}")


class TestPain001V6Templates(unittest.TestCase):
    """Test template files for pain.001.001.06."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.template_dir = Path("pain001/templates/pain.001.001.06")
        self.xml_template = self.template_dir / "template.xml"

    def test_jinja2_template_exists(self) -> None:
        """Test that Jinja2 template exists."""
        self.assertTrue(
            self.xml_template.exists(),
            f"Jinja2 template not found: {self.xml_template}",
        )

    def test_jinja2_template_has_variables(self) -> None:
        """Test that Jinja2 template has expected variables."""
        with open(self.xml_template) as f:
            content = f.read()
            self.assertIn("{{", content)
            self.assertIn("}}", content)

    def test_jinja2_template_has_loop(self) -> None:
        """Test that Jinja2 template has for loop or is single-transaction."""
        with open(self.xml_template) as f:
            content = f.read()
            # Templates may have loops for multiple transactions or be single-transaction
            has_loop = "{% for" in content or "{%for" in content
            has_jinja_vars = "{{" in content or "{%" in content
            self.assertTrue(
                has_loop or has_jinja_vars,
                "Template should contain Jinja2 loop or variables",
            )


if __name__ == "__main__":
    unittest.main()
