::: tipi.abstractions
