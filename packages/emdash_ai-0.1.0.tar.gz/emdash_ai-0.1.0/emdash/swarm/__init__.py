"""Multi-agent swarm execution with git worktrees."""

from emdash.swarm.task_definition import SwarmTask, SwarmState, TaskStatus
from emdash.swarm.worktree_manager import WorktreeManager, WorktreeInfo, WorktreeError
from emdash.swarm.swarm_runner import SwarmRunner
from emdash.swarm.session_manager import SessionManager

__all__ = [
    "SwarmTask",
    "SwarmState",
    "TaskStatus",
    "WorktreeManager",
    "WorktreeInfo",
    "WorktreeError",
    "SwarmRunner",
    "SessionManager",
]
