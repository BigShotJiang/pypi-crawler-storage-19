"""Language parsers for code extraction."""

from emdash.ingestion.parsers.base_parser import BaseLanguageParser
from emdash.ingestion.parsers.registry import ParserRegistry
from emdash.ingestion.parsers.python_parser import PythonParser
from emdash.ingestion.parsers.typescript_parser import TypeScriptParser

# Parsers auto-register when imported above

__all__ = ['BaseLanguageParser', 'ParserRegistry', 'PythonParser', 'TypeScriptParser']
