"""Graph analytics module."""

from emdash.analytics.engine import AnalyticsEngine

__all__ = ['AnalyticsEngine']
