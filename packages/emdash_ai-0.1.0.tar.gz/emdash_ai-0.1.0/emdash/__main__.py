"""Entry point for running EmDash as a module."""

from emdash.cli.main import cli

if __name__ == "__main__":
    cli()
