"""Utility modules for EmDash."""

from .image import (
    is_clipboard_image_available,
    read_clipboard_image,
    encode_image_to_base64,
    encode_image_for_llm,
    resize_image_if_needed,
    get_image_info,
    estimate_image_tokens,
    read_and_prepare_image,
    ClipboardImageError,
    ImageProcessingError,
    ImageFormat,
)

__all__ = [
    "is_clipboard_image_available",
    "read_clipboard_image",
    "encode_image_to_base64",
    "encode_image_for_llm",
    "resize_image_if_needed",
    "get_image_info",
    "estimate_image_tokens",
    "read_and_prepare_image",
    "ClipboardImageError",
    "ImageProcessingError",
    "ImageFormat",
]