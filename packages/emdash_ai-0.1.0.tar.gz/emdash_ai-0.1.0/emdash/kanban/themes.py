"""Color themes for Kanban board."""

from dataclasses import dataclass
from typing import Dict


@dataclass
class Theme:
    """A color theme for the Kanban board."""
    name: str
    description: str
    emoji: str

    # Main colors
    background: str
    surface: str
    surface_light: str
    surface_dark: str

    # Accent colors
    primary: str
    primary_light: str
    primary_dark: str
    accent: str

    # Text colors
    text: str
    text_muted: str
    text_on_primary: str

    # Border colors
    border: str
    border_focus: str

    # Priority colors
    priority_high: str
    priority_medium: str
    priority_low: str

    # Danger color (for delete)
    danger: str


# ============================================================================
# THEME DEFINITIONS - Go crazy with colors!
# ============================================================================

THEMES: Dict[str, Theme] = {
    "ember": Theme(
        name="Ember",
        description="Warm orange and amber tones",
        emoji="🔥",
        background="#1a1512",
        surface="#2a1f18",
        surface_light="#3a2a1f",
        surface_dark="#1e1714",
        primary="#d35400",
        primary_light="#e67e22",
        primary_dark="#a04000",
        accent="#f39c12",
        text="#f0e6dc",
        text_muted="#a67c52",
        text_on_primary="#ffffff",
        border="#5c3d2e",
        border_focus="#e67e22",
        priority_high="#e74c3c",
        priority_medium="#f39c12",
        priority_low="#27ae60",
        danger="#c0392b",
    ),

    "ocean": Theme(
        name="Ocean",
        description="Deep sea blues and teals",
        emoji="🌊",
        background="#0a1628",
        surface="#122640",
        surface_light="#1a3a5c",
        surface_dark="#0d1e35",
        primary="#0077b6",
        primary_light="#00a8e8",
        primary_dark="#005f8d",
        accent="#00d4ff",
        text="#e0f4ff",
        text_muted="#6ba3c7",
        text_on_primary="#ffffff",
        border="#1e4976",
        border_focus="#00d4ff",
        priority_high="#ff6b6b",
        priority_medium="#ffd93d",
        priority_low="#6bcb77",
        danger="#e63946",
    ),

    "forest": Theme(
        name="Forest",
        description="Earthy greens and browns",
        emoji="🌲",
        background="#1a1f16",
        surface="#2a3324",
        surface_light="#3a4834",
        surface_dark="#1e2619",
        primary="#2d6a4f",
        primary_light="#40916c",
        primary_dark="#1b4332",
        accent="#95d5b2",
        text="#d8f3dc",
        text_muted="#74a892",
        text_on_primary="#ffffff",
        border="#3d5a45",
        border_focus="#95d5b2",
        priority_high="#e07a5f",
        priority_medium="#f2cc8f",
        priority_low="#81b29a",
        danger="#bc4749",
    ),

    "midnight": Theme(
        name="Midnight",
        description="Deep purple and violet dreams",
        emoji="🌙",
        background="#13111c",
        surface="#1e1a2e",
        surface_light="#2a2440",
        surface_dark="#17142a",
        primary="#7c3aed",
        primary_light="#a78bfa",
        primary_dark="#5b21b6",
        accent="#c084fc",
        text="#e9e4f0",
        text_muted="#9d8ab8",
        text_on_primary="#ffffff",
        border="#4c3d6e",
        border_focus="#c084fc",
        priority_high="#f87171",
        priority_medium="#fbbf24",
        priority_low="#4ade80",
        danger="#dc2626",
    ),

    "cyberpunk": Theme(
        name="Cyberpunk",
        description="Neon lights in the dark city",
        emoji="🤖",
        background="#0d0d0d",
        surface="#1a1a2e",
        surface_light="#252545",
        surface_dark="#121220",
        primary="#ff2a6d",
        primary_light="#ff6b9d",
        primary_dark="#d1004b",
        accent="#05d9e8",
        text="#ffffff",
        text_muted="#8888aa",
        text_on_primary="#000000",
        border="#3d3d5c",
        border_focus="#05d9e8",
        priority_high="#ff2a6d",
        priority_medium="#f9f002",
        priority_low="#05d9e8",
        danger="#ff0055",
    ),

    "sakura": Theme(
        name="Sakura",
        description="Cherry blossom pink aesthetic",
        emoji="🌸",
        background="#1f1a1d",
        surface="#2d252a",
        surface_light="#3d333a",
        surface_dark="#251e22",
        primary="#d4729c",
        primary_light="#e899b8",
        primary_dark="#b85a82",
        accent="#ffb7c5",
        text="#fce4ec",
        text_muted="#c9a0ad",
        text_on_primary="#ffffff",
        border="#5c4450",
        border_focus="#ffb7c5",
        priority_high="#ff6b6b",
        priority_medium="#ffd93d",
        priority_low="#a8e6cf",
        danger="#e84545",
    ),

    "matrix": Theme(
        name="Matrix",
        description="Follow the white rabbit",
        emoji="💊",
        background="#0d0208",
        surface="#0f0f0f",
        surface_light="#1a1a1a",
        surface_dark="#050505",
        primary="#00ff41",
        primary_light="#39ff14",
        primary_dark="#00b330",
        accent="#00ff41",
        text="#00ff41",
        text_muted="#008f11",
        text_on_primary="#000000",
        border="#003b00",
        border_focus="#00ff41",
        priority_high="#ff0000",
        priority_medium="#ffff00",
        priority_low="#00ff00",
        danger="#ff0000",
    ),

    "nord": Theme(
        name="Nord",
        description="Arctic, north-bluish color palette",
        emoji="❄️",
        background="#2e3440",
        surface="#3b4252",
        surface_light="#434c5e",
        surface_dark="#2e3440",
        primary="#5e81ac",
        primary_light="#81a1c1",
        primary_dark="#4c6a90",
        accent="#88c0d0",
        text="#eceff4",
        text_muted="#a3b1c6",
        text_on_primary="#ffffff",
        border="#4c566a",
        border_focus="#88c0d0",
        priority_high="#bf616a",
        priority_medium="#ebcb8b",
        priority_low="#a3be8c",
        danger="#bf616a",
    ),

    "dracula": Theme(
        name="Dracula",
        description="Dark theme for vampires",
        emoji="🧛",
        background="#282a36",
        surface="#343746",
        surface_light="#44475a",
        surface_dark="#21222c",
        primary="#bd93f9",
        primary_light="#caa9fa",
        primary_dark="#9d6fdc",
        accent="#ff79c6",
        text="#f8f8f2",
        text_muted="#6272a4",
        text_on_primary="#ffffff",
        border="#44475a",
        border_focus="#ff79c6",
        priority_high="#ff5555",
        priority_medium="#ffb86c",
        priority_low="#50fa7b",
        danger="#ff5555",
    ),

    "sunset": Theme(
        name="Sunset",
        description="Golden hour vibes",
        emoji="🌅",
        background="#1a1520",
        surface="#2d2233",
        surface_light="#3d3044",
        surface_dark="#211a28",
        primary="#ff6b35",
        primary_light="#ff8c5a",
        primary_dark="#e05020",
        accent="#ffd700",
        text="#fff5e6",
        text_muted="#c9a080",
        text_on_primary="#ffffff",
        border="#5c4050",
        border_focus="#ffd700",
        priority_high="#ff4757",
        priority_medium="#ffa502",
        priority_low="#2ed573",
        danger="#ff4757",
    ),

    "monochrome": Theme(
        name="Monochrome",
        description="Classic black and white",
        emoji="⬛",
        background="#0a0a0a",
        surface="#1a1a1a",
        surface_light="#2a2a2a",
        surface_dark="#111111",
        primary="#ffffff",
        primary_light="#ffffff",
        primary_dark="#cccccc",
        accent="#ffffff",
        text="#ffffff",
        text_muted="#888888",
        text_on_primary="#000000",
        border="#333333",
        border_focus="#ffffff",
        priority_high="#ff4444",
        priority_medium="#ffaa00",
        priority_low="#44ff44",
        danger="#ff4444",
    ),

    "coffee": Theme(
        name="Coffee",
        description="Warm coffee shop vibes",
        emoji="☕",
        background="#1b1510",
        surface="#2c2218",
        surface_light="#3d3025",
        surface_dark="#201a14",
        primary="#c49a6c",
        primary_light="#d4b08c",
        primary_dark="#a07850",
        accent="#e8d4b8",
        text="#f5ebe0",
        text_muted="#9c8570",
        text_on_primary="#1b1510",
        border="#4a3c2e",
        border_focus="#e8d4b8",
        priority_high="#d4726a",
        priority_medium="#d4a96a",
        priority_low="#8eb87a",
        danger="#b84c43",
    ),

    "paper": Theme(
        name="Paper",
        description="Clean light theme",
        emoji="📄",
        background="#ffffff",
        surface="#f5f5f5",
        surface_light="#fafafa",
        surface_dark="#eeeeee",
        primary="#333333",
        primary_light="#555555",
        primary_dark="#111111",
        accent="#666666",
        text="#111111",
        text_muted="#666666",
        text_on_primary="#ffffff",
        border="#dddddd",
        border_focus="#333333",
        priority_high="#dc3545",
        priority_medium="#fd7e14",
        priority_low="#28a745",
        danger="#dc3545",
    ),
}

DEFAULT_THEME = "ember"


def get_theme(name: str) -> Theme:
    """Get a theme by name."""
    return THEMES.get(name, THEMES[DEFAULT_THEME])


def list_themes() -> list[Theme]:
    """List all available themes."""
    return list(THEMES.values())


def generate_css(theme: Theme) -> str:
    """Generate CSS variables from a theme."""
    return f"""
    /* Theme: {theme.name} */
    Screen {{
        background: {theme.background};
    }}

    Header {{
        background: {theme.primary};
        color: {theme.text_on_primary};
    }}

    Footer {{
        background: {theme.surface_dark};
        color: {theme.primary_light};
    }}

    Footer > .footer--key {{
        background: {theme.primary};
        color: {theme.text_on_primary};
    }}

    KanbanColumn {{
        border: solid {theme.border};
        background: {theme.surface_dark};
    }}

    KanbanColumn:focus-within {{
        border: solid {theme.border_focus};
    }}

    KanbanColumn .column-header {{
        background: {theme.surface};
        color: {theme.primary_light};
    }}

    KanbanColumn .empty-message {{
        color: {theme.text_muted};
    }}

    TaskCard {{
        background: {theme.surface};
        border: solid {theme.border};
        color: {theme.text};
    }}

    TaskCard:focus {{
        border: solid {theme.border_focus};
        background: {theme.surface_light};
    }}

    TaskCard:hover {{
        background: {theme.surface_light};
    }}

    TaskCard.selected {{
        border: double {theme.accent};
        background: {theme.surface_light};
    }}

    TaskCard .title {{
        color: {theme.text};
    }}

    TaskCard .labels {{
        color: {theme.text_muted};
    }}

    TaskCard .assignee {{
        color: {theme.primary_light};
    }}

    TaskCard .priority-high {{
        color: {theme.priority_high};
    }}

    TaskCard .priority-medium {{
        color: {theme.priority_medium};
    }}

    TaskCard .priority-low {{
        color: {theme.priority_low};
    }}
    """
