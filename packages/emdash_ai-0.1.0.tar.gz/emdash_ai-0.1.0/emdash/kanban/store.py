"""Persistence layer for Kanban board - Business Logic Layer."""

import json
from pathlib import Path
from typing import Optional, Dict, Any

from emdash.kanban.models import Board
from emdash.utils.logger import log


DEFAULT_SETTINGS = {
    "theme": "ember",
}


class KanbanStore:
    """Persists Kanban board and settings to .emdash/kanban.json."""

    KANBAN_DIR = ".emdash"
    KANBAN_FILE = "kanban.json"

    def __init__(self, repo_root: Optional[Path] = None):
        """Initialize the store.

        Args:
            repo_root: Repository root directory. Uses cwd if not provided.
        """
        self.repo_root = repo_root or Path.cwd()
        self.kanban_dir = self.repo_root / self.KANBAN_DIR
        self.kanban_path = self.kanban_dir / self.KANBAN_FILE
        self._settings: Dict[str, Any] = DEFAULT_SETTINGS.copy()

    def _ensure_dir(self) -> None:
        """Ensure the .emdash directory exists."""
        self.kanban_dir.mkdir(parents=True, exist_ok=True)

    def _load_raw(self) -> Dict[str, Any]:
        """Load raw JSON data."""
        if not self.kanban_path.exists():
            return {"tasks": [], "settings": DEFAULT_SETTINGS.copy()}

        try:
            with open(self.kanban_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"tasks": [], "settings": DEFAULT_SETTINGS.copy()}

    def load(self) -> Board:
        """Load the board from disk.

        Returns:
            Board instance (empty if file doesn't exist)
        """
        data = self._load_raw()
        self._settings = data.get("settings", DEFAULT_SETTINGS.copy())

        try:
            board = Board.from_dict(data)
            log.debug(f"Loaded {len(board.tasks)} tasks from {self.kanban_path}")
            return board
        except Exception as e:
            log.warning(f"Failed to parse kanban file: {e}, creating empty board")
            return Board()

    def save(self, board: Board) -> None:
        """Save the board to disk.

        Args:
            board: Board instance to save
        """
        self._ensure_dir()

        try:
            data = board.to_dict()
            data["settings"] = self._settings
            with open(self.kanban_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            log.debug(f"Saved {len(board.tasks)} tasks to {self.kanban_path}")
        except Exception as e:
            log.error(f"Failed to save kanban file: {e}")
            raise

    def get_theme(self) -> str:
        """Get the current theme name."""
        return self._settings.get("theme", "ember")

    def set_theme(self, theme: str) -> None:
        """Set the theme name."""
        self._settings["theme"] = theme

    def exists(self) -> bool:
        """Check if kanban file exists."""
        return self.kanban_path.exists()
