"""Column widget for Kanban board."""

from textual.app import ComposeResult
from textual.widgets import Static
from textual.containers import Vertical, VerticalScroll
from textual.message import Message

from emdash.kanban.models import Task, Column
from emdash.kanban.widgets.card import TaskCard


class KanbanColumn(Vertical):
    """A column in the Kanban board containing task cards."""

    DEFAULT_CSS = """
    KanbanColumn {
        width: 1fr;
        height: 100%;
    }

    KanbanColumn .column-header {
        dock: top;
        height: 3;
        padding: 0 1;
        text-align: center;
        text-style: bold;
    }

    KanbanColumn .task-list {
        padding: 1;
    }

    KanbanColumn .empty-message {
        text-align: center;
        padding: 2;
    }
    """

    def __init__(self, column: Column, tasks: list[Task] = None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.column = column
        self.tasks = tasks or []

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        count = len(self.tasks)
        yield Static(
            f"{self.column.display_name} [dim]({count})[/dim]",
            classes="column-header",
        )

        with VerticalScroll(classes="task-list"):
            if self.tasks:
                for task in self.tasks:
                    yield TaskCard(task, id=f"task-{task.id}")
            else:
                yield Static("No tasks", classes="empty-message")

    def get_task_cards(self) -> list[TaskCard]:
        """Get all task cards in this column."""
        return list(self.query(TaskCard))

    def refresh_tasks(self, tasks: list[Task]) -> None:
        """Update the tasks displayed in this column."""
        self.tasks = tasks
        task_list = self.query_one(".task-list", VerticalScroll)

        # Build maps of existing and new tasks
        existing_cards = {card.task_data.id: card for card in self.query(TaskCard)}
        new_task_ids = {task.id for task in tasks}

        # Remove cards that are no longer present
        for task_id, card in existing_cards.items():
            if task_id not in new_task_ids:
                card.remove()

        # Remove empty message if present
        try:
            empty_msg = task_list.query_one(".empty-message", Static)
            empty_msg.remove()
        except Exception:
            pass

        # Update existing cards or add new ones
        for task in tasks:
            if task.id in existing_cards:
                # Update existing card
                existing_cards[task.id].refresh_task(task)
            else:
                # Add new card
                task_list.mount(TaskCard(task, id=f"task-{task.id}"))

        # Show empty message if no tasks
        if not tasks:
            task_list.mount(Static("No tasks", classes="empty-message"))

        # Update header count
        header = self.query_one(".column-header", Static)
        header.update(f"{self.column.display_name} [dim]({len(tasks)})[/dim]")
