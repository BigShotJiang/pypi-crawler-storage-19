"""Modal dialogs for Kanban board."""

from typing import Optional

from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal, Grid, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import (
    Static, Button, Input, TextArea, Select, Label
)
from textual.message import Message

from emdash.db.models import TeamMember
from emdash.kanban.models import Task, Column, Priority, AIStatus


class AddTaskModal(ModalScreen[Task | None]):
    """Modal for adding a new task."""

    DEFAULT_CSS = """
    AddTaskModal {
        align: center middle;
    }

    AddTaskModal > Vertical {
        width: 60;
        height: auto;
        max-height: 80%;
        background: #2a1f18;
        border: thick #d35400;
        padding: 1 2;
    }

    AddTaskModal .modal-title {
        text-align: center;
        text-style: bold;
        padding: 1;
        background: #d35400;
        color: #ffffff;
        margin-bottom: 1;
    }

    AddTaskModal Label {
        margin-top: 1;
        color: #e67e22;
    }

    AddTaskModal Input, AddTaskModal TextArea, AddTaskModal Select {
        width: 100%;
        margin-bottom: 1;
        background: #1e1714;
        border: solid #5c3d2e;
        color: #f0e6dc;
    }

    AddTaskModal Input:focus, AddTaskModal TextArea:focus, AddTaskModal Select:focus {
        border: solid #e67e22;
    }

    AddTaskModal TextArea {
        height: 5;
    }

    AddTaskModal .button-row {
        margin-top: 1;
        align: center middle;
        height: 3;
    }

    AddTaskModal Button {
        margin: 0 1;
    }

    AddTaskModal Button#save {
        background: #d35400;
    }
    """

    BINDINGS = [
        ("escape", "cancel", "Cancel"),
    ]

    def __init__(
        self,
        column: Column = Column.TODO,
        team_members: Optional[list[TeamMember]] = None,
        **kwargs
    ) -> None:
        super().__init__(**kwargs)
        self.initial_column = column
        self.team_members = team_members or []

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("Add Task", classes="modal-title")

            yield Label("Title:")
            yield Input(placeholder="Task title...", id="title")

            yield Label("Description:")
            yield TextArea(id="description")

            with Horizontal():
                with Vertical():
                    yield Label("Column:")
                    yield Select(
                        [(col.display_name, col.value) for col in Column],
                        value=self.initial_column.value,
                        id="column",
                    )
                with Vertical():
                    yield Label("Priority:")
                    yield Select(
                        [("Low", "low"), ("Medium", "medium"), ("High", "high")],
                        value="medium",
                        id="priority",
                    )

            yield Label("Assignee:")
            if self.team_members:
                # Dropdown of team members
                options = [("Unassigned", "")]
                for member in self.team_members:
                    display = f"@{member.github_handle}" if member.github_handle else member.name
                    options.append((display, member.github_handle or member.name))
                yield Select(options, value="", id="assignee")
            else:
                yield Input(placeholder="@username", id="assignee")

            yield Label("Labels (comma separated):")
            yield Input(placeholder="bug, feature, urgent", id="labels")

            with Horizontal(classes="button-row"):
                yield Button("Cancel", variant="default", id="cancel")
                yield Button("Save", variant="primary", id="save")

    def on_mount(self) -> None:
        """Focus the title input on mount."""
        self.query_one("#title", Input).focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        if event.button.id == "cancel":
            self.dismiss(None)
        elif event.button.id == "save":
            self._save_task()

    def action_cancel(self) -> None:
        """Cancel the modal."""
        self.dismiss(None)

    def _save_task(self) -> None:
        """Create and return the task."""
        title = self.query_one("#title", Input).value.strip()
        if not title:
            self.notify("Title is required", severity="error")
            return

        description = self.query_one("#description", TextArea).text
        column = Column(self.query_one("#column", Select).value)
        priority = Priority(self.query_one("#priority", Select).value)

        # Get assignee from Select or Input depending on mode
        if self.team_members:
            assignee = self.query_one("#assignee", Select).value or ""
        else:
            assignee = self.query_one("#assignee", Input).value.strip().lstrip("@")

        labels_str = self.query_one("#labels", Input).value
        labels = [l.strip() for l in labels_str.split(",") if l.strip()]

        task = Task.create(
            title=title,
            description=description,
            column=column,
            priority=priority,
            assignee=assignee,
            labels=labels,
        )

        self.dismiss(task)


class ViewTaskModal(ModalScreen[str | None]):
    """Modal for viewing task details.

    Returns:
        "edit" - User wants to edit
        "delete" - User wants to delete
        "move" - User wants to move
        "plan" - User wants to generate plan
        "view_plan" - User wants to view existing plan
        None - User closed modal
    """

    DEFAULT_CSS = """
    ViewTaskModal {
        align: center middle;
    }

    ViewTaskModal > Vertical {
        width: 70;
        height: auto;
        max-height: 90%;
        background: #2a1f18;
        border: thick #d35400;
        padding: 1 2;
    }

    ViewTaskModal .modal-title {
        text-align: center;
        text-style: bold;
        padding: 1;
        background: #d35400;
        color: #ffffff;
        margin-bottom: 1;
    }

    ViewTaskModal .task-title {
        text-style: bold;
        padding: 1 0;
        color: #fdebd0;
    }

    ViewTaskModal .task-description {
        padding: 1;
        background: #1e1714;
        color: #f0e6dc;
        margin: 1 0;
        min-height: 3;
    }

    ViewTaskModal .detail-row {
        padding: 0;
        color: #f0e6dc;
    }

    ViewTaskModal .detail-label {
        color: #a67c52;
        width: 15;
    }

    ViewTaskModal .priority-high {
        color: #e74c3c;
    }

    ViewTaskModal .priority-medium {
        color: #f39c12;
    }

    ViewTaskModal .priority-low {
        color: #27ae60;
    }

    ViewTaskModal .spec-link {
        color: #e67e22;
    }

    ViewTaskModal .button-row {
        margin-top: 1;
        align: center middle;
        height: 3;
        width: 100%;
    }

    ViewTaskModal Button {
        margin: 0 1;
        min-width: 12;
        color: white;
    }

    ViewTaskModal Button#plan {
        background: #27ae60;
        color: white;
    }

    ViewTaskModal Button#view_plan {
        background: #3498db;
        color: white;
    }

    ViewTaskModal .plan-indicator {
        color: #27ae60;
        text-style: bold;
        padding: 1 0;
    }

    ViewTaskModal .buttons-container {
        height: auto;
        width: 100%;
    }

    ViewTaskModal .ai-status-box {
        background: #1a3a2a;
        border: solid #27ae60;
        padding: 1;
        margin: 1 0;
        height: auto;
        max-height: 15;
    }

    ViewTaskModal .ai-status-label {
        color: #27ae60;
        text-style: bold;
    }

    ViewTaskModal .ai-logs {
        background: #0d1a12;
        color: #7dcea0;
        padding: 1;
        height: auto;
        max-height: 10;
        overflow-y: auto;
    }

    ViewTaskModal Button#stop {
        background: #c0392b;
        color: white;
    }
    """

    BINDINGS = [
        ("escape", "close", "Close"),
        ("e", "edit", "Edit"),
        ("d", "delete", "Delete"),
        ("p", "plan", "Plan"),
    ]

    def __init__(self, task: Task, **kwargs) -> None:
        super().__init__(**kwargs)
        self.task_data = task  # Renamed to avoid conflict with ModalScreen.task

    def compose(self) -> ComposeResult:
        priority_class = f"priority-{self.task_data.priority.value}"
        priority_label = self.task_data.priority.value.upper()

        with Vertical():
            yield Static("Task Details", classes="modal-title")

            # Title with priority
            yield Static(
                f"[bold]{self.task_data.title}[/bold] [{priority_class}][{priority_label}][/{priority_class}]",
                classes="task-title"
            )

            # Description
            desc = self.task_data.description or "(No description)"
            yield Static(desc, classes="task-description")

            # Details
            with Horizontal(classes="detail-row"):
                yield Static("Column:", classes="detail-label")
                yield Static(self.task_data.column.display_name)

            with Horizontal(classes="detail-row"):
                yield Static("Assignee:", classes="detail-label")
                yield Static(f"@{self.task_data.assignee}" if self.task_data.assignee else "(unassigned)")

            with Horizontal(classes="detail-row"):
                yield Static("Labels:", classes="detail-label")
                labels = ", ".join(f"#{l}" for l in self.task_data.labels) if self.task_data.labels else "(none)"
                yield Static(labels)

            if self.task_data.spec_path:
                with Horizontal(classes="detail-row"):
                    yield Static("Spec:", classes="detail-label")
                    yield Static(self.task_data.spec_path, classes="spec-link")

            with Horizontal(classes="detail-row"):
                yield Static("Created:", classes="detail-label")
                yield Static(self.task_data.created_at.strftime("%Y-%m-%d %H:%M"))

            with Horizontal(classes="detail-row"):
                yield Static("Updated:", classes="detail-label")
                yield Static(self.task_data.updated_at.strftime("%Y-%m-%d %H:%M"))

            # AI Status indicator (if generating)
            if self.task_data.ai_status.is_active:
                with Vertical(classes="ai-status-box"):
                    yield Static(f"⏳ {self.task_data.ai_status.display_name}", classes="ai-status-label")
                    with VerticalScroll(classes="ai-logs", id="logs-scroll"):
                        yield Static("Starting...", id="ai-logs")

            # Spec indicator
            elif self.task_data.plan:
                yield Static("✓ Spec generated", classes="plan-indicator")

            # Buttons row 1
            with Horizontal(classes="button-row"):
                yield Button("Edit", variant="primary", id="edit")
                yield Button("Move", variant="default", id="move")
                yield Button("Delete", variant="error", id="delete")
                yield Button("Close", variant="default", id="close")

            # Buttons row 2 - Spec button (changes based on state)
            with Horizontal(classes="button-row"):
                if self.task_data.ai_status.is_active:
                    # Show stop button when generating
                    yield Button("Stop Generating", id="stop")
                elif self.task_data.plan:
                    yield Button("View Spec", id="view_plan")
                else:
                    yield Button("Generate Spec", id="plan")

    def on_mount(self) -> None:
        """Start log refresh timer if task is generating."""
        if self.task_data.ai_status.is_active:
            self.set_interval(0.5, self._refresh_logs)

    def _refresh_logs(self) -> None:
        """Refresh logs from the app."""
        try:
            logs = self.app.get_task_logs(self.task_data.id)
            if logs:
                scroll = self.query_one("#logs-scroll", VerticalScroll)
                # Check if user is at bottom before updating
                at_bottom = scroll.scroll_offset.y >= (scroll.max_scroll_y - 2)

                # Update log content
                log_widget = self.query_one("#ai-logs", Static)
                log_widget.update(logs)

                # Only auto-scroll if user was already at bottom
                if at_bottom:
                    scroll.scroll_end(animate=False)
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        self.dismiss(event.button.id)

    def action_close(self) -> None:
        self.dismiss(None)

    def action_edit(self) -> None:
        self.dismiss("edit")

    def action_delete(self) -> None:
        self.dismiss("delete")

    def action_plan(self) -> None:
        if self.task_data.plan:
            self.dismiss("view_plan")
        else:
            self.dismiss("plan")


class EditTaskModal(ModalScreen[Task | None]):
    """Modal for editing an existing task."""

    DEFAULT_CSS = """
    EditTaskModal {
        align: center middle;
    }

    EditTaskModal > Vertical {
        width: 60;
        height: auto;
        max-height: 80%;
        background: #2a1f18;
        border: thick #d35400;
        padding: 1 2;
    }

    EditTaskModal .modal-title {
        text-align: center;
        text-style: bold;
        padding: 1;
        background: #d35400;
        color: #ffffff;
        margin-bottom: 1;
    }

    EditTaskModal Label {
        margin-top: 1;
        color: #e67e22;
    }

    EditTaskModal Input, EditTaskModal TextArea, EditTaskModal Select {
        width: 100%;
        margin-bottom: 1;
        background: #1e1714;
        border: solid #5c3d2e;
        color: #f0e6dc;
    }

    EditTaskModal Input:focus, EditTaskModal TextArea:focus, EditTaskModal Select:focus {
        border: solid #e67e22;
    }

    EditTaskModal TextArea {
        height: 5;
    }

    EditTaskModal .button-row {
        margin-top: 1;
        align: center middle;
        height: 3;
    }

    EditTaskModal Button {
        margin: 0 1;
    }

    EditTaskModal Button#save {
        background: #d35400;
    }
    """

    BINDINGS = [
        ("escape", "cancel", "Cancel"),
    ]

    def __init__(
        self,
        task: Task,
        team_members: Optional[list[TeamMember]] = None,
        **kwargs
    ) -> None:
        super().__init__(**kwargs)
        self.task_data = task  # Renamed to avoid conflict with ModalScreen.task
        self.team_members = team_members or []

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("Edit Task", classes="modal-title")

            yield Label("Title:")
            yield Input(value=self.task_data.title, id="title")

            yield Label("Description:")
            yield TextArea(self.task_data.description, id="description")

            with Horizontal():
                with Vertical():
                    yield Label("Column:")
                    yield Select(
                        [(col.display_name, col.value) for col in Column],
                        value=self.task_data.column.value,
                        id="column",
                    )
                with Vertical():
                    yield Label("Priority:")
                    yield Select(
                        [("Low", "low"), ("Medium", "medium"), ("High", "high")],
                        value=self.task_data.priority.value,
                        id="priority",
                    )

            yield Label("Assignee:")
            if self.team_members:
                # Dropdown of team members
                options = [("Unassigned", "")]
                for member in self.team_members:
                    display = f"@{member.github_handle}" if member.github_handle else member.name
                    options.append((display, member.github_handle or member.name))
                yield Select(options, value=self.task_data.assignee or "", id="assignee")
            else:
                yield Input(value=self.task_data.assignee, placeholder="@username", id="assignee")

            yield Label("Labels (comma separated):")
            yield Input(value=", ".join(self.task_data.labels), id="labels")

            with Horizontal(classes="button-row"):
                yield Button("Cancel", variant="default", id="cancel")
                yield Button("Save", variant="primary", id="save")

    def on_mount(self) -> None:
        """Focus the title input on mount."""
        self.query_one("#title", Input).focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        if event.button.id == "cancel":
            self.dismiss(None)
        elif event.button.id == "save":
            self._save_task()

    def action_cancel(self) -> None:
        """Cancel the modal."""
        self.dismiss(None)

    def _save_task(self) -> None:
        """Update and return the task."""
        title = self.query_one("#title", Input).value.strip()
        if not title:
            self.notify("Title is required", severity="error")
            return

        # Update task fields
        self.task_data.title = title
        self.task_data.description = self.query_one("#description", TextArea).text
        self.task_data.column = Column(self.query_one("#column", Select).value)
        self.task_data.priority = Priority(self.query_one("#priority", Select).value)

        # Get assignee from Select or Input depending on mode
        if self.team_members:
            self.task_data.assignee = self.query_one("#assignee", Select).value or ""
        else:
            self.task_data.assignee = self.query_one("#assignee", Input).value.strip().lstrip("@")

        labels_str = self.query_one("#labels", Input).value
        self.task_data.labels = [l.strip() for l in labels_str.split(",") if l.strip()]

        self.dismiss(self.task_data)


class ConfirmDeleteModal(ModalScreen[bool]):
    """Modal for confirming task deletion."""

    DEFAULT_CSS = """
    ConfirmDeleteModal {
        align: center middle;
    }

    ConfirmDeleteModal > Vertical {
        width: 50;
        height: auto;
        background: #2a1f18;
        border: thick #c0392b;
        padding: 1 2;
    }

    ConfirmDeleteModal .modal-title {
        text-align: center;
        text-style: bold;
        padding: 1;
        background: #c0392b;
        color: #ffffff;
        margin-bottom: 1;
    }

    ConfirmDeleteModal .message {
        text-align: center;
        padding: 2;
        color: #f0e6dc;
    }

    ConfirmDeleteModal .button-row {
        margin-top: 1;
        align: center middle;
        height: 3;
    }

    ConfirmDeleteModal Button {
        margin: 0 1;
    }

    ConfirmDeleteModal Button#confirm {
        background: #c0392b;
    }
    """

    BINDINGS = [
        ("escape", "cancel", "Cancel"),
        ("y", "confirm", "Yes"),
        ("n", "cancel", "No"),
    ]

    def __init__(self, task: Task, **kwargs) -> None:
        super().__init__(**kwargs)
        self.task_data = task  # Renamed to avoid conflict with ModalScreen.task

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("Delete Task?", classes="modal-title")
            yield Static(
                f"Are you sure you want to delete:\n[bold]{self.task_data.title}[/bold]",
                classes="message"
            )
            with Horizontal(classes="button-row"):
                yield Button("No", variant="default", id="cancel")
                yield Button("Yes, Delete", variant="error", id="confirm")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        self.dismiss(event.button.id == "confirm")

    def action_cancel(self) -> None:
        self.dismiss(False)

    def action_confirm(self) -> None:
        self.dismiss(True)


class SettingsModal(ModalScreen[str | None]):
    """Modal for Kanban board settings - theme picker."""

    DEFAULT_CSS = """
    SettingsModal {
        align: center middle;
    }

    SettingsModal > Vertical {
        width: 70;
        height: auto;
        max-height: 85%;
        background: #1a1a1a;
        border: thick #e67e22;
        padding: 1 2;
    }

    SettingsModal .modal-title {
        text-align: center;
        text-style: bold;
        padding: 1;
        background: #e67e22;
        color: #ffffff;
        margin-bottom: 1;
    }

    SettingsModal .section-title {
        text-style: bold;
        color: #e67e22;
        padding: 1 0;
    }

    SettingsModal .theme-grid {
        height: 20;
        max-height: 20;
        padding: 1;
        scrollbar-gutter: stable;
    }

    SettingsModal .theme-card {
        width: 100%;
        height: 3;
        padding: 0 1;
        margin: 0 0 1 0;
        background: #2a2a2a;
        border: solid #444444;
    }

    SettingsModal .theme-card:hover {
        background: #3a3a3a;
    }

    SettingsModal .theme-card:focus {
        border: solid #e67e22;
        background: #3a3a3a;
    }

    SettingsModal .theme-card.selected {
        border: double #e67e22;
        background: #4a3a2a;
    }

    SettingsModal .theme-name {
        text-style: bold;
    }

    SettingsModal .theme-desc {
        color: #888888;
    }

    SettingsModal .button-row {
        margin-top: 1;
        align: center middle;
        height: 3;
    }

    SettingsModal Button {
        margin: 0 1;
    }

    SettingsModal .preview-box {
        height: 5;
        margin: 1 0;
        padding: 1;
        border: solid #444444;
    }
    """

    BINDINGS = [
        ("escape", "close", "Close"),
        ("up", "prev_theme", "Previous"),
        ("down", "next_theme", "Next"),
        ("enter", "select_theme", "Select"),
    ]

    def __init__(self, current_theme: str = "ember", **kwargs) -> None:
        super().__init__(**kwargs)
        self.current_theme = current_theme
        self.selected_index = 0
        self._theme_names = list(self._get_themes().keys())
        if current_theme in self._theme_names:
            self.selected_index = self._theme_names.index(current_theme)

    def _get_themes(self):
        from emdash.kanban.themes import THEMES
        return THEMES

    def compose(self) -> ComposeResult:
        from emdash.kanban.themes import THEMES

        with Vertical():
            yield Static("⚙️  Settings", classes="modal-title")

            yield Static("🎨 Choose Theme", classes="section-title")

            with VerticalScroll(classes="theme-grid"):
                for i, (key, theme) in enumerate(THEMES.items()):
                    is_current = key == self.current_theme
                    card_classes = "theme-card selected" if is_current else "theme-card"
                    card = Static(
                        f"{theme.emoji} [bold]{theme.name}[/bold] - [dim]{theme.description}[/dim]",
                        classes=card_classes,
                        id=f"theme-{key}",
                    )
                    card.can_focus = True
                    yield card

            # Preview box
            yield Static("Preview colors will apply when selected", classes="preview-box", id="preview")

            with Horizontal(classes="button-row"):
                yield Button("Cancel", variant="default", id="cancel")
                yield Button("Apply Theme", variant="primary", id="apply")

    def on_mount(self) -> None:
        """Focus current theme on mount."""
        try:
            card = self.query_one(f"#theme-{self.current_theme}")
            card.focus()
        except Exception:
            pass

    def on_static_focus(self, event) -> None:
        """Handle theme card focus."""
        # Update selection visual
        for card in self.query(".theme-card"):
            card.remove_class("selected")
        event.static.add_class("selected")

        # Extract theme key from id and update index
        if event.static.id and event.static.id.startswith("theme-"):
            theme_key = event.static.id.replace("theme-", "")
            if theme_key in self._theme_names:
                self.selected_index = self._theme_names.index(theme_key)
            self._update_preview(theme_key)

    def _update_preview(self, theme_key: str) -> None:
        """Update the preview box with theme colors."""
        from emdash.kanban.themes import get_theme
        theme = get_theme(theme_key)
        preview = self.query_one("#preview", Static)
        preview.styles.background = theme.surface
        preview.styles.border = ("solid", theme.primary)
        preview.styles.color = theme.text
        preview.update(
            f"[{theme.primary}]■[/{theme.primary}] Primary  "
            f"[{theme.accent}]■[/{theme.accent}] Accent  "
            f"[{theme.priority_high}]■[/{theme.priority_high}] High  "
            f"[{theme.priority_medium}]■[/{theme.priority_medium}] Med  "
            f"[{theme.priority_low}]■[/{theme.priority_low}] Low"
        )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        if event.button.id == "cancel":
            self.dismiss(None)
        elif event.button.id == "apply":
            # Find selected theme
            for card in self.query(".theme-card"):
                if "selected" in card.classes and card.id:
                    theme_key = card.id.replace("theme-", "")
                    self.dismiss(theme_key)
                    return
            self.dismiss(None)

    def action_close(self) -> None:
        self.dismiss(None)

    def action_prev_theme(self) -> None:
        """Move to previous theme in list."""
        if self.selected_index > 0:
            self.selected_index -= 1
            theme_key = self._theme_names[self.selected_index]
            try:
                card = self.query_one(f"#theme-{theme_key}")
                card.focus()
            except Exception:
                pass

    def action_next_theme(self) -> None:
        """Move to next theme in list."""
        if self.selected_index < len(self._theme_names) - 1:
            self.selected_index += 1
            theme_key = self._theme_names[self.selected_index]
            try:
                card = self.query_one(f"#theme-{theme_key}")
                card.focus()
            except Exception:
                pass

    def action_select_theme(self) -> None:
        """Select the currently focused theme."""
        focused = self.focused
        if focused and hasattr(focused, 'id') and focused.id and focused.id.startswith("theme-"):
            theme_key = focused.id.replace("theme-", "")
            self.dismiss(theme_key)

    def on_key(self, event) -> None:
        """Handle Enter key on theme cards."""
        if event.key == "enter":
            focused = self.focused
            if focused and hasattr(focused, 'id') and focused.id and focused.id.startswith("theme-"):
                theme_key = focused.id.replace("theme-", "")
                self.dismiss(theme_key)
                event.stop()


class PlanModal(ModalScreen[None]):
    """Modal for displaying task spec in markdown format."""

    DEFAULT_CSS = """
    PlanModal {
        align: center middle;
    }

    PlanModal > Vertical {
        width: 90%;
        height: 85%;
        background: #1e1714;
        border: thick #27ae60;
        padding: 1 2;
    }

    PlanModal .modal-title {
        text-align: center;
        text-style: bold;
        padding: 1;
        background: #27ae60;
        color: #ffffff;
        margin-bottom: 1;
    }

    PlanModal .plan-content {
        height: 1fr;
        padding: 1;
        background: #2a1f18;
        color: #f0e6dc;
        border: solid #5c3d2e;
    }

    PlanModal .button-row {
        margin-top: 1;
        align: center middle;
        height: 3;
    }

    PlanModal Button {
        margin: 0 1;
    }
    """

    BINDINGS = [
        ("escape", "close", "Close"),
    ]

    def __init__(self, task: Task, **kwargs) -> None:
        super().__init__(**kwargs)
        self.task_data = task

    def compose(self) -> ComposeResult:
        from textual.widgets import Markdown as TextualMarkdown

        with Vertical():
            yield Static(f"📋 Spec: {self.task_data.title[:40]}...", classes="modal-title")

            # Display spec as markdown
            yield TextualMarkdown(self.task_data.plan or "*No spec generated yet*", classes="plan-content")

            with Horizontal(classes="button-row"):
                yield Button("Close", variant="default", id="close")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        self.dismiss(None)

    def action_close(self) -> None:
        self.dismiss(None)


class PlanRunningModal(ModalScreen[str | None]):
    """Modal showing plan generation progress."""

    DEFAULT_CSS = """
    PlanRunningModal {
        align: center middle;
    }

    PlanRunningModal > Vertical {
        width: 60;
        height: auto;
        background: #1e1714;
        border: thick #27ae60;
        padding: 2;
    }

    PlanRunningModal .modal-title {
        text-align: center;
        text-style: bold;
        padding: 1;
        background: #27ae60;
        color: #ffffff;
        margin-bottom: 1;
    }

    PlanRunningModal .status {
        text-align: center;
        padding: 2;
        color: #f0e6dc;
    }

    PlanRunningModal .spinner {
        text-align: center;
        color: #27ae60;
        text-style: bold;
    }

    PlanRunningModal .button-row {
        margin-top: 1;
        align: center middle;
        height: 3;
    }

    PlanRunningModal Button#minimize {
        background: #3498db;
    }
    """

    BINDINGS = [
        ("escape", "cancel", "Cancel"),
        ("m", "minimize", "Minimize"),
    ]

    def __init__(self, task: Task, **kwargs) -> None:
        super().__init__(**kwargs)
        self.task_data = task
        self.plan_output = ""
        self._plan_running = True

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("⚙️  Generating Spec", classes="modal-title")
            yield Static("▶ Running emdash spec --save...", classes="spinner", id="spinner")
            yield Static(f"Task: {self.task_data.title[:50]}...", classes="status")
            yield Static("[dim]Press M to minimize and continue working[/dim]", classes="status")
            with Horizontal(classes="button-row"):
                yield Button("Minimize", id="minimize")
                yield Button("Cancel", variant="error", id="cancel")

    def on_mount(self) -> None:
        """Start the plan generation when modal mounts."""
        self.run_worker(self._generate_plan(), exclusive=True)

    async def _generate_plan(self) -> None:
        """Run the emdash spec --save command."""
        import asyncio

        # Close database connection to avoid lock conflict
        try:
            from emdash.graph.connection import close_connection
            close_connection()
        except Exception:
            pass

        # Build the prompt from task title and description
        prompt = f"{self.task_data.title}"
        if self.task_data.description:
            prompt += f" - {self.task_data.description}"

        try:
            # Get repo_root from app
            repo_root = getattr(self.app, 'repo_root', None)
            cwd = str(repo_root) if repo_root else None

            # Run emdash spec --save command in repo root
            process = await asyncio.create_subprocess_exec(
                "emdash", "spec", prompt, "--save",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
            )

            stdout, stderr = await process.communicate()

            if process.returncode == 0:
                self.plan_output = stdout.decode("utf-8")
                self._plan_running = False
                self.dismiss(self.plan_output)
            else:
                error = stderr.decode("utf-8") if stderr else "Unknown error"
                self._plan_running = False
                self.notify(f"Spec generation failed: {error}", severity="error")
                self.dismiss(None)

        except FileNotFoundError:
            self._plan_running = False
            self.notify("emdash command not found", severity="error")
            self.dismiss(None)
        except Exception as e:
            self._plan_running = False
            self.notify(f"Error: {e}", severity="error")
            self.dismiss(None)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        if event.button.id == "cancel":
            self._plan_running = False
            self.dismiss(None)
        elif event.button.id == "minimize":
            # Return special value to indicate minimized - background processing continues
            self.dismiss("__minimized__")

    def action_cancel(self) -> None:
        self._plan_running = False
        self.dismiss(None)

    def action_minimize(self) -> None:
        """Minimize modal and continue in background."""
        self.dismiss("__minimized__")
