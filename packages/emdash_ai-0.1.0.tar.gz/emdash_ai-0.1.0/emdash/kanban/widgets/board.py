"""Kanban board widget containing all columns."""

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.message import Message

from emdash.kanban.models import Board, Column, Task
from emdash.kanban.widgets.column import KanbanColumn
from emdash.kanban.widgets.card import TaskCard


class KanbanBoard(Horizontal):
    """The main Kanban board containing all columns."""

    DEFAULT_CSS = """
    KanbanBoard {
        width: 100%;
        height: 100%;
        padding: 0;
    }
    """

    COLUMNS = [Column.TODO, Column.DESIGN_REVIEW, Column.IN_PROGRESS, Column.IN_PR]

    def __init__(self, board: Board, **kwargs) -> None:
        super().__init__(**kwargs)
        self.board = board

    def compose(self) -> ComposeResult:
        """Create the columns."""
        for column in self.COLUMNS:
            tasks = self.board.get_tasks_by_column(column)
            yield KanbanColumn(column, tasks, id=f"column-{column.value}")

    def get_column(self, column: Column) -> KanbanColumn:
        """Get a column widget by column type."""
        return self.query_one(f"#column-{column.value}", KanbanColumn)

    def refresh_board(self, board: Board) -> None:
        """Refresh all columns with updated board data."""
        self.board = board
        for column in self.COLUMNS:
            tasks = board.get_tasks_by_column(column)
            col_widget = self.get_column(column)
            col_widget.refresh_tasks(tasks)

    def get_all_cards(self) -> list[TaskCard]:
        """Get all task cards across all columns."""
        return list(self.query(TaskCard))

    def focus_task(self, task_id: str) -> None:
        """Focus a specific task card."""
        try:
            card = self.query_one(f"#task-{task_id}", TaskCard)
            card.focus()
        except Exception:
            pass

    def focus_first_in_column(self, column: Column) -> bool:
        """Focus the first task in a column. Returns True if successful."""
        col_widget = self.get_column(column)
        cards = col_widget.get_task_cards()
        if cards:
            cards[0].focus()
            return True
        return False
