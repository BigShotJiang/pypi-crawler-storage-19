"""Task card widget for Kanban board."""

from textual.app import ComposeResult
from textual.widgets import Static
from textual.containers import Vertical
from textual.message import Message
from textual import on

from emdash.kanban.models import Task, Priority, AIStatus


class TaskCard(Static):
    """A task card displayed in a Kanban column."""

    DEFAULT_CSS = """
    TaskCard {
        width: 100%;
        height: auto;
        min-height: 3;
        margin: 0 0 1 0;
        padding: 0 1;
    }

    TaskCard .title {
        text-style: bold;
    }

    TaskCard .ai-status {
        color: #27ae60;
        text-style: italic;
    }
    """

    class Selected(Message):
        """Posted when card is selected."""
        def __init__(self, task: Task) -> None:
            self.task = task
            super().__init__()

    class Activated(Message):
        """Posted when card is activated (Enter pressed)."""
        def __init__(self, task: Task) -> None:
            self.task = task
            super().__init__()

    def __init__(self, task_data: Task, **kwargs) -> None:
        super().__init__(**kwargs)
        self.task_data = task_data  # Renamed to avoid conflict with Static.task
        self.can_focus = True

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        # Build card content
        priority_class = f"priority-{self.task_data.priority.value}"
        priority_icon = {"high": "[H]", "medium": "[M]", "low": "[L]"}[self.task_data.priority.value]

        # Add plan indicator if plan exists
        plan_icon = "📋 " if self.task_data.plan else ""

        # Add AI status indicator if active
        ai_icon = "⏳ " if self.task_data.ai_status.is_active else ""

        content = f"[bold]{self.task_data.title}[/bold]"

        # Add priority indicator, plan icon, and AI icon
        yield Static(f"{ai_icon}{plan_icon}{priority_icon} {content}", classes="title")

        # Show AI status if active
        if self.task_data.ai_status.is_active:
            yield Static(f"⚙️ {self.task_data.ai_status.display_name}", classes="ai-status")

        # Add labels if any
        if self.task_data.labels:
            labels_str = " ".join(f"#{label}" for label in self.task_data.labels[:3])
            yield Static(labels_str, classes="labels")

        # Add assignee if any
        if self.task_data.assignee:
            yield Static(f"@{self.task_data.assignee}", classes="assignee")

    def on_focus(self) -> None:
        """Handle focus."""
        self.add_class("selected")
        # Apply focus colors from theme
        try:
            from emdash.kanban.themes import get_theme
            theme_name = getattr(self.app, 'current_theme_name', 'ember')
            theme = get_theme(theme_name)
            self.styles.border = ("solid", theme.border_focus)
            self.styles.background = theme.surface_light
        except Exception:
            pass
        self.post_message(self.Selected(self.task_data))

    def on_blur(self) -> None:
        """Handle blur."""
        self.remove_class("selected")
        # Reset to normal theme colors
        try:
            from emdash.kanban.themes import get_theme
            theme_name = getattr(self.app, 'current_theme_name', 'ember')
            theme = get_theme(theme_name)
            self.styles.border = ("solid", theme.border)
            self.styles.background = theme.surface
        except Exception:
            pass

    def on_key(self, event) -> None:
        """Handle key press."""
        if event.key == "enter":
            self.post_message(self.Activated(self.task_data))
            event.stop()

    def refresh_task(self, task_data: Task) -> None:
        """Update the displayed task."""
        self.task_data = task_data
        # Remove old children and re-compose
        self.remove_children()
        # Re-add children with updated data
        priority_icon = {"high": "[H]", "medium": "[M]", "low": "[L]"}[self.task_data.priority.value]
        plan_icon = "📋 " if self.task_data.plan else ""
        ai_icon = "⏳ " if self.task_data.ai_status.is_active else ""
        content = f"[bold]{self.task_data.title}[/bold]"

        self.mount(Static(f"{ai_icon}{plan_icon}{priority_icon} {content}", classes="title"))

        if self.task_data.ai_status.is_active:
            self.mount(Static(f"⚙️ {self.task_data.ai_status.display_name}", classes="ai-status"))

        if self.task_data.labels:
            labels_str = " ".join(f"#{label}" for label in self.task_data.labels[:3])
            self.mount(Static(labels_str, classes="labels"))

        if self.task_data.assignee:
            self.mount(Static(f"@{self.task_data.assignee}", classes="assignee"))
