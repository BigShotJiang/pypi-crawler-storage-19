"""Data models for Kanban board - Business Logic Layer."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional
import uuid


class Priority(str, Enum):
    """Task priority levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

    def next(self) -> "Priority":
        """Cycle to next priority level."""
        cycle = [Priority.LOW, Priority.MEDIUM, Priority.HIGH]
        idx = cycle.index(self)
        return cycle[(idx + 1) % len(cycle)]


class AIStatus(str, Enum):
    """AI processing status for tasks."""
    IDLE = "idle"
    GENERATING_SPEC = "generating_spec"
    GENERATING_TASKS = "generating_tasks"
    IMPLEMENTING = "implementing"
    REVIEWING = "reviewing"

    @property
    def display_name(self) -> str:
        """Human-readable status name."""
        names = {
            AIStatus.IDLE: "",
            AIStatus.GENERATING_SPEC: "Generating Spec...",
            AIStatus.GENERATING_TASKS: "Generating Tasks...",
            AIStatus.IMPLEMENTING: "Implementing...",
            AIStatus.REVIEWING: "Reviewing...",
        }
        return names[self]

    @property
    def is_active(self) -> bool:
        """Check if AI is actively processing."""
        return self != AIStatus.IDLE


class Column(str, Enum):
    """Kanban board columns."""
    TODO = "todo"
    DESIGN_REVIEW = "design-review"
    IN_PROGRESS = "in-progress"
    IN_PR = "in-pr"

    @property
    def display_name(self) -> str:
        """Human-readable column name."""
        names = {
            Column.TODO: "Todo",
            Column.DESIGN_REVIEW: "Design Review",
            Column.IN_PROGRESS: "In Progress",
            Column.IN_PR: "In-PR",
        }
        return names[self]

    def next(self) -> Optional["Column"]:
        """Get next column (move right)."""
        order = [Column.TODO, Column.DESIGN_REVIEW, Column.IN_PROGRESS, Column.IN_PR]
        idx = order.index(self)
        if idx < len(order) - 1:
            return order[idx + 1]
        return None

    def prev(self) -> Optional["Column"]:
        """Get previous column (move left)."""
        order = [Column.TODO, Column.DESIGN_REVIEW, Column.IN_PROGRESS, Column.IN_PR]
        idx = order.index(self)
        if idx > 0:
            return order[idx - 1]
        return None


@dataclass
class Task:
    """A task on the Kanban board."""
    id: str
    title: str
    description: str = ""
    column: Column = Column.TODO
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    labels: list[str] = field(default_factory=list)
    assignee: str = ""
    priority: Priority = Priority.MEDIUM
    spec_path: str = ""  # Link to spec file
    plan: str = ""  # Generated implementation plan (markdown)
    ai_status: AIStatus = AIStatus.IDLE  # Current AI processing status

    @classmethod
    def create(
        cls,
        title: str,
        description: str = "",
        column: Column = Column.TODO,
        labels: list[str] = None,
        assignee: str = "",
        priority: Priority = Priority.MEDIUM,
        spec_path: str = "",
        plan: str = "",
        ai_status: AIStatus = AIStatus.IDLE,
    ) -> "Task":
        """Create a new task with generated ID."""
        now = datetime.now()
        return cls(
            id=str(uuid.uuid4()),
            title=title,
            description=description,
            column=column,
            created_at=now,
            updated_at=now,
            labels=labels or [],
            assignee=assignee,
            priority=priority,
            spec_path=spec_path,
            plan=plan,
            ai_status=ai_status,
        )

    def to_dict(self) -> dict:
        """Serialize task to dictionary."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "column": self.column.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "labels": self.labels,
            "assignee": self.assignee,
            "priority": self.priority.value,
            "spec_path": self.spec_path,
            "plan": self.plan,
            "ai_status": self.ai_status.value,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Task":
        """Deserialize task from dictionary."""
        return cls(
            id=data["id"],
            title=data["title"],
            description=data.get("description", ""),
            column=Column(data.get("column", "todo")),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
            labels=data.get("labels", []),
            assignee=data.get("assignee", ""),
            priority=Priority(data.get("priority", "medium")),
            spec_path=data.get("spec_path", ""),
            plan=data.get("plan", ""),
            ai_status=AIStatus(data.get("ai_status", "idle")),
        )


@dataclass
class Board:
    """Kanban board containing tasks."""
    tasks: list[Task] = field(default_factory=list)

    def add_task(
        self,
        title: str,
        description: str = "",
        column: Column = Column.TODO,
        labels: list[str] = None,
        assignee: str = "",
        priority: Priority = Priority.MEDIUM,
        spec_path: str = "",
        plan: str = "",
    ) -> Task:
        """Add a new task to the board."""
        task = Task.create(
            title=title,
            description=description,
            column=column,
            labels=labels,
            assignee=assignee,
            priority=priority,
            spec_path=spec_path,
            plan=plan,
        )
        self.tasks.append(task)
        return task

    def get_task(self, task_id: str) -> Optional[Task]:
        """Get a task by ID."""
        for task in self.tasks:
            if task.id == task_id:
                return task
        return None

    def move_task(self, task_id: str, to_column: Column) -> Optional[Task]:
        """Move a task to a different column."""
        task = self.get_task(task_id)
        if task:
            task.column = to_column
            task.updated_at = datetime.now()
            return task
        return None

    def update_task(self, task_id: str, **updates) -> Optional[Task]:
        """Update task fields."""
        task = self.get_task(task_id)
        if task:
            for key, value in updates.items():
                if hasattr(task, key):
                    setattr(task, key, value)
            task.updated_at = datetime.now()
            return task
        return None

    def delete_task(self, task_id: str) -> bool:
        """Delete a task by ID."""
        for i, task in enumerate(self.tasks):
            if task.id == task_id:
                self.tasks.pop(i)
                return True
        return False

    def get_tasks_by_column(self, column: Column) -> list[Task]:
        """Get all tasks in a specific column."""
        return [t for t in self.tasks if t.column == column]

    def link_to_spec(self, task_id: str, spec_path: str) -> Optional[Task]:
        """Link a task to a specification file."""
        return self.update_task(task_id, spec_path=spec_path)

    def to_dict(self) -> dict:
        """Serialize board to dictionary."""
        return {
            "tasks": [t.to_dict() for t in self.tasks]
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Board":
        """Deserialize board from dictionary."""
        tasks = [Task.from_dict(t) for t in data.get("tasks", [])]
        return cls(tasks=tasks)
