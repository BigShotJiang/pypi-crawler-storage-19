"""Supabase-backed Kanban store."""

import asyncio
from pathlib import Path
from typing import Optional

from emdash.db.models import Feature, FeatureStatus, TeamMember
from emdash.db.providers.supabase import SupabaseProvider
from emdash.kanban.converters import (
    column_to_status,
    feature_to_task,
    task_to_feature_data,
    task_update_to_feature_data,
)
from emdash.kanban.models import Board, Task


DEFAULT_SETTINGS = {
    "theme": "ember",
}


class SupabaseKanbanStore:
    """Kanban store backed by Supabase database.

    Maps Kanban Tasks to Supabase Features.
    """

    def __init__(
        self,
        provider: SupabaseProvider,
        project_id: str,
        team_members: Optional[list[TeamMember]] = None,
    ):
        """Initialize the store.

        Args:
            provider: Supabase database provider
            project_id: The project ID to load features from
            team_members: List of team members for assignee selection
        """
        self.provider = provider
        self.project_id = project_id
        self.team_members = team_members or []
        self._settings = DEFAULT_SETTINGS.copy()

    def _run_async(self, coro):
        """Run an async coroutine synchronously.

        Needed because Textual's event handlers aren't async.
        """
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # Create a new event loop for this thread
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    future = pool.submit(asyncio.run, coro)
                    return future.result()
            else:
                return loop.run_until_complete(coro)
        except RuntimeError:
            return asyncio.run(coro)

    def load(self) -> Board:
        """Load features from Supabase as a Kanban Board.

        Returns:
            Board containing tasks (features converted to tasks)
        """
        features = self._run_async(
            self.provider.list_features(self.project_id, include_relations=True)
        )

        tasks = []
        for feature in features:
            # Skip DONE features (they won't appear on the board)
            if feature.status == FeatureStatus.DONE:
                continue
            task = feature_to_task(feature)
            if task:
                tasks.append(task)

        return Board(tasks=tasks)

    def save(self, board: Board) -> None:
        """Save is a no-op for Supabase store.

        Individual operations (add, update, delete) handle their own persistence.
        This method exists for API compatibility with KanbanStore.
        """
        pass

    def add_task(self, task: Task) -> Task:
        """Add a new task to Supabase.

        Args:
            task: Task to add

        Returns:
            Task with ID assigned by database
        """
        data = task_to_feature_data(task, self.project_id)
        feature = self._run_async(
            self.provider.create_feature(
                project_id=data["project_id"],
                title=data["title"],
                description=data.get("description"),
                status=FeatureStatus(data["status"]),
                spec=data.get("spec"),
            )
        )

        # Update task with the database-assigned ID
        task.id = feature.id
        return task

    def update_task(self, task: Task) -> Optional[Task]:
        """Update an existing task in Supabase.

        Args:
            task: Task with updated fields

        Returns:
            Updated task, or None if not found
        """
        data = task_update_to_feature_data(task)
        feature = self._run_async(
            self.provider.update_feature(
                feature_id=task.id,
                title=data["title"],
                description=data.get("description"),
                status=FeatureStatus(data["status"]),
                spec=data.get("spec"),
            )
        )

        if feature:
            return task
        return None

    def delete_task(self, task_id: str) -> bool:
        """Delete a task from Supabase.

        Args:
            task_id: ID of task to delete

        Returns:
            True if deleted, False if not found
        """
        return self._run_async(self.provider.delete_feature(task_id))

    def move_task(self, task_id: str, task: Task) -> Optional[Task]:
        """Move a task to a different column.

        Args:
            task_id: ID of task to move
            task: Task with updated column

        Returns:
            Updated task, or None if not found
        """
        status = column_to_status(task.column)
        feature = self._run_async(
            self.provider.update_feature(feature_id=task_id, status=status)
        )

        if feature:
            return task
        return None

    def assign_task(self, task_id: str, team_member_id: str) -> bool:
        """Assign a team member to a task.

        Args:
            task_id: Feature ID
            team_member_id: TeamMember ID to assign

        Returns:
            True if successful
        """
        try:
            self._run_async(
                self.provider.assign_feature(task_id, team_member_id)
            )
            return True
        except Exception:
            return False

    def unassign_task(self, task_id: str, team_member_id: str) -> bool:
        """Remove a team member assignment from a task.

        Args:
            task_id: Feature ID
            team_member_id: TeamMember ID to unassign

        Returns:
            True if successful
        """
        return self._run_async(
            self.provider.unassign_feature(task_id, team_member_id)
        )

    def get_theme(self) -> str:
        """Get current theme name."""
        return self._settings.get("theme", "ember")

    def set_theme(self, theme: str) -> None:
        """Set theme name (stored locally, not in Supabase)."""
        self._settings["theme"] = theme

    def get_team_member_by_id(self, member_id: str) -> Optional[TeamMember]:
        """Get a team member by ID from cached list.

        Args:
            member_id: TeamMember ID

        Returns:
            TeamMember or None if not found
        """
        for member in self.team_members:
            if member.id == member_id:
                return member
        return None

    def get_team_member_by_github(self, github_handle: str) -> Optional[TeamMember]:
        """Get a team member by GitHub handle from cached list.

        Args:
            github_handle: GitHub username

        Returns:
            TeamMember or None if not found
        """
        for member in self.team_members:
            if member.github_handle == github_handle:
                return member
        return None
