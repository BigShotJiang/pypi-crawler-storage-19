"""Kanban App - Main Textual Application."""

from pathlib import Path
from typing import Optional, Union

from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, Static
from textual.containers import Vertical
from textual.binding import Binding
from textual import on

from emdash.db.models import Project, TeamMember
from emdash.kanban.models import Board, Task, Column, Priority
from emdash.kanban.store import KanbanStore
from emdash.kanban.themes import get_theme
from emdash.kanban.widgets.board import KanbanBoard
from emdash.kanban.widgets.card import TaskCard
from emdash.kanban.widgets.modals import (
    AddTaskModal,
    ViewTaskModal,
    EditTaskModal,
    ConfirmDeleteModal,
    SettingsModal,
    PlanModal,
    PlanRunningModal,
)


class KanbanApp(App):
    """Terminal Kanban board application."""

    TITLE = "EmDash Kanban"

    CSS = """
    #main-content {
        width: 100%;
        height: 100%;
    }
    """

    BINDINGS = [
        Binding("a", "add_task", "Add Task", show=True),
        Binding("q", "quit", "Quit", show=True),
        Binding("escape", "quit", "Quit", show=False),
        Binding("left", "move_left", "Move Left", show=True),
        Binding("right", "move_right", "Move Right", show=True),
        Binding("d", "delete_task", "Delete", show=True),
        Binding("p", "cycle_priority", "Priority", show=True),
        Binding("t", "open_settings", "Theme", show=True),
        Binding("1", "goto_column_1", "Todo", show=False),
        Binding("2", "goto_column_2", "Design", show=False),
        Binding("3", "goto_column_3", "Progress", show=False),
        Binding("4", "goto_column_4", "PR", show=False),
    ]

    def __init__(
        self,
        repo_root: Optional[Path] = None,
        supabase_store: Optional["SupabaseKanbanStore"] = None,
        project: Optional[Project] = None,
        team_members: Optional[list[TeamMember]] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.repo_root = repo_root or Path.cwd()

        # Supabase mode if store provided
        self.supabase_mode = supabase_store is not None
        self.project = project
        self.team_members = team_members or []

        if supabase_store:
            self.store: Union[KanbanStore, "SupabaseKanbanStore"] = supabase_store
        else:
            self.store = KanbanStore(self.repo_root)

        self.board = self.store.load()
        self.selected_task: Optional[Task] = None
        self.current_theme_name = self.store.get_theme()
        # Store logs for tasks being processed
        self._task_logs: dict[str, str] = {}
        # Track running subprocesses for cleanup
        self._running_processes: dict[str, "asyncio.subprocess.Process"] = {}
        # Track Ctrl+C presses for force quit
        self._ctrl_c_count = 0
        self._ctrl_c_timer = None

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Header()
        with Vertical(id="main-content"):
            yield KanbanBoard(self.board, id="kanban-board")
        yield Footer()

    def on_mount(self) -> None:
        """Apply theme and focus first task on mount."""
        # Apply theme after widgets are ready
        self.call_after_refresh(self._apply_full_theme)

        # Focus first task in any column
        board_widget = self.query_one("#kanban-board", KanbanBoard)
        for col in Column:
            if board_widget.focus_first_in_column(col):
                break

    def _apply_full_theme(self) -> None:
        """Apply current theme to ALL widgets."""
        self._apply_theme(self.current_theme_name)

    def _apply_theme(self, theme_name: str) -> None:
        """Apply theme colors to ALL widgets comprehensively."""
        from emdash.kanban.widgets.column import KanbanColumn

        theme = get_theme(theme_name)

        # Apply to screen
        self.styles.background = theme.background

        # Apply to header
        try:
            header = self.query_one("Header")
            header.styles.background = theme.primary
            header.styles.color = theme.text_on_primary
        except Exception:
            pass

        # Apply to footer
        try:
            footer = self.query_one("Footer")
            footer.styles.background = theme.surface_dark
            footer.styles.color = theme.primary_light
        except Exception:
            pass

        # Apply to ALL columns
        for column in self.query(KanbanColumn):
            column.styles.background = theme.surface_dark
            column.styles.border = ("solid", theme.border)
            # Column header
            try:
                col_header = column.query_one(".column-header")
                col_header.styles.background = theme.surface
                col_header.styles.color = theme.primary_light
            except Exception:
                pass
            # Empty message
            try:
                empty_msg = column.query_one(".empty-message")
                empty_msg.styles.color = theme.text_muted
            except Exception:
                pass

        # Apply to ALL task cards
        for card in self.query(TaskCard):
            card.styles.background = theme.surface
            card.styles.border = ("solid", theme.border)
            card.styles.color = theme.text
            # Title
            try:
                title = card.query_one(".title")
                title.styles.color = theme.text
            except Exception:
                pass
            # Labels
            try:
                labels = card.query_one(".labels")
                labels.styles.color = theme.text_muted
            except Exception:
                pass
            # Assignee
            try:
                assignee = card.query_one(".assignee")
                assignee.styles.color = theme.primary_light
            except Exception:
                pass

        self.refresh(layout=True)

    @on(TaskCard.Selected)
    def on_task_selected(self, event: TaskCard.Selected) -> None:
        """Handle task selection."""
        self.selected_task = event.task

    @on(TaskCard.Activated)
    def on_task_activated(self, event: TaskCard.Activated) -> None:
        """Handle task activation (Enter pressed)."""
        self._show_view_modal(event.task)

    def _show_view_modal(self, task: Task) -> None:
        """Show the view task modal."""
        def handle_view_result(result: str | None) -> None:
            if result == "edit":
                self._show_edit_modal(task)
            elif result == "delete":
                self._show_delete_modal(task)
            elif result == "move":
                self._move_task_right(task)
            elif result == "plan":
                self._show_plan_running_modal(task)
            elif result == "view_plan":
                self._show_plan_modal(task)
            elif result == "stop":
                self._stop_generating(task)

        self.push_screen(ViewTaskModal(task), handle_view_result)

    def _show_edit_modal(self, task: Task) -> None:
        """Show the edit task modal."""
        def handle_edit_result(result: Task | None) -> None:
            if result:
                # Update task in board
                self.board.update_task(
                    task.id,
                    title=result.title,
                    description=result.description,
                    column=result.column,
                    priority=result.priority,
                    assignee=result.assignee,
                    labels=result.labels,
                )

                if self.supabase_mode:
                    # In Supabase mode, update via store
                    from emdash.kanban.supabase_store import SupabaseKanbanStore
                    if isinstance(self.store, SupabaseKanbanStore):
                        self.store.update_task(result)

                self._save_and_refresh()
                self.notify(f"Updated: {result.title}")

        self.push_screen(
            EditTaskModal(task, team_members=self.team_members),
            handle_edit_result
        )

    def _show_delete_modal(self, task: Task) -> None:
        """Show delete confirmation modal."""
        def handle_delete_result(confirmed: bool) -> None:
            if confirmed:
                if self.supabase_mode:
                    # Delete from Supabase first
                    from emdash.kanban.supabase_store import SupabaseKanbanStore
                    if isinstance(self.store, SupabaseKanbanStore):
                        self.store.delete_task(task.id)

                self.board.delete_task(task.id)
                self._save_and_refresh()
                self.notify(f"Deleted: {task.title}", severity="warning")

        self.push_screen(ConfirmDeleteModal(task), handle_delete_result)

    def _show_plan_modal(self, task: Task) -> None:
        """Show the plan viewing modal."""
        self.push_screen(PlanModal(task))

    def _show_plan_running_modal(self, task: Task) -> None:
        """Show the plan generation modal and run the agent."""
        from emdash.kanban.models import AIStatus

        def handle_plan_result(plan_output: str | None) -> None:
            if plan_output == "__minimized__":
                # User minimized - run in background
                self._run_spec_in_background(task)
            elif plan_output:
                # Spec completed while modal was open
                self._handle_spec_complete(task, plan_output)

        self.push_screen(PlanRunningModal(task), handle_plan_result)

    def _run_spec_in_background(self, task: Task) -> None:
        """Run spec generation in background."""
        from emdash.kanban.models import AIStatus

        # Close database connection to avoid lock conflict with subprocess
        try:
            from emdash.graph.connection import close_connection
            close_connection()
        except Exception:
            pass

        # Set AI status to generating
        self.board.update_task(task.id, ai_status=AIStatus.GENERATING_SPEC)
        self._save_and_refresh()
        self.notify("Spec generation continues in background...")

        # Start background worker
        self.run_worker(self._generate_spec_async(task), exclusive=False)

    async def _generate_spec_async(self, task: Task) -> None:
        """Generate spec asynchronously in background."""
        import asyncio
        from emdash.kanban.models import AIStatus

        # Initialize logs for this task
        self._task_logs[task.id] = ""

        # Build the prompt from task title and description
        prompt = f"{task.title}"
        if task.description:
            prompt += f" - {task.description}"

        try:
            # Run emdash spec --save command in repo root
            process = await asyncio.create_subprocess_exec(
                "emdash", "spec", prompt, "--save",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,  # Combine stderr into stdout
                cwd=str(self.repo_root),
            )

            # Track the process for cleanup
            self._running_processes[task.id] = process

            # Stream output line by line
            while True:
                line = await process.stdout.readline()
                if not line:
                    break
                decoded_line = line.decode("utf-8")
                self._task_logs[task.id] += decoded_line

            await process.wait()

            # Remove from tracking
            self._running_processes.pop(task.id, None)

            if process.returncode == 0:
                plan_output = self._task_logs.get(task.id, "")
                # Use call_from_thread to update UI from worker
                self.call_from_thread(self._handle_spec_complete, task, plan_output)
            else:
                error = self._task_logs.get(task.id, "Unknown error")
                self.call_from_thread(self._handle_spec_failed, task, error)

        except Exception as e:
            self._running_processes.pop(task.id, None)
            self._task_logs[task.id] += f"\nError: {str(e)}"
            self.call_from_thread(self._handle_spec_failed, task, str(e))

    def _handle_spec_complete(self, task: Task, plan_output: str) -> None:
        """Handle completed spec generation."""
        from emdash.kanban.models import AIStatus

        # Save the plan to the task and reset AI status
        self.board.update_task(task.id, plan=plan_output, ai_status=AIStatus.IDLE)

        if self.supabase_mode:
            from emdash.kanban.supabase_store import SupabaseKanbanStore
            if isinstance(self.store, SupabaseKanbanStore):
                task.plan = plan_output
                task.ai_status = AIStatus.IDLE
                self.store.update_task(task)

        # Move to Design Review column
        next_col = task.column.next()
        if next_col:
            self.board.move_task(task.id, next_col)
            if self.supabase_mode:
                from emdash.kanban.supabase_store import SupabaseKanbanStore
                if isinstance(self.store, SupabaseKanbanStore):
                    task.column = next_col
                    self.store.move_task(task.id, task)

        self._save_and_refresh()
        self.notify(f"Spec generated! Moved to {next_col.display_name if next_col else 'same column'}")

    def _handle_spec_failed(self, task: Task, error: str) -> None:
        """Handle failed spec generation."""
        from emdash.kanban.models import AIStatus

        # Reset AI status
        self.board.update_task(task.id, ai_status=AIStatus.IDLE)
        self._save_and_refresh()
        self.notify(f"Spec generation failed: {error}", severity="error")

    def _stop_generating(self, task: Task) -> None:
        """Stop the spec generation for a task."""
        from emdash.kanban.models import AIStatus

        # Kill the running process if any
        process = self._running_processes.pop(task.id, None)
        if process:
            try:
                process.terminate()
            except Exception:
                pass

        # Reset AI status to idle
        self.board.update_task(task.id, ai_status=AIStatus.IDLE)
        # Clean up logs
        self._task_logs.pop(task.id, None)
        self._save_and_refresh()
        self.notify("Spec generation stopped", severity="warning")

    def get_task_logs(self, task_id: str) -> str:
        """Get the current logs for a task."""
        return self._task_logs.get(task_id, "")

    def _cleanup_processes(self) -> None:
        """Kill all running subprocesses."""
        for task_id, process in list(self._running_processes.items()):
            try:
                process.terminate()
            except Exception:
                pass
        self._running_processes.clear()

    def action_quit(self) -> None:
        """Clean up and quit."""
        self._cleanup_processes()
        self.exit()

    def on_unmount(self) -> None:
        """Clean up when app unmounts."""
        self._cleanup_processes()

    def _reset_ctrl_c(self) -> None:
        """Reset Ctrl+C counter."""
        self._ctrl_c_count = 0

    def on_key(self, event) -> None:
        """Handle key presses."""
        if event.key == "ctrl+c":
            self._ctrl_c_count += 1

            # Cancel previous timer
            if self._ctrl_c_timer:
                self._ctrl_c_timer.stop()

            if self._ctrl_c_count >= 3:
                # Force quit after 3 Ctrl+C
                self._cleanup_processes()
                self.exit()
            else:
                remaining = 3 - self._ctrl_c_count
                self.notify(f"Press Ctrl+C {remaining} more time(s) to quit", severity="warning")
                # Reset counter after 2 seconds
                self._ctrl_c_timer = self.set_timer(2.0, self._reset_ctrl_c)

    def _save_and_refresh(self) -> None:
        """Save board and refresh UI."""
        self.store.save(self.board)
        board_widget = self.query_one("#kanban-board", KanbanBoard)
        board_widget.refresh_board(self.board)

    def _move_task_right(self, task: Task) -> None:
        """Move task to next column."""
        next_col = task.column.next()
        if next_col:
            self.board.move_task(task.id, next_col)

            if self.supabase_mode:
                from emdash.kanban.supabase_store import SupabaseKanbanStore
                if isinstance(self.store, SupabaseKanbanStore):
                    # Update the task object with new column before saving
                    task.column = next_col
                    self.store.move_task(task.id, task)

            self._save_and_refresh()
            self.notify(f"Moved to {next_col.display_name}")

    def _move_task_left(self, task: Task) -> None:
        """Move task to previous column."""
        prev_col = task.column.prev()
        if prev_col:
            self.board.move_task(task.id, prev_col)

            if self.supabase_mode:
                from emdash.kanban.supabase_store import SupabaseKanbanStore
                if isinstance(self.store, SupabaseKanbanStore):
                    task.column = prev_col
                    self.store.move_task(task.id, task)

            self._save_and_refresh()
            self.notify(f"Moved to {prev_col.display_name}")

    # Actions

    def action_add_task(self) -> None:
        """Open add task modal."""
        # Default to the column of selected task, or TODO
        initial_column = Column.TODO
        if self.selected_task:
            initial_column = self.selected_task.column

        def handle_add_result(task: Task | None) -> None:
            if task:
                if self.supabase_mode:
                    # In Supabase mode, add via store which handles DB
                    from emdash.kanban.supabase_store import SupabaseKanbanStore
                    if isinstance(self.store, SupabaseKanbanStore):
                        task = self.store.add_task(task)
                        self.board.tasks.append(task)
                else:
                    self.board.tasks.append(task)

                self._save_and_refresh()
                self.notify(f"Added: {task.title}")
                # Focus the new task
                board_widget = self.query_one("#kanban-board", KanbanBoard)
                board_widget.focus_task(task.id)

        self.push_screen(
            AddTaskModal(initial_column, team_members=self.team_members),
            handle_add_result
        )

    def action_delete_task(self) -> None:
        """Delete selected task."""
        if self.selected_task:
            self._show_delete_modal(self.selected_task)

    def action_move_left(self) -> None:
        """Move selected task left."""
        if self.selected_task:
            self._move_task_left(self.selected_task)

    def action_move_right(self) -> None:
        """Move selected task right."""
        if self.selected_task:
            self._move_task_right(self.selected_task)

    def action_cycle_priority(self) -> None:
        """Cycle priority of selected task."""
        if self.selected_task:
            new_priority = self.selected_task.priority.next()
            self.board.update_task(self.selected_task.id, priority=new_priority)
            self._save_and_refresh()
            self.notify(f"Priority: {new_priority.value.upper()}")

    def action_open_settings(self) -> None:
        """Open settings modal for theme selection."""
        def handle_settings_result(theme_name: str | None) -> None:
            if theme_name and theme_name != self.current_theme_name:
                self.current_theme_name = theme_name
                self.store.set_theme(theme_name)
                self.store.save(self.board)
                # Exit and signal to reload with new theme
                self.exit(result="reload_theme")

        self.push_screen(SettingsModal(self.current_theme_name), handle_settings_result)

    def _remount_board(self) -> None:
        """Remount the kanban board to apply theme changes."""
        try:
            old_board = self.query_one("#kanban-board", KanbanBoard)
            container = self.query_one("#main-content")
            old_board.remove()
            new_board = KanbanBoard(self.board, id="kanban-board")
            container.mount(new_board)
            # Apply theme after board is fully mounted
            self.call_after_refresh(self._apply_full_theme)
        except Exception:
            pass

    def action_goto_column_1(self) -> None:
        """Jump to Todo column."""
        board = self.query_one("#kanban-board", KanbanBoard)
        board.focus_first_in_column(Column.TODO)

    def action_goto_column_2(self) -> None:
        """Jump to Design Review column."""
        board = self.query_one("#kanban-board", KanbanBoard)
        board.focus_first_in_column(Column.DESIGN_REVIEW)

    def action_goto_column_3(self) -> None:
        """Jump to In Progress column."""
        board = self.query_one("#kanban-board", KanbanBoard)
        board.focus_first_in_column(Column.IN_PROGRESS)

    def action_goto_column_4(self) -> None:
        """Jump to In-PR column."""
        board = self.query_one("#kanban-board", KanbanBoard)
        board.focus_first_in_column(Column.IN_PR)


def run_kanban(
    repo_root: Optional[Path] = None,
    supabase_mode: bool = False,
    access_token: Optional[str] = None,
) -> None:
    """Run the Kanban app.

    Args:
        repo_root: Repository root directory. Uses cwd if not provided.
        supabase_mode: If True, use Supabase for storage instead of local files.
        access_token: GitHub access token for Supabase auth (required for supabase_mode).
    """
    import asyncio

    repo_root = repo_root or Path.cwd()

    supabase_store = None
    project = None
    team_members: list[TeamMember] = []

    if supabase_mode and access_token:
        try:
            from emdash.db.providers.supabase import SupabaseProvider
            from emdash.kanban.git_utils import get_normalized_remote_url
            from emdash.kanban.supabase_store import SupabaseKanbanStore

            # Initialize Supabase provider with auth
            provider = SupabaseProvider(access_token=access_token)

            # Detect project from git remote
            remote_url = get_normalized_remote_url(repo_root)
            if remote_url:
                project = asyncio.run(provider.get_project_by_repo_url(remote_url))

            if project:
                # Load team members
                team_members = asyncio.run(provider.list_team_members(project.id))

                # Create Supabase store
                supabase_store = SupabaseKanbanStore(
                    provider=provider,
                    project_id=project.id,
                    team_members=team_members,
                )
            else:
                # No project found, fall back to local mode
                supabase_mode = False

        except Exception as e:
            # Fall back to local mode on error
            print(f"Warning: Could not initialize Supabase: {e}")
            supabase_mode = False

    while True:
        app = KanbanApp(
            repo_root=repo_root,
            supabase_store=supabase_store,
            project=project,
            team_members=team_members,
        )
        result = app.run()
        # Restart if theme was changed
        if result != "reload_theme":
            break


if __name__ == "__main__":
    run_kanban()
