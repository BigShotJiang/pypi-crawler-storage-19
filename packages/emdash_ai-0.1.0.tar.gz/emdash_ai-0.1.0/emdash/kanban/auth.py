"""Kanban authentication with GitHub OAuth via Supabase."""

import json
import os
import socket
import time
import webbrowser
from dataclasses import dataclass
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs, urlparse

from rich.console import Console
from rich.spinner import Spinner
from rich.live import Live

# Check if supabase is available
try:
    from supabase import create_client, Client
    SUPABASE_AVAILABLE = True
except ImportError:
    SUPABASE_AVAILABLE = False


@dataclass
class KanbanUser:
    """Authenticated Kanban user."""
    id: str
    email: Optional[str]
    github_handle: Optional[str]
    avatar_url: Optional[str]
    name: Optional[str]


class OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler to capture OAuth callback."""

    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    auth_code: Optional[str] = None

    def do_GET(self):
        """Handle GET request from OAuth callback."""
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)

        if parsed.path == "/auth/callback":
            # Check for PKCE code in query string first
            code = query.get("code", [None])[0]
            error = query.get("error_description", query.get("error", [None]))[0]

            if error:
                self._send_error_page(error)
            elif code:
                # PKCE flow - store code for exchange
                OAuthCallbackHandler.auth_code = code
                self._send_success_page()
            else:
                # Check for tokens in hash fragment (implicit flow)
                self._send_hash_extractor_page()

        elif parsed.path == "/auth/tokens":
            # Receive tokens from JavaScript (implicit flow)
            OAuthCallbackHandler.access_token = query.get("access_token", [None])[0]
            OAuthCallbackHandler.refresh_token = query.get("refresh_token", [None])[0]

            self.send_response(200)
            self.send_header("Content-type", "text/plain")
            self.end_headers()
            self.wfile.write(b"OK")

        else:
            self.send_response(404)
            self.end_headers()

    def _send_success_page(self):
        """Send success page."""
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        html = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>EmDash - Login</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    color: white;
                }
                .container {
                    text-align: center;
                    padding: 40px;
                    background: rgba(255, 255, 255, 0.05);
                    border-radius: 16px;
                    backdrop-filter: blur(10px);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                }
                .icon { font-size: 48px; margin-bottom: 16px; }
                h1 { color: #00cc66; margin-bottom: 12px; font-size: 24px; }
                p { color: rgba(255, 255, 255, 0.7); font-size: 14px; }
                .countdown { margin-top: 16px; font-size: 12px; color: rgba(255, 255, 255, 0.5); }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="icon">✓</div>
                <h1>Login Successful!</h1>
                <p>You can return to the terminal now.</p>
                <p class="countdown">This window will close in <span id="countdown">3</span> seconds...</p>
            </div>
            <script>
                let countdown = 3;
                const timer = setInterval(() => {
                    countdown--;
                    document.getElementById('countdown').textContent = countdown;
                    if (countdown <= 0) {
                        clearInterval(timer);
                        window.close();
                    }
                }, 1000);
            </script>
        </body>
        </html>
        """
        self.wfile.write(html.encode())

    def _send_error_page(self, error_msg):
        """Send error page."""
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>EmDash - Login Failed</title>
            <style>
                * {{ margin: 0; padding: 0; box-sizing: border-box; }}
                body {{
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    color: white;
                }}
                .container {{
                    text-align: center;
                    padding: 40px;
                    background: rgba(255, 255, 255, 0.05);
                    border-radius: 16px;
                    backdrop-filter: blur(10px);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                }}
                .icon {{ font-size: 48px; margin-bottom: 16px; }}
                h1 {{ color: #ff6b6b; margin-bottom: 12px; font-size: 24px; }}
                p {{ color: rgba(255, 255, 255, 0.7); font-size: 14px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="icon">✗</div>
                <h1>Login Failed</h1>
                <p>{error_msg or 'Please try again from the terminal.'}</p>
            </div>
        </body>
        </html>
        """
        self.wfile.write(html.encode())

    def _send_hash_extractor_page(self):
        """Send page that extracts tokens from hash fragment (implicit flow)."""
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        html = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>EmDash - Login</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    color: white;
                }
                .container {
                    text-align: center;
                    padding: 40px;
                    background: rgba(255, 255, 255, 0.05);
                    border-radius: 16px;
                    backdrop-filter: blur(10px);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                }
                .spinner {
                    width: 24px;
                    height: 24px;
                    border: 2px solid rgba(255, 255, 255, 0.3);
                    border-top-color: #00cc66;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                    margin: 0 auto 16px;
                }
                @keyframes spin { to { transform: rotate(360deg); } }
                h1 { color: #00cc66; margin-bottom: 12px; font-size: 24px; }
                p { color: rgba(255, 255, 255, 0.7); font-size: 14px; }
                .error { color: #ff6b6b; }
            </style>
        </head>
        <body>
            <div class="container" id="content">
                <div class="spinner"></div>
                <h1>Authenticating...</h1>
                <p>Please wait while we complete your login.</p>
            </div>
            <script>
                const container = document.getElementById('content');
                const hash = window.location.hash.substring(1);
                const params = new URLSearchParams(hash);
                const accessToken = params.get('access_token');
                const refreshToken = params.get('refresh_token');
                const error = params.get('error_description') || params.get('error');

                if (error) {
                    container.innerHTML = '<div style="font-size:48px;margin-bottom:16px">✗</div><h1 class="error">Login Failed</h1><p>' + error + '</p>';
                } else if (accessToken) {
                    fetch('/auth/tokens?access_token=' + encodeURIComponent(accessToken) + '&refresh_token=' + encodeURIComponent(refreshToken || ''))
                        .then(res => {
                            if (res.ok) {
                                container.innerHTML = '<div style="font-size:48px;margin-bottom:16px">✓</div><h1>Login Successful!</h1><p>You can return to the terminal now.</p>';
                                setTimeout(() => window.close(), 3000);
                            } else {
                                container.innerHTML = '<div style="font-size:48px;margin-bottom:16px">✗</div><h1 class="error">Login Failed</h1><p>Failed to complete authentication.</p>';
                            }
                        });
                } else {
                    container.innerHTML = '<div style="font-size:48px;margin-bottom:16px">✗</div><h1 class="error">Login Failed</h1><p>No authentication token received.</p>';
                }
            </script>
        </body>
        </html>
        """
        self.wfile.write(html.encode())

    def log_message(self, format, *args):
        """Suppress HTTP logs."""
        pass


class KanbanAuth:
    """Handle Kanban authentication with GitHub OAuth."""

    CALLBACK_PORT = 54321
    CALLBACK_URL = f"http://localhost:{CALLBACK_PORT}/auth/callback"
    TOKEN_FILE = ".emdash/kanban_auth.json"

    def __init__(self):
        self.console = Console()
        self.supabase_url = os.getenv("SUPABASE_URL")
        self.supabase_key = os.getenv("SUPABASE_KEY")
        self._client: Optional[Client] = None
        self._user: Optional[KanbanUser] = None

    @property
    def client(self) -> Optional[Client]:
        """Get or create Supabase client."""
        if not SUPABASE_AVAILABLE:
            return None
        if self._client is None and self.supabase_url and self.supabase_key:
            self._client = create_client(self.supabase_url, self.supabase_key)
        return self._client

    def is_configured(self) -> bool:
        """Check if Supabase is configured."""
        return bool(self.supabase_url and self.supabase_key and SUPABASE_AVAILABLE)

    def get_stored_session(self) -> Optional[dict]:
        """Get stored session from file."""
        token_path = Path.cwd() / self.TOKEN_FILE
        if token_path.exists():
            try:
                with open(token_path) as f:
                    return json.load(f)
            except Exception:
                pass
        return None

    def store_session(self, access_token: str, refresh_token: str, user_data: dict):
        """Store session to file."""
        token_path = Path.cwd() / self.TOKEN_FILE
        token_path.parent.mkdir(parents=True, exist_ok=True)

        with open(token_path, "w") as f:
            json.dump({
                "access_token": access_token,
                "refresh_token": refresh_token,
                "user": user_data,
            }, f, indent=2)

    def clear_session(self):
        """Clear stored session."""
        token_path = Path.cwd() / self.TOKEN_FILE
        if token_path.exists():
            token_path.unlink()
        self._user = None

    def _validate_token(self, access_token: str) -> bool:
        """Validate access token with Supabase."""
        if not self.client:
            return False
        try:
            response = self.client.auth.get_user(access_token)
            return response and response.user is not None
        except Exception:
            return False

    def _refresh_session(self, refresh_token: str) -> Optional[dict]:
        """Refresh the session using refresh token.

        Returns new session dict with access_token, refresh_token if successful.
        """
        if not self.client or not refresh_token:
            return None
        try:
            response = self.client.auth.refresh_session(refresh_token)
            if response and response.session:
                session = response.session
                return {
                    "access_token": session.access_token,
                    "refresh_token": session.refresh_token,
                }
        except Exception:
            pass
        return None

    def get_current_user(self, validate: bool = False) -> Optional[KanbanUser]:
        """Get current authenticated user, checking stored session first.

        Args:
            validate: If True, validate token with Supabase and refresh if expired.
        """
        if self._user and not validate:
            return self._user

        # Try stored session
        stored = self.get_stored_session()
        if not stored or not stored.get("user"):
            return None

        access_token = stored.get("access_token")
        refresh_token = stored.get("refresh_token")
        user_data = stored["user"]

        # Validate token if requested
        if validate and access_token and self.is_configured():
            if not self._validate_token(access_token):
                # Token invalid, try to refresh
                new_session = self._refresh_session(refresh_token or "")
                if new_session:
                    # Update stored session with new tokens
                    self.store_session(
                        new_session["access_token"],
                        new_session["refresh_token"],
                        user_data,
                    )
                else:
                    # Refresh failed, clear session
                    self.clear_session()
                    return None

        self._user = KanbanUser(
            id=user_data.get("id", ""),
            email=user_data.get("email"),
            github_handle=user_data.get("github_handle"),
            avatar_url=user_data.get("avatar_url"),
            name=user_data.get("name"),
        )
        return self._user

    def _is_port_available(self, port: int) -> bool:
        """Check if a port is available for binding."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("localhost", port))
                return True
        except OSError:
            return False

    def _find_available_port(self, start_port: int, max_attempts: int = 10) -> Optional[int]:
        """Find an available port starting from start_port."""
        for i in range(max_attempts):
            port = start_port + i
            if self._is_port_available(port):
                return port
        return None

    def login_with_github(self) -> Optional[KanbanUser]:
        """Initiate GitHub OAuth login flow via Supabase.

        Uses Supabase OAuth which creates actual Auth users in Supabase.
        """
        if not self.client:
            self.console.print("[red]Supabase not configured.[/red]")
            return None

        self.console.print()
        self.console.print("[cyan]Authenticating with GitHub via Supabase...[/cyan]")

        try:
            # Find available port for callback server
            port = self._find_available_port(self.CALLBACK_PORT)
            if not port:
                self.console.print("[red]Could not find available port for auth callback.[/red]")
                return None

            callback_url = f"http://localhost:{port}/auth/callback"

            # Get OAuth URL from Supabase
            response = self.client.auth.sign_in_with_oauth({
                "provider": "github",
                "options": {
                    "redirect_to": callback_url,
                    "scopes": "repo read:user user:email",
                }
            })

            if not response or not response.url:
                self.console.print("[red]Failed to get OAuth URL from Supabase.[/red]")
                return None

            oauth_url = response.url

            # Start local server to catch callback
            OAuthCallbackHandler.access_token = None
            OAuthCallbackHandler.refresh_token = None
            OAuthCallbackHandler.auth_code = None

            server = HTTPServer(("localhost", port), OAuthCallbackHandler)
            server.timeout = 300  # 5 minute timeout

            self.console.print()
            self.console.print("[dim]Press Enter to open browser for GitHub login...[/dim]")
            self.console.input()
            webbrowser.open(oauth_url)

            # Wait for callback with spinner (either code or tokens)
            with Live(Spinner("dots", text="Waiting for GitHub authorization..."), console=self.console):
                while OAuthCallbackHandler.auth_code is None and OAuthCallbackHandler.access_token is None:
                    server.handle_request()

            server.server_close()

            access_token = OAuthCallbackHandler.access_token
            refresh_token = OAuthCallbackHandler.refresh_token or ""
            auth_code = OAuthCallbackHandler.auth_code

            # If we got a code (PKCE flow), exchange it for tokens
            if auth_code and not access_token:
                session_response = self.client.auth.exchange_code_for_session({
                    "auth_code": auth_code,
                })
                if session_response and session_response.session:
                    access_token = session_response.session.access_token
                    refresh_token = session_response.session.refresh_token or ""

            if not access_token:
                self.console.print("[red]Authentication failed - no token received.[/red]")
                return None

            # Get user info from Supabase
            user_response = self.client.auth.get_user(access_token)
            if not user_response or not user_response.user:
                self.console.print("[red]Failed to get user info from Supabase.[/red]")
                return None

            supabase_user = user_response.user
            user_metadata = supabase_user.user_metadata or {}

            github_handle = user_metadata.get("user_name") or user_metadata.get("preferred_username")
            avatar_url = user_metadata.get("avatar_url")
            name = user_metadata.get("full_name") or user_metadata.get("name")
            email = supabase_user.email

            user_data = {
                "id": supabase_user.id,
                "email": email,
                "github_handle": github_handle,
                "avatar_url": avatar_url,
                "name": name,
            }

            # Store session with Supabase JWT
            self.store_session(access_token, refresh_token, user_data)

            self._user = KanbanUser(**user_data)
            return self._user

        except Exception as e:
            self.console.print(f"[red]Authentication error: {e}[/red]")
            return None

    def ensure_authenticated(self) -> Optional[KanbanUser]:
        """Ensure user is authenticated, prompting login if needed.

        Returns:
            KanbanUser if authenticated, None if failed/cancelled
        """
        # Check existing session
        user = self.get_current_user()
        if user:
            self.console.print(f"[green]✓[/green] Logged in as [cyan]{user.github_handle or user.email}[/cyan]")
            return user

        # Need to login
        self.console.print("[yellow]GitHub login required for Kanban.[/yellow]")
        return self.login_with_github()


def handle_kanban_command(repo_root, console: Console) -> tuple[bool, Optional[str]]:
    """Handle /kanban command with auth check.

    Args:
        repo_root: Repository root path (unused, for API compatibility)
        console: Rich console for output

    Returns:
        Tuple of (should_open_kanban, access_token).
        access_token is None for offline mode or if auth failed.
    """
    _ = repo_root  # Unused
    auth = KanbanAuth()

    # Check if Supabase is configured
    if not auth.is_configured():
        console.print("[yellow]Supabase not configured - opening Kanban in offline mode.[/yellow]")
        return (True, None)

    # Show loader while validating auth
    with console.status("[cyan]Checking authentication...[/cyan]"):
        user = auth.get_current_user(validate=True)

    if user:
        console.print(f"[green]✓[/green] Logged in as [cyan]@{user.github_handle or user.email}[/cyan]")
        session = auth.get_stored_session()
        access_token = session.get("access_token") if session else None
        return (True, access_token)

    # Need to authenticate via Supabase OAuth
    console.print()
    console.print("[bold]GitHub Login Required[/bold]")
    console.print("[dim]Kanban syncs with your GitHub account via Supabase.[/dim]")
    console.print()

    user = auth.login_with_github()

    if user:
        console.print()
        console.print(f"[green]✓[/green] Welcome, [cyan]@{user.github_handle}[/cyan]!")
        session = auth.get_stored_session()
        access_token = session.get("access_token") if session else None
        return (True, access_token)

    return (False, None)


def handle_logout_command(console: Console) -> bool:
    """Handle /logout command to clear stored session.

    Args:
        console: Rich console for output

    Returns:
        True if logout was successful
    """
    auth = KanbanAuth()
    user = auth.get_current_user()

    if not user:
        console.print("[yellow]Not currently logged in.[/yellow]")
        return True

    auth.clear_session()
    console.print(f"[green]✓[/green] Logged out from [cyan]@{user.github_handle or user.email}[/cyan]")
    return True
