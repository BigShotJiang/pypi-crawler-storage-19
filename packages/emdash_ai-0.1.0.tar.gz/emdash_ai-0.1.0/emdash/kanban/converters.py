"""Converters between Kanban models and Database models."""

from datetime import datetime
from typing import Optional

from emdash.db.models import Feature, FeatureStatus, TeamMember
from emdash.kanban.models import Column, Priority, Task


# Column <-> FeatureStatus mapping
COLUMN_TO_STATUS = {
    Column.TODO: FeatureStatus.TODO,
    Column.DESIGN_REVIEW: FeatureStatus.IN_DESIGN_REVIEW,
    Column.IN_PROGRESS: FeatureStatus.IN_PROGRESS,
    Column.IN_PR: FeatureStatus.IN_PR,
}

STATUS_TO_COLUMN = {
    FeatureStatus.TODO: Column.TODO,
    FeatureStatus.IN_DESIGN_REVIEW: Column.DESIGN_REVIEW,
    FeatureStatus.IN_PROGRESS: Column.IN_PROGRESS,
    FeatureStatus.IN_PR: Column.IN_PR,
    # DONE maps to None (hidden from board or shown in archive)
    FeatureStatus.DONE: None,
}


def column_to_status(column: Column) -> FeatureStatus:
    """Convert Kanban Column to FeatureStatus.

    Args:
        column: Kanban column enum

    Returns:
        Corresponding FeatureStatus
    """
    return COLUMN_TO_STATUS[column]


def status_to_column(status: FeatureStatus) -> Optional[Column]:
    """Convert FeatureStatus to Kanban Column.

    Args:
        status: Feature status enum

    Returns:
        Corresponding Column, or None for DONE status
    """
    return STATUS_TO_COLUMN.get(status)


def feature_to_task(feature: Feature) -> Optional[Task]:
    """Convert a Feature to a Kanban Task.

    Args:
        feature: Database Feature object

    Returns:
        Kanban Task, or None if feature status is DONE
    """
    column = status_to_column(feature.status)
    if column is None:
        # DONE features are not shown on the board
        return None

    # Get first assignee's github handle or name
    assignee = ""
    if feature.assignees:
        first_assignee = feature.assignees[0]
        assignee = first_assignee.github_handle or first_assignee.name

    return Task(
        id=feature.id,
        title=feature.title,
        description=feature.description or "",
        column=column,
        created_at=feature.created_at or datetime.now(),
        updated_at=feature.updated_at or datetime.now(),
        labels=[],  # Feature doesn't have labels yet
        assignee=assignee,
        priority=Priority.MEDIUM,  # Feature doesn't have priority yet
        spec_path=feature.spec or "",
    )


def task_to_feature_data(task: Task, project_id: str) -> dict:
    """Convert a Kanban Task to Feature creation/update data.

    Args:
        task: Kanban Task object
        project_id: The project ID to associate with

    Returns:
        Dictionary of Feature fields for create/update
    """
    return {
        "project_id": project_id,
        "title": task.title,
        "description": task.description or None,
        "status": column_to_status(task.column).value,
        "spec": task.spec_path or None,
    }


def task_update_to_feature_data(task: Task) -> dict:
    """Convert Task updates to Feature update data.

    Args:
        task: Updated Kanban Task

    Returns:
        Dictionary of Feature fields to update
    """
    return {
        "title": task.title,
        "description": task.description or None,
        "status": column_to_status(task.column).value,
        "spec": task.spec_path or None,
    }


def get_assignee_display(assignees: list[TeamMember]) -> str:
    """Get display string for assignees.

    Args:
        assignees: List of TeamMember objects

    Returns:
        Comma-separated list of github handles or names
    """
    if not assignees:
        return ""

    names = []
    for member in assignees:
        if member.github_handle:
            names.append(f"@{member.github_handle}")
        else:
            names.append(member.name)

    return ", ".join(names)
