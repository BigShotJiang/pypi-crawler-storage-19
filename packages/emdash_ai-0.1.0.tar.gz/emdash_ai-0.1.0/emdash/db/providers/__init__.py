"""Database provider implementations."""

from emdash.db.providers.supabase import SupabaseProvider

__all__ = ["SupabaseProvider"]
