"""History tools for git and PR analysis.

NOTE: Local history tools have been removed in favor of GitHub MCP tools.
Use the GitHub MCP tools (github_list_prs, github_pr_details, github_search_prs)
for PR and history analysis. These provide live data directly from GitHub.
"""

# This module previously contained:
# - GetFileHistoryTool
# - GetAuthorExpertiseTool
# - GetRecentPRsTool
# - GetPRDetailsTool
#
# These have been replaced by GitHub MCP tools which provide richer,
# live data directly from the GitHub API.
