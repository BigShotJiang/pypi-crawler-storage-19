"""MCP (Model Context Protocol) support for extensible tool servers.

This package provides:
- GitHubMCPClient: Client for the GitHub MCP server
- GenericMCPClient: Generic client for any MCP server
- MCPServerManager: Lifecycle management for multiple MCP servers
- MCPDynamicTool: Dynamic tool wrapper for MCP tools
- Configuration classes for .emdash/mcp.json
"""

from .client import GitHubMCPClient, GenericMCPClient, MCPError, MCPToolInfo, MCPResponse
from .config import (
    MCPServerConfig,
    MCPConfigFile,
    get_default_mcp_config_path,
    get_default_mcp_servers,
    create_default_mcp_config,
    ensure_mcp_config,
)
from .manager import MCPServerManager, get_mcp_manager, reset_mcp_manager
from .tool_factory import MCPDynamicTool, create_tools_from_mcp, create_tools_for_server

__all__ = [
    # Client
    "GitHubMCPClient",
    "GenericMCPClient",
    "MCPError",
    "MCPToolInfo",
    "MCPResponse",
    # Config
    "MCPServerConfig",
    "MCPConfigFile",
    "get_default_mcp_config_path",
    "get_default_mcp_servers",
    "create_default_mcp_config",
    "ensure_mcp_config",
    # Manager
    "MCPServerManager",
    "get_mcp_manager",
    "reset_mcp_manager",
    # Tool Factory
    "MCPDynamicTool",
    "create_tools_from_mcp",
    "create_tools_for_server",
]

