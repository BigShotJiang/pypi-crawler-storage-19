"""Deep Research Agent - Fact-grounded, team-values-driven research.

This module provides a sophisticated research agent that uses multi-LLM loops
with critic evaluation to perform thorough investigation of the codebase.

Key components:
- DeepResearchAgent: Main entry point for running research
- PlannerAgent: Creates research plans with questions
- ResearcherAgent: Executes tool macros, collects evidence
- CriticAgent: Evaluates and gates progress
- SynthesizerAgent: Generates final reports
- ResearchController: Manages budgets and state transitions

Example:
    from emdash.agent.research import DeepResearchAgent
    
    agent = DeepResearchAgent()
    report = agent.research("How does the agent toolkit work?")
    print(report)
"""

from emdash.agent.research.state import (
    EvidenceItem,
    Claim,
    Gap,
    ResearchQuestion,
    ResearchPlan,
    Critique,
    CritiqueScores,
    IterationResult,
    ResearchState,
    FollowUpQuestion,
    Contradiction,
    ValuesViolation,
)
from emdash.agent.research.macros import (
    TOOL_MACROS,
    ToolMacro,
    MacroExecutor,
    get_macro,
    list_macros,
    suggest_macros,
)
from emdash.agent.research.planner import PlannerAgent
from emdash.agent.research.researcher import ResearcherAgent
from emdash.agent.research.critic import CriticAgent
from emdash.agent.research.synthesizer import SynthesizerAgent
from emdash.agent.research.controller import ResearchController
from emdash.agent.research.agent import DeepResearchAgent, research

__all__ = [
    # Main agent
    "DeepResearchAgent",
    "research",
    # Sub-agents
    "PlannerAgent",
    "ResearcherAgent",
    "CriticAgent",
    "SynthesizerAgent",
    "ResearchController",
    # State classes
    "EvidenceItem",
    "Claim",
    "Gap",
    "ResearchQuestion",
    "ResearchPlan",
    "Critique",
    "CritiqueScores",
    "IterationResult",
    "ResearchState",
    "FollowUpQuestion",
    "Contradiction",
    "ValuesViolation",
    # Macros
    "TOOL_MACROS",
    "ToolMacro",
    "MacroExecutor",
    "get_macro",
    "list_macros",
    "suggest_macros",
]

