"""Claudear scripts and utilities."""
