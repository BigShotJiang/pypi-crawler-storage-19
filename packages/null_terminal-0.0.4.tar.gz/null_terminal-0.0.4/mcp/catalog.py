"""MCP Server Catalog - curated list of popular MCP servers."""

import asyncio
import shutil
from dataclasses import dataclass


@dataclass
class CatalogEntry:
    name: str
    description: str
    command: str
    args: list[str]
    env_keys: list[str]
    category: str
    url: str


async def verify_entry(entry: CatalogEntry) -> dict[str, bool | str]:
    """
    Verify a catalog entry's requirements.
    Returns dict with: command_available, package_exists, error (if any).
    """
    result = {
        "command_available": False,
        "package_exists": False,
        "error": "",
    }

    if shutil.which(entry.command) is None:
        result["error"] = f"Command '{entry.command}' not found"
        return result

    result["command_available"] = True

    if entry.command == "npx":
        package = _extract_npm_package(entry.args)
        if package:
            result["package_exists"] = await _check_npm_package(package)
            if not result["package_exists"]:
                result["error"] = f"npm package '{package}' not found"
    elif entry.command == "uvx":
        package = entry.args[0] if entry.args else None
        if package:
            result["package_exists"] = await _check_pypi_package(package)
            if not result["package_exists"]:
                result["error"] = f"PyPI package '{package}' not found"
    else:
        result["package_exists"] = True

    return result


def _extract_npm_package(args: list[str]) -> str | None:
    """Extract npm package name from npx args."""
    try:
        if "-y" in args:
            idx = args.index("-y")
            if idx + 1 < len(args):
                return args[idx + 1]
        for arg in args:
            if arg.startswith("@") or not arg.startswith("-"):
                return arg
    except (ValueError, IndexError):
        pass
    return None


async def _check_npm_package(package: str) -> bool:
    """Check if npm package exists."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "npm",
            "view",
            package,
            "name",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
        return proc.returncode == 0
    except Exception:
        return True


async def _check_pypi_package(package: str) -> bool:
    """Check if PyPI package exists."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "pip",
            "index",
            "versions",
            package,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
        return proc.returncode == 0
    except Exception:
        return True


CATALOG: list[CatalogEntry] = [
    # === File System ===
    CatalogEntry(
        name="filesystem",
        description="Read/write files, directory operations",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-filesystem", "/path/to/dir"],
        env_keys=[],
        category="filesystem",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="markitdown",
        description="Convert files (PDF, Office, images) to Markdown",
        command="uvx",
        args=["mcp-server-markitdown"],
        env_keys=[],
        category="filesystem",
        url="https://github.com/microsoft/markitdown",
    ),
    CatalogEntry(
        name="desktop-commander",
        description="Terminal, file search, diff tools",
        command="npx",
        args=["-y", "@anthropic/mcp-desktop-commander"],
        env_keys=[],
        category="filesystem",
        url="https://github.com/anthropics/mcp-desktop-commander",
    ),
    # === Database ===
    CatalogEntry(
        name="sqlite",
        description="Query SQLite databases",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-sqlite", "/path/to/db.sqlite"],
        env_keys=[],
        category="database",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="postgres",
        description="Query PostgreSQL databases",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-postgres"],
        env_keys=["POSTGRES_CONNECTION_STRING"],
        category="database",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="mysql",
        description="Query MySQL databases",
        command="npx",
        args=["-y", "@benborber/mcp-server-mysql"],
        env_keys=["MYSQL_HOST", "MYSQL_USER", "MYSQL_PASSWORD", "MYSQL_DATABASE"],
        category="database",
        url="https://github.com/benborla/mcp-server-mysql",
    ),
    CatalogEntry(
        name="redis",
        description="Redis key-value operations",
        command="npx",
        args=["-y", "mcp-redis"],
        env_keys=["REDIS_URL"],
        category="database",
        url="https://github.com/redis/mcp-redis",
    ),
    CatalogEntry(
        name="mongodb",
        description="MongoDB database operations",
        command="npx",
        args=["-y", "@anthropic/mcp-server-mongodb"],
        env_keys=["MONGODB_URI"],
        category="database",
        url="https://github.com/mongodb/mcp-server-mongodb",
    ),
    CatalogEntry(
        name="qdrant",
        description="Vector search with Qdrant",
        command="uvx",
        args=["mcp-server-qdrant"],
        env_keys=["QDRANT_URL", "QDRANT_API_KEY"],
        category="database",
        url="https://github.com/qdrant/mcp-server-qdrant",
    ),
    CatalogEntry(
        name="elasticsearch",
        description="Elasticsearch search and analytics",
        command="npx",
        args=["-y", "@elastic/mcp-server-elasticsearch"],
        env_keys=["ELASTICSEARCH_URL", "ELASTICSEARCH_API_KEY"],
        category="database",
        url="https://github.com/elastic/mcp-server-elasticsearch",
    ),
    CatalogEntry(
        name="supabase",
        description="Supabase database and auth",
        command="npx",
        args=["-y", "@supabase/mcp-server-supabase"],
        env_keys=["SUPABASE_URL", "SUPABASE_KEY"],
        category="database",
        url="https://github.com/supabase/mcp-server-supabase",
    ),
    CatalogEntry(
        name="neon",
        description="Neon serverless Postgres",
        command="npx",
        args=["-y", "@neondatabase/mcp-server-neon"],
        env_keys=["NEON_API_KEY"],
        category="database",
        url="https://github.com/neondatabase/mcp-server-neon",
    ),
    # === Development & DevOps ===
    CatalogEntry(
        name="github",
        description="GitHub repos, issues, PRs",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-github"],
        env_keys=["GITHUB_TOKEN"],
        category="development",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="gitlab",
        description="GitLab projects, issues, MRs",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-gitlab"],
        env_keys=["GITLAB_TOKEN", "GITLAB_URL"],
        category="development",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="git",
        description="Git operations on local repos",
        command="uvx",
        args=["mcp-server-git", "--repository", "/path/to/repo"],
        env_keys=[],
        category="development",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="context7",
        description="Up-to-date library documentation",
        command="npx",
        args=["-y", "@upstash/context7-mcp"],
        env_keys=[],
        category="development",
        url="https://context7.com",
    ),
    CatalogEntry(
        name="sentry",
        description="Sentry error tracking",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-sentry"],
        env_keys=["SENTRY_AUTH_TOKEN", "SENTRY_ORG"],
        category="development",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="linear",
        description="Linear issues and projects",
        command="npx",
        args=["-y", "@tacticlaunch/mcp-linear"],
        env_keys=["LINEAR_API_KEY"],
        category="development",
        url="https://github.com/tacticlaunch/mcp-linear",
    ),
    CatalogEntry(
        name="jira",
        description="Jira issues and projects",
        command="npx",
        args=["-y", "@anthropic/mcp-server-jira"],
        env_keys=["JIRA_URL", "JIRA_EMAIL", "JIRA_API_TOKEN"],
        category="development",
        url="https://github.com/anthropics/mcp-server-jira",
    ),
    CatalogEntry(
        name="npm",
        description="NPM package info and search",
        command="npx",
        args=["-y", "mcp-npm"],
        env_keys=[],
        category="development",
        url="https://github.com/mcp-npm/mcp-npm",
    ),
    CatalogEntry(
        name="pypi",
        description="Python package info",
        command="uvx",
        args=["mcp-server-pypi"],
        env_keys=[],
        category="development",
        url="https://github.com/pypi/mcp-server-pypi",
    ),
    CatalogEntry(
        name="docker",
        description="Docker container management",
        command="npx",
        args=["-y", "@anthropic/mcp-server-docker"],
        env_keys=[],
        category="sysadmin",
        url="https://github.com/anthropics/mcp-server-docker",
    ),
    CatalogEntry(
        name="kubernetes",
        description="Kubernetes cluster management",
        command="npx",
        args=["-y", "@anthropic/mcp-server-kubernetes"],
        env_keys=["KUBECONFIG"],
        category="sysadmin",
        url="https://github.com/anthropics/mcp-server-kubernetes",
    ),
    CatalogEntry(
        name="circleci",
        description="CircleCI pipelines and jobs",
        command="npx",
        args=["-y", "@anthropic/mcp-server-circleci"],
        env_keys=["CIRCLECI_TOKEN"],
        category="development",
        url="https://github.com/anthropics/mcp-server-circleci",
    ),
    CatalogEntry(
        name="vercel",
        description="Vercel deployments and projects",
        command="npx",
        args=["-y", "@vercel/mcp"],
        env_keys=["VERCEL_TOKEN"],
        category="development",
        url="https://github.com/vercel/mcp",
    ),
    CatalogEntry(
        name="netlify",
        description="Netlify sites and deploys",
        command="npx",
        args=["-y", "@netlify/mcp-server-netlify"],
        env_keys=["NETLIFY_AUTH_TOKEN"],
        category="development",
        url="https://github.com/netlify/mcp-server-netlify",
    ),
    CatalogEntry(
        name="cloudflare",
        description="Cloudflare workers and DNS",
        command="npx",
        args=["-y", "@cloudflare/mcp-server-cloudflare"],
        env_keys=["CLOUDFLARE_API_TOKEN", "CLOUDFLARE_ACCOUNT_ID"],
        category="cloud",
        url="https://github.com/cloudflare/mcp-server-cloudflare",
    ),
    # === Sysadmin & Infrastructure ===
    CatalogEntry(
        name="shell",
        description="Execute shell commands",
        command="npx",
        args=["-y", "@anthropic/mcp-server-shell"],
        env_keys=[],
        category="sysadmin",
        url="https://github.com/anthropics/mcp-server-shell",
    ),
    CatalogEntry(
        name="ssh",
        description="SSH remote command execution",
        command="npx",
        args=["-y", "@anthropic/mcp-server-ssh"],
        env_keys=["SSH_HOST", "SSH_USER", "SSH_KEY_PATH"],
        category="sysadmin",
        url="https://github.com/anthropics/mcp-server-ssh",
    ),
    CatalogEntry(
        name="ansible",
        description="Ansible playbook execution",
        command="uvx",
        args=["mcp-server-ansible"],
        env_keys=[],
        category="sysadmin",
        url="https://github.com/ansible/mcp-server-ansible",
    ),
    CatalogEntry(
        name="terraform",
        description="Terraform infrastructure management",
        command="npx",
        args=["-y", "@hashicorp/mcp-server-terraform"],
        env_keys=[],
        category="sysadmin",
        url="https://github.com/hashicorp/mcp-server-terraform",
    ),
    CatalogEntry(
        name="prometheus",
        description="Prometheus metrics and alerts",
        command="npx",
        args=["-y", "@prometheus/mcp-server-prometheus"],
        env_keys=["PROMETHEUS_URL"],
        category="monitoring",
        url="https://github.com/prometheus/mcp-server-prometheus",
    ),
    CatalogEntry(
        name="grafana",
        description="Grafana dashboards and alerts",
        command="npx",
        args=["-y", "@grafana/mcp-server-grafana"],
        env_keys=["GRAFANA_URL", "GRAFANA_API_KEY"],
        category="monitoring",
        url="https://github.com/grafana/mcp-server-grafana",
    ),
    CatalogEntry(
        name="datadog",
        description="Datadog monitoring and logs",
        command="npx",
        args=["-y", "@datadog/mcp-server-datadog"],
        env_keys=["DD_API_KEY", "DD_APP_KEY"],
        category="monitoring",
        url="https://github.com/DataDog/mcp-server-datadog",
    ),
    CatalogEntry(
        name="pagerduty",
        description="PagerDuty incidents and schedules",
        command="npx",
        args=["-y", "@pagerduty/mcp-server-pagerduty"],
        env_keys=["PAGERDUTY_API_KEY"],
        category="monitoring",
        url="https://github.com/PagerDuty/mcp-server-pagerduty",
    ),
    # === Cloud Platforms ===
    CatalogEntry(
        name="aws",
        description="AWS services (S3, EC2, Lambda, etc.)",
        command="npx",
        args=["-y", "@aws/mcp-server-aws"],
        env_keys=["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_REGION"],
        category="cloud",
        url="https://github.com/aws/mcp-server-aws",
    ),
    CatalogEntry(
        name="aws-kb",
        description="AWS Bedrock Knowledge Base",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-aws-kb-retrieval"],
        env_keys=["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_REGION"],
        category="cloud",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="gcp",
        description="Google Cloud Platform services",
        command="npx",
        args=["-y", "@google-cloud/mcp-server-gcp"],
        env_keys=["GOOGLE_APPLICATION_CREDENTIALS"],
        category="cloud",
        url="https://github.com/googleapis/mcp-server-gcp",
    ),
    CatalogEntry(
        name="azure",
        description="Microsoft Azure services",
        command="npx",
        args=["-y", "@azure/mcp-server-azure"],
        env_keys=["AZURE_SUBSCRIPTION_ID", "AZURE_TENANT_ID"],
        category="cloud",
        url="https://github.com/Azure/mcp-server-azure",
    ),
    CatalogEntry(
        name="google-drive",
        description="Google Drive file access",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-gdrive"],
        env_keys=["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"],
        category="cloud",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="dropbox",
        description="Dropbox file access",
        command="npx",
        args=["-y", "@dropbox/mcp-server-dropbox"],
        env_keys=["DROPBOX_ACCESS_TOKEN"],
        category="cloud",
        url="https://github.com/dropbox/mcp-server-dropbox",
    ),
    CatalogEntry(
        name="onedrive",
        description="OneDrive file access",
        command="npx",
        args=["-y", "@microsoft/mcp-server-onedrive"],
        env_keys=["ONEDRIVE_CLIENT_ID", "ONEDRIVE_CLIENT_SECRET"],
        category="cloud",
        url="https://github.com/microsoft/mcp-server-onedrive",
    ),
    CatalogEntry(
        name="s3",
        description="AWS S3 bucket operations",
        command="npx",
        args=["-y", "@aws/mcp-server-s3"],
        env_keys=["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_REGION"],
        category="cloud",
        url="https://github.com/aws/mcp-server-s3",
    ),
    # === Web & Browser ===
    CatalogEntry(
        name="fetch",
        description="Fetch and parse web pages",
        command="uvx",
        args=["mcp-server-fetch"],
        env_keys=[],
        category="web",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="puppeteer",
        description="Browser automation with Puppeteer",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-puppeteer"],
        env_keys=[],
        category="web",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="playwright",
        description="Browser automation with Playwright",
        command="npx",
        args=["-y", "@playwright/mcp@latest"],
        env_keys=[],
        category="web",
        url="https://github.com/microsoft/playwright-mcp",
    ),
    CatalogEntry(
        name="browserbase",
        description="Cloud browser automation",
        command="npx",
        args=["-y", "@browserbase/mcp-server-browserbase"],
        env_keys=["BROWSERBASE_API_KEY"],
        category="web",
        url="https://github.com/browserbase/mcp-server-browserbase",
    ),
    CatalogEntry(
        name="firecrawl",
        description="Web scraping and crawling",
        command="npx",
        args=["-y", "@firecrawl/mcp-server-firecrawl"],
        env_keys=["FIRECRAWL_API_KEY"],
        category="web",
        url="https://github.com/firecrawl/mcp-server-firecrawl",
    ),
    # === Search ===
    CatalogEntry(
        name="brave-search",
        description="Web search via Brave",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-brave-search"],
        env_keys=["BRAVE_API_KEY"],
        category="search",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="exa",
        description="Exa AI-powered search",
        command="npx",
        args=["-y", "@exa/mcp-server-exa"],
        env_keys=["EXA_API_KEY"],
        category="search",
        url="https://github.com/exa-labs/mcp-server-exa",
    ),
    CatalogEntry(
        name="tavily",
        description="Tavily AI search",
        command="npx",
        args=["-y", "@tavily/mcp-server-tavily"],
        env_keys=["TAVILY_API_KEY"],
        category="search",
        url="https://github.com/tavily-ai/mcp-server-tavily",
    ),
    CatalogEntry(
        name="serper",
        description="Google search via Serper",
        command="npx",
        args=["-y", "@serper/mcp-server-serper"],
        env_keys=["SERPER_API_KEY"],
        category="search",
        url="https://github.com/serper-dev/mcp-server-serper",
    ),
    CatalogEntry(
        name="google-search",
        description="Google Custom Search",
        command="npx",
        args=["-y", "@anthropic/mcp-server-google-search"],
        env_keys=["GOOGLE_API_KEY", "GOOGLE_CSE_ID"],
        category="search",
        url="https://github.com/anthropics/mcp-server-google-search",
    ),
    # === Communication ===
    CatalogEntry(
        name="slack",
        description="Slack channels and messages",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-slack"],
        env_keys=["SLACK_BOT_TOKEN", "SLACK_TEAM_ID"],
        category="communication",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="discord",
        description="Discord servers and channels",
        command="npx",
        args=["-y", "@anthropic/mcp-server-discord"],
        env_keys=["DISCORD_BOT_TOKEN"],
        category="communication",
        url="https://github.com/anthropics/mcp-server-discord",
    ),
    CatalogEntry(
        name="telegram",
        description="Telegram messages and chats",
        command="npx",
        args=["-y", "@anthropic/mcp-server-telegram"],
        env_keys=["TELEGRAM_BOT_TOKEN"],
        category="communication",
        url="https://github.com/anthropics/mcp-server-telegram",
    ),
    CatalogEntry(
        name="email",
        description="Email sending via SMTP",
        command="npx",
        args=["-y", "@anthropic/mcp-server-email"],
        env_keys=["SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD"],
        category="communication",
        url="https://github.com/anthropics/mcp-server-email",
    ),
    CatalogEntry(
        name="gmail",
        description="Gmail read and send",
        command="npx",
        args=["-y", "@anthropic/mcp-server-gmail"],
        env_keys=["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"],
        category="communication",
        url="https://github.com/anthropics/mcp-server-gmail",
    ),
    CatalogEntry(
        name="twilio",
        description="SMS and voice via Twilio",
        command="npx",
        args=["-y", "@twilio/mcp-server-twilio"],
        env_keys=["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN"],
        category="communication",
        url="https://github.com/twilio/mcp-server-twilio",
    ),
    CatalogEntry(
        name="sendgrid",
        description="Email via SendGrid",
        command="npx",
        args=["-y", "@sendgrid/mcp-server-sendgrid"],
        env_keys=["SENDGRID_API_KEY"],
        category="communication",
        url="https://github.com/sendgrid/mcp-server-sendgrid",
    ),
    # === Productivity ===
    CatalogEntry(
        name="notion",
        description="Notion pages and databases",
        command="npx",
        args=["-y", "@notionhq/mcp-server-notion"],
        env_keys=["NOTION_API_KEY"],
        category="productivity",
        url="https://github.com/makenotion/mcp-server-notion",
    ),
    CatalogEntry(
        name="obsidian",
        description="Obsidian vault notes",
        command="npx",
        args=["-y", "mcp-obsidian", "/path/to/vault"],
        env_keys=[],
        category="productivity",
        url="https://github.com/smithery-ai/mcp-obsidian",
    ),
    CatalogEntry(
        name="todoist",
        description="Todoist tasks and projects",
        command="npx",
        args=["-y", "@abhiz123/todoist-mcp-server"],
        env_keys=["TODOIST_API_TOKEN"],
        category="productivity",
        url="https://github.com/abhiz123/todoist-mcp-server",
    ),
    CatalogEntry(
        name="asana",
        description="Asana tasks and projects",
        command="npx",
        args=["-y", "@asana/mcp-server-asana"],
        env_keys=["ASANA_ACCESS_TOKEN"],
        category="productivity",
        url="https://github.com/Asana/mcp-server-asana",
    ),
    CatalogEntry(
        name="trello",
        description="Trello boards and cards",
        command="npx",
        args=["-y", "@anthropic/mcp-server-trello"],
        env_keys=["TRELLO_API_KEY", "TRELLO_TOKEN"],
        category="productivity",
        url="https://github.com/anthropics/mcp-server-trello",
    ),
    CatalogEntry(
        name="airtable",
        description="Airtable bases and records",
        command="npx",
        args=["-y", "@airtable/mcp-server-airtable"],
        env_keys=["AIRTABLE_API_KEY"],
        category="productivity",
        url="https://github.com/Airtable/mcp-server-airtable",
    ),
    CatalogEntry(
        name="google-calendar",
        description="Google Calendar events",
        command="npx",
        args=["-y", "@anthropic/mcp-server-google-calendar"],
        env_keys=["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"],
        category="productivity",
        url="https://github.com/anthropics/mcp-server-google-calendar",
    ),
    CatalogEntry(
        name="apple-reminders",
        description="Apple Reminders (macOS)",
        command="npx",
        args=["-y", "@anthropic/mcp-server-apple-reminders"],
        env_keys=[],
        category="productivity",
        url="https://github.com/FradSer/mcp-server-apple-reminders",
    ),
    CatalogEntry(
        name="apple-notes",
        description="Apple Notes (macOS)",
        command="npx",
        args=["-y", "@anthropic/mcp-server-apple-notes"],
        env_keys=[],
        category="productivity",
        url="https://github.com/anthropics/mcp-server-apple-notes",
    ),
    # === Memory & Knowledge ===
    CatalogEntry(
        name="memory",
        description="Persistent memory via knowledge graph",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-memory"],
        env_keys=[],
        category="memory",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="knowledge-graph",
        description="Build and query knowledge graphs",
        command="npx",
        args=["-y", "@anthropic/mcp-server-knowledge-graph"],
        env_keys=[],
        category="memory",
        url="https://github.com/anthropics/mcp-server-knowledge-graph",
    ),
    CatalogEntry(
        name="chroma",
        description="ChromaDB vector database",
        command="uvx",
        args=["mcp-server-chroma"],
        env_keys=[],
        category="memory",
        url="https://github.com/chroma-core/mcp-server-chroma",
    ),
    CatalogEntry(
        name="pinecone",
        description="Pinecone vector database",
        command="npx",
        args=["-y", "@pinecone-database/mcp-server-pinecone"],
        env_keys=["PINECONE_API_KEY"],
        category="memory",
        url="https://github.com/pinecone-io/mcp-server-pinecone",
    ),
    CatalogEntry(
        name="weaviate",
        description="Weaviate vector database",
        command="npx",
        args=["-y", "@weaviate/mcp-server-weaviate"],
        env_keys=["WEAVIATE_URL", "WEAVIATE_API_KEY"],
        category="memory",
        url="https://github.com/weaviate/mcp-server-weaviate",
    ),
    # === Finance ===
    CatalogEntry(
        name="stripe",
        description="Stripe payments and customers",
        command="npx",
        args=["-y", "@stripe/mcp-server-stripe"],
        env_keys=["STRIPE_API_KEY"],
        category="finance",
        url="https://github.com/stripe/mcp-server-stripe",
    ),
    CatalogEntry(
        name="plaid",
        description="Plaid banking data",
        command="npx",
        args=["-y", "@plaid/mcp-server-plaid"],
        env_keys=["PLAID_CLIENT_ID", "PLAID_SECRET"],
        category="finance",
        url="https://github.com/plaid/mcp-server-plaid",
    ),
    CatalogEntry(
        name="coinbase",
        description="Coinbase crypto trading",
        command="npx",
        args=["-y", "@coinbase/mcp-server-coinbase"],
        env_keys=["COINBASE_API_KEY", "COINBASE_API_SECRET"],
        category="finance",
        url="https://github.com/coinbase/mcp-server-coinbase",
    ),
    CatalogEntry(
        name="polygon",
        description="Polygon.io stock market data",
        command="npx",
        args=["-y", "@polygon/mcp-server-polygon"],
        env_keys=["POLYGON_API_KEY"],
        category="finance",
        url="https://github.com/polygon-io/mcp-server-polygon",
    ),
    CatalogEntry(
        name="alpaca",
        description="Alpaca stock trading",
        command="npx",
        args=["-y", "@alpaca/mcp-server-alpaca"],
        env_keys=["ALPACA_API_KEY", "ALPACA_SECRET_KEY"],
        category="finance",
        url="https://github.com/alpacahq/mcp-server-alpaca",
    ),
    # === Social Media ===
    CatalogEntry(
        name="twitter",
        description="Twitter/X posts and search",
        command="npx",
        args=["-y", "@anthropic/mcp-server-twitter"],
        env_keys=["TWITTER_BEARER_TOKEN"],
        category="social",
        url="https://github.com/anthropics/mcp-server-twitter",
    ),
    CatalogEntry(
        name="reddit",
        description="Reddit posts and comments",
        command="npx",
        args=["-y", "@anthropic/mcp-server-reddit"],
        env_keys=["REDDIT_CLIENT_ID", "REDDIT_CLIENT_SECRET"],
        category="social",
        url="https://github.com/anthropics/mcp-server-reddit",
    ),
    CatalogEntry(
        name="youtube",
        description="YouTube video info and transcripts",
        command="npx",
        args=["-y", "@anthropic/mcp-server-youtube"],
        env_keys=["YOUTUBE_API_KEY"],
        category="social",
        url="https://github.com/anthropics/mcp-server-youtube",
    ),
    CatalogEntry(
        name="linkedin",
        description="LinkedIn profiles and posts",
        command="npx",
        args=["-y", "@anthropic/mcp-server-linkedin"],
        env_keys=["LINKEDIN_ACCESS_TOKEN"],
        category="social",
        url="https://github.com/anthropics/mcp-server-linkedin",
    ),
    CatalogEntry(
        name="hackernews",
        description="Hacker News stories and comments",
        command="npx",
        args=["-y", "@anthropic/mcp-server-hackernews"],
        env_keys=[],
        category="social",
        url="https://github.com/anthropics/mcp-server-hackernews",
    ),
    # === Utilities ===
    CatalogEntry(
        name="time",
        description="Current time and timezone conversion",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-time"],
        env_keys=[],
        category="utility",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="sequential-thinking",
        description="Problem-solving thought sequences",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-sequential-thinking"],
        env_keys=[],
        category="utility",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="everything",
        description="Reference server with all features",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-everything"],
        env_keys=[],
        category="utility",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="raygun",
        description="Raygun crash reporting",
        command="npx",
        args=["-y", "@raygun/mcp-server-raygun"],
        env_keys=["RAYGUN_PAT"],
        category="development",
        url="https://github.com/MindscapeHQ/mcp-server-raygun",
    ),
    CatalogEntry(
        name="google-maps",
        description="Google Maps and directions",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-google-maps"],
        env_keys=["GOOGLE_MAPS_API_KEY"],
        category="utility",
        url="https://github.com/modelcontextprotocol/servers",
    ),
    CatalogEntry(
        name="weather",
        description="Weather forecasts (OpenWeatherMap)",
        command="npx",
        args=["-y", "@anthropic/mcp-server-weather"],
        env_keys=["OPENWEATHERMAP_API_KEY"],
        category="utility",
        url="https://github.com/anthropics/mcp-server-weather",
    ),
    CatalogEntry(
        name="wolfram",
        description="Wolfram Alpha computations",
        command="npx",
        args=["-y", "@anthropic/mcp-server-wolfram"],
        env_keys=["WOLFRAM_APP_ID"],
        category="utility",
        url="https://github.com/anthropics/mcp-server-wolfram",
    ),
    CatalogEntry(
        name="calculator",
        description="Math calculations and expressions",
        command="npx",
        args=["-y", "@anthropic/mcp-server-calculator"],
        env_keys=[],
        category="utility",
        url="https://github.com/anthropics/mcp-server-calculator",
    ),
    CatalogEntry(
        name="qr-code",
        description="Generate QR codes",
        command="npx",
        args=["-y", "@anthropic/mcp-server-qrcode"],
        env_keys=[],
        category="utility",
        url="https://github.com/anthropics/mcp-server-qrcode",
    ),
    CatalogEntry(
        name="uuid",
        description="Generate UUIDs",
        command="npx",
        args=["-y", "@anthropic/mcp-server-uuid"],
        env_keys=[],
        category="utility",
        url="https://github.com/anthropics/mcp-server-uuid",
    ),
    CatalogEntry(
        name="crypto",
        description="Cryptographic operations (hash, encrypt)",
        command="npx",
        args=["-y", "@anthropic/mcp-server-crypto"],
        env_keys=[],
        category="utility",
        url="https://github.com/anthropics/mcp-server-crypto",
    ),
    # === AI & LLM ===
    CatalogEntry(
        name="openai",
        description="OpenAI API (GPT, DALL-E, etc.)",
        command="npx",
        args=["-y", "@anthropic/mcp-server-openai"],
        env_keys=["OPENAI_API_KEY"],
        category="ai",
        url="https://github.com/anthropics/mcp-server-openai",
    ),
    CatalogEntry(
        name="anthropic",
        description="Anthropic Claude API",
        command="npx",
        args=["-y", "@anthropic/mcp-server-anthropic"],
        env_keys=["ANTHROPIC_API_KEY"],
        category="ai",
        url="https://github.com/anthropics/mcp-server-anthropic",
    ),
    CatalogEntry(
        name="ollama",
        description="Local Ollama models",
        command="npx",
        args=["-y", "@anthropic/mcp-server-ollama"],
        env_keys=["OLLAMA_HOST"],
        category="ai",
        url="https://github.com/anthropics/mcp-server-ollama",
    ),
    CatalogEntry(
        name="huggingface",
        description="HuggingFace models and datasets",
        command="npx",
        args=["-y", "@huggingface/mcp-server-huggingface"],
        env_keys=["HF_TOKEN"],
        category="ai",
        url="https://github.com/huggingface/mcp-server-huggingface",
    ),
    CatalogEntry(
        name="replicate",
        description="Replicate AI models",
        command="npx",
        args=["-y", "@replicate/mcp-server-replicate"],
        env_keys=["REPLICATE_API_TOKEN"],
        category="ai",
        url="https://github.com/replicate/mcp-server-replicate",
    ),
    CatalogEntry(
        name="stability",
        description="Stability AI image generation",
        command="npx",
        args=["-y", "@stability/mcp-server-stability"],
        env_keys=["STABILITY_API_KEY"],
        category="ai",
        url="https://github.com/Stability-AI/mcp-server-stability",
    ),
    CatalogEntry(
        name="fal",
        description="Fal.ai image/video generation",
        command="uvx",
        args=["mcp-server-fal"],
        env_keys=["FAL_KEY"],
        category="ai",
        url="https://github.com/fal-ai/mcp-server-fal",
    ),
    # === E-commerce ===
    CatalogEntry(
        name="shopify",
        description="Shopify stores and products",
        command="npx",
        args=["-y", "@shopify/mcp-server-shopify"],
        env_keys=["SHOPIFY_STORE_URL", "SHOPIFY_ACCESS_TOKEN"],
        category="ecommerce",
        url="https://github.com/Shopify/mcp-server-shopify",
    ),
    CatalogEntry(
        name="woocommerce",
        description="WooCommerce orders and products",
        command="npx",
        args=["-y", "@anthropic/mcp-server-woocommerce"],
        env_keys=["WC_URL", "WC_KEY", "WC_SECRET"],
        category="ecommerce",
        url="https://github.com/anthropics/mcp-server-woocommerce",
    ),
    # === Analytics ===
    CatalogEntry(
        name="google-analytics",
        description="Google Analytics data",
        command="npx",
        args=["-y", "@anthropic/mcp-server-google-analytics"],
        env_keys=["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"],
        category="analytics",
        url="https://github.com/anthropics/mcp-server-google-analytics",
    ),
    CatalogEntry(
        name="mixpanel",
        description="Mixpanel analytics",
        command="npx",
        args=["-y", "@mixpanel/mcp-server-mixpanel"],
        env_keys=["MIXPANEL_TOKEN"],
        category="analytics",
        url="https://github.com/mixpanel/mcp-server-mixpanel",
    ),
    CatalogEntry(
        name="amplitude",
        description="Amplitude analytics",
        command="npx",
        args=["-y", "@amplitude/mcp-server-amplitude"],
        env_keys=["AMPLITUDE_API_KEY"],
        category="analytics",
        url="https://github.com/amplitude/mcp-server-amplitude",
    ),
    CatalogEntry(
        name="posthog",
        description="PostHog product analytics",
        command="npx",
        args=["-y", "@posthog/mcp-server-posthog"],
        env_keys=["POSTHOG_API_KEY", "POSTHOG_HOST"],
        category="analytics",
        url="https://github.com/PostHog/mcp-server-posthog",
    ),
    # === CRM & Marketing ===
    CatalogEntry(
        name="salesforce",
        description="Salesforce CRM",
        command="npx",
        args=["-y", "@salesforce/mcp-server-salesforce"],
        env_keys=["SF_USERNAME", "SF_PASSWORD", "SF_TOKEN"],
        category="crm",
        url="https://github.com/salesforce/mcp-server-salesforce",
    ),
    CatalogEntry(
        name="hubspot",
        description="HubSpot CRM and marketing",
        command="npx",
        args=["-y", "@hubspot/mcp-server-hubspot"],
        env_keys=["HUBSPOT_API_KEY"],
        category="crm",
        url="https://github.com/HubSpot/mcp-server-hubspot",
    ),
    CatalogEntry(
        name="mailchimp",
        description="Mailchimp email marketing",
        command="npx",
        args=["-y", "@mailchimp/mcp-server-mailchimp"],
        env_keys=["MAILCHIMP_API_KEY"],
        category="crm",
        url="https://github.com/mailchimp/mcp-server-mailchimp",
    ),
    CatalogEntry(
        name="intercom",
        description="Intercom customer messaging",
        command="npx",
        args=["-y", "@intercom/mcp-server-intercom"],
        env_keys=["INTERCOM_ACCESS_TOKEN"],
        category="crm",
        url="https://github.com/intercom/mcp-server-intercom",
    ),
    CatalogEntry(
        name="zendesk",
        description="Zendesk support tickets",
        command="npx",
        args=["-y", "@zendesk/mcp-server-zendesk"],
        env_keys=["ZENDESK_SUBDOMAIN", "ZENDESK_EMAIL", "ZENDESK_TOKEN"],
        category="crm",
        url="https://github.com/zendesk/mcp-server-zendesk",
    ),
    CatalogEntry(
        name="freshdesk",
        description="Freshdesk support tickets",
        command="npx",
        args=["-y", "@freshworks/mcp-server-freshdesk"],
        env_keys=["FRESHDESK_DOMAIN", "FRESHDESK_API_KEY"],
        category="crm",
        url="https://github.com/freshworks/mcp-server-freshdesk",
    ),
]

CATEGORIES = {
    "filesystem": "File System",
    "database": "Database",
    "development": "Development",
    "sysadmin": "Sysadmin & DevOps",
    "monitoring": "Monitoring",
    "cloud": "Cloud Platforms",
    "web": "Web & Browser",
    "search": "Search",
    "communication": "Communication",
    "productivity": "Productivity",
    "memory": "Memory & Knowledge",
    "finance": "Finance",
    "social": "Social Media",
    "utility": "Utilities",
    "ai": "AI & LLM",
    "ecommerce": "E-commerce",
    "analytics": "Analytics",
    "crm": "CRM & Marketing",
}


def get_by_category(category: str) -> list[CatalogEntry]:
    return [e for e in CATALOG if e.category == category]


def get_by_name(name: str) -> CatalogEntry | None:
    for entry in CATALOG:
        if entry.name == name:
            return entry
    return None


def search(query: str) -> list[CatalogEntry]:
    query = query.lower()
    return [
        e for e in CATALOG if query in e.name.lower() or query in e.description.lower()
    ]
