import logging
import os

import icat_plus_client
from dotenv import load_dotenv

# --- Load environment variables ---
load_dotenv()

# --- Setup logging ---
log_level = os.getenv("LOG_LEVEL", "INFO").upper()
logging.basicConfig(
    level=getattr(logging, log_level, logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("minedrac")

# --- Global configuration ---
host = os.getenv("icat_plus_server", "http://localhost:8080")

configuration = icat_plus_client.Configuration(host=host)

logger.debug(f"Configuration initialized with host={host}, log_level={log_level}")
