import typer
import subprocess
from rich.console import Console


app = typer.Typer(help="Git Wizard (gset) - Simple Git Automation Tool")
console = Console()


def run_git_command(command: list):
    try:
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        console.print(
            f"[bold red]Error running command:[/bold red] {' '.join(command)}"
        )
        console.print(f"[red]{e.stderr}[/red]")
        raise typer.Exit(code=1)


@app.command()
def config():
    """
    Configure global Git user name and email interactively.
    """
    console.print("[bold blue]🔧 Git Global Configuration Wizard[/bold blue]")

    name = typer.prompt("Enter your full name")
    email = typer.prompt("Enter your email")

    with console.status("[bold green]Setting up configuration...[/bold green]"):
        run_git_command(["git", "config", "--global", "user.name", name])
        run_git_command(["git", "config", "--global", "user.email", email])

    console.print("[bold green]✅ Configuration Updated Successfully![/bold green]")
    console.print("[dim]Current Global Config:[/dim]")

    current_config = run_git_command(["git", "config", "--global", "--list"])
    console.print(f"[cyan]{current_config}[/cyan]")


@app.command()
def push():
    """
    Push current directory changes to GitHub.
    Handles empty commits and push errors gracefully.
    """

    status = run_git_command(["git", "status", "--porcelain"])

    if not status:
        console.print("[yellow]Nothing to commit, working tree clean.[/yellow]")
        raise typer.Exit()

    commit_message = typer.prompt("Enter commit message")

    with console.status("[bold green]Processing...[/bold green]"):
        run_git_command(["git", "add", "."])
        run_git_command(["git", "commit", "-m", commit_message])

    try:
        with console.status("[bold green]Processing...[/bold green]"):
            result = subprocess.run(["git", "push"], capture_output=True, text=True)
        if result.returncode != 0:
            console.print("[bold red]Push Failed![/bold red]")
            console.print(f"[red]{result.stderr.strip()}[/red]")

            if "updates were rejected" in result.stderr.strip():
                console.print(
                    "[yellow]Hint: Try pulling changes first using 'git pull'[/yellow]"
                )

            elif "has no upstream branch" in result.stderr.lower():
                console.print(
                    "[yellow]Hint: No remote branch. Try 'git push --set-upstream origin main'[/yellow]"
                )

            raise typer.Exit(code=1)

        console.print("[bold green]✅ Successfully pushed to github[/bold green]")
    except subprocess.CalledProcessError as e:
        console.print(f"[bold red]Error:[/bold red] {e.stderr}")


if __name__ == "__main__":
    app()
