from kaizapy.exceptions import KaizaException

class Result:
  val = None
  err = None

  def __init__(self, **kwargs):
    if "val" in kwargs and "err" in kwargs:
      raise KaizaException("invalid Result object constructor")
    if "val" in kwargs:
      self.val = kwargs["val"]
    if "err" in kwargs:
      self.err = kwargs["err"]

  @property
  def has_err(self):
    return self.err is not None
  
  @property
  def has_val(self):
    return self.val is not None

  @staticmethod
  def error(err):
    result = Result(err=err)
    return result
  
  @staticmethod
  def value(value):
    result = Result(val=value)
    return result


__all__ = [
  "Result"
]