import requests
from kaizapy.result import Result

class NetworkService:
  __attrs__ = [
    "base_url",
    "http_session"
  ]

  def __init__(self, base_url):
    self.base_url = base_url
    s = requests.Session()
    self.http_session = requests.Session()

  def renew_headers(self, headers):
    self.http_session.headers = headers

  def get(self, path) -> Result:
    try:
      res = self.http_session.get(f"{self.base_url}{path}")
      res.raise_for_status()
      res_json = res.json()
      return Result.value(res_json["data"])
    except Exception as e:
      return Result.error(e)

  def post(self, path, body) -> Result:
    try:
      res = self.http_session.post(f"{self.base_url}{path}", json=body)
      res.raise_for_status()
      res_json = res.json()
      return Result.value(res_json["data"])
    except Exception as e:
      return Result.error(e)
    
def create_network_service(base_url: str) -> NetworkService:
  return NetworkService(base_url)

__all__ = [
  "NetworkService",
  "create_network_service",
]