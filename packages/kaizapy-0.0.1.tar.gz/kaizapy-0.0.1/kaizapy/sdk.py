from kaizapy.network_service import create_network_service
from datetime import datetime
from kaizapy.exceptions import KaizaException, err_sdk_not_initialized
from kaizapy.models import InitiatePaymentDTO, Payment

class _Credentials:
  def __init__(self, api_key_header, api_secret_header, base_url, init_payment_path):
    self.api_key_header = api_key_header
    self.api_secret_header = api_secret_header
    self.base_url = base_url
    self.init_payment_path = init_payment_path

  @staticmethod
  def from_json(json):
    return _Credentials(
      api_key_header=json["apiKeyHeader"],
      api_secret_header=json["apiSecretHeader"],
      base_url=json["baseURL"],
      init_payment_path=json["initPaymentPath"]
    )

class Kaiza:
  def __init__(self, api_key, api_secret):
    self.api_key = api_key
    self.api_secret = api_secret
    self._credential_url = "http://localhost:8080"
    self._credentials = None
    self._network_service = None

  @property
  def is_initialized(self):
    return self._credentials is not None
  
  def init_sdk(self):
    headers = {"X-Kch": datetime.now().isoformat()}
    temp_network_service = create_network_service(self._credential_url)
    temp_network_service.renew_headers(headers)
    creds = temp_network_service.get("/merchants/auth/credentials")
    if creds.has_err:
      raise creds.err
    
    self._credentials = _Credentials.from_json(creds.val)
    self._network_service = create_network_service(self._credentials.base_url)
    print("initializing sdk")
    print(self)

  def initiate_payment(self, data: InitiatePaymentDTO):
    if not self.is_initialized:
      raise KaizaException(err_sdk_not_initialized)
    
    headers = {
      self._credentials.api_key_header: self.api_key,
      self._credentials.api_secret_header: self.api_secret,
    }
    self._network_service.renew_headers(headers)
    body = {
      "amount": f"{data.amount}",
      "initiationRoute": f"{data.initiation_route}",
    }
    if data.redirect_url is not None and data.redirect_url != "":
      body["redirectUrl"] = data.redirect_url
    
    res = self._network_service.post("/payments/incoming", body=body)
    if res.has_err:
      raise res.err
    
    return Payment.from_url(res.val)
  
def create_sdk(api_key: str, api_secret: str) -> Kaiza:
  return Kaiza(api_key=api_key, api_secret=api_secret)

__all__ = [
  "Kaiza",
  "create_sdk",
]