err_sdk_not_initialized = "sdk not initialized"
err_malformed_response = "bad response"

class KaizaException(Exception):
  def __init__(self, message):
    self.message = message

  def __str__(self):
    return f"KaizaError(\n\tmessage: {self.message}\n)"

  def __repr__(self):
    return self.__str__()
  
class MalformedResponseException(KaizaException):
  def __init__(self):
    super().__init__(err_malformed_response)

__all__ = [
  "err_sdk_not_initialized",
  "err_malformed_response",
  "KaizaException",
  "MalformedResponseException",
]