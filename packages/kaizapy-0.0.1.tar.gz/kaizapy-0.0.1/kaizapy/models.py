from urllib.parse import urlsplit, parse_qs
from kaizapy.exceptions import MalformedResponseException

class ApiResponse:
  __attrs__ = [
    "status",
    "data",
    "message",
  ]

  def __init__(self, status, data, message = ""):
    self.status = status
    self.data = data
    self.message = message

  @staticmethod
  def from_json(json):
    return ApiResponse(json["status"], json["data"])
  
class InitiatePaymentDTO:
  __attrs__ = [
    "amount",
    "redirect_url",
    "initiation_route",
  ]

  def __init__(self, amount, redirect_url, initiation_route = "PYTHON_SDK"):
    self.amount = amount
    self.redirect_url = redirect_url
    self.initiation_route = initiation_route
    

class Payment:
  __attrs__ = [
    "status",
    "reference",
    "url",
  ]

  def __init__(self, status: str, reference: str, url: str):
    self.status = status
    self.reference = reference
    self.url = url

  def __eq__(self, other):
    if not isinstance(other, Payment):
      return False
    return self.reference == other.reference
  
  def __hash__(self):
    return hash(self.reference)

  def __repr__(self):
    return self.__str__()

  def __setattr__(self, name, value):
    if hasattr(self, name):
      raise AttributeError(f"cannot modify attribute {name}")
    super().__setattr__(name, value)

  def __str__(self):
    map = {
      "status": self.status,
      "reference": self.reference,
      "url": self.url,
    }
    return map.__str__()

  @staticmethod
  def from_url(uri: str):
    url_parts = urlsplit(uri)
    query = parse_qs(url_parts.query)
    q = query.get("ref")
    if q is None:
      raise MalformedResponseException()
    elif len(q) != 1:
      raise MalformedResponseException()
    return Payment(status="success", reference=q[0], url=uri)

__all__ = [
  "InitiatePaymentDTO",
  "Payment",
]