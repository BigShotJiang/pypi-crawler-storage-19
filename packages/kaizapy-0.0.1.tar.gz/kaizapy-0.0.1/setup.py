import setuptools

with open("README.md", "r") as fh:
    description = fh.read()

setuptools.setup(
    name="kaizapy",
    version="0.0.1",
    author="Peter Ndukwe",
    author_email="onumdev@gmail.com",
    packages=["kaizapy"],
    description="A KaizaPay package for accepting payments in your Python application",
    long_description=description,
    long_description_content_type="text/markdown",
    url="https://github.com/patrickishaf/kaizapy",
    license='MIT',
    python_requires='>=3.8',
    install_requires=[]
)