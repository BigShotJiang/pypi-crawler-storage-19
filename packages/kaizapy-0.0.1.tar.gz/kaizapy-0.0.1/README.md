# KaizaPY

A [KaizaPay](https://kaizapay.com) plugin for accepting payments in your Python application.

## Requirements
KaizaPay Python SDK builds upon the recent patterns in Python, thus your app should target:
- Python >= 3.10.3

## Getting Started
- Install the dependency in your project
```sh
pip install kaizapy
```
- Import the kaizapay SDK into your `.py` file
```python
from kaizapy import Kaiza, InitiatePaymentDTO
```
- Use the package
```python
api_key="your_api_key"
api_secret="your_api_secret"

kaiza_sdk = Kaiza(api_key, api_secret)
try:
    kaiza_sdk.init_sdk()
    payment = kaiza_sdk.initiate_payment(InitiatePaymentDTO(amount=100, redirect_url="https://python.org"))
    print(payment)
except Exception as e:
    print(e)
```

## Handling responses
The SDK produces two categories of responses - **Payment** objects and **KaizaException** objects 

- **Payment** object. It is returned when a call to `initiatePayment()` is successful after a preceding call to `initSDK()`

  | Parameter |  Type  | Description                                                                                             |
  |   :---   |  :---: |:--------------------------------------------------------------------------------------------------------|
  | `status` | String | Indicates the status of the payment. Possible values are: `success`, `error`                            |
  | `reference` | String | This is a unique identifier for the payment created. It is only returned when the `status` is `success` |

- **KaizaException**: Exceptions are thrown during your integration process. They are mostly issues surrounding the development process. Exceptions make use of the Python's `Exception` model which has the following parameters:
following model:

  | Parameter   |  Type  | Description                              |
    |:------------|  :---: |:-----------------------------------------|
  | `message`   | String | This is a short description of the exception |

