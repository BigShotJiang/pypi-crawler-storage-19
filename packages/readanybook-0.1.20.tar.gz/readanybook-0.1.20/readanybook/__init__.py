"""
ReadAnyBook - A RAG-based cheat sheet generator for books and papers.

This package provides a modular pipeline for:
1. Ingesting books/papers (PDF, EPUB, HTML)
2. Building structured knowledge stores (chunks + embeddings + metadata)
3. Running specialized generation passes (concepts, formulas, models, pseudocode)
4. Assembling comprehensive LaTeX or Markdown cheat sheets
5. Compiling to PDF (optional)

Example usage:
    from readanybook import build_cheatsheet
    
    # Generate Markdown cheat sheet (recommended for cloud notebooks)
    build_cheatsheet("book.pdf", output_format="markdown", llm_backend="huggingface", in_memory=True)
    
    # Generate LaTeX cheat sheet
    build_cheatsheet("book.pdf", output_format="latex", latex_only=True)
    
    # Using Ollama backend (requires local Ollama server)
    build_cheatsheet("book.pdf", llm_backend="ollama", llm_model="llama3.2")
"""

__version__ = "0.1.20"
__author__ = "ReadAnyBook Team"

from .core.pipeline import CheatSheetPipeline, build_cheatsheet
from .infra.settings import Settings

# Summarization module
from .summarization import (
    SummarizationOrchestrator,
    CheatSheetSchema,
    CoreConceptsSection,
    MathFormulasSection,
    ModelsTheoremsSection,
    AlgorithmSection,
)

# Evaluation module
from .evaluation import (
    RAGEvaluator,
    RegressionTestSuite,
    CheatSheetMetrics,
)

# Experiment tracking
from .infra.experiment_tracking import (
    ExperimentTracker,
    create_tracker,
)

__all__ = [
    # Core
    "CheatSheetPipeline",
    "Settings",
    "build_cheatsheet",
    "__version__",
    
    # Summarization
    "SummarizationOrchestrator",
    "CheatSheetSchema",
    "CoreConceptsSection",
    "MathFormulasSection",
    "ModelsTheoremsSection",
    "AlgorithmSection",
    
    # Evaluation
    "RAGEvaluator",
    "RegressionTestSuite",
    "CheatSheetMetrics",
    
    # Experiment tracking
    "ExperimentTracker",
    "create_tracker",
]
