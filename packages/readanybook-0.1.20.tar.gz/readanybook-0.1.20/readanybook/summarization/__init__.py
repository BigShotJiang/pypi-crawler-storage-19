"""
Summarization module for multi-pass content extraction.

This module orchestrates specialized passes for extracting:
- Core concepts and definitions
- Mathematical formulas  
- Models and theorems
- Algorithms and pseudocode
- Global outline and structure
"""

from .schema import (
    CheatSheetSchema,
    CoreConceptsSection,
    MathFormulasSection,
    ModelsTheoremsSection,
    AlgorithmSection,
    PassResult,
)
from .orchestrator import SummarizationOrchestrator
from .passes import (
    CoreConceptsPass,
    MathFormulasPass,
    ModelsTheoremsPass,
    AlgorithmsPass,
    GlobalOutlinePass,
)

__all__ = [
    "CheatSheetSchema",
    "CoreConceptsSection",
    "MathFormulasSection",
    "ModelsTheoremsSection",
    "AlgorithmSection",
    "PassResult",
    "SummarizationOrchestrator",
    "CoreConceptsPass",
    "MathFormulasPass",
    "ModelsTheoremsPass",
    "AlgorithmsPass",
    "GlobalOutlinePass",
]
