"""
Evaluation module for RAG and cheat sheet quality assessment.
"""

from .rag_eval import RAGEvaluator, RetrievalMetrics
from .metrics import (
    calculate_bleu,
    calculate_rouge,
    evaluate_latex_quality,
    evaluate_coverage,
    CheatSheetMetrics,
)
from .regression_suite import (
    RegressionTestSuite,
    TestCase,
    TestResult,
    RegressionReport,
)

__all__ = [
    "RAGEvaluator",
    "RetrievalMetrics",
    "calculate_bleu",
    "calculate_rouge",
    "evaluate_latex_quality",
    "evaluate_coverage",
    "CheatSheetMetrics",
    "RegressionTestSuite",
    "TestCase",
    "TestResult",
    "RegressionReport",
]
