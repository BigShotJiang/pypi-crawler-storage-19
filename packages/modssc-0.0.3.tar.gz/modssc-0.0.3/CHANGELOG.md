# Changelog

All notable changes to this project will be documented in this file.

The format is based on "Keep a Changelog", and this project adheres to Semantic Versioning.

## 0.0.3
- Fixed bugs and improved logging for inductive methods.

## 0.0.2
- Updated github workflow

## 0.0.1
- Initial public release.
