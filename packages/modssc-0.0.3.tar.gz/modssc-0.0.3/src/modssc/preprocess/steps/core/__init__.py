"""Core preprocessing steps."""
