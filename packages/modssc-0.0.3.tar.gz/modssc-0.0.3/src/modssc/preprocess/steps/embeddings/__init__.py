"""Embedding/featurizer steps."""
