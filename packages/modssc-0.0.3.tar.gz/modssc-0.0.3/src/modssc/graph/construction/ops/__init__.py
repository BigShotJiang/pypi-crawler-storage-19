"""Small graph construction operations."""
