"""Scripts for putplace-assist."""
