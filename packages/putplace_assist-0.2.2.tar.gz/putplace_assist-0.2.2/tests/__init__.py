"""Tests for putplace-assist."""
