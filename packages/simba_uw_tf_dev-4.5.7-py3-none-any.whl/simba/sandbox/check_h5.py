
import h5py
print("HDF5 library version:", h5py.version.hdf5_version)
print("h5py version:", h5py.__version__)

PATH = r"E:\h5_read\20251208_TS1_Gr3_T1.h5"

f = h5py.File(PATH, "r")
print(list(f.keys()))