"""MCP (Model Context Protocol) server for Asqav.

This module provides an MCP server that exposes Asqav functionality
as tools for AI models like Claude.

Includes MCP Gateway Mode for signing and verifying tool calls.

Usage:
    Run as MCP server: python -m asqav.mcp
    Run as Gateway: python -m asqav.mcp --gateway
    Or use with Claude Desktop by adding to config.
"""

from __future__ import annotations

import base64
import json
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from typing import Any

# MCP protocol constants
JSONRPC_VERSION = "2.0"


@dataclass
class SignedToolCall:
    """A tool call with ML-DSA signature.

    Attributes:
        call_id: Unique identifier for this call.
        tool_name: Name of the tool being called.
        arguments: Tool arguments.
        agent_id: ID of the calling agent.
        timestamp: Unix timestamp of the call.
        signature: Base64-encoded ML-DSA signature.
    """

    call_id: str
    tool_name: str
    arguments: dict[str, Any]
    agent_id: str
    timestamp: float
    signature: str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SignedToolCall:
        """Create from dictionary."""
        return cls(**data)

    def get_signing_payload(self) -> bytes:
        """Get the payload that was/will be signed."""
        payload = {
            "call_id": self.call_id,
            "tool_name": self.tool_name,
            "arguments": self.arguments,
            "agent_id": self.agent_id,
            "timestamp": self.timestamp,
        }
        return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


@dataclass
class SignedToolResult:
    """A tool result with ML-DSA signature.

    Attributes:
        call_id: ID of the original call.
        result: Tool result data.
        agent_id: ID of the agent that executed the call.
        timestamp: Unix timestamp of the result.
        success: Whether the call succeeded.
        signature: Base64-encoded ML-DSA signature.
    """

    call_id: str
    result: dict[str, Any]
    agent_id: str
    timestamp: float
    success: bool
    signature: str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SignedToolResult:
        """Create from dictionary."""
        return cls(**data)

    def get_signing_payload(self) -> bytes:
        """Get the payload that was/will be signed."""
        payload = {
            "call_id": self.call_id,
            "result": self.result,
            "agent_id": self.agent_id,
            "timestamp": self.timestamp,
            "success": self.success,
        }
        return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


@dataclass
class GatewayAuditEntry:
    """Audit log entry for gateway operations."""

    call_id: str
    tool_name: str
    agent_id: str
    timestamp: float
    success: bool
    duration_ms: float
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


class AsqavMCPServer:
    """MCP server exposing Asqav tools."""

    def __init__(self) -> None:
        """Initialize the MCP server."""
        self._agents: dict[str, Any] = {}

    def get_tools(self) -> list[dict[str, Any]]:
        """Return list of available tools."""
        return [
            {
                "name": "asqav_create_agent",
                "description": "Create a new quantum-safe AI agent identity using ML-DSA signatures",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "Name for the agent",
                        },
                        "algorithm": {
                            "type": "string",
                            "description": "ML-DSA algorithm (ml-dsa-44, ml-dsa-65, ml-dsa-87)",
                            "default": "ml-dsa-65",
                        },
                        "capabilities": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of capabilities/permissions",
                            "default": [],
                        },
                    },
                    "required": ["name"],
                },
            },
            {
                "name": "asqav_issue_token",
                "description": "Issue a quantum-safe JWT token for an agent",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "agent_id": {
                            "type": "string",
                            "description": "ID of the agent to issue token for",
                        },
                        "ttl": {
                            "type": "integer",
                            "description": "Token time-to-live in seconds",
                            "default": 3600,
                        },
                    },
                    "required": ["agent_id"],
                },
            },
            {
                "name": "asqav_log_action",
                "description": "Log an action for runtime monitoring",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "agent_id": {
                            "type": "string",
                            "description": "ID of the agent performing the action",
                        },
                        "action": {
                            "type": "string",
                            "description": "Action being performed (e.g., read:file, write:data)",
                        },
                        "metadata": {
                            "type": "object",
                            "description": "Additional metadata about the action",
                            "default": {},
                        },
                    },
                    "required": ["agent_id", "action"],
                },
            },
            {
                "name": "asqav_assess_risk",
                "description": "Assess quantum security risk of a cryptographic algorithm",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "algorithm": {
                            "type": "string",
                            "description": "Algorithm to assess (e.g., ES256, RS256, ML-DSA-65)",
                        },
                    },
                    "required": ["algorithm"],
                },
            },
            {
                "name": "asqav_check_revoked",
                "description": "Check if an agent has been revoked",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "agent_id": {
                            "type": "string",
                            "description": "ID of the agent to check",
                        },
                    },
                    "required": ["agent_id"],
                },
            },
            {
                "name": "asqav_list_agents",
                "description": "List all agents created in this session",
                "inputSchema": {
                    "type": "object",
                    "properties": {},
                },
            },
        ]

    def handle_tool_call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Handle a tool call.

        Args:
            name: Tool name.
            arguments: Tool arguments.

        Returns:
            Tool result.
        """
        if name == "asqav_create_agent":
            return self._create_agent(arguments)
        elif name == "asqav_issue_token":
            return self._issue_token(arguments)
        elif name == "asqav_log_action":
            return self._log_action(arguments)
        elif name == "asqav_assess_risk":
            return self._assess_risk(arguments)
        elif name == "asqav_check_revoked":
            return self._check_revoked(arguments)
        elif name == "asqav_list_agents":
            return self._list_agents()
        else:
            return {"error": f"Unknown tool: {name}"}

    def _create_agent(self, args: dict[str, Any]) -> dict[str, Any]:
        """Create a new agent."""
        from .core.agent import SecureAgent

        try:
            agent = SecureAgent.create(
                name=args["name"],
                algorithm=args.get("algorithm", "ml-dsa-65"),
                capabilities=args.get("capabilities", []),
            )
            self._agents[agent.agent_id] = agent

            return {
                "success": True,
                "agent_id": agent.agent_id,
                "name": agent.name,
                "algorithm": agent.algorithm.value,
                "key_id": agent.key_id,
                "capabilities": agent.capabilities,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _issue_token(self, args: dict[str, Any]) -> dict[str, Any]:
        """Issue a token for an agent."""
        agent_id = args["agent_id"]

        if agent_id not in self._agents:
            return {"success": False, "error": f"Agent not found: {agent_id}"}

        agent = self._agents[agent_id]
        try:
            token = agent.issue_token_string(ttl=args.get("ttl", 3600))
            return {
                "success": True,
                "token": token,
                "agent_id": agent_id,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _log_action(self, args: dict[str, Any]) -> dict[str, Any]:
        """Log an action."""
        agent_id = args["agent_id"]

        if agent_id not in self._agents:
            return {"success": False, "error": f"Agent not found: {agent_id}"}

        agent = self._agents[agent_id]
        try:
            with agent.session() as session:
                session.log_action(args["action"], metadata=args.get("metadata", {}))

            return {
                "success": True,
                "agent_id": agent_id,
                "action": args["action"],
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _assess_risk(self, args: dict[str, Any]) -> dict[str, Any]:
        """Assess algorithm risk."""
        from .core.tokens import assess_token_risk

        try:
            result = assess_token_risk(args["algorithm"])
            return {"success": True, **result}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _check_revoked(self, args: dict[str, Any]) -> dict[str, Any]:
        """Check if agent is revoked."""
        from .core.revocation import is_revoked

        agent_id = args["agent_id"]
        try:
            revoked = is_revoked(agent_id)
            return {
                "success": True,
                "agent_id": agent_id,
                "is_revoked": revoked,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _list_agents(self) -> dict[str, Any]:
        """List all agents."""
        agents = []
        for agent_id, agent in self._agents.items():
            agents.append({
                "agent_id": agent_id,
                "name": agent.name,
                "algorithm": agent.algorithm.value,
                "capabilities": agent.capabilities,
            })
        return {"success": True, "agents": agents, "count": len(agents)}

    def handle_request(self, request: dict[str, Any]) -> dict[str, Any] | None:
        """Handle a JSON-RPC request.

        Args:
            request: JSON-RPC request.

        Returns:
            JSON-RPC response, or None for notifications.
        """
        method = request.get("method", "")
        params = request.get("params", {})
        request_id = request.get("id")

        if method == "initialize":
            return {
                "jsonrpc": JSONRPC_VERSION,
                "id": request_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {
                        "name": "asqav",
                        "version": "0.1.0",
                    },
                },
            }

        elif method == "tools/list":
            return {
                "jsonrpc": JSONRPC_VERSION,
                "id": request_id,
                "result": {"tools": self.get_tools()},
            }

        elif method == "tools/call":
            tool_name = params.get("name", "")
            arguments = params.get("arguments", {})
            result = self.handle_tool_call(tool_name, arguments)

            return {
                "jsonrpc": JSONRPC_VERSION,
                "id": request_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(result, indent=2),
                        }
                    ],
                },
            }

        elif method == "notifications/initialized":
            return None  # No response for notifications

        else:
            return {
                "jsonrpc": JSONRPC_VERSION,
                "id": request_id,
                "error": {
                    "code": -32601,
                    "message": f"Method not found: {method}",
                },
            }


class MCPGateway:
    """MCP Gateway for signing and proxying tool calls.

    The gateway acts as a signing proxy between AI models and backend
    MCP servers. All tool calls are signed with ML-DSA and logged.

    Example:
        from asqav import MCPGateway, SecureAgent

        agent = SecureAgent.create(name="gateway-agent")
        gateway = MCPGateway(agent)

        # Sign a tool call
        signed = gateway.sign_tool_call("file_read", {"path": "/tmp/test"})

        # Verify a signed call
        is_valid = gateway.verify_tool_call(signed)
    """

    def __init__(
        self,
        agent: Any | None = None,
        backend_command: list[str] | None = None,
    ) -> None:
        """Initialize the gateway.

        Args:
            agent: SecureAgent for signing. If None, creates one.
            backend_command: Command to run backend MCP server (optional).
        """
        from .core.identity import IdentityProvider

        if agent is None:
            from .core.agent import SecureAgent

            agent = SecureAgent.create(
                name="mcp-gateway",
                capabilities=["mcp:*"],
            )
        self._agent = agent
        self._identity = IdentityProvider(agent.algorithm)
        self._backend_command = backend_command
        self._backend_process: subprocess.Popen[str] | None = None
        self._audit_log: list[GatewayAuditEntry] = []
        self._call_counter = 0

    @property
    def agent_id(self) -> str:
        """Get the gateway agent's ID."""
        return self._agent.agent_id

    @property
    def public_key(self) -> bytes:
        """Get the gateway agent's public key."""
        return self._agent.public_key

    @property
    def public_key_b64(self) -> str:
        """Get the gateway agent's public key as base64."""
        return self._agent.public_key_b64

    def _generate_call_id(self) -> str:
        """Generate a unique call ID."""
        import uuid

        self._call_counter += 1
        return f"call_{uuid.uuid4().hex[:12]}_{self._call_counter}"

    def sign_tool_call(
        self,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> SignedToolCall:
        """Sign a tool call with ML-DSA.

        Args:
            tool_name: Name of the tool.
            arguments: Tool arguments.

        Returns:
            SignedToolCall with ML-DSA signature.
        """
        call_id = self._generate_call_id()
        timestamp = time.time()

        # Create the call object (without signature first)
        call = SignedToolCall(
            call_id=call_id,
            tool_name=tool_name,
            arguments=arguments,
            agent_id=self._agent.agent_id,
            timestamp=timestamp,
            signature="",  # Placeholder
        )

        # Sign the payload
        payload = call.get_signing_payload()
        sig = self._identity.sign(payload, self._agent.keypair)
        call.signature = base64.b64encode(sig.value).decode()

        return call

    def sign_tool_result(
        self,
        call_id: str,
        result: dict[str, Any],
        success: bool = True,
    ) -> SignedToolResult:
        """Sign a tool result with ML-DSA.

        Args:
            call_id: ID of the original call.
            result: Tool result data.
            success: Whether the call succeeded.

        Returns:
            SignedToolResult with ML-DSA signature.
        """
        timestamp = time.time()

        # Create the result object (without signature first)
        tool_result = SignedToolResult(
            call_id=call_id,
            result=result,
            agent_id=self._agent.agent_id,
            timestamp=timestamp,
            success=success,
            signature="",  # Placeholder
        )

        # Sign the payload
        payload = tool_result.get_signing_payload()
        sig = self._identity.sign(payload, self._agent.keypair)
        tool_result.signature = base64.b64encode(sig.value).decode()

        return tool_result

    def verify_tool_call(
        self,
        signed_call: SignedToolCall,
        public_key: bytes | None = None,
    ) -> bool:
        """Verify a signed tool call.

        Args:
            signed_call: The signed call to verify.
            public_key: Public key to verify against. If None, uses own key.

        Returns:
            True if signature is valid.
        """
        from .core.identity import Signature

        if public_key is None:
            public_key = self._agent.public_key

        payload = signed_call.get_signing_payload()
        signature_bytes = base64.b64decode(signed_call.signature)
        signature = Signature(
            value=signature_bytes,
            algorithm=self._agent.algorithm,
            key_id="",
        )

        try:
            return self._identity.verify(payload, signature, public_key)
        except Exception:
            return False

    def verify_tool_result(
        self,
        signed_result: SignedToolResult,
        public_key: bytes | None = None,
    ) -> bool:
        """Verify a signed tool result.

        Args:
            signed_result: The signed result to verify.
            public_key: Public key to verify against. If None, uses own key.

        Returns:
            True if signature is valid.
        """
        from .core.identity import Signature

        if public_key is None:
            public_key = self._agent.public_key

        payload = signed_result.get_signing_payload()
        signature_bytes = base64.b64decode(signed_result.signature)
        signature = Signature(
            value=signature_bytes,
            algorithm=self._agent.algorithm,
            key_id="",
        )

        try:
            return self._identity.verify(payload, signature, public_key)
        except Exception:
            return False

    def execute_signed(
        self,
        tool_name: str,
        arguments: dict[str, Any],
        executor: Any | None = None,
    ) -> SignedToolResult:
        """Execute a tool call with signing and logging.

        Args:
            tool_name: Name of the tool.
            arguments: Tool arguments.
            executor: Callable to execute the tool. If None, uses backend.

        Returns:
            SignedToolResult with execution result and signature.
        """
        start_time = time.time()
        signed_call = self.sign_tool_call(tool_name, arguments)
        success = True
        error = None
        result: dict[str, Any] = {}

        try:
            if executor is not None:
                result = executor(tool_name, arguments)
            elif self._backend_process is not None:
                result = self._call_backend(tool_name, arguments)
            else:
                result = {"error": "No executor or backend configured"}
                success = False
        except Exception as e:
            result = {"error": str(e)}
            success = False
            error = str(e)

        end_time = time.time()
        duration_ms = (end_time - start_time) * 1000

        # Log the operation
        audit_entry = GatewayAuditEntry(
            call_id=signed_call.call_id,
            tool_name=tool_name,
            agent_id=self._agent.agent_id,
            timestamp=signed_call.timestamp,
            success=success,
            duration_ms=duration_ms,
            error=error,
        )
        self._audit_log.append(audit_entry)

        # Also log to agent session
        with self._agent.session() as session:
            session.log_action(
                f"mcp:{tool_name}",
                metadata={
                    "call_id": signed_call.call_id,
                    "arguments": arguments,
                    "success": success,
                    "duration_ms": duration_ms,
                },
            )

        return self.sign_tool_result(signed_call.call_id, result, success)

    def get_audit_log(
        self,
        limit: int = 100,
        tool_name: str | None = None,
    ) -> list[dict[str, Any]]:
        """Get the gateway audit log.

        Args:
            limit: Maximum entries to return.
            tool_name: Filter by tool name.

        Returns:
            List of audit entries.
        """
        entries = self._audit_log
        if tool_name:
            entries = [e for e in entries if e.tool_name == tool_name]
        return [e.to_dict() for e in entries[-limit:]]

    def _start_backend(self) -> None:
        """Start the backend MCP server process."""
        if self._backend_command and self._backend_process is None:
            self._backend_process = subprocess.Popen(
                self._backend_command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )

    def _call_backend(
        self,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> dict[str, Any]:
        """Call a tool on the backend MCP server."""
        if self._backend_process is None:
            self._start_backend()

        if self._backend_process is None or self._backend_process.stdin is None:
            return {"error": "Backend not available"}

        request = {
            "jsonrpc": JSONRPC_VERSION,
            "id": self._call_counter,
            "method": "tools/call",
            "params": {"name": tool_name, "arguments": arguments},
        }

        self._backend_process.stdin.write(json.dumps(request) + "\n")
        self._backend_process.stdin.flush()

        if self._backend_process.stdout is None:
            return {"error": "Backend stdout not available"}

        response_line = self._backend_process.stdout.readline()
        if not response_line:
            return {"error": "No response from backend"}

        try:
            response: dict[str, Any] = json.loads(response_line)
            result: dict[str, Any] = response.get("result", {})
            return result
        except json.JSONDecodeError:
            return {"error": "Invalid response from backend"}

    def close(self) -> None:
        """Close the backend process if running."""
        if self._backend_process is not None:
            self._backend_process.terminate()
            self._backend_process = None


class AsqavMCPGatewayServer(AsqavMCPServer):
    """MCP server with gateway signing capabilities.

    Extends AsqavMCPServer with tools for signing and verifying
    tool calls using ML-DSA signatures.
    """

    def __init__(self) -> None:
        """Initialize the gateway server."""
        super().__init__()
        self._gateways: dict[str, MCPGateway] = {}

    def get_tools(self) -> list[dict[str, Any]]:
        """Return list of available tools including gateway tools."""
        base_tools = super().get_tools()
        gateway_tools = [
            {
                "name": "asqav_gateway_create",
                "description": "Create an MCP gateway for signing tool calls",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "agent_id": {
                            "type": "string",
                            "description": "Agent ID to use (optional, creates new if not provided)",
                        },
                    },
                },
            },
            {
                "name": "asqav_gateway_sign_call",
                "description": "Sign a tool call with ML-DSA",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "gateway_id": {
                            "type": "string",
                            "description": "Gateway/agent ID",
                        },
                        "tool_name": {
                            "type": "string",
                            "description": "Name of the tool to call",
                        },
                        "arguments": {
                            "type": "object",
                            "description": "Tool arguments",
                        },
                    },
                    "required": ["gateway_id", "tool_name", "arguments"],
                },
            },
            {
                "name": "asqav_gateway_verify_call",
                "description": "Verify a signed tool call",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "signed_call": {
                            "type": "object",
                            "description": "The signed call object to verify",
                        },
                        "public_key_b64": {
                            "type": "string",
                            "description": "Base64 public key to verify against",
                        },
                    },
                    "required": ["signed_call"],
                },
            },
            {
                "name": "asqav_gateway_audit_log",
                "description": "Get the gateway audit log",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "gateway_id": {
                            "type": "string",
                            "description": "Gateway/agent ID",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum entries to return",
                            "default": 100,
                        },
                    },
                    "required": ["gateway_id"],
                },
            },
        ]
        return base_tools + gateway_tools

    def handle_tool_call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Handle a tool call including gateway tools."""
        if name == "asqav_gateway_create":
            return self._gateway_create(arguments)
        elif name == "asqav_gateway_sign_call":
            return self._gateway_sign_call(arguments)
        elif name == "asqav_gateway_verify_call":
            return self._gateway_verify_call(arguments)
        elif name == "asqav_gateway_audit_log":
            return self._gateway_audit_log(arguments)
        else:
            return super().handle_tool_call(name, arguments)

    def _gateway_create(self, args: dict[str, Any]) -> dict[str, Any]:
        """Create a new gateway."""
        agent_id = args.get("agent_id")

        if agent_id and agent_id in self._agents:
            # Use existing agent
            gateway = MCPGateway(agent=self._agents[agent_id])
        else:
            # Create new gateway with new agent
            gateway = MCPGateway()
            self._agents[gateway.agent_id] = gateway._agent

        self._gateways[gateway.agent_id] = gateway

        return {
            "success": True,
            "gateway_id": gateway.agent_id,
            "public_key": gateway.public_key_b64,
        }

    def _gateway_sign_call(self, args: dict[str, Any]) -> dict[str, Any]:
        """Sign a tool call."""
        gateway_id = args["gateway_id"]

        if gateway_id not in self._gateways:
            return {"success": False, "error": f"Gateway not found: {gateway_id}"}

        gateway = self._gateways[gateway_id]
        try:
            signed = gateway.sign_tool_call(
                args["tool_name"],
                args["arguments"],
            )
            return {
                "success": True,
                "signed_call": signed.to_dict(),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _gateway_verify_call(self, args: dict[str, Any]) -> dict[str, Any]:
        """Verify a signed tool call."""
        try:
            signed_call = SignedToolCall.from_dict(args["signed_call"])

            # Find gateway for verification
            gateway_id = signed_call.agent_id
            public_key: bytes | None = None

            if "public_key_b64" in args:
                public_key = base64.b64decode(args["public_key_b64"])
            elif gateway_id in self._gateways:
                public_key = self._gateways[gateway_id].public_key

            if public_key is None:
                return {"success": False, "error": "No public key available"}

            # Need a gateway for verification
            gateway = (
                self._gateways[gateway_id]
                if gateway_id in self._gateways
                else MCPGateway()
            )

            is_valid = gateway.verify_tool_call(signed_call, public_key)

            return {
                "success": True,
                "is_valid": is_valid,
                "call_id": signed_call.call_id,
                "tool_name": signed_call.tool_name,
                "agent_id": signed_call.agent_id,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _gateway_audit_log(self, args: dict[str, Any]) -> dict[str, Any]:
        """Get the gateway audit log."""
        gateway_id = args["gateway_id"]

        if gateway_id not in self._gateways:
            return {"success": False, "error": f"Gateway not found: {gateway_id}"}

        gateway = self._gateways[gateway_id]
        limit = args.get("limit", 100)

        return {
            "success": True,
            "entries": gateway.get_audit_log(limit=limit),
            "count": len(gateway._audit_log),
        }


def run_server(gateway_mode: bool = False) -> None:
    """Run the MCP server on stdin/stdout.

    Args:
        gateway_mode: If True, use gateway server with signing tools.
    """
    if gateway_mode:
        server: AsqavMCPServer = AsqavMCPGatewayServer()
    else:
        server = AsqavMCPServer()

    while True:
        try:
            line = sys.stdin.readline()
            if not line:
                break

            request = json.loads(line)
            response = server.handle_request(request)

            if response is not None:
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()

        except json.JSONDecodeError:
            continue
        except KeyboardInterrupt:
            break


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Asqav MCP Server")
    parser.add_argument(
        "--gateway",
        action="store_true",
        help="Run in gateway mode with signing tools",
    )
    args = parser.parse_args()

    run_server(gateway_mode=args.gateway)
