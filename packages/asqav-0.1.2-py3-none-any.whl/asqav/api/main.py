"""FastAPI application for Asqav Cloud API."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from .config import settings
from .rate_limit import limiter


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan handler."""
    # Startup
    yield
    # Shutdown


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    application = FastAPI(
        title="Asqav API",
        description="Quantum-safe identity and runtime monitoring for AI agents",
        version="0.1.0",
        lifespan=lifespan,
    )

    # Rate limiting
    if settings.rate_limit_enabled:
        application.state.limiter = limiter
        application.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

    # CORS middleware
    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Custom rate limit exceeded handler with more detail
    @application.exception_handler(RateLimitExceeded)
    async def rate_limit_handler(request: Request, exc: RateLimitExceeded) -> JSONResponse:
        return JSONResponse(
            status_code=429,
            content={
                "error": "rate_limit_exceeded",
                "message": f"Rate limit exceeded: {exc.detail}",
                "retry_after": getattr(exc, "retry_after", None),
            },
        )

    # Include routers
    from .routes import agents, health, qml, sessions

    application.include_router(health.router, prefix=settings.api_prefix)
    application.include_router(agents.router, prefix=settings.api_prefix)
    application.include_router(sessions.router, prefix=settings.api_prefix)
    application.include_router(qml.router, prefix=settings.api_prefix)

    return application


app = create_app()
