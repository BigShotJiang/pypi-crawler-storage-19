"""Redis caching for Asqav API.

Provides caching for:
- Token verification results
- Agent public keys
- Revocation status
- Rate limit counters
"""

from __future__ import annotations

import json
from datetime import timedelta
from typing import Any

from .config import settings

# Redis client (lazy initialized)
_redis_client: Any = None


def get_redis_client() -> Any:
    """Get or create Redis client.

    Returns None if Redis is not configured.
    """
    global _redis_client

    if not settings.redis_url:
        return None

    if _redis_client is None:
        try:
            import redis

            _redis_client = redis.from_url(
                settings.redis_url,
                decode_responses=True,
            )
            # Test connection
            _redis_client.ping()
        except Exception:
            _redis_client = None

    return _redis_client


class TokenCache:
    """Cache for token verification results.

    Stores verified token claims to avoid repeated verification
    of the same token.
    """

    PREFIX = "asqav:token:"
    DEFAULT_TTL = timedelta(minutes=5)

    @classmethod
    def _key(cls, token_hash: str) -> str:
        """Generate cache key for token."""
        return f"{cls.PREFIX}{token_hash}"

    @classmethod
    def get(cls, token_hash: str) -> dict[str, Any] | None:
        """Get cached token verification result.

        Args:
            token_hash: SHA256 hash of the token.

        Returns:
            Cached claims dict, or None if not cached.
        """
        client = get_redis_client()
        if not client:
            return None

        try:
            data = client.get(cls._key(token_hash))
            if data:
                return json.loads(data)
        except Exception:
            pass

        return None

    @classmethod
    def set(
        cls,
        token_hash: str,
        claims: dict[str, Any],
        ttl: timedelta | None = None,
    ) -> None:
        """Cache token verification result.

        Args:
            token_hash: SHA256 hash of the token.
            claims: Verified token claims.
            ttl: Time to live. Defaults to 5 minutes.
        """
        client = get_redis_client()
        if not client:
            return

        try:
            client.setex(
                cls._key(token_hash),
                ttl or cls.DEFAULT_TTL,
                json.dumps(claims),
            )
        except Exception:
            pass

    @classmethod
    def invalidate(cls, token_hash: str) -> None:
        """Remove cached token."""
        client = get_redis_client()
        if not client:
            return

        try:
            client.delete(cls._key(token_hash))
        except Exception:
            pass


class PublicKeyCache:
    """Cache for agent public keys.

    Avoids repeated database lookups for public keys.
    """

    PREFIX = "asqav:pubkey:"
    DEFAULT_TTL = timedelta(hours=1)

    @classmethod
    def _key(cls, agent_id: str, key_id: str) -> str:
        """Generate cache key."""
        return f"{cls.PREFIX}{agent_id}:{key_id}"

    @classmethod
    def get(cls, agent_id: str, key_id: str) -> bytes | None:
        """Get cached public key.

        Args:
            agent_id: Agent identifier.
            key_id: Key identifier.

        Returns:
            Public key bytes, or None if not cached.
        """
        client = get_redis_client()
        if not client:
            return None

        try:
            # Keys are stored as base64
            import base64

            data = client.get(cls._key(agent_id, key_id))
            if data:
                return base64.b64decode(data)
        except Exception:
            pass

        return None

    @classmethod
    def set(
        cls,
        agent_id: str,
        key_id: str,
        public_key: bytes,
        ttl: timedelta | None = None,
    ) -> None:
        """Cache public key.

        Args:
            agent_id: Agent identifier.
            key_id: Key identifier.
            public_key: Public key bytes.
            ttl: Time to live. Defaults to 1 hour.
        """
        client = get_redis_client()
        if not client:
            return

        try:
            import base64

            client.setex(
                cls._key(agent_id, key_id),
                ttl or cls.DEFAULT_TTL,
                base64.b64encode(public_key).decode(),
            )
        except Exception:
            pass

    @classmethod
    def invalidate(cls, agent_id: str, key_id: str) -> None:
        """Remove cached key."""
        client = get_redis_client()
        if not client:
            return

        try:
            client.delete(cls._key(agent_id, key_id))
        except Exception:
            pass

    @classmethod
    def invalidate_agent(cls, agent_id: str) -> None:
        """Remove all cached keys for an agent."""
        client = get_redis_client()
        if not client:
            return

        try:
            # Use SCAN to find all keys for this agent
            pattern = f"{cls.PREFIX}{agent_id}:*"
            cursor = 0
            while True:
                cursor, keys = client.scan(cursor, match=pattern, count=100)
                if keys:
                    client.delete(*keys)
                if cursor == 0:
                    break
        except Exception:
            pass


class RevocationCache:
    """Cache for agent revocation status.

    Quick lookup for revoked agents without database query.
    """

    PREFIX = "asqav:revoked:"
    DEFAULT_TTL = timedelta(minutes=5)

    @classmethod
    def _key(cls, agent_id: str) -> str:
        """Generate cache key."""
        return f"{cls.PREFIX}{agent_id}"

    @classmethod
    def is_revoked(cls, agent_id: str) -> bool | None:
        """Check if agent is revoked.

        Args:
            agent_id: Agent identifier.

        Returns:
            True if revoked, False if not revoked, None if not cached.
        """
        client = get_redis_client()
        if not client:
            return None

        try:
            data = client.get(cls._key(agent_id))
            if data is not None:
                return data == "1"
        except Exception:
            pass

        return None

    @classmethod
    def set(
        cls,
        agent_id: str,
        is_revoked: bool,
        ttl: timedelta | None = None,
    ) -> None:
        """Cache revocation status.

        Args:
            agent_id: Agent identifier.
            is_revoked: Whether agent is revoked.
            ttl: Time to live. Defaults to 5 minutes.
        """
        client = get_redis_client()
        if not client:
            return

        try:
            client.setex(
                cls._key(agent_id),
                ttl or cls.DEFAULT_TTL,
                "1" if is_revoked else "0",
            )
        except Exception:
            pass

    @classmethod
    def invalidate(cls, agent_id: str) -> None:
        """Remove cached status (call after revocation)."""
        client = get_redis_client()
        if not client:
            return

        try:
            client.delete(cls._key(agent_id))
        except Exception:
            pass


class SessionCache:
    """Cache for active sessions.

    Quick lookup for session status during action logging.
    """

    PREFIX = "asqav:session:"
    DEFAULT_TTL = timedelta(hours=24)

    @classmethod
    def _key(cls, session_id: str) -> str:
        """Generate cache key."""
        return f"{cls.PREFIX}{session_id}"

    @classmethod
    def get(cls, session_id: str) -> dict[str, Any] | None:
        """Get cached session data.

        Args:
            session_id: Session identifier.

        Returns:
            Session data dict, or None if not cached.
        """
        client = get_redis_client()
        if not client:
            return None

        try:
            data = client.get(cls._key(session_id))
            if data:
                return json.loads(data)
        except Exception:
            pass

        return None

    @classmethod
    def set(
        cls,
        session_id: str,
        data: dict[str, Any],
        ttl: timedelta | None = None,
    ) -> None:
        """Cache session data.

        Args:
            session_id: Session identifier.
            data: Session data to cache.
            ttl: Time to live. Defaults to 24 hours.
        """
        client = get_redis_client()
        if not client:
            return

        try:
            client.setex(
                cls._key(session_id),
                ttl or cls.DEFAULT_TTL,
                json.dumps(data, default=str),
            )
        except Exception:
            pass

    @classmethod
    def invalidate(cls, session_id: str) -> None:
        """Remove cached session."""
        client = get_redis_client()
        if not client:
            return

        try:
            client.delete(cls._key(session_id))
        except Exception:
            pass


def flush_all_caches() -> None:
    """Flush all Asqav caches (use with caution)."""
    client = get_redis_client()
    if not client:
        return

    try:
        # Delete all keys with asqav: prefix
        cursor = 0
        while True:
            cursor, keys = client.scan(cursor, match="asqav:*", count=1000)
            if keys:
                client.delete(*keys)
            if cursor == 0:
                break
    except Exception:
        pass
