"""Health check endpoints."""

from __future__ import annotations

from fastapi import APIRouter

router = APIRouter(prefix="/health", tags=["health"])


@router.get("/")
async def health_check() -> dict[str, str]:
    """Basic health check."""
    return {"status": "healthy", "version": "0.1.0"}


@router.get("/ready")
async def readiness_check() -> dict[str, str]:
    """Readiness check."""
    return {"status": "ready"}
