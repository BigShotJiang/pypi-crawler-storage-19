"""Session and action logging endpoints."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from ..rate_limit import READ_RATE, WRITE_RATE, limiter

router = APIRouter(prefix="/sessions", tags=["sessions"])


# In-memory storage for now (will be replaced with database)
_sessions: dict[str, dict[str, Any]] = {}
_actions: dict[str, dict[str, Any]] = {}


class SessionCreate(BaseModel):
    """Request schema for creating a session."""

    session_id: str | None = Field(default=None, pattern=r"^ses_[A-Za-z0-9_-]+$")
    agent_id: str = Field(..., pattern=r"^agt_[A-Za-z0-9_-]+$")
    metadata: dict[str, Any] | None = None


class SessionResponse(BaseModel):
    """Response schema for session."""

    session_id: str
    agent_id: str
    status: str
    started_at: datetime
    ended_at: datetime | None = None
    metadata: dict[str, Any] | None = None


class SessionUpdate(BaseModel):
    """Request schema for updating session status."""

    status: str = Field(..., pattern=r"^(completed|error|timeout)$")


class ActionCreate(BaseModel):
    """Request schema for logging an action."""

    action_id: str | None = Field(default=None, pattern=r"^act_[A-Za-z0-9_-]+$")
    action_type: str = Field(default="custom")
    action_name: str = Field(..., min_length=1, max_length=255)
    timestamp: datetime | None = None
    metadata: dict[str, Any] | None = None
    status: str = Field(default="completed")


class ActionResponse(BaseModel):
    """Response schema for action."""

    action_id: str
    session_id: str
    agent_id: str
    action_type: str
    action_name: str
    timestamp: datetime
    metadata: dict[str, Any] | None = None
    status: str


class ActionBatch(BaseModel):
    """Request schema for batch action logging."""

    actions: list[ActionCreate]


@router.post("/", response_model=SessionResponse, status_code=201)
@limiter.limit(WRITE_RATE)
async def create_session(request: Request, session: SessionCreate) -> SessionResponse:
    """Create a new session."""
    session_id = session.session_id or f"ses_{uuid.uuid4().hex[:16]}"

    if session_id in _sessions:
        raise HTTPException(status_code=409, detail="Session already exists")

    started_at = datetime.now()
    session_data: dict[str, Any] = {
        "session_id": session_id,
        "agent_id": session.agent_id,
        "status": "active",
        "started_at": started_at,
        "ended_at": None,
        "metadata": session.metadata,
    }
    _sessions[session_id] = session_data

    return SessionResponse(
        session_id=session_id,
        agent_id=session.agent_id,
        status="active",
        started_at=started_at,
        ended_at=None,
        metadata=session.metadata,
    )


@router.get("/{session_id}", response_model=SessionResponse)
@limiter.limit(READ_RATE)
async def get_session(request: Request, session_id: str) -> SessionResponse:
    """Get session by ID."""
    if session_id not in _sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    s = _sessions[session_id]
    return SessionResponse(
        session_id=str(s["session_id"]),
        agent_id=str(s["agent_id"]),
        status=str(s["status"]),
        started_at=s["started_at"],
        ended_at=s.get("ended_at"),
        metadata=s.get("metadata"),
    )


@router.patch("/{session_id}", response_model=SessionResponse)
@limiter.limit(WRITE_RATE)
async def update_session(request: Request, session_id: str, update: SessionUpdate) -> SessionResponse:
    """Update session status (end it)."""
    if session_id not in _sessions:
        raise HTTPException(status_code=404, detail="Session not found")

    ended_at = datetime.now()
    _sessions[session_id]["status"] = update.status
    _sessions[session_id]["ended_at"] = ended_at
    s = _sessions[session_id]

    return SessionResponse(
        session_id=str(s["session_id"]),
        agent_id=str(s["agent_id"]),
        status=str(s["status"]),
        started_at=s["started_at"],
        ended_at=ended_at,
        metadata=s.get("metadata"),
    )


@router.get("/", response_model=list[SessionResponse])
@limiter.limit(READ_RATE)
async def list_sessions(
    request: Request,
    agent_id: str | None = None,
    status: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[SessionResponse]:
    """List sessions with filters."""
    sessions = list(_sessions.values())

    if agent_id:
        sessions = [s for s in sessions if s["agent_id"] == agent_id]
    if status:
        sessions = [s for s in sessions if s["status"] == status]

    return [
        SessionResponse(
            session_id=str(s["session_id"]),
            agent_id=str(s["agent_id"]),
            status=str(s["status"]),
            started_at=s["started_at"],
            ended_at=s.get("ended_at"),
            metadata=s.get("metadata"),
        )
        for s in sessions[offset : offset + limit]
    ]


@router.post("/{session_id}/actions", response_model=ActionResponse, status_code=201)
@limiter.limit(WRITE_RATE)
async def log_action(request: Request, session_id: str, action: ActionCreate) -> ActionResponse:
    """Log an action to a session."""
    if session_id not in _sessions:
        raise HTTPException(status_code=404, detail="Session not found")

    action_id = action.action_id or f"act_{uuid.uuid4().hex[:16]}"

    action_data = {
        "action_id": action_id,
        "session_id": session_id,
        "agent_id": _sessions[session_id]["agent_id"],
        "action_type": action.action_type,
        "action_name": action.action_name,
        "timestamp": action.timestamp or datetime.now(),
        "metadata": action.metadata,
        "status": action.status,
    }
    _actions[action_id] = action_data

    return ActionResponse(**action_data)


@router.post("/{session_id}/actions/batch", response_model=list[ActionResponse], status_code=201)
@limiter.limit(WRITE_RATE)
async def log_actions_batch(request: Request, session_id: str, batch: ActionBatch) -> list[ActionResponse]:
    """Log multiple actions at once."""
    if session_id not in _sessions:
        raise HTTPException(status_code=404, detail="Session not found")

    results = []
    for action in batch.actions:
        action_id = action.action_id or f"act_{uuid.uuid4().hex[:16]}"

        action_data = {
            "action_id": action_id,
            "session_id": session_id,
            "agent_id": _sessions[session_id]["agent_id"],
            "action_type": action.action_type,
            "action_name": action.action_name,
            "timestamp": action.timestamp or datetime.now(),
            "metadata": action.metadata,
            "status": action.status,
        }
        _actions[action_id] = action_data
        results.append(ActionResponse(**action_data))

    return results


@router.get("/{session_id}/actions", response_model=list[ActionResponse])
@limiter.limit(READ_RATE)
async def get_session_actions(
    request: Request,
    session_id: str,
    limit: int = 100,
    offset: int = 0,
) -> list[ActionResponse]:
    """Get all actions for a session."""
    if session_id not in _sessions:
        raise HTTPException(status_code=404, detail="Session not found")

    actions = [a for a in _actions.values() if a["session_id"] == session_id]
    actions.sort(key=lambda x: x["timestamp"], reverse=True)

    return [ActionResponse(**a) for a in actions[offset : offset + limit]]
