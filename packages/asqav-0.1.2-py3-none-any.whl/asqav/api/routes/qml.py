"""
QML Security Platform API routes.

Provides endpoints for:
- Full platform security scans
- Platform status monitoring
- Scan report retrieval
- Alert configuration and management
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

router = APIRouter(prefix="/qml", tags=["QML Security"])


# Request/Response models


class MeasurementInput(BaseModel):
    """Input format for measurement data."""

    counts: dict[str, int] = Field(..., description="Measurement counts by bitstring")
    n_qubits: int | None = Field(None, description="Number of qubits (inferred if not provided)")


class CircuitGate(BaseModel):
    """Quantum gate specification."""

    gate_type: str = Field(..., description="Gate type (H, X, Y, Z, RX, RY, RZ, CNOT, CZ)")
    target: int = Field(..., description="Target qubit index")
    control: int | None = Field(None, description="Control qubit for two-qubit gates")
    parameter: float | None = Field(None, description="Rotation angle for parametric gates")


class CircuitInput(BaseModel):
    """Input format for quantum circuit."""

    n_qubits: int = Field(..., description="Number of qubits")
    gates: list[CircuitGate] = Field(..., description="List of gates")


class NoiseProfileInput(BaseModel):
    """Input format for noise profile."""

    device_name: str = Field(..., description="Device identifier")
    n_qubits: int = Field(..., description="Number of qubits")
    t1_times: list[float] = Field(..., description="T1 times per qubit (microseconds)")
    t2_times: list[float] = Field(..., description="T2 times per qubit (microseconds)")
    readout_errors: list[float] = Field(..., description="Readout error rates per qubit")
    gate_errors: list[float] = Field(..., description="Single-qubit gate error rates")


class ScanRequest(BaseModel):
    """Request body for full platform scan."""

    model_path: str | None = Field(None, description="Path to model file for integrity check")
    registry_id: str | None = Field(None, description="Registry ID for model verification")
    measurements: list[MeasurementInput] | None = Field(
        None, description="Measurement data for backdoor detection"
    )
    circuit: CircuitInput | None = Field(
        None, description="Circuit for robustness verification"
    )
    noise_profile: NoiseProfileInput | None = Field(
        None, description="Noise profile for device verification"
    )
    reference_profile_id: str | None = Field(
        None, description="Reference profile ID for noise comparison"
    )


class ModuleResultResponse(BaseModel):
    """Response format for a single module scan result."""

    module_name: str
    scan_type: str
    status: str
    risk_level: str
    confidence: float
    details: dict[str, Any] = {}
    error: str | None = None
    duration_ms: float


class ScanResponse(BaseModel):
    """Response format for platform scan."""

    report_id: str
    timestamp: str
    overall_risk: str
    scan_types: list[str]
    module_results: list[ModuleResultResponse]
    summary: str
    recommendations: list[str]
    is_secure: bool
    failed_modules: list[str]


class PlatformStatusResponse(BaseModel):
    """Response format for platform status."""

    overall_risk: str
    modules_available: list[str]
    last_scan_time: str | None
    total_scans: int
    active_alerts: int
    models_registered: int
    noise_profiles_stored: int


class AlertRuleInput(BaseModel):
    """Input format for alert rule configuration."""

    name: str = Field(..., description="Unique rule name")
    severity: str = Field(..., description="Alert severity (info, warning, high, critical)")
    title_template: str = Field(
        "Security Alert: {module}", description="Title template"
    )
    message_template: str = Field(
        "Risk level {risk_level} detected in {module}", description="Message template"
    )
    risk_levels: list[str] | None = Field(None, description="Trigger on these risk levels")
    modules: list[str] | None = Field(None, description="Trigger only for these modules")
    scan_types: list[str] | None = Field(None, description="Trigger only for these scan types")
    enabled: bool = Field(True, description="Whether rule is enabled")


class AlertResponse(BaseModel):
    """Response format for an alert."""

    alert_id: str
    timestamp: str
    severity: str
    title: str
    message: str
    source_module: str
    rule_name: str
    status: str
    details: dict[str, Any] = {}
    report_id: str | None = None


class NotifierConfigInput(BaseModel):
    """Input format for notifier configuration."""

    notifier_type: str = Field(..., description="Type: webhook, slack, email, pagerduty")
    config: dict[str, Any] = Field(..., description="Notifier-specific configuration")


# Platform instance (lazy-loaded)
_platform = None
_alert_engine = None


def get_platform() -> Any:
    """Get or create platform instance."""
    global _platform
    if _platform is None:
        from asqav.qml.qml_platform import QMLPlatform

        _platform = QMLPlatform()
    return _platform


def get_alert_engine() -> Any:
    """Get or create alert engine instance."""
    global _alert_engine
    if _alert_engine is None:
        from asqav.platform.alerts import create_alert_engine

        _alert_engine = create_alert_engine(add_default_rules=True)
    return _alert_engine


# Endpoints


@router.post("/scan", response_model=ScanResponse)
async def run_scan(request: ScanRequest) -> ScanResponse:
    """Run a full platform security scan.

    Runs all applicable security checks based on provided inputs:
    - Backdoor detection (if measurements provided)
    - Robustness verification (if circuit provided)
    - Noise profile verification (if profile provided)
    - Model integrity check (if model_path provided)
    """
    platform = get_platform()

    # Convert inputs to internal formats
    measurements = None
    circuit = None
    noise_profile = None

    if request.measurements:
        from asqav.qml.qml_anomaly import MeasurementData

        measurements = []
        for m in request.measurements:
            n_qubits = m.n_qubits or len(next(iter(m.counts.keys())))
            measurements.append(MeasurementData.from_counts(m.counts, n_qubits=n_qubits))

    if request.circuit:
        from asqav.qml.vqc_verifier import GateType, QuantumCircuit, QuantumGate

        gates = []
        for g in request.circuit.gates:
            gate_type = GateType[g.gate_type.upper()]
            # Build qubits list from target and optional control
            qubits = [g.target] if g.control is None else [g.control, g.target]
            parameters = [g.parameter] if g.parameter is not None else []
            gates.append(
                QuantumGate(
                    gate_type=gate_type,
                    qubits=qubits,
                    parameters=parameters,
                )
            )
        circuit = QuantumCircuit(n_qubits=request.circuit.n_qubits, gates=gates)

    if request.noise_profile:
        import uuid
        from datetime import datetime

        from asqav.qml.noise_profiler import NoiseProfile, QubitNoiseParams

        qubit_params = []
        for i in range(request.noise_profile.n_qubits):
            # Use same error rate for both readout states and gate types
            readout_err = request.noise_profile.readout_errors[i]
            gate_err = request.noise_profile.gate_errors[i]
            qubit_params.append(
                QubitNoiseParams(
                    qubit_id=i,
                    t1=request.noise_profile.t1_times[i],
                    t2=request.noise_profile.t2_times[i],
                    readout_error_0=readout_err,
                    readout_error_1=readout_err,
                    gate_error_1q=gate_err,
                    gate_error_2q=gate_err * 10,  # 2Q gates typically have higher error
                )
            )
        # Generate linear connectivity for the device
        connectivity = [(i, i + 1) for i in range(request.noise_profile.n_qubits - 1)]
        noise_profile = NoiseProfile(
            profile_id=f"api_{uuid.uuid4().hex[:12]}",
            device_name=request.noise_profile.device_name,
            n_qubits=request.noise_profile.n_qubits,
            qubit_params=qubit_params,
            connectivity=connectivity,
            calibration_timestamp=datetime.now().isoformat(),
        )

    # Run scan
    model_path = Path(request.model_path) if request.model_path else None
    report = platform.full_scan(
        model_path=model_path,
        measurements=measurements,
        circuit=circuit,
        noise_profile=noise_profile,
        registry_id=request.registry_id,
        reference_profile_id=request.reference_profile_id,
    )

    # Check for alerts
    alert_engine = get_alert_engine()
    alert_engine.check_and_notify(report)

    # Convert to response
    return ScanResponse(
        report_id=report.report_id,
        timestamp=report.timestamp.isoformat(),
        overall_risk=report.overall_risk.value,
        scan_types=[st.value for st in report.scan_types],
        module_results=[
            ModuleResultResponse(
                module_name=r.module_name,
                scan_type=r.scan_type.value,
                status=r.status.value,
                risk_level=r.risk_level,
                confidence=r.confidence,
                details=r.details,
                error=r.error,
                duration_ms=r.duration_ms,
            )
            for r in report.module_results
        ],
        summary=report.summary,
        recommendations=report.recommendations,
        is_secure=report.is_secure,
        failed_modules=report.failed_modules,
    )


@router.get("/status", response_model=PlatformStatusResponse)
async def get_status() -> PlatformStatusResponse:
    """Get current platform status."""
    platform = get_platform()
    status = platform.get_status()

    return PlatformStatusResponse(
        overall_risk=status.overall_risk.value if hasattr(status.overall_risk, 'value') else status.overall_risk,
        modules_available=status.modules_available,
        last_scan_time=status.last_scan_time.isoformat() if status.last_scan_time else None,
        total_scans=status.total_scans,
        active_alerts=status.active_alerts,
        models_registered=status.models_registered,
        noise_profiles_stored=status.noise_profiles_stored,
    )


@router.get("/reports", response_model=list[ScanResponse])
async def list_reports(limit: int = 10) -> list[ScanResponse]:
    """List recent scan reports."""
    platform = get_platform()
    reports = platform.get_reports(limit=limit)

    return [
        ScanResponse(
            report_id=r.report_id,
            timestamp=r.timestamp.isoformat(),
            overall_risk=r.overall_risk.value,
            scan_types=[st.value for st in r.scan_types],
            module_results=[
                ModuleResultResponse(
                    module_name=m.module_name,
                    scan_type=m.scan_type.value,
                    status=m.status.value,
                    risk_level=m.risk_level,
                    confidence=m.confidence,
                    details=m.details,
                    error=m.error,
                    duration_ms=m.duration_ms,
                )
                for m in r.module_results
            ],
            summary=r.summary,
            recommendations=r.recommendations,
            is_secure=r.is_secure,
            failed_modules=r.failed_modules,
        )
        for r in reports
    ]


@router.get("/reports/{report_id}", response_model=ScanResponse)
async def get_report(report_id: str) -> ScanResponse:
    """Get a specific scan report by ID."""
    platform = get_platform()
    report = platform.get_report(report_id)

    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    return ScanResponse(
        report_id=report.report_id,
        timestamp=report.timestamp.isoformat(),
        overall_risk=report.overall_risk.value,
        scan_types=[st.value for st in report.scan_types],
        module_results=[
            ModuleResultResponse(
                module_name=m.module_name,
                scan_type=m.scan_type.value,
                status=m.status.value,
                risk_level=m.risk_level,
                confidence=m.confidence,
                details=m.details,
                error=m.error,
                duration_ms=m.duration_ms,
            )
            for m in report.module_results
        ],
        summary=report.summary,
        recommendations=report.recommendations,
        is_secure=report.is_secure,
        failed_modules=report.failed_modules,
    )


@router.get("/alerts", response_model=list[AlertResponse])
async def list_alerts(
    status: str | None = None,
    severity: str | None = None,
    limit: int = 100,
) -> list[AlertResponse]:
    """List alerts with optional filtering."""
    from asqav.platform.alerts import AlertSeverity, AlertStatus

    engine = get_alert_engine()

    status_filter = AlertStatus(status) if status else None
    severity_filter = AlertSeverity(severity) if severity else None

    alerts = engine.get_alerts(
        status=status_filter,
        severity=severity_filter,
        limit=limit,
    )

    return [
        AlertResponse(
            alert_id=a.alert_id,
            timestamp=a.timestamp.isoformat(),
            severity=a.severity.value,
            title=a.title,
            message=a.message,
            source_module=a.source_module,
            rule_name=a.rule_name,
            status=a.status.value,
            details=a.details,
            report_id=a.report_id,
        )
        for a in alerts
    ]


@router.post("/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: str) -> dict[str, Any]:
    """Acknowledge an alert."""
    engine = get_alert_engine()
    success = engine.acknowledge_alert(alert_id)

    if not success:
        raise HTTPException(status_code=404, detail="Alert not found")

    return {"status": "acknowledged", "alert_id": alert_id}


@router.post("/alerts/{alert_id}/resolve")
async def resolve_alert(alert_id: str) -> dict[str, Any]:
    """Mark an alert as resolved."""
    engine = get_alert_engine()
    success = engine.resolve_alert(alert_id)

    if not success:
        raise HTTPException(status_code=404, detail="Alert not found")

    return {"status": "resolved", "alert_id": alert_id}


@router.post("/alerts/rules")
async def add_alert_rule(rule: AlertRuleInput) -> dict[str, Any]:
    """Add a new alert rule."""
    from asqav.platform.alerts import AlertRule, AlertSeverity

    engine = get_alert_engine()

    alert_rule = AlertRule(
        name=rule.name,
        severity=AlertSeverity(rule.severity),
        title_template=rule.title_template,
        message_template=rule.message_template,
        risk_levels=rule.risk_levels,
        modules=rule.modules,
        scan_types=rule.scan_types,
        enabled=rule.enabled,
    )

    engine.add_rule(alert_rule)

    return {"status": "created", "rule_name": rule.name}


@router.delete("/alerts/rules/{rule_name}")
async def remove_alert_rule(rule_name: str) -> dict[str, Any]:
    """Remove an alert rule."""
    engine = get_alert_engine()
    success = engine.remove_rule(rule_name)

    if not success:
        raise HTTPException(status_code=404, detail="Rule not found")

    return {"status": "deleted", "rule_name": rule_name}


@router.post("/notifiers")
async def add_notifier(config: NotifierConfigInput) -> dict[str, Any]:
    """Add a notifier for alert delivery."""
    from asqav.platform.alerts import (
        AlertSeverity,
        EmailNotifier,
        Notifier,
        PagerDutyNotifier,
        SlackNotifier,
        WebhookNotifier,
    )

    engine = get_alert_engine()

    notifier_type = config.notifier_type.lower()
    cfg = config.config

    notifier: Notifier
    if notifier_type == "webhook":
        notifier = WebhookNotifier(
            webhook_url=cfg["webhook_url"],
            headers=cfg.get("headers"),
            method=cfg.get("method", "POST"),
            min_severity=AlertSeverity(cfg.get("min_severity", "info")),
        )
    elif notifier_type == "slack":
        notifier = SlackNotifier(
            webhook_url=cfg["webhook_url"],
            channel=cfg.get("channel"),
            username=cfg.get("username", "Asqav Security"),
            min_severity=AlertSeverity(cfg.get("min_severity", "warning")),
        )
    elif notifier_type == "email":
        notifier = EmailNotifier(
            smtp_host=cfg["smtp_host"],
            smtp_port=cfg["smtp_port"],
            from_addr=cfg["from_addr"],
            to_addrs=cfg["to_addrs"],
            username=cfg.get("username"),
            password=cfg.get("password"),
            use_tls=cfg.get("use_tls", True),
            min_severity=AlertSeverity(cfg.get("min_severity", "high")),
        )
    elif notifier_type == "pagerduty":
        notifier = PagerDutyNotifier(
            routing_key=cfg["routing_key"],
            min_severity=AlertSeverity(cfg.get("min_severity", "high")),
        )
    else:
        raise HTTPException(status_code=400, detail=f"Unknown notifier type: {notifier_type}")

    engine.add_notifier(notifier)

    return {"status": "created", "notifier_type": notifier_type}


@router.delete("/notifiers/{notifier_name}")
async def remove_notifier(notifier_name: str) -> dict[str, Any]:
    """Remove a notifier."""
    engine = get_alert_engine()
    success = engine.remove_notifier(notifier_name)

    if not success:
        raise HTTPException(status_code=404, detail="Notifier not found")

    return {"status": "deleted", "notifier_name": notifier_name}
