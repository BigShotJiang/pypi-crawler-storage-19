"""API configuration settings."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class Settings:
    """API configuration."""

    # Database
    database_url: str = field(
        default_factory=lambda: os.getenv(
            "ASQAV_DATABASE_URL",
            "sqlite+aiosqlite:///asqav.db"
        )
    )

    # Redis (for rate limiting storage)
    redis_url: str = field(
        default_factory=lambda: os.getenv("ASQAV_REDIS_URL", "")
    )

    # API
    api_prefix: str = "/api/v1"
    debug: bool = field(
        default_factory=lambda: os.getenv("ASQAV_DEBUG", "false").lower() == "true"
    )
    cors_origins: list[str] = field(default_factory=lambda: ["*"])

    # Server
    host: str = field(default_factory=lambda: os.getenv("ASQAV_HOST", "0.0.0.0"))
    port: int = field(
        default_factory=lambda: int(os.getenv("ASQAV_PORT", "8000"))
    )

    # Rate Limiting
    rate_limit_enabled: bool = field(
        default_factory=lambda: os.getenv("ASQAV_RATE_LIMIT_ENABLED", "true").lower() == "true"
    )
    rate_limit_default: str = field(
        default_factory=lambda: os.getenv("ASQAV_RATE_LIMIT_DEFAULT", "100/minute")
    )
    rate_limit_read: str = field(
        default_factory=lambda: os.getenv("ASQAV_RATE_LIMIT_READ", "200/minute")
    )
    rate_limit_write: str = field(
        default_factory=lambda: os.getenv("ASQAV_RATE_LIMIT_WRITE", "50/minute")
    )
    rate_limit_expensive: str = field(
        default_factory=lambda: os.getenv("ASQAV_RATE_LIMIT_EXPENSIVE", "10/minute")
    )


settings = Settings()
