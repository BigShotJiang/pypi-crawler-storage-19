"""PostgreSQL database models and session management for Asqav Cloud.

Uses SQLAlchemy 2.0 with async support for production deployments.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import uuid4

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    LargeBinary,
    String,
    Text,
    create_engine,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from .config import settings


class Base(DeclarativeBase):
    """Base class for all database models."""

    pass


def generate_uuid() -> str:
    """Generate a UUID string."""
    return str(uuid4())


# ============================================================================
# Agent Models
# ============================================================================


class Agent(Base):
    """Agent identity stored in the cloud."""

    __tablename__ = "agents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    agent_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    algorithm: Mapped[str] = mapped_column(String(32), nullable=False)
    public_key: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)
    key_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    capabilities: Mapped[dict[str, Any]] = mapped_column(JSONB, default=list)
    issuer: Mapped[str] = mapped_column(String(255), default="asqav")
    metadata: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)

    # Status
    is_revoked: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    revocation_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    # Relationships
    sessions: Mapped[list["Session"]] = relationship("Session", back_populates="agent")
    delegations_given: Mapped[list["Delegation"]] = relationship(
        "Delegation", foreign_keys="Delegation.parent_agent_id", back_populates="parent_agent"
    )
    delegations_received: Mapped[list["Delegation"]] = relationship(
        "Delegation", foreign_keys="Delegation.child_agent_id", back_populates="child_agent"
    )
    key_rotations: Mapped[list["KeyRotation"]] = relationship(
        "KeyRotation", back_populates="agent"
    )

    __table_args__ = (
        Index("ix_agents_created", "created_at"),
        Index("ix_agents_algorithm", "algorithm"),
    )


# ============================================================================
# Session Models
# ============================================================================


class Session(Base):
    """Runtime monitoring session."""

    __tablename__ = "sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    agent_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("agents.agent_id"), nullable=False, index=True
    )
    status: Mapped[str] = mapped_column(String(32), default="active", index=True)
    metadata: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)

    # Timestamps
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # Relationships
    agent: Mapped["Agent"] = relationship("Agent", back_populates="sessions")
    actions: Mapped[list["Action"]] = relationship("Action", back_populates="session")

    __table_args__ = (Index("ix_sessions_started", "started_at"),)


class Action(Base):
    """Action logged during a session."""

    __tablename__ = "actions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    action_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    session_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("sessions.session_id"), nullable=False, index=True
    )
    agent_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    action_type: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    action_name: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="completed")
    metadata: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)

    # Timestamps
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    # Relationships
    session: Mapped["Session"] = relationship("Session", back_populates="actions")

    __table_args__ = (Index("ix_actions_timestamp", "timestamp"),)


# ============================================================================
# Delegation Models
# ============================================================================


class Delegation(Base):
    """Delegation chain record."""

    __tablename__ = "delegations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    delegation_id: Mapped[str] = mapped_column(
        String(64), unique=True, nullable=False, index=True
    )
    parent_agent_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("agents.agent_id"), nullable=False, index=True
    )
    child_agent_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("agents.agent_id"), nullable=False, index=True
    )
    scope: Mapped[dict[str, Any]] = mapped_column(JSONB, default=list)
    chain_depth: Mapped[int] = mapped_column(Integer, default=1)
    metadata: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)

    # Status
    is_revoked: Mapped[bool] = mapped_column(Boolean, default=False)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # Relationships
    parent_agent: Mapped["Agent"] = relationship(
        "Agent", foreign_keys=[parent_agent_id], back_populates="delegations_given"
    )
    child_agent: Mapped["Agent"] = relationship(
        "Agent", foreign_keys=[child_agent_id], back_populates="delegations_received"
    )

    __table_args__ = (
        Index("ix_delegations_parent_child", "parent_agent_id", "child_agent_id"),
    )


# ============================================================================
# Key Rotation Models
# ============================================================================


class KeyRotation(Base):
    """Key rotation history."""

    __tablename__ = "key_rotations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    rotation_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    agent_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("agents.agent_id"), nullable=False, index=True
    )
    old_key_id: Mapped[str] = mapped_column(String(64), nullable=False)
    new_key_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    old_public_key: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)
    new_public_key: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)
    reason: Mapped[str] = mapped_column(String(64), nullable=False)
    metadata: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)

    # Timestamps
    rotated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    grace_period_ends: Mapped[datetime] = mapped_column(DateTime, nullable=False)

    # Relationships
    agent: Mapped["Agent"] = relationship("Agent", back_populates="key_rotations")

    __table_args__ = (
        Index("ix_key_rotations_grace", "grace_period_ends"),
    )


# ============================================================================
# Alert Models
# ============================================================================


class Alert(Base):
    """Security alert record."""

    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    alert_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    agent_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    session_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    severity: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    alert_type: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=True)
    metadata: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)

    # Status
    status: Mapped[str] = mapped_column(String(32), default="open", index=True)
    acknowledged_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index("ix_alerts_created", "created_at"),
    )


# ============================================================================
# Model Registry Models
# ============================================================================


class RegisteredModel(Base):
    """ML model registered in the integrity registry."""

    __tablename__ = "registered_models"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    registry_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    model_name: Mapped[str] = mapped_column(String(255), nullable=False)
    model_hash: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    signer_agent_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    signer_key_id: Mapped[str] = mapped_column(String(64), nullable=False)
    signature: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)
    algorithm: Mapped[str] = mapped_column(String(32), nullable=False)
    metadata: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)

    # Status
    is_revoked: Mapped[bool] = mapped_column(Boolean, default=False)

    # Timestamps
    registered_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )

    __table_args__ = (Index("ix_models_registered", "registered_at"),)


# ============================================================================
# Database Session Management
# ============================================================================


def get_sync_engine():
    """Create synchronous database engine."""
    return create_engine(
        settings.database_url.replace("postgresql://", "postgresql+psycopg2://"),
        echo=settings.debug,
        pool_pre_ping=True,
    )


def get_async_engine():
    """Create asynchronous database engine."""
    return create_async_engine(
        settings.database_url.replace("postgresql://", "postgresql+asyncpg://"),
        echo=settings.debug,
        pool_pre_ping=True,
    )


def get_async_session_maker():
    """Create async session factory."""
    engine = get_async_engine()
    return async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def get_db() -> AsyncSession:
    """Dependency for getting database session."""
    async_session = get_async_session_maker()
    async with async_session() as session:
        yield session


def create_tables():
    """Create all tables (for development/testing)."""
    engine = get_sync_engine()
    Base.metadata.create_all(engine)


def drop_tables():
    """Drop all tables (for development/testing)."""
    engine = get_sync_engine()
    Base.metadata.drop_all(engine)
