"""Rate limiting for Asqav API."""

from __future__ import annotations

from typing import TYPE_CHECKING

from slowapi import Limiter
from slowapi.util import get_remote_address

if TYPE_CHECKING:
    from fastapi import Request


def get_identifier(request: Request) -> str:
    """Get rate limit identifier from request.

    Uses API key if provided in header, otherwise falls back to IP address.
    """
    api_key = request.headers.get("X-API-Key")
    if api_key:
        return f"api_key:{api_key}"
    return get_remote_address(request)


# Create limiter instance with default rate limits
limiter = Limiter(key_func=get_identifier)

# Rate limit decorators for different tiers
# Default: 100 requests per minute
DEFAULT_RATE = "100/minute"

# Higher limit for read operations
READ_RATE = "200/minute"

# Lower limit for write operations
WRITE_RATE = "50/minute"

# Very low limit for expensive operations (scanning, verification)
EXPENSIVE_RATE = "10/minute"
