"""
Model Integrity Registry: ML-DSA signed hashes for AI/QML model verification.

This module provides quantum-safe model integrity verification using ML-DSA
signatures. It can register and verify any AI model file (classical or quantum).
"""

from __future__ import annotations

import hashlib
import json
import secrets
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..core.identity import IdentityProvider, KeyPair, Signature, parse_algorithm


@dataclass
class ModelMetadata:
    """Metadata for a registered model."""

    name: str
    version: str = "1.0.0"
    model_type: str = "unknown"  # classical, qnn, vqc, hybrid
    framework: str = "unknown"  # pytorch, tensorflow, qiskit, pennylane
    description: str = ""
    author: str = ""
    tags: list[str] = field(default_factory=list)
    custom: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "version": self.version,
            "model_type": self.model_type,
            "framework": self.framework,
            "description": self.description,
            "author": self.author,
            "tags": self.tags,
            "custom": self.custom,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ModelMetadata:
        """Create from dictionary."""
        return cls(
            name=data.get("name", "unknown"),
            version=data.get("version", "1.0.0"),
            model_type=data.get("model_type", "unknown"),
            framework=data.get("framework", "unknown"),
            description=data.get("description", ""),
            author=data.get("author", ""),
            tags=data.get("tags", []),
            custom=data.get("custom", {}),
        )


@dataclass
class RegistryEntry:
    """A registered model entry with signature."""

    registry_id: str
    file_hash: str  # SHA3-256 hash of model file
    file_size: int
    signature: str  # Base64 encoded ML-DSA signature
    algorithm: str  # ML-DSA algorithm used
    key_id: str  # Key ID of signer
    metadata: ModelMetadata
    registered_at: float
    registered_by: str  # Agent ID or user ID

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "registry_id": self.registry_id,
            "file_hash": self.file_hash,
            "file_size": self.file_size,
            "signature": self.signature,
            "algorithm": self.algorithm,
            "key_id": self.key_id,
            "metadata": self.metadata.to_dict(),
            "registered_at": self.registered_at,
            "registered_by": self.registered_by,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RegistryEntry:
        """Create from dictionary."""
        return cls(
            registry_id=data["registry_id"],
            file_hash=data["file_hash"],
            file_size=data["file_size"],
            signature=data["signature"],
            algorithm=data["algorithm"],
            key_id=data["key_id"],
            metadata=ModelMetadata.from_dict(data.get("metadata", {})),
            registered_at=data["registered_at"],
            registered_by=data["registered_by"],
        )


@dataclass
class VerificationResult:
    """Result of model verification."""

    is_valid: bool
    registry_id: str | None = None
    file_hash: str | None = None
    expected_hash: str | None = None
    error: str | None = None
    metadata: ModelMetadata | None = None

    @property
    def hash_match(self) -> bool:
        """Check if file hash matches expected."""
        return self.file_hash == self.expected_hash


def generate_registry_id() -> str:
    """Generate a unique registry ID."""
    return f"reg_{secrets.token_urlsafe(16)}"


def compute_file_hash(file_path: str | Path) -> str:
    """Compute SHA3-256 hash of a file.

    Args:
        file_path: Path to the file.

    Returns:
        Hex-encoded SHA3-256 hash.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    hasher = hashlib.sha3_256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)

    return hasher.hexdigest()


def compute_bytes_hash(data: bytes) -> str:
    """Compute SHA3-256 hash of bytes.

    Args:
        data: Bytes to hash.

    Returns:
        Hex-encoded SHA3-256 hash.
    """
    return hashlib.sha3_256(data).hexdigest()


class ModelRegistry:
    """Registry for ML-DSA signed AI/QML model hashes.

    This class provides model registration and verification using
    quantum-safe ML-DSA signatures.

    Example:
        registry = ModelRegistry(keypair)
        entry = registry.register("model.pt", ModelMetadata(name="my-model"))
        result = registry.verify("model.pt", entry.registry_id)
    """

    def __init__(
        self,
        keypair: KeyPair,
        storage_path: str | Path | None = None,
        signer_id: str = "unknown",
    ) -> None:
        """Initialize the model registry.

        Args:
            keypair: ML-DSA key pair for signing.
            storage_path: Path to SQLite database. Defaults to ~/.asqav/model_registry.db
            signer_id: ID of the signer (agent_id or user_id).
        """
        self.keypair = keypair
        self.signer_id = signer_id
        self._identity = IdentityProvider(keypair.algorithm)

        if storage_path is None:
            storage_dir = Path.home() / ".asqav"
            storage_dir.mkdir(parents=True, exist_ok=True)
            storage_path = storage_dir / "model_registry.db"

        self._storage_path = Path(storage_path)
        self._local = threading.local()
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Get thread-local database connection."""
        if not hasattr(self._local, "connection"):
            self._local.connection = sqlite3.connect(
                str(self._storage_path),
                check_same_thread=False,
            )
            self._local.connection.row_factory = sqlite3.Row
        conn: sqlite3.Connection = self._local.connection
        return conn

    def _init_db(self) -> None:
        """Initialize database schema."""
        conn = self._get_connection()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS registry (
                registry_id TEXT PRIMARY KEY,
                file_hash TEXT NOT NULL,
                file_size INTEGER NOT NULL,
                signature TEXT NOT NULL,
                algorithm TEXT NOT NULL,
                key_id TEXT NOT NULL,
                metadata TEXT NOT NULL,
                registered_at REAL NOT NULL,
                registered_by TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_file_hash ON registry(file_hash)
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_key_id ON registry(key_id)
        """)
        conn.commit()

    def register(
        self,
        file_path: str | Path,
        metadata: ModelMetadata | None = None,
    ) -> RegistryEntry:
        """Register a model file with ML-DSA signature.

        Args:
            file_path: Path to the model file.
            metadata: Optional metadata about the model.

        Returns:
            The registry entry.
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Model file not found: {file_path}")

        file_hash = compute_file_hash(path)
        file_size = path.stat().st_size

        if metadata is None:
            metadata = ModelMetadata(name=path.stem)

        registry_id = generate_registry_id()
        registered_at = time.time()

        # Create message to sign: hash + metadata + timestamp
        sign_data = self._create_sign_data(
            registry_id, file_hash, file_size, metadata, registered_at
        )
        signature = self._identity.sign(sign_data, self.keypair)

        entry = RegistryEntry(
            registry_id=registry_id,
            file_hash=file_hash,
            file_size=file_size,
            signature=signature.value_b64,
            algorithm=self.keypair.algorithm.value,
            key_id=self.keypair.key_id,
            metadata=metadata,
            registered_at=registered_at,
            registered_by=self.signer_id,
        )

        self._store_entry(entry)
        return entry

    def register_bytes(
        self,
        data: bytes,
        metadata: ModelMetadata,
    ) -> RegistryEntry:
        """Register model bytes with ML-DSA signature.

        Args:
            data: Model bytes.
            metadata: Metadata about the model.

        Returns:
            The registry entry.
        """
        file_hash = compute_bytes_hash(data)
        file_size = len(data)

        registry_id = generate_registry_id()
        registered_at = time.time()

        sign_data = self._create_sign_data(
            registry_id, file_hash, file_size, metadata, registered_at
        )
        signature = self._identity.sign(sign_data, self.keypair)

        entry = RegistryEntry(
            registry_id=registry_id,
            file_hash=file_hash,
            file_size=file_size,
            signature=signature.value_b64,
            algorithm=self.keypair.algorithm.value,
            key_id=self.keypair.key_id,
            metadata=metadata,
            registered_at=registered_at,
            registered_by=self.signer_id,
        )

        self._store_entry(entry)
        return entry

    def _create_sign_data(
        self,
        registry_id: str,
        file_hash: str,
        file_size: int,
        metadata: ModelMetadata,
        timestamp: float,
    ) -> bytes:
        """Create canonical data to sign."""
        data = {
            "registry_id": registry_id,
            "file_hash": file_hash,
            "file_size": file_size,
            "metadata": metadata.to_dict(),
            "registered_at": timestamp,
        }
        return json.dumps(data, sort_keys=True, separators=(",", ":")).encode()

    def _store_entry(self, entry: RegistryEntry) -> None:
        """Store entry in database."""
        conn = self._get_connection()
        conn.execute(
            """
            INSERT INTO registry
            (registry_id, file_hash, file_size, signature, algorithm, key_id,
             metadata, registered_at, registered_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                entry.registry_id,
                entry.file_hash,
                entry.file_size,
                entry.signature,
                entry.algorithm,
                entry.key_id,
                json.dumps(entry.metadata.to_dict()),
                entry.registered_at,
                entry.registered_by,
            ),
        )
        conn.commit()

    def verify(
        self,
        file_path: str | Path,
        registry_id: str,
        public_key: bytes | None = None,
    ) -> VerificationResult:
        """Verify a model file against registry.

        Args:
            file_path: Path to the model file to verify.
            registry_id: Registry ID to verify against.
            public_key: Public key for signature verification. Defaults to own key.

        Returns:
            Verification result.
        """
        entry = self.get_entry(registry_id)
        if entry is None:
            return VerificationResult(
                is_valid=False,
                registry_id=registry_id,
                error=f"Registry entry not found: {registry_id}",
            )

        path = Path(file_path)
        if not path.exists():
            return VerificationResult(
                is_valid=False,
                registry_id=registry_id,
                error=f"File not found: {file_path}",
            )

        file_hash = compute_file_hash(path)

        if file_hash != entry.file_hash:
            return VerificationResult(
                is_valid=False,
                registry_id=registry_id,
                file_hash=file_hash,
                expected_hash=entry.file_hash,
                error="File hash mismatch - model has been modified",
                metadata=entry.metadata,
            )

        # Verify signature
        if public_key is None:
            public_key = self.keypair.public_key

        sign_data = self._create_sign_data(
            entry.registry_id,
            entry.file_hash,
            entry.file_size,
            entry.metadata,
            entry.registered_at,
        )

        algorithm = parse_algorithm(entry.algorithm)
        signature = Signature.from_b64(entry.signature, algorithm, entry.key_id)

        try:
            is_valid = self._identity.verify(sign_data, signature, public_key)
        except Exception as e:
            return VerificationResult(
                is_valid=False,
                registry_id=registry_id,
                file_hash=file_hash,
                expected_hash=entry.file_hash,
                error=f"Signature verification failed: {e}",
                metadata=entry.metadata,
            )

        if not is_valid:
            return VerificationResult(
                is_valid=False,
                registry_id=registry_id,
                file_hash=file_hash,
                expected_hash=entry.file_hash,
                error="Invalid signature",
                metadata=entry.metadata,
            )

        return VerificationResult(
            is_valid=True,
            registry_id=registry_id,
            file_hash=file_hash,
            expected_hash=entry.file_hash,
            metadata=entry.metadata,
        )

    def verify_bytes(
        self,
        data: bytes,
        registry_id: str,
        public_key: bytes | None = None,
    ) -> VerificationResult:
        """Verify model bytes against registry.

        Args:
            data: Model bytes to verify.
            registry_id: Registry ID to verify against.
            public_key: Public key for signature verification.

        Returns:
            Verification result.
        """
        entry = self.get_entry(registry_id)
        if entry is None:
            return VerificationResult(
                is_valid=False,
                registry_id=registry_id,
                error=f"Registry entry not found: {registry_id}",
            )

        file_hash = compute_bytes_hash(data)

        if file_hash != entry.file_hash:
            return VerificationResult(
                is_valid=False,
                registry_id=registry_id,
                file_hash=file_hash,
                expected_hash=entry.file_hash,
                error="Hash mismatch - model has been modified",
                metadata=entry.metadata,
            )

        if public_key is None:
            public_key = self.keypair.public_key

        sign_data = self._create_sign_data(
            entry.registry_id,
            entry.file_hash,
            entry.file_size,
            entry.metadata,
            entry.registered_at,
        )

        algorithm = parse_algorithm(entry.algorithm)
        signature = Signature.from_b64(entry.signature, algorithm, entry.key_id)

        try:
            is_valid = self._identity.verify(sign_data, signature, public_key)
        except Exception as e:
            return VerificationResult(
                is_valid=False,
                registry_id=registry_id,
                file_hash=file_hash,
                expected_hash=entry.file_hash,
                error=f"Signature verification failed: {e}",
                metadata=entry.metadata,
            )

        return VerificationResult(
            is_valid=is_valid,
            registry_id=registry_id,
            file_hash=file_hash,
            expected_hash=entry.file_hash,
            metadata=entry.metadata,
            error=None if is_valid else "Invalid signature",
        )

    def get_entry(self, registry_id: str) -> RegistryEntry | None:
        """Get a registry entry by ID."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM registry WHERE registry_id = ?",
            (registry_id,),
        )
        row = cursor.fetchone()
        if row is None:
            return None

        return RegistryEntry(
            registry_id=row["registry_id"],
            file_hash=row["file_hash"],
            file_size=row["file_size"],
            signature=row["signature"],
            algorithm=row["algorithm"],
            key_id=row["key_id"],
            metadata=ModelMetadata.from_dict(json.loads(row["metadata"])),
            registered_at=row["registered_at"],
            registered_by=row["registered_by"],
        )

    def find_by_hash(self, file_hash: str) -> list[RegistryEntry]:
        """Find registry entries by file hash."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM registry WHERE file_hash = ?",
            (file_hash,),
        )
        return [
            RegistryEntry(
                registry_id=row["registry_id"],
                file_hash=row["file_hash"],
                file_size=row["file_size"],
                signature=row["signature"],
                algorithm=row["algorithm"],
                key_id=row["key_id"],
                metadata=ModelMetadata.from_dict(json.loads(row["metadata"])),
                registered_at=row["registered_at"],
                registered_by=row["registered_by"],
            )
            for row in cursor.fetchall()
        ]

    def list_entries(self, limit: int = 100) -> list[RegistryEntry]:
        """List all registry entries."""
        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM registry ORDER BY registered_at DESC LIMIT ?",
            (limit,),
        )
        return [
            RegistryEntry(
                registry_id=row["registry_id"],
                file_hash=row["file_hash"],
                file_size=row["file_size"],
                signature=row["signature"],
                algorithm=row["algorithm"],
                key_id=row["key_id"],
                metadata=ModelMetadata.from_dict(json.loads(row["metadata"])),
                registered_at=row["registered_at"],
                registered_by=row["registered_by"],
            )
            for row in cursor.fetchall()
        ]

    def delete_entry(self, registry_id: str) -> bool:
        """Delete a registry entry."""
        conn = self._get_connection()
        cursor = conn.execute(
            "DELETE FROM registry WHERE registry_id = ?",
            (registry_id,),
        )
        conn.commit()
        return cursor.rowcount > 0

    def get_provenance(self, registry_id: str) -> dict[str, Any] | None:
        """Get full provenance information for a model.

        Args:
            registry_id: The registry ID.

        Returns:
            Provenance information including signer, timestamp, and chain.
        """
        entry = self.get_entry(registry_id)
        if entry is None:
            return None

        return {
            "registry_id": entry.registry_id,
            "file_hash": entry.file_hash,
            "file_size": entry.file_size,
            "algorithm": entry.algorithm,
            "key_id": entry.key_id,
            "signed_by": entry.registered_by,
            "signed_at": entry.registered_at,
            "metadata": entry.metadata.to_dict(),
            "signature_valid": True,  # Entry exists, signature was valid at registration
        }
