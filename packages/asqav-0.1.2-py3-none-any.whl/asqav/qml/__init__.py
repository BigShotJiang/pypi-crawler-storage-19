"""QML (Quantum Machine Learning) Security modules.

This module provides security tools for quantum machine learning systems:
- Anomaly detection for quantum measurements
- Model registry with ML-DSA signing
- QSentry backdoor detection
- VQC robustness verification
- Noise profiling and device fingerprinting
- Unified QML security platform
"""

from .model_registry import (
    ModelMetadata,
    ModelRegistry,
    RegistryEntry,
    VerificationResult,
    compute_file_hash,
)
from .noise_profiler import (
    MatchResult,
    MatchStatus,
    NoiseProfile,
    NoiseProfiler,
    NoiseProfileStorage,
    NoiseType,
    QubitNoiseParams,
    create_synthetic_profile,
)
from .qml_anomaly import (
    MeasurementData,
    MeasurementDistributionRule,
    QMLAnomalyDetector,
    create_qml_detector,
)
from .qml_platform import (
    ModuleScanResult,
    OverallRisk,
    PlatformConfig,
    PlatformReport,
    PlatformStatus,
    QMLPlatform,
    ScanStatus,
    ScanType,
    create_platform,
)
from .qsentry import (
    BackdoorReport,
    BackdoorRisk,
    QSentry,
    analyze_measurements,
)
from .vqc_verifier import (
    GateType,
    QuantumCircuit,
    QuantumGate,
    QuantumInterval,
    RobustnessCertificate,
    RobustnessStatus,
    VerificationReport,
    VQCVerifier,
    create_simple_vqc,
    verify_vqc_robustness,
)

__all__ = [
    # Model Registry
    "ModelRegistry",
    "ModelMetadata",
    "RegistryEntry",
    "VerificationResult",
    "compute_file_hash",
    # QML Anomaly Detection
    "QMLAnomalyDetector",
    "MeasurementData",
    "MeasurementDistributionRule",
    "create_qml_detector",
    # QSentry Backdoor Detection
    "QSentry",
    "BackdoorReport",
    "BackdoorRisk",
    "analyze_measurements",
    # VQC Verifier
    "VQCVerifier",
    "QuantumCircuit",
    "QuantumGate",
    "QuantumInterval",
    "GateType",
    "RobustnessStatus",
    "RobustnessCertificate",
    "VerificationReport",
    "create_simple_vqc",
    "verify_vqc_robustness",
    # Noise Profiler
    "NoiseProfiler",
    "NoiseProfile",
    "QubitNoiseParams",
    "NoiseType",
    "MatchStatus",
    "MatchResult",
    "NoiseProfileStorage",
    "create_synthetic_profile",
    # QML Platform
    "QMLPlatform",
    "PlatformConfig",
    "PlatformReport",
    "PlatformStatus",
    "ModuleScanResult",
    "OverallRisk",
    "ScanType",
    "ScanStatus",
    "create_platform",
]
