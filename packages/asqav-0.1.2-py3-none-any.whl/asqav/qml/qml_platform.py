"""
Unified QML Security Platform for Asqav.

Integrates all QML security modules into a single orchestration layer:
- QSentry: Backdoor detection via measurement clustering
- VQC Verifier: Variational circuit robustness verification
- Noise Profiler: Device fingerprinting and watermark extraction
- Model Registry: ML-DSA signed model integrity

Example:
    from asqav import QMLPlatform

    platform = QMLPlatform()

    # Run full security scan
    report = platform.full_scan(
        model_path="model.pt",
        measurements=measurement_data,
        circuit=vqc_circuit,
        noise_profile=device_profile,
    )

    # Check overall status
    status = platform.get_status()
    print(f"Security Level: {status.overall_risk}")
"""

from __future__ import annotations

import contextlib
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel


class OverallRisk(str, Enum):
    """Overall security risk level for the platform."""

    SECURE = "secure"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ScanType(str, Enum):
    """Types of security scans available."""

    BACKDOOR = "backdoor"
    ROBUSTNESS = "robustness"
    NOISE = "noise"
    INTEGRITY = "integrity"
    FULL = "full"


class ScanStatus(str, Enum):
    """Status of a scan operation."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class ModuleScanResult:
    """Result from a single module scan."""

    module_name: str
    scan_type: ScanType
    status: ScanStatus
    risk_level: str
    confidence: float
    details: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    duration_ms: float = 0.0


@dataclass
class PlatformReport:
    """Comprehensive report from a full platform scan."""

    report_id: str
    timestamp: datetime
    overall_risk: OverallRisk
    scan_types: list[ScanType]
    module_results: list[ModuleScanResult]
    summary: str
    recommendations: list[str]
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_secure(self) -> bool:
        """Check if all scans passed with low/no risk."""
        return self.overall_risk in (OverallRisk.SECURE, OverallRisk.LOW)

    @property
    def failed_modules(self) -> list[str]:
        """Get list of modules that failed or have high risk."""
        return [
            r.module_name
            for r in self.module_results
            if r.status == ScanStatus.FAILED or r.risk_level in ("high", "critical")
        ]

    def to_dict(self) -> dict[str, Any]:
        """Convert report to dictionary for serialization."""
        return {
            "report_id": self.report_id,
            "timestamp": self.timestamp.isoformat(),
            "overall_risk": self.overall_risk.value,
            "scan_types": [st.value for st in self.scan_types],
            "module_results": [
                {
                    "module_name": r.module_name,
                    "scan_type": r.scan_type.value,
                    "status": r.status.value,
                    "risk_level": r.risk_level,
                    "confidence": r.confidence,
                    "details": r.details,
                    "error": r.error,
                    "duration_ms": r.duration_ms,
                }
                for r in self.module_results
            ],
            "summary": self.summary,
            "recommendations": self.recommendations,
            "metadata": self.metadata,
            "is_secure": self.is_secure,
            "failed_modules": self.failed_modules,
        }


class PlatformStatus(BaseModel):
    """Current status of the QML Security Platform."""

    overall_risk: OverallRisk = OverallRisk.SECURE
    modules_available: list[str] = []
    last_scan_time: datetime | None = None
    total_scans: int = 0
    active_alerts: int = 0
    models_registered: int = 0
    noise_profiles_stored: int = 0

    model_config = {"use_enum_values": True}


class PlatformConfig(BaseModel):
    """Configuration for the QML Security Platform."""

    # QSentry settings
    qsentry_n_clusters: int = 5
    qsentry_outlier_threshold: float = 2.0

    # VQC Verifier settings
    vqc_default_epsilon: float = 0.1
    vqc_epsilon_range: tuple[float, float] = (0.01, 0.5)

    # Noise Profiler settings
    noise_match_threshold: float = 0.85
    noise_storage_path: str | None = None

    # Model Registry settings
    registry_db_path: str | None = None
    registry_algorithm: str = "ML-DSA-65"

    # General settings
    enable_auto_alerts: bool = True
    alert_on_high_risk: bool = True
    store_reports: bool = True
    max_stored_reports: int = 1000


class QMLPlatform:
    """
    Unified QML Security Platform.

    Orchestrates all QML security modules and provides a single interface
    for comprehensive security scanning of quantum machine learning systems.
    """

    def __init__(self, config: PlatformConfig | None = None) -> None:
        """Initialize the QML Security Platform.

        Args:
            config: Platform configuration. Uses defaults if not provided.
        """
        self.config = config or PlatformConfig()
        self._reports: list[PlatformReport] = []
        self._status = PlatformStatus()

        # Lazy-loaded modules
        self._qsentry: Any = None
        self._vqc_verifier: Any = None
        self._noise_profiler: Any = None
        self._model_registry: Any = None
        self._keypair: Any = None

        self._update_available_modules()

    def _update_available_modules(self) -> None:
        """Update list of available modules."""
        modules = []
        try:
            from .qsentry import QSentry  # noqa: F401

            modules.append("qsentry")
        except ImportError:
            pass

        try:
            from .vqc_verifier import VQCVerifier  # noqa: F401

            modules.append("vqc_verifier")
        except ImportError:
            pass

        try:
            from .noise_profiler import NoiseProfiler  # noqa: F401

            modules.append("noise_profiler")
        except ImportError:
            pass

        try:
            from .model_registry import ModelRegistry  # noqa: F401

            modules.append("model_registry")
        except ImportError:
            pass

        self._status.modules_available = modules

    @property
    def qsentry(self) -> Any:
        """Get or create QSentry instance."""
        if self._qsentry is None:
            from .qsentry import QSentry

            self._qsentry = QSentry(
                n_clusters=self.config.qsentry_n_clusters,
                outlier_threshold=self.config.qsentry_outlier_threshold,
            )
        return self._qsentry

    @property
    def vqc_verifier(self) -> Any:
        """Get or create VQC Verifier instance."""
        if self._vqc_verifier is None:
            from .vqc_verifier import VQCVerifier

            self._vqc_verifier = VQCVerifier()
        return self._vqc_verifier

    @property
    def noise_profiler(self) -> Any:
        """Get or create Noise Profiler instance."""
        if self._noise_profiler is None:
            from .noise_profiler import NoiseProfiler

            self._noise_profiler = NoiseProfiler(
                match_threshold=self.config.noise_match_threshold,
            )
        return self._noise_profiler

    @property
    def model_registry(self) -> Any:
        """Get or create Model Registry instance."""
        if self._model_registry is None:
            from ..core.identity import IdentityProvider, parse_algorithm
            from .model_registry import ModelRegistry

            # Create keypair for signing
            if self._keypair is None:
                alg = parse_algorithm(self.config.registry_algorithm)
                provider = IdentityProvider(alg)
                self._keypair = provider.generate_keypair()

            self._model_registry = ModelRegistry(
                keypair=self._keypair,
                signer_id="qml-platform",
                storage_path=self.config.registry_db_path,
            )
        return self._model_registry

    def scan_backdoor(
        self,
        measurements: list[Any],
        sample_ids: list[int] | None = None,
    ) -> ModuleScanResult:
        """Scan measurements for backdoor indicators using QSentry.

        Args:
            measurements: List of MeasurementData objects
            sample_ids: Optional sample identifiers

        Returns:
            ModuleScanResult with backdoor detection results
        """
        import time

        start = time.perf_counter()

        try:
            # Create fresh QSentry for this scan
            from .qsentry import QSentry

            qsentry = QSentry(
                n_clusters=self.config.qsentry_n_clusters,
                outlier_threshold=self.config.qsentry_outlier_threshold,
            )

            for i, m in enumerate(measurements):
                sid = sample_ids[i] if sample_ids else i
                qsentry.add_measurement(m, sample_id=sid)

            report = qsentry.analyze()
            duration = (time.perf_counter() - start) * 1000

            return ModuleScanResult(
                module_name="qsentry",
                scan_type=ScanType.BACKDOOR,
                status=ScanStatus.COMPLETED,
                risk_level=report.risk_level.value,
                confidence=report.confidence,
                details={
                    "n_samples": report.n_samples,
                    "n_clusters": report.n_clusters,
                    "suspicious_samples": report.suspicious_samples,
                    "description": report.description,
                },
                duration_ms=duration,
            )
        except Exception as e:
            duration = (time.perf_counter() - start) * 1000
            return ModuleScanResult(
                module_name="qsentry",
                scan_type=ScanType.BACKDOOR,
                status=ScanStatus.FAILED,
                risk_level="unknown",
                confidence=0.0,
                error=str(e),
                duration_ms=duration,
            )

    def scan_robustness(
        self,
        circuit: Any,
        epsilon: float | None = None,
        target_class: int = 0,
    ) -> ModuleScanResult:
        """Verify VQC robustness using interval arithmetic.

        Args:
            circuit: QuantumCircuit to verify
            epsilon: Perturbation bound (uses default if not provided)
            target_class: Target classification class

        Returns:
            ModuleScanResult with robustness verification results
        """
        import time

        start = time.perf_counter()

        try:
            eps = epsilon or self.config.vqc_default_epsilon
            report = self.vqc_verifier.verify_circuit(
                circuit=circuit,
                epsilons=[eps],
                target_class=target_class,
            )

            duration = (time.perf_counter() - start) * 1000

            # Determine risk based on certification status
            cert = report.certificates[0] if report.certificates else None
            if cert and cert.is_certified:
                risk = "low"
            elif cert and cert.max_certified_epsilon > 0:
                risk = "medium"
            else:
                risk = "high"

            return ModuleScanResult(
                module_name="vqc_verifier",
                scan_type=ScanType.ROBUSTNESS,
                status=ScanStatus.COMPLETED,
                risk_level=risk,
                confidence=0.95 if cert and cert.is_certified else 0.5,
                details={
                    "is_certified": cert.is_certified if cert else False,
                    "max_certified_epsilon": cert.max_certified_epsilon if cert else 0.0,
                    "epsilon_tested": eps,
                    "target_class": target_class,
                },
                duration_ms=duration,
            )
        except Exception as e:
            duration = (time.perf_counter() - start) * 1000
            return ModuleScanResult(
                module_name="vqc_verifier",
                scan_type=ScanType.ROBUSTNESS,
                status=ScanStatus.FAILED,
                risk_level="unknown",
                confidence=0.0,
                error=str(e),
                duration_ms=duration,
            )

    def scan_noise_profile(
        self,
        profile: Any,
        reference_id: str | None = None,
    ) -> ModuleScanResult:
        """Verify noise profile matches expected device characteristics.

        Args:
            profile: NoiseProfile to verify
            reference_id: Optional reference profile ID to compare against

        Returns:
            ModuleScanResult with noise profile verification results
        """
        import time

        start = time.perf_counter()

        try:
            if reference_id:
                # Compare against stored reference
                match = self.noise_profiler.match_profile(profile, reference_id)
                is_match = match.status.value == "match"
                similarity = match.similarity
            else:
                # Just verify profile is valid
                is_match = True
                similarity = 1.0

            duration = (time.perf_counter() - start) * 1000

            risk = "low" if is_match else "high"

            return ModuleScanResult(
                module_name="noise_profiler",
                scan_type=ScanType.NOISE,
                status=ScanStatus.COMPLETED,
                risk_level=risk,
                confidence=similarity,
                details={
                    "device_name": profile.device_name,
                    "n_qubits": profile.n_qubits,
                    "fingerprint": profile.fingerprint[:16] + "...",
                    "reference_match": is_match,
                    "similarity": similarity,
                },
                duration_ms=duration,
            )
        except Exception as e:
            duration = (time.perf_counter() - start) * 1000
            return ModuleScanResult(
                module_name="noise_profiler",
                scan_type=ScanType.NOISE,
                status=ScanStatus.FAILED,
                risk_level="unknown",
                confidence=0.0,
                error=str(e),
                duration_ms=duration,
            )

    def scan_integrity(
        self,
        model_path: Path | str,
        registry_id: str | None = None,
    ) -> ModuleScanResult:
        """Verify model integrity using ML-DSA signatures.

        Args:
            model_path: Path to model file
            registry_id: Optional registry ID to verify against

        Returns:
            ModuleScanResult with integrity verification results
        """
        import time

        start = time.perf_counter()
        model_path = Path(model_path)

        try:
            if registry_id:
                # Verify against existing registration
                result = self.model_registry.verify(model_path, registry_id)
                is_valid = result.is_valid
                file_hash = result.file_hash
            else:
                # Just compute hash (no verification)
                from .model_registry import compute_file_hash

                file_hash = compute_file_hash(model_path)
                is_valid = True  # No reference to compare

            duration = (time.perf_counter() - start) * 1000

            risk = "low" if is_valid else "critical"

            return ModuleScanResult(
                module_name="model_registry",
                scan_type=ScanType.INTEGRITY,
                status=ScanStatus.COMPLETED,
                risk_level=risk,
                confidence=1.0 if is_valid else 0.0,
                details={
                    "file_path": str(model_path),
                    "file_hash": file_hash[:32] + "..." if file_hash else None,
                    "registry_id": registry_id,
                    "is_valid": is_valid,
                },
                duration_ms=duration,
            )
        except Exception as e:
            duration = (time.perf_counter() - start) * 1000
            return ModuleScanResult(
                module_name="model_registry",
                scan_type=ScanType.INTEGRITY,
                status=ScanStatus.FAILED,
                risk_level="unknown",
                confidence=0.0,
                error=str(e),
                duration_ms=duration,
            )

    def full_scan(
        self,
        model_path: Path | str | None = None,
        measurements: list[Any] | None = None,
        circuit: Any | None = None,
        noise_profile: Any | None = None,
        registry_id: str | None = None,
        reference_profile_id: str | None = None,
    ) -> PlatformReport:
        """Run full security scan across all available modules.

        Args:
            model_path: Path to model file for integrity check
            measurements: Measurement data for backdoor detection
            circuit: Quantum circuit for robustness verification
            noise_profile: Noise profile for device verification
            registry_id: Registry ID for model verification
            reference_profile_id: Reference profile ID for noise comparison

        Returns:
            PlatformReport with comprehensive security assessment
        """
        report_id = str(uuid.uuid4())
        timestamp = datetime.now(tz=UTC)
        results: list[ModuleScanResult] = []
        scan_types: list[ScanType] = []

        # Run backdoor scan if measurements provided
        if measurements:
            result = self.scan_backdoor(measurements)
            results.append(result)
            scan_types.append(ScanType.BACKDOOR)

        # Run robustness scan if circuit provided
        if circuit:
            result = self.scan_robustness(circuit)
            results.append(result)
            scan_types.append(ScanType.ROBUSTNESS)

        # Run noise profile scan if profile provided
        if noise_profile:
            result = self.scan_noise_profile(noise_profile, reference_profile_id)
            results.append(result)
            scan_types.append(ScanType.NOISE)

        # Run integrity scan if model path provided
        if model_path:
            result = self.scan_integrity(model_path, registry_id)
            results.append(result)
            scan_types.append(ScanType.INTEGRITY)

        # If nothing provided, mark as full scan type
        if not scan_types:
            scan_types.append(ScanType.FULL)

        # Determine overall risk
        overall_risk = self._calculate_overall_risk(results)

        # Generate summary and recommendations
        summary = self._generate_summary(results)
        recommendations = self._generate_recommendations(results)

        report = PlatformReport(
            report_id=report_id,
            timestamp=timestamp,
            overall_risk=overall_risk,
            scan_types=scan_types,
            module_results=results,
            summary=summary,
            recommendations=recommendations,
        )

        # Store report
        if self.config.store_reports:
            self._reports.append(report)
            if len(self._reports) > self.config.max_stored_reports:
                self._reports = self._reports[-self.config.max_stored_reports :]

        # Update status
        self._status.last_scan_time = timestamp
        self._status.total_scans += 1
        self._status.overall_risk = overall_risk

        return report

    def _calculate_overall_risk(self, results: list[ModuleScanResult]) -> OverallRisk:
        """Calculate overall risk from module results."""
        if not results:
            return OverallRisk.SECURE

        risk_levels = [r.risk_level for r in results if r.status == ScanStatus.COMPLETED]

        if "critical" in risk_levels:
            return OverallRisk.CRITICAL
        if "high" in risk_levels:
            return OverallRisk.HIGH
        if "medium" in risk_levels:
            return OverallRisk.MEDIUM
        if "low" in risk_levels:
            return OverallRisk.LOW

        # Check for failures
        if any(r.status == ScanStatus.FAILED for r in results):
            return OverallRisk.MEDIUM

        return OverallRisk.SECURE

    def _generate_summary(self, results: list[ModuleScanResult]) -> str:
        """Generate human-readable summary of scan results."""
        if not results:
            return "No scans performed."

        completed = [r for r in results if r.status == ScanStatus.COMPLETED]
        failed = [r for r in results if r.status == ScanStatus.FAILED]

        parts = []

        if completed:
            high_risk = [r for r in completed if r.risk_level in ("high", "critical")]
            if high_risk:
                modules = ", ".join(r.module_name for r in high_risk)
                parts.append(f"High-risk findings in: {modules}")
            else:
                parts.append(f"All {len(completed)} completed scans show acceptable risk levels")

        if failed:
            modules = ", ".join(r.module_name for r in failed)
            parts.append(f"Failed scans: {modules}")

        return ". ".join(parts) + "."

    def _generate_recommendations(self, results: list[ModuleScanResult]) -> list[str]:
        """Generate actionable recommendations based on scan results."""
        recommendations = []

        for result in results:
            if result.status == ScanStatus.FAILED:
                recommendations.append(
                    f"Investigate {result.module_name} failure: {result.error}"
                )
            elif result.risk_level == "critical":
                if result.scan_type == ScanType.INTEGRITY:
                    recommendations.append(
                        "CRITICAL: Model integrity compromised. Do not deploy."
                    )
                elif result.scan_type == ScanType.BACKDOOR:
                    recommendations.append(
                        "CRITICAL: Potential backdoor detected. Quarantine model."
                    )
            elif result.risk_level == "high":
                if result.scan_type == ScanType.BACKDOOR:
                    recommendations.append(
                        "Review suspicious samples flagged by QSentry."
                    )
                elif result.scan_type == ScanType.ROBUSTNESS:
                    recommendations.append(
                        "Circuit robustness is low. Consider adversarial training."
                    )
                elif result.scan_type == ScanType.NOISE:
                    recommendations.append(
                        "Noise profile mismatch. Verify device authenticity."
                    )
            elif result.risk_level == "medium":
                if result.scan_type == ScanType.ROBUSTNESS:
                    recommendations.append(
                        "Consider increasing robustness certification epsilon."
                    )

        if not recommendations:
            recommendations.append("No immediate actions required.")

        return recommendations

    def get_status(self) -> PlatformStatus:
        """Get current platform status.

        Returns:
            PlatformStatus with current security state
        """
        # Update counts
        with contextlib.suppress(Exception):
            self._status.models_registered = len(self.model_registry.list_entries())

        with contextlib.suppress(Exception):
            self._status.noise_profiles_stored = len(self.noise_profiler.storage.list_profiles())

        return self._status

    def get_reports(self, limit: int = 10) -> list[PlatformReport]:
        """Get recent scan reports.

        Args:
            limit: Maximum number of reports to return

        Returns:
            List of recent PlatformReport objects
        """
        return self._reports[-limit:]

    def get_report(self, report_id: str) -> PlatformReport | None:
        """Get a specific scan report by ID.

        Args:
            report_id: Report ID to retrieve

        Returns:
            PlatformReport if found, None otherwise
        """
        for report in self._reports:
            if report.report_id == report_id:
                return report
        return None

    def clear_reports(self) -> int:
        """Clear all stored reports.

        Returns:
            Number of reports cleared
        """
        count = len(self._reports)
        self._reports.clear()
        return count


def create_platform(config: PlatformConfig | None = None) -> QMLPlatform:
    """Create a QML Security Platform instance.

    Args:
        config: Optional platform configuration

    Returns:
        Configured QMLPlatform instance
    """
    return QMLPlatform(config)
