"""Quantum Noise Profiler - Device fingerprinting for circuit integrity verification.

This module implements quantum hardware noise profiling and fingerprinting,
allowing verification that circuits ran on expected devices and detection
of hardware-level tampering.

Based on research from:
- Quantum noise watermarking research
- Hardware fingerprinting via noise characteristics

Key concepts:
- Each quantum device has unique noise signatures
- Noise patterns can serve as natural watermarks
- Profile matching enables device verification
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

import numpy as np


class NoiseType(Enum):
    """Types of quantum noise."""

    DEPOLARIZING = "depolarizing"
    AMPLITUDE_DAMPING = "amplitude_damping"
    PHASE_DAMPING = "phase_damping"
    READOUT = "readout"
    CROSSTALK = "crosstalk"
    THERMAL = "thermal"


@dataclass
class QubitNoiseParams:
    """Noise parameters for a single qubit."""

    qubit_id: int
    t1: float  # Relaxation time (microseconds)
    t2: float  # Dephasing time (microseconds)
    readout_error_0: float  # P(1|0) - probability of reading 1 when state is 0
    readout_error_1: float  # P(0|1) - probability of reading 0 when state is 1
    gate_error_1q: float  # Single-qubit gate error rate
    gate_error_2q: float  # Two-qubit gate error rate (with adjacent qubits)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "qubit_id": self.qubit_id,
            "t1": self.t1,
            "t2": self.t2,
            "readout_error_0": self.readout_error_0,
            "readout_error_1": self.readout_error_1,
            "gate_error_1q": self.gate_error_1q,
            "gate_error_2q": self.gate_error_2q,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> QubitNoiseParams:
        """Create from dictionary."""
        return cls(
            qubit_id=data["qubit_id"],
            t1=data["t1"],
            t2=data["t2"],
            readout_error_0=data["readout_error_0"],
            readout_error_1=data["readout_error_1"],
            gate_error_1q=data["gate_error_1q"],
            gate_error_2q=data["gate_error_2q"],
        )

    def as_vector(self) -> np.ndarray:
        """Convert to feature vector for comparison."""
        return np.array([
            self.t1,
            self.t2,
            self.readout_error_0,
            self.readout_error_1,
            self.gate_error_1q,
            self.gate_error_2q,
        ])


@dataclass
class NoiseProfile:
    """Complete noise profile for a quantum device."""

    profile_id: str
    device_name: str
    n_qubits: int
    qubit_params: list[QubitNoiseParams]
    connectivity: list[tuple[int, int]]  # Pairs of connected qubits
    calibration_timestamp: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "profile_id": self.profile_id,
            "device_name": self.device_name,
            "n_qubits": self.n_qubits,
            "qubit_params": [q.to_dict() for q in self.qubit_params],
            "connectivity": self.connectivity,
            "calibration_timestamp": self.calibration_timestamp,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NoiseProfile:
        """Create from dictionary."""
        return cls(
            profile_id=data["profile_id"],
            device_name=data["device_name"],
            n_qubits=data["n_qubits"],
            qubit_params=[QubitNoiseParams.from_dict(q) for q in data["qubit_params"]],
            connectivity=[tuple(c) for c in data["connectivity"]],
            calibration_timestamp=data["calibration_timestamp"],
            metadata=data.get("metadata", {}),
        )

    def fingerprint(self) -> str:
        """Generate unique fingerprint for this profile.

        Uses a hash of the noise parameters to create a unique identifier.
        """
        # Concatenate all noise parameters
        params_str = ""
        for qp in sorted(self.qubit_params, key=lambda x: x.qubit_id):
            params_str += f"{qp.t1:.6f},{qp.t2:.6f},"
            params_str += f"{qp.readout_error_0:.6f},{qp.readout_error_1:.6f},"
            params_str += f"{qp.gate_error_1q:.6f},{qp.gate_error_2q:.6f};"

        # Include connectivity
        params_str += str(sorted(self.connectivity))

        # Hash
        return hashlib.sha256(params_str.encode()).hexdigest()[:32]

    def as_feature_matrix(self) -> np.ndarray:
        """Convert to feature matrix for ML-based comparison."""
        vectors = [qp.as_vector() for qp in sorted(self.qubit_params, key=lambda x: x.qubit_id)]
        return np.array(vectors)


class MatchStatus(Enum):
    """Result of profile matching."""

    MATCH = "match"
    PARTIAL_MATCH = "partial_match"
    NO_MATCH = "no_match"
    INSUFFICIENT_DATA = "insufficient_data"


@dataclass
class MatchResult:
    """Result of comparing two noise profiles."""

    status: MatchStatus
    similarity: float  # 0.0 to 1.0
    confidence: float  # Confidence in the result
    matched_qubits: list[int]  # Qubits that matched
    mismatched_qubits: list[int]  # Qubits that didn't match
    description: str
    metadata: dict[str, Any] = field(default_factory=dict)


class NoiseProfiler:
    """Quantum noise profiler for device fingerprinting.

    Collects noise characteristics from quantum hardware and uses them
    to verify device identity and detect tampering.
    """

    def __init__(
        self,
        match_threshold: float = 0.9,
        qubit_match_threshold: float = 0.85,
    ) -> None:
        """Initialize the profiler.

        Args:
            match_threshold: Overall similarity threshold for matching.
            qubit_match_threshold: Per-qubit similarity threshold.
        """
        self.match_threshold = match_threshold
        self.qubit_match_threshold = qubit_match_threshold

    def profile_from_calibration(
        self,
        device_name: str,
        calibration_data: dict[str, Any],
    ) -> NoiseProfile:
        """Create noise profile from calibration data.

        Args:
            device_name: Name of the quantum device.
            calibration_data: Calibration data with qubit properties.

        Returns:
            NoiseProfile for the device.
        """
        qubit_params = []

        # Parse calibration data
        qubits = calibration_data.get("qubits", calibration_data.get("qubit_properties", []))

        for i, qubit_data in enumerate(qubits):
            params = QubitNoiseParams(
                qubit_id=i,
                t1=qubit_data.get("t1", qubit_data.get("T1", 100.0)),
                t2=qubit_data.get("t2", qubit_data.get("T2", 50.0)),
                readout_error_0=qubit_data.get("readout_error_0", qubit_data.get("prob_meas1_prep0", 0.01)),
                readout_error_1=qubit_data.get("readout_error_1", qubit_data.get("prob_meas0_prep1", 0.01)),
                gate_error_1q=qubit_data.get("gate_error_1q", qubit_data.get("sx_error", 0.001)),
                gate_error_2q=qubit_data.get("gate_error_2q", qubit_data.get("cx_error", 0.01)),
            )
            qubit_params.append(params)

        # Parse connectivity
        connectivity = calibration_data.get("connectivity", calibration_data.get("coupling_map", []))
        if isinstance(connectivity, dict):
            connectivity = list(connectivity.items())

        return NoiseProfile(
            profile_id=f"prof_{uuid.uuid4().hex[:16]}",
            device_name=device_name,
            n_qubits=len(qubit_params),
            qubit_params=qubit_params,
            connectivity=[(int(a), int(b)) for a, b in connectivity],
            calibration_timestamp=datetime.utcnow().isoformat(),
            metadata={"source": "calibration_data"},
        )

    def profile_from_measurements(
        self,
        device_name: str,
        measurement_results: list[dict[str, Any]],
        n_qubits: int,
    ) -> NoiseProfile:
        """Create noise profile from measurement results.

        Uses statistical analysis of measurement outcomes to estimate
        noise parameters.

        Args:
            device_name: Name of the quantum device.
            measurement_results: List of measurement outcomes.
            n_qubits: Number of qubits.

        Returns:
            Estimated NoiseProfile.
        """
        qubit_params = []

        for q in range(n_qubits):
            # Estimate readout errors from measurement statistics
            # This is a simplified estimation
            readout_0_errors = []
            readout_1_errors = []

            for result in measurement_results:
                if f"readout_q{q}_prep0" in result:
                    # Count errors when preparing |0>
                    counts = result[f"readout_q{q}_prep0"]
                    total = sum(counts.values())
                    ones = sum(c for k, c in counts.items() if k[q] == "1")
                    readout_0_errors.append(ones / total if total > 0 else 0)

                if f"readout_q{q}_prep1" in result:
                    # Count errors when preparing |1>
                    counts = result[f"readout_q{q}_prep1"]
                    total = sum(counts.values())
                    zeros = sum(c for k, c in counts.items() if k[q] == "0")
                    readout_1_errors.append(zeros / total if total > 0 else 0)

            params = QubitNoiseParams(
                qubit_id=q,
                t1=100.0,  # Default - would need decay experiments
                t2=50.0,  # Default - would need Ramsey experiments
                readout_error_0=np.mean(readout_0_errors) if readout_0_errors else 0.01,
                readout_error_1=np.mean(readout_1_errors) if readout_1_errors else 0.01,
                gate_error_1q=0.001,  # Default - would need RB
                gate_error_2q=0.01,  # Default - would need 2Q RB
            )
            qubit_params.append(params)

        return NoiseProfile(
            profile_id=f"prof_{uuid.uuid4().hex[:16]}",
            device_name=device_name,
            n_qubits=n_qubits,
            qubit_params=qubit_params,
            connectivity=[],  # Unknown from measurements alone
            calibration_timestamp=datetime.utcnow().isoformat(),
            metadata={"source": "measurements", "n_samples": len(measurement_results)},
        )

    def compare_profiles(
        self,
        profile1: NoiseProfile,
        profile2: NoiseProfile,
    ) -> MatchResult:
        """Compare two noise profiles.

        Args:
            profile1: First profile.
            profile2: Second profile.

        Returns:
            MatchResult with comparison details.
        """
        # Check qubit counts
        if profile1.n_qubits != profile2.n_qubits:
            return MatchResult(
                status=MatchStatus.NO_MATCH,
                similarity=0.0,
                confidence=1.0,
                matched_qubits=[],
                mismatched_qubits=list(range(max(profile1.n_qubits, profile2.n_qubits))),
                description=f"Qubit count mismatch: {profile1.n_qubits} vs {profile2.n_qubits}",
            )

        # Compare per-qubit parameters
        matched_qubits = []
        mismatched_qubits = []
        similarities = []

        for q in range(profile1.n_qubits):
            p1_params = profile1.qubit_params[q]
            p2_params = profile2.qubit_params[q]

            # Compute similarity using normalized distance
            v1 = p1_params.as_vector()
            v2 = p2_params.as_vector()

            # Normalize by expected ranges
            # T1, T2 in microseconds (0-500), errors in fractions (0-1)
            normalization = np.array([500.0, 200.0, 1.0, 1.0, 0.1, 0.1])
            v1_norm = v1 / normalization
            v2_norm = v2 / normalization

            # Cosine similarity
            dot = np.dot(v1_norm, v2_norm)
            norm1 = np.linalg.norm(v1_norm)
            norm2 = np.linalg.norm(v2_norm)

            similarity = dot / (norm1 * norm2) if norm1 > 0 and norm2 > 0 else 0.0

            similarities.append(similarity)

            if similarity >= self.qubit_match_threshold:
                matched_qubits.append(q)
            else:
                mismatched_qubits.append(q)

        # Overall similarity
        overall_similarity = np.mean(similarities) if similarities else 0.0

        # Determine status
        if overall_similarity >= self.match_threshold:
            status = MatchStatus.MATCH
            description = f"Profiles match with {overall_similarity:.1%} similarity"
        elif overall_similarity >= self.match_threshold * 0.8:
            status = MatchStatus.PARTIAL_MATCH
            description = f"Partial match ({overall_similarity:.1%}), {len(mismatched_qubits)} qubits differ"
        else:
            status = MatchStatus.NO_MATCH
            description = f"Profiles do not match ({overall_similarity:.1%} similarity)"

        return MatchResult(
            status=status,
            similarity=overall_similarity,
            confidence=min(1.0, len(similarities) / 5),  # More qubits = more confidence
            matched_qubits=matched_qubits,
            mismatched_qubits=mismatched_qubits,
            description=description,
            metadata={
                "per_qubit_similarities": similarities,
                "threshold": self.match_threshold,
            },
        )

    def verify_device(
        self,
        expected_profile: NoiseProfile,
        actual_profile: NoiseProfile,
    ) -> bool:
        """Verify that actual profile matches expected.

        Args:
            expected_profile: Expected device profile.
            actual_profile: Observed profile.

        Returns:
            True if profiles match.
        """
        result = self.compare_profiles(expected_profile, actual_profile)
        return result.status == MatchStatus.MATCH

    def extract_watermark(
        self,
        measurements: np.ndarray,
        n_bits: int = 32,
    ) -> bytes:
        """Extract watermark from measurement noise patterns.

        Uses the inherent noise in measurements as a natural watermark.

        Args:
            measurements: Raw measurement outcomes (n_shots x n_qubits).
            n_bits: Number of bits in the watermark.

        Returns:
            Watermark bytes extracted from noise.
        """
        if len(measurements) == 0:
            return b"\x00" * (n_bits // 8)

        # Compute per-qubit statistics that depend on noise
        n_qubits = measurements.shape[1] if len(measurements.shape) > 1 else 1

        # Extract features from measurement distribution
        features = []

        for q in range(n_qubits):
            qubit_measurements = measurements if n_qubits == 1 else measurements[:, q]

            # Mean (affected by readout bias)
            mean = np.mean(qubit_measurements)

            # Variance (affected by noise)
            var = np.var(qubit_measurements)

            # Autocorrelation lag-1 (affected by temporal correlations)
            if len(qubit_measurements) > 1:
                autocorr = np.corrcoef(qubit_measurements[:-1], qubit_measurements[1:])[0, 1]
                if np.isnan(autocorr):
                    autocorr = 0.0
            else:
                autocorr = 0.0

            features.extend([mean, var, autocorr])

        # Hash features to get watermark
        feature_str = ",".join(f"{f:.6f}" for f in features)
        full_hash = hashlib.sha256(feature_str.encode()).digest()

        return full_hash[: n_bits // 8]


class NoiseProfileStorage:
    """SQLite storage for noise profiles."""

    def __init__(self, db_path: str | Path | None = None) -> None:
        """Initialize storage.

        Args:
            db_path: Path to SQLite database. Defaults to user data directory.
        """
        if db_path is None:
            db_path = Path.home() / ".asqav" / "noise_profiles.db"
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Get database connection."""
        return sqlite3.connect(self.db_path)

    def _init_db(self) -> None:
        """Initialize database schema."""
        conn = self._get_connection()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS profiles (
                    profile_id TEXT PRIMARY KEY,
                    device_name TEXT NOT NULL,
                    fingerprint TEXT NOT NULL,
                    profile_data TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_device_name ON profiles(device_name)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_fingerprint ON profiles(fingerprint)
            """)
            conn.commit()
        finally:
            conn.close()

    def save(self, profile: NoiseProfile) -> None:
        """Save a noise profile.

        Args:
            profile: Profile to save.
        """
        conn = self._get_connection()
        try:
            now = datetime.utcnow().isoformat()
            conn.execute(
                """
                INSERT OR REPLACE INTO profiles
                (profile_id, device_name, fingerprint, profile_data, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    profile.profile_id,
                    profile.device_name,
                    profile.fingerprint(),
                    json.dumps(profile.to_dict()),
                    now,
                    now,
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def load(self, profile_id: str) -> NoiseProfile | None:
        """Load a noise profile by ID.

        Args:
            profile_id: Profile ID.

        Returns:
            NoiseProfile or None if not found.
        """
        conn = self._get_connection()
        try:
            cursor = conn.execute(
                "SELECT profile_data FROM profiles WHERE profile_id = ?",
                (profile_id,),
            )
            row = cursor.fetchone()
            if row:
                return NoiseProfile.from_dict(json.loads(row[0]))
            return None
        finally:
            conn.close()

    def load_by_device(self, device_name: str) -> list[NoiseProfile]:
        """Load all profiles for a device.

        Args:
            device_name: Device name.

        Returns:
            List of profiles.
        """
        conn = self._get_connection()
        try:
            cursor = conn.execute(
                "SELECT profile_data FROM profiles WHERE device_name = ? ORDER BY updated_at DESC",
                (device_name,),
            )
            return [NoiseProfile.from_dict(json.loads(row[0])) for row in cursor.fetchall()]
        finally:
            conn.close()

    def find_by_fingerprint(self, fingerprint: str) -> NoiseProfile | None:
        """Find profile by fingerprint.

        Args:
            fingerprint: Profile fingerprint.

        Returns:
            NoiseProfile or None if not found.
        """
        conn = self._get_connection()
        try:
            cursor = conn.execute(
                "SELECT profile_data FROM profiles WHERE fingerprint = ?",
                (fingerprint,),
            )
            row = cursor.fetchone()
            if row:
                return NoiseProfile.from_dict(json.loads(row[0]))
            return None
        finally:
            conn.close()

    def list_devices(self) -> list[str]:
        """List all device names with profiles.

        Returns:
            List of device names.
        """
        conn = self._get_connection()
        try:
            cursor = conn.execute("SELECT DISTINCT device_name FROM profiles")
            return [row[0] for row in cursor.fetchall()]
        finally:
            conn.close()

    def delete(self, profile_id: str) -> bool:
        """Delete a profile.

        Args:
            profile_id: Profile ID.

        Returns:
            True if deleted.
        """
        conn = self._get_connection()
        try:
            cursor = conn.execute(
                "DELETE FROM profiles WHERE profile_id = ?",
                (profile_id,),
            )
            conn.commit()
            return cursor.rowcount > 0
        finally:
            conn.close()


def create_synthetic_profile(
    device_name: str,
    n_qubits: int,
    noise_level: str = "medium",
) -> NoiseProfile:
    """Create a synthetic noise profile for testing.

    Args:
        device_name: Name for the device.
        n_qubits: Number of qubits.
        noise_level: "low", "medium", or "high".

    Returns:
        Synthetic NoiseProfile.
    """
    # Base parameters by noise level
    noise_params = {
        "low": {"t1": 200.0, "t2": 100.0, "re": 0.005, "ge1": 0.0005, "ge2": 0.005},
        "medium": {"t1": 100.0, "t2": 50.0, "re": 0.01, "ge1": 0.001, "ge2": 0.01},
        "high": {"t1": 50.0, "t2": 25.0, "re": 0.02, "ge1": 0.005, "ge2": 0.02},
    }

    base = noise_params.get(noise_level, noise_params["medium"])

    # Add some variation per qubit
    np.random.seed(hash(device_name) % (2**32))

    qubit_params = []
    for q in range(n_qubits):
        variation = 1.0 + 0.2 * np.random.randn()
        params = QubitNoiseParams(
            qubit_id=q,
            t1=max(10.0, base["t1"] * variation),
            t2=max(5.0, base["t2"] * variation),
            readout_error_0=max(0.001, base["re"] * abs(1 + 0.3 * np.random.randn())),
            readout_error_1=max(0.001, base["re"] * abs(1 + 0.3 * np.random.randn())),
            gate_error_1q=max(0.0001, base["ge1"] * abs(1 + 0.2 * np.random.randn())),
            gate_error_2q=max(0.001, base["ge2"] * abs(1 + 0.2 * np.random.randn())),
        )
        qubit_params.append(params)

    # Create linear connectivity
    connectivity = [(i, i + 1) for i in range(n_qubits - 1)]

    return NoiseProfile(
        profile_id=f"prof_{uuid.uuid4().hex[:16]}",
        device_name=device_name,
        n_qubits=n_qubits,
        qubit_params=qubit_params,
        connectivity=connectivity,
        calibration_timestamp=datetime.utcnow().isoformat(),
        metadata={"synthetic": True, "noise_level": noise_level},
    )
