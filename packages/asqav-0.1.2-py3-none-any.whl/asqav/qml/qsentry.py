"""
QSentry: Backdoor detection for Quantum Neural Networks.

This module implements measurement clustering techniques for detecting
backdoor attacks in quantum neural networks, based on the research paper:
"QSentry: Backdoor Detection for Quantum Neural Networks via Measurement Clustering"
(arXiv 2511.15376)

The key insight is that backdoor triggers cause anomalous measurement
distributions that can be detected through clustering analysis.

License Note: This implementation is inspired by the CC BY 4.0 licensed paper.
We implement the algorithm concepts (not copyrightable) in our own original code.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import numpy as np

from .qml_anomaly import MeasurementData


class BackdoorRisk(Enum):
    """Risk levels for backdoor detection."""

    CLEAN = "clean"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class ClusterInfo:
    """Information about a measurement cluster."""

    cluster_id: int
    centroid: np.ndarray
    size: int
    avg_distance: float
    samples: list[int]  # Indices of samples in this cluster

    @property
    def is_small(self) -> bool:
        """Check if cluster is abnormally small."""
        return self.size <= 3


@dataclass
class BackdoorReport:
    """Report from QSentry backdoor analysis."""

    report_id: str
    risk_level: BackdoorRisk
    confidence: float  # 0-1 confidence in the assessment
    n_samples: int
    n_clusters: int
    suspicious_samples: list[int]  # Indices of suspicious samples
    suspicious_clusters: list[ClusterInfo]
    description: str
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "report_id": self.report_id,
            "risk_level": self.risk_level.value,
            "confidence": self.confidence,
            "n_samples": self.n_samples,
            "n_clusters": self.n_clusters,
            "n_suspicious_samples": len(self.suspicious_samples),
            "suspicious_sample_indices": self.suspicious_samples[:20],  # Limit for readability
            "description": self.description,
            "details": self.details,
        }


class QSentry:
    """Backdoor detection for quantum neural networks.

    Uses measurement clustering to identify potentially backdoored samples
    by finding anomalous measurement distributions.

    Example:
        qsentry = QSentry(n_clusters=5)

        # Add measurements from test samples
        for i, measurement in enumerate(test_measurements):
            qsentry.add_measurement(measurement, sample_id=i)

        # Run analysis
        report = qsentry.analyze()

        if report.risk_level != BackdoorRisk.CLEAN:
            print(f"Warning: {report.description}")
    """

    def __init__(
        self,
        n_clusters: int = 5,
        outlier_threshold: float = 2.0,
        min_cluster_ratio: float = 0.05,
        entropy_threshold: float = 0.2,
    ) -> None:
        """Initialize QSentry.

        Args:
            n_clusters: Number of clusters for K-means.
            outlier_threshold: Standard deviations for outlier detection.
            min_cluster_ratio: Minimum cluster size as ratio of total samples.
            entropy_threshold: Minimum entropy ratio for normal samples.
        """
        self.n_clusters = n_clusters
        self.outlier_threshold = outlier_threshold
        self.min_cluster_ratio = min_cluster_ratio
        self.entropy_threshold = entropy_threshold

        self._measurements: list[MeasurementData] = []
        self._sample_ids: list[int] = []
        self._feature_vectors: list[np.ndarray] = []

    def add_measurement(
        self,
        measurement: MeasurementData,
        sample_id: int | None = None,
    ) -> None:
        """Add a measurement for analysis.

        Args:
            measurement: Quantum measurement data.
            sample_id: Optional sample identifier.
        """
        self._measurements.append(measurement)
        self._sample_ids.append(sample_id if sample_id is not None else len(self._measurements) - 1)

        # Extract feature vector from measurement
        features = self._extract_features(measurement)
        self._feature_vectors.append(features)

    def _extract_features(self, measurement: MeasurementData) -> np.ndarray:
        """Extract feature vector from measurement data.

        Features include:
        - Probability distribution
        - Entropy
        - Max probability
        - Distribution moments

        Args:
            measurement: Measurement data.

        Returns:
            Feature vector.
        """
        probs = measurement.probabilities

        # Basic features
        entropy = measurement.entropy
        max_prob = float(np.max(probs))
        min_nonzero = float(np.min(probs[probs > 0])) if np.any(probs > 0) else 0

        # Distribution moments
        mean = float(np.mean(probs))
        std = float(np.std(probs))
        skewness = float(np.mean(((probs - mean) / (std + 1e-10)) ** 3)) if std > 0 else 0
        kurtosis = float(np.mean(((probs - mean) / (std + 1e-10)) ** 4)) if std > 0 else 0

        # Combine into feature vector
        # Include probability distribution and statistical features
        features = np.concatenate(
            [
                probs,  # Full distribution
                np.array([entropy, max_prob, min_nonzero, mean, std, skewness, kurtosis]),
            ]
        )

        return features

    def clear(self) -> None:
        """Clear all stored measurements."""
        self._measurements.clear()
        self._sample_ids.clear()
        self._feature_vectors.clear()

    def analyze(self) -> BackdoorReport:
        """Analyze collected measurements for backdoor indicators.

        Returns:
            BackdoorReport with analysis results.
        """
        if len(self._measurements) < self.n_clusters:
            return BackdoorReport(
                report_id=f"qsentry_{uuid.uuid4().hex[:12]}",
                risk_level=BackdoorRisk.CLEAN,
                confidence=0.0,
                n_samples=len(self._measurements),
                n_clusters=0,
                suspicious_samples=[],
                suspicious_clusters=[],
                description="Insufficient samples for analysis",
            )

        # Convert to feature matrix
        X = np.array(self._feature_vectors)

        # Normalize features
        X_normalized = self._normalize_features(X)

        # Run K-means clustering
        clusters, centroids = self._kmeans_clustering(X_normalized)

        # Analyze clusters for anomalies
        cluster_infos = self._analyze_clusters(X_normalized, clusters, centroids)

        # Identify suspicious patterns
        suspicious_samples, suspicious_clusters, risk_details = self._identify_suspicious(
            cluster_infos
        )

        # Determine risk level
        risk_level, confidence, description = self._assess_risk(
            suspicious_samples, suspicious_clusters, risk_details
        )

        return BackdoorReport(
            report_id=f"qsentry_{uuid.uuid4().hex[:12]}",
            risk_level=risk_level,
            confidence=confidence,
            n_samples=len(self._measurements),
            n_clusters=self.n_clusters,
            suspicious_samples=suspicious_samples,
            suspicious_clusters=suspicious_clusters,
            description=description,
            details=risk_details,
        )

    def _normalize_features(self, X: np.ndarray) -> np.ndarray:
        """Normalize feature matrix."""
        mean = np.mean(X, axis=0)
        std = np.std(X, axis=0)
        std[std == 0] = 1  # Avoid division by zero
        return np.asarray((X - mean) / std)

    def _kmeans_clustering(
        self,
        X: np.ndarray,
        max_iterations: int = 100,
        tolerance: float = 1e-4,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Simple K-means implementation.

        Args:
            X: Feature matrix (n_samples x n_features).
            max_iterations: Maximum iterations.
            tolerance: Convergence tolerance.

        Returns:
            Tuple of (cluster_assignments, centroids).
        """
        n_samples, n_features = X.shape
        k = min(self.n_clusters, n_samples)

        # Initialize centroids using K-means++
        centroids = self._init_centroids_plusplus(X, k)

        for _ in range(max_iterations):
            # Assign samples to nearest centroid
            distances = self._compute_distances(X, centroids)
            assignments = np.argmin(distances, axis=1)

            # Update centroids
            new_centroids = np.zeros_like(centroids)
            for i in range(k):
                mask = assignments == i
                if np.any(mask):
                    new_centroids[i] = np.mean(X[mask], axis=0)
                else:
                    new_centroids[i] = centroids[i]

            # Check convergence
            if np.allclose(centroids, new_centroids, atol=tolerance):
                break

            centroids = new_centroids

        return assignments, centroids

    def _init_centroids_plusplus(self, X: np.ndarray, k: int) -> np.ndarray:
        """Initialize centroids using K-means++ algorithm."""
        n_samples = X.shape[0]
        centroids = []

        # First centroid: random sample
        idx = np.random.randint(n_samples)
        centroids.append(X[idx])

        # Remaining centroids: weighted by distance
        for _ in range(1, k):
            distances = np.min(self._compute_distances(X, np.array(centroids)), axis=1)
            probabilities = distances**2

            # Handle edge case: all distances are zero (identical points)
            prob_sum = probabilities.sum()
            if prob_sum == 0 or np.isnan(prob_sum):
                # Fall back to random selection
                idx = np.random.randint(n_samples)
            else:
                probabilities /= prob_sum
                idx = np.random.choice(n_samples, p=probabilities)

            centroids.append(X[idx])

        return np.array(centroids)

    def _compute_distances(self, X: np.ndarray, centroids: np.ndarray) -> np.ndarray:
        """Compute distances from samples to centroids."""
        # Euclidean distance
        n_samples = X.shape[0]
        n_centroids = centroids.shape[0]
        distances = np.zeros((n_samples, n_centroids))

        for i, centroid in enumerate(centroids):
            distances[:, i] = np.linalg.norm(X - centroid, axis=1)

        return distances

    def _analyze_clusters(
        self,
        X: np.ndarray,
        assignments: np.ndarray,
        centroids: np.ndarray,
    ) -> list[ClusterInfo]:
        """Analyze cluster properties."""
        cluster_infos = []

        for i in range(len(centroids)):
            mask = assignments == i
            indices = np.where(mask)[0].tolist()
            size = len(indices)

            if size > 0:
                cluster_points = X[mask]
                distances = np.linalg.norm(cluster_points - centroids[i], axis=1)
                avg_distance = float(np.mean(distances))
            else:
                avg_distance = 0.0

            cluster_infos.append(
                ClusterInfo(
                    cluster_id=i,
                    centroid=centroids[i],
                    size=size,
                    avg_distance=avg_distance,
                    samples=[self._sample_ids[idx] for idx in indices],
                )
            )

        return cluster_infos

    def _identify_suspicious(
        self,
        cluster_infos: list[ClusterInfo],
    ) -> tuple[list[int], list[ClusterInfo], dict[str, Any]]:
        """Identify suspicious samples and clusters."""
        suspicious_samples = []
        suspicious_clusters = []
        risk_details: dict[str, Any] = {
            "small_clusters": [],
            "outlier_clusters": [],
            "entropy_anomalies": [],
        }

        total_samples = sum(c.size for c in cluster_infos)
        min_cluster_size = max(2, int(total_samples * self.min_cluster_ratio))

        # Calculate cluster distance statistics
        cluster_distances = [c.avg_distance for c in cluster_infos if c.size > 0]
        if cluster_distances:
            mean_distance = float(np.mean(cluster_distances))
            std_distance = float(np.std(cluster_distances))
        else:
            mean_distance = 0.0
            std_distance = 0.0

        for cluster in cluster_infos:
            is_suspicious = False
            reasons = []

            # Check 1: Abnormally small clusters
            if 0 < cluster.size < min_cluster_size:
                is_suspicious = True
                reasons.append(f"small_cluster (size={cluster.size})")
                risk_details["small_clusters"].append(cluster.cluster_id)

            # Check 2: Outlier distance (cluster is far from others)
            if std_distance > 0:
                z_score = (cluster.avg_distance - mean_distance) / std_distance
                if abs(z_score) > self.outlier_threshold:
                    is_suspicious = True
                    reasons.append(f"outlier_distance (z={z_score:.2f})")
                    risk_details["outlier_clusters"].append(cluster.cluster_id)

            if is_suspicious:
                suspicious_clusters.append(cluster)
                suspicious_samples.extend(cluster.samples)

        # Also check for entropy anomalies in individual measurements
        for i, measurement in enumerate(self._measurements):
            entropy_ratio = (
                measurement.entropy / measurement.max_entropy if measurement.max_entropy > 0 else 0
            )
            if entropy_ratio < self.entropy_threshold:
                if self._sample_ids[i] not in suspicious_samples:
                    suspicious_samples.append(self._sample_ids[i])
                    risk_details["entropy_anomalies"].append(self._sample_ids[i])

        return suspicious_samples, suspicious_clusters, risk_details

    def _assess_risk(
        self,
        suspicious_samples: list[int],
        suspicious_clusters: list[ClusterInfo],
        risk_details: dict[str, Any],
    ) -> tuple[BackdoorRisk, float, str]:
        """Assess overall risk level."""
        total_samples = len(self._measurements)
        suspicious_ratio = len(suspicious_samples) / total_samples if total_samples > 0 else 0

        # Determine risk level based on suspicious patterns
        if len(suspicious_samples) == 0:
            return BackdoorRisk.CLEAN, 0.95, "No suspicious patterns detected"

        if suspicious_ratio < 0.01:
            return BackdoorRisk.LOW, 0.7, f"Minor anomalies: {len(suspicious_samples)} suspicious samples"

        if suspicious_ratio < 0.05:
            confidence = 0.75 + (suspicious_ratio * 2)
            return (
                BackdoorRisk.MEDIUM,
                min(0.9, confidence),
                f"Moderate anomalies: {len(suspicious_samples)} suspicious samples ({suspicious_ratio:.1%})",
            )

        if suspicious_ratio < 0.15:
            confidence = 0.85 + (suspicious_ratio)
            return (
                BackdoorRisk.HIGH,
                min(0.95, confidence),
                f"Significant anomalies detected: {len(suspicious_samples)} suspicious samples ({suspicious_ratio:.1%})",
            )

        return (
            BackdoorRisk.CRITICAL,
            0.95,
            f"Critical: {len(suspicious_samples)} suspicious samples ({suspicious_ratio:.1%}) - likely backdoor attack",
        )


def analyze_measurements(
    measurements: list[MeasurementData],
    n_clusters: int = 5,
) -> BackdoorReport:
    """Convenience function to analyze a list of measurements.

    Args:
        measurements: List of measurement data.
        n_clusters: Number of clusters for analysis.

    Returns:
        BackdoorReport with analysis results.
    """
    qsentry = QSentry(n_clusters=n_clusters)

    for i, measurement in enumerate(measurements):
        qsentry.add_measurement(measurement, sample_id=i)

    return qsentry.analyze()
