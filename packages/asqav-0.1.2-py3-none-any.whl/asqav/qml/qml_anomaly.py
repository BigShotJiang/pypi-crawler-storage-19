"""
QML-specific anomaly detection for quantum neural networks.

This module extends the base anomaly detection with rules specific to
quantum machine learning, including measurement distribution analysis,
noise pattern detection, and circuit integrity checks.

Based on research from:
- QSentry (arXiv 2511.15376) - Measurement clustering for backdoor detection
- Entangled Threats (arXiv 2507.08623) - QML attack taxonomy
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import numpy as np

from ..platform.anomaly import (
    ActionContext,
    AnomalyDetector,
    AnomalyEvent,
    AnomalyRule,
    AnomalyType,
    Severity,
)


class QMLAnomalyType(Enum):
    """QML-specific anomaly types."""

    MEASUREMENT_DISTRIBUTION = "measurement_distribution"
    NOISE_PATTERN = "noise_pattern"
    CIRCUIT_DEPTH = "circuit_depth"
    ENTANGLEMENT_PATTERN = "entanglement_pattern"
    GATE_SEQUENCE = "gate_sequence"
    PARAMETER_DRIFT = "parameter_drift"


@dataclass
class MeasurementData:
    """Quantum measurement data for analysis."""

    measurements: np.ndarray  # Raw measurement outcomes (n_shots x n_qubits)
    probabilities: np.ndarray  # Probability distribution
    n_qubits: int
    n_shots: int
    circuit_id: str | None = None
    timestamp: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_counts(cls, counts: dict[str, int], n_qubits: int) -> MeasurementData:
        """Create from measurement counts dictionary.

        Args:
            counts: Dictionary mapping bitstrings to counts.
            n_qubits: Number of qubits.

        Returns:
            MeasurementData instance.
        """
        n_shots = sum(counts.values())
        n_states = 2**n_qubits

        # Create probability distribution
        probabilities = np.zeros(n_states)
        for bitstring, count in counts.items():
            idx = int(bitstring, 2)
            probabilities[idx] = count / n_shots

        # Create measurement array
        measurements = []
        for bitstring, count in counts.items():
            bits = [int(b) for b in bitstring]
            measurements.extend([bits] * count)

        return cls(
            measurements=np.array(measurements),
            probabilities=probabilities,
            n_qubits=n_qubits,
            n_shots=n_shots,
        )

    @property
    def entropy(self) -> float:
        """Calculate Shannon entropy of the distribution."""
        probs = self.probabilities[self.probabilities > 0]
        return float(-np.sum(probs * np.log2(probs)))

    @property
    def max_entropy(self) -> float:
        """Maximum possible entropy for this system."""
        return float(self.n_qubits)


@dataclass
class QMLActionContext(ActionContext):
    """Extended action context for QML operations."""

    measurement_data: MeasurementData | None = None
    circuit_depth: int | None = None
    gate_counts: dict[str, int] = field(default_factory=dict)
    parameter_values: np.ndarray | None = None


def calculate_kl_divergence(p: np.ndarray, q: np.ndarray, epsilon: float = 1e-10) -> float:
    """Calculate KL divergence D(p||q).

    Args:
        p: First probability distribution.
        q: Second probability distribution.
        epsilon: Small value to avoid log(0).

    Returns:
        KL divergence value.
    """
    p = np.clip(p, epsilon, 1)
    q = np.clip(q, epsilon, 1)
    return float(np.sum(p * np.log(p / q)))


def calculate_js_divergence(p: np.ndarray, q: np.ndarray) -> float:
    """Calculate Jensen-Shannon divergence.

    Args:
        p: First probability distribution.
        q: Second probability distribution.

    Returns:
        JS divergence value (0 to 1).
    """
    m = 0.5 * (p + q)
    return 0.5 * (calculate_kl_divergence(p, m) + calculate_kl_divergence(q, m))


class MeasurementDistributionRule(AnomalyRule):
    """Detect anomalies in quantum measurement distributions.

    Based on QSentry paper: unusual measurement distributions may indicate
    backdoor triggers or adversarial inputs.
    """

    def __init__(
        self,
        entropy_threshold: float = 0.1,
        js_divergence_threshold: float = 0.3,
        severity: Severity = Severity.HIGH,
    ) -> None:
        """Initialize rule.

        Args:
            entropy_threshold: Min entropy ratio (actual/max) for normal operation.
            js_divergence_threshold: Max JS divergence from baseline.
            severity: Severity level.
        """
        super().__init__("measurement_distribution", severity)
        self.entropy_threshold = entropy_threshold
        self.js_divergence_threshold = js_divergence_threshold
        self._baseline_distributions: dict[str, np.ndarray] = {}

    def set_baseline(self, circuit_id: str, distribution: np.ndarray) -> None:
        """Set baseline distribution for a circuit.

        Args:
            circuit_id: Circuit identifier.
            distribution: Baseline probability distribution.
        """
        self._baseline_distributions[circuit_id] = distribution

    def check(self, context: ActionContext, history: list[ActionContext]) -> AnomalyEvent | None:
        """Check measurement distribution for anomalies."""
        if not isinstance(context, QMLActionContext):
            return None

        if context.measurement_data is None:
            return None

        data = context.measurement_data
        anomalies = []

        # Check 1: Entropy too low (concentrated distribution)
        entropy_ratio = data.entropy / data.max_entropy if data.max_entropy > 0 else 0
        if entropy_ratio < self.entropy_threshold:
            anomalies.append(f"Low entropy ratio: {entropy_ratio:.3f}")

        # Check 2: Divergence from baseline
        if data.circuit_id and data.circuit_id in self._baseline_distributions:
            baseline = self._baseline_distributions[data.circuit_id]
            js_div = calculate_js_divergence(data.probabilities, baseline)
            if js_div > self.js_divergence_threshold:
                anomalies.append(f"High JS divergence from baseline: {js_div:.3f}")

        # Check 3: Unusual spikes (potential backdoor trigger)
        max_prob = np.max(data.probabilities)
        if max_prob > 0.9 and data.n_qubits > 2:  # >90% on one state is suspicious
            anomalies.append(f"Suspicious probability spike: {max_prob:.3f}")

        if anomalies:
            return AnomalyEvent(
                event_id=f"ano_{uuid.uuid4().hex[:16]}",
                anomaly_type=AnomalyType.SEQUENCE_ANOMALY,  # Use existing type
                severity=self.severity,
                agent_id=context.agent_id,
                session_id=context.session_id,
                description=f"Measurement distribution anomaly: {'; '.join(anomalies)}",
                metadata={
                    "entropy": data.entropy,
                    "entropy_ratio": entropy_ratio,
                    "max_probability": float(max_prob),
                    "n_qubits": data.n_qubits,
                    "anomaly_type": QMLAnomalyType.MEASUREMENT_DISTRIBUTION.value,
                },
            )

        return None


class CircuitDepthRule(AnomalyRule):
    """Detect suspicious circuit depth changes.

    Sudden increases in circuit depth may indicate injected malicious gates.
    """

    def __init__(
        self,
        max_depth_ratio: float = 2.0,
        absolute_max_depth: int = 1000,
        severity: Severity = Severity.MEDIUM,
    ) -> None:
        """Initialize rule.

        Args:
            max_depth_ratio: Max allowed ratio vs recent average depth.
            absolute_max_depth: Absolute maximum circuit depth.
            severity: Severity level.
        """
        super().__init__("circuit_depth", severity)
        self.max_depth_ratio = max_depth_ratio
        self.absolute_max_depth = absolute_max_depth

    def check(self, context: ActionContext, history: list[ActionContext]) -> AnomalyEvent | None:
        """Check circuit depth for anomalies."""
        if not isinstance(context, QMLActionContext):
            return None

        if context.circuit_depth is None:
            return None

        depth = context.circuit_depth
        anomalies = []

        # Check 1: Absolute depth limit
        if depth > self.absolute_max_depth:
            anomalies.append(f"Exceeds max depth: {depth} > {self.absolute_max_depth}")

        # Check 2: Relative to history
        qml_history = [h for h in history if isinstance(h, QMLActionContext) and h.circuit_depth]
        if len(qml_history) >= 3:
            avg_depth = sum(h.circuit_depth for h in qml_history[-10:] if h.circuit_depth) / min(
                len(qml_history), 10
            )
            if avg_depth > 0 and depth / avg_depth > self.max_depth_ratio:
                anomalies.append(
                    f"Depth spike: {depth} vs avg {avg_depth:.1f} (ratio: {depth/avg_depth:.2f})"
                )

        if anomalies:
            return AnomalyEvent(
                event_id=f"ano_{uuid.uuid4().hex[:16]}",
                anomaly_type=AnomalyType.SEQUENCE_ANOMALY,
                severity=self.severity,
                agent_id=context.agent_id,
                session_id=context.session_id,
                description=f"Circuit depth anomaly: {'; '.join(anomalies)}",
                metadata={
                    "depth": depth,
                    "anomaly_type": QMLAnomalyType.CIRCUIT_DEPTH.value,
                },
            )

        return None


class GateSequenceRule(AnomalyRule):
    """Detect suspicious gate sequences.

    Unusual gate patterns may indicate circuit tampering or backdoors.
    """

    def __init__(
        self,
        suspicious_patterns: list[list[str]] | None = None,
        max_single_gate_ratio: float = 0.8,
        severity: Severity = Severity.MEDIUM,
    ) -> None:
        """Initialize rule.

        Args:
            suspicious_patterns: List of suspicious gate sequences.
            max_single_gate_ratio: Max ratio of any single gate type.
            severity: Severity level.
        """
        super().__init__("gate_sequence", severity)
        self.suspicious_patterns = suspicious_patterns or [
            ["H", "H", "H", "H"],  # Suspicious repeated Hadamards
            ["X", "X", "X", "X"],  # Repeated X gates (often noop)
            ["CNOT", "CNOT"],  # Consecutive CNOTs on same qubits
        ]
        self.max_single_gate_ratio = max_single_gate_ratio

    def check(self, context: ActionContext, history: list[ActionContext]) -> AnomalyEvent | None:
        """Check gate sequence for anomalies."""
        if not isinstance(context, QMLActionContext):
            return None

        if not context.gate_counts:
            return None

        gate_counts = context.gate_counts
        total_gates = sum(gate_counts.values())

        if total_gates == 0:
            return None

        anomalies = []

        # Check for suspicious gate dominance
        for gate, count in gate_counts.items():
            ratio = count / total_gates
            if ratio > self.max_single_gate_ratio:
                anomalies.append(f"Gate '{gate}' dominance: {ratio:.1%}")

        # Check for identity-like patterns (X,X or H,H,H,H)
        if gate_counts.get("X", 0) % 2 == 0 and gate_counts.get("X", 0) > 4:
            anomalies.append("Many paired X gates (potential obfuscation)")

        if anomalies:
            return AnomalyEvent(
                event_id=f"ano_{uuid.uuid4().hex[:16]}",
                anomaly_type=AnomalyType.SEQUENCE_ANOMALY,
                severity=self.severity,
                agent_id=context.agent_id,
                session_id=context.session_id,
                description=f"Gate sequence anomaly: {'; '.join(anomalies)}",
                metadata={
                    "gate_counts": gate_counts,
                    "total_gates": total_gates,
                    "anomaly_type": QMLAnomalyType.GATE_SEQUENCE.value,
                },
            )

        return None


class ParameterDriftRule(AnomalyRule):
    """Detect suspicious parameter drift in variational circuits.

    Sudden parameter changes may indicate model tampering.
    """

    def __init__(
        self,
        max_drift_per_step: float = 0.5,
        max_total_drift: float = 2.0,
        severity: Severity = Severity.MEDIUM,
    ) -> None:
        """Initialize rule.

        Args:
            max_drift_per_step: Max L2 norm change per step.
            max_total_drift: Max cumulative drift.
            severity: Severity level.
        """
        super().__init__("parameter_drift", severity)
        self.max_drift_per_step = max_drift_per_step
        self.max_total_drift = max_total_drift
        self._initial_params: dict[str, np.ndarray] = {}

    def set_initial_params(self, agent_id: str, params: np.ndarray) -> None:
        """Set initial parameters for tracking drift.

        Args:
            agent_id: Agent identifier.
            params: Initial parameter values.
        """
        self._initial_params[agent_id] = params.copy()

    def check(self, context: ActionContext, history: list[ActionContext]) -> AnomalyEvent | None:
        """Check parameter drift for anomalies."""
        if not isinstance(context, QMLActionContext):
            return None

        if context.parameter_values is None:
            return None

        params = context.parameter_values
        anomalies = []

        # Check step-wise drift
        qml_history = [
            h for h in history if isinstance(h, QMLActionContext) and h.parameter_values is not None
        ]
        if qml_history:
            prev_params = qml_history[-1].parameter_values
            if prev_params is not None and prev_params.shape == params.shape:
                step_drift = float(np.linalg.norm(params - prev_params))
                if step_drift > self.max_drift_per_step:
                    anomalies.append(f"Large step drift: {step_drift:.3f}")

        # Check total drift from initial
        if context.agent_id in self._initial_params:
            initial = self._initial_params[context.agent_id]
            if initial.shape == params.shape:
                total_drift = float(np.linalg.norm(params - initial))
                if total_drift > self.max_total_drift:
                    anomalies.append(f"Large total drift: {total_drift:.3f}")

        if anomalies:
            return AnomalyEvent(
                event_id=f"ano_{uuid.uuid4().hex[:16]}",
                anomaly_type=AnomalyType.SEQUENCE_ANOMALY,
                severity=self.severity,
                agent_id=context.agent_id,
                session_id=context.session_id,
                description=f"Parameter drift anomaly: {'; '.join(anomalies)}",
                metadata={
                    "n_parameters": len(params),
                    "anomaly_type": QMLAnomalyType.PARAMETER_DRIFT.value,
                },
            )

        return None


class QMLAnomalyDetector(AnomalyDetector):
    """Extended anomaly detector with QML-specific rules."""

    def __init__(self) -> None:
        """Initialize QML detector."""
        super().__init__()
        self._measurement_history: dict[str, list[MeasurementData]] = {}

    def add_qml_rules(self) -> None:
        """Add default QML-specific rules."""
        self.add_rule(MeasurementDistributionRule())
        self.add_rule(CircuitDepthRule())
        self.add_rule(GateSequenceRule())
        self.add_rule(ParameterDriftRule())

    def check_measurement(
        self,
        agent_id: str,
        measurement_data: MeasurementData,
        session_id: str | None = None,
    ) -> list[AnomalyEvent]:
        """Check measurement data for anomalies.

        Args:
            agent_id: Agent identifier.
            measurement_data: Quantum measurement data.
            session_id: Optional session ID.

        Returns:
            List of anomaly events.
        """
        import time

        context = QMLActionContext(
            agent_id=agent_id,
            session_id=session_id,
            action_type="qml",
            action_name="measurement",
            timestamp=time.time(),
            capabilities=[],
            measurement_data=measurement_data,
        )

        return self.check_action(context)

    def check_circuit(
        self,
        agent_id: str,
        circuit_depth: int,
        gate_counts: dict[str, int],
        parameter_values: np.ndarray | None = None,
        session_id: str | None = None,
    ) -> list[AnomalyEvent]:
        """Check circuit properties for anomalies.

        Args:
            agent_id: Agent identifier.
            circuit_depth: Circuit depth.
            gate_counts: Dictionary of gate type to count.
            parameter_values: Optional parameter values.
            session_id: Optional session ID.

        Returns:
            List of anomaly events.
        """
        import time

        context = QMLActionContext(
            agent_id=agent_id,
            session_id=session_id,
            action_type="qml",
            action_name="circuit_execution",
            timestamp=time.time(),
            capabilities=[],
            circuit_depth=circuit_depth,
            gate_counts=gate_counts,
            parameter_values=parameter_values,
        )

        return self.check_action(context)


def create_qml_detector() -> QMLAnomalyDetector:
    """Create detector with QML-specific rules.

    Returns:
        Configured QMLAnomalyDetector.
    """
    detector = QMLAnomalyDetector()
    detector.add_qml_rules()
    return detector
