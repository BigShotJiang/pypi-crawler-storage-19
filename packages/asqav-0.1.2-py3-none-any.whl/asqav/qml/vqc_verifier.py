"""VQC Robustness Scanner - Formal verification for variational quantum circuits.

This module implements abstract interpretation and interval arithmetic
for verifying robustness properties of variational quantum circuits (VQCs).

Based on research from:
- arXiv 2507.10635 - Formal Verification of Variational Quantum Circuits

Key concepts:
- Quantum interval arithmetic: Bounds on quantum state amplitudes
- Abstract interpretation: Over-approximate circuit behavior
- Robustness certification: Prove outputs stay bounded under input perturbations
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import numpy as np


class GateType(Enum):
    """Supported quantum gate types."""

    # Single-qubit gates
    X = "x"
    Y = "y"
    Z = "z"
    H = "h"
    S = "s"
    T = "t"
    RX = "rx"
    RY = "ry"
    RZ = "rz"

    # Two-qubit gates
    CNOT = "cnot"
    CZ = "cz"

    # Parameterized
    U = "u"  # General single-qubit


@dataclass
class QuantumGate:
    """Representation of a quantum gate in a circuit."""

    gate_type: GateType
    qubits: list[int]
    parameters: list[float] = field(default_factory=list)
    is_parameterized: bool = False

    @property
    def n_qubits(self) -> int:
        """Number of qubits this gate acts on."""
        return len(self.qubits)


@dataclass
class QuantumCircuit:
    """Simple representation of a quantum circuit."""

    n_qubits: int
    gates: list[QuantumGate] = field(default_factory=list)
    name: str = ""

    def add_gate(self, gate: QuantumGate) -> None:
        """Add a gate to the circuit."""
        if any(q >= self.n_qubits or q < 0 for q in gate.qubits):
            raise ValueError(f"Gate qubits {gate.qubits} out of range for {self.n_qubits} qubits")
        self.gates.append(gate)

    def depth(self) -> int:
        """Calculate circuit depth (simplified: count of gates)."""
        return len(self.gates)

    @property
    def parameters(self) -> list[float]:
        """Extract all parameters from parameterized gates."""
        params = []
        for gate in self.gates:
            if gate.is_parameterized:
                params.extend(gate.parameters)
        return params

    @parameters.setter
    def parameters(self, values: list[float]) -> None:
        """Set parameters for parameterized gates."""
        idx = 0
        for gate in self.gates:
            if gate.is_parameterized:
                n_params = len(gate.parameters)
                gate.parameters = list(values[idx : idx + n_params])
                idx += n_params


@dataclass
class QuantumInterval:
    """Interval representation of quantum state amplitudes.

    For a state vector, we track bounds [lower, upper] for both
    real and imaginary parts of each amplitude.
    """

    real_lower: np.ndarray  # Lower bounds on real parts
    real_upper: np.ndarray  # Upper bounds on real parts
    imag_lower: np.ndarray  # Lower bounds on imaginary parts
    imag_upper: np.ndarray  # Upper bounds on imaginary parts

    @classmethod
    def from_state(cls, state: np.ndarray, epsilon: float = 0.0) -> QuantumInterval:
        """Create interval from a concrete state with optional perturbation.

        Args:
            state: Complex state vector.
            epsilon: Perturbation bound (L-infinity).

        Returns:
            QuantumInterval with bounds around the state.
        """
        real_parts = np.real(state)
        imag_parts = np.imag(state)

        return cls(
            real_lower=real_parts - epsilon,
            real_upper=real_parts + epsilon,
            imag_lower=imag_parts - epsilon,
            imag_upper=imag_parts + epsilon,
        )

    @classmethod
    def zeros(cls, dim: int) -> QuantumInterval:
        """Create zero interval (|0...0> state)."""
        real_lower = np.zeros(dim)
        real_upper = np.zeros(dim)
        imag_lower = np.zeros(dim)
        imag_upper = np.zeros(dim)

        # |0> state has amplitude 1 at index 0
        real_lower[0] = 1.0
        real_upper[0] = 1.0

        return cls(
            real_lower=real_lower,
            real_upper=real_upper,
            imag_lower=imag_lower,
            imag_upper=imag_upper,
        )

    @property
    def dim(self) -> int:
        """Dimension of the state space."""
        return len(self.real_lower)

    @property
    def n_qubits(self) -> int:
        """Number of qubits."""
        return int(np.log2(self.dim))

    def width(self) -> float:
        """Maximum interval width across all amplitudes."""
        real_width = np.max(self.real_upper - self.real_lower)
        imag_width = np.max(self.imag_upper - self.imag_lower)
        return float(max(real_width, imag_width))

    def center(self) -> np.ndarray:
        """Center point of the interval (midpoint state)."""
        real_center = (self.real_lower + self.real_upper) / 2
        imag_center = (self.imag_lower + self.imag_upper) / 2
        return np.asarray(real_center + 1j * imag_center)

    def contains(self, state: np.ndarray) -> bool:
        """Check if a concrete state is within this interval."""
        real_parts = np.real(state)
        imag_parts = np.imag(state)

        real_in = np.all(real_parts >= self.real_lower - 1e-10) and np.all(
            real_parts <= self.real_upper + 1e-10
        )
        imag_in = np.all(imag_parts >= self.imag_lower - 1e-10) and np.all(
            imag_parts <= self.imag_upper + 1e-10
        )

        return bool(real_in and imag_in)


class IntervalArithmetic:
    """Interval arithmetic operations for quantum gates.

    Implements sound over-approximations of gate operations
    on interval-valued quantum states.
    """

    @staticmethod
    def multiply_intervals(
        a_lower: float,
        a_upper: float,
        b_lower: float,
        b_upper: float,
    ) -> tuple[float, float]:
        """Multiply two intervals [a_lower, a_upper] * [b_lower, b_upper]."""
        products = [
            a_lower * b_lower,
            a_lower * b_upper,
            a_upper * b_lower,
            a_upper * b_upper,
        ]
        return min(products), max(products)

    @staticmethod
    def add_intervals(
        a_lower: float,
        a_upper: float,
        b_lower: float,
        b_upper: float,
    ) -> tuple[float, float]:
        """Add two intervals."""
        return a_lower + b_lower, a_upper + b_upper

    @staticmethod
    def complex_multiply(
        r1_l: float,
        r1_u: float,
        i1_l: float,
        i1_u: float,
        r2_l: float,
        r2_u: float,
        i2_l: float,
        i2_u: float,
    ) -> tuple[float, float, float, float]:
        """Multiply two complex intervals.

        (a + bi)(c + di) = (ac - bd) + (ad + bc)i
        """
        # Real part: ac - bd
        ac_l, ac_u = IntervalArithmetic.multiply_intervals(r1_l, r1_u, r2_l, r2_u)
        bd_l, bd_u = IntervalArithmetic.multiply_intervals(i1_l, i1_u, i2_l, i2_u)
        real_lower = ac_l - bd_u
        real_upper = ac_u - bd_l

        # Imag part: ad + bc
        ad_l, ad_u = IntervalArithmetic.multiply_intervals(r1_l, r1_u, i2_l, i2_u)
        bc_l, bc_u = IntervalArithmetic.multiply_intervals(i1_l, i1_u, r2_l, r2_u)
        imag_lower = ad_l + bc_l
        imag_upper = ad_u + bc_u

        return real_lower, real_upper, imag_lower, imag_upper


class AbstractGateExecutor:
    """Execute quantum gates on interval states (abstract interpretation)."""

    def __init__(self) -> None:
        """Initialize the executor."""
        self._gate_matrices: dict[GateType, np.ndarray] = self._init_gate_matrices()

    def _init_gate_matrices(self) -> dict[GateType, np.ndarray]:
        """Initialize standard gate matrices."""
        sqrt2 = 1 / np.sqrt(2)

        return {
            GateType.X: np.array([[0, 1], [1, 0]], dtype=complex),
            GateType.Y: np.array([[0, -1j], [1j, 0]], dtype=complex),
            GateType.Z: np.array([[1, 0], [0, -1]], dtype=complex),
            GateType.H: np.array([[sqrt2, sqrt2], [sqrt2, -sqrt2]], dtype=complex),
            GateType.S: np.array([[1, 0], [0, 1j]], dtype=complex),
            GateType.T: np.array([[1, 0], [0, np.exp(1j * np.pi / 4)]], dtype=complex),
        }

    def rx_matrix(self, theta: float) -> np.ndarray:
        """RX gate matrix."""
        c = np.cos(theta / 2)
        s = np.sin(theta / 2)
        return np.array([[c, -1j * s], [-1j * s, c]], dtype=complex)

    def ry_matrix(self, theta: float) -> np.ndarray:
        """RY gate matrix."""
        c = np.cos(theta / 2)
        s = np.sin(theta / 2)
        return np.array([[c, -s], [s, c]], dtype=complex)

    def rz_matrix(self, theta: float) -> np.ndarray:
        """RZ gate matrix."""
        return np.array(
            [[np.exp(-1j * theta / 2), 0], [0, np.exp(1j * theta / 2)]],
            dtype=complex,
        )

    def cnot_matrix(self) -> np.ndarray:
        """CNOT gate matrix (control on first qubit)."""
        return np.array(
            [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]],
            dtype=complex,
        )

    def apply_single_qubit_gate(
        self,
        interval: QuantumInterval,
        gate_matrix: np.ndarray,
        qubit: int,
    ) -> QuantumInterval:
        """Apply single-qubit gate to interval state.

        Uses tensor product structure to apply gate to specific qubit.
        """
        n_qubits = interval.n_qubits

        # Build full unitary via tensor products
        # Gate on qubit k: I_0 x ... x I_{k-1} x G x I_{k+1} x ... x I_{n-1}
        full_matrix = np.eye(1, dtype=complex)
        for q in range(n_qubits):
            if q == qubit:
                full_matrix = np.kron(full_matrix, gate_matrix)
            else:
                full_matrix = np.kron(full_matrix, np.eye(2, dtype=complex))

        # Apply matrix to interval (over-approximation)
        return self._apply_matrix_to_interval(interval, full_matrix)

    def apply_two_qubit_gate(
        self,
        interval: QuantumInterval,
        gate_matrix: np.ndarray,
        qubits: list[int],
    ) -> QuantumInterval:
        """Apply two-qubit gate to interval state."""
        n_qubits = interval.n_qubits

        # Build permutation to bring target qubits to positions 0, 1
        # Then apply gate, then permute back
        # For simplicity, we use the direct approach for adjacent qubits

        if qubits[1] - qubits[0] == 1:
            # Adjacent qubits - direct tensor product
            full_matrix = np.eye(1, dtype=complex)
            q = 0
            while q < n_qubits:
                if q == qubits[0]:
                    full_matrix = np.kron(full_matrix, gate_matrix)
                    q += 2
                else:
                    full_matrix = np.kron(full_matrix, np.eye(2, dtype=complex))
                    q += 1
        else:
            # Non-adjacent - use swap gates (simplified: direct computation)
            full_matrix = self._build_two_qubit_matrix(n_qubits, gate_matrix, qubits)

        return self._apply_matrix_to_interval(interval, full_matrix)

    def _build_two_qubit_matrix(
        self,
        n_qubits: int,
        gate_matrix: np.ndarray,
        qubits: list[int],
    ) -> np.ndarray:
        """Build full matrix for two-qubit gate on arbitrary qubits."""
        dim = 2**n_qubits
        full_matrix = np.zeros((dim, dim), dtype=complex)

        for i in range(dim):
            for j in range(dim):
                # Extract bits for target qubits
                i_bits = [(i >> (n_qubits - 1 - q)) & 1 for q in range(n_qubits)]
                j_bits = [(j >> (n_qubits - 1 - q)) & 1 for q in range(n_qubits)]

                # Check if non-target bits match
                non_target_match = all(
                    i_bits[q] == j_bits[q] for q in range(n_qubits) if q not in qubits
                )

                if non_target_match:
                    # Get gate matrix element
                    i_gate = i_bits[qubits[0]] * 2 + i_bits[qubits[1]]
                    j_gate = j_bits[qubits[0]] * 2 + j_bits[qubits[1]]
                    full_matrix[i, j] = gate_matrix[i_gate, j_gate]

        return full_matrix

    def _apply_matrix_to_interval(
        self,
        interval: QuantumInterval,
        matrix: np.ndarray,
    ) -> QuantumInterval:
        """Apply unitary matrix to interval state (over-approximation).

        For each output amplitude, compute interval bounds from
        the linear combination of input intervals.
        """
        dim = interval.dim
        new_real_lower = np.zeros(dim)
        new_real_upper = np.zeros(dim)
        new_imag_lower = np.zeros(dim)
        new_imag_upper = np.zeros(dim)

        for i in range(dim):
            # Output amplitude i is sum over j of matrix[i,j] * input[j]
            real_sum_lower = 0.0
            real_sum_upper = 0.0
            imag_sum_lower = 0.0
            imag_sum_upper = 0.0

            for j in range(dim):
                m_real = np.real(matrix[i, j])
                m_imag = np.imag(matrix[i, j])

                # Interval for input[j]
                in_r_l = interval.real_lower[j]
                in_r_u = interval.real_upper[j]
                in_i_l = interval.imag_lower[j]
                in_i_u = interval.imag_upper[j]

                # Complex multiply: (m_real + m_imag*i) * (in_r + in_i*i)
                # Real part: m_real * in_r - m_imag * in_i
                # Imag part: m_real * in_i + m_imag * in_r

                # m_real * in_r
                if m_real >= 0:
                    mr_inr_l = m_real * in_r_l
                    mr_inr_u = m_real * in_r_u
                else:
                    mr_inr_l = m_real * in_r_u
                    mr_inr_u = m_real * in_r_l

                # m_imag * in_i
                if m_imag >= 0:
                    mi_ini_l = m_imag * in_i_l
                    mi_ini_u = m_imag * in_i_u
                else:
                    mi_ini_l = m_imag * in_i_u
                    mi_ini_u = m_imag * in_i_l

                # m_real * in_i
                if m_real >= 0:
                    mr_ini_l = m_real * in_i_l
                    mr_ini_u = m_real * in_i_u
                else:
                    mr_ini_l = m_real * in_i_u
                    mr_ini_u = m_real * in_i_l

                # m_imag * in_r
                if m_imag >= 0:
                    mi_inr_l = m_imag * in_r_l
                    mi_inr_u = m_imag * in_r_u
                else:
                    mi_inr_l = m_imag * in_r_u
                    mi_inr_u = m_imag * in_r_l

                # Accumulate real part (m_real * in_r - m_imag * in_i)
                real_sum_lower += mr_inr_l - mi_ini_u
                real_sum_upper += mr_inr_u - mi_ini_l

                # Accumulate imag part (m_real * in_i + m_imag * in_r)
                imag_sum_lower += mr_ini_l + mi_inr_l
                imag_sum_upper += mr_ini_u + mi_inr_u

            new_real_lower[i] = real_sum_lower
            new_real_upper[i] = real_sum_upper
            new_imag_lower[i] = imag_sum_lower
            new_imag_upper[i] = imag_sum_upper

        return QuantumInterval(
            real_lower=new_real_lower,
            real_upper=new_real_upper,
            imag_lower=new_imag_lower,
            imag_upper=new_imag_upper,
        )

    def execute_gate(self, interval: QuantumInterval, gate: QuantumGate) -> QuantumInterval:
        """Execute a single gate on an interval state."""
        if gate.gate_type in self._gate_matrices:
            matrix = self._gate_matrices[gate.gate_type]
            return self.apply_single_qubit_gate(interval, matrix, gate.qubits[0])

        elif gate.gate_type == GateType.RX:
            matrix = self.rx_matrix(gate.parameters[0])
            return self.apply_single_qubit_gate(interval, matrix, gate.qubits[0])

        elif gate.gate_type == GateType.RY:
            matrix = self.ry_matrix(gate.parameters[0])
            return self.apply_single_qubit_gate(interval, matrix, gate.qubits[0])

        elif gate.gate_type == GateType.RZ:
            matrix = self.rz_matrix(gate.parameters[0])
            return self.apply_single_qubit_gate(interval, matrix, gate.qubits[0])

        elif gate.gate_type == GateType.CNOT:
            matrix = self.cnot_matrix()
            return self.apply_two_qubit_gate(interval, matrix, gate.qubits)

        elif gate.gate_type == GateType.CZ:
            matrix = np.diag([1, 1, 1, -1]).astype(complex)
            return self.apply_two_qubit_gate(interval, matrix, gate.qubits)

        else:
            raise ValueError(f"Unsupported gate type: {gate.gate_type}")


class RobustnessStatus(Enum):
    """Result of robustness certification."""

    CERTIFIED = "certified"  # Proven robust
    UNKNOWN = "unknown"  # Could not prove (may or may not be robust)
    VIOLATED = "violated"  # Found counterexample


@dataclass
class RobustnessCertificate:
    """Certificate of robustness verification."""

    certificate_id: str
    status: RobustnessStatus
    epsilon: float  # Perturbation bound
    confidence: float  # Confidence in the result (1.0 for certified)
    output_bounds: dict[str, tuple[float, float]]  # Bounds on output probabilities
    description: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class VerificationReport:
    """Full verification report for a VQC."""

    report_id: str
    circuit_name: str
    n_qubits: int
    circuit_depth: int
    certificates: list[RobustnessCertificate]
    overall_status: RobustnessStatus
    max_certified_epsilon: float
    description: str
    metadata: dict[str, Any] = field(default_factory=dict)


class VQCVerifier:
    """Formal verification for variational quantum circuits.

    Provides robustness certification through abstract interpretation,
    proving that small input perturbations don't cause large output changes.
    """

    def __init__(self) -> None:
        """Initialize the verifier."""
        self.executor = AbstractGateExecutor()

    def execute_circuit(self, circuit: QuantumCircuit, interval: QuantumInterval) -> QuantumInterval:
        """Execute circuit on an interval state.

        Args:
            circuit: The quantum circuit to execute.
            interval: Input state as interval.

        Returns:
            Output interval after circuit execution.
        """
        current = interval
        for gate in circuit.gates:
            current = self.executor.execute_gate(current, gate)
        return current

    def compute_output_probabilities(
        self,
        interval: QuantumInterval,
    ) -> dict[str, tuple[float, float]]:
        """Compute bounds on measurement probabilities.

        Args:
            interval: Output interval state.

        Returns:
            Dictionary mapping basis state to (lower, upper) probability bounds.
        """
        n_qubits = interval.n_qubits
        prob_bounds = {}

        for i in range(interval.dim):
            # Probability = |amplitude|^2 = real^2 + imag^2
            r_l, r_u = interval.real_lower[i], interval.real_upper[i]
            i_l, i_u = interval.imag_lower[i], interval.imag_upper[i]

            # Lower bound on |amplitude|^2
            # If interval contains 0, lower bound is 0
            r_sq_lower = 0.0 if r_l <= 0 <= r_u else min(r_l**2, r_u**2)
            i_sq_lower = 0.0 if i_l <= 0 <= i_u else min(i_l**2, i_u**2)

            prob_lower = r_sq_lower + i_sq_lower

            # Upper bound
            r_sq_upper = max(r_l**2, r_u**2)
            i_sq_upper = max(i_l**2, i_u**2)
            prob_upper = r_sq_upper + i_sq_upper

            basis_state = format(i, f"0{n_qubits}b")
            prob_bounds[basis_state] = (max(0.0, prob_lower), min(1.0, prob_upper))

        return prob_bounds

    def certify_robustness(
        self,
        circuit: QuantumCircuit,
        input_state: np.ndarray | None = None,
        epsilon: float = 0.01,
        target_class: int | None = None,
    ) -> RobustnessCertificate:
        """Certify robustness of circuit against epsilon-bounded perturbations.

        Args:
            circuit: The VQC to verify.
            input_state: Input state (default: |0...0>).
            epsilon: Maximum input perturbation (L-infinity norm).
            target_class: Expected output class (basis state index).

        Returns:
            RobustnessCertificate with verification result.
        """
        # Create input interval
        if input_state is None:
            dim = 2**circuit.n_qubits
            input_interval = QuantumInterval.zeros(dim)
            # Add perturbation
            input_interval.real_lower -= epsilon
            input_interval.real_upper += epsilon
            input_interval.imag_lower -= epsilon
            input_interval.imag_upper += epsilon
        else:
            input_interval = QuantumInterval.from_state(input_state, epsilon)

        # Execute circuit on interval
        output_interval = self.execute_circuit(circuit, input_interval)

        # Compute output probability bounds
        prob_bounds = self.compute_output_probabilities(output_interval)

        # Determine status
        if target_class is not None:
            target_state = format(target_class, f"0{circuit.n_qubits}b")
            target_lower, target_upper = prob_bounds[target_state]

            # Check if target class is always the most likely
            certified = True
            for state, (_p_lower, p_upper) in prob_bounds.items():
                if state != target_state:
                    # If other class could have higher probability, not certified
                    if p_upper >= target_lower:
                        certified = False
                        break

            status = RobustnessStatus.CERTIFIED if certified else RobustnessStatus.UNKNOWN
            confidence = 1.0 if certified else 0.5
            description = (
                f"Target class {target_state} certified robust for epsilon={epsilon}"
                if certified
                else f"Could not certify target class {target_state} for epsilon={epsilon}"
            )
        else:
            # No target class - just report bounds
            status = RobustnessStatus.UNKNOWN
            confidence = 0.5
            width = output_interval.width()
            description = f"Output interval width: {width:.6f}"

        return RobustnessCertificate(
            certificate_id=f"cert_{uuid.uuid4().hex[:16]}",
            status=status,
            epsilon=epsilon,
            confidence=confidence,
            output_bounds=prob_bounds,
            description=description,
            metadata={
                "input_width": epsilon * 2,
                "output_width": output_interval.width(),
                "n_qubits": circuit.n_qubits,
                "circuit_depth": circuit.depth(),
            },
        )

    def find_max_certified_epsilon(
        self,
        circuit: QuantumCircuit,
        target_class: int,
        input_state: np.ndarray | None = None,
        max_epsilon: float = 0.5,
        tolerance: float = 0.001,
    ) -> float:
        """Find maximum epsilon for which circuit is certified robust.

        Uses binary search to find the largest perturbation bound
        that still allows certification.

        Args:
            circuit: The VQC to verify.
            target_class: Expected output class.
            input_state: Input state (default: |0...0>).
            max_epsilon: Maximum epsilon to search.
            tolerance: Precision of the search.

        Returns:
            Maximum certified epsilon value.
        """
        low, high = 0.0, max_epsilon

        while high - low > tolerance:
            mid = (low + high) / 2
            cert = self.certify_robustness(circuit, input_state, mid, target_class)

            if cert.status == RobustnessStatus.CERTIFIED:
                low = mid
            else:
                high = mid

        return low

    def verify_circuit(
        self,
        circuit: QuantumCircuit,
        epsilons: list[float] | None = None,
        target_class: int | None = None,
        input_state: np.ndarray | None = None,
    ) -> VerificationReport:
        """Run full verification on a circuit.

        Args:
            circuit: The VQC to verify.
            epsilons: List of epsilon values to test.
            target_class: Expected output class.
            input_state: Input state.

        Returns:
            VerificationReport with all certificates.
        """
        if epsilons is None:
            epsilons = [0.001, 0.005, 0.01, 0.02, 0.05, 0.1]

        certificates = []
        max_certified = 0.0

        for eps in sorted(epsilons):
            cert = self.certify_robustness(circuit, input_state, eps, target_class)
            certificates.append(cert)
            if cert.status == RobustnessStatus.CERTIFIED:
                max_certified = eps

        # Determine overall status
        if max_certified > 0:
            overall_status = RobustnessStatus.CERTIFIED
            description = f"Circuit certified robust up to epsilon={max_certified}"
        else:
            overall_status = RobustnessStatus.UNKNOWN
            description = "Could not certify robustness for any tested epsilon"

        return VerificationReport(
            report_id=f"vqc_{uuid.uuid4().hex[:16]}",
            circuit_name=circuit.name or "unnamed",
            n_qubits=circuit.n_qubits,
            circuit_depth=circuit.depth(),
            certificates=certificates,
            overall_status=overall_status,
            max_certified_epsilon=max_certified,
            description=description,
            metadata={
                "epsilons_tested": epsilons,
                "target_class": target_class,
            },
        )


def create_simple_vqc(n_qubits: int, n_layers: int = 1) -> QuantumCircuit:
    """Create a simple variational quantum circuit.

    Args:
        n_qubits: Number of qubits.
        n_layers: Number of variational layers.

    Returns:
        A QuantumCircuit with parameterized gates.
    """
    circuit = QuantumCircuit(n_qubits=n_qubits, name=f"VQC_{n_qubits}q_{n_layers}l")

    for layer in range(n_layers):
        # Rotation layer
        for q in range(n_qubits):
            circuit.add_gate(
                QuantumGate(
                    gate_type=GateType.RY,
                    qubits=[q],
                    parameters=[0.1 * (layer + 1) * (q + 1)],
                    is_parameterized=True,
                )
            )
            circuit.add_gate(
                QuantumGate(
                    gate_type=GateType.RZ,
                    qubits=[q],
                    parameters=[0.2 * (layer + 1) * (q + 1)],
                    is_parameterized=True,
                )
            )

        # Entangling layer
        for q in range(n_qubits - 1):
            circuit.add_gate(
                QuantumGate(gate_type=GateType.CNOT, qubits=[q, q + 1])
            )

    return circuit


def verify_vqc_robustness(
    circuit: QuantumCircuit,
    target_class: int = 0,
    epsilons: list[float] | None = None,
) -> VerificationReport:
    """Convenience function to verify VQC robustness.

    Args:
        circuit: The circuit to verify.
        target_class: Expected output class.
        epsilons: Perturbation bounds to test.

    Returns:
        VerificationReport.
    """
    verifier = VQCVerifier()
    return verifier.verify_circuit(circuit, epsilons=epsilons, target_class=target_class)
