"""
Delegation chain tracking for AI agents.

This module provides functionality for tracking and validating delegation
chains between agents, ensuring proper authorization flow and scope
attenuation.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .agent import SecureAgent


@dataclass
class DelegationRecord:
    """A record of a delegation from one agent to another."""

    delegation_id: str
    delegator_id: str
    delegatee_id: str
    scope: list[str]
    granted_at: float
    expires_at: float | None = None
    revoked_at: float | None = None
    parent_delegation_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_active(self) -> bool:
        """Check if delegation is currently active."""
        if self.revoked_at is not None:
            return False
        return not (self.expires_at is not None and time.time() > self.expires_at)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "delegation_id": self.delegation_id,
            "delegator_id": self.delegator_id,
            "delegatee_id": self.delegatee_id,
            "scope": self.scope,
            "granted_at": self.granted_at,
            "expires_at": self.expires_at,
            "revoked_at": self.revoked_at,
            "parent_delegation_id": self.parent_delegation_id,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DelegationRecord:
        """Create from dictionary."""
        return cls(
            delegation_id=data["delegation_id"],
            delegator_id=data["delegator_id"],
            delegatee_id=data["delegatee_id"],
            scope=data["scope"],
            granted_at=data["granted_at"],
            expires_at=data.get("expires_at"),
            revoked_at=data.get("revoked_at"),
            parent_delegation_id=data.get("parent_delegation_id"),
            metadata=data.get("metadata", {}),
        )


class DelegationChain:
    """Manages delegation chains between agents."""

    def __init__(self) -> None:
        """Initialize delegation chain manager."""
        self._delegations: dict[str, DelegationRecord] = {}
        self._by_delegator: dict[str, list[str]] = {}
        self._by_delegatee: dict[str, list[str]] = {}

    def create_delegation(
        self,
        delegator: SecureAgent,
        delegatee: SecureAgent,
        scope: list[str] | None = None,
        ttl: int | None = None,
        parent_delegation_id: str | None = None,
    ) -> DelegationRecord:
        """Create a new delegation from one agent to another.

        Args:
            delegator: The agent granting the delegation.
            delegatee: The agent receiving the delegation.
            scope: Permissions to grant. Automatically attenuated to delegator's scope.
            ttl: Time-to-live in seconds.
            parent_delegation_id: ID of parent delegation in chain.

        Returns:
            The created DelegationRecord.
        """
        import uuid

        # Attenuate scope to intersection with delegator's capabilities
        if scope is not None:
            granted_scope = list(set(scope) & set(delegator.capabilities))
        else:
            granted_scope = list(delegator.capabilities)

        delegation_id = f"del_{uuid.uuid4().hex[:16]}"
        now = time.time()

        record = DelegationRecord(
            delegation_id=delegation_id,
            delegator_id=delegator.agent_id,
            delegatee_id=delegatee.agent_id,
            scope=granted_scope,
            granted_at=now,
            expires_at=now + ttl if ttl else None,
            parent_delegation_id=parent_delegation_id,
        )

        self._delegations[delegation_id] = record

        if delegator.agent_id not in self._by_delegator:
            self._by_delegator[delegator.agent_id] = []
        self._by_delegator[delegator.agent_id].append(delegation_id)

        if delegatee.agent_id not in self._by_delegatee:
            self._by_delegatee[delegatee.agent_id] = []
        self._by_delegatee[delegatee.agent_id].append(delegation_id)

        return record

    def revoke_delegation(self, delegation_id: str) -> bool:
        """Revoke a delegation.

        Args:
            delegation_id: ID of the delegation to revoke.

        Returns:
            True if revoked, False if not found.
        """
        if delegation_id not in self._delegations:
            return False

        self._delegations[delegation_id].revoked_at = time.time()
        return True

    def revoke_all_from_delegator(self, delegator_id: str) -> int:
        """Revoke all delegations from a specific delegator.

        Args:
            delegator_id: ID of the delegator.

        Returns:
            Number of delegations revoked.
        """
        count = 0
        for del_id in self._by_delegator.get(delegator_id, []):
            if self.revoke_delegation(del_id):
                count += 1
        return count

    def get_delegation(self, delegation_id: str) -> DelegationRecord | None:
        """Get a delegation by ID."""
        return self._delegations.get(delegation_id)

    def get_delegations_by_delegator(
        self, delegator_id: str, active_only: bool = True
    ) -> list[DelegationRecord]:
        """Get all delegations from a delegator.

        Args:
            delegator_id: ID of the delegator.
            active_only: Only return active delegations.

        Returns:
            List of DelegationRecords.
        """
        del_ids = self._by_delegator.get(delegator_id, [])
        records = [self._delegations[d] for d in del_ids]
        if active_only:
            records = [r for r in records if r.is_active]
        return records

    def get_delegations_by_delegatee(
        self, delegatee_id: str, active_only: bool = True
    ) -> list[DelegationRecord]:
        """Get all delegations to a delegatee.

        Args:
            delegatee_id: ID of the delegatee.
            active_only: Only return active delegations.

        Returns:
            List of DelegationRecords.
        """
        del_ids = self._by_delegatee.get(delegatee_id, [])
        records = [self._delegations[d] for d in del_ids]
        if active_only:
            records = [r for r in records if r.is_active]
        return records

    def get_chain(self, delegation_id: str) -> list[DelegationRecord]:
        """Get the full delegation chain leading to a delegation.

        Args:
            delegation_id: ID of the delegation.

        Returns:
            List of DelegationRecords from root to the specified delegation.
        """
        chain: list[DelegationRecord] = []
        current_id: str | None = delegation_id

        while current_id is not None:
            record = self._delegations.get(current_id)
            if record is None:
                break
            chain.insert(0, record)
            current_id = record.parent_delegation_id

        return chain

    def validate_chain(self, delegation_id: str) -> tuple[bool, str | None]:
        """Validate a delegation chain.

        Args:
            delegation_id: ID of the delegation to validate.

        Returns:
            Tuple of (is_valid, error_message).
        """
        chain = self.get_chain(delegation_id)

        if not chain:
            return False, "Delegation not found"

        # Check each link in the chain
        for i, record in enumerate(chain):
            if not record.is_active:
                return False, f"Delegation {record.delegation_id} is not active"

            # Check scope attenuation (each delegation must be subset of parent)
            if i > 0:
                parent_scope = set(chain[i - 1].scope)
                current_scope = set(record.scope)
                if not current_scope.issubset(parent_scope):
                    return False, (
                        f"Scope violation: {record.delegation_id} exceeds "
                        f"parent scope"
                    )

        return True, None

    def get_effective_scope(self, agent_id: str) -> set[str]:
        """Get the effective scope for an agent from all delegations.

        Args:
            agent_id: ID of the agent.

        Returns:
            Set of all capabilities the agent has through delegations.
        """
        scope: set[str] = set()
        for record in self.get_delegations_by_delegatee(agent_id, active_only=True):
            scope.update(record.scope)
        return scope


def _scope_matches(parent_scope: str, requested_scope: str) -> bool:
    """Check if a parent scope covers a requested scope.

    Supports wildcard matching:
    - "file:*" covers "file:read", "file:write", etc.
    - "*" covers everything
    - Exact matches always work
    """
    if parent_scope == "*":
        return True
    if parent_scope == requested_scope:
        return True
    # Wildcard matching: "file:*" covers "file:read"
    if parent_scope.endswith(":*"):
        prefix = parent_scope[:-1]  # "file:" from "file:*"
        if requested_scope.startswith(prefix):
            return True
    return False


def attenuate_scope(
    parent_scope: list[str],
    requested_scope: list[str] | None,
) -> list[str]:
    """Calculate attenuated scope for delegation.

    Automatically restricts the requested scope to only include capabilities
    that the parent actually has. This ensures delegated agents cannot
    exceed their delegator's permissions.

    Supports wildcard matching:
    - If parent has "file:*", requesting "file:read" will be granted
    - If parent has "*", any scope will be granted

    Args:
        parent_scope: The delegator's capabilities.
        requested_scope: Requested scope for delegation (None for all).

    Returns:
        The attenuated scope list (intersection of parent and requested).
    """
    if requested_scope is None:
        return list(parent_scope)

    # Check each requested scope against parent scopes with wildcard matching
    attenuated = []
    for req in requested_scope:
        for parent in parent_scope:
            if _scope_matches(parent, req):
                attenuated.append(req)
                break

    return attenuated
