"""
PQC-JWT: Quantum-safe JWT-like tokens using ML-DSA signatures.

This module implements a JWT-compatible token format that uses ML-DSA
(FIPS 204) for digital signatures instead of vulnerable ECDSA/RSA.
"""

from __future__ import annotations

import base64
import json
import time
from dataclasses import dataclass, field
from typing import Any

from .identity import IdentityProvider, KeyPair, MLDSALevel, Signature, parse_algorithm


def _b64_encode(data: bytes) -> str:
    """URL-safe base64 encode without padding."""
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64_decode(data: str) -> bytes:
    """URL-safe base64 decode with automatic padding."""
    padding = 4 - (len(data) % 4)
    if padding != 4:
        data += "=" * padding
    return base64.urlsafe_b64decode(data)


@dataclass
class TokenHeader:
    """PQC-JWT header."""

    alg: str  # ML-DSA algorithm (e.g., "ML-DSA-65")
    typ: str = "PQC-JWT"
    kid: str | None = None  # Key ID

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result: dict[str, Any] = {"alg": self.alg, "typ": self.typ}
        if self.kid:
            result["kid"] = self.kid
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TokenHeader:
        """Create from dictionary."""
        return cls(
            alg=data["alg"],
            typ=data.get("typ", "PQC-JWT"),
            kid=data.get("kid"),
        )


@dataclass
class TokenClaims:
    """PQC-JWT claims (payload)."""

    sub: str  # Subject (agent ID)
    iss: str  # Issuer
    iat: int = field(default_factory=lambda: int(time.time()))  # Issued at
    exp: int | None = None  # Expiration
    nbf: int | None = None  # Not before
    jti: str | None = None  # Token ID
    aud: str | list[str] | None = None  # Audience
    scope: list[str] = field(default_factory=list)  # Capabilities/permissions
    delegator: str | None = None  # Parent agent ID (for delegation chains)
    custom: dict[str, Any] = field(default_factory=dict)  # Custom claims

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result: dict[str, Any] = {
            "sub": self.sub,
            "iss": self.iss,
            "iat": self.iat,
        }
        if self.exp is not None:
            result["exp"] = self.exp
        if self.nbf is not None:
            result["nbf"] = self.nbf
        if self.jti:
            result["jti"] = self.jti
        if self.aud:
            result["aud"] = self.aud
        if self.scope:
            result["scope"] = self.scope
        if self.delegator:
            result["delegator"] = self.delegator
        if self.custom:
            result.update(self.custom)
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TokenClaims:
        """Create from dictionary."""
        known_keys = {
            "sub", "iss", "iat", "exp", "nbf", "jti", "aud", "scope", "delegator"
        }
        custom = {k: v for k, v in data.items() if k not in known_keys}

        return cls(
            sub=data["sub"],
            iss=data["iss"],
            iat=data.get("iat", int(time.time())),
            exp=data.get("exp"),
            nbf=data.get("nbf"),
            jti=data.get("jti"),
            aud=data.get("aud"),
            scope=data.get("scope", []),
            delegator=data.get("delegator"),
            custom=custom,
        )

    def is_expired(self) -> bool:
        """Check if token is expired."""
        if self.exp is None:
            return False
        return time.time() > self.exp

    def is_active(self) -> bool:
        """Check if token is currently valid (not before, not expired)."""
        now = time.time()
        if self.exp is not None and now > self.exp:
            return False
        return not (self.nbf is not None and now < self.nbf)


@dataclass
class PQCToken:
    """A complete PQC-JWT token."""

    header: TokenHeader
    claims: TokenClaims
    signature: bytes

    def encode(self) -> str:
        """Encode the token as a string (header.payload.signature)."""
        header_b64 = _b64_encode(json.dumps(self.header.to_dict()).encode())
        payload_b64 = _b64_encode(json.dumps(self.claims.to_dict()).encode())
        sig_b64 = _b64_encode(self.signature)
        return f"{header_b64}.{payload_b64}.{sig_b64}"

    @classmethod
    def decode(cls, token: str) -> PQCToken:
        """Decode a token string (does not verify signature)."""
        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError("Invalid token format: expected 3 parts")

        header_data = json.loads(_b64_decode(parts[0]))
        claims_data = json.loads(_b64_decode(parts[1]))
        signature = _b64_decode(parts[2])

        return cls(
            header=TokenHeader.from_dict(header_data),
            claims=TokenClaims.from_dict(claims_data),
            signature=signature,
        )


class TokenIssuer:
    """Issues and verifies PQC-JWT tokens using ML-DSA signatures."""

    def __init__(
        self,
        keypair: KeyPair,
        issuer: str = "asqav",
        default_ttl: int = 3600,
    ) -> None:
        """Initialize the token issuer.

        Args:
            keypair: The ML-DSA key pair for signing tokens.
            issuer: The issuer identifier (iss claim).
            default_ttl: Default token time-to-live in seconds.
        """
        self.keypair = keypair
        self.issuer = issuer
        self.default_ttl = default_ttl
        self._identity = IdentityProvider(keypair.algorithm)

    def issue(
        self,
        subject: str,
        scope: list[str] | None = None,
        ttl: int | None = None,
        delegator: str | None = None,
        audience: str | list[str] | None = None,
        custom_claims: dict[str, Any] | None = None,
    ) -> PQCToken:
        """Issue a new token.

        Args:
            subject: The subject (agent ID) for the token.
            scope: List of capabilities/permissions.
            ttl: Time-to-live in seconds (None for no expiration).
            delegator: Parent agent ID if this is a delegated token.
            audience: Intended audience(s) for the token.
            custom_claims: Additional custom claims.

        Returns:
            A signed PQCToken.
        """
        now = int(time.time())

        header = TokenHeader(
            alg=self.keypair.algorithm.value,
            kid=self.keypair.key_id,
        )

        exp = now + (ttl if ttl is not None else self.default_ttl) if ttl != 0 else None

        claims = TokenClaims(
            sub=subject,
            iss=self.issuer,
            iat=now,
            exp=exp,
            scope=scope or [],
            delegator=delegator,
            aud=audience,
            custom=custom_claims or {},
        )

        # Create signing input
        header_b64 = _b64_encode(json.dumps(header.to_dict()).encode())
        payload_b64 = _b64_encode(json.dumps(claims.to_dict()).encode())
        signing_input = f"{header_b64}.{payload_b64}".encode()

        # Sign with ML-DSA
        signature = self._identity.sign(signing_input, self.keypair)

        return PQCToken(
            header=header,
            claims=claims,
            signature=signature.value,
        )


class TokenVerifier:
    """Verifies PQC-JWT tokens."""

    def __init__(self) -> None:
        """Initialize the token verifier."""
        self._providers: dict[MLDSALevel, IdentityProvider] = {}

    def _get_provider(self, algorithm: MLDSALevel) -> IdentityProvider:
        """Get or create an identity provider for the algorithm."""
        if algorithm not in self._providers:
            self._providers[algorithm] = IdentityProvider(algorithm)
        return self._providers[algorithm]

    def verify(
        self,
        token: str | PQCToken,
        public_key: bytes,
        verify_exp: bool = True,
        verify_nbf: bool = True,
        audience: str | list[str] | None = None,
        issuer: str | None = None,
    ) -> TokenClaims:
        """Verify a token and return its claims.

        Args:
            token: The token string or PQCToken object.
            public_key: The public key of the issuer.
            verify_exp: Whether to verify expiration.
            verify_nbf: Whether to verify not-before.
            audience: Expected audience(s).
            issuer: Expected issuer.

        Returns:
            The verified TokenClaims.

        Raises:
            ValueError: If the token is invalid.
            TokenExpiredError: If the token is expired.
            TokenNotYetValidError: If the token is not yet valid.
        """
        pqc_token = PQCToken.decode(token) if isinstance(token, str) else token

        # Verify signature
        algorithm = parse_algorithm(pqc_token.header.alg)
        provider = self._get_provider(algorithm)

        # Reconstruct signing input
        header_b64 = _b64_encode(json.dumps(pqc_token.header.to_dict()).encode())
        payload_b64 = _b64_encode(json.dumps(pqc_token.claims.to_dict()).encode())
        signing_input = f"{header_b64}.{payload_b64}".encode()

        signature = Signature(
            value=pqc_token.signature,
            algorithm=algorithm,
            key_id=pqc_token.header.kid or "",
        )

        if not provider.verify(signing_input, signature, public_key):
            raise ValueError("Invalid token signature")

        # Verify claims
        claims = pqc_token.claims

        if verify_exp and claims.is_expired():
            raise TokenExpiredError("Token has expired")

        if verify_nbf and claims.nbf is not None and time.time() < claims.nbf:
            raise TokenNotYetValidError("Token is not yet valid")

        if issuer is not None and claims.iss != issuer:
            raise ValueError(f"Invalid issuer: expected {issuer}, got {claims.iss}")

        if audience is not None:
            expected = [audience] if isinstance(audience, str) else audience
            token_aud = (
                [claims.aud] if isinstance(claims.aud, str) else (claims.aud or [])
            )
            if not any(aud in token_aud for aud in expected):
                raise ValueError(f"Invalid audience: {claims.aud}")

        return claims


class TokenExpiredError(Exception):
    """Raised when a token has expired."""

    pass


class TokenNotYetValidError(Exception):
    """Raised when a token is not yet valid (nbf claim)."""

    pass


def assess_token_risk(token_algorithm: str) -> dict[str, Any]:
    """Assess the quantum security risk of a token's algorithm.

    Args:
        token_algorithm: The algorithm used (e.g., "ES256", "RS256", "ML-DSA-65").

    Returns:
        A dictionary with risk assessment details.
    """
    quantum_safe_algorithms = {"ML-DSA-44", "ML-DSA-65", "ML-DSA-87"}
    vulnerable_algorithms = {
        "ES256": "ECDSA P-256",
        "ES384": "ECDSA P-384",
        "ES512": "ECDSA P-521",
        "RS256": "RSA 2048",
        "RS384": "RSA 3072",
        "RS512": "RSA 4096",
        "PS256": "RSA-PSS 2048",
        "PS384": "RSA-PSS 3072",
        "PS512": "RSA-PSS 4096",
        "EdDSA": "Ed25519",
    }

    normalized = token_algorithm.upper().replace("-", "_")
    for ml_dsa in quantum_safe_algorithms:
        if normalized == ml_dsa.upper().replace("-", "_"):
            return {
                "algorithm": ml_dsa,
                "quantum_safe": True,
                "risk": "LOW",
                "recommendation": None,
            }

    if token_algorithm in vulnerable_algorithms:
        return {
            "algorithm": token_algorithm,
            "algorithm_name": vulnerable_algorithms[token_algorithm],
            "quantum_safe": False,
            "risk": "HIGH",
            "recommendation": "Migrate to ML-DSA-65 for quantum-safe signatures",
        }

    return {
        "algorithm": token_algorithm,
        "quantum_safe": False,
        "risk": "UNKNOWN",
        "recommendation": "Algorithm not recognized. Consider using ML-DSA-65.",
    }
