"""
Runtime monitoring sessions for AI agents.

This module provides session context management for tracking agent actions
during execution, supporting local logging and cloud synchronization.
"""

from __future__ import annotations

import sqlite3
import threading
import time
import uuid
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .agent import SecureAgent


class ActionType(str, Enum):
    """Types of actions that can be logged."""

    READ = "read"
    WRITE = "write"
    EXECUTE = "execute"
    DELEGATE = "delegate"
    REVOKE = "revoke"
    CUSTOM = "custom"


@dataclass
class ActionRecord:
    """A record of an action performed during a session."""

    action_id: str
    session_id: str
    agent_id: str
    action_type: ActionType
    action_name: str
    timestamp: float
    metadata: dict[str, Any] = field(default_factory=dict)
    parent_action_id: str | None = None
    status: str = "completed"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for storage."""
        return {
            "action_id": self.action_id,
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "action_type": self.action_type.value,
            "action_name": self.action_name,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
            "parent_action_id": self.parent_action_id,
            "status": self.status,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ActionRecord:
        """Create from dictionary."""
        return cls(
            action_id=data["action_id"],
            session_id=data["session_id"],
            agent_id=data["agent_id"],
            action_type=ActionType(data["action_type"]),
            action_name=data["action_name"],
            timestamp=data["timestamp"],
            metadata=data.get("metadata", {}),
            parent_action_id=data.get("parent_action_id"),
            status=data.get("status", "completed"),
        )


class LocalStorage:
    """SQLite-based local storage for session logs."""

    def __init__(self, db_path: Path | str | None = None) -> None:
        """Initialize local storage.

        Args:
            db_path: Path to SQLite database. Defaults to ~/.asqav/sessions.db
        """
        if db_path is None:
            db_path = Path.home() / ".asqav" / "sessions.db"
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_schema()

    def _get_connection(self) -> sqlite3.Connection:
        """Get thread-local database connection."""
        if not hasattr(self._local, "conn"):
            self._local.conn = sqlite3.connect(str(self.db_path))
            self._local.conn.row_factory = sqlite3.Row
        conn: sqlite3.Connection = self._local.conn
        return conn

    def _init_schema(self) -> None:
        """Initialize database schema."""
        conn = self._get_connection()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                agent_id TEXT NOT NULL,
                started_at REAL NOT NULL,
                ended_at REAL,
                status TEXT DEFAULT 'active',
                metadata TEXT
            );

            CREATE TABLE IF NOT EXISTS actions (
                action_id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                agent_id TEXT NOT NULL,
                action_type TEXT NOT NULL,
                action_name TEXT NOT NULL,
                timestamp REAL NOT NULL,
                metadata TEXT,
                parent_action_id TEXT,
                status TEXT DEFAULT 'completed',
                FOREIGN KEY (session_id) REFERENCES sessions(session_id)
            );

            CREATE INDEX IF NOT EXISTS idx_actions_session
            ON actions(session_id);

            CREATE INDEX IF NOT EXISTS idx_actions_agent
            ON actions(agent_id);

            CREATE INDEX IF NOT EXISTS idx_actions_timestamp
            ON actions(timestamp);
        """)
        conn.commit()

    def create_session(
        self, session_id: str, agent_id: str, metadata: dict[str, Any] | None = None
    ) -> None:
        """Create a new session record."""
        import json

        conn = self._get_connection()
        conn.execute(
            "INSERT INTO sessions (session_id, agent_id, started_at, metadata) "
            "VALUES (?, ?, ?, ?)",
            (session_id, agent_id, time.time(), json.dumps(metadata or {})),
        )
        conn.commit()

    def end_session(self, session_id: str, status: str = "completed") -> None:
        """Mark a session as ended."""
        conn = self._get_connection()
        conn.execute(
            "UPDATE sessions SET ended_at = ?, status = ? WHERE session_id = ?",
            (time.time(), status, session_id),
        )
        conn.commit()

    def log_action(self, record: ActionRecord) -> None:
        """Log an action record."""
        import json

        conn = self._get_connection()
        conn.execute(
            "INSERT INTO actions "
            "(action_id, session_id, agent_id, action_type, action_name, "
            "timestamp, metadata, parent_action_id, status) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                record.action_id,
                record.session_id,
                record.agent_id,
                record.action_type.value,
                record.action_name,
                record.timestamp,
                json.dumps(record.metadata),
                record.parent_action_id,
                record.status,
            ),
        )
        conn.commit()

    def get_session_actions(
        self, session_id: str, limit: int = 100, offset: int = 0
    ) -> list[ActionRecord]:
        """Get actions for a session."""
        import json

        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM actions WHERE session_id = ? "
            "ORDER BY timestamp DESC LIMIT ? OFFSET ?",
            (session_id, limit, offset),
        )
        rows = cursor.fetchall()
        results = []
        for row in rows:
            data = dict(row)
            data["metadata"] = json.loads(data["metadata"] or "{}")
            results.append(ActionRecord.from_dict(data))
        return results

    def get_agent_actions(
        self,
        agent_id: str,
        since: float | None = None,
        limit: int = 100,
    ) -> list[ActionRecord]:
        """Get recent actions for an agent."""
        import json

        conn = self._get_connection()
        if since is not None:
            cursor = conn.execute(
                "SELECT * FROM actions WHERE agent_id = ? AND timestamp > ? "
                "ORDER BY timestamp DESC LIMIT ?",
                (agent_id, since, limit),
            )
        else:
            cursor = conn.execute(
                "SELECT * FROM actions WHERE agent_id = ? "
                "ORDER BY timestamp DESC LIMIT ?",
                (agent_id, limit),
            )
        rows = cursor.fetchall()
        results = []
        for row in rows:
            data = dict(row)
            data["metadata"] = json.loads(data["metadata"] or "{}")
            results.append(ActionRecord.from_dict(data))
        return results

    def get_all_actions(self, limit: int = 100) -> list[ActionRecord]:
        """Get all recent actions across all agents and sessions."""
        import json

        conn = self._get_connection()
        cursor = conn.execute(
            "SELECT * FROM actions ORDER BY timestamp DESC LIMIT ?",
            (limit,),
        )
        rows = cursor.fetchall()
        results = []
        for row in rows:
            data = dict(row)
            data["metadata"] = json.loads(data["metadata"] or "{}")
            results.append(ActionRecord.from_dict(data))
        return results


class Session:
    """A runtime monitoring session for an agent."""

    def __init__(
        self,
        agent: SecureAgent,
        storage: LocalStorage | None = None,
        session_id: str | None = None,
        parent_session: Session | None = None,
    ) -> None:
        """Initialize a session.

        Args:
            agent: The agent this session belongs to.
            storage: Storage backend for logging. Defaults to LocalStorage.
            session_id: Optional custom session ID.
            parent_session: Parent session for nested/delegated sessions.
        """
        self.agent = agent
        self.session_id = session_id or f"ses_{uuid.uuid4().hex[:16]}"
        self.storage = storage or LocalStorage()
        self.parent_session = parent_session
        self._started_at: float | None = None
        self._ended_at: float | None = None
        self._action_stack: list[str] = []
        self._active = False

    @property
    def is_active(self) -> bool:
        """Check if session is currently active."""
        return self._active

    @property
    def duration(self) -> float | None:
        """Get session duration in seconds."""
        if self._started_at is None:
            return None
        end = self._ended_at or time.time()
        return end - self._started_at

    def start(self) -> None:
        """Start the session."""
        if self._active:
            raise RuntimeError("Session already active")
        self._started_at = time.time()
        self._active = True
        self.storage.create_session(
            self.session_id,
            self.agent.agent_id,
            metadata={
                "parent_session": (
                    self.parent_session.session_id if self.parent_session else None
                ),
            },
        )

    def end(self, status: str = "completed") -> None:
        """End the session."""
        if not self._active:
            return
        self._ended_at = time.time()
        self._active = False
        self.storage.end_session(self.session_id, status)

    def log_action(
        self,
        action_name: str,
        metadata: dict[str, Any] | None = None,
        action_type: ActionType = ActionType.CUSTOM,
    ) -> str:
        """Log an action during the session.

        Args:
            action_name: Name or identifier for the action.
            metadata: Optional metadata about the action.
            action_type: Type of action being performed.

        Returns:
            The action ID for the logged action.
        """
        if not self._active:
            raise RuntimeError("Session not active. Use 'with agent.session()' context.")

        action_id = f"act_{uuid.uuid4().hex[:16]}"
        parent_action_id = self._action_stack[-1] if self._action_stack else None

        record = ActionRecord(
            action_id=action_id,
            session_id=self.session_id,
            agent_id=self.agent.agent_id,
            action_type=action_type,
            action_name=action_name,
            timestamp=time.time(),
            metadata=metadata or {},
            parent_action_id=parent_action_id,
        )

        self.storage.log_action(record)
        return action_id

    @contextmanager
    def action_context(
        self,
        action_name: str,
        metadata: dict[str, Any] | None = None,
        action_type: ActionType = ActionType.CUSTOM,
    ) -> Generator[str, None, None]:
        """Context manager for tracking nested actions.

        Args:
            action_name: Name or identifier for the action.
            metadata: Optional metadata about the action.
            action_type: Type of action being performed.

        Yields:
            The action ID for the logged action.
        """
        action_id = self.log_action(action_name, metadata, action_type)
        self._action_stack.append(action_id)
        try:
            yield action_id
        finally:
            self._action_stack.pop()

    def get_actions(self, limit: int = 100) -> list[ActionRecord]:
        """Get actions logged in this session."""
        return self.storage.get_session_actions(self.session_id, limit=limit)

    def delegate_to(
        self,
        sub_agent: SecureAgent,
        scope: list[str] | None = None,
    ) -> Session:
        """Create a delegated session for a sub-agent.

        Args:
            sub_agent: The sub-agent to delegate to.
            scope: Optional scope restriction for the delegation.

        Returns:
            A new Session for the sub-agent.
        """
        self.log_action(
            f"delegate:{sub_agent.agent_id}",
            metadata={
                "delegatee": sub_agent.agent_id,
                "scope": scope,
            },
            action_type=ActionType.DELEGATE,
        )

        return Session(
            agent=sub_agent,
            storage=self.storage,
            parent_session=self,
        )


def get_default_storage() -> LocalStorage:
    """Get the default local storage instance."""
    return LocalStorage()


def format_action_log(actions: list[ActionRecord]) -> str:
    """Format action records as a human-readable log.

    Args:
        actions: List of action records to format.

    Returns:
        Formatted string representation of the actions.
    """
    lines = []
    for action in actions:
        dt = datetime.fromtimestamp(action.timestamp, tz=UTC)
        timestamp = dt.strftime("%Y-%m-%d %H:%M:%S UTC")
        indent = "  " if action.parent_action_id else ""
        lines.append(
            f"{indent}[{timestamp}] {action.action_type.value.upper()}: "
            f"{action.action_name}"
        )
        if action.metadata:
            for key, value in action.metadata.items():
                lines.append(f"{indent}    {key}: {value}")
    return "\n".join(lines)
