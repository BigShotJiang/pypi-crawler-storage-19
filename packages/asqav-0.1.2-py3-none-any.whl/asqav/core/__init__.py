"""Core security primitives for Asqav.

This module provides the foundational components for quantum-safe
identity management, token handling, session monitoring, delegation,
and revocation.
"""

from .agent import AgentConfig, SecureAgent, create_agent
from .delegation import DelegationChain, DelegationRecord, attenuate_scope
from .key_rotation import (
    KeyRotationManager,
    KeyRotationPolicy,
    KeyRotationRecord,
    KeyRotationResult,
)
from .identity import (
    IdentityProvider,
    KeyPair,
    MLDSALevel,
    Signature,
    generate_agent_id,
    get_available_algorithms,
    parse_algorithm,
)
from .revocation import (
    RevocationList,
    RevocationReason,
    RevocationRecord,
    get_revocation_list,
    is_revoked,
    revoke_agent,
)
from .session import ActionRecord, ActionType, LocalStorage, Session, format_action_log
from .tokens import (
    PQCToken,
    TokenClaims,
    TokenExpiredError,
    TokenHeader,
    TokenIssuer,
    TokenNotYetValidError,
    TokenVerifier,
    assess_token_risk,
)

__all__ = [
    # Agent
    "SecureAgent",
    "AgentConfig",
    "create_agent",
    # Identity
    "IdentityProvider",
    "KeyPair",
    "MLDSALevel",
    "Signature",
    "generate_agent_id",
    "get_available_algorithms",
    "parse_algorithm",
    # Tokens
    "PQCToken",
    "TokenClaims",
    "TokenHeader",
    "TokenIssuer",
    "TokenVerifier",
    "TokenExpiredError",
    "TokenNotYetValidError",
    "assess_token_risk",
    # Sessions
    "Session",
    "ActionRecord",
    "ActionType",
    "LocalStorage",
    "format_action_log",
    # Delegation
    "DelegationChain",
    "DelegationRecord",
    "attenuate_scope",
    # Revocation
    "RevocationList",
    "RevocationReason",
    "RevocationRecord",
    "get_revocation_list",
    "is_revoked",
    "revoke_agent",
    # Key Rotation
    "KeyRotationManager",
    "KeyRotationPolicy",
    "KeyRotationRecord",
    "KeyRotationResult",
]
