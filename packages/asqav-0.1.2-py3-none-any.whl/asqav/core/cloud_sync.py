"""Cloud synchronization for session logs.

Syncs local SQLite session logs to the Asqav Cloud API.
Supports:
- Background sync
- Batch uploads
- Retry with exponential backoff
- Offline queue
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from queue import Queue, Empty
from typing import Any
from urllib.error import URLError
from urllib.request import Request, urlopen


@dataclass
class SyncConfig:
    """Configuration for cloud sync."""

    # API endpoint
    api_url: str = "https://api.asqav.com/api/v1"
    api_key: str | None = None

    # Sync behavior
    batch_size: int = 100
    sync_interval_seconds: int = 60
    max_retries: int = 3
    retry_delay_seconds: int = 5

    # Storage
    offline_queue_path: str | None = None


@dataclass
class SyncStatus:
    """Status of cloud sync."""

    is_running: bool = False
    last_sync: datetime | None = None
    pending_count: int = 0
    synced_count: int = 0
    failed_count: int = 0
    last_error: str | None = None


class CloudSync:
    """Synchronizes local session logs to Asqav Cloud.

    Example:
        from asqav import CloudSync, SyncConfig

        sync = CloudSync(SyncConfig(
            api_url="https://api.asqav.com/api/v1",
            api_key="your-api-key"
        ))

        # Start background sync
        sync.start()

        # Queue a session for sync
        sync.queue_session(session_id, actions)

        # Stop sync
        sync.stop()
    """

    def __init__(self, config: SyncConfig | None = None) -> None:
        """Initialize cloud sync.

        Args:
            config: Sync configuration. Defaults to standard config.
        """
        self.config = config or SyncConfig()
        self._status = SyncStatus()
        self._queue: Queue[dict[str, Any]] = Queue()
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._local = threading.local()

        # Initialize offline queue if configured
        if self.config.offline_queue_path:
            self._init_offline_queue()

    def _get_connection(self) -> sqlite3.Connection | None:
        """Get thread-local database connection for offline queue."""
        if not self.config.offline_queue_path:
            return None

        if not hasattr(self._local, "conn"):
            conn: sqlite3.Connection = sqlite3.connect(self.config.offline_queue_path)
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return self._local.conn

    def _init_offline_queue(self) -> None:
        """Initialize offline queue database."""
        conn = self._get_connection()
        if not conn:
            return

        conn.execute("""
            CREATE TABLE IF NOT EXISTS sync_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                payload TEXT NOT NULL,
                created_at TEXT NOT NULL,
                retry_count INTEGER DEFAULT 0,
                last_error TEXT
            )
        """)
        conn.commit()

    @property
    def status(self) -> SyncStatus:
        """Get current sync status."""
        return self._status

    def start(self) -> None:
        """Start background sync thread."""
        if self._thread and self._thread.is_alive():
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._sync_loop, daemon=True)
        self._thread.start()
        self._status.is_running = True

    def stop(self) -> None:
        """Stop background sync thread."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        self._status.is_running = False

    def queue_session(
        self,
        session_id: str,
        agent_id: str,
        actions: list[dict[str, Any]],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Queue a session for sync.

        Args:
            session_id: Session identifier.
            agent_id: Agent identifier.
            actions: List of action records.
            metadata: Optional session metadata.
        """
        payload = {
            "session_id": session_id,
            "agent_id": agent_id,
            "actions": actions,
            "metadata": metadata,
            "queued_at": datetime.now().isoformat(),
        }

        self._queue.put(payload)
        self._status.pending_count += 1

        # Also persist to offline queue
        self._persist_to_offline_queue(payload)

    def queue_action(
        self,
        session_id: str,
        agent_id: str,
        action: dict[str, Any],
    ) -> None:
        """Queue a single action for sync.

        Args:
            session_id: Session identifier.
            agent_id: Agent identifier.
            action: Action record.
        """
        payload = {
            "session_id": session_id,
            "agent_id": agent_id,
            "actions": [action],
            "queued_at": datetime.now().isoformat(),
        }

        self._queue.put(payload)
        self._status.pending_count += 1

    def sync_now(self) -> SyncStatus:
        """Perform immediate sync (blocking).

        Returns:
            Current sync status.
        """
        self._process_queue()
        return self._status

    def _sync_loop(self) -> None:
        """Background sync loop."""
        while not self._stop_event.is_set():
            try:
                self._process_queue()
            except Exception as e:
                self._status.last_error = str(e)

            # Wait for next interval or stop event
            self._stop_event.wait(self.config.sync_interval_seconds)

    def _process_queue(self) -> None:
        """Process items in the sync queue."""
        batch: list[dict[str, Any]] = []

        # Collect batch from queue
        while len(batch) < self.config.batch_size:
            try:
                item = self._queue.get_nowait()
                batch.append(item)
            except Empty:
                break

        if not batch:
            # Try loading from offline queue
            batch = self._load_from_offline_queue()

        if not batch:
            return

        # Group by session for efficient upload
        sessions: dict[str, dict[str, Any]] = {}
        for item in batch:
            sid = item["session_id"]
            if sid not in sessions:
                sessions[sid] = {
                    "session_id": sid,
                    "agent_id": item["agent_id"],
                    "actions": [],
                    "metadata": item.get("metadata"),
                }
            sessions[sid]["actions"].extend(item.get("actions", []))

        # Upload each session
        for session_data in sessions.values():
            success = self._upload_session(session_data)
            if success:
                self._status.synced_count += len(session_data["actions"])
                self._status.pending_count -= len(session_data["actions"])
                self._remove_from_offline_queue(session_data["session_id"])
            else:
                self._status.failed_count += 1

        self._status.last_sync = datetime.now()

    def _upload_session(self, session_data: dict[str, Any]) -> bool:
        """Upload session data to cloud API.

        Args:
            session_data: Session data to upload.

        Returns:
            True if successful.
        """
        if not self.config.api_key:
            self._status.last_error = "API key not configured"
            return False

        url = f"{self.config.api_url}/sessions/sync"
        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }

        for attempt in range(self.config.max_retries):
            try:
                request = Request(
                    url,
                    data=json.dumps(session_data).encode("utf-8"),
                    headers=headers,
                    method="POST",
                )

                with urlopen(request, timeout=30) as response:
                    if response.status == 200 or response.status == 201:
                        return True
                    else:
                        self._status.last_error = f"HTTP {response.status}"

            except URLError as e:
                self._status.last_error = str(e)
            except Exception as e:
                self._status.last_error = str(e)

            # Exponential backoff
            if attempt < self.config.max_retries - 1:
                delay = self.config.retry_delay_seconds * (2**attempt)
                time.sleep(delay)

        return False

    def _persist_to_offline_queue(self, payload: dict[str, Any]) -> None:
        """Persist payload to offline queue for recovery."""
        conn = self._get_connection()
        if not conn:
            return

        try:
            conn.execute(
                """
                INSERT INTO sync_queue (payload, created_at)
                VALUES (?, ?)
                """,
                (json.dumps(payload), datetime.now().isoformat()),
            )
            conn.commit()
        except Exception:
            pass

    def _load_from_offline_queue(self) -> list[dict[str, Any]]:
        """Load items from offline queue."""
        conn = self._get_connection()
        if not conn:
            return []

        try:
            cursor = conn.execute(
                """
                SELECT id, payload FROM sync_queue
                WHERE retry_count < ?
                ORDER BY created_at
                LIMIT ?
                """,
                (self.config.max_retries, self.config.batch_size),
            )
            rows = cursor.fetchall()
            return [json.loads(row["payload"]) for row in rows]
        except Exception:
            return []

    def _remove_from_offline_queue(self, session_id: str) -> None:
        """Remove successfully synced session from offline queue."""
        conn = self._get_connection()
        if not conn:
            return

        try:
            conn.execute(
                """
                DELETE FROM sync_queue
                WHERE payload LIKE ?
                """,
                (f'%"session_id": "{session_id}"%',),
            )
            conn.commit()
        except Exception:
            pass


class AutoSync:
    """Automatic sync integration with Session context.

    Example:
        from asqav import SecureAgent, AutoSync, SyncConfig

        sync = AutoSync(SyncConfig(api_key="your-key"))
        agent = SecureAgent.create(name="my-agent")

        # Actions are automatically queued for sync
        with sync.session(agent) as session:
            session.log_action("read:data", {"id": 123})
    """

    def __init__(self, config: SyncConfig | None = None) -> None:
        """Initialize auto sync.

        Args:
            config: Sync configuration.
        """
        self.cloud_sync = CloudSync(config)
        self.cloud_sync.start()

    def session(self, agent: Any):
        """Create a syncing session context.

        Args:
            agent: SecureAgent to create session for.

        Returns:
            Session context that auto-syncs.
        """
        from .session import Session

        # Wrap session to capture actions
        original_session = agent.session()
        return _SyncingSession(original_session, self.cloud_sync, agent.agent_id)

    def stop(self) -> None:
        """Stop auto sync."""
        self.cloud_sync.stop()


class _SyncingSession:
    """Session wrapper that syncs actions to cloud."""

    def __init__(
        self,
        session: Any,
        cloud_sync: CloudSync,
        agent_id: str,
    ) -> None:
        self._session = session
        self._cloud_sync = cloud_sync
        self._agent_id = agent_id
        self._actions: list[dict[str, Any]] = []

    def __enter__(self) -> "_SyncingSession":
        self._session.__enter__()
        return self

    def __exit__(self, *args: Any) -> None:
        self._session.__exit__(*args)

        # Queue all actions for sync
        if self._actions:
            self._cloud_sync.queue_session(
                session_id=self._session.session_id,
                agent_id=self._agent_id,
                actions=self._actions,
            )

    def log_action(self, action_type: str, metadata: dict[str, Any] | None = None) -> str:
        """Log an action and queue for sync."""
        action_id = self._session.log_action(action_type, metadata)

        # Capture action for sync
        self._actions.append({
            "action_id": action_id,
            "action_type": action_type,
            "metadata": metadata,
            "timestamp": datetime.now().isoformat(),
        })

        return action_id

    # Delegate other methods to underlying session
    def __getattr__(self, name: str) -> Any:
        return getattr(self._session, name)
