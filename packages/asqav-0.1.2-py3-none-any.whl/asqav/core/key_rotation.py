"""Key rotation mechanism for Asqav agents.

Provides secure key rotation with:
- Grace period for old key validity
- Rotation history tracking
- Automatic token re-issuance
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from .identity import IdentityProvider, KeyPair, parse_algorithm


@dataclass
class KeyRotationRecord:
    """Record of a key rotation event."""

    rotation_id: str
    agent_id: str
    old_key_id: str
    new_key_id: str
    old_public_key: bytes
    new_public_key: bytes
    rotated_at: datetime
    grace_period_ends: datetime
    reason: str
    metadata: dict[str, Any] | None = None


@dataclass
class KeyRotationPolicy:
    """Policy for key rotation."""

    # Maximum age before rotation is recommended
    max_key_age_days: int = 90

    # Grace period where old key is still valid
    grace_period_hours: int = 24

    # Whether to automatically rotate expired keys
    auto_rotate: bool = False

    # Minimum interval between rotations
    min_rotation_interval_hours: int = 1


@dataclass
class KeyRotationResult:
    """Result of a key rotation operation."""

    success: bool
    rotation_id: str | None = None
    old_key_id: str | None = None
    new_key_id: str | None = None
    new_keypair: KeyPair | None = None
    error: str | None = None
    grace_period_ends: datetime | None = None


class KeyRotationManager:
    """Manages key rotation for agents.

    Example:
        from asqav import SecureAgent, KeyRotationManager

        agent = SecureAgent.create(name="my-agent")
        manager = KeyRotationManager()

        # Rotate keys with 24-hour grace period
        result = manager.rotate_keys(
            agent,
            reason="scheduled",
            grace_period_hours=24
        )

        # Check if rotation is needed
        if manager.should_rotate(agent):
            manager.rotate_keys(agent)

        # Verify token during grace period (accepts old or new key)
        is_valid = manager.verify_during_grace_period(
            token, agent_id, public_key
        )
    """

    def __init__(
        self,
        db_path: str | Path | None = None,
        policy: KeyRotationPolicy | None = None,
    ) -> None:
        """Initialize the key rotation manager.

        Args:
            db_path: Path to SQLite database for rotation history.
                    Defaults to ~/.asqav/key_rotation.db
            policy: Key rotation policy. Defaults to standard policy.
        """
        if db_path is None:
            db_path = Path.home() / ".asqav" / "key_rotation.db"
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        self.policy = policy or KeyRotationPolicy()
        self._local = threading.local()
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Get thread-local database connection."""
        if not hasattr(self._local, "conn"):
            conn: sqlite3.Connection = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return self._local.conn

    def _init_db(self) -> None:
        """Initialize the database schema."""
        conn = self._get_connection()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS key_rotations (
                rotation_id TEXT PRIMARY KEY,
                agent_id TEXT NOT NULL,
                old_key_id TEXT NOT NULL,
                new_key_id TEXT NOT NULL,
                old_public_key BLOB NOT NULL,
                new_public_key BLOB NOT NULL,
                rotated_at TEXT NOT NULL,
                grace_period_ends TEXT NOT NULL,
                reason TEXT NOT NULL,
                metadata TEXT
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_rotations_agent
            ON key_rotations(agent_id)
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_rotations_grace
            ON key_rotations(grace_period_ends)
        """)
        conn.commit()

    def rotate_keys(
        self,
        agent: Any,  # SecureAgent - using Any to avoid circular import
        reason: str = "manual",
        grace_period_hours: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> KeyRotationResult:
        """Rotate the keys for an agent.

        Args:
            agent: The SecureAgent to rotate keys for.
            reason: Reason for rotation (manual, scheduled, compromised, policy).
            grace_period_hours: Hours old key remains valid. Defaults to policy.
            metadata: Additional metadata to store with rotation.

        Returns:
            KeyRotationResult with new identity if successful.
        """
        if grace_period_hours is None:
            grace_period_hours = self.policy.grace_period_hours

        # Check minimum rotation interval
        last_rotation = self.get_last_rotation(agent.agent_id)
        if last_rotation:
            min_interval = timedelta(hours=self.policy.min_rotation_interval_hours)
            if datetime.now() - last_rotation.rotated_at < min_interval:
                return KeyRotationResult(
                    success=False,
                    error=f"Minimum rotation interval not met. Wait at least {self.policy.min_rotation_interval_hours} hours.",
                )

        # Generate new keypair with same algorithm
        provider = IdentityProvider(agent.keypair.algorithm)
        new_keypair = provider.generate_keypair()

        # Create rotation record
        rotation_id = self._generate_rotation_id(
            agent.agent_id,
            agent.keypair.key_id,
            new_keypair.key_id,
        )

        rotated_at = datetime.now()
        grace_period_ends = rotated_at + timedelta(hours=grace_period_hours)

        record = KeyRotationRecord(
            rotation_id=rotation_id,
            agent_id=agent.agent_id,
            old_key_id=agent.keypair.key_id,
            new_key_id=new_keypair.key_id,
            old_public_key=agent.keypair.public_key,
            new_public_key=new_keypair.public_key,
            rotated_at=rotated_at,
            grace_period_ends=grace_period_ends,
            reason=reason,
            metadata=metadata,
        )

        # Store rotation record
        self._store_rotation(record)

        # Return result - caller must update agent's keypair
        return KeyRotationResult(
            success=True,
            rotation_id=rotation_id,
            old_key_id=agent.keypair.key_id,
            new_key_id=new_keypair.key_id,
            new_keypair=new_keypair,
            grace_period_ends=grace_period_ends,
        )

    def should_rotate(self, agent: Any) -> bool:
        """Check if an agent's keys should be rotated based on policy.

        Args:
            agent: The SecureAgent to check.

        Returns:
            True if rotation is recommended.
        """
        # Check key age based on agent creation time
        key_age = datetime.now() - agent.created_at
        max_age = timedelta(days=self.policy.max_key_age_days)

        return key_age > max_age

    def get_rotation_history(
        self,
        agent_id: str,
        limit: int = 100,
    ) -> list[KeyRotationRecord]:
        """Get rotation history for an agent.

        Args:
            agent_id: The agent ID to get history for.
            limit: Maximum number of records to return.

        Returns:
            List of rotation records, most recent first.
        """
        conn = self._get_connection()
        cursor = conn.execute(
            """
            SELECT * FROM key_rotations
            WHERE agent_id = ?
            ORDER BY rotated_at DESC
            LIMIT ?
            """,
            (agent_id, limit),
        )
        return [self._row_to_record(row) for row in cursor.fetchall()]

    def get_last_rotation(self, agent_id: str) -> KeyRotationRecord | None:
        """Get the most recent rotation for an agent.

        Args:
            agent_id: The agent ID.

        Returns:
            Most recent rotation record, or None if never rotated.
        """
        history = self.get_rotation_history(agent_id, limit=1)
        return history[0] if history else None

    def is_in_grace_period(self, agent_id: str, key_id: str) -> bool:
        """Check if a key is within its grace period.

        Args:
            agent_id: The agent ID.
            key_id: The key ID to check.

        Returns:
            True if key is in grace period (old key still valid).
        """
        conn = self._get_connection()
        cursor = conn.execute(
            """
            SELECT grace_period_ends FROM key_rotations
            WHERE agent_id = ? AND old_key_id = ?
            ORDER BY rotated_at DESC
            LIMIT 1
            """,
            (agent_id, key_id),
        )
        row = cursor.fetchone()
        if not row:
            return False

        grace_ends = datetime.fromisoformat(row["grace_period_ends"])
        return datetime.now() < grace_ends

    def get_valid_keys(self, agent_id: str) -> list[str]:
        """Get all currently valid key IDs for an agent.

        Includes current key and any keys still in grace period.

        Args:
            agent_id: The agent ID.

        Returns:
            List of valid key IDs.
        """
        conn = self._get_connection()
        now = datetime.now().isoformat()

        # Get keys still in grace period
        cursor = conn.execute(
            """
            SELECT old_key_id FROM key_rotations
            WHERE agent_id = ? AND grace_period_ends > ?
            """,
            (agent_id, now),
        )
        grace_keys = [row["old_key_id"] for row in cursor.fetchall()]

        # Get the current (newest) key
        cursor = conn.execute(
            """
            SELECT new_key_id FROM key_rotations
            WHERE agent_id = ?
            ORDER BY rotated_at DESC
            LIMIT 1
            """,
            (agent_id,),
        )
        row = cursor.fetchone()
        current_key = row["new_key_id"] if row else None

        valid_keys = list(set(grace_keys))
        if current_key and current_key not in valid_keys:
            valid_keys.append(current_key)

        return valid_keys

    def cleanup_expired_grace_periods(self) -> int:
        """Remove records for keys whose grace period has expired.

        Returns:
            Number of records cleaned up.
        """
        conn = self._get_connection()
        threshold = (
            datetime.now() - timedelta(days=30)
        ).isoformat()  # Keep 30 days of history

        cursor = conn.execute(
            """
            DELETE FROM key_rotations
            WHERE grace_period_ends < ?
            """,
            (threshold,),
        )
        conn.commit()
        return cursor.rowcount

    def _generate_rotation_id(
        self,
        agent_id: str,
        old_key_id: str,
        new_key_id: str,
    ) -> str:
        """Generate a unique rotation ID."""
        data = f"{agent_id}:{old_key_id}:{new_key_id}:{datetime.now().isoformat()}"
        hash_bytes = hashlib.sha256(data.encode()).digest()
        return f"rot_{hash_bytes[:8].hex()}"

    def _store_rotation(self, record: KeyRotationRecord) -> None:
        """Store a rotation record in the database."""
        conn = self._get_connection()
        conn.execute(
            """
            INSERT INTO key_rotations
            (rotation_id, agent_id, old_key_id, new_key_id,
             old_public_key, new_public_key, rotated_at,
             grace_period_ends, reason, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                record.rotation_id,
                record.agent_id,
                record.old_key_id,
                record.new_key_id,
                record.old_public_key,
                record.new_public_key,
                record.rotated_at.isoformat(),
                record.grace_period_ends.isoformat(),
                record.reason,
                json.dumps(record.metadata) if record.metadata else None,
            ),
        )
        conn.commit()

    def _row_to_record(self, row: sqlite3.Row) -> KeyRotationRecord:
        """Convert a database row to a KeyRotationRecord."""
        return KeyRotationRecord(
            rotation_id=row["rotation_id"],
            agent_id=row["agent_id"],
            old_key_id=row["old_key_id"],
            new_key_id=row["new_key_id"],
            old_public_key=row["old_public_key"],
            new_public_key=row["new_public_key"],
            rotated_at=datetime.fromisoformat(row["rotated_at"]),
            grace_period_ends=datetime.fromisoformat(row["grace_period_ends"]),
            reason=row["reason"],
            metadata=json.loads(row["metadata"]) if row["metadata"] else None,
        )
