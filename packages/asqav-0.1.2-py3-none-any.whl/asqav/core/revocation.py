"""
Agent revocation management.

This module provides functionality for revoking agent credentials and
propagating revocations across the system.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass


class RevocationReason(str, Enum):
    """Reasons for agent revocation."""

    COMPROMISED = "compromised"
    EXPIRED = "expired"
    POLICY_VIOLATION = "policy_violation"
    MANUAL = "manual"
    ANOMALY_DETECTED = "anomaly_detected"
    PARENT_REVOKED = "parent_revoked"


@dataclass
class RevocationRecord:
    """A record of an agent revocation."""

    agent_id: str
    revoked_at: float
    reason: RevocationReason
    revoked_by: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    propagated: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "agent_id": self.agent_id,
            "revoked_at": self.revoked_at,
            "reason": self.reason.value,
            "revoked_by": self.revoked_by,
            "metadata": self.metadata,
            "propagated": self.propagated,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RevocationRecord:
        """Create from dictionary."""
        return cls(
            agent_id=data["agent_id"],
            revoked_at=data["revoked_at"],
            reason=RevocationReason(data["reason"]),
            revoked_by=data.get("revoked_by"),
            metadata=data.get("metadata", {}),
            propagated=data.get("propagated", False),
        )


class RevocationList:
    """Manages a list of revoked agents."""

    def __init__(self) -> None:
        """Initialize revocation list."""
        self._revocations: dict[str, RevocationRecord] = {}
        self._listeners: list[Callable[[RevocationRecord], None]] = []
        self._delegation_map: dict[str, set[str]] = {}

    def revoke(
        self,
        agent_id: str,
        reason: RevocationReason = RevocationReason.MANUAL,
        revoked_by: str | None = None,
        metadata: dict[str, Any] | None = None,
        propagate: bool = True,
    ) -> RevocationRecord:
        """Revoke an agent.

        Args:
            agent_id: ID of the agent to revoke.
            reason: Reason for revocation.
            revoked_by: ID of the entity initiating revocation.
            metadata: Additional metadata about the revocation.
            propagate: Whether to propagate to delegated agents.

        Returns:
            The RevocationRecord.
        """
        record = RevocationRecord(
            agent_id=agent_id,
            revoked_at=time.time(),
            reason=reason,
            revoked_by=revoked_by,
            metadata=metadata or {},
        )

        self._revocations[agent_id] = record

        # Notify listeners
        for listener in self._listeners:
            listener(record)

        # Propagate to delegated agents
        if propagate:
            self._propagate_revocation(agent_id)
            record.propagated = True

        return record

    def _propagate_revocation(self, agent_id: str) -> None:
        """Propagate revocation to all delegated agents.

        Args:
            agent_id: ID of the revoked agent.
        """
        delegatees = self._delegation_map.get(agent_id, set())
        for delegatee_id in delegatees:
            if delegatee_id not in self._revocations:
                self.revoke(
                    delegatee_id,
                    reason=RevocationReason.PARENT_REVOKED,
                    revoked_by=agent_id,
                    metadata={"parent_agent": agent_id},
                    propagate=True,
                )

    def is_revoked(self, agent_id: str) -> bool:
        """Check if an agent is revoked.

        Args:
            agent_id: ID of the agent to check.

        Returns:
            True if the agent is revoked.
        """
        return agent_id in self._revocations

    def get_revocation(self, agent_id: str) -> RevocationRecord | None:
        """Get revocation record for an agent.

        Args:
            agent_id: ID of the agent.

        Returns:
            The RevocationRecord if revoked, None otherwise.
        """
        return self._revocations.get(agent_id)

    def get_all_revocations(self) -> list[RevocationRecord]:
        """Get all revocation records.

        Returns:
            List of all RevocationRecords.
        """
        return list(self._revocations.values())

    def register_delegation(self, delegator_id: str, delegatee_id: str) -> None:
        """Register a delegation relationship for propagation.

        Args:
            delegator_id: ID of the delegator.
            delegatee_id: ID of the delegatee.
        """
        if delegator_id not in self._delegation_map:
            self._delegation_map[delegator_id] = set()
        self._delegation_map[delegator_id].add(delegatee_id)

    def add_listener(self, callback: Callable[[RevocationRecord], None]) -> None:
        """Add a listener for revocation events.

        Args:
            callback: Function to call when an agent is revoked.
        """
        self._listeners.append(callback)

    def remove_listener(self, callback: Callable[[RevocationRecord], None]) -> None:
        """Remove a revocation listener.

        Args:
            callback: The callback to remove.
        """
        if callback in self._listeners:
            self._listeners.remove(callback)

    def clear(self) -> None:
        """Clear all revocations. Use with caution."""
        self._revocations.clear()

    def export(self) -> list[dict[str, Any]]:
        """Export all revocations as a list of dictionaries."""
        return [r.to_dict() for r in self._revocations.values()]

    def import_revocations(self, data: list[dict[str, Any]]) -> int:
        """Import revocations from a list of dictionaries.

        Args:
            data: List of revocation dictionaries.

        Returns:
            Number of revocations imported.
        """
        count = 0
        for item in data:
            record = RevocationRecord.from_dict(item)
            if record.agent_id not in self._revocations:
                self._revocations[record.agent_id] = record
                count += 1
        return count


# Global revocation list instance
_global_revocation_list: RevocationList | None = None


def get_revocation_list() -> RevocationList:
    """Get the global revocation list instance."""
    global _global_revocation_list
    if _global_revocation_list is None:
        _global_revocation_list = RevocationList()
    return _global_revocation_list


def is_revoked(agent_id: str) -> bool:
    """Check if an agent is revoked using the global list.

    Args:
        agent_id: ID of the agent to check.

    Returns:
        True if the agent is revoked.
    """
    return get_revocation_list().is_revoked(agent_id)


def revoke_agent(
    agent_id: str,
    reason: RevocationReason = RevocationReason.MANUAL,
    revoked_by: str | None = None,
) -> RevocationRecord:
    """Revoke an agent using the global list.

    Args:
        agent_id: ID of the agent to revoke.
        reason: Reason for revocation.
        revoked_by: ID of the entity initiating revocation.

    Returns:
        The RevocationRecord.
    """
    return get_revocation_list().revoke(agent_id, reason, revoked_by)
