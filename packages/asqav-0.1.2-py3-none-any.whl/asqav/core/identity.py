"""
ML-DSA key generation and identity management for quantum-safe AI agents.

This module provides NIST FIPS 204 compliant digital signature operations
using the ML-DSA (Module-Lattice Digital Signature Algorithm).
"""

from __future__ import annotations

import base64
import hashlib
import secrets
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

import oqs

if TYPE_CHECKING:
    pass


class MLDSALevel(str, Enum):
    """ML-DSA security levels as defined in FIPS 204."""

    ML_DSA_44 = "ML-DSA-44"  # 128-bit security
    ML_DSA_65 = "ML-DSA-65"  # 192-bit security (recommended)
    ML_DSA_87 = "ML-DSA-87"  # 256-bit security

    @property
    def security_bits(self) -> int:
        """Return the security level in bits."""
        return {
            self.ML_DSA_44: 128,
            self.ML_DSA_65: 192,
            self.ML_DSA_87: 256,
        }[self]


# Alias for convenience
ALGORITHM_MAP = {
    "ml-dsa-44": MLDSALevel.ML_DSA_44,
    "ml-dsa-65": MLDSALevel.ML_DSA_65,
    "ml-dsa-87": MLDSALevel.ML_DSA_87,
}


@dataclass(frozen=True)
class KeyPair:
    """A quantum-safe ML-DSA key pair."""

    public_key: bytes
    secret_key: bytes
    algorithm: MLDSALevel

    @property
    def public_key_b64(self) -> str:
        """Return the public key as base64 string."""
        return base64.urlsafe_b64encode(self.public_key).decode("ascii")

    @property
    def key_id(self) -> str:
        """Generate a unique identifier for this key based on public key hash."""
        digest = hashlib.sha256(self.public_key).digest()[:16]
        return base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")

    def to_dict(self) -> dict[str, str]:
        """Serialize key pair to dictionary (excludes secret key for safety)."""
        return {
            "key_id": self.key_id,
            "public_key": self.public_key_b64,
            "algorithm": self.algorithm.value,
        }


@dataclass(frozen=True)
class Signature:
    """A digital signature with metadata."""

    value: bytes
    algorithm: MLDSALevel
    key_id: str

    @property
    def value_b64(self) -> str:
        """Return the signature as base64 string."""
        return base64.urlsafe_b64encode(self.value).decode("ascii")

    @classmethod
    def from_b64(cls, value_b64: str, algorithm: MLDSALevel, key_id: str) -> Signature:
        """Create signature from base64 encoded value."""
        return cls(
            value=base64.urlsafe_b64decode(value_b64),
            algorithm=algorithm,
            key_id=key_id,
        )


class IdentityProvider:
    """Manages quantum-safe identity operations using ML-DSA."""

    def __init__(self, algorithm: MLDSALevel = MLDSALevel.ML_DSA_65) -> None:
        """Initialize the identity provider.

        Args:
            algorithm: The ML-DSA security level to use. Defaults to ML-DSA-65
                      which provides 192-bit security.
        """
        self.algorithm = algorithm
        self._verify_algorithm_available()

    def _verify_algorithm_available(self) -> None:
        """Verify the algorithm is available in liboqs."""
        available = oqs.get_enabled_sig_mechanisms()
        if self.algorithm.value not in available:
            raise RuntimeError(
                f"Algorithm {self.algorithm.value} not available. "
                f"Available: {available}"
            )

    def generate_keypair(self) -> KeyPair:
        """Generate a new ML-DSA key pair.

        Returns:
            A KeyPair containing the public and secret keys.
        """
        with oqs.Signature(self.algorithm.value) as sig:
            public_key = sig.generate_keypair()
            secret_key = sig.export_secret_key()

        return KeyPair(
            public_key=public_key,
            secret_key=secret_key,
            algorithm=self.algorithm,
        )

    def sign(self, message: bytes, keypair: KeyPair) -> Signature:
        """Sign a message using the secret key.

        Args:
            message: The message bytes to sign.
            keypair: The key pair containing the secret key.

        Returns:
            A Signature object containing the signature bytes and metadata.
        """
        if keypair.algorithm != self.algorithm:
            raise ValueError(
                f"Key pair algorithm {keypair.algorithm} does not match "
                f"provider algorithm {self.algorithm}"
            )

        with oqs.Signature(self.algorithm.value, keypair.secret_key) as sig:
            signature_bytes = sig.sign(message)

        return Signature(
            value=signature_bytes,
            algorithm=self.algorithm,
            key_id=keypair.key_id,
        )

    def verify(
        self, message: bytes, signature: Signature, public_key: bytes
    ) -> bool:
        """Verify a signature against a message and public key.

        Args:
            message: The original message bytes.
            signature: The signature to verify.
            public_key: The public key bytes of the signer.

        Returns:
            True if the signature is valid, False otherwise.
        """
        with oqs.Signature(self.algorithm.value) as verifier:
            return bool(verifier.verify(message, signature.value, public_key))


def generate_agent_id() -> str:
    """Generate a unique agent identifier."""
    return f"agt_{secrets.token_urlsafe(16)}"


def get_available_algorithms() -> list[str]:
    """Return list of available ML-DSA algorithms."""
    all_sigs = oqs.get_enabled_sig_mechanisms()
    return [alg for alg in all_sigs if alg.startswith("ML-DSA")]


def parse_algorithm(algorithm: str) -> MLDSALevel:
    """Parse algorithm string to MLDSALevel enum.

    Args:
        algorithm: Algorithm name like "ml-dsa-65" or "ML-DSA-65"

    Returns:
        The corresponding MLDSALevel enum value.
    """
    normalized = algorithm.lower()
    if normalized in ALGORITHM_MAP:
        return ALGORITHM_MAP[normalized]

    # Try direct match
    for level in MLDSALevel:
        if level.value.lower() == normalized:
            return level

    raise ValueError(
        f"Unknown algorithm: {algorithm}. "
        f"Valid options: {list(ALGORITHM_MAP.keys())}"
    )
