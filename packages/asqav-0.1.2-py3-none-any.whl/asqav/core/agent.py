"""
SecureAgent: Quantum-safe AI agent identity and runtime management.

This module provides the main SecureAgent class that combines quantum-safe
identity, token management, session monitoring, and delegation capabilities.
"""

from __future__ import annotations

import time
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

from .delegation import DelegationChain, attenuate_scope
from .identity import (
    IdentityProvider,
    KeyPair,
    MLDSALevel,
    generate_agent_id,
    parse_algorithm,
)
from .revocation import RevocationList, RevocationReason, get_revocation_list, is_revoked
from .session import LocalStorage, Session
from .tokens import PQCToken, TokenClaims, TokenIssuer, TokenVerifier, assess_token_risk


@dataclass
class AgentConfig:
    """Configuration for a SecureAgent."""

    name: str
    algorithm: MLDSALevel = MLDSALevel.ML_DSA_65
    capabilities: list[str] = field(default_factory=list)
    issuer: str = "asqav"
    token_ttl: int = 3600
    metadata: dict[str, Any] = field(default_factory=dict)


class SecureAgent:
    """A quantum-safe AI agent with identity, tokens, and monitoring.

    This is the main class for creating and managing secure AI agent
    identities using post-quantum cryptography (ML-DSA).

    Example:
        agent = SecureAgent.create(
            name="my-agent",
            algorithm="ml-dsa-65",
            capabilities=["read:data", "write:logs"]
        )

        with agent.session() as session:
            session.log_action("read:data", {"file": "config.json"})
    """

    def __init__(
        self,
        agent_id: str,
        name: str,
        keypair: KeyPair,
        capabilities: list[str],
        issuer: str = "asqav",
        token_ttl: int = 3600,
        metadata: dict[str, Any] | None = None,
        created_at: float | None = None,
    ) -> None:
        """Initialize a SecureAgent.

        Args:
            agent_id: Unique identifier for the agent.
            name: Human-readable name for the agent.
            keypair: ML-DSA key pair for signing.
            capabilities: List of capabilities/permissions.
            issuer: Token issuer identifier.
            token_ttl: Default token time-to-live in seconds.
            metadata: Optional metadata.
            created_at: Creation timestamp.
        """
        self.agent_id = agent_id
        self.name = name
        self.keypair = keypair
        self.capabilities = capabilities
        self.issuer = issuer
        self.token_ttl = token_ttl
        self.metadata = metadata or {}
        self.created_at = created_at or time.time()

        self._token_issuer = TokenIssuer(keypair, issuer, token_ttl)
        self._storage: LocalStorage | None = None
        self._delegation_chain: DelegationChain | None = None
        self._revocation_list: RevocationList | None = None

    @classmethod
    def create(
        cls,
        name: str,
        algorithm: str | MLDSALevel = "ml-dsa-65",
        capabilities: list[str] | None = None,
        issuer: str = "asqav",
        token_ttl: int = 3600,
        metadata: dict[str, Any] | None = None,
    ) -> SecureAgent:
        """Create a new SecureAgent with a fresh identity.

        Args:
            name: Human-readable name for the agent.
            algorithm: ML-DSA algorithm to use (default: ml-dsa-65).
            capabilities: List of capabilities/permissions.
            issuer: Token issuer identifier.
            token_ttl: Default token time-to-live in seconds.
            metadata: Optional metadata.

        Returns:
            A new SecureAgent instance.
        """
        if isinstance(algorithm, str):
            algorithm = parse_algorithm(algorithm)

        identity = IdentityProvider(algorithm)
        keypair = identity.generate_keypair()
        agent_id = generate_agent_id()

        return cls(
            agent_id=agent_id,
            name=name,
            keypair=keypair,
            capabilities=capabilities or [],
            issuer=issuer,
            token_ttl=token_ttl,
            metadata=metadata,
        )

    @property
    def public_key(self) -> bytes:
        """Get the agent's public key."""
        return self.keypair.public_key

    @property
    def public_key_b64(self) -> str:
        """Get the agent's public key as base64."""
        return self.keypair.public_key_b64

    @property
    def key_id(self) -> str:
        """Get the agent's key ID."""
        return self.keypair.key_id

    @property
    def algorithm(self) -> MLDSALevel:
        """Get the agent's algorithm."""
        return self.keypair.algorithm

    def issue_token(
        self,
        scope: list[str] | None = None,
        ttl: int | None = None,
        audience: str | list[str] | None = None,
        custom_claims: dict[str, Any] | None = None,
    ) -> PQCToken:
        """Issue a token for this agent.

        Args:
            scope: Capabilities to include (default: all).
            ttl: Token time-to-live in seconds.
            audience: Intended audience(s).
            custom_claims: Additional claims.

        Returns:
            A signed PQCToken.
        """
        return self._token_issuer.issue(
            subject=self.agent_id,
            scope=scope or self.capabilities,
            ttl=ttl,
            audience=audience,
            custom_claims=custom_claims,
        )

    def issue_token_string(
        self,
        scope: list[str] | None = None,
        ttl: int | None = None,
    ) -> str:
        """Issue a token and return as encoded string.

        Args:
            scope: Capabilities to include (default: all).
            ttl: Token time-to-live in seconds.

        Returns:
            The encoded token string.
        """
        return self.issue_token(scope=scope, ttl=ttl).encode()

    @contextmanager
    def session(
        self,
        session_id: str | None = None,
    ) -> Generator[Session, None, None]:
        """Create a runtime monitoring session.

        Args:
            session_id: Optional custom session ID.

        Yields:
            A Session object for logging actions.
        """
        if self._storage is None:
            self._storage = LocalStorage()

        session = Session(
            agent=self,
            storage=self._storage,
            session_id=session_id,
        )

        session.start()
        try:
            yield session
        except Exception:
            session.end(status="error")
            raise
        else:
            session.end(status="completed")

    def delegate_to(
        self,
        name: str,
        scope: list[str] | None = None,
        algorithm: str | MLDSALevel | None = None,
        ttl: int | None = None,
    ) -> SecureAgent:
        """Create a delegated sub-agent.

        Args:
            name: Name for the sub-agent.
            scope: Capabilities to delegate (must be subset of own).
            algorithm: Algorithm for sub-agent (default: same as self).
            ttl: Token TTL for sub-agent.

        Returns:
            A new SecureAgent with delegated capabilities.

        Raises:
            ValueError: If scope exceeds own capabilities.
        """
        delegated_scope = attenuate_scope(self.capabilities, scope)

        if algorithm is None:
            algorithm = self.algorithm
        elif isinstance(algorithm, str):
            algorithm = parse_algorithm(algorithm)

        sub_agent = SecureAgent.create(
            name=name,
            algorithm=algorithm,
            capabilities=delegated_scope,
            issuer=self.issuer,
            token_ttl=ttl or self.token_ttl,
            metadata={"delegator": self.agent_id},
        )

        # Register delegation in revocation list for propagation
        revocation_list = self._revocation_list or get_revocation_list()
        revocation_list.register_delegation(self.agent_id, sub_agent.agent_id)

        return sub_agent

    def revoke(
        self,
        reason: RevocationReason = RevocationReason.MANUAL,
        propagate: bool = True,
    ) -> None:
        """Revoke this agent's credentials.

        Args:
            reason: Reason for revocation.
            propagate: Whether to propagate to delegated agents.
        """
        revocation_list = self._revocation_list or get_revocation_list()
        revocation_list.revoke(
            self.agent_id,
            reason=reason,
            propagate=propagate,
        )

    @property
    def is_revoked(self) -> bool:
        """Check if this agent is revoked."""
        return is_revoked(self.agent_id)

    def to_dict(self) -> dict[str, Any]:
        """Convert agent to dictionary (excludes secret key).

        Returns:
            Dictionary representation of the agent.
        """
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "public_key": self.public_key_b64,
            "key_id": self.key_id,
            "algorithm": self.algorithm.value,
            "capabilities": self.capabilities,
            "issuer": self.issuer,
            "created_at": self.created_at,
            "metadata": self.metadata,
        }

    @staticmethod
    def verify(
        token: str | PQCToken,
        public_key: bytes,
        verify_exp: bool = True,
    ) -> TokenClaims:
        """Verify a token from another agent.

        Args:
            token: The token to verify.
            public_key: Public key of the issuing agent.
            verify_exp: Whether to verify expiration.

        Returns:
            The verified TokenClaims.

        Raises:
            ValueError: If the token is invalid.
        """
        verifier = TokenVerifier()
        return verifier.verify(token, public_key, verify_exp=verify_exp)

    @staticmethod
    def is_agent_revoked(agent_id: str) -> bool:
        """Check if an agent ID is revoked.

        Args:
            agent_id: The agent ID to check.

        Returns:
            True if the agent is revoked.
        """
        return is_revoked(agent_id)

    @staticmethod
    def assess_risk(token_algorithm: str) -> dict[str, Any]:
        """Assess the quantum security risk of a token algorithm.

        Args:
            token_algorithm: The algorithm (e.g., "ES256", "ML-DSA-65").

        Returns:
            Risk assessment dictionary.
        """
        return assess_token_risk(token_algorithm)


def create_agent(
    name: str,
    algorithm: str = "ml-dsa-65",
    capabilities: list[str] | None = None,
) -> SecureAgent:
    """Convenience function to create a SecureAgent.

    Args:
        name: Human-readable name for the agent.
        algorithm: ML-DSA algorithm to use.
        capabilities: List of capabilities/permissions.

    Returns:
        A new SecureAgent instance.
    """
    return SecureAgent.create(
        name=name,
        algorithm=algorithm,
        capabilities=capabilities,
    )
