"""
Asqav Integrations for AI Agent Frameworks.

Provides quantum-safe identity wrappers for popular AI agent frameworks:
- OpenCode: Terminal-based AI coding agent
- LangChain: Most widely adopted agent framework
- CrewAI: Role-based multi-agent orchestration
- MCP: Model Context Protocol gateway (see asqav.mcp)

Example:
    from asqav.integrations.opencode import OpenCodeSecureAgent
    from asqav.integrations.langchain import LangChainAuthServer
    from asqav.integrations.crewai import SecureCrewAgent

    # OpenCode with quantum-safe identity
    agent = OpenCodeSecureAgent.create(
        name="coding-assistant",
        capabilities=["file:read", "file:write"],
    )

    # LangChain Auth Server
    auth = LangChainAuthServer()
    token = auth.register_agent("analyst", capabilities=["data:read"])

    # CrewAI secure agents
    researcher = SecureCrewAgent.create(
        name="researcher",
        role="Research Analyst",
        capabilities=["web:search"],
    )
"""

from __future__ import annotations

# CrewAI integration
from .crewai import (
    A2AAuditEntry,
    A2AMessage,
    A2AMessageStatus,
    A2AMessageType,
    A2ASecureProtocol,
    SecureCrewAgent,
    TaskDelegation,
    create_secure_crew,
)

# LangChain integration
from .langchain import (
    AuditEntry,
    AuthenticatedAgent,
    AuthRequest,
    AuthResponse,
    AuthResult,
    LangChainAuthServer,
    SecureToolExecutor,
    create_auth_server,
    create_secure_executor,
)

# OpenCode integration
from .opencode import (
    OpenCodeSecureAgent,
    OpenCodeToolCall,
    SignedToolResult,
    create_opencode_agent,
)

__all__ = [
    # OpenCode
    "OpenCodeSecureAgent",
    "OpenCodeToolCall",
    "SignedToolResult",
    "create_opencode_agent",
    # LangChain
    "LangChainAuthServer",
    "SecureToolExecutor",
    "AuthenticatedAgent",
    "AuthRequest",
    "AuthResponse",
    "AuthResult",
    "AuditEntry",
    "create_auth_server",
    "create_secure_executor",
    # CrewAI
    "SecureCrewAgent",
    "A2ASecureProtocol",
    "A2AMessage",
    "A2AMessageType",
    "A2AMessageStatus",
    "A2AAuditEntry",
    "TaskDelegation",
    "create_secure_crew",
]
