"""
OpenCode Integration for Asqav.

Provides quantum-safe identity and audit trail for OpenCode AI coding agents.
Wraps OpenCode agents with ML-DSA signatures for all tool executions.

OpenCode is an open-source AI coding agent for the terminal with:
- Build agent: Full toolkit (file operations, commands, debugging)
- Plan agent: Restricted agent for planning/analysis only
- Subagent delegation for specialized tasks

This integration adds:
- ML-DSA quantum-safe identity for each agent
- Signed audit trail for all tool calls
- Delegation chains with scope attenuation
- Instant revocation propagating to subagents

Example:
    from asqav import OpenCodeSecureAgent

    # Create quantum-safe OpenCode agent
    agent = OpenCodeSecureAgent.create(
        name="coding-assistant",
        agent_type="build",
        capabilities=["file:read", "file:write", "command:execute"],
    )

    # Execute tools with automatic signing
    with agent.session() as session:
        result = agent.execute_tool(
            "file_write",
            {"path": "main.py", "content": "print('hello')"},
        )
        # Result includes ML-DSA signature for verification

    # Delegate to subagent with restricted scope
    test_agent = agent.delegate_to(
        name="test-runner",
        scope=["command:execute"],
    )
"""

from __future__ import annotations

import base64
import hashlib
import json
import uuid
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from ..core.agent import SecureAgent
from ..core.identity import IdentityProvider, Signature, parse_algorithm
from ..core.session import Session


class OpenCodeAgentType(str, Enum):
    """OpenCode agent types."""

    BUILD = "build"  # Full toolkit: file ops, commands, debugging
    PLAN = "plan"  # Restricted: planning/analysis only


class OpenCodeToolType(str, Enum):
    """Standard OpenCode tool categories."""

    FILE_READ = "file:read"
    FILE_WRITE = "file:write"
    FILE_DELETE = "file:delete"
    COMMAND_EXECUTE = "command:execute"
    LSP_DIAGNOSTICS = "lsp:diagnostics"
    LSP_COMPLETION = "lsp:completion"
    SEARCH_CODE = "search:code"
    SEARCH_FILES = "search:files"
    DEBUG_START = "debug:start"
    DEBUG_STEP = "debug:step"


@dataclass
class OpenCodeToolCall:
    """Represents a tool call in OpenCode.

    Attributes:
        tool_id: Unique identifier for this tool call
        tool_name: Name of the tool being called
        tool_type: Category of the tool
        parameters: Tool parameters/arguments
        timestamp: When the call was made
        agent_id: ID of the agent making the call
        session_id: Session this call belongs to
        parent_call_id: If this is a nested call, the parent's ID
    """

    tool_id: str
    tool_name: str
    tool_type: str
    parameters: dict[str, Any]
    timestamp: datetime
    agent_id: str
    session_id: str | None = None
    parent_call_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for signing."""
        return {
            "tool_id": self.tool_id,
            "tool_name": self.tool_name,
            "tool_type": self.tool_type,
            "parameters": self.parameters,
            "timestamp": self.timestamp.isoformat(),
            "agent_id": self.agent_id,
            "session_id": self.session_id,
            "parent_call_id": self.parent_call_id,
        }

    def canonical_bytes(self) -> bytes:
        """Get canonical byte representation for signing."""
        return json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":")).encode()


@dataclass
class SignedToolResult:
    """Result of a tool execution with ML-DSA signature.

    Attributes:
        tool_call: The original tool call
        result: Tool execution result
        success: Whether execution succeeded
        error: Error message if failed
        signature: ML-DSA signature of the call + result
        signature_algorithm: Algorithm used for signing
        signed_at: When the signature was created
    """

    tool_call: OpenCodeToolCall
    result: Any
    success: bool
    error: str | None = None
    signature: bytes = field(default_factory=bytes)
    signature_algorithm: str = "ml-dsa-65"
    signed_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "tool_call": self.tool_call.to_dict(),
            "result": self.result,
            "success": self.success,
            "error": self.error,
            "signature": base64.b64encode(self.signature).decode() if self.signature else None,
            "signature_algorithm": self.signature_algorithm,
            "signed_at": self.signed_at.isoformat(),
        }

    def verify(self, public_key: bytes) -> bool:
        """Verify the signature using the agent's public key.

        Args:
            public_key: ML-DSA public key bytes

        Returns:
            True if signature is valid
        """
        if not self.signature:
            return False

        algorithm = parse_algorithm(self.signature_algorithm)
        provider = IdentityProvider(algorithm)
        message = self._get_signed_content()
        sig = Signature(value=self.signature, algorithm=algorithm, key_id="")
        return provider.verify(message, sig, public_key)

    def _get_signed_content(self) -> bytes:
        """Get the content that was signed."""
        content = {
            "tool_call": self.tool_call.to_dict(),
            "result_hash": hashlib.sha256(
                json.dumps(self.result, sort_keys=True, default=str).encode()
            ).hexdigest(),
            "success": self.success,
            "error": self.error,
        }
        return json.dumps(content, sort_keys=True, separators=(",", ":")).encode()


class OpenCodeSecureAgent:
    """Quantum-safe wrapper for OpenCode agents.

    Provides ML-DSA identity, signed audit trails, and delegation chains
    for OpenCode AI coding agents.

    Attributes:
        secure_agent: Underlying Asqav SecureAgent
        agent_type: OpenCode agent type (build/plan)
        tool_history: List of signed tool results
    """

    def __init__(
        self,
        secure_agent: SecureAgent,
        agent_type: OpenCodeAgentType = OpenCodeAgentType.BUILD,
    ) -> None:
        """Initialize OpenCode secure agent.

        Args:
            secure_agent: Underlying Asqav SecureAgent with ML-DSA identity
            agent_type: OpenCode agent type
        """
        self._secure_agent = secure_agent
        self._agent_type = agent_type
        self._tool_history: list[SignedToolResult] = []
        self._current_session: Session | None = None
        self._identity_provider = IdentityProvider(secure_agent.keypair.algorithm)

    @classmethod
    def create(
        cls,
        name: str,
        agent_type: str | OpenCodeAgentType = OpenCodeAgentType.BUILD,
        algorithm: str = "ml-dsa-65",
        capabilities: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> OpenCodeSecureAgent:
        """Create a new quantum-safe OpenCode agent.

        Args:
            name: Human-readable agent name
            agent_type: "build" or "plan"
            algorithm: ML-DSA algorithm level (ml-dsa-44/65/87)
            capabilities: List of allowed tool types
            metadata: Additional agent metadata

        Returns:
            New OpenCodeSecureAgent instance

        Example:
            agent = OpenCodeSecureAgent.create(
                name="coding-assistant",
                agent_type="build",
                capabilities=["file:read", "file:write"],
            )
        """
        if isinstance(agent_type, str):
            agent_type = OpenCodeAgentType(agent_type.lower())

        # Default capabilities based on agent type
        if capabilities is None:
            if agent_type == OpenCodeAgentType.BUILD:
                capabilities = [
                    OpenCodeToolType.FILE_READ.value,
                    OpenCodeToolType.FILE_WRITE.value,
                    OpenCodeToolType.FILE_DELETE.value,
                    OpenCodeToolType.COMMAND_EXECUTE.value,
                    OpenCodeToolType.LSP_DIAGNOSTICS.value,
                    OpenCodeToolType.SEARCH_CODE.value,
                    OpenCodeToolType.SEARCH_FILES.value,
                ]
            else:  # PLAN
                capabilities = [
                    OpenCodeToolType.FILE_READ.value,
                    OpenCodeToolType.SEARCH_CODE.value,
                    OpenCodeToolType.SEARCH_FILES.value,
                ]

        # Create underlying SecureAgent
        agent_metadata = metadata or {}
        agent_metadata["opencode_agent_type"] = agent_type.value

        secure_agent = SecureAgent.create(
            name=name,
            algorithm=algorithm,
            capabilities=capabilities,
            metadata=agent_metadata,
        )

        return cls(secure_agent, agent_type)

    @property
    def agent_id(self) -> str:
        """Get unique agent identifier."""
        return self._secure_agent.agent_id

    @property
    def name(self) -> str:
        """Get agent name."""
        return self._secure_agent.name

    @property
    def agent_type(self) -> OpenCodeAgentType:
        """Get OpenCode agent type."""
        return self._agent_type

    @property
    def public_key(self) -> bytes:
        """Get agent's ML-DSA public key."""
        return self._secure_agent.public_key

    @property
    def public_key_b64(self) -> str:
        """Get base64-encoded public key."""
        return self._secure_agent.public_key_b64

    @property
    def capabilities(self) -> list[str]:
        """Get agent's capabilities (allowed tool types)."""
        return self._secure_agent.capabilities

    @property
    def is_revoked(self) -> bool:
        """Check if agent has been revoked."""
        return self._secure_agent.is_revoked

    @property
    def tool_history(self) -> list[SignedToolResult]:
        """Get history of signed tool executions."""
        return self._tool_history.copy()

    @contextmanager
    def session(
        self, session_id: str | None = None
    ) -> Generator[Session, None, None]:
        """Create a monitoring session for this agent.

        Args:
            session_id: Optional session ID (auto-generated if not provided)

        Yields:
            Session object for logging actions
        """
        with self._secure_agent.session(session_id) as sess:
            self._current_session = sess
            try:
                yield sess
            finally:
                self._current_session = None

    def execute_tool(
        self,
        tool_name: str,
        parameters: dict[str, Any],
        tool_type: str | None = None,
        executor: Any | None = None,
    ) -> SignedToolResult:
        """Execute a tool with quantum-safe signing.

        Args:
            tool_name: Name of the tool to execute
            parameters: Tool parameters
            tool_type: Tool category (inferred from name if not provided)
            executor: Optional callable to actually execute the tool

        Returns:
            SignedToolResult with ML-DSA signature

        Raises:
            PermissionError: If agent lacks capability for this tool type
            RuntimeError: If agent has been revoked
        """
        if self.is_revoked:
            raise RuntimeError(f"Agent {self.agent_id} has been revoked")

        # Infer tool type from name if not provided
        if tool_type is None:
            tool_type = self._infer_tool_type(tool_name)

        # Check capability
        if not self._has_capability(tool_type):
            raise PermissionError(
                f"Agent lacks capability '{tool_type}' for tool '{tool_name}'"
            )

        # Create tool call record
        tool_call = OpenCodeToolCall(
            tool_id=str(uuid.uuid4()),
            tool_name=tool_name,
            tool_type=tool_type,
            parameters=parameters,
            timestamp=datetime.now(tz=UTC),
            agent_id=self.agent_id,
            session_id=self._current_session.session_id if self._current_session else None,
        )

        # Execute tool if executor provided
        result = None
        success = True
        error = None

        if executor is not None:
            try:
                result = executor(tool_name, parameters)
            except Exception as e:
                success = False
                error = str(e)
        else:
            # Mock execution for testing/demonstration
            result = {"status": "executed", "tool": tool_name}

        # Create signed result
        signed_result = SignedToolResult(
            tool_call=tool_call,
            result=result,
            success=success,
            error=error,
            signature_algorithm=self._secure_agent.keypair.algorithm.value,
        )

        # Sign the result
        signed_result.signature = self._sign_result(signed_result)

        # Log to session if active
        if self._current_session:
            self._current_session.log_action(
                f"tool:{tool_name}",
                metadata={
                    "tool_id": tool_call.tool_id,
                    "tool_type": tool_type,
                    "parameters": parameters,
                    "success": success,
                    "signature": base64.b64encode(signed_result.signature).decode(),
                },
            )

        # Add to history
        self._tool_history.append(signed_result)

        return signed_result

    def delegate_to(
        self,
        name: str,
        scope: list[str] | None = None,
        agent_type: str | OpenCodeAgentType = OpenCodeAgentType.BUILD,
        ttl: int | None = None,
    ) -> OpenCodeSecureAgent:
        """Delegate to a subagent with restricted scope.

        Args:
            name: Name for the subagent
            scope: Allowed capabilities (must be subset of parent's)
            agent_type: OpenCode agent type for subagent
            ttl: Time-to-live in seconds

        Returns:
            New OpenCodeSecureAgent with restricted capabilities

        Example:
            test_agent = build_agent.delegate_to(
                name="test-runner",
                scope=["command:execute"],
            )
        """
        if isinstance(agent_type, str):
            agent_type = OpenCodeAgentType(agent_type.lower())

        # Delegate underlying SecureAgent
        delegated = self._secure_agent.delegate_to(
            name=name,
            scope=scope,
            ttl=ttl,
        )

        return OpenCodeSecureAgent(delegated, agent_type)

    def revoke(self, reason: str = "manual") -> None:
        """Revoke this agent and all its delegates.

        Args:
            reason: Reason for revocation
        """
        from ..core.revocation import RevocationReason

        reason_enum = RevocationReason.MANUAL
        if reason == "compromised":
            reason_enum = RevocationReason.COMPROMISED
        elif reason == "policy_violation":
            reason_enum = RevocationReason.POLICY_VIOLATION

        self._secure_agent.revoke(reason=reason_enum, propagate=True)

    def issue_token(
        self,
        scope: list[str] | None = None,
        ttl: int = 3600,
        audience: str | None = None,
    ) -> str:
        """Issue a PQC-JWT token for this agent.

        Args:
            scope: Token scope (defaults to agent's capabilities)
            ttl: Time-to-live in seconds
            audience: Token audience

        Returns:
            Encoded PQC-JWT token string
        """
        return self._secure_agent.issue_token(
            scope=scope,
            ttl=ttl,
            audience=audience,
        ).encode()

    def to_dict(self) -> dict[str, Any]:
        """Serialize agent to dictionary (excludes secret key).

        Returns:
            Dictionary with agent details
        """
        base = self._secure_agent.to_dict()
        base["opencode_agent_type"] = self._agent_type.value
        base["tool_history_count"] = len(self._tool_history)
        return base

    def _sign_result(self, result: SignedToolResult) -> bytes:
        """Sign a tool result with the agent's ML-DSA key."""
        content = result._get_signed_content()
        signature = self._identity_provider.sign(content, self._secure_agent.keypair)
        return signature.value

    def _has_capability(self, tool_type: str) -> bool:
        """Check if agent has capability for a tool type."""
        # Exact match
        if tool_type in self.capabilities:
            return True

        # Wildcard match (e.g., "file:*" matches "file:read")
        for cap in self.capabilities:
            if cap.endswith(":*"):
                prefix = cap[:-1]  # Remove "*"
                if tool_type.startswith(prefix):
                    return True

        return False

    def _infer_tool_type(self, tool_name: str) -> str:
        """Infer tool type from tool name."""
        name_lower = tool_name.lower()

        if "read" in name_lower or "get" in name_lower or "cat" in name_lower:
            return OpenCodeToolType.FILE_READ.value
        elif "write" in name_lower or "create" in name_lower or "save" in name_lower:
            return OpenCodeToolType.FILE_WRITE.value
        elif "delete" in name_lower or "remove" in name_lower or "rm" in name_lower:
            return OpenCodeToolType.FILE_DELETE.value
        elif "exec" in name_lower or "run" in name_lower or "command" in name_lower:
            return OpenCodeToolType.COMMAND_EXECUTE.value
        elif "search" in name_lower or "find" in name_lower or "grep" in name_lower:
            return OpenCodeToolType.SEARCH_CODE.value
        elif "diagnostic" in name_lower or "lint" in name_lower:
            return OpenCodeToolType.LSP_DIAGNOSTICS.value
        elif "complete" in name_lower or "suggest" in name_lower:
            return OpenCodeToolType.LSP_COMPLETION.value
        elif "debug" in name_lower:
            return OpenCodeToolType.DEBUG_START.value

        # Default to file read as safest
        return OpenCodeToolType.FILE_READ.value


def create_opencode_agent(
    name: str,
    agent_type: str = "build",
    algorithm: str = "ml-dsa-65",
    capabilities: list[str] | None = None,
) -> OpenCodeSecureAgent:
    """Convenience function to create an OpenCode secure agent.

    Args:
        name: Agent name
        agent_type: "build" or "plan"
        algorithm: ML-DSA algorithm
        capabilities: Allowed tool types

    Returns:
        New OpenCodeSecureAgent

    Example:
        agent = create_opencode_agent("my-agent", agent_type="build")
    """
    return OpenCodeSecureAgent.create(
        name=name,
        agent_type=agent_type,
        algorithm=algorithm,
        capabilities=capabilities,
    )
