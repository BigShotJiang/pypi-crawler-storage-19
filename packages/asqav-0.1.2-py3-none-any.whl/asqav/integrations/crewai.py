"""
CrewAI A2A Protocol Extension for Asqav.

Extends CrewAI's Agent-to-Agent (A2A) protocol with quantum-safe ML-DSA
signatures for secure inter-agent communication.

CrewAI is a role-based multi-agent orchestration framework where agents:
- Have specific roles and goals
- Use tools to accomplish tasks
- Collaborate on complex workflows
- Communicate via the A2A protocol

This integration adds:
- ML-DSA signed A2A messages between agents
- Quantum-safe token exchange for agent authentication
- Verifiable delegation chains for task handoffs
- Signed audit trail for all inter-agent communications

Example:
    from asqav.integrations.crewai import (
        A2ASecureProtocol,
        SecureCrewAgent,
        create_secure_crew,
    )

    # Create secure agents
    researcher = SecureCrewAgent.create(
        name="researcher",
        role="Research Analyst",
        capabilities=["web:search", "data:analyze"],
    )

    writer = SecureCrewAgent.create(
        name="writer",
        role="Content Writer",
        capabilities=["content:write", "content:edit"],
    )

    # Create secure A2A protocol
    protocol = A2ASecureProtocol()

    # Send signed message between agents
    message = protocol.create_message(
        sender=researcher,
        recipient=writer,
        content={"task": "write_report", "data": {...}},
    )

    # Recipient verifies message
    is_valid = protocol.verify_message(message, researcher.public_key)
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from ..core.agent import SecureAgent
from ..core.identity import IdentityProvider, Signature


class A2AMessageType(str, Enum):
    """Types of A2A messages."""

    TASK_REQUEST = "task_request"
    TASK_RESPONSE = "task_response"
    TASK_DELEGATION = "task_delegation"
    STATUS_UPDATE = "status_update"
    ERROR = "error"
    HANDOFF = "handoff"


class A2AMessageStatus(str, Enum):
    """Status of A2A messages."""

    PENDING = "pending"
    DELIVERED = "delivered"
    VERIFIED = "verified"
    REJECTED = "rejected"
    EXPIRED = "expired"


@dataclass
class A2AMessage:
    """A signed Agent-to-Agent message.

    Attributes:
        message_id: Unique identifier
        sender_id: ID of the sending agent
        recipient_id: ID of the receiving agent
        message_type: Type of message
        content: Message payload
        timestamp: When the message was created
        signature: ML-DSA signature (base64)
        parent_message_id: ID of message this is responding to
        ttl: Time-to-live in seconds
        metadata: Additional metadata
    """

    message_id: str
    sender_id: str
    recipient_id: str
    message_type: A2AMessageType
    content: dict[str, Any]
    timestamp: float
    signature: str
    parent_message_id: str | None = None
    ttl: int = 3600
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "message_id": self.message_id,
            "sender_id": self.sender_id,
            "recipient_id": self.recipient_id,
            "message_type": self.message_type.value,
            "content": self.content,
            "timestamp": self.timestamp,
            "signature": self.signature,
            "parent_message_id": self.parent_message_id,
            "ttl": self.ttl,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> A2AMessage:
        """Create from dictionary."""
        return cls(
            message_id=data["message_id"],
            sender_id=data["sender_id"],
            recipient_id=data["recipient_id"],
            message_type=A2AMessageType(data["message_type"]),
            content=data["content"],
            timestamp=data["timestamp"],
            signature=data["signature"],
            parent_message_id=data.get("parent_message_id"),
            ttl=data.get("ttl", 3600),
            metadata=data.get("metadata", {}),
        )

    def get_signing_payload(self) -> bytes:
        """Get the payload for signing/verification."""
        payload = {
            "message_id": self.message_id,
            "sender_id": self.sender_id,
            "recipient_id": self.recipient_id,
            "message_type": self.message_type.value,
            "content": self.content,
            "timestamp": self.timestamp,
            "parent_message_id": self.parent_message_id,
        }
        return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()

    def is_expired(self) -> bool:
        """Check if the message has expired."""
        return time.time() > (self.timestamp + self.ttl)


@dataclass
class TaskDelegation:
    """Represents a task delegation between agents.

    Attributes:
        delegation_id: Unique identifier
        delegator_id: Agent delegating the task
        delegate_id: Agent receiving the delegation
        task: Task description
        scope: Allowed scope for the delegation
        token: Delegation token (ML-DSA signed)
        created_at: When delegation was created
        expires_at: When delegation expires
    """

    delegation_id: str
    delegator_id: str
    delegate_id: str
    task: dict[str, Any]
    scope: list[str]
    token: str
    created_at: float
    expires_at: float

    def is_expired(self) -> bool:
        """Check if the delegation has expired."""
        return time.time() > self.expires_at


@dataclass
class A2AAuditEntry:
    """Audit entry for A2A communications."""

    entry_id: str
    message_id: str
    sender_id: str
    recipient_id: str
    message_type: A2AMessageType
    status: A2AMessageStatus
    timestamp: float
    verified: bool
    metadata: dict[str, Any] = field(default_factory=dict)


class SecureCrewAgent:
    """A CrewAI agent with quantum-safe identity.

    Wraps CrewAI agent concepts with ML-DSA cryptographic identity
    for secure A2A communications.

    Example:
        agent = SecureCrewAgent.create(
            name="research-analyst",
            role="Senior Research Analyst",
            goal="Find and analyze relevant information",
            capabilities=["web:search", "data:analyze"],
        )

        # Issue token for A2A auth
        token = agent.issue_a2a_token(scope=["data:analyze"])
    """

    def __init__(
        self,
        agent: SecureAgent,
        role: str,
        goal: str = "",
        backstory: str = "",
    ) -> None:
        """Initialize the secure crew agent.

        Args:
            agent: The underlying SecureAgent
            role: Agent's role in the crew
            goal: Agent's goal
            backstory: Agent's backstory
        """
        self._agent = agent
        self.role = role
        self.goal = goal
        self.backstory = backstory
        self._identity = IdentityProvider(agent.algorithm)

    @classmethod
    def create(
        cls,
        name: str,
        role: str,
        goal: str = "",
        backstory: str = "",
        capabilities: list[str] | None = None,
        algorithm: str = "ml-dsa-65",
    ) -> SecureCrewAgent:
        """Create a new secure crew agent.

        Args:
            name: Agent name
            role: Agent's role
            goal: Agent's goal
            backstory: Agent's backstory
            capabilities: List of capabilities
            algorithm: ML-DSA algorithm

        Returns:
            New SecureCrewAgent
        """
        agent = SecureAgent.create(
            name=name,
            algorithm=algorithm,
            capabilities=capabilities or [],
            metadata={"role": role, "goal": goal},
        )
        return cls(agent, role, goal, backstory)

    @property
    def agent_id(self) -> str:
        """Get the agent ID."""
        return self._agent.agent_id

    @property
    def name(self) -> str:
        """Get the agent name."""
        return self._agent.name

    @property
    def capabilities(self) -> list[str]:
        """Get the agent's capabilities."""
        return self._agent.capabilities

    @property
    def public_key(self) -> bytes:
        """Get the agent's public key."""
        return self._agent.public_key

    @property
    def public_key_b64(self) -> str:
        """Get the agent's public key as base64."""
        return self._agent.public_key_b64

    def issue_a2a_token(
        self,
        scope: list[str] | None = None,
        ttl: int = 3600,
    ) -> str:
        """Issue a token for A2A authentication.

        Args:
            scope: Token scope (default: all capabilities)
            ttl: Token TTL in seconds

        Returns:
            Encoded token string
        """
        return self._agent.issue_token_string(scope=scope, ttl=ttl)

    def sign_message(self, message: bytes) -> bytes:
        """Sign a message.

        Args:
            message: Message bytes to sign

        Returns:
            Signature bytes
        """
        sig = self._identity.sign(message, self._agent.keypair)
        return sig.value

    def verify_signature(
        self,
        message: bytes,
        signature: bytes,
        public_key: bytes | None = None,
    ) -> bool:
        """Verify a signature.

        Args:
            message: Original message bytes
            signature: Signature bytes
            public_key: Public key (default: own key)

        Returns:
            True if valid
        """
        if public_key is None:
            public_key = self._agent.public_key

        sig_obj = Signature(
            value=signature,
            algorithm=self._agent.algorithm,
            key_id="",
        )

        try:
            return self._identity.verify(message, sig_obj, public_key)
        except Exception:
            return False

    def delegate_to(
        self,
        name: str,
        role: str,
        scope: list[str] | None = None,
    ) -> SecureCrewAgent:
        """Delegate to a sub-agent with restricted scope.

        Args:
            name: Sub-agent name
            role: Sub-agent role
            scope: Allowed scope

        Returns:
            New SecureCrewAgent with delegated authority
        """
        sub_agent = self._agent.delegate_to(
            name=name,
            scope=scope,
        )
        return SecureCrewAgent(
            agent=sub_agent,
            role=role,
            goal=f"Delegated from {self.name}",
        )


class A2ASecureProtocol:
    """Secure A2A protocol with ML-DSA signatures.

    Provides message signing, verification, and audit logging
    for CrewAI agent communications.

    Example:
        protocol = A2ASecureProtocol()

        # Create signed message
        message = protocol.create_message(
            sender=agent1,
            recipient=agent2,
            message_type=A2AMessageType.TASK_REQUEST,
            content={"task": "analyze_data"},
        )

        # Verify message
        is_valid = protocol.verify_message(message, agent1.public_key)
    """

    def __init__(self) -> None:
        """Initialize the protocol."""
        self._messages: dict[str, A2AMessage] = {}
        self._delegations: dict[str, TaskDelegation] = {}
        self._audit_log: list[A2AAuditEntry] = []
        self._identity = IdentityProvider()

    def create_message(
        self,
        sender: SecureCrewAgent,
        recipient: SecureCrewAgent,
        message_type: A2AMessageType,
        content: dict[str, Any],
        parent_message_id: str | None = None,
        ttl: int = 3600,
        metadata: dict[str, Any] | None = None,
    ) -> A2AMessage:
        """Create a signed A2A message.

        Args:
            sender: Sending agent
            recipient: Receiving agent
            message_type: Type of message
            content: Message content
            parent_message_id: Parent message ID
            ttl: Time-to-live
            metadata: Additional metadata

        Returns:
            Signed A2AMessage
        """
        import base64

        message_id = f"msg_{uuid.uuid4().hex[:12]}"
        timestamp = time.time()

        # Create message without signature
        message = A2AMessage(
            message_id=message_id,
            sender_id=sender.agent_id,
            recipient_id=recipient.agent_id,
            message_type=message_type,
            content=content,
            timestamp=timestamp,
            signature="",
            parent_message_id=parent_message_id,
            ttl=ttl,
            metadata=metadata or {},
        )

        # Sign the message
        payload = message.get_signing_payload()
        signature = sender.sign_message(payload)
        message.signature = base64.b64encode(signature).decode()

        # Store message
        self._messages[message_id] = message

        # Log
        self._log_message(message, A2AMessageStatus.PENDING, verified=False)

        return message

    def verify_message(
        self,
        message: A2AMessage,
        public_key: bytes,
    ) -> bool:
        """Verify a message signature.

        Args:
            message: The message to verify
            public_key: Sender's public key

        Returns:
            True if signature is valid
        """
        import base64

        if message.is_expired():
            self._log_message(message, A2AMessageStatus.EXPIRED, verified=False)
            return False

        payload = message.get_signing_payload()
        signature = base64.b64decode(message.signature)

        sig_obj = Signature(
            value=signature,
            algorithm=self._identity.algorithm,
            key_id="",
        )

        try:
            is_valid = self._identity.verify(payload, sig_obj, public_key)
            status = A2AMessageStatus.VERIFIED if is_valid else A2AMessageStatus.REJECTED
            self._log_message(message, status, verified=is_valid)
            return is_valid
        except Exception:
            self._log_message(message, A2AMessageStatus.REJECTED, verified=False)
            return False

    def create_delegation(
        self,
        delegator: SecureCrewAgent,
        delegate: SecureCrewAgent,
        task: dict[str, Any],
        scope: list[str],
        ttl: int = 3600,
    ) -> TaskDelegation:
        """Create a task delegation with signed token.

        Args:
            delegator: Agent delegating the task
            delegate: Agent receiving the delegation
            task: Task to delegate
            scope: Allowed scope
            ttl: Delegation TTL

        Returns:
            TaskDelegation with signed token
        """
        delegation_id = f"del_{uuid.uuid4().hex[:12]}"
        now = time.time()

        # Issue delegation token
        token = delegator._agent.issue_token_string(scope=scope, ttl=ttl)

        delegation = TaskDelegation(
            delegation_id=delegation_id,
            delegator_id=delegator.agent_id,
            delegate_id=delegate.agent_id,
            task=task,
            scope=scope,
            token=token,
            created_at=now,
            expires_at=now + ttl,
        )

        self._delegations[delegation_id] = delegation
        return delegation

    def _log_message(
        self,
        message: A2AMessage,
        status: A2AMessageStatus,
        verified: bool,
    ) -> None:
        """Log a message to audit trail."""
        entry = A2AAuditEntry(
            entry_id=f"audit_{uuid.uuid4().hex[:8]}",
            message_id=message.message_id,
            sender_id=message.sender_id,
            recipient_id=message.recipient_id,
            message_type=message.message_type,
            status=status,
            timestamp=time.time(),
            verified=verified,
        )
        self._audit_log.append(entry)

    def get_audit_log(
        self,
        agent_id: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get the audit log.

        Args:
            agent_id: Filter by agent ID
            limit: Maximum entries

        Returns:
            List of audit entries
        """
        entries = self._audit_log
        if agent_id:
            entries = [
                e for e in entries
                if e.sender_id == agent_id or e.recipient_id == agent_id
            ]

        return [
            {
                "entry_id": e.entry_id,
                "message_id": e.message_id,
                "sender_id": e.sender_id,
                "recipient_id": e.recipient_id,
                "message_type": e.message_type.value,
                "status": e.status.value,
                "timestamp": e.timestamp,
                "verified": e.verified,
            }
            for e in entries[-limit:]
        ]


def create_secure_crew(
    agents: list[dict[str, Any]],
    algorithm: str = "ml-dsa-65",
) -> list[SecureCrewAgent]:
    """Create a secure crew of agents.

    Args:
        agents: List of agent configurations
        algorithm: ML-DSA algorithm

    Returns:
        List of SecureCrewAgents

    Example:
        crew = create_secure_crew([
            {"name": "researcher", "role": "Researcher", "capabilities": ["web:search"]},
            {"name": "writer", "role": "Writer", "capabilities": ["content:write"]},
        ])
    """
    return [
        SecureCrewAgent.create(
            name=agent["name"],
            role=agent["role"],
            goal=agent.get("goal", ""),
            backstory=agent.get("backstory", ""),
            capabilities=agent.get("capabilities", []),
            algorithm=algorithm,
        )
        for agent in agents
    ]
