"""
LangChain Agent Auth Server Integration for Asqav.

Provides quantum-safe authentication and authorization for LangChain agents.
Implements the "Agent Auth Server" pattern recommended by LangChain/LangGraph
documentation, using ML-DSA post-quantum cryptography.

This integration provides:
- Token issuance for LangChain agents with ML-DSA signatures
- Token verification middleware for tool execution
- Scope-based authorization for agent capabilities
- Audit logging for all authenticated operations
- Agent identity verification across multi-agent systems

Example:
    from asqav.integrations.langchain import (
        LangChainAuthServer,
        SecureToolExecutor,
        create_auth_server,
    )

    # Create the auth server
    auth_server = create_auth_server(name="langchain-auth")

    # Register an agent and get a token
    token = auth_server.register_agent(
        name="research-agent",
        capabilities=["web:search", "file:read"],
    )

    # Create a secure tool executor
    executor = SecureToolExecutor(auth_server)

    # Execute tools with authentication
    result = executor.execute(
        tool_name="web_search",
        args={"query": "quantum computing"},
        token=token,
    )

LangGraph Integration:
    from langgraph.graph import StateGraph
    from asqav.integrations.langchain import LangChainAuthServer

    auth = LangChainAuthServer()

    # Create authenticated node
    def search_node(state, config):
        token = config.get("token")
        if not auth.verify_token(token, required_scope="web:search"):
            raise PermissionError("Unauthorized")
        # ... execute search
"""

from __future__ import annotations

import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from ..core.agent import SecureAgent
from ..core.identity import IdentityProvider, parse_algorithm
from ..core.tokens import TokenVerifier


class AuthResult(str, Enum):
    """Authentication result status."""

    SUCCESS = "success"
    INVALID_TOKEN = "invalid_token"
    EXPIRED_TOKEN = "expired_token"
    INSUFFICIENT_SCOPE = "insufficient_scope"
    REVOKED = "revoked"


@dataclass
class AuthenticatedAgent:
    """Represents an authenticated LangChain agent.

    Attributes:
        agent_id: Unique identifier for the agent
        name: Human-readable agent name
        capabilities: List of granted capabilities/scopes
        token: The agent's auth token
        public_key_b64: Base64 encoded public key for verification
        created_at: When the agent was registered
        metadata: Additional agent metadata
    """

    agent_id: str
    name: str
    capabilities: list[str]
    token: str
    public_key_b64: str
    created_at: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AuthRequest:
    """Authentication request for tool execution.

    Attributes:
        token: The bearer token
        required_scope: Scope required for this operation
        tool_name: Name of the tool being called
        arguments: Tool arguments
        timestamp: Request timestamp
    """

    token: str
    required_scope: str | None = None
    tool_name: str = ""
    arguments: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


@dataclass
class AuthResponse:
    """Authentication response.

    Attributes:
        result: Authentication result status
        agent_id: ID of the authenticated agent (if successful)
        claims: Token claims (if successful)
        error: Error message (if failed)
        timestamp: Response timestamp
    """

    result: AuthResult
    agent_id: str | None = None
    claims: dict[str, Any] | None = None
    error: str | None = None
    timestamp: float = field(default_factory=time.time)


@dataclass
class AuditEntry:
    """Audit log entry for authenticated operations.

    Attributes:
        entry_id: Unique entry identifier
        agent_id: ID of the agent
        tool_name: Tool that was called
        auth_result: Authentication result
        timestamp: When the operation occurred
        duration_ms: Operation duration in milliseconds
        metadata: Additional metadata
    """

    entry_id: str
    agent_id: str
    tool_name: str
    auth_result: AuthResult
    timestamp: float
    duration_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


class LangChainAuthServer:
    """Agent Auth Server for LangChain/LangGraph agents.

    Provides centralized authentication and authorization for LangChain
    agents using quantum-safe ML-DSA signatures.

    Example:
        auth_server = LangChainAuthServer(name="my-auth-server")

        # Register agent
        token = auth_server.register_agent(
            name="data-analyst",
            capabilities=["file:read", "db:query"],
        )

        # Verify token before tool execution
        response = auth_server.authenticate(AuthRequest(
            token=token,
            required_scope="file:read",
            tool_name="read_file",
        ))

        if response.result == AuthResult.SUCCESS:
            # Execute tool
            pass
    """

    def __init__(
        self,
        name: str = "langchain-auth-server",
        algorithm: str = "ml-dsa-65",
        token_ttl: int = 3600,
    ) -> None:
        """Initialize the auth server.

        Args:
            name: Name of the auth server
            algorithm: ML-DSA algorithm for signing
            token_ttl: Default token time-to-live in seconds
        """
        self.name = name
        self.algorithm = parse_algorithm(algorithm)
        self.token_ttl = token_ttl

        # Server's own identity for signing
        self._server_agent = SecureAgent.create(
            name=name,
            algorithm=algorithm,
            capabilities=["auth:*"],
        )

        # Registered agents
        self._agents: dict[str, SecureAgent] = {}
        self._agent_tokens: dict[str, str] = {}  # agent_id -> token
        self._token_to_agent: dict[str, str] = {}  # token -> agent_id

        # Audit log
        self._audit_log: list[AuditEntry] = []

        # Identity provider for verification
        self._identity = IdentityProvider(self.algorithm)
        self._verifier = TokenVerifier()

    @property
    def server_id(self) -> str:
        """Get the auth server's agent ID."""
        return self._server_agent.agent_id

    @property
    def public_key_b64(self) -> str:
        """Get the server's public key as base64."""
        return self._server_agent.public_key_b64

    def register_agent(
        self,
        name: str,
        capabilities: list[str] | None = None,
        algorithm: str | None = None,
        ttl: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Register a new agent and issue a token.

        Args:
            name: Human-readable agent name
            capabilities: List of granted capabilities
            algorithm: ML-DSA algorithm (default: server's algorithm)
            ttl: Token TTL in seconds (default: server's default)
            metadata: Additional agent metadata

        Returns:
            The issued token string
        """
        # Create agent identity
        agent = SecureAgent.create(
            name=name,
            algorithm=algorithm or self.algorithm.value.lower().replace("-", "-"),
            capabilities=capabilities or [],
            metadata=metadata,
        )

        # Issue token
        token = agent.issue_token_string(
            scope=capabilities,
            ttl=ttl or self.token_ttl,
        )

        # Store mappings
        self._agents[agent.agent_id] = agent
        self._agent_tokens[agent.agent_id] = token
        self._token_to_agent[token] = agent.agent_id

        return token

    def authenticate(self, request: AuthRequest) -> AuthResponse:
        """Authenticate a request.

        Args:
            request: The authentication request

        Returns:
            AuthResponse with result and details
        """
        # Check if token is registered
        if request.token not in self._token_to_agent:
            return AuthResponse(
                result=AuthResult.INVALID_TOKEN,
                error="Token not recognized",
            )

        agent_id = self._token_to_agent[request.token]
        agent = self._agents.get(agent_id)

        if agent is None:
            return AuthResponse(
                result=AuthResult.INVALID_TOKEN,
                error="Agent not found",
            )

        # Check if agent is revoked
        if agent.is_revoked:
            return AuthResponse(
                result=AuthResult.REVOKED,
                agent_id=agent_id,
                error="Agent has been revoked",
            )

        # Verify token signature
        try:
            claims = self._verifier.verify(
                request.token,
                agent.public_key,
                verify_exp=True,
            )
        except Exception as e:
            error_msg = str(e)
            if "expired" in error_msg.lower():
                return AuthResponse(
                    result=AuthResult.EXPIRED_TOKEN,
                    agent_id=agent_id,
                    error="Token has expired",
                )
            return AuthResponse(
                result=AuthResult.INVALID_TOKEN,
                agent_id=agent_id,
                error=f"Token verification failed: {error_msg}",
            )

        # Check required scope
        if request.required_scope:
            if not self._check_scope(claims.scope, request.required_scope):
                return AuthResponse(
                    result=AuthResult.INSUFFICIENT_SCOPE,
                    agent_id=agent_id,
                    claims=claims.to_dict(),
                    error=f"Missing required scope: {request.required_scope}",
                )

        return AuthResponse(
            result=AuthResult.SUCCESS,
            agent_id=agent_id,
            claims=claims.to_dict(),
        )

    def _check_scope(self, granted: list[str], required: str) -> bool:
        """Check if required scope is covered by granted scopes.

        Supports wildcard matching:
        - "file:*" covers "file:read", "file:write", etc.
        - "*" covers everything
        """
        for scope in granted:
            if scope == "*":
                return True
            if scope == required:
                return True
            # Wildcard matching
            if scope.endswith(":*"):
                prefix = scope[:-1]  # "file:" from "file:*"
                if required.startswith(prefix):
                    return True
        return False

    def verify_token(
        self,
        token: str,
        required_scope: str | None = None,
    ) -> bool:
        """Convenience method to verify a token.

        Args:
            token: The bearer token
            required_scope: Required scope (optional)

        Returns:
            True if token is valid and has required scope
        """
        response = self.authenticate(AuthRequest(
            token=token,
            required_scope=required_scope,
        ))
        return response.result == AuthResult.SUCCESS

    def get_agent_info(self, token: str) -> AuthenticatedAgent | None:
        """Get agent information from a token.

        Args:
            token: The bearer token

        Returns:
            AuthenticatedAgent if valid, None otherwise
        """
        if token not in self._token_to_agent:
            return None

        agent_id = self._token_to_agent[token]
        agent = self._agents.get(agent_id)

        if agent is None:
            return None

        return AuthenticatedAgent(
            agent_id=agent.agent_id,
            name=agent.name,
            capabilities=agent.capabilities,
            token=token,
            public_key_b64=agent.public_key_b64,
            created_at=agent.created_at,
            metadata=agent.metadata,
        )

    def revoke_agent(self, agent_id: str) -> bool:
        """Revoke an agent's credentials.

        Args:
            agent_id: ID of the agent to revoke

        Returns:
            True if successfully revoked
        """
        agent = self._agents.get(agent_id)
        if agent is None:
            return False

        agent.revoke(propagate=True)

        # Keep token mapping so authenticate() can find the agent
        # and return REVOKED status instead of INVALID_TOKEN

        return True

    def log_operation(
        self,
        agent_id: str,
        tool_name: str,
        auth_result: AuthResult,
        duration_ms: float = 0.0,
        metadata: dict[str, Any] | None = None,
    ) -> AuditEntry:
        """Log an authenticated operation.

        Args:
            agent_id: ID of the agent
            tool_name: Tool that was called
            auth_result: Authentication result
            duration_ms: Operation duration
            metadata: Additional metadata

        Returns:
            The created audit entry
        """
        entry = AuditEntry(
            entry_id=f"audit_{uuid.uuid4().hex[:12]}",
            agent_id=agent_id,
            tool_name=tool_name,
            auth_result=auth_result,
            timestamp=time.time(),
            duration_ms=duration_ms,
            metadata=metadata or {},
        )
        self._audit_log.append(entry)
        return entry

    def get_audit_log(
        self,
        agent_id: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get the audit log.

        Args:
            agent_id: Filter by agent ID
            limit: Maximum entries to return

        Returns:
            List of audit entries as dictionaries
        """
        entries = self._audit_log
        if agent_id:
            entries = [e for e in entries if e.agent_id == agent_id]

        return [
            {
                "entry_id": e.entry_id,
                "agent_id": e.agent_id,
                "tool_name": e.tool_name,
                "auth_result": e.auth_result.value,
                "timestamp": e.timestamp,
                "duration_ms": e.duration_ms,
                "metadata": e.metadata,
            }
            for e in entries[-limit:]
        ]

    def list_agents(self) -> list[dict[str, Any]]:
        """List all registered agents.

        Returns:
            List of agent information dictionaries
        """
        return [
            {
                "agent_id": agent.agent_id,
                "name": agent.name,
                "capabilities": agent.capabilities,
                "is_revoked": agent.is_revoked,
                "created_at": agent.created_at,
            }
            for agent in self._agents.values()
        ]


class SecureToolExecutor:
    """Secure tool executor with authentication.

    Wraps tool execution with authentication and audit logging.

    Example:
        executor = SecureToolExecutor(auth_server)

        result = executor.execute(
            tool_name="search",
            args={"query": "test"},
            token=agent_token,
            tool_func=lambda args: {"results": []},
        )
    """

    def __init__(self, auth_server: LangChainAuthServer) -> None:
        """Initialize the executor.

        Args:
            auth_server: The auth server for authentication
        """
        self.auth_server = auth_server

    def execute(
        self,
        tool_name: str,
        args: dict[str, Any],
        token: str,
        tool_func: Callable[[dict[str, Any]], Any] | None = None,
        required_scope: str | None = None,
    ) -> dict[str, Any]:
        """Execute a tool with authentication.

        Args:
            tool_name: Name of the tool
            args: Tool arguments
            token: Bearer token for authentication
            tool_func: Function to execute the tool
            required_scope: Required scope (defaults to tool_name)

        Returns:
            Execution result dictionary
        """
        start_time = time.time()

        # Authenticate
        response = self.auth_server.authenticate(AuthRequest(
            token=token,
            required_scope=required_scope or tool_name,
            tool_name=tool_name,
            arguments=args,
        ))

        if response.result != AuthResult.SUCCESS:
            self.auth_server.log_operation(
                agent_id=response.agent_id or "unknown",
                tool_name=tool_name,
                auth_result=response.result,
                duration_ms=(time.time() - start_time) * 1000,
                metadata={"error": response.error},
            )
            return {
                "success": False,
                "error": response.error,
                "auth_result": response.result.value,
            }

        # Execute tool
        result: Any = None
        error: str | None = None
        success = True

        try:
            if tool_func:
                result = tool_func(args)
            else:
                result = {"message": f"Tool {tool_name} executed (no func provided)"}
        except Exception as e:
            error = str(e)
            success = False

        end_time = time.time()
        duration_ms = (end_time - start_time) * 1000

        # Log operation
        self.auth_server.log_operation(
            agent_id=response.agent_id or "unknown",
            tool_name=tool_name,
            auth_result=AuthResult.SUCCESS,
            duration_ms=duration_ms,
            metadata={"success": success, "error": error},
        )

        return {
            "success": success,
            "result": result,
            "error": error,
            "agent_id": response.agent_id,
            "duration_ms": duration_ms,
        }


def create_auth_server(
    name: str = "langchain-auth",
    algorithm: str = "ml-dsa-65",
    token_ttl: int = 3600,
) -> LangChainAuthServer:
    """Create a LangChain Auth Server.

    Args:
        name: Server name
        algorithm: ML-DSA algorithm
        token_ttl: Default token TTL

    Returns:
        Configured LangChainAuthServer
    """
    return LangChainAuthServer(
        name=name,
        algorithm=algorithm,
        token_ttl=token_ttl,
    )


def create_secure_executor(
    auth_server: LangChainAuthServer,
) -> SecureToolExecutor:
    """Create a secure tool executor.

    Args:
        auth_server: The auth server to use

    Returns:
        Configured SecureToolExecutor
    """
    return SecureToolExecutor(auth_server)
