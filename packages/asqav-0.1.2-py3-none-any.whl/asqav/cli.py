"""
Command-line interface for Asqav.

Provides commands for managing quantum-safe AI agent identities,
viewing logs, and checking revocation status.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="asqav",
    help="Quantum-safe identity and runtime monitoring for AI agents",
    no_args_is_help=True,
)

console = Console()


@app.command()
def create(
    name: str = typer.Argument(..., help="Name for the agent"),
    algorithm: str = typer.Option(
        "ml-dsa-65",
        "--algorithm",
        "-a",
        help="ML-DSA algorithm (ml-dsa-44, ml-dsa-65, ml-dsa-87)",
    ),
    capabilities: str | None = typer.Option(
        None,
        "--capabilities",
        "-c",
        help="Comma-separated capabilities",
    ),
    output: Path | None = typer.Option(  # noqa: B008
        None,
        "--output",
        "-o",
        help="Output file for agent credentials",
    ),
) -> None:
    """Create a new quantum-safe agent identity."""
    from .core.agent import SecureAgent

    caps = capabilities.split(",") if capabilities else []

    try:
        agent = SecureAgent.create(
            name=name,
            algorithm=algorithm,
            capabilities=caps,
        )
    except Exception as e:
        console.print(f"[red]Error creating agent: {e}[/red]")
        raise typer.Exit(1) from None

    agent_data = agent.to_dict()

    if output:
        with open(output, "w") as f:
            json.dump(agent_data, f, indent=2)
        console.print(f"[green]Agent credentials saved to {output}[/green]")
    else:
        console.print(json.dumps(agent_data, indent=2))

    console.print("\n[green]Agent created successfully[/green]")
    console.print(f"  ID: {agent.agent_id}")
    console.print(f"  Name: {agent.name}")
    console.print(f"  Algorithm: {agent.algorithm.value}")
    console.print(f"  Key ID: {agent.key_id}")


@app.command()
def info() -> None:
    """Show information about available algorithms."""
    from .core.identity import get_available_algorithms

    try:
        algorithms = get_available_algorithms()
    except Exception as e:
        console.print(f"[red]Error getting algorithms: {e}[/red]")
        console.print("[yellow]Note: liboqs may not be installed correctly[/yellow]")
        raise typer.Exit(1) from None

    table = Table(title="Available ML-DSA Algorithms")
    table.add_column("Algorithm", style="cyan")
    table.add_column("Security Level", style="green")
    table.add_column("Recommendation", style="yellow")

    security_levels = {
        "ML-DSA-44": ("128-bit", "Fast, suitable for most uses"),
        "ML-DSA-65": ("192-bit", "Recommended default"),
        "ML-DSA-87": ("256-bit", "Maximum security"),
    }

    for alg in sorted(algorithms):
        level, rec = security_levels.get(alg, ("Unknown", ""))
        table.add_row(alg, level, rec)

    console.print(table)


@app.command()
def logs(
    agent_id: str | None = typer.Option(
        None,
        "--agent",
        "-a",
        help="Filter by agent ID",
    ),
    limit: int = typer.Option(
        50,
        "--limit",
        "-l",
        help="Maximum number of actions to show",
    ),
    session_id: str | None = typer.Option(
        None,
        "--session",
        "-s",
        help="Filter by session ID",
    ),
) -> None:
    """View agent action logs."""
    from .core.session import LocalStorage, format_action_log

    storage = LocalStorage()

    if session_id:
        actions = storage.get_session_actions(session_id, limit=limit)
    elif agent_id:
        actions = storage.get_agent_actions(agent_id, limit=limit)
    else:
        actions = storage.get_all_actions(limit=limit)

    if not actions:
        console.print("[yellow]No actions found[/yellow]")
        return

    console.print(format_action_log(actions))
    console.print(f"\n[dim]Showing {len(actions)} actions[/dim]")


@app.command()
def risk(
    algorithm: str = typer.Argument(
        ...,
        help="Algorithm to assess (e.g., ES256, RS256, ML-DSA-65)",
    ),
) -> None:
    """Assess quantum security risk of an algorithm."""
    from .core.tokens import assess_token_risk

    result = assess_token_risk(algorithm)

    risk_color = {
        "LOW": "green",
        "HIGH": "red",
        "UNKNOWN": "yellow",
    }.get(result["risk"], "white")

    console.print(f"Algorithm: [cyan]{result['algorithm']}[/cyan]")
    if "algorithm_name" in result:
        console.print(f"Full name: {result['algorithm_name']}")
    console.print(f"Quantum-safe: {'Yes' if result['quantum_safe'] else 'No'}")
    console.print(f"Risk: [{risk_color}]{result['risk']}[/{risk_color}]")

    if result.get("recommendation"):
        console.print(f"\nRecommendation: {result['recommendation']}")


@app.command()
def token(
    agent_file: Path = typer.Argument(  # noqa: B008
        ...,
        help="Path to agent credentials file",
    ),
    ttl: int = typer.Option(
        3600,
        "--ttl",
        "-t",
        help="Token time-to-live in seconds",
    ),
    scope: str | None = typer.Option(
        None,
        "--scope",
        "-s",
        help="Comma-separated scope (default: all capabilities)",
    ),
) -> None:
    """Generate a token for an agent."""
    console.print("[yellow]Token generation from file not yet implemented[/yellow]")
    console.print("[dim]Use the Python API to generate tokens[/dim]")


@app.command()
def serve(
    host: str = typer.Option(
        "0.0.0.0",
        "--host",
        "-h",
        help="Host to bind to",
    ),
    port: int = typer.Option(
        8000,
        "--port",
        "-p",
        help="Port to bind to",
    ),
    reload: bool = typer.Option(
        False,
        "--reload",
        "-r",
        help="Enable auto-reload for development",
    ),
) -> None:
    """Start the Asqav API server."""
    try:
        import uvicorn
    except ImportError:
        console.print("[red]Error: uvicorn not installed[/red]")
        console.print("[yellow]Install with: pip install asqav[cloud][/yellow]")
        raise typer.Exit(1) from None

    console.print(f"[green]Starting Asqav API server on {host}:{port}[/green]")
    uvicorn.run(
        "asqav.api.main:app",
        host=host,
        port=port,
        reload=reload,
    )


@app.command()
def version() -> None:
    """Show version information."""
    import oqs

    console.print("Asqav version: 0.1.0")
    console.print(f"liboqs version: {oqs.oqs_version()}")
    console.print(f"liboqs-python version: {oqs.oqs_python_version()}")
    console.print(f"Python version: {sys.version}")


# Model registry subcommands
model_app = typer.Typer(help="Model integrity registry commands")
app.add_typer(model_app, name="model")


@model_app.command("register")
def model_register(
    model_path: Path = typer.Argument(  # noqa: B008
        ...,
        help="Path to model file to register",
    ),
    name: str = typer.Option(
        None,
        "--name",
        "-n",
        help="Model name (default: filename)",
    ),
    version_str: str = typer.Option(
        "1.0.0",
        "--version",
        "-v",
        help="Model version",
    ),
    model_type: str = typer.Option(
        "unknown",
        "--type",
        "-t",
        help="Model type (classical, qnn, vqc, hybrid)",
    ),
    framework: str = typer.Option(
        "unknown",
        "--framework",
        "-f",
        help="Framework (pytorch, tensorflow, qiskit, pennylane)",
    ),
    algorithm: str = typer.Option(
        "ml-dsa-65",
        "--algorithm",
        "-a",
        help="ML-DSA algorithm for signing",
    ),
) -> None:
    """Register a model with ML-DSA signature."""
    from .core.identity import IdentityProvider, parse_algorithm
    from .qml.model_registry import ModelMetadata, ModelRegistry

    if not model_path.exists():
        console.print(f"[red]Error: File not found: {model_path}[/red]")
        raise typer.Exit(1)

    try:
        alg = parse_algorithm(algorithm)
        provider = IdentityProvider(alg)
        keypair = provider.generate_keypair()

        registry = ModelRegistry(keypair, signer_id="cli-user")

        metadata = ModelMetadata(
            name=name or model_path.stem,
            version=version_str,
            model_type=model_type,
            framework=framework,
        )

        entry = registry.register(model_path, metadata)

        console.print("[green]Model registered successfully[/green]\n")
        console.print(f"Registry ID: [cyan]{entry.registry_id}[/cyan]")
        console.print(f"File Hash: {entry.file_hash}")
        console.print(f"Algorithm: {entry.algorithm}")
        console.print(f"Key ID: {entry.key_id}")
        console.print("\n[dim]Store the registry ID to verify the model later[/dim]")

    except Exception as e:
        console.print(f"[red]Error registering model: {e}[/red]")
        raise typer.Exit(1) from None


@model_app.command("verify")
def model_verify(
    model_path: Path = typer.Argument(  # noqa: B008
        ...,
        help="Path to model file to verify",
    ),
    registry_id: str = typer.Argument(
        ...,
        help="Registry ID to verify against",
    ),
) -> None:
    """Verify a model's integrity."""
    from .core.identity import IdentityProvider, MLDSALevel
    from .qml.model_registry import ModelRegistry

    if not model_path.exists():
        console.print(f"[red]Error: File not found: {model_path}[/red]")
        raise typer.Exit(1)

    try:
        # Create a temporary keypair just for verification
        provider = IdentityProvider(MLDSALevel.ML_DSA_65)
        keypair = provider.generate_keypair()

        registry = ModelRegistry(keypair, signer_id="cli-user")
        result = registry.verify(model_path, registry_id)

        if result.is_valid:
            console.print("[green]Model verification PASSED[/green]\n")
            console.print(f"Registry ID: {result.registry_id}")
            console.print(f"File Hash: {result.file_hash}")
            if result.metadata:
                console.print(f"Model Name: {result.metadata.name}")
                console.print(f"Version: {result.metadata.version}")
        else:
            console.print("[red]Model verification FAILED[/red]\n")
            console.print(f"Error: {result.error}")
            if result.file_hash and result.expected_hash:
                console.print(f"\nExpected hash: {result.expected_hash}")
                console.print(f"Actual hash: {result.file_hash}")
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error verifying model: {e}[/red]")
        raise typer.Exit(1) from None


@model_app.command("list")
def model_list(
    limit: int = typer.Option(
        20,
        "--limit",
        "-l",
        help="Maximum number of entries to show",
    ),
) -> None:
    """List registered models."""
    from .core.identity import IdentityProvider, MLDSALevel
    from .qml.model_registry import ModelRegistry

    try:
        provider = IdentityProvider(MLDSALevel.ML_DSA_65)
        keypair = provider.generate_keypair()
        registry = ModelRegistry(keypair, signer_id="cli-user")

        entries = registry.list_entries(limit=limit)

        if not entries:
            console.print("[yellow]No registered models found[/yellow]")
            return

        table = Table(title="Registered Models")
        table.add_column("Registry ID", style="cyan")
        table.add_column("Name", style="green")
        table.add_column("Version")
        table.add_column("Type")
        table.add_column("Algorithm")

        for entry in entries:
            table.add_row(
                entry.registry_id[:20] + "...",
                entry.metadata.name,
                entry.metadata.version,
                entry.metadata.model_type,
                entry.algorithm,
            )

        console.print(table)
        console.print(f"\n[dim]Showing {len(entries)} entries[/dim]")

    except Exception as e:
        console.print(f"[red]Error listing models: {e}[/red]")
        raise typer.Exit(1) from None


# QML Security subcommands
qml_app = typer.Typer(help="QML security analysis commands")
app.add_typer(qml_app, name="qml")


@qml_app.command("scan")
def qml_scan(
    data_file: Path = typer.Argument(  # noqa: B008
        ...,
        help="Path to JSON file with measurement data",
    ),
    n_clusters: int = typer.Option(
        5,
        "--clusters",
        "-c",
        help="Number of clusters for analysis",
    ),
) -> None:
    """Scan quantum measurements for backdoor indicators (QSentry).

    The data file should be a JSON array of measurement counts, where each
    entry is an object with bitstring keys and count values.

    Example data file:
    [
      {"00": 50, "01": 20, "10": 15, "11": 15},
      {"00": 45, "01": 25, "10": 18, "11": 12},
      ...
    ]
    """
    from .qml.qml_anomaly import MeasurementData
    from .qml.qsentry import QSentry

    if not data_file.exists():
        console.print(f"[red]Error: File not found: {data_file}[/red]")
        raise typer.Exit(1)

    try:
        with open(data_file) as f:
            data = json.load(f)

        if not isinstance(data, list) or len(data) == 0:
            console.print("[red]Error: Data file must be a non-empty JSON array[/red]")
            raise typer.Exit(1)

        # Determine n_qubits from first measurement
        first_counts = data[0]
        first_key = next(iter(first_counts.keys()))
        n_qubits = len(first_key)

        qsentry = QSentry(n_clusters=n_clusters)

        for i, counts in enumerate(data):
            measurement = MeasurementData.from_counts(counts, n_qubits=n_qubits)
            qsentry.add_measurement(measurement, sample_id=i)

        report = qsentry.analyze()

        # Display results
        risk_colors = {
            "clean": "green",
            "low": "yellow",
            "medium": "orange3",
            "high": "red",
            "critical": "red bold",
        }

        console.print("\n[bold]QSentry Analysis Report[/bold]\n")
        console.print(f"Report ID: {report.report_id}")
        console.print(f"Samples analyzed: {report.n_samples}")
        console.print(f"Clusters: {report.n_clusters}")

        risk_color = risk_colors.get(report.risk_level.value, "white")
        console.print(f"Risk Level: [{risk_color}]{report.risk_level.value.upper()}[/{risk_color}]")
        console.print(f"Confidence: {report.confidence:.1%}")
        console.print(f"\n{report.description}")

        if report.suspicious_samples:
            console.print(f"\n[yellow]Suspicious samples: {len(report.suspicious_samples)}[/yellow]")
            if len(report.suspicious_samples) <= 10:
                console.print(f"Sample indices: {report.suspicious_samples}")

    except json.JSONDecodeError as e:
        console.print(f"[red]Error parsing JSON: {e}[/red]")
        raise typer.Exit(1) from None
    except Exception as e:
        console.print(f"[red]Error during analysis: {e}[/red]")
        raise typer.Exit(1) from None


@qml_app.command("status")
def qml_status() -> None:
    """Show QML Security Platform status."""
    from .qml.qml_platform import QMLPlatform

    try:
        platform = QMLPlatform()
        status = platform.get_status()

        console.print("\n[bold]QML Security Platform Status[/bold]\n")

        risk_colors = {
            "secure": "green",
            "low": "green",
            "medium": "yellow",
            "high": "red",
            "critical": "red bold",
        }
        risk_val = status.overall_risk.value if hasattr(status.overall_risk, 'value') else status.overall_risk
        risk_color = risk_colors.get(risk_val, "white")
        console.print(f"Overall Risk: [{risk_color}]{risk_val.upper()}[/{risk_color}]")

        console.print(f"\nModules Available: {', '.join(status.modules_available)}")
        console.print(f"Total Scans: {status.total_scans}")
        console.print(f"Active Alerts: {status.active_alerts}")
        console.print(f"Models Registered: {status.models_registered}")
        console.print(f"Noise Profiles: {status.noise_profiles_stored}")

        if status.last_scan_time:
            console.print(f"Last Scan: {status.last_scan_time.isoformat()}")

    except Exception as e:
        console.print(f"[red]Error getting status: {e}[/red]")
        raise typer.Exit(1) from None


@qml_app.command("full-scan")
def qml_full_scan(
    model_path: Path | None = typer.Option(
        None,
        "--model",
        "-m",
        help="Path to model file for integrity check",
    ),
    data_file: Path | None = typer.Option(
        None,
        "--data",
        "-d",
        help="JSON file with measurement data for backdoor detection",
    ),
) -> None:
    """Run full QML security platform scan."""
    from .qml.qml_anomaly import MeasurementData
    from .qml.qml_platform import QMLPlatform

    try:
        platform = QMLPlatform()

        # Load measurements if provided
        measurements = None
        if data_file and data_file.exists():
            with open(data_file) as f:
                data = json.load(f)
            if isinstance(data, list) and len(data) > 0:
                first_key = next(iter(data[0].keys()))
                n_qubits = len(first_key)
                measurements = [
                    MeasurementData.from_counts(counts, n_qubits=n_qubits)
                    for counts in data
                ]

        # Run scan
        report = platform.full_scan(
            model_path=model_path,
            measurements=measurements,
        )

        # Display results
        risk_colors = {
            "secure": "green",
            "low": "green",
            "medium": "yellow",
            "high": "red",
            "critical": "red bold",
        }

        console.print("\n[bold]QML Platform Scan Report[/bold]\n")
        console.print(f"Report ID: {report.report_id}")
        console.print(f"Timestamp: {report.timestamp.isoformat()}")

        risk_color = risk_colors.get(report.overall_risk.value, "white")
        console.print(f"Overall Risk: [{risk_color}]{report.overall_risk.value.upper()}[/{risk_color}]")

        console.print("\n[bold]Module Results:[/bold]")
        for result in report.module_results:
            status_icon = "[green]OK[/green]" if result.status.value == "completed" else "[red]FAIL[/red]"
            risk_c = risk_colors.get(result.risk_level, "white")
            console.print(
                f"  {result.module_name}: {status_icon} - "
                f"[{risk_c}]{result.risk_level.upper()}[/{risk_c}] "
                f"({result.confidence:.1%} confidence)"
            )

        console.print(f"\n[bold]Summary:[/bold] {report.summary}")

        if report.recommendations:
            console.print("\n[bold]Recommendations:[/bold]")
            for rec in report.recommendations:
                console.print(f"  - {rec}")

    except Exception as e:
        console.print(f"[red]Error during scan: {e}[/red]")
        raise typer.Exit(1) from None


# Alerts subcommands
alerts_app = typer.Typer(help="Alert management commands")
qml_app.add_typer(alerts_app, name="alerts")


@alerts_app.command("list")
def alerts_list(
    status: str | None = typer.Option(
        None,
        "--status",
        "-s",
        help="Filter by status (pending, sent, acknowledged, resolved)",
    ),
    severity: str | None = typer.Option(
        None,
        "--severity",
        "-v",
        help="Filter by severity (info, warning, high, critical)",
    ),
    limit: int = typer.Option(
        20,
        "--limit",
        "-l",
        help="Maximum alerts to show",
    ),
) -> None:
    """List security alerts."""
    from .platform.alerts import AlertSeverity, AlertStatus, create_alert_engine

    try:
        engine = create_alert_engine()

        status_filter = AlertStatus(status) if status else None
        severity_filter = AlertSeverity(severity) if severity else None

        alerts = engine.get_alerts(
            status=status_filter,
            severity=severity_filter,
            limit=limit,
        )

        if not alerts:
            console.print("[yellow]No alerts found[/yellow]")
            return

        table = Table(title="Security Alerts")
        table.add_column("ID", style="cyan", max_width=12)
        table.add_column("Severity", style="bold")
        table.add_column("Title")
        table.add_column("Module")
        table.add_column("Status")
        table.add_column("Time")

        severity_colors = {
            "info": "blue",
            "warning": "yellow",
            "high": "red",
            "critical": "red bold",
        }

        for alert in alerts:
            sev_color = severity_colors.get(alert.severity.value, "white")
            table.add_row(
                alert.alert_id[:12],
                f"[{sev_color}]{alert.severity.value.upper()}[/{sev_color}]",
                alert.title[:40],
                alert.source_module,
                alert.status.value,
                alert.timestamp.strftime("%Y-%m-%d %H:%M"),
            )

        console.print(table)
        console.print(f"\n[dim]Showing {len(alerts)} alerts[/dim]")

    except Exception as e:
        console.print(f"[red]Error listing alerts: {e}[/red]")
        raise typer.Exit(1) from None


@alerts_app.command("acknowledge")
def alerts_acknowledge(
    alert_id: str = typer.Argument(..., help="Alert ID to acknowledge"),
) -> None:
    """Acknowledge an alert."""
    from .platform.alerts import create_alert_engine

    try:
        engine = create_alert_engine()
        success = engine.acknowledge_alert(alert_id)

        if success:
            console.print(f"[green]Alert {alert_id} acknowledged[/green]")
        else:
            console.print(f"[red]Alert {alert_id} not found[/red]")
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1) from None


@alerts_app.command("resolve")
def alerts_resolve(
    alert_id: str = typer.Argument(..., help="Alert ID to resolve"),
) -> None:
    """Mark an alert as resolved."""
    from .platform.alerts import create_alert_engine

    try:
        engine = create_alert_engine()
        success = engine.resolve_alert(alert_id)

        if success:
            console.print(f"[green]Alert {alert_id} resolved[/green]")
        else:
            console.print(f"[red]Alert {alert_id} not found[/red]")
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1) from None


# Compliance subcommands
compliance_app = typer.Typer(help="Compliance reporting commands")
qml_app.add_typer(compliance_app, name="compliance")


@compliance_app.command("iso42001")
def compliance_iso42001(
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path (HTML format)",
    ),
    organization: str = typer.Option(
        "Organization",
        "--org",
        help="Organization name for report",
    ),
) -> None:
    """Generate ISO/IEC 42001:2023 compliance report."""
    from .platform.compliance import ComplianceReporter
    from .qml.qml_platform import QMLPlatform

    try:
        platform = QMLPlatform()
        reports = platform.get_reports(limit=50)

        reporter = ComplianceReporter(organization=organization)
        compliance_report = reporter.generate_iso42001_report(reports)

        if output:
            html = reporter.export_html(compliance_report)
            with open(output, "w") as f:
                f.write(html)
            console.print(f"[green]Report saved to {output}[/green]")
        else:
            text = reporter.export_text(compliance_report)
            console.print(text)

        console.print(f"\n[bold]Compliance Rate: {compliance_report.overall_compliance_rate:.1f}%[/bold]")

    except Exception as e:
        console.print(f"[red]Error generating report: {e}[/red]")
        raise typer.Exit(1) from None


@compliance_app.command("nist")
def compliance_nist(
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path (HTML format)",
    ),
    organization: str = typer.Option(
        "Organization",
        "--org",
        help="Organization name for report",
    ),
) -> None:
    """Generate NIST AI Risk Management Framework report."""
    from .platform.compliance import ComplianceReporter
    from .qml.qml_platform import QMLPlatform

    try:
        platform = QMLPlatform()
        reports = platform.get_reports(limit=50)

        reporter = ComplianceReporter(organization=organization)
        compliance_report = reporter.generate_nist_report(reports)

        if output:
            html = reporter.export_html(compliance_report)
            with open(output, "w") as f:
                f.write(html)
            console.print(f"[green]Report saved to {output}[/green]")
        else:
            text = reporter.export_text(compliance_report)
            console.print(text)

        console.print(f"\n[bold]Compliance Rate: {compliance_report.overall_compliance_rate:.1f}%[/bold]")

    except Exception as e:
        console.print(f"[red]Error generating report: {e}[/red]")
        raise typer.Exit(1) from None


def main() -> None:
    """Main entry point for CLI."""
    app()


if __name__ == "__main__":
    main()
