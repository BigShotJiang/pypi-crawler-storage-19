"""Anomaly detection for AI agent behavior.

This module provides rule-based anomaly detection for monitoring
agent actions and triggering alerts when suspicious patterns are detected.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class AnomalyType(Enum):
    """Types of anomalies that can be detected."""

    ACTION_FREQUENCY = "action_frequency"
    SCOPE_VIOLATION = "scope_violation"
    TIME_PATTERN = "time_pattern"
    SEQUENCE_ANOMALY = "sequence_anomaly"
    RESOURCE_ACCESS = "resource_access"


class Severity(Enum):
    """Severity levels for anomalies."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class AnomalyEvent:
    """An anomaly event detected by a rule."""

    event_id: str
    anomaly_type: AnomalyType
    severity: Severity
    agent_id: str
    session_id: str | None
    description: str
    timestamp: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "event_id": self.event_id,
            "anomaly_type": self.anomaly_type.value,
            "severity": self.severity.value,
            "agent_id": self.agent_id,
            "session_id": self.session_id,
            "description": self.description,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


@dataclass
class ActionContext:
    """Context for an action being analyzed."""

    agent_id: str
    session_id: str | None
    action_type: str
    action_name: str
    timestamp: float
    capabilities: list[str]
    metadata: dict[str, Any] = field(default_factory=dict)


class AnomalyRule(ABC):
    """Base class for anomaly detection rules."""

    def __init__(self, name: str, severity: Severity = Severity.MEDIUM) -> None:
        """Initialize rule.

        Args:
            name: Rule name.
            severity: Default severity for anomalies from this rule.
        """
        self.name = name
        self.severity = severity
        self.enabled = True

    @abstractmethod
    def check(self, context: ActionContext, history: list[ActionContext]) -> AnomalyEvent | None:
        """Check if this action triggers the rule.

        Args:
            context: Current action context.
            history: Recent action history for the agent.

        Returns:
            AnomalyEvent if rule triggered, None otherwise.
        """
        pass


class ActionFrequencyRule(AnomalyRule):
    """Detect unusually high action frequency."""

    def __init__(
        self,
        max_actions_per_minute: int = 100,
        window_seconds: int = 60,
        severity: Severity = Severity.MEDIUM,
    ) -> None:
        """Initialize rule.

        Args:
            max_actions_per_minute: Maximum allowed actions per window.
            window_seconds: Time window in seconds.
            severity: Severity level.
        """
        super().__init__("action_frequency", severity)
        self.max_actions = max_actions_per_minute
        self.window_seconds = window_seconds

    def check(self, context: ActionContext, history: list[ActionContext]) -> AnomalyEvent | None:
        """Check action frequency."""
        cutoff = context.timestamp - self.window_seconds
        recent_actions = [a for a in history if a.timestamp >= cutoff]

        if len(recent_actions) >= self.max_actions:
            import uuid

            return AnomalyEvent(
                event_id=f"ano_{uuid.uuid4().hex[:16]}",
                anomaly_type=AnomalyType.ACTION_FREQUENCY,
                severity=self.severity,
                agent_id=context.agent_id,
                session_id=context.session_id,
                description=f"High action frequency: {len(recent_actions)} actions in {self.window_seconds}s (limit: {self.max_actions})",
                metadata={
                    "action_count": len(recent_actions),
                    "window_seconds": self.window_seconds,
                    "threshold": self.max_actions,
                },
            )
        return None


class ScopeViolationRule(AnomalyRule):
    """Detect actions outside agent's capabilities."""

    def __init__(self, severity: Severity = Severity.HIGH) -> None:
        """Initialize rule."""
        super().__init__("scope_violation", severity)

    def check(self, context: ActionContext, history: list[ActionContext]) -> AnomalyEvent | None:
        """Check for scope violation."""
        # Check if action matches any capability
        action = context.action_name

        # Simple prefix matching for capabilities like "read:data"
        for cap in context.capabilities:
            if action.startswith(cap.split(":")[0]):
                return None

        # If no capability matches, it's a violation
        import uuid

        return AnomalyEvent(
            event_id=f"ano_{uuid.uuid4().hex[:16]}",
            anomaly_type=AnomalyType.SCOPE_VIOLATION,
            severity=self.severity,
            agent_id=context.agent_id,
            session_id=context.session_id,
            description=f"Action '{action}' not in agent capabilities",
            metadata={
                "action": action,
                "capabilities": context.capabilities,
            },
        )


class TimePatternRule(AnomalyRule):
    """Detect actions at unusual times."""

    def __init__(
        self,
        allowed_hours: tuple[int, int] = (6, 22),
        severity: Severity = Severity.LOW,
    ) -> None:
        """Initialize rule.

        Args:
            allowed_hours: Tuple of (start_hour, end_hour) in 24h format.
            severity: Severity level.
        """
        super().__init__("time_pattern", severity)
        self.start_hour, self.end_hour = allowed_hours

    def check(self, context: ActionContext, history: list[ActionContext]) -> AnomalyEvent | None:
        """Check time pattern."""
        import datetime

        dt = datetime.datetime.fromtimestamp(context.timestamp)
        hour = dt.hour

        if not (self.start_hour <= hour < self.end_hour):
            import uuid

            return AnomalyEvent(
                event_id=f"ano_{uuid.uuid4().hex[:16]}",
                anomaly_type=AnomalyType.TIME_PATTERN,
                severity=self.severity,
                agent_id=context.agent_id,
                session_id=context.session_id,
                description=f"Action at unusual time: {dt.strftime('%H:%M')} (allowed: {self.start_hour}:00-{self.end_hour}:00)",
                metadata={
                    "hour": hour,
                    "allowed_range": [self.start_hour, self.end_hour],
                },
            )
        return None


# Type for alert callbacks
AlertCallback = Callable[[AnomalyEvent], None]


class AnomalyDetector:
    """Main anomaly detection engine."""

    def __init__(self) -> None:
        """Initialize detector."""
        self._rules: list[AnomalyRule] = []
        self._history: dict[str, list[ActionContext]] = defaultdict(list)
        self._callbacks: list[AlertCallback] = []
        self._max_history: int = 1000

    def add_rule(self, rule: AnomalyRule) -> None:
        """Add a detection rule.

        Args:
            rule: Rule to add.
        """
        self._rules.append(rule)

    def remove_rule(self, name: str) -> bool:
        """Remove a rule by name.

        Args:
            name: Rule name.

        Returns:
            True if rule was removed.
        """
        for i, rule in enumerate(self._rules):
            if rule.name == name:
                del self._rules[i]
                return True
        return False

    def add_callback(self, callback: AlertCallback) -> None:
        """Add alert callback.

        Args:
            callback: Function to call when anomaly detected.
        """
        self._callbacks.append(callback)

    def check_action(self, context: ActionContext) -> list[AnomalyEvent]:
        """Check an action against all rules.

        Args:
            context: Action context to check.

        Returns:
            List of triggered anomaly events.
        """
        events: list[AnomalyEvent] = []
        history = self._history[context.agent_id]

        for rule in self._rules:
            if not rule.enabled:
                continue

            event = rule.check(context, history)
            if event:
                events.append(event)
                # Trigger callbacks
                for callback in self._callbacks:
                    callback(event)

        # Update history
        history.append(context)
        if len(history) > self._max_history:
            self._history[context.agent_id] = history[-self._max_history :]

        return events

    def get_history(self, agent_id: str) -> list[ActionContext]:
        """Get action history for an agent.

        Args:
            agent_id: Agent ID.

        Returns:
            List of action contexts.
        """
        return list(self._history.get(agent_id, []))

    def clear_history(self, agent_id: str | None = None) -> None:
        """Clear action history.

        Args:
            agent_id: Agent ID to clear, or None for all.
        """
        if agent_id:
            self._history.pop(agent_id, None)
        else:
            self._history.clear()


def create_default_detector() -> AnomalyDetector:
    """Create detector with default rules.

    Returns:
        Configured AnomalyDetector.
    """
    detector = AnomalyDetector()
    detector.add_rule(ActionFrequencyRule())
    detector.add_rule(ScopeViolationRule())
    detector.add_rule(TimePatternRule())
    return detector
