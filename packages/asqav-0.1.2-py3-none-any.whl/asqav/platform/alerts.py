"""
Alert Engine for Asqav QML Security Platform.

Provides configurable alerting with multiple notifier backends:
- Email (SMTP)
- Slack (webhook)
- PagerDuty (API)
- Generic webhook

Example:
    from asqav import AlertEngine, SlackNotifier, AlertRule

    engine = AlertEngine()
    engine.add_notifier(SlackNotifier(webhook_url="https://..."))
    engine.add_rule(AlertRule(
        name="high_risk_alert",
        condition="risk_level == 'high'",
        severity=AlertSeverity.HIGH,
    ))

    # Check platform report for alerts
    alerts = engine.check_and_notify(platform_report)
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Any


class AlertSeverity(str, Enum):
    """Severity levels for alerts."""

    INFO = "info"
    WARNING = "warning"
    HIGH = "high"
    CRITICAL = "critical"


class AlertStatus(str, Enum):
    """Status of an alert."""

    PENDING = "pending"
    SENT = "sent"
    FAILED = "failed"
    ACKNOWLEDGED = "acknowledged"
    RESOLVED = "resolved"


@dataclass
class Alert:
    """Represents a security alert."""

    alert_id: str
    timestamp: datetime
    severity: AlertSeverity
    title: str
    message: str
    source_module: str
    rule_name: str
    status: AlertStatus = AlertStatus.PENDING
    details: dict[str, Any] = field(default_factory=dict)
    report_id: str | None = None
    acknowledged_at: datetime | None = None
    resolved_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert alert to dictionary for serialization."""
        return {
            "alert_id": self.alert_id,
            "timestamp": self.timestamp.isoformat(),
            "severity": self.severity.value,
            "title": self.title,
            "message": self.message,
            "source_module": self.source_module,
            "rule_name": self.rule_name,
            "status": self.status.value,
            "details": self.details,
            "report_id": self.report_id,
            "acknowledged_at": self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Alert:
        """Create alert from dictionary."""
        return cls(
            alert_id=data["alert_id"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            severity=AlertSeverity(data["severity"]),
            title=data["title"],
            message=data["message"],
            source_module=data["source_module"],
            rule_name=data["rule_name"],
            status=AlertStatus(data["status"]),
            details=data.get("details", {}),
            report_id=data.get("report_id"),
            acknowledged_at=(
                datetime.fromisoformat(data["acknowledged_at"])
                if data.get("acknowledged_at")
                else None
            ),
            resolved_at=(
                datetime.fromisoformat(data["resolved_at"])
                if data.get("resolved_at")
                else None
            ),
        )


@dataclass
class AlertRule:
    """Rule for triggering alerts based on scan results."""

    name: str
    severity: AlertSeverity
    title_template: str = "Security Alert: {module}"
    message_template: str = "Risk level {risk_level} detected in {module}"
    enabled: bool = True

    # Condition fields - all optional, evaluated with AND logic
    risk_levels: list[str] | None = None
    modules: list[str] | None = None
    scan_types: list[str] | None = None
    min_confidence: float | None = None

    def matches(self, result: Any) -> bool:
        """Check if a module result matches this rule.

        Args:
            result: ModuleScanResult to check

        Returns:
            True if the result matches all conditions
        """
        if not self.enabled:
            return False

        # Check risk level
        if self.risk_levels and result.risk_level not in self.risk_levels:
            return False

        # Check module
        if self.modules and result.module_name not in self.modules:
            return False

        # Check scan type
        if self.scan_types and result.scan_type.value not in self.scan_types:
            return False

        # Check confidence
        return self.min_confidence is None or result.confidence >= self.min_confidence

    def create_alert(self, result: Any, report_id: str | None = None) -> Alert:
        """Create an alert from a matching result.

        Args:
            result: ModuleScanResult that matched this rule
            report_id: Optional report ID for tracking

        Returns:
            New Alert instance
        """
        title = self.title_template.format(
            module=result.module_name,
            risk_level=result.risk_level,
            scan_type=result.scan_type.value,
        )
        message = self.message_template.format(
            module=result.module_name,
            risk_level=result.risk_level,
            scan_type=result.scan_type.value,
            confidence=result.confidence,
        )

        return Alert(
            alert_id=str(uuid.uuid4()),
            timestamp=datetime.now(tz=UTC),
            severity=self.severity,
            title=title,
            message=message,
            source_module=result.module_name,
            rule_name=self.name,
            details=result.details,
            report_id=report_id,
        )


class Notifier(ABC):
    """Abstract base class for alert notifiers."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Get notifier name."""

    @abstractmethod
    def send(self, alert: Alert) -> bool:
        """Send an alert notification.

        Args:
            alert: Alert to send

        Returns:
            True if sent successfully
        """

    def supports_severity(self, severity: AlertSeverity) -> bool:
        """Check if this notifier handles the given severity.

        Override to filter alerts by severity.
        """
        return True


class ConsoleNotifier(Notifier):
    """Notifier that prints alerts to console."""

    @property
    def name(self) -> str:
        return "console"

    def send(self, alert: Alert) -> bool:
        """Print alert to console."""
        severity_markers = {
            AlertSeverity.INFO: "[INFO]",
            AlertSeverity.WARNING: "[WARN]",
            AlertSeverity.HIGH: "[HIGH]",
            AlertSeverity.CRITICAL: "[CRIT]",
        }
        marker = severity_markers.get(alert.severity, "[????]")
        print(f"{marker} {alert.title}: {alert.message}")
        return True


class WebhookNotifier(Notifier):
    """Generic webhook notifier."""

    def __init__(
        self,
        webhook_url: str,
        headers: dict[str, str] | None = None,
        method: str = "POST",
        min_severity: AlertSeverity = AlertSeverity.INFO,
    ) -> None:
        """Initialize webhook notifier.

        Args:
            webhook_url: URL to send webhooks to
            headers: Optional HTTP headers
            method: HTTP method (default POST)
            min_severity: Minimum severity to notify
        """
        self.webhook_url = webhook_url
        self.headers = headers or {"Content-Type": "application/json"}
        self.method = method
        self.min_severity = min_severity
        self._severity_order = [
            AlertSeverity.INFO,
            AlertSeverity.WARNING,
            AlertSeverity.HIGH,
            AlertSeverity.CRITICAL,
        ]

    @property
    def name(self) -> str:
        return "webhook"

    def supports_severity(self, severity: AlertSeverity) -> bool:
        """Check if severity meets minimum threshold."""
        return self._severity_order.index(severity) >= self._severity_order.index(
            self.min_severity
        )

    def send(self, alert: Alert) -> bool:
        """Send alert via webhook."""
        try:
            import urllib.request

            data = json.dumps(alert.to_dict()).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url,
                data=data,
                headers=self.headers,
                method=self.method,
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return bool(resp.status < 400)
        except Exception:
            return False


class SlackNotifier(Notifier):
    """Slack webhook notifier."""

    def __init__(
        self,
        webhook_url: str,
        channel: str | None = None,
        username: str = "Asqav Security",
        min_severity: AlertSeverity = AlertSeverity.WARNING,
    ) -> None:
        """Initialize Slack notifier.

        Args:
            webhook_url: Slack incoming webhook URL
            channel: Optional channel override
            username: Bot username
            min_severity: Minimum severity to notify
        """
        self.webhook_url = webhook_url
        self.channel = channel
        self.username = username
        self.min_severity = min_severity
        self._severity_order = [
            AlertSeverity.INFO,
            AlertSeverity.WARNING,
            AlertSeverity.HIGH,
            AlertSeverity.CRITICAL,
        ]

    @property
    def name(self) -> str:
        return "slack"

    def supports_severity(self, severity: AlertSeverity) -> bool:
        """Check if severity meets minimum threshold."""
        return self._severity_order.index(severity) >= self._severity_order.index(
            self.min_severity
        )

    def send(self, alert: Alert) -> bool:
        """Send alert to Slack."""
        try:
            import urllib.request

            color_map = {
                AlertSeverity.INFO: "#36a64f",
                AlertSeverity.WARNING: "#ff9800",
                AlertSeverity.HIGH: "#f44336",
                AlertSeverity.CRITICAL: "#9c27b0",
            }

            payload = {
                "username": self.username,
                "attachments": [
                    {
                        "color": color_map.get(alert.severity, "#808080"),
                        "title": alert.title,
                        "text": alert.message,
                        "fields": [
                            {
                                "title": "Severity",
                                "value": alert.severity.value.upper(),
                                "short": True,
                            },
                            {
                                "title": "Module",
                                "value": alert.source_module,
                                "short": True,
                            },
                        ],
                        "ts": int(alert.timestamp.timestamp()),
                    }
                ],
            }

            if self.channel:
                payload["channel"] = self.channel

            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return bool(resp.status < 400)
        except Exception:
            return False


class EmailNotifier(Notifier):
    """Email notifier using SMTP."""

    def __init__(
        self,
        smtp_host: str,
        smtp_port: int,
        from_addr: str,
        to_addrs: list[str],
        username: str | None = None,
        password: str | None = None,
        use_tls: bool = True,
        min_severity: AlertSeverity = AlertSeverity.HIGH,
    ) -> None:
        """Initialize email notifier.

        Args:
            smtp_host: SMTP server hostname
            smtp_port: SMTP server port
            from_addr: From email address
            to_addrs: List of recipient addresses
            username: SMTP username (optional)
            password: SMTP password (optional)
            use_tls: Use TLS encryption
            min_severity: Minimum severity to email
        """
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.from_addr = from_addr
        self.to_addrs = to_addrs
        self.username = username
        self.password = password
        self.use_tls = use_tls
        self.min_severity = min_severity
        self._severity_order = [
            AlertSeverity.INFO,
            AlertSeverity.WARNING,
            AlertSeverity.HIGH,
            AlertSeverity.CRITICAL,
        ]

    @property
    def name(self) -> str:
        return "email"

    def supports_severity(self, severity: AlertSeverity) -> bool:
        """Check if severity meets minimum threshold."""
        return self._severity_order.index(severity) >= self._severity_order.index(
            self.min_severity
        )

    def send(self, alert: Alert) -> bool:
        """Send alert via email."""
        try:
            import smtplib
            from email.mime.multipart import MIMEMultipart
            from email.mime.text import MIMEText

            msg = MIMEMultipart("alternative")
            msg["Subject"] = f"[{alert.severity.value.upper()}] {alert.title}"
            msg["From"] = self.from_addr
            msg["To"] = ", ".join(self.to_addrs)

            text_body = f"""
Asqav Security Alert

Title: {alert.title}
Severity: {alert.severity.value.upper()}
Module: {alert.source_module}
Time: {alert.timestamp.isoformat()}

Message:
{alert.message}

Details:
{json.dumps(alert.details, indent=2)}

---
Asqav QML Security Platform
"""

            html_body = f"""
<html>
<head><style>
    body {{ font-family: Arial, sans-serif; }}
    .severity-info {{ color: #36a64f; }}
    .severity-warning {{ color: #ff9800; }}
    .severity-high {{ color: #f44336; }}
    .severity-critical {{ color: #9c27b0; font-weight: bold; }}
</style></head>
<body>
    <h2>Asqav Security Alert</h2>
    <p><strong>Title:</strong> {alert.title}</p>
    <p><strong>Severity:</strong>
        <span class="severity-{alert.severity.value}">{alert.severity.value.upper()}</span>
    </p>
    <p><strong>Module:</strong> {alert.source_module}</p>
    <p><strong>Time:</strong> {alert.timestamp.isoformat()}</p>
    <h3>Message</h3>
    <p>{alert.message}</p>
    <h3>Details</h3>
    <pre>{json.dumps(alert.details, indent=2)}</pre>
    <hr>
    <p><em>Asqav QML Security Platform</em></p>
</body>
</html>
"""

            msg.attach(MIMEText(text_body, "plain"))
            msg.attach(MIMEText(html_body, "html"))

            if self.use_tls:
                server = smtplib.SMTP(self.smtp_host, self.smtp_port)
                server.starttls()
            else:
                server = smtplib.SMTP(self.smtp_host, self.smtp_port)

            if self.username and self.password:
                server.login(self.username, self.password)

            server.sendmail(self.from_addr, self.to_addrs, msg.as_string())
            server.quit()
            return True
        except Exception:
            return False


class PagerDutyNotifier(Notifier):
    """PagerDuty Events API v2 notifier."""

    def __init__(
        self,
        routing_key: str,
        min_severity: AlertSeverity = AlertSeverity.HIGH,
    ) -> None:
        """Initialize PagerDuty notifier.

        Args:
            routing_key: PagerDuty integration routing key
            min_severity: Minimum severity to page
        """
        self.routing_key = routing_key
        self.min_severity = min_severity
        self.api_url = "https://events.pagerduty.com/v2/enqueue"
        self._severity_order = [
            AlertSeverity.INFO,
            AlertSeverity.WARNING,
            AlertSeverity.HIGH,
            AlertSeverity.CRITICAL,
        ]

    @property
    def name(self) -> str:
        return "pagerduty"

    def supports_severity(self, severity: AlertSeverity) -> bool:
        """Check if severity meets minimum threshold."""
        return self._severity_order.index(severity) >= self._severity_order.index(
            self.min_severity
        )

    def send(self, alert: Alert) -> bool:
        """Send alert to PagerDuty."""
        try:
            import urllib.request

            # Map severity to PagerDuty severity
            pd_severity_map = {
                AlertSeverity.INFO: "info",
                AlertSeverity.WARNING: "warning",
                AlertSeverity.HIGH: "error",
                AlertSeverity.CRITICAL: "critical",
            }

            payload = {
                "routing_key": self.routing_key,
                "event_action": "trigger",
                "dedup_key": self._dedup_key(alert),
                "payload": {
                    "summary": f"{alert.title}: {alert.message}",
                    "severity": pd_severity_map.get(alert.severity, "error"),
                    "source": f"asqav-{alert.source_module}",
                    "timestamp": alert.timestamp.isoformat(),
                    "custom_details": alert.details,
                },
            }

            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                self.api_url,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return bool(resp.status < 400)
        except Exception:
            return False

    def _dedup_key(self, alert: Alert) -> str:
        """Generate deduplication key for alert."""
        key_data = f"{alert.source_module}:{alert.rule_name}:{alert.report_id or ''}"
        return hashlib.sha256(key_data.encode()).hexdigest()[:32]


class AlertStorage:
    """SQLite storage for alert history."""

    def __init__(self, db_path: str | Path | None = None) -> None:
        """Initialize alert storage.

        Args:
            db_path: Path to SQLite database. Uses default if not provided.
        """
        if db_path is None:
            db_path = Path.home() / ".asqav" / "alerts.db"
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        """Get thread-local database connection."""
        if not hasattr(self._local, "conn"):
            self._local.conn = sqlite3.connect(str(self.db_path))
            self._local.conn.row_factory = sqlite3.Row
        conn: sqlite3.Connection = self._local.conn
        return conn

    def _init_db(self) -> None:
        """Initialize database schema."""
        conn = self._get_conn()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                alert_id TEXT PRIMARY KEY,
                timestamp TEXT NOT NULL,
                severity TEXT NOT NULL,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                source_module TEXT NOT NULL,
                rule_name TEXT NOT NULL,
                status TEXT NOT NULL,
                details TEXT,
                report_id TEXT,
                acknowledged_at TEXT,
                resolved_at TEXT
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_alerts_timestamp
            ON alerts(timestamp DESC)
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_alerts_status
            ON alerts(status)
        """)
        conn.commit()

    def save(self, alert: Alert) -> None:
        """Save an alert to storage."""
        conn = self._get_conn()
        conn.execute(
            """
            INSERT OR REPLACE INTO alerts
            (alert_id, timestamp, severity, title, message, source_module,
             rule_name, status, details, report_id, acknowledged_at, resolved_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                alert.alert_id,
                alert.timestamp.isoformat(),
                alert.severity.value,
                alert.title,
                alert.message,
                alert.source_module,
                alert.rule_name,
                alert.status.value,
                json.dumps(alert.details),
                alert.report_id,
                alert.acknowledged_at.isoformat() if alert.acknowledged_at else None,
                alert.resolved_at.isoformat() if alert.resolved_at else None,
            ),
        )
        conn.commit()

    def get(self, alert_id: str) -> Alert | None:
        """Get an alert by ID."""
        conn = self._get_conn()
        row = conn.execute(
            "SELECT * FROM alerts WHERE alert_id = ?", (alert_id,)
        ).fetchone()
        if row:
            return self._row_to_alert(row)
        return None

    def list_alerts(
        self,
        status: AlertStatus | None = None,
        severity: AlertSeverity | None = None,
        limit: int = 100,
    ) -> list[Alert]:
        """List alerts with optional filtering."""
        conn = self._get_conn()
        query = "SELECT * FROM alerts"
        params: list[Any] = []
        conditions = []

        if status:
            conditions.append("status = ?")
            params.append(status.value)
        if severity:
            conditions.append("severity = ?")
            params.append(severity.value)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        rows = conn.execute(query, params).fetchall()
        return [self._row_to_alert(row) for row in rows]

    def update_status(
        self,
        alert_id: str,
        status: AlertStatus,
    ) -> bool:
        """Update alert status."""
        conn = self._get_conn()
        now = datetime.now(tz=UTC).isoformat()

        updates = ["status = ?"]
        params: list[Any] = [status.value]

        if status == AlertStatus.ACKNOWLEDGED:
            updates.append("acknowledged_at = ?")
            params.append(now)
        elif status == AlertStatus.RESOLVED:
            updates.append("resolved_at = ?")
            params.append(now)

        params.append(alert_id)

        result = conn.execute(
            f"UPDATE alerts SET {', '.join(updates)} WHERE alert_id = ?",
            params,
        )
        conn.commit()
        return result.rowcount > 0

    def _row_to_alert(self, row: sqlite3.Row) -> Alert:
        """Convert database row to Alert object."""
        return Alert(
            alert_id=row["alert_id"],
            timestamp=datetime.fromisoformat(row["timestamp"]),
            severity=AlertSeverity(row["severity"]),
            title=row["title"],
            message=row["message"],
            source_module=row["source_module"],
            rule_name=row["rule_name"],
            status=AlertStatus(row["status"]),
            details=json.loads(row["details"]) if row["details"] else {},
            report_id=row["report_id"],
            acknowledged_at=(
                datetime.fromisoformat(row["acknowledged_at"])
                if row["acknowledged_at"]
                else None
            ),
            resolved_at=(
                datetime.fromisoformat(row["resolved_at"])
                if row["resolved_at"]
                else None
            ),
        )


class AlertEngine:
    """Central alert engine for the QML Security Platform."""

    def __init__(
        self,
        storage: AlertStorage | None = None,
        enable_storage: bool = True,
    ) -> None:
        """Initialize alert engine.

        Args:
            storage: Optional custom storage backend
            enable_storage: Whether to persist alerts
        """
        self.storage = storage if enable_storage else None
        if enable_storage and storage is None:
            self.storage = AlertStorage()

        self._notifiers: list[Notifier] = []
        self._rules: list[AlertRule] = []
        self._default_rules_added = False

    def add_notifier(self, notifier: Notifier) -> None:
        """Add a notifier to the engine."""
        self._notifiers.append(notifier)

    def remove_notifier(self, name: str) -> bool:
        """Remove a notifier by name."""
        for i, n in enumerate(self._notifiers):
            if n.name == name:
                self._notifiers.pop(i)
                return True
        return False

    def add_rule(self, rule: AlertRule) -> None:
        """Add an alert rule."""
        self._rules.append(rule)

    def remove_rule(self, name: str) -> bool:
        """Remove a rule by name."""
        for i, r in enumerate(self._rules):
            if r.name == name:
                self._rules.pop(i)
                return True
        return False

    def add_default_rules(self) -> None:
        """Add default alert rules for common scenarios."""
        if self._default_rules_added:
            return

        self._rules.extend([
            AlertRule(
                name="critical_risk",
                severity=AlertSeverity.CRITICAL,
                risk_levels=["critical"],
                title_template="CRITICAL: {module} security risk",
                message_template="Critical security risk detected in {module}. Immediate action required.",
            ),
            AlertRule(
                name="high_risk",
                severity=AlertSeverity.HIGH,
                risk_levels=["high"],
                title_template="HIGH: {module} security risk",
                message_template="High security risk ({risk_level}) detected in {module}.",
            ),
            AlertRule(
                name="backdoor_detection",
                severity=AlertSeverity.CRITICAL,
                modules=["qsentry"],
                risk_levels=["high", "critical"],
                title_template="Potential Backdoor Detected",
                message_template="QSentry detected potential backdoor with {confidence:.1%} confidence.",
            ),
            AlertRule(
                name="integrity_failure",
                severity=AlertSeverity.CRITICAL,
                modules=["model_registry"],
                risk_levels=["critical"],
                title_template="Model Integrity Compromised",
                message_template="Model integrity verification failed. Hash mismatch detected.",
            ),
            AlertRule(
                name="robustness_warning",
                severity=AlertSeverity.WARNING,
                modules=["vqc_verifier"],
                risk_levels=["medium", "high"],
                title_template="VQC Robustness Warning",
                message_template="Circuit robustness is below acceptable threshold.",
            ),
        ])

        self._default_rules_added = True

    def check_thresholds(self, report: Any) -> list[Alert]:
        """Check a platform report against all rules.

        Args:
            report: PlatformReport to check

        Returns:
            List of triggered alerts
        """
        alerts = []

        for result in report.module_results:
            for rule in self._rules:
                if rule.matches(result):
                    alert = rule.create_alert(result, report_id=report.report_id)
                    alerts.append(alert)

        return alerts

    def send_alert(self, alert: Alert) -> dict[str, bool]:
        """Send an alert to all applicable notifiers.

        Args:
            alert: Alert to send

        Returns:
            Dict mapping notifier names to success status
        """
        results = {}

        for notifier in self._notifiers:
            if notifier.supports_severity(alert.severity):
                success = notifier.send(alert)
                results[notifier.name] = success
                if success:
                    alert.status = AlertStatus.SENT

        return results

    def check_and_notify(self, report: Any) -> list[Alert]:
        """Check report for alerts and send notifications.

        Args:
            report: PlatformReport to check

        Returns:
            List of alerts that were triggered
        """
        alerts = self.check_thresholds(report)

        for alert in alerts:
            # Send to notifiers
            self.send_alert(alert)

            # Store alert
            if self.storage:
                self.storage.save(alert)

        return alerts

    def get_alerts(
        self,
        status: AlertStatus | None = None,
        severity: AlertSeverity | None = None,
        limit: int = 100,
    ) -> list[Alert]:
        """Get alerts from storage.

        Args:
            status: Filter by status
            severity: Filter by severity
            limit: Maximum alerts to return

        Returns:
            List of matching alerts
        """
        if self.storage:
            return self.storage.list_alerts(status, severity, limit)
        return []

    def acknowledge_alert(self, alert_id: str) -> bool:
        """Mark an alert as acknowledged.

        Args:
            alert_id: ID of alert to acknowledge

        Returns:
            True if successful
        """
        if self.storage:
            return self.storage.update_status(alert_id, AlertStatus.ACKNOWLEDGED)
        return False

    def resolve_alert(self, alert_id: str) -> bool:
        """Mark an alert as resolved.

        Args:
            alert_id: ID of alert to resolve

        Returns:
            True if successful
        """
        if self.storage:
            return self.storage.update_status(alert_id, AlertStatus.RESOLVED)
        return False


def create_alert_engine(
    enable_storage: bool = True,
    add_default_rules: bool = True,
    add_console_notifier: bool = False,
) -> AlertEngine:
    """Create and configure an alert engine.

    Args:
        enable_storage: Enable alert persistence
        add_default_rules: Add default alert rules
        add_console_notifier: Add console output notifier

    Returns:
        Configured AlertEngine instance
    """
    engine = AlertEngine(enable_storage=enable_storage)

    if add_default_rules:
        engine.add_default_rules()

    if add_console_notifier:
        engine.add_notifier(ConsoleNotifier())

    return engine
