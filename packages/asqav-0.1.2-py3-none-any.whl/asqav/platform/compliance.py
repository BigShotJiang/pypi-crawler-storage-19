"""
Compliance Reporting for Asqav QML Security Platform.

Generates compliance reports based on security scan results:
- ISO/IEC 42001:2023 (AI Management System)
- NIST AI Risk Management Framework (AI RMF)
- Custom audit reports

Example:
    from asqav import ComplianceReporter

    reporter = ComplianceReporter()

    # Generate ISO 42001 report
    report = reporter.generate_iso42001_report(scan_reports)
    html = reporter.export_html(report)

    # Generate NIST AI RMF report
    nist_report = reporter.generate_nist_report(scan_reports)
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any


class ComplianceStandard(str, Enum):
    """Supported compliance standards."""

    ISO_42001 = "iso_42001"
    NIST_AI_RMF = "nist_ai_rmf"
    CUSTOM = "custom"


class ControlStatus(str, Enum):
    """Status of a compliance control."""

    COMPLIANT = "compliant"
    PARTIALLY_COMPLIANT = "partially_compliant"
    NON_COMPLIANT = "non_compliant"
    NOT_APPLICABLE = "not_applicable"
    NOT_ASSESSED = "not_assessed"


@dataclass
class ControlAssessment:
    """Assessment result for a single control."""

    control_id: str
    control_name: str
    description: str
    status: ControlStatus
    findings: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "control_id": self.control_id,
            "control_name": self.control_name,
            "description": self.description,
            "status": self.status.value,
            "findings": self.findings,
            "evidence": self.evidence,
            "recommendations": self.recommendations,
        }


@dataclass
class ComplianceSection:
    """Section of a compliance report."""

    section_id: str
    section_name: str
    description: str
    controls: list[ControlAssessment] = field(default_factory=list)

    @property
    def compliant_count(self) -> int:
        """Count of compliant controls."""
        return sum(1 for c in self.controls if c.status == ControlStatus.COMPLIANT)

    @property
    def total_count(self) -> int:
        """Total number of assessed controls."""
        return sum(
            1 for c in self.controls if c.status != ControlStatus.NOT_APPLICABLE
        )

    @property
    def compliance_rate(self) -> float:
        """Compliance rate as percentage."""
        if self.total_count == 0:
            return 100.0
        return (self.compliant_count / self.total_count) * 100

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "section_id": self.section_id,
            "section_name": self.section_name,
            "description": self.description,
            "controls": [c.to_dict() for c in self.controls],
            "compliant_count": self.compliant_count,
            "total_count": self.total_count,
            "compliance_rate": self.compliance_rate,
        }


@dataclass
class ComplianceReport:
    """Complete compliance report."""

    report_id: str
    standard: ComplianceStandard
    title: str
    generated_at: datetime
    organization: str
    assessor: str
    scope: str
    sections: list[ComplianceSection] = field(default_factory=list)
    executive_summary: str = ""
    overall_status: ControlStatus = ControlStatus.NOT_ASSESSED
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def overall_compliance_rate(self) -> float:
        """Overall compliance rate across all sections."""
        total_compliant = sum(s.compliant_count for s in self.sections)
        total_controls = sum(s.total_count for s in self.sections)
        if total_controls == 0:
            return 100.0
        return (total_compliant / total_controls) * 100

    @property
    def total_findings(self) -> int:
        """Total number of findings across all controls."""
        return sum(
            len(c.findings)
            for s in self.sections
            for c in s.controls
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "report_id": self.report_id,
            "standard": self.standard.value,
            "title": self.title,
            "generated_at": self.generated_at.isoformat(),
            "organization": self.organization,
            "assessor": self.assessor,
            "scope": self.scope,
            "sections": [s.to_dict() for s in self.sections],
            "executive_summary": self.executive_summary,
            "overall_status": self.overall_status.value,
            "overall_compliance_rate": self.overall_compliance_rate,
            "total_findings": self.total_findings,
            "metadata": self.metadata,
        }


class ComplianceReporter:
    """Generator for compliance reports."""

    def __init__(
        self,
        organization: str = "Organization",
        assessor: str = "Asqav QML Platform",
    ) -> None:
        """Initialize compliance reporter.

        Args:
            organization: Organization name for reports
            assessor: Assessor name for reports
        """
        self.organization = organization
        self.assessor = assessor

    def generate_iso42001_report(
        self,
        scan_reports: list[Any],
        scope: str = "AI/ML System Security",
    ) -> ComplianceReport:
        """Generate ISO/IEC 42001:2023 compliance report.

        ISO 42001 specifies requirements for an AI management system (AIMS).
        This maps QML security scan results to relevant controls.

        Args:
            scan_reports: List of PlatformReport objects
            scope: Scope description for the assessment

        Returns:
            ComplianceReport for ISO 42001
        """
        report = ComplianceReport(
            report_id=str(uuid.uuid4()),
            standard=ComplianceStandard.ISO_42001,
            title="ISO/IEC 42001:2023 AI Management System Compliance Report",
            generated_at=datetime.now(tz=UTC),
            organization=self.organization,
            assessor=self.assessor,
            scope=scope,
        )

        # Analyze scan reports
        has_scans = len(scan_reports) > 0
        high_risk_found = any(
            r.overall_risk.value in ("high", "critical")
            for r in scan_reports
        ) if has_scans else False
        integrity_verified = any(
            any(m.scan_type.value == "integrity" and m.status.value == "completed"
                for m in r.module_results)
            for r in scan_reports
        ) if has_scans else False
        backdoor_scanned = any(
            any(m.scan_type.value == "backdoor" for m in r.module_results)
            for r in scan_reports
        ) if has_scans else False

        # Section 6: Planning - Risk Assessment
        section6 = ComplianceSection(
            section_id="6",
            section_name="Planning",
            description="Risk assessment and treatment for AI systems",
        )

        section6.controls.append(ControlAssessment(
            control_id="6.1.2",
            control_name="AI risk assessment",
            description="Organization shall identify and analyze AI-related risks",
            status=ControlStatus.COMPLIANT if has_scans else ControlStatus.NOT_ASSESSED,
            findings=[
                f"Automated security scans performed: {len(scan_reports)}"
            ] if has_scans else ["No security scans performed"],
            evidence=[
                f"Scan report IDs: {[r.report_id for r in scan_reports[:5]]}"
            ] if has_scans else [],
            recommendations=[] if has_scans else [
                "Implement regular QML security scanning"
            ],
        ))

        section6.controls.append(ControlAssessment(
            control_id="6.1.3",
            control_name="AI risk treatment",
            description="Organization shall determine actions to address AI risks",
            status=(
                ControlStatus.COMPLIANT if has_scans and not high_risk_found
                else ControlStatus.PARTIALLY_COMPLIANT if has_scans
                else ControlStatus.NOT_ASSESSED
            ),
            findings=[
                "High-risk findings detected in scans" if high_risk_found
                else "No high-risk findings in scans"
            ] if has_scans else [],
            recommendations=[
                "Address high-risk findings identified in scans"
            ] if high_risk_found else [],
        ))

        report.sections.append(section6)

        # Section 8: Operation - AI System Development
        section8 = ComplianceSection(
            section_id="8",
            section_name="Operation",
            description="AI system development and deployment controls",
        )

        section8.controls.append(ControlAssessment(
            control_id="8.4",
            control_name="AI system testing",
            description="Testing to verify AI system meets requirements",
            status=(
                ControlStatus.COMPLIANT if backdoor_scanned
                else ControlStatus.PARTIALLY_COMPLIANT if has_scans
                else ControlStatus.NOT_ASSESSED
            ),
            findings=[
                "Backdoor detection scans implemented" if backdoor_scanned
                else "Limited security testing coverage"
            ] if has_scans else [],
            evidence=[
                "QSentry backdoor detection active"
            ] if backdoor_scanned else [],
        ))

        section8.controls.append(ControlAssessment(
            control_id="8.5",
            control_name="AI system validation",
            description="Validation of AI system for intended use",
            status=(
                ControlStatus.COMPLIANT if integrity_verified
                else ControlStatus.NOT_ASSESSED
            ),
            findings=[
                "Model integrity verification implemented"
            ] if integrity_verified else ["Model integrity not verified"],
            recommendations=[] if integrity_verified else [
                "Implement model integrity verification with ML-DSA signatures"
            ],
        ))

        report.sections.append(section8)

        # Section 9: Performance Evaluation
        section9 = ComplianceSection(
            section_id="9",
            section_name="Performance Evaluation",
            description="Monitoring and measurement of AI system performance",
        )

        section9.controls.append(ControlAssessment(
            control_id="9.1",
            control_name="Monitoring and measurement",
            description="Monitor AI system security posture",
            status=ControlStatus.COMPLIANT if has_scans else ControlStatus.NOT_ASSESSED,
            findings=[
                f"Security monitoring active with {len(scan_reports)} scans"
            ] if has_scans else [],
            evidence=[
                "QML Security Platform deployed"
            ] if has_scans else [],
        ))

        section9.controls.append(ControlAssessment(
            control_id="9.2",
            control_name="Internal audit",
            description="Conduct internal audits of AI management system",
            status=(
                ControlStatus.COMPLIANT if has_scans and len(scan_reports) >= 3
                else ControlStatus.PARTIALLY_COMPLIANT if has_scans
                else ControlStatus.NOT_ASSESSED
            ),
            findings=[
                f"Automated audit via security scans: {len(scan_reports)} performed"
            ] if has_scans else [],
            recommendations=[
                "Increase scan frequency for comprehensive coverage"
            ] if has_scans and len(scan_reports) < 3 else [],
        ))

        report.sections.append(section9)

        # Generate executive summary
        report.executive_summary = self._generate_executive_summary(report)
        report.overall_status = self._calculate_overall_status(report)

        return report

    def generate_nist_report(
        self,
        scan_reports: list[Any],
        scope: str = "AI/ML System Security",
    ) -> ComplianceReport:
        """Generate NIST AI Risk Management Framework report.

        Maps QML security scan results to NIST AI RMF functions:
        - GOVERN
        - MAP
        - MEASURE
        - MANAGE

        Args:
            scan_reports: List of PlatformReport objects
            scope: Scope description for the assessment

        Returns:
            ComplianceReport for NIST AI RMF
        """
        report = ComplianceReport(
            report_id=str(uuid.uuid4()),
            standard=ComplianceStandard.NIST_AI_RMF,
            title="NIST AI Risk Management Framework Compliance Report",
            generated_at=datetime.now(tz=UTC),
            organization=self.organization,
            assessor=self.assessor,
            scope=scope,
        )

        # Analyze scan reports
        has_scans = len(scan_reports) > 0
        high_risk_count = sum(
            1 for r in scan_reports
            if r.overall_risk.value in ("high", "critical")
        ) if has_scans else 0
        total_findings = sum(
            len(r.failed_modules) for r in scan_reports
        ) if has_scans else 0

        # GOVERN function
        govern = ComplianceSection(
            section_id="GOVERN",
            section_name="Govern",
            description="Cultivate a culture of risk management",
        )

        govern.controls.append(ControlAssessment(
            control_id="GOVERN-1.1",
            control_name="Risk Management Policies",
            description="Policies for AI risk management are established",
            status=ControlStatus.COMPLIANT if has_scans else ControlStatus.NOT_ASSESSED,
            findings=[
                "Automated security scanning implemented"
            ] if has_scans else [],
        ))

        govern.controls.append(ControlAssessment(
            control_id="GOVERN-1.5",
            control_name="Risk Tolerances",
            description="Risk tolerances are established and monitored",
            status=(
                ControlStatus.COMPLIANT if has_scans and high_risk_count == 0
                else ControlStatus.PARTIALLY_COMPLIANT if has_scans
                else ControlStatus.NOT_ASSESSED
            ),
            findings=[
                f"High-risk scan results: {high_risk_count}"
            ] if has_scans else [],
        ))

        report.sections.append(govern)

        # MAP function
        map_section = ComplianceSection(
            section_id="MAP",
            section_name="Map",
            description="Categorize and understand AI system context",
        )

        map_section.controls.append(ControlAssessment(
            control_id="MAP-1.1",
            control_name="System Characterization",
            description="AI system components and dependencies identified",
            status=ControlStatus.COMPLIANT if has_scans else ControlStatus.NOT_ASSESSED,
            findings=[
                "QML security modules profiling system"
            ] if has_scans else [],
            evidence=[
                "Model registry, noise profiler, VQC verifier active"
            ] if has_scans else [],
        ))

        map_section.controls.append(ControlAssessment(
            control_id="MAP-3.1",
            control_name="Third-Party Risk",
            description="Third-party AI risks are identified",
            status=(
                ControlStatus.COMPLIANT if any(
                    any(m.scan_type.value == "noise" for m in r.module_results)
                    for r in scan_reports
                )
                else ControlStatus.NOT_ASSESSED
            ),
            findings=[
                "Device fingerprinting via noise profiler"
            ] if has_scans else [],
        ))

        report.sections.append(map_section)

        # MEASURE function
        measure = ComplianceSection(
            section_id="MEASURE",
            section_name="Measure",
            description="Analyze and assess AI risks",
        )

        measure.controls.append(ControlAssessment(
            control_id="MEASURE-1.1",
            control_name="Risk Assessment Methods",
            description="Methods to assess AI risks are established",
            status=ControlStatus.COMPLIANT if has_scans else ControlStatus.NOT_ASSESSED,
            findings=[
                f"Automated assessment via {len(scan_reports)} security scans"
            ] if has_scans else [],
        ))

        measure.controls.append(ControlAssessment(
            control_id="MEASURE-2.3",
            control_name="Adversarial Testing",
            description="AI system tested for adversarial robustness",
            status=(
                ControlStatus.COMPLIANT if any(
                    any(m.scan_type.value == "robustness" for m in r.module_results)
                    for r in scan_reports
                )
                else ControlStatus.PARTIALLY_COMPLIANT if has_scans
                else ControlStatus.NOT_ASSESSED
            ),
            findings=[
                "VQC robustness verification implemented"
            ] if has_scans else [],
        ))

        measure.controls.append(ControlAssessment(
            control_id="MEASURE-2.6",
            control_name="Security Testing",
            description="AI system tested for security vulnerabilities",
            status=(
                ControlStatus.COMPLIANT if any(
                    any(m.scan_type.value == "backdoor" for m in r.module_results)
                    for r in scan_reports
                )
                else ControlStatus.NOT_ASSESSED
            ),
            findings=[
                "QSentry backdoor detection active"
            ] if has_scans else [],
        ))

        report.sections.append(measure)

        # MANAGE function
        manage = ComplianceSection(
            section_id="MANAGE",
            section_name="Manage",
            description="Manage AI risks based on assessment",
        )

        manage.controls.append(ControlAssessment(
            control_id="MANAGE-1.1",
            control_name="Risk Prioritization",
            description="AI risks are prioritized for treatment",
            status=ControlStatus.COMPLIANT if has_scans else ControlStatus.NOT_ASSESSED,
            findings=[
                f"Risks categorized: {high_risk_count} high, {len(scan_reports) - high_risk_count} acceptable"
            ] if has_scans else [],
        ))

        manage.controls.append(ControlAssessment(
            control_id="MANAGE-2.1",
            control_name="Risk Response",
            description="Responses to AI risks are identified",
            status=(
                ControlStatus.COMPLIANT if total_findings == 0 and has_scans
                else ControlStatus.PARTIALLY_COMPLIANT if has_scans
                else ControlStatus.NOT_ASSESSED
            ),
            findings=[
                f"Active findings requiring response: {total_findings}"
            ] if has_scans else [],
            recommendations=[
                "Address identified security findings"
            ] if total_findings > 0 else [],
        ))

        manage.controls.append(ControlAssessment(
            control_id="MANAGE-4.1",
            control_name="Continuous Monitoring",
            description="AI risks are continuously monitored",
            status=ControlStatus.COMPLIANT if has_scans else ControlStatus.NOT_ASSESSED,
            findings=[
                "QML Security Platform provides continuous monitoring"
            ] if has_scans else [],
        ))

        report.sections.append(manage)

        # Generate executive summary
        report.executive_summary = self._generate_executive_summary(report)
        report.overall_status = self._calculate_overall_status(report)

        return report

    def generate_custom_report(
        self,
        scan_reports: list[Any],
        title: str = "Security Audit Report",
        scope: str = "AI/ML System Security",
    ) -> ComplianceReport:
        """Generate a custom audit report.

        Args:
            scan_reports: List of PlatformReport objects
            title: Report title
            scope: Scope description

        Returns:
            Custom ComplianceReport
        """
        report = ComplianceReport(
            report_id=str(uuid.uuid4()),
            standard=ComplianceStandard.CUSTOM,
            title=title,
            generated_at=datetime.now(tz=UTC),
            organization=self.organization,
            assessor=self.assessor,
            scope=scope,
        )

        # Create sections from scan results
        for scan in scan_reports:
            section = ComplianceSection(
                section_id=scan.report_id[:8],
                section_name=f"Scan: {scan.timestamp.strftime('%Y-%m-%d %H:%M')}",
                description=scan.summary,
            )

            for result in scan.module_results:
                status = (
                    ControlStatus.COMPLIANT if result.risk_level in ("low", "secure")
                    else ControlStatus.PARTIALLY_COMPLIANT if result.risk_level == "medium"
                    else ControlStatus.NON_COMPLIANT if result.risk_level in ("high", "critical")
                    else ControlStatus.NOT_ASSESSED
                )

                section.controls.append(ControlAssessment(
                    control_id=f"{result.module_name}:{result.scan_type.value}",
                    control_name=f"{result.module_name} - {result.scan_type.value}",
                    description=f"Security scan of {result.module_name}",
                    status=status,
                    findings=[
                        f"Risk level: {result.risk_level}",
                        f"Confidence: {result.confidence:.1%}",
                    ],
                    evidence=[str(result.details)] if result.details else [],
                    recommendations=scan.recommendations,
                ))

            report.sections.append(section)

        report.executive_summary = self._generate_executive_summary(report)
        report.overall_status = self._calculate_overall_status(report)

        return report

    def _generate_executive_summary(self, report: ComplianceReport) -> str:
        """Generate executive summary for a report."""
        rate = report.overall_compliance_rate
        findings = report.total_findings

        if rate >= 90:
            status_desc = "strong"
        elif rate >= 70:
            status_desc = "adequate"
        elif rate >= 50:
            status_desc = "needs improvement"
        else:
            status_desc = "requires immediate attention"

        return (
            f"This {report.standard.value.replace('_', ' ').upper()} compliance assessment "
            f"evaluated {report.scope} for {report.organization}. "
            f"The overall compliance rate is {rate:.1f}%, indicating {status_desc} alignment "
            f"with the standard. A total of {findings} findings were identified across "
            f"{len(report.sections)} assessment areas. "
            f"Recommendations are provided for areas requiring improvement."
        )

    def _calculate_overall_status(self, report: ComplianceReport) -> ControlStatus:
        """Calculate overall compliance status."""
        rate = report.overall_compliance_rate

        if rate >= 90:
            return ControlStatus.COMPLIANT
        elif rate >= 70:
            return ControlStatus.PARTIALLY_COMPLIANT
        else:
            return ControlStatus.NON_COMPLIANT

    def export_html(self, report: ComplianceReport) -> str:
        """Export report to HTML format.

        Args:
            report: ComplianceReport to export

        Returns:
            HTML string
        """
        status_colors = {
            ControlStatus.COMPLIANT: "#28a745",
            ControlStatus.PARTIALLY_COMPLIANT: "#ffc107",
            ControlStatus.NON_COMPLIANT: "#dc3545",
            ControlStatus.NOT_APPLICABLE: "#6c757d",
            ControlStatus.NOT_ASSESSED: "#17a2b8",
        }

        sections_html = ""
        for section in report.sections:
            controls_html = ""
            for control in section.controls:
                color = status_colors.get(control.status, "#6c757d")
                findings_html = "".join(f"<li>{f}</li>" for f in control.findings)
                recommendations_html = "".join(f"<li>{r}</li>" for r in control.recommendations)

                controls_html += f"""
                <div class="control">
                    <div class="control-header">
                        <span class="control-id">{control.control_id}</span>
                        <span class="control-name">{control.control_name}</span>
                        <span class="status" style="background-color: {color};">
                            {control.status.value.replace('_', ' ').title()}
                        </span>
                    </div>
                    <p class="description">{control.description}</p>
                    {"<h5>Findings</h5><ul>" + findings_html + "</ul>" if control.findings else ""}
                    {"<h5>Recommendations</h5><ul>" + recommendations_html + "</ul>" if control.recommendations else ""}
                </div>
                """

            sections_html += f"""
            <div class="section">
                <h3>{section.section_id}. {section.section_name}</h3>
                <p>{section.description}</p>
                <p class="compliance-rate">Compliance Rate: {section.compliance_rate:.1f}%</p>
                {controls_html}
            </div>
            """

        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{report.title}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; color: #333; }}
        h1 {{ color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }}
        h2 {{ color: #2c3e50; margin-top: 30px; }}
        h3 {{ color: #34495e; margin-top: 25px; }}
        .metadata {{ background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }}
        .metadata p {{ margin: 5px 0; }}
        .summary {{ background: #e8f4f8; padding: 20px; border-left: 4px solid #3498db; margin: 20px 0; }}
        .section {{ margin: 30px 0; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }}
        .control {{ margin: 15px 0; padding: 15px; background: #fff; border: 1px solid #eee; }}
        .control-header {{ display: flex; align-items: center; gap: 15px; margin-bottom: 10px; }}
        .control-id {{ font-weight: bold; color: #3498db; }}
        .control-name {{ flex-grow: 1; font-weight: 500; }}
        .status {{ padding: 3px 10px; border-radius: 3px; color: white; font-size: 0.85em; }}
        .description {{ color: #666; font-style: italic; }}
        .compliance-rate {{ font-weight: bold; color: #27ae60; }}
        ul {{ margin: 10px 0; padding-left: 25px; }}
        li {{ margin: 5px 0; }}
        h5 {{ margin: 10px 0 5px; color: #555; }}
        .footer {{ margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 0.9em; }}
    </style>
</head>
<body>
    <h1>{report.title}</h1>

    <div class="metadata">
        <p><strong>Report ID:</strong> {report.report_id}</p>
        <p><strong>Generated:</strong> {report.generated_at.strftime('%Y-%m-%d %H:%M:%S UTC')}</p>
        <p><strong>Organization:</strong> {report.organization}</p>
        <p><strong>Assessor:</strong> {report.assessor}</p>
        <p><strong>Scope:</strong> {report.scope}</p>
        <p><strong>Overall Compliance:</strong> {report.overall_compliance_rate:.1f}%</p>
        <p><strong>Status:</strong> {report.overall_status.value.replace('_', ' ').title()}</p>
    </div>

    <h2>Executive Summary</h2>
    <div class="summary">
        <p>{report.executive_summary}</p>
    </div>

    <h2>Assessment Details</h2>
    {sections_html}

    <div class="footer">
        <p>Generated by Asqav QML Security Platform</p>
        <p>Standard: {report.standard.value.replace('_', ' ').upper()}</p>
    </div>
</body>
</html>"""

        return html

    def export_text(self, report: ComplianceReport) -> str:
        """Export report to plain text format.

        Args:
            report: ComplianceReport to export

        Returns:
            Plain text string
        """
        lines = [
            "=" * 70,
            report.title.center(70),
            "=" * 70,
            "",
            f"Report ID: {report.report_id}",
            f"Generated: {report.generated_at.strftime('%Y-%m-%d %H:%M:%S UTC')}",
            f"Organization: {report.organization}",
            f"Assessor: {report.assessor}",
            f"Scope: {report.scope}",
            f"Overall Compliance: {report.overall_compliance_rate:.1f}%",
            f"Status: {report.overall_status.value.replace('_', ' ').title()}",
            "",
            "-" * 70,
            "EXECUTIVE SUMMARY",
            "-" * 70,
            "",
            report.executive_summary,
            "",
        ]

        for section in report.sections:
            lines.extend([
                "-" * 70,
                f"{section.section_id}. {section.section_name}",
                "-" * 70,
                section.description,
                f"Compliance Rate: {section.compliance_rate:.1f}%",
                "",
            ])

            for control in section.controls:
                status = control.status.value.replace('_', ' ').upper()
                lines.extend([
                    f"  [{control.control_id}] {control.control_name}",
                    f"  Status: {status}",
                    f"  {control.description}",
                ])

                if control.findings:
                    lines.append("  Findings:")
                    for f in control.findings:
                        lines.append(f"    - {f}")

                if control.recommendations:
                    lines.append("  Recommendations:")
                    for r in control.recommendations:
                        lines.append(f"    - {r}")

                lines.append("")

        lines.extend([
            "=" * 70,
            "Generated by Asqav QML Security Platform",
            f"Standard: {report.standard.value.replace('_', ' ').upper()}",
            "=" * 70,
        ])

        return "\n".join(lines)


def create_reporter(
    organization: str = "Organization",
    assessor: str = "Asqav QML Platform",
) -> ComplianceReporter:
    """Create a compliance reporter.

    Args:
        organization: Organization name
        assessor: Assessor name

    Returns:
        Configured ComplianceReporter
    """
    return ComplianceReporter(organization=organization, assessor=assessor)
