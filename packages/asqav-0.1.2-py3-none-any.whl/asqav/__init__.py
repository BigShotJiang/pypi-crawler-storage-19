"""
Asqav: Quantum-safe identity and runtime monitoring for AI agents.

This package provides post-quantum cryptographic identity management
for AI agents using NIST FIPS 204 ML-DSA (Module-Lattice Digital
Signature Algorithm).

Example:
    from asqav import SecureAgent

    # Create a quantum-safe agent identity
    agent = SecureAgent.create(
        name="my-agent",
        algorithm="ml-dsa-65",
        capabilities=["read:data", "write:logs"]
    )

    # Runtime monitoring session
    with agent.session() as session:
        session.log_action("read:data", {"file": "config.json"})

    # Issue a token
    token = agent.issue_token_string()

    # Verify another agent's token
    claims = SecureAgent.verify(incoming_token, public_key)

    # Check if an agent is revoked
    if SecureAgent.is_agent_revoked(agent_id):
        raise SecurityError("Agent revoked")

    # Assess legacy token risk
    risk = SecureAgent.assess_risk("ES256")
    # {"algorithm": "ES256", "quantum_safe": False, "risk": "HIGH", ...}
"""

# Core modules
from .core import (
    ActionRecord,
    ActionType,
    DelegationChain,
    DelegationRecord,
    IdentityProvider,
    KeyPair,
    LocalStorage,
    MLDSALevel,
    PQCToken,
    RevocationList,
    RevocationReason,
    RevocationRecord,
    SecureAgent,
    Session,
    Signature,
    TokenClaims,
    TokenExpiredError,
    TokenHeader,
    TokenIssuer,
    TokenNotYetValidError,
    TokenVerifier,
    assess_token_risk,
    attenuate_scope,
    create_agent,
    format_action_log,
    generate_agent_id,
    get_available_algorithms,
    get_revocation_list,
    is_revoked,
    parse_algorithm,
    revoke_agent,
)

# AI Agent Framework Integrations
from .integrations import (
    OpenCodeSecureAgent,
    OpenCodeToolCall,
    SignedToolResult,
    create_opencode_agent,
)

# MCP Gateway
from .mcp import (
    AsqavMCPGatewayServer,
    AsqavMCPServer,
    GatewayAuditEntry,
    MCPGateway,
)
from .mcp import (
    SignedToolCall as MCPSignedToolCall,
)
from .mcp import (
    SignedToolResult as MCPSignedToolResult,
)

# Platform modules (Alerts, Compliance, Anomaly Detection)
from .platform import (
    Alert,
    AlertEngine,
    AlertRule,
    AlertSeverity,
    AlertStatus,
    AlertStorage,
    ComplianceReport,
    ComplianceReporter,
    ComplianceSection,
    ComplianceStandard,
    ConsoleNotifier,
    ControlAssessment,
    ControlStatus,
    EmailNotifier,
    Notifier,
    PagerDutyNotifier,
    SlackNotifier,
    WebhookNotifier,
    create_alert_engine,
    create_reporter,
)

# QML Security modules
from .qml import (
    BackdoorReport,
    BackdoorRisk,
    GateType,
    MatchResult,
    MatchStatus,
    MeasurementData,
    MeasurementDistributionRule,
    ModelMetadata,
    ModelRegistry,
    ModuleScanResult,
    NoiseProfile,
    NoiseProfiler,
    NoiseProfileStorage,
    NoiseType,
    OverallRisk,
    PlatformConfig,
    PlatformReport,
    PlatformStatus,
    QMLAnomalyDetector,
    QMLPlatform,
    QSentry,
    QuantumCircuit,
    QuantumGate,
    QuantumInterval,
    QubitNoiseParams,
    RegistryEntry,
    RobustnessCertificate,
    RobustnessStatus,
    ScanStatus,
    ScanType,
    VerificationReport,
    VerificationResult,
    VQCVerifier,
    analyze_measurements,
    compute_file_hash,
    create_platform,
    create_qml_detector,
    create_simple_vqc,
    create_synthetic_profile,
    verify_vqc_robustness,
)

__version__ = "0.1.0"
__all__ = [
    # Main classes
    "SecureAgent",
    "create_agent",
    # Identity
    "IdentityProvider",
    "KeyPair",
    "MLDSALevel",
    "Signature",
    "generate_agent_id",
    "get_available_algorithms",
    "parse_algorithm",
    # Tokens
    "PQCToken",
    "TokenClaims",
    "TokenHeader",
    "TokenIssuer",
    "TokenVerifier",
    "TokenExpiredError",
    "TokenNotYetValidError",
    "assess_token_risk",
    # Sessions
    "Session",
    "ActionRecord",
    "ActionType",
    "LocalStorage",
    "format_action_log",
    # Delegation
    "DelegationChain",
    "DelegationRecord",
    "attenuate_scope",
    # Revocation
    "RevocationList",
    "RevocationReason",
    "RevocationRecord",
    "get_revocation_list",
    "is_revoked",
    "revoke_agent",
    # Model Registry
    "ModelRegistry",
    "ModelMetadata",
    "RegistryEntry",
    "VerificationResult",
    "compute_file_hash",
    # QML Anomaly Detection
    "QMLAnomalyDetector",
    "MeasurementData",
    "MeasurementDistributionRule",
    "create_qml_detector",
    # QSentry Backdoor Detection
    "QSentry",
    "BackdoorReport",
    "BackdoorRisk",
    "analyze_measurements",
    # VQC Verifier (Tier 2)
    "VQCVerifier",
    "QuantumCircuit",
    "QuantumGate",
    "QuantumInterval",
    "GateType",
    "RobustnessStatus",
    "RobustnessCertificate",
    "VerificationReport",
    "create_simple_vqc",
    "verify_vqc_robustness",
    # Noise Profiler (Tier 2)
    "NoiseProfiler",
    "NoiseProfile",
    "QubitNoiseParams",
    "NoiseType",
    "MatchStatus",
    "MatchResult",
    "NoiseProfileStorage",
    "create_synthetic_profile",
    # QML Platform (Tier 3)
    "QMLPlatform",
    "PlatformConfig",
    "PlatformReport",
    "PlatformStatus",
    "ModuleScanResult",
    "OverallRisk",
    "ScanType",
    "ScanStatus",
    "create_platform",
    # Alert System (Tier 3)
    "AlertEngine",
    "Alert",
    "AlertRule",
    "AlertSeverity",
    "AlertStatus",
    "AlertStorage",
    "Notifier",
    "ConsoleNotifier",
    "WebhookNotifier",
    "SlackNotifier",
    "EmailNotifier",
    "PagerDutyNotifier",
    "create_alert_engine",
    # Compliance Reporting (Tier 3)
    "ComplianceReporter",
    "ComplianceReport",
    "ComplianceSection",
    "ComplianceStandard",
    "ControlAssessment",
    "ControlStatus",
    "create_reporter",
    # AI Agent Framework Integrations
    "OpenCodeSecureAgent",
    "OpenCodeToolCall",
    "SignedToolResult",
    "create_opencode_agent",
    # MCP Gateway
    "MCPGateway",
    "MCPSignedToolCall",
    "MCPSignedToolResult",
    "GatewayAuditEntry",
    "AsqavMCPServer",
    "AsqavMCPGatewayServer",
]
