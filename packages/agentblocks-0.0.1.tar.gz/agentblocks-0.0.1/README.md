# agentblocks

Reusable primitives, components, layouts, and templates for AI-assisted development.

🚧 **Under active development** - More coming soon.

## Vision

A comprehensive library of pre-built, composable building blocks that AI agents can use to rapidly scaffold applications without generating boilerplate from scratch.

- UI Components (React/TypeScript)
- Layout templates (dashboards, landing pages, etc.)
- Backend patterns (error handling, auth flows, API scaffolds)
- Consistent conventions across the stack

## License

MIT
