#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}  Package Publisher: agentblocks & agentblocks${NC}"
echo -e "${YELLOW}========================================${NC}"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Check for required tools
check_tools() {
    echo -e "${YELLOW}Checking required tools...${NC}"
    
    if ! command -v npm &> /dev/null; then
        echo -e "${RED}Error: npm not found. Install Node.js first.${NC}"
        exit 1
    fi
    
    if ! command -v python3 &> /dev/null; then
        echo -e "${RED}Error: python3 not found.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✓ All tools available${NC}"
    echo ""
}

# Check authentication status
check_auth() {
    echo -e "${YELLOW}Checking authentication...${NC}"
    
    # Check npm
    if npm whoami &> /dev/null; then
        NPM_USER=$(npm whoami)
        echo -e "${GREEN}✓ npm: logged in as ${NPM_USER}${NC}"
    else
        echo -e "${RED}✗ npm: not logged in${NC}"
        echo -e "  Run: ${YELLOW}npm login${NC}"
        NPM_AUTH=false
    fi
    
    # Check PyPI
    if [[ -f ~/.pypirc ]] && grep -q "pypi" ~/.pypirc; then
        echo -e "${GREEN}✓ PyPI: .pypirc found${NC}"
    else
        echo -e "${RED}✗ PyPI: ~/.pypirc not configured${NC}"
        echo -e "  1. Create token at: ${YELLOW}https://pypi.org/manage/account/token/${NC}"
        echo -e "  2. Add to ~/.pypirc:"
        echo -e "     ${YELLOW}[pypi]${NC}"
        echo -e "     ${YELLOW}username = __token__${NC}"
        echo -e "     ${YELLOW}password = pypi-YOUR-TOKEN-HERE${NC}"
        PYPI_AUTH=false
    fi
    
    if [[ "$NPM_AUTH" == "false" ]] || [[ "$PYPI_AUTH" == "false" ]]; then
        echo ""
        echo -e "${RED}Please authenticate and run again.${NC}"
        exit 1
    fi
    
    echo ""
}

# Install Python build tools
setup_python_tools() {
    echo -e "${YELLOW}Ensuring Python build tools...${NC}"
    pip install --quiet --upgrade build twine
    echo -e "${GREEN}✓ build and twine ready${NC}"
    echo ""
}

# Publish a package to npm
publish_npm() {
    local pkg_dir=$1
    local pkg_name=$2
    
    echo -e "${YELLOW}Publishing ${pkg_name} to npm...${NC}"
    cd "$pkg_dir"
    
    if npm view "$pkg_name" &> /dev/null; then
        echo -e "${RED}✗ ${pkg_name} already exists on npm${NC}"
        return 1
    fi
    
    npm publish --access public
    echo -e "${GREEN}✓ ${pkg_name} published to npm${NC}"
}

# Publish a package to PyPI
publish_pypi() {
    local pkg_dir=$1
    local pkg_name=$2
    
    echo -e "${YELLOW}Publishing ${pkg_name} to PyPI...${NC}"
    cd "$pkg_dir"
    
    # Clean previous builds
    rm -rf dist/ build/ *.egg-info src/*.egg-info
    
    # Build
    python3 -m build --sdist --wheel
    
    # Upload
    twine upload dist/* --skip-existing
    echo -e "${GREEN}✓ ${pkg_name} published to PyPI${NC}"
}

# Main
main() {
    check_tools
    check_auth
    setup_python_tools
    
    echo -e "${YELLOW}========================================${NC}"
    echo -e "${YELLOW}  Publishing packages...${NC}"
    echo -e "${YELLOW}========================================${NC}"
    echo ""
    
    # Publish agentblocks
    echo -e "${YELLOW}--- agentblocks ---${NC}"
    publish_npm "$SCRIPT_DIR/agentblocks" "agentblocks" || true
    publish_pypi "$SCRIPT_DIR/agentblocks" "agentblocks" || true
    echo ""
    
    # Publish agentblocks
    echo -e "${YELLOW}--- agentblocks ---${NC}"
    publish_npm "$SCRIPT_DIR/agentblocks" "agentblocks" || true
    publish_pypi "$SCRIPT_DIR/agentblocks" "agentblocks" || true
    echo ""
    
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}  Done!${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo ""
    echo "Verify at:"
    echo "  https://www.npmjs.com/package/agentblocks"
    echo "  https://www.npmjs.com/package/agentblocks"
    echo "  https://pypi.org/project/agentblocks/"
    echo "  https://pypi.org/project/agentblocks/"
}

main "$@"
