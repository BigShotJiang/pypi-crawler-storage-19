# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.1] - 2025-01-12

### Fixed
- Fixed package installation structure - now installs correctly as `cron_builder.py`
- Added proper file mapping in `pyproject.toml` using `force-include`
- Package now imports correctly: `from cron_builder import CronBuilder`

### Changed
- Simplified to flat `src/` layout (single `src/cron_builder.py` file)
- Updated build configuration for Hatchling

## [0.1.0] - 2025-01-11

### Added
- Initial release
- Fluent API for building cron expressions
- Type-safe with full type hints
- Validated input with automatic range checking
- Support for Weekday and Month enums
- Immutable mode for functional programming
- Smart `should_run()` for schedule validation
- 75 comprehensive tests with 100% coverage
- Zero runtime dependencies
- Complete documentation

### Features
- Time methods: `at()`, `at_hour()`, `at_minute()`, `every_minutes()`, etc.
- Day methods: `on_dom()`, `on_dow()`, `on_weekdays()`, `on_weekends()`
- Month methods: `in_month()`, `in_months()`, `month_range()`
- Convenience presets: `hourly()`, `daily()`, `weekly()`, `monthly()`, `yearly()`
- Conjunction support: `and_dow()`, `and_dom()` for complex schedules
- `should_run()` method for runtime validation

[0.1.1]: https://github.com/brunolnetto/cron-builder/releases/tag/v0.1.1
[0.1.0]: https://github.com/brunolnetto/cron-builder/releases/tag/v0.1.0
