"""OpenBotAuth verifier tests."""
