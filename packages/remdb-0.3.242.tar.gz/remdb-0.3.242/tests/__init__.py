"""
REM Test Suite
"""
