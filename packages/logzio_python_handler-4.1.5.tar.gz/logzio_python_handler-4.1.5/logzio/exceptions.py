class LogzioException(Exception):
    pass
