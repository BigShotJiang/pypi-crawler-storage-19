"""
Sales Agent Schemas - Pydantic models for typed workflow analysis.

This module contains all the Pydantic schemas used for sales agent analysis workflows,
including metrics, critiques, summaries, and sales-specific analysis components.
"""

from enum import Enum
from typing import Any, Optional, Union

from pydantic import BaseModel, ConfigDict, Field

# ============================================================================
# ENUMS
# ============================================================================


class MetricCategory(str, Enum):
    """Categories for metric scores."""

    COMMUNICATION = "communication"
    TECHNICAL = "technical"
    SALES = "sales"
    RAPPORT = "rapport"
    OBJECTION_HANDLING = "objection_handling"
    OTHER = "other"


class CritiqueSeverity(str, Enum):
    """Severity levels for critique items."""

    CRITICAL = "critical"
    MAJOR = "major"
    MINOR = "minor"
    SUGGESTION = "suggestion"


class InsightCategory(str, Enum):
    """Categories for golden nugget insights."""

    TECHNIQUE = "technique"
    OBJECTION = "objection"
    CLOSING = "closing"
    RAPPORT = "rapport"
    DISCOVERY = "discovery"
    PRESENTATION = "presentation"


class ImpactLevel(str, Enum):
    """Impact levels for insights."""

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class SalesStageEnum(str, Enum):
    """Stages in the sales process."""

    PROSPECTING = "prospecting"
    QUALIFICATION = "qualification"
    NEEDS_ANALYSIS = "needs_analysis"
    PROPOSAL = "proposal"
    NEGOTIATION = "negotiation"
    CLOSING = "closing"
    POST_SALE = "post_sale"


class ObjectionCategory(str, Enum):
    """Categories of sales objections."""

    PRICE = "price"
    TIMING = "timing"
    AUTHORITY = "authority"
    NEED = "need"
    COMPETITION = "competition"
    TRUST = "trust"


class ResponseQuality(str, Enum):
    """Quality ratings for responses."""

    EXCELLENT = "excellent"
    GOOD = "good"
    ADEQUATE = "adequate"
    POOR = "poor"
    MISSED = "missed"
    IGNORED = "ignored"


class QuestionType(str, Enum):
    """Types of discovery questions."""

    OPEN_ENDED = "open_ended"
    CLOSED = "closed"
    LEADING = "leading"
    PROBING = "probing"
    CLARIFYING = "clarifying"


class DiscoveryTopic(str, Enum):
    """Topics for discovery questions."""

    PAIN_POINTS = "pain_points"
    BUDGET = "budget"
    TIMELINE = "timeline"
    DECISION_PROCESS = "decision_process"
    GOALS = "goals"
    CURRENT_STATE = "current_state"


class ClosingTechnique(str, Enum):
    """Types of closing techniques."""

    ASSUMPTIVE = "assumptive"
    URGENCY = "urgency"
    SUMMARY = "summary"
    QUESTION = "question"
    DIRECT = "direct"
    SOFT = "soft"
    TRIAL = "trial"


class SalesMethodology(str, Enum):
    """Sales methodologies."""

    SPIN = "SPIN"
    BANT = "BANT"
    MEDDIC = "MEDDIC"
    SANDLER = "Sandler"
    CHALLENGER = "Challenger"
    CUSTOM = "Custom"
    NONE = "None"
    AUTO = "Auto"


class CallOutcome(str, Enum):
    """Possible call outcomes."""

    CLOSED_WON = "closed_won"
    CLOSED_LOST = "closed_lost"
    FOLLOW_UP_SCHEDULED = "follow_up_scheduled"
    NEEDS_FOLLOW_UP = "needs_follow_up"
    NO_DECISION = "no_decision"


# ============================================================================
# CORE ANALYSIS SCHEMAS
# ============================================================================


class Citation(BaseModel):
    """Reference to transcript with timing information."""

    model_config = ConfigDict(extra="allow")

    start_sec: Optional[float] = Field(
        None, description="Start time in seconds of the citation"
    )
    end_sec: Optional[float] = Field(
        None, description="End time in seconds of the citation"
    )
    match_confidence: Optional[str] = Field(
        None, description="Match confidence of the citation"
    )
    quote: Optional[str] = Field(
        None, description="The actual quote text from the transcript"
    )


class MetricScore(BaseModel):
    """Performance metric with score and explanation."""

    score: Union[int, float, str, None] = Field(
        None, description="Score from 0 to 10, or 'N/A' for inapplicable metrics"
    )
    explanation: str = Field(..., description="Explanation for the score")
    citations: Optional[list[Citation]] = Field(
        None, description="List of citations for the score"
    )
    detailed_explanation: Optional[list[Any]] = Field(
        None,
        description=(
            "Detailed breakdown of checklist items contributing to this metric score"
        ),
    )
    stage: Optional[str] = Field(
        None, description="Stage of the sales call. Eg. 'Prospecting/Lead'"
    )
    topic: Optional[str] = Field(
        None, description="Topic of the sales call. Eg. 'Active Qualification Assessment'"
    )

    def get_numeric_score(self) -> Optional[float]:
        """Convert score to float, handling various types.

        Returns:
            Float score or None if score is N/A, None, or cannot be converted.
        """
        # Handle numeric scores (int or float)
        if isinstance(self.score, (int, float)):
            return float(self.score)
        # Handle string scores that can be converted to float
        if isinstance(self.score, str):
            score_str = self.score.strip()
            if score_str and score_str.upper() != "N/A":
                try:
                    return float(score_str)
                except (ValueError, TypeError):
                    return None
        return None


class CritiqueItem(Citation):
    """Individual critique item."""

    model_config = ConfigDict(extra="allow")

    observation: str = Field("", description="Observation about the citation")
    type: str = Field("", description="Type: 'strength' or 'improvement_needed'")
    impact: Optional[str] = Field(None, description="Impact description of the issue")
    stage_relevance: Optional[str] = Field(
        None, description="Relevance to the current sales stage"
    )
    ideal_alternative_response: Optional[str] = Field(
        None, description="Exact alternative response they should have said instead"
    )


class KeyMoment(Citation):
    """
    Key coaching moment extracted from call analysis.

    Represents a specific moment in the call where the sales representative
    could improve their approach, with the actual quote, ideal response,
    and importance scoring. Inherits start_sec, end_sec, and match_confidence
    from Citation for timestamp information.
    """

    model_config = ConfigDict(extra="allow")

    what_was_said: Optional[str] = Field(
        None, description="Exact verbatim quote from the transcript"
    )
    what_should_be_said: Optional[str] = Field(
        None,
        description=(
            "Ideal corrected response following brand standards and best practices"
        ),
    )
    reason: Optional[str] = Field(
        None,
        description=(
            "Why this moment matters for coaching - "
            "explain the impact and what needs improvement"
        ),
    )
    category: Optional[str] = Field(
        None,
        description=(
            "The metric topic this relates to "
            "(e.g., 'Call Opening', 'Product Knowledge')"
        ),
    )
    importance: Optional[int] = Field(
        None,
        ge=1,
        le=10,
        description=(
            "Score from 1-10 indicating how critical this coaching moment is "
            "(1=minor, 10=critical)"
        ),
    )


class FiveSecondSummary(BaseModel):
    """Five-second summary output from session analysis."""

    failed_to_handle: Optional[list[str]] = Field(
        ..., description="2-3 bullet points of major mistakes or missed opportunities"
    )
    did_well: Optional[list[str]] = Field(
        ..., description="2-3 bullet points of positive aspects or successful tactics"
    )
    the_fix: Optional[str] = Field(
        ..., description="A single, impactful suggestion for improvement"
    )
    result: Optional[str] = Field(
        ..., description="A brief statement of the call's outcome or main consequence"
    )
    progression_note: Optional[str] = Field(
        None,
        description=(
            "Optional 1-2 sentence summary of improvement or regression "
            "from previous sessions"
        ),
    )


class MetricExplanation(BaseModel):
    """Detailed explanation for a specific checklist item within a metric."""

    checklist_item: str = Field(
        ..., description="Description of the checklist item being evaluated"
    )
    satisfied: bool = Field(..., description="Whether this checklist item was satisfied")
    quotes: list[str] = Field(
        default_factory=list, description="Relevant quotes from the conversation"
    )
    reasoning: str = Field(
        ..., description="Reasoning for the satisfaction/non-satisfaction of this item"
    )


class SuggestionItem(Citation):
    """Individual suggestion for improvement."""

    current_approach: str = Field(..., description="Current approach description")
    suggested_improvement: str = Field(..., description="Suggested improvement")
    rationale: str = Field(..., description="Rationale for the suggestion")


class GoldenNuggetItem(Citation):
    """Golden nugget item from analysis workflow."""

    statement: str = Field(..., description="The golden nugget statement")
    team_impact: str = Field(..., description="How this can impact the team")
    stage_relevance: str = Field(..., description="Relevance to the current sales stage")


class OverallAssessment(BaseModel):
    """Overall assessment of the conversation."""

    strengths: list[str] = Field(..., description="List of strengths")
    areas_for_growth: list[str] = Field(..., description="Areas for improvement")
    priority_improvements: list[str] = Field(..., description="Priority improvements")


class MethodologyAnalysis(BaseModel):
    """Analysis output for a specific sales methodology."""

    methodology_type: str = Field(
        ..., description="Name of the methodology (e.g., MEDIC, MEDPIC, Challenger, BANT)"
    )
    analysis_points: list[str] = Field(
        ..., description="List of analysis points for this methodology"
    )


class ExtractedDataItem(BaseModel):
    """Single extracted data item with value and optional supporting quote."""

    value: Any = Field(
        ..., description="The extracted value (can be string, list, dict, etc.)"
    )
    quote: Optional[str] = Field(None, description="Supporting quote from the transcript")


# ============================================================================
# API REQUEST/RESPONSE SCHEMAS
# ============================================================================


class TranscriptData(BaseModel):
    """Model for conversation transcript data from ElevenLabs."""

    transcript: str = Field(..., description="The conversation transcript")
    conversation_id: str = Field(..., description="ElevenLabs conversation ID")
    agent_id: str = Field("", description="ElevenLabs agent ID")
    duration_secs: int = Field(0, description="Conversation duration in seconds")
    message_count: int = Field(0, description="Number of messages in conversation")
    status: str = Field("completed", description="Conversation status")
    request_status: str = Field(
        "success", description="Status of the transcript request (success/fail)"
    )


class AnalysisRequest(BaseModel):
    """Request model for running workflow analysis on a practice script."""

    metric_groups: Optional[str] = Field(
        default=None,
        description="JSON string of metric groups to evaluate in the analysis",
    )
    analysis_prompt: Optional[str] = Field(
        default=None, description="Custom prompt for guiding the analysis"
    )
    analysis_context: Optional[str] = Field(
        default=None,
        description="Additional background context (e.g., fact sheet) "
        "to inform the analysis",
    )
    run_without_cache: Optional[bool] = Field(
        default=None, description="Whether to run the analysis without cached results"
    )
    workflow_name: Optional[str] = Field(
        default=None,
        description=(
            "Name of the workflow to run " "(e.g., 'Practice Session Data Extraction')"
        ),
    )
    skip_methodology_analysis: Optional[bool] = Field(
        default=None,
        description=(
            "Skip sales methodology analysis (MEDIC, BANT, etc.) for non-B2B sales"
            " scenarios. "
            "If not provided, defaults to True for free trial orgs."
        ),
    )
    users_to_analyze: Optional[list[str]] = Field(
        default=None,
        description=(
            "List of speaker roles to analyze (e.g., ['user', 'agent']). "
            "Used to filter analysis to specific speakers in the transcript. "
            "If not provided, defaults to ['user']."
        ),
    )


class AnalysisResponse(BaseModel):
    """Response model for workflow analysis results."""

    status: str = Field(..., description="Analysis success status")
    analysis_output: Optional["AnalysisOutput"] = Field(
        None, description="Detailed analysis results"
    )
    analysis_id: Optional[str] = Field(
        None, description="entity which is being analyzed (meeting, session, etc.)"
    )
    id: Optional[str] = Field(None, description="Unique id of the analysis")
    error_message: Optional[str] = Field(None, description="Error message if failed")


class MetricCategoryModel(BaseModel):
    """Model for a single metric evaluation category.

    Field naming:
    - metric_id: Unique identifier for this specific metric (e.g., 'call_opening')
    - category_id: Group/category this metric belongs to (e.g., 'soft_skills')
    """

    metric_id: str = Field(..., description="Unique identifier for this metric")
    category_id: str = Field(
        ...,
        description="Category/group this metric belongs to (e.g., 'soft_skills', "
        "'sales_competencies')",
    )
    topic: str = Field(..., description="Display name/topic of the metric")
    checklist: list[str] = Field(
        ..., description="List of checklist items for this metric"
    )
    is_system: bool = Field(
        default=False, description="Whether this is a system-managed metric"
    )
    metric_source: Optional[str] = Field(
        default=None,
        description=(
            "Metric source identifier (e.g., 'general_sales', 'rivian') "
            "to distinguish metric sources"
        ),
    )
    rating_examples: Optional[dict[str, str]] = Field(
        default=None,
        description="Optional rating examples keyed by score (e.g., '1', '2', '3')",
    )
    minimum_score: int = Field(
        default=1, description="Minimum score for the metric (defaults to 1)"
    )
    maximum_score: int = Field(
        default=3, description="Maximum score for the metric (defaults to 3)"
    )
    weight: Optional[float] = Field(
        default=None, description="Weight for calculating overall score"
    )
    prompt_override: Optional[str] = Field(
        default=None, description="Optional prompt override for this specific metric"
    )

    # Backward compatibility - deprecated fields
    category_type: Optional[str] = Field(
        default=None,
        description=(
            "DEPRECATED: Use category_id instead. Kept for backward compatibility."
        ),
        deprecated=True,
    )


class ConversationAnalysis(BaseModel):
    """Output schema for conversation analysis with moments and causal chains.

    This schema captures reward signals and causal relationships in sales conversations
    for use in reinforcement learning and training data generation.
    """

    moments: list[Any] = Field(
        default_factory=list,
        description=(
            "Moment-by-moment reward analysis for reinforcement learning. "
            "Each moment contains turn, speaker, content, and reward signals."
        ),
    )
    causal_chains: list[Any] = Field(
        default_factory=list,
        description=(
            "Multi-step causal chains showing how actions led to outcomes. "
            "Each chain contains steps, value_created, and summary."
        ),
    )
    key_insights: list[str] = Field(
        default_factory=list,
        description=(
            "Key insights and patterns identified from moment and chain analysis. "
            "High-level takeaways about what made the conversation succeed/fail."
        ),
    )


class AnalysisOutput(BaseModel):
    """Expected structure for workflow analysis output.

    This model supports multiple types of analysis outputs:
    - Standard analysis: metric_scores, critique, suggestions, etc.
    - Moment chain analysis: moments, causal_chains, key_insights
    - Both can coexist in a single output

    Allows extra fields to support custom DSL schemas that extend the base output.
    """

    model_config = ConfigDict(extra="allow")

    metric_scores: dict[str, MetricScore] = Field(
        default_factory=dict,
        description="Metric scores with score and explanation for each",
    )
    extracted_metrics: Optional[dict[str, ExtractedDataItem]] = Field(
        default=None, description="Key-value pairs of extracted business data"
    )
    summary: str = Field(default="", description="Analysis summary")
    critique: list[CritiqueItem] = Field(
        default_factory=list,
        description="List of critiques with citations and observations",
    )
    suggestions: Optional[list[SuggestionItem]] = Field(
        default=None, description="List of improvement suggestions"
    )
    overall_assessment: Optional[OverallAssessment] = Field(
        default=None, description="Overall assessment with strengths and areas for growth"
    )
    five_second_summary: Optional[FiveSecondSummary] = Field(
        None, description="Five second summary"
    )
    methodology: Optional[list[MethodologyAnalysis]] = Field(
        None, description="List of sales methodology analyses"
    )
    golden_nuggets: Optional[list[GoldenNuggetItem]] = Field(
        None, description="List of golden nuggets"
    )
    key_moments: Optional[list[KeyMoment]] = Field(
        None,
        description=(
            "List of key coaching moments with what was said, "
            "what should be said, and importance scores"
        ),
    )
    metadata: Optional[dict[str, Any]] = Field(
        default=None,
        description=(
            "Misc metadata about the analysis. "
            "Includes workflow_run_id for streaming support and progress tracking."
        ),
    )

    # Moment and chain analysis fields (for RL training data)
    moments: Optional[list[Any]] = Field(
        default=None,
        description=(
            "Moment-by-moment reward analysis for reinforcement learning. "
            "Each moment contains turn, speaker, content, and reward signals."
        ),
    )
    causal_chains: Optional[list[Any]] = Field(
        default=None,
        description=(
            "Multi-step causal chains showing how actions led to outcomes. "
            "Each chain contains steps, value_created, and summary."
        ),
    )
    key_insights: Optional[list[str]] = Field(
        default=None,
        description=(
            "Key insights and patterns identified from moment and chain analysis. "
            "High-level takeaways about what made the conversation succeed/fail."
        ),
    )

    # Legacy field for backward compatibility
    conversation_analysis_json: Optional[dict[str, Any]] = Field(
        default=None,
        description=(
            "Legacy field containing moments, causal_chains, and key_insights. "
            "Use top-level moments/causal_chains/key_insights fields instead."
        ),
    )


class SalesStage(BaseModel):
    """Sales stage information with progression tracking."""

    current_stage: str = Field(..., description="Current stage in the sales cycle")
    confidence: float = Field(
        ..., description="Confidence level in the stage assessment (0-1)"
    )
    next_stage: Optional[str] = Field(None, description="Next recommended stage")
    blockers: list[str] = Field(
        default_factory=list, description="List of blockers preventing progression"
    )
    actions_to_advance: list[str] = Field(
        default_factory=list, description="Actions needed to advance to next stage"
    )


class SalesAnalysisOutput(AnalysisOutput):
    """Extended analysis output with sales-specific fields.

    Extends AnalysisOutput with additional sales-focused information:
    - Sales stage tracking and progression
    - Recommended next actions
    """

    sales_stage: Optional[SalesStage] = Field(
        None, description="Current sales stage with progression details"
    )
    recommended_next_actions: Optional[list[str]] = Field(
        None, description="List of recommended next actions based on the analysis"
    )


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================


def validate_metric_score(score: float) -> float:
    """Validate that a metric score is within valid range."""
    if not 0 <= score <= 10:
        raise ValueError(f"Score {score} is not between 0 and 10")
    return score


def create_empty_analysis() -> AnalysisOutput:
    """Create an empty analysis output with default values."""
    return AnalysisOutput(
        metric_scores={},
        critique=[],
        summary="No analysis performed",
        five_second_summary=FiveSecondSummary(
            did_well=["N/A"],
            failed_to_handle=[],
            the_fix="No analysis performed",
            result="No expected outcome",
            progression_note=None,
        ),
        methodology=None,
        golden_nuggets=None,
        key_moments=None,
        metadata={"empty": True},
    )


# ============================================================================
# SCHEMA REGISTRY
# ============================================================================

# Registry of all available schemas for easy access
SCHEMA_REGISTRY = {
    # Core schemas
    "Citation": Citation,
    "MetricScore": MetricScore,
    "MetricExplanation": MetricExplanation,
    "CritiqueItem": CritiqueItem,
    "SuggestionItem": SuggestionItem,
    "GoldenNuggetItem": GoldenNuggetItem,
    "FiveSecondSummary": FiveSecondSummary,
    "OverallAssessment": OverallAssessment,
    "MethodologyAnalysis": MethodologyAnalysis,
    "ExtractedDataItem": ExtractedDataItem,
    "ConversationAnalysis": ConversationAnalysis,
    # API schemas
    "TranscriptData": TranscriptData,
    "AnalysisRequest": AnalysisRequest,
    "AnalysisResponse": AnalysisResponse,
    "MetricCategoryModel": MetricCategoryModel,
    # Output schemas
    "AnalysisOutput": AnalysisOutput,
    "SalesStage": SalesStage,
    "SalesAnalysisOutput": SalesAnalysisOutput,
}


def get_schema(name: str) -> type[BaseModel]:
    """Get a schema class by name."""
    if name not in SCHEMA_REGISTRY:
        raise KeyError(f"Schema '{name}' not found in registry")
    return SCHEMA_REGISTRY[name]  # type: ignore[return-value]


def list_schemas() -> list[str]:
    """List all available schema names."""
    return list(SCHEMA_REGISTRY.keys())


# Export commonly used schemas at module level
__all__ = [
    # Enums
    "MetricCategory",
    "CritiqueSeverity",
    "InsightCategory",
    "ImpactLevel",
    "SalesStageEnum",
    "ObjectionCategory",
    "ResponseQuality",
    "QuestionType",
    "DiscoveryTopic",
    "ClosingTechnique",
    "SalesMethodology",
    "CallOutcome",
    # Core schemas
    "Citation",
    "MetricScore",
    "MetricExplanation",
    "CritiqueItem",
    "KeyMoment",
    "SuggestionItem",
    "GoldenNuggetItem",
    "FiveSecondSummary",
    "OverallAssessment",
    "MethodologyAnalysis",
    "ExtractedDataItem",
    # API schemas
    "TranscriptData",
    "AnalysisRequest",
    "AnalysisResponse",
    "MetricCategoryModel",
    # Output schemas
    "AnalysisOutput",
    "SalesStage",
    "SalesAnalysisOutput",
    # Registry and utilities
    "SCHEMA_REGISTRY",
    "get_schema",
    "list_schemas",
    "validate_metric_score",
    "create_empty_analysis",
]
