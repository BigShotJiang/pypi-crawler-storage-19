import base64
import typing as t

from pydantic import PlainSerializer, PlainValidator, WithJsonSchema

# Import sales agent schemas from the local module
from .sales_agent_schemas import (  # noqa: F401
    AnalysisOutput,
    CallOutcome,
    Citation,
    ClosingTechnique,
    CritiqueItem,
    CritiqueSeverity,
    DiscoveryTopic,
    FiveSecondSummary,
    ImpactLevel,
    InsightCategory,
    MetricCategory,
    MetricScore,
    ObjectionCategory,
    QuestionType,
    ResponseQuality,
    SalesAnalysisOutput,
    SalesMethodology,
    SalesStage,
    SalesStageEnum,
    create_empty_analysis,
    get_schema,
    list_schemas,
    validate_metric_score,
)


def serialize_base64bytes(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def validate_base64bytes(value: t.Any) -> bytes:
    match value:
        case bytes():
            return value
        case str():
            return base64.b64decode(value)
        case _:
            raise ValueError(f"Invalid input type: {type(value)}")


Base64Bytes = t.Annotated[
    bytes,
    PlainValidator(validate_base64bytes),
    PlainSerializer(serialize_base64bytes),
    WithJsonSchema({"type": "string", "format": "base64"}),
]

# Export all
__all__ = [
    # Base64 type
    "Base64Bytes",
    # Enums
    "MetricCategory",
    "CritiqueSeverity",
    "InsightCategory",
    "ImpactLevel",
    "SalesStageEnum",
    "ObjectionCategory",
    "ResponseQuality",
    "QuestionType",
    "DiscoveryTopic",
    "ClosingTechnique",
    "SalesMethodology",
    "CallOutcome",
    # Core schemas
    "Citation",
    "MetricScore",
    "CritiqueItem",
    "FiveSecondSummary",
    # Output schemas
    "AnalysisOutput",
    "SalesStage",
    "SalesAnalysisOutput",
    # Utility functions
    "validate_metric_score",
    "create_empty_analysis",
    "get_schema",
    "list_schemas",
]
