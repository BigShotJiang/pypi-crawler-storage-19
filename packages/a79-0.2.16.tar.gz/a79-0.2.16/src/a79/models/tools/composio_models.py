from typing import Any

from pydantic import BaseModel

from . import ToolSummary


class ComposioResult(BaseModel):
    result: Any
    tool_summary: ToolSummary | None = None
