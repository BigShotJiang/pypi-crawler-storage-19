from pydantic import BaseModel, Field

from .. import enums
from . import ToolOutput


class ConvertToPdfBase64Input(BaseModel):
    base64_string: str = Field(
        default="",
        json_schema_extra={
            "mandatory": True,
            "field_type": enums.CustomDataType.TEXT.value,
        },
    )


class ConvertToPdfBase64Output(ToolOutput):
    pdf_base64_string: str = Field(
        default="", description="The Base64 encoded string of the resulting PDF file."
    )
