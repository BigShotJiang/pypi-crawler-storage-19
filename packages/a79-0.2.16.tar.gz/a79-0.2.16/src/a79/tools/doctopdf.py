# This is a generated file by scripts/codegen/tools.py, do not edit manually
# ruff: noqa


from ..client import A79Client
from ..models.tools import DEFAULT
from ..models.tools.doctopdf_models import (
    ConvertToPdfBase64Input,
    ConvertToPdfBase64Output,
)

__all__ = ["ConvertToPdfBase64Input", "ConvertToPdfBase64Output", "convert_to_pdf_base64"]


def convert_to_pdf_base64(*, base64_string: str = DEFAULT) -> ConvertToPdfBase64Output:
    """
    Converts any Base64 encoded document (e.g., TIFF)
    to a PDF and returns it as a Base64 string.
    """
    kwargs = locals()
    kwargs = {k: v for k, v in kwargs.items() if v is not DEFAULT}
    input_model = ConvertToPdfBase64Input.model_validate(kwargs)

    client = A79Client()
    output_model = client.execute_tool(
        package="doctopdf", name="convert_to_pdf_base64", input=input_model.model_dump()
    )
    return ConvertToPdfBase64Output.model_validate(output_model)
