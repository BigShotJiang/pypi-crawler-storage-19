"""Tests for sales_agent_utils module.

Tests for Sales Agent SDK-specific functions have been moved to:
    common_py/sales_agents/workflow_helpers_test.py
"""

from .sales_agent_utils import find_best_transcript_message


def test_find_best_transcript_message():
    """Test finding best matching message in transcript."""
    transcript_messages = [
        {"speaker": "Agent", "message": "Hello, how can I help you today?"},
        {"speaker": "Customer", "message": "I need help with my order"},
        {"speaker": "Agent", "message": "I'd be happy to assist you"},
    ]

    result = find_best_transcript_message(
        "I need help with my order", transcript_messages
    )

    assert result is not None
    assert result["message"] == "I need help with my order"
    assert result["speaker"] == "Customer"


def test_find_best_transcript_message_no_match():
    """Test when no good match is found."""
    transcript_messages = [
        {"speaker": "Agent", "message": "Hello, how can I help you today?"},
        {"speaker": "Customer", "message": "I need help with my order"},
    ]

    result = find_best_transcript_message(
        "Completely different text that won't match", transcript_messages
    )

    # Should return None if similarity is below threshold
    assert result is None


def test_find_best_transcript_message_partial_match():
    """Test partial matching with substring."""
    transcript_messages = [
        {"speaker": "Agent", "message": "I can help you with that order"},
        {"speaker": "Customer", "message": "Great, thanks!"},
    ]

    result = find_best_transcript_message("help you with that", transcript_messages)

    assert result is not None
    assert "help you with that" in result["message"].lower()
