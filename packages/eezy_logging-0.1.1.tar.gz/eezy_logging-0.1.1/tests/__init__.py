"""Tests for eezy-logging."""
