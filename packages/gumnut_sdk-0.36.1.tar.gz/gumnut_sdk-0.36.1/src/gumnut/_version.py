# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "gumnut"
__version__ = "0.36.1"  # x-release-please-version
