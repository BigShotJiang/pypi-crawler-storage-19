# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteImmutableRuleRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'namespace_name': 'str',
        'immutable_rule_id': 'int'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'namespace_name': 'namespace_name',
        'immutable_rule_id': 'immutable_rule_id'
    }

    def __init__(self, instance_id=None, namespace_name=None, immutable_rule_id=None):
        r"""DeleteImmutableRuleRequest

        The model defined in huaweicloud sdk

        :param instance_id: 企业仓库实例ID
        :type instance_id: str
        :param namespace_name: 命名空间名称
        :type namespace_name: str
        :param immutable_rule_id: 不可变Tag策略ID
        :type immutable_rule_id: int
        """
        
        

        self._instance_id = None
        self._namespace_name = None
        self._immutable_rule_id = None
        self.discriminator = None

        self.instance_id = instance_id
        self.namespace_name = namespace_name
        self.immutable_rule_id = immutable_rule_id

    @property
    def instance_id(self):
        r"""Gets the instance_id of this DeleteImmutableRuleRequest.

        企业仓库实例ID

        :return: The instance_id of this DeleteImmutableRuleRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this DeleteImmutableRuleRequest.

        企业仓库实例ID

        :param instance_id: The instance_id of this DeleteImmutableRuleRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def namespace_name(self):
        r"""Gets the namespace_name of this DeleteImmutableRuleRequest.

        命名空间名称

        :return: The namespace_name of this DeleteImmutableRuleRequest.
        :rtype: str
        """
        return self._namespace_name

    @namespace_name.setter
    def namespace_name(self, namespace_name):
        r"""Sets the namespace_name of this DeleteImmutableRuleRequest.

        命名空间名称

        :param namespace_name: The namespace_name of this DeleteImmutableRuleRequest.
        :type namespace_name: str
        """
        self._namespace_name = namespace_name

    @property
    def immutable_rule_id(self):
        r"""Gets the immutable_rule_id of this DeleteImmutableRuleRequest.

        不可变Tag策略ID

        :return: The immutable_rule_id of this DeleteImmutableRuleRequest.
        :rtype: int
        """
        return self._immutable_rule_id

    @immutable_rule_id.setter
    def immutable_rule_id(self, immutable_rule_id):
        r"""Sets the immutable_rule_id of this DeleteImmutableRuleRequest.

        不可变Tag策略ID

        :param immutable_rule_id: The immutable_rule_id of this DeleteImmutableRuleRequest.
        :type immutable_rule_id: int
        """
        self._immutable_rule_id = immutable_rule_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteImmutableRuleRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
