# CMake generated Testfile for 
# Source directory: /home/runner/work/tvm-ffi/tvm-ffi/build_test/_deps/googletest-src/googletest
# Build directory: /home/runner/work/tvm-ffi/tvm-ffi/build_test/_deps/googletest-build/googletest
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
