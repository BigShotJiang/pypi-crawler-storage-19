"""Database migrations for commandbus."""
