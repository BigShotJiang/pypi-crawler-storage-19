"""
A2UI Templates

Pre-built UI templates for common use cases.
"""

from overai.ui.a2ui.templates.chat import ChatTemplate
from overai.ui.a2ui.templates.list import ListTemplate
from overai.ui.a2ui.templates.form import FormTemplate
from overai.ui.a2ui.templates.dashboard import DashboardTemplate

__all__ = [
    "ChatTemplate",
    "ListTemplate",
    "FormTemplate",
    "DashboardTemplate",
]
