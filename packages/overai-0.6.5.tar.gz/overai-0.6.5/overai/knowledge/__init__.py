"""
PraisonAI Knowledge - Advanced knowledge management system with configurable features.

This module provides:
- Document readers (ReaderProtocol, ReaderRegistry)
- Vector stores (VectorStoreProtocol, VectorStoreRegistry)
- Retrieval strategies (RetrieverProtocol, RetrievalStrategy)
- Rerankers (RerankerProtocol, RerankerRegistry)
- Index types (IndexProtocol, IndexType)
- Query engines (QueryEngineProtocol, QueryMode)
"""

# Core Knowledge class (always available)
from overai.knowledge.knowledge import Knowledge
from overai.knowledge.chunking import Chunking

# Lazy loading for protocols and registries to avoid import overhead
_LAZY_IMPORTS = {
    # Readers
    "Document": ("overai.knowledge.readers", "Document"),
    "ReaderProtocol": ("overai.knowledge.readers", "ReaderProtocol"),
    "ReaderRegistry": ("overai.knowledge.readers", "ReaderRegistry"),
    "get_reader_registry": ("overai.knowledge.readers", "get_reader_registry"),
    "detect_source_kind": ("overai.knowledge.readers", "detect_source_kind"),
    
    # Vector stores
    "VectorRecord": ("overai.knowledge.vector_store", "VectorRecord"),
    "VectorStoreProtocol": ("overai.knowledge.vector_store", "VectorStoreProtocol"),
    "VectorStoreRegistry": ("overai.knowledge.vector_store", "VectorStoreRegistry"),
    "get_vector_store_registry": ("overai.knowledge.vector_store", "get_vector_store_registry"),
    "InMemoryVectorStore": ("overai.knowledge.vector_store", "InMemoryVectorStore"),
    
    # Retrieval
    "RetrievalResult": ("overai.knowledge.retrieval", "RetrievalResult"),
    "RetrievalStrategy": ("overai.knowledge.retrieval", "RetrievalStrategy"),
    "RetrieverProtocol": ("overai.knowledge.retrieval", "RetrieverProtocol"),
    "RetrieverRegistry": ("overai.knowledge.retrieval", "RetrieverRegistry"),
    "get_retriever_registry": ("overai.knowledge.retrieval", "get_retriever_registry"),
    "reciprocal_rank_fusion": ("overai.knowledge.retrieval", "reciprocal_rank_fusion"),
    "merge_adjacent_chunks": ("overai.knowledge.retrieval", "merge_adjacent_chunks"),
    
    # Rerankers
    "RerankResult": ("overai.knowledge.rerankers", "RerankResult"),
    "RerankerProtocol": ("overai.knowledge.rerankers", "RerankerProtocol"),
    "RerankerRegistry": ("overai.knowledge.rerankers", "RerankerRegistry"),
    "get_reranker_registry": ("overai.knowledge.rerankers", "get_reranker_registry"),
    "SimpleReranker": ("overai.knowledge.rerankers", "SimpleReranker"),
    
    # Index
    "IndexType": ("overai.knowledge.index", "IndexType"),
    "IndexStats": ("overai.knowledge.index", "IndexStats"),
    "IndexProtocol": ("overai.knowledge.index", "IndexProtocol"),
    "IndexRegistry": ("overai.knowledge.index", "IndexRegistry"),
    "get_index_registry": ("overai.knowledge.index", "get_index_registry"),
    "KeywordIndex": ("overai.knowledge.index", "KeywordIndex"),
    
    # Query engine
    "QueryMode": ("overai.knowledge.query_engine", "QueryMode"),
    "QueryResult": ("overai.knowledge.query_engine", "QueryResult"),
    "QueryEngineProtocol": ("overai.knowledge.query_engine", "QueryEngineProtocol"),
    "QueryEngineRegistry": ("overai.knowledge.query_engine", "QueryEngineRegistry"),
    "get_query_engine_registry": ("overai.knowledge.query_engine", "get_query_engine_registry"),
    "decompose_question": ("overai.knowledge.query_engine", "decompose_question"),
    "SimpleQueryEngine": ("overai.knowledge.query_engine", "SimpleQueryEngine"),
    "SubQuestionEngine": ("overai.knowledge.query_engine", "SubQuestionEngine"),
}


def __getattr__(name: str):
    """Lazy load protocols and registries."""
    if name in _LAZY_IMPORTS:
        module_path, attr_name = _LAZY_IMPORTS[name]
        import importlib
        module = importlib.import_module(module_path)
        return getattr(module, attr_name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    """List available attributes."""
    return list(_LAZY_IMPORTS.keys()) + ["Knowledge", "Chunking"]


__all__ = [
    # Core
    "Knowledge",
    "Chunking",
    # Readers
    "Document",
    "ReaderProtocol",
    "ReaderRegistry",
    "get_reader_registry",
    "detect_source_kind",
    # Vector stores
    "VectorRecord",
    "VectorStoreProtocol",
    "VectorStoreRegistry",
    "get_vector_store_registry",
    "InMemoryVectorStore",
    # Retrieval
    "RetrievalResult",
    "RetrievalStrategy",
    "RetrieverProtocol",
    "RetrieverRegistry",
    "get_retriever_registry",
    "reciprocal_rank_fusion",
    "merge_adjacent_chunks",
    # Rerankers
    "RerankResult",
    "RerankerProtocol",
    "RerankerRegistry",
    "get_reranker_registry",
    "SimpleReranker",
    # Index
    "IndexType",
    "IndexStats",
    "IndexProtocol",
    "IndexRegistry",
    "get_index_registry",
    "KeywordIndex",
    # Query engine
    "QueryMode",
    "QueryResult",
    "QueryEngineProtocol",
    "QueryEngineRegistry",
    "get_query_engine_registry",
    "decompose_question",
    "SimpleQueryEngine",
    "SubQuestionEngine",
] 