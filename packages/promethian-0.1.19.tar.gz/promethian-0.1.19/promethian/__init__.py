"""Promethian: Self-improving AI agent with centralized knowledge."""

from importlib.metadata import version, PackageNotFoundError

from promethian.config import PromethianConfig
from promethian.core.types import Skill, Tool, Plan, ExecutionResult
from promethian.core.conversation_agent import ConversationAgent

try:
    __version__ = version("promethian")
except PackageNotFoundError:
    __version__ = "0.1.19"  # Fallback for development
__all__ = [
    "PromethianConfig",
    "Skill",
    "Tool",
    "Plan",
    "ExecutionResult",
    "ConversationAgent",
]
