"""Web search tool for Promethian.

Supports multiple search backends:
- Tavily (recommended): AI-optimized search with content extraction. Requires TAVILY_API_KEY.
- DuckDuckGo (fallback): No API key required, but only returns snippets.

When TAVILY_API_KEY is set, Tavily is used automatically. Otherwise falls back to DDG.
"""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass
class SearchResult:
    """A single search result."""
    title: str
    url: str
    snippet: str
    content: str | None = None  # Full extracted content (Tavily only)
    score: float | None = None  # Relevance score (Tavily only)


@dataclass
class WebSearchResult:
    """Result from a web search."""
    success: bool
    results: list[SearchResult] | None = None
    error: str | None = None
    query: str = ""
    source: str = ""  # "tavily" or "ddg"


class SearchBackend(Protocol):
    """Protocol for search backends."""

    async def search(
        self,
        query: str,
        max_results: int | None = None,
    ) -> WebSearchResult:
        ...

    async def news_search(
        self,
        query: str,
        max_results: int | None = None,
    ) -> WebSearchResult:
        ...

    def get_tool_schemas(self) -> list[dict]:
        ...


class TavilySearchTool:
    """
    Web search using Tavily API - optimized for AI agents.

    Tavily provides:
    - Full content extraction from pages (not just snippets)
    - Relevance scoring
    - AI-optimized results

    Requires TAVILY_API_KEY environment variable.
    """

    def __init__(self, api_key: str | None = None, max_results: int = 5):
        self.api_key = api_key or os.environ.get("TAVILY_API_KEY")
        if not self.api_key:
            raise ValueError("TAVILY_API_KEY is required for Tavily search")
        self.max_results = max_results
        self._client = None

    def _ensure_client(self):
        """Ensure Tavily client is available."""
        if self._client is None:
            try:
                from tavily import TavilyClient
                self._client = TavilyClient(api_key=self.api_key)
            except ImportError:
                raise RuntimeError(
                    "tavily-python not installed. Run: pip install tavily-python"
                )
        return self._client

    async def search(
        self,
        query: str,
        max_results: int | None = None,
        include_content: bool = True,
    ) -> WebSearchResult:
        """
        Search the web using Tavily.

        Args:
            query: The search query
            max_results: Maximum number of results (default: 5)
            include_content: Whether to include full page content (default: True)

        Returns:
            WebSearchResult with list of results including content
        """
        try:
            client = self._ensure_client()
            num_results = max_results or self.max_results

            # Run in thread pool since tavily client is synchronous
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: client.search(
                    query=query,
                    max_results=num_results,
                    include_raw_content=include_content,
                    search_depth="advanced",  # Better quality results
                )
            )

            results = []
            for r in response.get("results", []):
                results.append(SearchResult(
                    title=r.get("title", ""),
                    url=r.get("url", ""),
                    snippet=r.get("content", "")[:500] if r.get("content") else "",
                    content=r.get("raw_content") or r.get("content"),
                    score=r.get("score"),
                ))

            return WebSearchResult(
                success=True,
                results=results,
                query=query,
                source="tavily",
            )

        except Exception as e:
            return WebSearchResult(
                success=False,
                error=str(e),
                query=query,
                source="tavily",
            )

    async def news_search(
        self,
        query: str,
        max_results: int | None = None,
    ) -> WebSearchResult:
        """
        Search for recent news using Tavily.

        Args:
            query: The search query
            max_results: Maximum number of results (default: 5)

        Returns:
            WebSearchResult with list of news results
        """
        try:
            client = self._ensure_client()
            num_results = max_results or self.max_results

            # Run in thread pool since tavily client is synchronous
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: client.search(
                    query=query,
                    max_results=num_results,
                    topic="news",  # Filter for news
                    include_raw_content=True,
                )
            )

            results = []
            for r in response.get("results", []):
                results.append(SearchResult(
                    title=r.get("title", ""),
                    url=r.get("url", ""),
                    snippet=r.get("content", "")[:500] if r.get("content") else "",
                    content=r.get("raw_content") or r.get("content"),
                    score=r.get("score"),
                ))

            return WebSearchResult(
                success=True,
                results=results,
                query=query,
                source="tavily",
            )

        except Exception as e:
            return WebSearchResult(
                success=False,
                error=str(e),
                query=query,
                source="tavily",
            )

    def get_tool_schemas(self) -> list[dict]:
        """Get Claude tool schemas for Tavily search actions."""
        return [
            {
                "name": "web_search",
                "description": (
                    "Search the web using Tavily AI search. Returns titles, URLs, snippets, "
                    "AND full extracted page content. Use this to find and read information, "
                    "documentation, articles, or any web content. The content field contains "
                    "the full text extracted from each page."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The search query"
                        },
                        "max_results": {
                            "type": "integer",
                            "description": "Maximum number of results (default 5, max 10)",
                            "default": 5
                        }
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "web_news_search",
                "description": (
                    "Search for recent news articles using Tavily AI search. Returns titles, "
                    "URLs, snippets, and full article content. Use this for current events "
                    "or recent developments."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The news search query"
                        },
                        "max_results": {
                            "type": "integer",
                            "description": "Maximum number of results (default 5, max 10)",
                            "default": 5
                        }
                    },
                    "required": ["query"]
                }
            },
        ]

    async def execute_tool(self, name: str, params: dict) -> WebSearchResult:
        """Execute a web search tool by name."""
        max_results = min(params.get("max_results", 5), 10)  # Cap at 10

        if name == "web_search":
            return await self.search(
                query=params["query"],
                max_results=max_results,
            )
        elif name == "web_news_search":
            return await self.news_search(
                query=params["query"],
                max_results=max_results,
            )
        else:
            return WebSearchResult(
                success=False,
                error=f"Unknown web search tool: {name}",
                query=params.get("query", ""),
                source="tavily",
            )


class DDGSearchTool:
    """
    Web search tool using DuckDuckGo (fallback).

    Provides:
    - search(query) - Search the web and get results
    - news_search(query) - Search for recent news

    No API key required, but only returns snippets (not full content).
    """

    def __init__(self, max_results: int = 5):
        self.max_results = max_results
        self._ddgs = None

    def _ensure_ddgs(self):
        """Ensure DuckDuckGo search is available."""
        if self._ddgs is None:
            try:
                # Try new package name first
                from ddgs import DDGS
                self._ddgs = DDGS()
            except ImportError:
                try:
                    # Fall back to old package name
                    from duckduckgo_search import DDGS
                    self._ddgs = DDGS()
                except ImportError:
                    raise RuntimeError(
                        "ddgs not installed. Run: pip install ddgs"
                    )
        return self._ddgs

    async def search(
        self,
        query: str,
        max_results: int | None = None,
        region: str = "wt-wt",
    ) -> WebSearchResult:
        """
        Search the web using DuckDuckGo.

        Args:
            query: The search query
            max_results: Maximum number of results (default: 5)
            region: Region for results (default: worldwide)

        Returns:
            WebSearchResult with list of results (snippets only, no full content)
        """
        try:
            ddgs = self._ensure_ddgs()
            num_results = max_results or self.max_results

            # Run in thread pool since ddgs is synchronous
            loop = asyncio.get_event_loop()
            raw_results = await loop.run_in_executor(
                None,
                lambda: list(ddgs.text(query, max_results=num_results, region=region))
            )

            results = [
                SearchResult(
                    title=r.get("title", ""),
                    url=r.get("href", r.get("link", "")),
                    snippet=r.get("body", r.get("snippet", "")),
                    content=None,  # DDG doesn't provide full content
                    score=None,
                )
                for r in raw_results
            ]

            return WebSearchResult(
                success=True,
                results=results,
                query=query,
                source="ddg",
            )

        except Exception as e:
            return WebSearchResult(
                success=False,
                error=str(e),
                query=query,
                source="ddg",
            )

    async def news_search(
        self,
        query: str,
        max_results: int | None = None,
        region: str = "wt-wt",
    ) -> WebSearchResult:
        """
        Search for recent news using DuckDuckGo.

        Args:
            query: The search query
            max_results: Maximum number of results (default: 5)
            region: Region for results (default: worldwide)

        Returns:
            WebSearchResult with list of news results
        """
        try:
            ddgs = self._ensure_ddgs()
            num_results = max_results or self.max_results

            # Run in thread pool since ddgs is synchronous
            loop = asyncio.get_event_loop()
            raw_results = await loop.run_in_executor(
                None,
                lambda: list(ddgs.news(query, max_results=num_results, region=region))
            )

            results = [
                SearchResult(
                    title=r.get("title", ""),
                    url=r.get("url", r.get("link", "")),
                    snippet=r.get("body", r.get("excerpt", "")),
                    content=None,
                    score=None,
                )
                for r in raw_results
            ]

            return WebSearchResult(
                success=True,
                results=results,
                query=query,
                source="ddg",
            )

        except Exception as e:
            return WebSearchResult(
                success=False,
                error=str(e),
                query=query,
                source="ddg",
            )

    def get_tool_schemas(self) -> list[dict]:
        """Get Claude tool schemas for web search actions."""
        return [
            {
                "name": "web_search",
                "description": (
                    "Search the web using DuckDuckGo. Returns titles, URLs, and snippets "
                    "for the top results. Use this to find information, documentation, "
                    "tutorials, or any web content. Note: Only returns snippets, not full "
                    "page content."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The search query"
                        },
                        "max_results": {
                            "type": "integer",
                            "description": "Maximum number of results (default 5, max 10)",
                            "default": 5
                        }
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "web_news_search",
                "description": (
                    "Search for recent news articles using DuckDuckGo. Returns titles, "
                    "URLs, and snippets for recent news. Use this for current events "
                    "or recent developments."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The news search query"
                        },
                        "max_results": {
                            "type": "integer",
                            "description": "Maximum number of results (default 5, max 10)",
                            "default": 5
                        }
                    },
                    "required": ["query"]
                }
            },
        ]

    async def execute_tool(self, name: str, params: dict) -> WebSearchResult:
        """Execute a web search tool by name."""
        max_results = min(params.get("max_results", 5), 10)  # Cap at 10

        if name == "web_search":
            return await self.search(
                query=params["query"],
                max_results=max_results,
            )
        elif name == "web_news_search":
            return await self.news_search(
                query=params["query"],
                max_results=max_results,
            )
        else:
            return WebSearchResult(
                success=False,
                error=f"Unknown web search tool: {name}",
                query=params.get("query", ""),
                source="ddg",
            )


# Type alias for the unified search tool
WebSearchTool = TavilySearchTool | DDGSearchTool

# Singleton web search tool instance
_web_search: WebSearchTool | None = None


def get_web_search(
    max_results: int = 5,
    tavily_api_key: str | None = None,
) -> WebSearchTool:
    """
    Get the global web search tool instance.

    Uses Tavily if TAVILY_API_KEY is set, otherwise falls back to DuckDuckGo.

    Args:
        max_results: Default number of results to return
        tavily_api_key: Optional Tavily API key (uses env var if not provided)

    Returns:
        TavilySearchTool if API key available, else DDGSearchTool
    """
    global _web_search
    if _web_search is None:
        api_key = tavily_api_key or os.environ.get("TAVILY_API_KEY")
        if api_key:
            try:
                _web_search = TavilySearchTool(api_key=api_key, max_results=max_results)
            except Exception:
                # Fall back to DDG if Tavily init fails
                _web_search = DDGSearchTool(max_results=max_results)
        else:
            _web_search = DDGSearchTool(max_results=max_results)
    return _web_search


def reset_web_search() -> None:
    """Reset the global web search tool instance."""
    global _web_search
    _web_search = None
