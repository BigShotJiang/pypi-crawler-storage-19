# Querit Content Retrieval Platform — Python SDK

The Querit Content Retrieval Platform provides powerful content search capabilities.
The Querit Python SDK allows developers to easily integrate Querit search functionality into Python applications.

## Installation

The Querit Python SDK is available on PyPI and supports Python 3.7.0 or later.

pip install querit-python

## Quick Start

Before using the Querit SDK, you need to obtain an API Key from the Querit platform.

## Search with the SDK

You can initialize the SDK using the QueritClient class by passing in your api_key:

from querit import QueritClient
from querit.models.request import SearchRequest

client = QueritClient(api_key="xxx")

req = SearchRequest(
    query="chat",
    count=5
)

response = client.search(req)
print(response)

