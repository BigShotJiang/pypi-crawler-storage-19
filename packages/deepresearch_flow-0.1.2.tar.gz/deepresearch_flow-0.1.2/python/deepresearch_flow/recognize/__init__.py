"""Recognize command helpers."""
