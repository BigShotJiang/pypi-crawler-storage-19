from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from ...core.types import ServiceEvent, ServiceInfo
from ...core.utils import batch_items, determine_service_status, extract_name_from_arn, paginate_aws_list

if TYPE_CHECKING:
    from typing import Any

    from mypy_boto3_ecs.client import ECSClient
    from mypy_boto3_ecs.type_defs import ServiceTypeDef

EVENT_CATEGORY_KEYWORDS: dict[str, list[str]] = {
    "failure": ["failed", "error", "unhealthy", "unable"],
    "deployment": ["deployment", "deploy", "started", "stopped", "updated", "registered", "deregistered", "targets"],
    "scaling": ["scaling", "scale", "capacity", "desired count", "steady state", "running tasks"],
}


class ServiceService:
    def __init__(self, ecs_client: ECSClient) -> None:
        self.ecs_client = ecs_client

    def get_services(self, cluster_name: str) -> list[str]:
        service_arns = paginate_aws_list(self.ecs_client, "list_services", "serviceArns", cluster=cluster_name)
        return [extract_name_from_arn(arn) for arn in service_arns]

    def get_service_info(self, cluster_name: str) -> list[ServiceInfo]:
        service_names = self.get_services(cluster_name)
        if not service_names:
            return []

        all_services = [
            service
            for batch in batch_items(service_names, 10)
            for service in self.ecs_client.describe_services(cluster=cluster_name, services=batch).get("services", [])
        ]

        return [_create_service_info(service) for service in all_services]

    def get_desired_task_definition_arn(self, cluster_name: str, service_name: str) -> str | None:
        response = self.ecs_client.describe_services(cluster=cluster_name, services=[service_name])
        services = response.get("services", [])
        if services:
            return services[0].get("taskDefinition")
        return None

    def get_service_events(self, cluster_name: str, service_name: str) -> list[ServiceEvent]:
        response = self.ecs_client.describe_services(cluster=cluster_name, services=[service_name])
        services = response.get("services", [])
        if not services:
            return []

        events = services[0].get("events", [])
        service_events = [_parse_service_event(dict(event)) for event in events]

        return sorted(service_events, key=lambda x: x["created_at"] or datetime.min, reverse=True)


def _create_service_info(service: ServiceTypeDef) -> ServiceInfo:
    service_name = service["serviceName"]
    running_count = service.get("runningCount", 0)
    desired_count = service.get("desiredCount", 0)
    pending_count = service.get("pendingCount", 0)

    icon, status = determine_service_status(running_count, desired_count, pending_count)

    display_name = f"{icon} {service_name} ({running_count}/{desired_count})"

    return {
        "name": display_name,
        "status": status,
        "running_count": running_count,
        "desired_count": desired_count,
        "pending_count": pending_count,
    }


def _parse_service_event(event: dict[str, Any]) -> ServiceEvent:
    event_id = event.get("id", "")
    created_at = event.get("createdAt")
    message = event.get("message", "")

    event_type = _categorize_event(message)

    return {
        "id": event_id,
        "created_at": created_at,
        "message": message,
        "event_type": event_type,
    }


def _categorize_event(message: str) -> str:
    message_lower = message.lower()
    for category, keywords in EVENT_CATEGORY_KEYWORDS.items():
        if any(term in message_lower for term in keywords):
            return category
    return "other"
