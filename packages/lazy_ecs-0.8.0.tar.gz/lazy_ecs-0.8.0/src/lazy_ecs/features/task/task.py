from __future__ import annotations

from typing import TYPE_CHECKING, Any

from botocore.exceptions import BotoCoreError, ClientError

from ...core.types import TaskDetails, TaskHistoryDetails, TaskInfo
from ...core.utils import (
    batch_items,
    extract_task_def_family,
    extract_task_def_revision,
    extract_task_id,
    paginate_aws_list,
)

if TYPE_CHECKING:
    from mypy_boto3_ecs.client import ECSClient
    from mypy_boto3_ecs.type_defs import TaskDefinitionTypeDef, TaskTypeDef

# Exit code mapping: exit_code -> (brief_reason, emoji, description)
EXIT_CODE_INFO: dict[int, tuple[str, str, str]] = {
    137: ("SIGKILL", "💀", "killed by SIGKILL (OOM, manual kill, or timeout)"),
    139: ("segfault", "💥", "crashed with segmentation fault (exit code 139)"),
    143: ("SIGTERM", "🛑", "gracefully stopped (SIGTERM)"),
    1: ("app error", "❌", "application error (exit code 1)"),
}


class TaskService:
    def __init__(self, ecs_client: ECSClient) -> None:
        self.ecs_client = ecs_client

    def get_tasks(self, cluster_name: str, service_name: str) -> list[str]:
        return paginate_aws_list(
            self.ecs_client,
            "list_tasks",
            "taskArns",
            cluster=cluster_name,
            serviceName=service_name,
        )

    def stop_task(
        self, cluster_name: str, task_arn: str, reason: str = "Stopped via lazy-ecs"
    ) -> tuple[bool, str | None]:
        try:
            self.ecs_client.stop_task(cluster=cluster_name, task=task_arn, reason=reason)
            return True, None
        except ClientError as e:
            return False, e.response.get("Error", {}).get("Message", str(e))
        except BotoCoreError as e:
            return False, str(e)

    def get_task_info(self, cluster_name: str, service_name: str, desired_task_def_arn: str | None) -> list[TaskInfo]:
        task_arns = self.get_tasks(cluster_name, service_name)
        if not task_arns:
            return []

        all_tasks = [
            task
            for batch in batch_items(task_arns, 100)
            for task in self.ecs_client.describe_tasks(cluster=cluster_name, tasks=batch).get("tasks", [])
        ]

        return [_create_task_info(task, desired_task_def_arn) for task in all_tasks]

    def get_task_details(
        self,
        cluster_name: str,
        task_arn: str,
        desired_task_def_arn: str | None,
    ) -> TaskDetails | None:
        result = self.get_task_and_definition(cluster_name, task_arn)
        if not result:
            return None

        task, task_definition = result
        is_desired_version = task["taskDefinitionArn"] == desired_task_def_arn
        return _build_task_details(task, task_definition, is_desired_version)

    def get_task_and_definition(
        self,
        cluster_name: str,
        task_arn: str,
    ) -> tuple[TaskTypeDef, TaskDefinitionTypeDef] | None:
        task_response = self.ecs_client.describe_tasks(cluster=cluster_name, tasks=[task_arn])
        tasks = task_response.get("tasks", [])
        if not tasks:
            return None

        task = tasks[0]
        task_def_arn = task["taskDefinitionArn"]
        task_def_response = self.ecs_client.describe_task_definition(taskDefinition=task_def_arn)
        task_definition = task_def_response.get("taskDefinition")
        if not task_definition:
            return None

        return task, task_definition

    def _list_tasks_by_status(self, cluster_name: str, service_name: str | None, desired_status: str) -> list[str]:
        kwargs = {"cluster": cluster_name, "desiredStatus": desired_status}
        if service_name:
            kwargs["serviceName"] = service_name
        return paginate_aws_list(self.ecs_client, "list_tasks", "taskArns", **kwargs)

    def get_task_history(self, cluster_name: str, service_name: str | None = None) -> list[TaskHistoryDetails]:
        task_arns = []

        running_arns = self._list_tasks_by_status(cluster_name, service_name, "RUNNING")
        task_arns.extend(running_arns)

        stopped_arns = self._list_tasks_by_status(cluster_name, service_name, "STOPPED")
        task_arns.extend(stopped_arns)

        if not task_arns:
            return []

        all_tasks = [
            task
            for batch in batch_items(task_arns, 100)
            for task in self.ecs_client.describe_tasks(cluster=cluster_name, tasks=batch).get("tasks", [])
        ]

        return [self._parse_task_history(task) for task in all_tasks]

    def get_task_failure_analysis(self, task_history: TaskHistoryDetails) -> str:
        if task_history["last_status"] == "RUNNING":
            return "✅ Task is currently running"

        stop_code = task_history["stop_code"]
        stopped_reason = task_history["stopped_reason"]

        # Check container exit codes
        for container in task_history["containers"]:
            exit_code = container["exit_code"]
            container_reason = container["reason"]

            if exit_code is not None and exit_code != 0:
                return self._analyze_container_failure(
                    container["name"],
                    exit_code,
                    container_reason,
                    stop_code,
                    stopped_reason,
                )

        return self._analyze_task_failure(stop_code, stopped_reason)

    @staticmethod
    def _parse_task_history(task: TaskTypeDef) -> TaskHistoryDetails:
        task_arn = task["taskArn"]
        task_def_arn = task["taskDefinitionArn"]
        task_def_family = extract_task_def_family(task_def_arn)
        task_def_revision = extract_task_def_revision(task_def_arn)

        containers = []
        for container in task.get("containers", []):
            containers.append(
                {
                    "name": container["name"],
                    "exit_code": container.get("exitCode"),
                    "reason": container.get("reason"),
                    "health_status": container.get("healthStatus"),
                    "last_status": container.get("lastStatus", "UNKNOWN"),
                },
            )

        return {
            "task_arn": task_arn,
            "task_definition_name": task_def_family,
            "task_definition_revision": task_def_revision,
            "last_status": task.get("lastStatus", "UNKNOWN"),
            "desired_status": task.get("desiredStatus", "UNKNOWN"),
            "stop_code": task.get("stopCode"),
            "stopped_reason": task.get("stoppedReason"),
            "created_at": task.get("createdAt"),
            "started_at": task.get("startedAt"),
            "stopped_at": task.get("stoppedAt"),
            "containers": containers,
        }

    @staticmethod
    def _analyze_container_failure(
        container_name: str,
        exit_code: int,
        container_reason: str | None,
        _stop_code: str | None,
        _stopped_reason: str | None,
    ) -> str:
        # Special case for OOM with explicit reason
        if exit_code == 137 and container_reason and "OutOfMemoryError" in container_reason:
            return f"🔴 Container '{container_name}' killed due to out of memory (OOM)"

        if exit_code in EXIT_CODE_INFO:
            _, emoji, description = EXIT_CODE_INFO[exit_code]
            return f"{emoji} Container '{container_name}' {description}"

        reason_text = f" - {container_reason}" if container_reason else ""
        return f"🔴 Container '{container_name}' failed with exit code {exit_code}{reason_text}"

    @staticmethod
    def _analyze_task_failure(stop_code: str | None, stopped_reason: str | None) -> str:
        if not stop_code and not stopped_reason:
            return "✅ Task completed successfully"

        if stop_code == "TaskFailedToStart":
            if stopped_reason and "CannotPullContainerError" in stopped_reason:
                return "📦 Failed to pull container image - check image exists and permissions"
            if stopped_reason and "ResourcesNotAvailable" in stopped_reason:
                return "⚠️ Insufficient resources available to start task"
            reason_text = f" - {stopped_reason}" if stopped_reason else ""
            return f"🚫 Task failed to start{reason_text}"
        if stop_code == "ServiceSchedulerInitiated":
            return "🔄 Task stopped by service scheduler (deployment/scaling)"
        if stop_code == "SpotInterruption":
            return "💸 Task stopped due to spot instance interruption"
        if stop_code == "UserInitiated":
            return "👤 Task manually stopped by user"
        reason_text = f" - {stopped_reason}" if stopped_reason else ""
        code_text = f"({stop_code}) " if stop_code else ""
        return f"🔴 Task stopped {code_text}{reason_text}"


def _get_brief_exit_reason(exit_code: int) -> str:
    if exit_code in EXIT_CODE_INFO:
        brief_reason, _, _ = EXIT_CODE_INFO[exit_code]
        return brief_reason
    return f"exit {exit_code}"


def _get_brief_stop_reason(stop_code: str | None) -> str | None:
    if not stop_code:
        return None
    reasons = {
        "TaskFailedToStart": "failed to start",
        "ServiceSchedulerInitiated": "scheduler stopped",
        "SpotInterruption": "spot interrupted",
        "UserInitiated": "user stopped",
    }
    return reasons.get(stop_code, stop_code.lower())


def _get_brief_failure_reason(task: TaskTypeDef | dict[str, Any]) -> str | None:
    last_status = task.get("lastStatus", "")
    if last_status == "RUNNING":
        return None

    for container in task.get("containers", []):
        exit_code = container.get("exitCode")
        if exit_code is not None and exit_code != 0:
            return _get_brief_exit_reason(exit_code)

    stop_code = task.get("stopCode")
    return _get_brief_stop_reason(stop_code)


def _create_task_info(task: TaskTypeDef | dict[str, Any], desired_task_def_arn: str | None) -> TaskInfo:
    task_arn = task["taskArn"]
    task_def_arn = task["taskDefinitionArn"]
    is_desired = task_def_arn == desired_task_def_arn

    task_id = extract_task_id(task_arn)
    task_def_family = extract_task_def_family(task_def_arn)
    revision = extract_task_def_revision(task_def_arn)

    created_at = task.get("createdAt")

    container_images = []
    for container in task.get("containers", []):
        if "image" in container:
            image = container["image"]
            if ":" in image:
                container_images.append(image.split(":")[-1])

    image_display = ", ".join(container_images) if container_images else "unknown"
    failure_reason = _get_brief_failure_reason(task)

    status_icon = "✅" if is_desired else "🔴"
    time_str = created_at.strftime("%H:%M:%S") if created_at else "unknown"

    display_name = f"{status_icon} v{revision} {task_def_family} ({task_id}) - {image_display} - {time_str}"
    if failure_reason:
        display_name = f"{display_name} - {failure_reason}"

    return {
        "name": display_name,
        "value": task_arn,
        "task_def_arn": task_def_arn,
        "is_desired": is_desired,
        "revision": revision,
        "images": container_images,
        "created_at": created_at,
        "failure_reason": failure_reason,
    }


def _build_task_details(
    task: TaskTypeDef,
    task_definition: TaskDefinitionTypeDef,
    is_desired_version: bool,
) -> TaskDetails:
    task_arn = task["taskArn"]
    task_def_arn = task["taskDefinitionArn"]
    task_def_family = extract_task_def_family(task_def_arn)
    task_def_revision = extract_task_def_revision(task_def_arn)

    containers = []
    for container_def in task_definition["containerDefinitions"]:
        container_info = {
            "name": container_def["name"],
            "image": container_def["image"],
            "cpu": container_def.get("cpu"),
            "memory": container_def.get("memory"),
            "memoryReservation": container_def.get("memoryReservation"),
        }
        containers.append(container_info)

    return {
        "task_arn": task_arn,
        "task_definition_name": task_def_family,
        "task_definition_revision": task_def_revision,
        "is_desired_version": is_desired_version,
        "task_status": task.get("lastStatus", "UNKNOWN"),
        "containers": containers,
        "created_at": task.get("createdAt"),
        "started_at": task.get("startedAt"),
    }
