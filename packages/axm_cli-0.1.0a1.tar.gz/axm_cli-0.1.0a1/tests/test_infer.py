"""Tests for schema inference from data files."""

from pathlib import Path

from axm_cli.commands.infer import discover_data, infer_tabular_schema


class TestInferTabularSchema:
    """Tests for tabular schema inference."""

    def test_infer_csv_columns_and_types(self, tmp_path: Path) -> None:
        """Test inferring schema from CSV with different column types."""
        csv_file = tmp_path / "users.csv"
        csv_file.write_text("id,name,score,active\n1,Alice,0.95,true\n2,Bob,0.42,false")

        schema = infer_tabular_schema(csv_file)

        assert len(schema["columns"]) == 4
        assert schema["columns"][0] == {
            "name": "id",
            "type": "integer",
            "nullable": True,
        }
        assert schema["columns"][1] == {
            "name": "name",
            "type": "string",
            "nullable": True,
        }
        assert schema["columns"][2] == {
            "name": "score",
            "type": "float",
            "nullable": True,
        }
        assert schema["columns"][3] == {
            "name": "active",
            "type": "boolean",
            "nullable": True,
        }

    def test_infer_empty_csv_returns_empty_columns(self, tmp_path: Path) -> None:
        """Test inferring schema from empty CSV."""
        csv_file = tmp_path / "empty.csv"
        csv_file.write_text("col1,col2\n")

        schema = infer_tabular_schema(csv_file)

        assert len(schema["columns"]) == 2
        assert schema["columns"][0]["name"] == "col1"
        assert schema["columns"][1]["name"] == "col2"


class TestDiscoverData:
    """Tests for data discovery and contract generation."""

    def test_discover_generates_axm_for_csv(self, tmp_path: Path) -> None:
        """Test that discover_data generates .axm contract for CSV files."""
        data_dir = tmp_path / "data"
        data_dir.mkdir()
        csv_file = data_dir / "raw_users.csv"
        csv_file.write_text("id,name\n1,Alice")

        contracts = list(discover_data(data_dir))

        assert len(contracts) == 1
        assert contracts[0]["name"] == "raw_users"
        assert contracts[0]["kind"] == "data"
        assert "columns" in contracts[0]["schema"]

    def test_discover_multiple_csv_files(self, tmp_path: Path) -> None:
        """Test discovering multiple CSV files."""
        data_dir = tmp_path / "data"
        data_dir.mkdir()
        (data_dir / "users.csv").write_text("id,name\n1,Alice")
        (data_dir / "orders.csv").write_text("order_id,user_id,amount\n100,1,99.99")

        contracts = list(discover_data(data_dir))

        assert len(contracts) == 2
        names = {c["name"] for c in contracts}
        assert names == {"users", "orders"}

    def test_discover_generates_correct_contract_content(self, tmp_path: Path) -> None:
        """Test that generated contract has correct structure."""
        data_dir = tmp_path / "data"
        data_dir.mkdir()
        (data_dir / "products.csv").write_text("sku,price\nABC123,19.99")

        contracts = list(discover_data(data_dir))

        contract = contracts[0]
        assert contract["axm"] == "1.0"
        assert contract["kind"] == "data"
        assert contract["name"] == "products"
        assert "identity" in contract
        assert contract["schema"]["format"] == "tabular"
