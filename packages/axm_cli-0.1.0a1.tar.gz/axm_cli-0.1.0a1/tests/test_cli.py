import pytest
from typer.testing import CliRunner

# We expect this import to might fail if we haven't created the file yet,
# but for TDD we write the test assuming the interface exists.
try:
    from axm_cli.main import app
except ImportError:
    app = None

runner = CliRunner()


def test_version_flag():
    if app is None:
        pytest.fail("axm_cli.main module not found")

    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "AXM CLI" in result.stdout
