"""Tests for the axm run command."""

from pathlib import Path
from textwrap import dedent

import pytest
from typer.testing import CliRunner

from axm_cli.main import app

runner = CliRunner()


@pytest.fixture
def sample_project(tmp_path: Path) -> Path:
    """Create a minimal project structure for testing."""
    # Create directories
    (tmp_path / "contracts" / "data").mkdir(parents=True)
    (tmp_path / "contracts" / "operations").mkdir(parents=True)
    (tmp_path / "contracts" / "pipelines").mkdir(parents=True)
    (tmp_path / "src").mkdir(parents=True)

    # Data contract
    (tmp_path / "contracts" / "data" / "message.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: data
        name: message
        version: "1.0.0"
        identity:
          display_name: "Message"
          domain: "demo"
          owner: {team: "dev", contact: "dev@example.com"}
        schema:
          format: json
          spec: {}
        location:
          storage: memory
          path_template: "message"
    """)
    )

    # Operation contract
    (tmp_path / "contracts" / "operations" / "greet.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: operation
        name: greet
        version: "1.0.0"
        identity:
          display_name: "Greet"
          domain: "demo"
          owner: {team: "dev", contact: "dev@example.com"}
        spec:
          type: python_file
          source: "src/hello.py"
          entrypoint: "say_hello"
        inputs: []
        outputs:
          - name: message
            data_ref: message
            version: "1.0"
    """)
    )

    # Pipeline contract
    (tmp_path / "contracts" / "pipelines" / "hello.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: pipeline
        name: hello_pipeline
        version: "1.0.0"
        identity:
          display_name: "Hello Pipeline"
          domain: "demo"
          owner: {team: "dev", contact: "dev@example.com"}
        dag:
          steps:
            - id: greet
              operation: greet
    """)
    )

    # Python implementation
    (tmp_path / "src" / "hello.py").write_text(
        dedent("""\
        def say_hello(inputs: dict, parameters: dict) -> dict:
            return {"message": "Hello from AXM!"}
    """)
    )

    return tmp_path


def test_run_command_displays_panel(sample_project: Path) -> None:
    """Test that 'axm run' displays a run panel."""
    pipeline_path = sample_project / "contracts" / "pipelines" / "hello.axm"
    result = runner.invoke(app, ["run", str(pipeline_path)])

    assert "Running pipeline" in result.stdout or "AXM Run" in result.stdout


def test_run_command_requires_pipeline_path() -> None:
    """Test that 'axm run' requires a pipeline path argument."""
    result = runner.invoke(app, ["run"])
    assert result.exit_code != 0


def test_run_command_fails_on_missing_file(tmp_path: Path) -> None:
    """Test that 'axm run' fails gracefully on missing file."""
    result = runner.invoke(app, ["run", str(tmp_path / "nonexistent.axm")])
    assert result.exit_code != 0


def test_run_command_pipeline_not_found(tmp_path: Path) -> None:
    """Test that 'axm run' fails when pipeline is not in catalog."""
    # Create minimal catalog with only data entry (no pipeline)
    (tmp_path / "data").mkdir()
    (tmp_path / "data" / "users.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: data
        name: users
        version: "1.0.0"
        identity:
          display_name: "Users"
          domain: "test"
          owner: {team: "t", contact: "t@t.com"}
        schema:
          format: json
          spec: {}
        location:
          storage: memory
          path_template: "users"
    """)
    )

    # Create empty pipeline file (will fail to parse as pipeline)
    (tmp_path / "pipelines").mkdir()
    pipeline_file = tmp_path / "pipelines" / "missing.axm"
    pipeline_file.write_text(
        dedent("""\
        axm: "1.0"
        kind: data
        name: not_a_pipeline
        version: "1.0.0"
        identity:
          display_name: "Not a Pipeline"
          domain: "test"
          owner: {team: "t", contact: "t@t.com"}
        schema:
          format: json
          spec: {}
        location:
          storage: memory
          path_template: "data"
    """)
    )

    result = runner.invoke(app, ["run", str(pipeline_file)])
    assert result.exit_code == 1
    assert "not found" in result.stdout.lower() or result.exit_code != 0


def test_run_command_successful_execution(sample_project: Path) -> None:
    """Test successful pipeline execution displays outputs."""
    pipeline_path = sample_project / "contracts" / "pipelines" / "hello.axm"
    result = runner.invoke(app, ["run", str(pipeline_path)])

    # Pipeline should complete (may succeed or fail depending on env)
    # But should show "Executing" message
    assert "Executing" in result.stdout or "Pipeline" in result.stdout
