"""Tests for the axm discover command (Pure Function Standard)."""

from pathlib import Path
from textwrap import dedent

from typer.testing import CliRunner

from axm_cli.main import app

runner = CliRunner()


def test_discover_finds_pure_function_operations(tmp_path: Path) -> None:
    """Test that discover finds pure functions by naming convention.

    Convention: operations/{name}/src/{name}/main.py with function {name}.
    """
    # Create operation package structure
    op_src = tmp_path / "operations" / "clean_data" / "src" / "clean_data"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text(
        dedent('''\
        """Clean data operation."""


        def clean_data(inputs: dict, parameters: dict) -> dict:
            """Clean the data."""
            return {}
    ''')
    )

    result = runner.invoke(app, ["discover", str(tmp_path / "operations"), "--dry-run"])

    assert result.exit_code == 0
    assert "clean_data" in result.stdout
    assert "1" in result.stdout  # 1 item discovered


def test_discover_generates_axm_file(tmp_path: Path) -> None:
    """Test that discover generates colocated .axm file."""
    # Create operation package structure
    op_src = tmp_path / "operations" / "process" / "src" / "process"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text(
        dedent('''\
        """Process data operation."""


        def process(inputs: dict, parameters: dict) -> dict:
            """Process the data."""
            return {}
    ''')
    )

    result = runner.invoke(app, ["discover", str(tmp_path / "operations")])

    assert result.exit_code == 0
    # Check colocated .axm was created next to main.py
    axm_file = op_src / "main.axm"
    assert axm_file.exists()

    content = axm_file.read_text()
    assert "kind: operation" in content
    assert "name: process" in content


def test_discover_dry_run_does_not_write(tmp_path: Path) -> None:
    """Test that --dry-run doesn't create files."""
    # Create operation package structure
    op_src = tmp_path / "operations" / "demo" / "src" / "demo"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text(
        dedent('''\
        """Demo operation."""


        def demo(inputs: dict, parameters: dict) -> dict:
            """Demo."""
            return {}
    ''')
    )

    result = runner.invoke(app, ["discover", str(tmp_path / "operations"), "--dry-run"])

    assert result.exit_code == 0
    assert not (op_src / "main.axm").exists()


def test_discover_shows_help(tmp_path: Path) -> None:
    """Test that discover command has help."""
    result = runner.invoke(app, ["discover", "--help"])

    assert result.exit_code == 0
    assert "discover" in result.stdout.lower()


def test_discover_empty_operations(tmp_path: Path) -> None:
    """Test discover with empty operations folder shows message."""
    (tmp_path / "operations").mkdir()

    result = runner.invoke(app, ["discover", str(tmp_path / "operations"), "--dry-run"])

    assert result.exit_code == 0
    assert "No operations found" in result.stdout or "0" in result.stdout


def test_discover_with_parse_error(tmp_path: Path) -> None:
    """Test discover continues on parse errors in Python files."""
    op_src = tmp_path / "operations" / "broken" / "src" / "broken"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text("def broken( invalid syntax")

    result = runner.invoke(app, ["discover", str(tmp_path / "operations"), "--dry-run"])

    # Should not crash, just skip the broken file
    assert result.exit_code == 0


def test_discover_with_data_flag(tmp_path: Path) -> None:
    """Test discover with --data flag scans data files."""
    # Create operation
    op_src = tmp_path / "operations" / "proc" / "src" / "proc"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text(
        dedent('''\
        """Process."""


        def proc(inputs: dict, parameters: dict) -> dict:
            """Process."""
            return {}
    ''')
    )

    # Create data file
    (tmp_path / "data.csv").write_text("a,b\n1,2")

    result = runner.invoke(
        app, ["discover", str(tmp_path / "operations"), "--data", "--dry-run"]
    )

    assert result.exit_code == 0
