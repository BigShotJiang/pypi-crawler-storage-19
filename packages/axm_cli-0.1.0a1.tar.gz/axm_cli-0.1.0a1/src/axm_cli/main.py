import importlib.metadata
from typing import Annotated

import typer
from rich.console import Console

from axm_cli.commands.add_operation import add_operation
from axm_cli.commands.check import check
from axm_cli.commands.discover import discover
from axm_cli.commands.init import init
from axm_cli.commands.run import run

app = typer.Typer(
    name="axm",
    help="AXM Protocols CLI - The Swiss Clock for Data Pipelines",
    add_completion=False,
)

# Sub-command group: axm add
add_app = typer.Typer(help="Add resources to the project")
add_app.command("operation")(add_operation)
app.add_typer(add_app, name="add")

app.command()(check)
app.command()(discover)
app.command()(init)
app.command()(run)
console = Console()


def get_version() -> str:
    try:
        return importlib.metadata.version("axm-cli")
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def version_callback(value: bool) -> None:
    if value:
        version = get_version()
        console.print(f"AXM CLI [bold green]v{version}[/bold green]")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool, typer.Option("--version", callback=version_callback, is_eager=True)
    ] = False,
) -> None:
    """
    AXM Protocols CLI to manage data contracts and pipelines.
    """
    pass


if __name__ == "__main__":
    app()
