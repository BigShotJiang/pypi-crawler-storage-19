"""PixelDojo test suite."""
