# kimbundu-speech

**kimbundu-speech** is a Python library that provides **Text-to-Speech (TTS)** and **Speech-to-Text (STT)** capabilities for **Kimbundu**, a Bantu language spoken in Angola. It allows developers, researchers, and language technology enthusiasts to build voice-enabled applications, assistive tools, and language preservation projects.

---

## Features

### Text-to-Speech (TTS)

- Convert Kimbundu text into high-quality speech audio using the Kimbundu and WaveGlow models.
- Save audio to a WAV file or play it immediately on your system.

#### `convert_to_file`

```python
convert_to_file(
    text: str, 
    checkpoint_path: str, 
    waveglow_path: str, 
    out_wav: str = 'output.wav', 
    device: str = 'cpu'
)
````

**Description:**
Converts input text into a spoken audio file.

**Parameters:**

* `text` (str): The input text to convert.
* `checkpoint_path` (str): Path to the Kimbundu model checkpoint.
* `waveglow_path` (str): Path to the WaveGlow model checkpoint.
* `out_wav` (str, optional): Path to save the WAV file. Default is `'output.wav'`.
* `device` (str, optional): Device to run inference (`'cpu'` or `'cuda'`). Default is `'cpu'`.

**Returns:**

* `str`: Path to the generated WAV file.

---

#### `play_default_player`

```python
play_default_player(
    text: str, 
    checkpoint_path: str, 
    waveglow_path: str, 
    device: str = 'cpu'
)
```

**Description:**
Converts text to speech and plays it immediately using the system's default audio player.

**Parameters:**

* `text` (str): The text to convert to speech.
* `checkpoint_path` (str): Path to the Tacotron model checkpoint.
* `waveglow_path` (str): Path to the WaveGlow model checkpoint.
* `device` (str, optional): Device to run inference (`'cpu'` or `'cuda'`). Default is `'cpu'`.

---

### Speech-to-Text (STT)

* Convert Kimbundu speech audio into text using a fine-tuned Whisper model.

#### `convert_to_text`

```python
convert_to_text(
    audio_path: str, 
    checkpoint_path: str
)
```

**Description:**
Transcribes speech from an audio file into text.

**Parameters:**

* `audio_path` (str): Path to the input audio file.
* `checkpoint_path` (str): Path to the fine-tuned Kimbundu Whisper model.

**Returns:**

* `str`: The transcribed text from the audio.

---

## Installation

```bash
pip install kimbundu-speech
```

**Dependencies:**

* `torch`
* `librosa`
* `soundfile`
* `numpy`
* `soundfile`
* `unidecode`
* `inflect`
* `transformers`

---

## Example Usage

```python
from kimbundu_speech import TTS, STT

# Text-to-Speech (save to WAV)
TTS.convert_to_file(
    text="ngana nzambi",
    checkpoint_path="path/to/kimbundu model",
    waveglow_path="path/to/waveglow model",
    out_wav="example.wav"
)

# Speech-to-Text
transcription = STT.convert_to_text(
    audio_path="example.wav",
    checkpoint_path="path/to/kimbundu's whisper fine-tuned model"
)

print(transcription)
```
