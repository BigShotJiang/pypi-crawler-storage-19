"""
VeriRoute Intel SDK Errors

Custom exception classes for API errors.
"""

from typing import Any, Dict, Optional


class VeriRouteError(Exception):
    """Base exception for VeriRoute SDK errors."""

    def __init__(
        self,
        message: str,
        code: str = "UNKNOWN_ERROR",
        status_code: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.details = details or {}

    def __str__(self) -> str:
        return f"[{self.code}] {self.args[0]}"


class AuthenticationError(VeriRouteError):
    """Raised when API key is invalid or missing."""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, "AUTH_FAILED", 401)


class RateLimitError(VeriRouteError):
    """Raised when rate limit is exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: Optional[int] = None,
    ):
        super().__init__(message, "RATE_LIMIT_EXCEEDED", 429)
        self.retry_after = retry_after


class InsufficientBalanceError(VeriRouteError):
    """Raised when account has insufficient balance."""

    def __init__(self, message: str = "Insufficient account balance"):
        super().__init__(message, "INSUFFICIENT_BALANCE", 402)


class InvalidPhoneError(VeriRouteError):
    """Raised when phone number is invalid."""

    def __init__(
        self,
        message: str = "Invalid phone number",
        phone_number: Optional[str] = None,
    ):
        super().__init__(
            message,
            "INVALID_PHONE_NUMBER",
            400,
            {"phone_number": phone_number} if phone_number else None,
        )
        self.phone_number = phone_number


class InternationalNotSupportedError(VeriRouteError):
    """Raised when attempting to look up international (non-NANP) numbers."""

    def __init__(
        self,
        message: str = "International numbers are not supported. Only North American (NANP) numbers are accepted.",
        phone_number: Optional[str] = None,
        detected_country_code: Optional[int] = None,
    ):
        super().__init__(
            message,
            "INTERNATIONAL_NOT_SUPPORTED",
            400,
            {
                "phone_number": phone_number,
                "detected_country_code": detected_country_code,
                "supported_country_codes": [1],
            },
        )
        self.phone_number = phone_number
        self.detected_country_code = detected_country_code


class TimeoutError(VeriRouteError):
    """Raised when request times out."""

    def __init__(self, message: str = "Request timed out"):
        super().__init__(message, "TIMEOUT")


class NetworkError(VeriRouteError):
    """Raised when network error occurs."""

    def __init__(self, message: str = "Network error occurred"):
        super().__init__(message, "NETWORK_ERROR")
