"""
VeriRoute Intel SDK Types

Dataclasses for API responses with full type hints.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Literal, Optional

SpamType = Literal["NONE", "SPAM", "SCAM", "ROBOCALL", "TELEMARKETER"]
LineType = Literal["mobile", "landline", "voip", "unknown"]
ReportType = Literal["spam", "robocall", "scam", "telemarketing", "fraud", "phishing"]


@dataclass
class CnamResult:
    """CNAM lookup result."""
    number: str
    cnam: Optional[str]
    spam_type: Optional[SpamType] = None


@dataclass
class EnhancedLrnData:
    """Enhanced LRN data with location information."""
    carrier: str
    carrier_type: str
    city: str
    state: str
    zip_code: str
    county: str
    timezone: str
    rate_center: str
    lata: str
    ocn: str


@dataclass
class MessagingData:
    """Messaging provider information."""
    provider: str
    enabled: bool
    country: str
    country_code: str
    reference_id: Optional[str] = None


@dataclass
class LrnResult:
    """LRN lookup result with carrier and line type."""
    phone_number: str
    lrn: Optional[str]
    lrn_activated_at: Optional[str]
    carrier: str
    line_type: LineType
    enhanced: Optional[EnhancedLrnData] = None
    messaging: Optional[MessagingData] = None


@dataclass
class TrustResult:
    """Trust/reputation lookup result."""
    number: str
    is_spam: bool
    is_robocall: bool
    is_scam: bool
    spam_type: SpamType
    complaint_count: int
    subjects: List[str] = field(default_factory=list)
    first_reported: Optional[str] = None
    last_reported: Optional[str] = None
    details: str = ""


@dataclass
class SpamResult:
    """Spam check result."""
    phone_number: str
    is_spam: bool
    is_robocall: bool
    is_scam: bool
    spam_type: SpamType
    cached: bool
    source: str


@dataclass
class SpamReportResult:
    """Result of spam report submission."""
    success: bool
    report_id: int
    carrier_id: Optional[int]
    carrier_name: Optional[str]
    message: str


@dataclass
class MessagingResult:
    """Messaging provider lookup result."""
    phone_number: str
    messaging_provider: str
    messaging_enabled: bool
    messaging_country: str
    messaging_country_code: str
    reference_id: str


@dataclass
class AnalyticsPeriod:
    """Analytics time period."""
    start: str
    end: str


@dataclass
class AnalyticsResult:
    """Analytics data result."""
    period: AnalyticsPeriod
    total_lookups: int
    carrier_type_breakdown: Dict[str, int]
    spam_breakdown: Dict[str, int]
    provider_category_breakdown: Dict[str, int]
    geographic_breakdown: Dict[str, int]
    trends: List[Dict[str, object]]


@dataclass
class UsageResult:
    """Usage report result."""
    total_lookups: int
    by_type: Dict[str, int]
    period: AnalyticsPeriod
    credits_remaining: float


@dataclass
class BulkError:
    """Error for a single number in bulk operation."""
    phone_number: str
    error: str


@dataclass
class BulkCnamResult:
    """Bulk CNAM lookup result."""
    results: List[CnamResult]
    errors: List[BulkError]
    total: int
    successful: int
    failed: int


@dataclass
class BulkLrnResult:
    """Bulk LRN lookup result."""
    results: List[LrnResult]
    errors: List[BulkError]
    total: int
    successful: int
    failed: int


@dataclass
class BulkSpamResult:
    """Bulk spam check result."""
    results: List[SpamResult]
    errors: List[BulkError]
    total: int
    successful: int
    failed: int
