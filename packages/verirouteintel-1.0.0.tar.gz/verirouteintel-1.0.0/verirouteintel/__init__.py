"""
VeriRoute Intel Python SDK

Official Python SDK for VeriRoute Intel phone number intelligence API.

Example:
    >>> from verirouteintel import VeriRoute
    >>> vri = VeriRoute('your_api_key')
    >>> caller = vri.cnam('+15551234567')
    >>> print(caller.cnam)
    JOHN DOE
"""

from .client import VeriRoute, VRI
from .types import (
    CnamResult,
    LrnResult,
    EnhancedLrnData,
    MessagingData,
    TrustResult,
    SpamResult,
    SpamReportResult,
    MessagingResult,
    AnalyticsResult,
    UsageResult,
    BulkCnamResult,
    BulkLrnResult,
    BulkSpamResult,
)
from .errors import (
    VeriRouteError,
    AuthenticationError,
    RateLimitError,
    InsufficientBalanceError,
    InvalidPhoneError,
    InternationalNotSupportedError,
    TimeoutError,
    NetworkError,
)

__version__ = "1.0.0"
__all__ = [
    # Client
    "VeriRoute",
    "VRI",
    # Types
    "CnamResult",
    "LrnResult",
    "EnhancedLrnData",
    "MessagingData",
    "TrustResult",
    "SpamResult",
    "SpamReportResult",
    "MessagingResult",
    "AnalyticsResult",
    "UsageResult",
    "BulkCnamResult",
    "BulkLrnResult",
    "BulkSpamResult",
    # Errors
    "VeriRouteError",
    "AuthenticationError",
    "RateLimitError",
    "InsufficientBalanceError",
    "InvalidPhoneError",
    "InternationalNotSupportedError",
    "TimeoutError",
    "NetworkError",
]
