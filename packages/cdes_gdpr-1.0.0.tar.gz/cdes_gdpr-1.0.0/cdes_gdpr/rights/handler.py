"""Data Subject Rights"""
from datetime import datetime
from cdes_gdpr.models import DataSubjectRequest, RequestType

class DataSubjectRightsHandler:
    def __init__(self): self._requests = {}
    def submit_request(self, subject_id: str, request_type: RequestType): return DataSubjectRequest(id=f"DSR_{subject_id}", subject_id=subject_id, request_type=request_type)