"""CDES-GDPR"""
from cdes_gdpr.models import *
__version__ = "1.0.0"