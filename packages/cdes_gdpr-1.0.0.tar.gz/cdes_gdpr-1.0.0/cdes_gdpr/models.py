"""CDES-GDPR Data Models"""
from datetime import datetime
from enum import Enum
from typing import Optional, List
from pydantic import BaseModel, Field

class LawfulBasis(str, Enum):
    CONSENT = "consent"
    CONTRACT = "contract"
    LEGAL_OBLIGATION = "legal_obligation"
    VITAL_INTERESTS = "vital_interests"
    PUBLIC_TASK = "public_task"
    LEGITIMATE_INTERESTS = "legitimate_interests"

class RequestType(str, Enum):
    ACCESS = "access"
    RECTIFICATION = "rectification"
    ERASURE = "erasure"
    RESTRICTION = "restriction"
    PORTABILITY = "portability"
    OBJECTION = "objection"

class ConsentPurpose(str, Enum):
    MEDICAL_TREATMENT = "medical_treatment"
    PRODUCT_RECOMMENDATIONS = "product_recommendations"
    RESEARCH = "research"
    MARKETING = "marketing"
    ANALYTICS = "analytics"

class DataSubject(BaseModel):
    id: str
    email: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Consent(BaseModel):
    id: str
    subject_id: str
    purpose: ConsentPurpose
    granted: bool
    granted_at: Optional[datetime] = None
    withdrawn_at: Optional[datetime] = None

class DataSubjectRequest(BaseModel):
    id: str
    subject_id: str
    request_type: RequestType
    status: str = "pending"
    requested_at: datetime = Field(default_factory=datetime.utcnow)

class ProcessingActivity(BaseModel):
    id: str
    name: str
    purpose: str
    lawful_basis: LawfulBasis
    data_categories: List[str]

class DataRetentionPolicy(BaseModel):
    data_category: str
    retention_days: int
    auto_delete: bool = True

class PrivacyImpactAssessment(BaseModel):
    id: str
    project_name: str
    risk_level: str
    findings: List[str]
    mitigations: List[str]