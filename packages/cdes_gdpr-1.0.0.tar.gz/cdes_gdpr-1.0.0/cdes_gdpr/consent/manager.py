"""Consent Management"""
from typing import List, Optional
from datetime import datetime
from cdes_gdpr.models import Consent, ConsentPurpose

class ConsentManager:
    def __init__(self):
        self._consents = {}
    
    def grant_consent(self, subject_id: str, purpose: ConsentPurpose) -> Consent:
        consent = Consent(id=f"{subject_id}_{purpose.value}", subject_id=subject_id,
                          purpose=purpose, granted=True, granted_at=datetime.utcnow())
        self._consents.setdefault(subject_id, []).append(consent)
        return consent
    
    def withdraw_consent(self, subject_id: str, purpose: ConsentPurpose) -> Optional[Consent]:
        for c in self._consents.get(subject_id, []):
            if c.purpose == purpose and c.granted:
                c.granted = False
                c.withdrawn_at = datetime.utcnow()
                return c
        return None
    
    def has_consent(self, subject_id: str, purpose: ConsentPurpose) -> bool:
        return any(c.purpose == purpose and c.granted for c in self._consents.get(subject_id, []))