"""Data Anonymization Engine"""
import hashlib
from typing import Dict, Any

class AnonymizationEngine:
    def pseudonymize(self, data: str) -> str: return hashlib.sha256(data.encode()).hexdigest()[:16]
    def anonymize_record(self, record: Dict[str, Any], fields: list) -> Dict[str, Any]:
        result = record.copy()
        for f in fields:
            if f in result: result[f] = self.pseudonymize(str(result[f]))
        return result