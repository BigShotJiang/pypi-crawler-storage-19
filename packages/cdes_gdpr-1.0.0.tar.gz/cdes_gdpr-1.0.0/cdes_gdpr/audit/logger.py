"""GDPR Audit Logger"""
from datetime import datetime
from typing import List

class GDPRAuditLogger:
    def __init__(self): self._logs = []
    def log(self, action: str, subject_id: str, details: dict = None): self._logs.append({"timestamp": datetime.utcnow(), "action": action, "subject_id": subject_id, "details": details})
    def get_logs(self, subject_id: str = None) -> List[dict]: return [l for l in self._logs if not subject_id or l["subject_id"] == subject_id]