# CDES-GDPR

GDPR Compliance for Cannabis Data