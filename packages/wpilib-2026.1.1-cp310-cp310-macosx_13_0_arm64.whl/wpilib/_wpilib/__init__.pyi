from __future__ import annotations
import collections.abc
import hal._wpiHal
import logging
import ntcore._ntcore
import typing
import typing_extensions
import wpilib.event._event
import wpilib.interfaces._interfaces
import wpimath._controls._controls.trajectory
import wpimath.geometry._geometry
import wpimath.units
import wpiutil._wpiutil
import wpiutil._wpiutil.log
from . import sysid
__all__: list[str] = ['ADIS16448_IMU', 'ADIS16470_IMU', 'ADXL345_I2C', 'ADXL345_SPI', 'ADXL362', 'ADXRS450_Gyro', 'AddressableLED', 'Alert', 'AnalogAccelerometer', 'AnalogEncoder', 'AnalogGyro', 'AnalogInput', 'AnalogOutput', 'AnalogPotentiometer', 'AnalogTrigger', 'AnalogTriggerOutput', 'AnalogTriggerType', 'BuiltInAccelerometer', 'CAN', 'CANData', 'CANStatus', 'Color', 'Color8Bit', 'Compressor', 'CompressorConfigType', 'Counter', 'DSControlWord', 'DataLogManager', 'DigitalGlitchFilter', 'DigitalInput', 'DigitalOutput', 'DigitalSource', 'DoubleSolenoid', 'DriverStation', 'DutyCycle', 'DutyCycleEncoder', 'Encoder', 'Field2d', 'FieldObject2d', 'I2C', 'IterativeRobotBase', 'Joystick', 'Koors40', 'LEDPattern', 'LiveWindow', 'Mechanism2d', 'MechanismLigament2d', 'MechanismObject2d', 'MechanismRoot2d', 'MotorControllerGroup', 'MotorSafety', 'Notifier', 'PS4Controller', 'PS5Controller', 'PWM', 'PWMMotorController', 'PWMSparkFlex', 'PWMSparkMax', 'PWMTalonFX', 'PWMTalonSRX', 'PWMVenom', 'PWMVictorSPX', 'PneumaticHub', 'PneumaticsBase', 'PneumaticsControlModule', 'PneumaticsModuleType', 'PowerDistribution', 'Preferences', 'RadioLEDState', 'Relay', 'RobotBase', 'RobotController', 'RobotState', 'RuntimeType', 'SPI', 'SendableBuilderImpl', 'SendableChooser', 'SendableChooserBase', 'SensorUtil', 'SerialPort', 'Servo', 'SharpIR', 'SmartDashboard', 'Solenoid', 'Spark', 'StadiaController', 'SynchronousInterrupt', 'Talon', 'TimedRobot', 'Timer', 'TimesliceRobot', 'Tracer', 'Ultrasonic', 'VictorSP', 'Watchdog', 'XboxController', 'getCurrentThreadPriority', 'getDeployDirectory', 'getErrorMessage', 'getOperatingDirectory', 'getTime', 'setCurrentThreadPriority', 'sysid', 'wait']
class ADIS16448_IMU(wpiutil._wpiutil.Sendable):
    class CalibrationTime:
        """
        ADIS16448 calibration times.
        
        Members:
        
          _32ms : 32 ms calibration time.
        
          _64ms : 64 ms calibration time.
        
          _128ms : 128 ms calibration time.
        
          _256ms : 256 ms calibration time.
        
          _512ms : 512 ms calibration time.
        
          _1s : 1 s calibration time.
        
          _2s : 2 s calibration time.
        
          _4s : 4 s calibration time.
        
          _8s : 8 s calibration time.
        
          _16s : 16 s calibration time.
        
          _32s : 32 s calibration time.
        
          _64s : 64 s calibration time.
        """
        _128ms: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._128ms: 2>
        _16s: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._16s: 9>
        _1s: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._1s: 5>
        _256ms: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._256ms: 3>
        _2s: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._2s: 6>
        _32ms: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._32ms: 0>
        _32s: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._32s: 10>
        _4s: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._4s: 7>
        _512ms: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._512ms: 4>
        _64ms: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._64ms: 1>
        _64s: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._64s: 11>
        _8s: typing.ClassVar[ADIS16448_IMU.CalibrationTime]  # value = <CalibrationTime._8s: 8>
        __members__: typing.ClassVar[dict[str, ADIS16448_IMU.CalibrationTime]]  # value = {'_32ms': <CalibrationTime._32ms: 0>, '_64ms': <CalibrationTime._64ms: 1>, '_128ms': <CalibrationTime._128ms: 2>, '_256ms': <CalibrationTime._256ms: 3>, '_512ms': <CalibrationTime._512ms: 4>, '_1s': <CalibrationTime._1s: 5>, '_2s': <CalibrationTime._2s: 6>, '_4s': <CalibrationTime._4s: 7>, '_8s': <CalibrationTime._8s: 8>, '_16s': <CalibrationTime._16s: 9>, '_32s': <CalibrationTime._32s: 10>, '_64s': <CalibrationTime._64s: 11>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class IMUAxis:
        """
        IMU axes.
        
        Members:
        
          kX : The IMU's X axis.
        
          kY : The IMU's Y axis.
        
          kZ : The IMU's Z axis.
        """
        __members__: typing.ClassVar[dict[str, ADIS16448_IMU.IMUAxis]]  # value = {'kX': <IMUAxis.kX: 0>, 'kY': <IMUAxis.kY: 1>, 'kZ': <IMUAxis.kZ: 2>}
        kX: typing.ClassVar[ADIS16448_IMU.IMUAxis]  # value = <IMUAxis.kX: 0>
        kY: typing.ClassVar[ADIS16448_IMU.IMUAxis]  # value = <IMUAxis.kY: 1>
        kZ: typing.ClassVar[ADIS16448_IMU.IMUAxis]  # value = <IMUAxis.kZ: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    @typing.overload
    def __init__(self) -> None:
        """
        IMU constructor on onboard MXP CS0, Z-up orientation, and complementary
        AHRS computation.
        """
    @typing.overload
    def __init__(self, yaw_axis: ADIS16448_IMU.IMUAxis, port: SPI.Port, cal_time: ADIS16448_IMU.CalibrationTime) -> None:
        """
        IMU constructor on the specified MXP port and orientation.
        
        :param yaw_axis: The axis where gravity is present. Valid options are kX,
                         kY, and kZ
        :param port:     The SPI port where the IMU is connected.
        :param cal_time: The calibration time that should be used on start-up.
        """
    def calibrate(self) -> None:
        """
        Initialize the IMU.
        
        Perform gyro offset calibration by collecting data for a number of seconds
        and computing the center value. The center value is subtracted from
        subsequent measurements.
        
        It's important to make sure that the robot is not moving while the
        centering calculations are in progress, this is typically done when the
        robot is first turned on while it's sitting at rest before the match
        starts.
        
        The calibration routine can be triggered by the user during runtime.
        """
    def configCalTime(self, new_cal_time: ADIS16448_IMU.CalibrationTime) -> int:
        """
        Configures the calibration time used for the next calibrate.
        
        :param new_cal_time: The calibration time that should be used
        """
    def configDecRate(self, decimationRate: typing.SupportsInt) -> int:
        """
        Configures the decimation rate of the IMU.
        
        :param decimationRate: The new decimation value.
        
        :returns: 0 if success, 1 if no change, 2 if error.
        """
    def getAccelX(self) -> wpimath.units.meters_per_second_squared:
        """
        Returns the acceleration in the X axis.
        """
    def getAccelY(self) -> wpimath.units.meters_per_second_squared:
        """
        Returns the acceleration in the Y axis.
        """
    def getAccelZ(self) -> wpimath.units.meters_per_second_squared:
        """
        Returns the acceleration in the Z axis.
        """
    def getAngle(self) -> wpimath.units.degrees:
        """
        Returns the yaw axis angle in degrees (CCW positive).
        """
    def getBarometricPressure(self) -> wpimath.units.pounds_per_square_inch:
        """
        Returns the barometric pressure.
        """
    def getGyroAngleX(self) -> wpimath.units.degrees:
        """
        Returns the accumulated gyro angle in the X axis.
        """
    def getGyroAngleY(self) -> wpimath.units.degrees:
        """
        Returns the accumulated gyro angle in the Y axis.
        """
    def getGyroAngleZ(self) -> wpimath.units.degrees:
        """
        Returns the accumulated gyro angle in the Z axis.
        """
    def getGyroRateX(self) -> wpimath.units.degrees_per_second:
        """
        Returns the angular rate in the X axis.
        """
    def getGyroRateY(self) -> wpimath.units.degrees_per_second:
        """
        Returns the angular rate in the Y axis.
        """
    def getGyroRateZ(self) -> wpimath.units.degrees_per_second:
        """
        Returns the angular rate in the Z axis.
        """
    def getMagneticFieldX(self) -> wpimath.units.teslas:
        """
        Returns the magnetic field strength in the X axis.
        """
    def getMagneticFieldY(self) -> wpimath.units.teslas:
        """
        Returns the magnetic field strength in the Y axis.
        """
    def getMagneticFieldZ(self) -> wpimath.units.teslas:
        """
        Returns the magnetic field strength in the Z axis.
        """
    def getPort(self) -> int:
        """
        Get the SPI port number.
        
        :returns: The SPI port number.
        """
    def getRate(self) -> wpimath.units.degrees_per_second:
        """
        Returns the yaw axis angular rate in degrees per second (CCW positive).
        """
    def getTemperature(self) -> wpimath.units.celsius:
        """
        Returns the temperature.
        """
    def getXComplementaryAngle(self) -> wpimath.units.degrees:
        """
        Returns the complementary angle around the X axis computed from
        accelerometer and gyro rate measurements.
        """
    def getXFilteredAccelAngle(self) -> wpimath.units.degrees:
        """
        Returns the X-axis filtered acceleration angle.
        """
    def getYComplementaryAngle(self) -> wpimath.units.degrees:
        """
        Returns the complementary angle around the Y axis computed from
        accelerometer and gyro rate measurements.
        """
    def getYFilteredAccelAngle(self) -> wpimath.units.degrees:
        """
        Returns the Y-axis filtered acceleration angle.
        """
    def getYawAxis(self) -> ADIS16448_IMU.IMUAxis:
        ...
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isConnected(self) -> bool:
        """
        Checks the connection status of the IMU.
        
        :returns: True if the IMU is connected, false otherwise.
        """
    def reset(self) -> None:
        """
        Reset the gyro.
        
        Resets the gyro accumulations to a heading of zero. This can be used if
        there is significant drift in the gyro and it needs to be recalibrated
        after running.
        """
    def setYawAxis(self, yaw_axis: ADIS16448_IMU.IMUAxis) -> int:
        ...
class ADIS16470_IMU(wpiutil._wpiutil.Sendable):
    class CalibrationTime:
        """
        ADIS16470 calibration times.
        
        Members:
        
          _32ms : 32 ms calibration time.
        
          _64ms : 64 ms calibration time.
        
          _128ms : 128 ms calibration time.
        
          _256ms : 256 ms calibration time.
        
          _512ms : 512 ms calibration time.
        
          _1s : 1 s calibration time.
        
          _2s : 2 s calibration time.
        
          _4s : 4 s calibration time.
        
          _8s : 8 s calibration time.
        
          _16s : 16 s calibration time.
        
          _32s : 32 s calibration time.
        
          _64s : 64 s calibration time.
        """
        _128ms: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._128ms: 2>
        _16s: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._16s: 9>
        _1s: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._1s: 5>
        _256ms: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._256ms: 3>
        _2s: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._2s: 6>
        _32ms: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._32ms: 0>
        _32s: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._32s: 10>
        _4s: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._4s: 7>
        _512ms: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._512ms: 4>
        _64ms: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._64ms: 1>
        _64s: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._64s: 11>
        _8s: typing.ClassVar[ADIS16470_IMU.CalibrationTime]  # value = <CalibrationTime._8s: 8>
        __members__: typing.ClassVar[dict[str, ADIS16470_IMU.CalibrationTime]]  # value = {'_32ms': <CalibrationTime._32ms: 0>, '_64ms': <CalibrationTime._64ms: 1>, '_128ms': <CalibrationTime._128ms: 2>, '_256ms': <CalibrationTime._256ms: 3>, '_512ms': <CalibrationTime._512ms: 4>, '_1s': <CalibrationTime._1s: 5>, '_2s': <CalibrationTime._2s: 6>, '_4s': <CalibrationTime._4s: 7>, '_8s': <CalibrationTime._8s: 8>, '_16s': <CalibrationTime._16s: 9>, '_32s': <CalibrationTime._32s: 10>, '_64s': <CalibrationTime._64s: 11>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class IMUAxis:
        """
        IMU axes.
        
        kX, kY, and kZ refer to the IMU's X, Y, and Z axes respectively. kYaw,
        kPitch, and kRoll are configured by the user to refer to an X, Y, or Z
        axis.
        
        Members:
        
          kX : The IMU's X axis.
        
          kY : The IMU's Y axis.
        
          kZ : The IMU's Z axis.
        
          kYaw : The user-configured yaw axis.
        
          kPitch : The user-configured pitch axis.
        
          kRoll : The user-configured roll axis.
        """
        __members__: typing.ClassVar[dict[str, ADIS16470_IMU.IMUAxis]]  # value = {'kX': <IMUAxis.kX: 0>, 'kY': <IMUAxis.kY: 1>, 'kZ': <IMUAxis.kZ: 2>, 'kYaw': <IMUAxis.kYaw: 3>, 'kPitch': <IMUAxis.kPitch: 4>, 'kRoll': <IMUAxis.kRoll: 5>}
        kPitch: typing.ClassVar[ADIS16470_IMU.IMUAxis]  # value = <IMUAxis.kPitch: 4>
        kRoll: typing.ClassVar[ADIS16470_IMU.IMUAxis]  # value = <IMUAxis.kRoll: 5>
        kX: typing.ClassVar[ADIS16470_IMU.IMUAxis]  # value = <IMUAxis.kX: 0>
        kY: typing.ClassVar[ADIS16470_IMU.IMUAxis]  # value = <IMUAxis.kY: 1>
        kYaw: typing.ClassVar[ADIS16470_IMU.IMUAxis]  # value = <IMUAxis.kYaw: 3>
        kZ: typing.ClassVar[ADIS16470_IMU.IMUAxis]  # value = <IMUAxis.kZ: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    @typing.overload
    def __init__(self) -> None:
        """
        Creates a new ADIS16740 IMU object.
        
        The default setup is the onboard SPI port with a calibration time of 1
        second. Yaw, pitch, and roll are kZ, kX, and kY respectively.
        """
    @typing.overload
    def __init__(self, yaw_axis: ADIS16470_IMU.IMUAxis, pitch_axis: ADIS16470_IMU.IMUAxis, roll_axis: ADIS16470_IMU.IMUAxis) -> None:
        """
        Creates a new ADIS16740 IMU object.
        
        The default setup is the onboard SPI port with a calibration time of 1
        second.
        
        :strong:`:emphasis:`Input axes limited to kX, kY and kZ. Specifying kYaw, kPitch,or kRoll
        will result in an error.``
        
        :param yaw_axis:   The axis that measures the yaw
        :param pitch_axis: The axis that measures the pitch
        :param roll_axis:  The axis that measures the roll
        """
    @typing.overload
    def __init__(self, yaw_axis: ADIS16470_IMU.IMUAxis, pitch_axis: ADIS16470_IMU.IMUAxis, roll_axis: ADIS16470_IMU.IMUAxis, port: SPI.Port, cal_time: ADIS16470_IMU.CalibrationTime) -> None:
        """
        Creates a new ADIS16740 IMU object.
        
        :strong:`:emphasis:`Input axes limited to kX, kY and kZ. Specifying kYaw, kPitch, or
        kRoll will result in an error.``
        
        :param yaw_axis:   The axis that measures the yaw
        :param pitch_axis: The axis that measures the pitch
        :param roll_axis:  The axis that measures the roll
        :param port:       The SPI Port the gyro is plugged into
        :param cal_time:   Calibration time
        """
    def calibrate(self) -> None:
        """
        Switches the active SPI port to standard SPI mode, writes the
        command to activate the new null configuration, and re-enables auto SPI.
        """
    def configCalTime(self, new_cal_time: ADIS16470_IMU.CalibrationTime) -> int:
        """
        Configures calibration time.
        
        :param new_cal_time: New calibration time
        
        :returns: 0 if success, 1 if no change, 2 if error.
        """
    def configDecRate(self, decimationRate: typing.SupportsInt) -> int:
        """
        Configures the decimation rate of the IMU.
        
        :param decimationRate: The new decimation value.
        
        :returns: 0 if success, 1 if no change, 2 if error.
        """
    def getAccelX(self) -> wpimath.units.meters_per_second_squared:
        """
        Returns the acceleration in the X axis.
        """
    def getAccelY(self) -> wpimath.units.meters_per_second_squared:
        """
        Returns the acceleration in the Y axis.
        """
    def getAccelZ(self) -> wpimath.units.meters_per_second_squared:
        """
        Returns the acceleration in the Z axis.
        """
    def getAngle(self, axis: ADIS16470_IMU.IMUAxis = ...) -> wpimath.units.degrees:
        """
        Returns the axis angle (CCW positive).
        
        :param axis: The IMUAxis whose angle to return. Defaults to user configured
                     Yaw.
        
        :returns: The axis angle (CCW positive).
        """
    def getPitchAxis(self) -> ADIS16470_IMU.IMUAxis:
        """
        Returns which axis, kX, kY, or kZ, is set to the pitch axis.
        
        :returns: IMUAxis Pitch Axis
        """
    def getPort(self) -> int:
        """
        Gets the SPI port number.
        
        :returns: The SPI port number.
        """
    def getRate(self, axis: ADIS16470_IMU.IMUAxis = ...) -> wpimath.units.degrees_per_second:
        """
        Returns the axis angular rate (CCW positive).
        
        :param axis: The IMUAxis whose rate to return. Defaults to user configured
                     Yaw.
        
        :returns: Axis angular rate (CCW positive).
        """
    def getRollAxis(self) -> ADIS16470_IMU.IMUAxis:
        """
        Returns which axis, kX, kY, or kZ, is set to the roll axis.
        
        :returns: IMUAxis Roll Axis
        """
    def getXComplementaryAngle(self) -> wpimath.units.degrees:
        """
        Returns the X-axis complementary angle.
        """
    def getXFilteredAccelAngle(self) -> wpimath.units.degrees:
        """
        Returns the X-axis filtered acceleration angle.
        """
    def getYComplementaryAngle(self) -> wpimath.units.degrees:
        """
        Returns the Y-axis complementary angle.
        """
    def getYFilteredAccelAngle(self) -> wpimath.units.degrees:
        """
        Returns the Y-axis filtered acceleration angle.
        """
    def getYawAxis(self) -> ADIS16470_IMU.IMUAxis:
        """
        Returns which axis, kX, kY, or kZ, is set to the yaw axis.
        
        :returns: IMUAxis Yaw Axis
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isConnected(self) -> bool:
        """
        Checks the connection status of the IMU.
        
        :returns: True if the IMU is connected, false otherwise.
        """
    def reset(self) -> None:
        """
        Reset the gyro.
        
        Resets the gyro accumulations to a heading of zero. This can be used if
        there is significant drift in the gyro and it needs to be recalibrated
        after running.
        """
    def setGyroAngle(self, axis: ADIS16470_IMU.IMUAxis, angle: wpimath.units.degrees) -> None:
        """
        Allow the designated gyro angle to be set to a given value. This may happen
        with unread values in the buffer, it is suggested that the IMU is not
        moving when this method is run.
        
        :param axis:  IMUAxis that will be changed
        :param angle: The new angle (CCW positive)
        """
    def setGyroAngleX(self, angle: wpimath.units.degrees) -> None:
        """
        Allow the gyro angle X to be set to a given value. This may happen with
        unread values in the buffer, it is suggested that the IMU is not moving
        when this method is run.
        
        :param angle: The new angle (CCW positive)
        """
    def setGyroAngleY(self, angle: wpimath.units.degrees) -> None:
        """
        Allow the gyro angle Y to be set to a given value. This may happen with
        unread values in the buffer, it is suggested that the IMU is not moving
        when this method is run.
        
        :param angle: The new angle (CCW positive)
        """
    def setGyroAngleZ(self, angle: wpimath.units.degrees) -> None:
        """
        Allow the gyro angle Z to be set to a given value. This may happen with
        unread values in the buffer, it is suggested that the IMU is not moving
        when this method is run.
        
        :param angle: The new angle (CCW positive)
        """
    @property
    def m_pitch_axis(self) -> ADIS16470_IMU.IMUAxis:
        ...
    @property
    def m_roll_axis(self) -> ADIS16470_IMU.IMUAxis:
        ...
    @property
    def m_yaw_axis(self) -> ADIS16470_IMU.IMUAxis:
        ...
class ADXL345_I2C(ntcore._ntcore.NTSendable):
    """
    ADXL345 Accelerometer on I2C.
    
    This class allows access to a Analog Devices ADXL345 3-axis accelerometer on
    an I2C bus. This class assumes the default (not alternate) sensor address of
    0x1D (7-bit address).
    
    The Onboard I2C port is subject to system lockups. See <a
    href="https://docs.wpilib.org/en/stable/docs/yearly-overview/known-issues.html#onboard-i2c-causing-system-lockups">
    WPILib Known Issues</a> page for details.
    """
    class AllAxes:
        """
        Container type for accelerations from all axes.
        """
        def __init__(self) -> None:
            ...
        @property
        def XAxis(self) -> float:
            """
            Acceleration along the X axis in g-forces.
            """
        @XAxis.setter
        def XAxis(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def YAxis(self) -> float:
            """
            Acceleration along the Y axis in g-forces.
            """
        @YAxis.setter
        def YAxis(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def ZAxis(self) -> float:
            """
            Acceleration along the Z axis in g-forces.
            """
        @ZAxis.setter
        def ZAxis(self, arg0: typing.SupportsFloat) -> None:
            ...
    class Axes:
        """
        Accelerometer axes.
        
        Members:
        
          kAxis_X : X axis.
        
          kAxis_Y : Y axis.
        
          kAxis_Z : Z axis.
        """
        __members__: typing.ClassVar[dict[str, ADXL345_I2C.Axes]]  # value = {'kAxis_X': <Axes.kAxis_X: 0>, 'kAxis_Y': <Axes.kAxis_Y: 2>, 'kAxis_Z': <Axes.kAxis_Z: 4>}
        kAxis_X: typing.ClassVar[ADXL345_I2C.Axes]  # value = <Axes.kAxis_X: 0>
        kAxis_Y: typing.ClassVar[ADXL345_I2C.Axes]  # value = <Axes.kAxis_Y: 2>
        kAxis_Z: typing.ClassVar[ADXL345_I2C.Axes]  # value = <Axes.kAxis_Z: 4>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Range:
        """
        Accelerometer range.
        
        Members:
        
          kRange_2G : 2 Gs max.
        
          kRange_4G : 4 Gs max.
        
          kRange_8G : 8 Gs max.
        
          kRange_16G : 16 Gs max.
        """
        __members__: typing.ClassVar[dict[str, ADXL345_I2C.Range]]  # value = {'kRange_2G': <Range.kRange_2G: 0>, 'kRange_4G': <Range.kRange_4G: 1>, 'kRange_8G': <Range.kRange_8G: 2>, 'kRange_16G': <Range.kRange_16G: 3>}
        kRange_16G: typing.ClassVar[ADXL345_I2C.Range]  # value = <Range.kRange_16G: 3>
        kRange_2G: typing.ClassVar[ADXL345_I2C.Range]  # value = <Range.kRange_2G: 0>
        kRange_4G: typing.ClassVar[ADXL345_I2C.Range]  # value = <Range.kRange_4G: 1>
        kRange_8G: typing.ClassVar[ADXL345_I2C.Range]  # value = <Range.kRange_8G: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    kAddress: typing.ClassVar[int] = 29
    def __init__(self, port: I2C.Port, range: ADXL345_I2C.Range = ..., deviceAddress: typing.SupportsInt = 29) -> None:
        """
        Constructs the ADXL345 Accelerometer over I2C.
        
        :param port:          The I2C port the accelerometer is attached to
        :param range:         The range (+ or -) that the accelerometer will measure
        :param deviceAddress: The I2C address of the accelerometer (0x1D or 0x53)
        """
    def getAcceleration(self, axis: ADXL345_I2C.Axes) -> float:
        """
        Get the acceleration of one axis in Gs.
        
        :param axis: The axis to read from.
        
        :returns: Acceleration of the ADXL345 in Gs.
        """
    def getAccelerations(self) -> ADXL345_I2C.AllAxes:
        """
        Get the acceleration of all axes in Gs.
        
        :returns: An object containing the acceleration measured on each axis of the
                  ADXL345 in Gs.
        """
    def getI2CDeviceAddress(self) -> int:
        ...
    def getI2CPort(self) -> I2C.Port:
        ...
    def getX(self) -> float:
        """
        Returns the acceleration along the X axis in g-forces.
        
        :returns: The acceleration along the X axis in g-forces.
        """
    def getY(self) -> float:
        """
        Returns the acceleration along the Y axis in g-forces.
        
        :returns: The acceleration along the Y axis in g-forces.
        """
    def getZ(self) -> float:
        """
        Returns the acceleration along the Z axis in g-forces.
        
        :returns: The acceleration along the Z axis in g-forces.
        """
    def initSendable(self, builder: ntcore._ntcore.NTSendableBuilder) -> None:
        ...
    def setRange(self, range: ADXL345_I2C.Range) -> None:
        """
        Set the measuring range of the accelerometer.
        
        :param range: The maximum acceleration, positive or negative, that the
                      accelerometer will measure.
        """
class ADXL345_SPI(ntcore._ntcore.NTSendable):
    """
    ADXL345 Accelerometer on SPI.
    
    This class allows access to an Analog Devices ADXL345 3-axis accelerometer
    via SPI. This class assumes the sensor is wired in 4-wire SPI mode.
    """
    class AllAxes:
        """
        Container type for accelerations from all axes.
        """
        def __init__(self) -> None:
            ...
        @property
        def XAxis(self) -> float:
            """
            Acceleration along the X axis in g-forces.
            """
        @XAxis.setter
        def XAxis(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def YAxis(self) -> float:
            """
            Acceleration along the Y axis in g-forces.
            """
        @YAxis.setter
        def YAxis(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def ZAxis(self) -> float:
            """
            Acceleration along the Z axis in g-forces.
            """
        @ZAxis.setter
        def ZAxis(self, arg0: typing.SupportsFloat) -> None:
            ...
    class Axes:
        """
        Accelerometer axes.
        
        Members:
        
          kAxis_X : X axis.
        
          kAxis_Y : Y axis.
        
          kAxis_Z : Z axis.
        """
        __members__: typing.ClassVar[dict[str, ADXL345_SPI.Axes]]  # value = {'kAxis_X': <Axes.kAxis_X: 0>, 'kAxis_Y': <Axes.kAxis_Y: 2>, 'kAxis_Z': <Axes.kAxis_Z: 4>}
        kAxis_X: typing.ClassVar[ADXL345_SPI.Axes]  # value = <Axes.kAxis_X: 0>
        kAxis_Y: typing.ClassVar[ADXL345_SPI.Axes]  # value = <Axes.kAxis_Y: 2>
        kAxis_Z: typing.ClassVar[ADXL345_SPI.Axes]  # value = <Axes.kAxis_Z: 4>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Range:
        """
        Accelerometer range.
        
        Members:
        
          kRange_2G : 2 Gs max.
        
          kRange_4G : 4 Gs max.
        
          kRange_8G : 8 Gs max.
        
          kRange_16G : 16 Gs max.
        """
        __members__: typing.ClassVar[dict[str, ADXL345_SPI.Range]]  # value = {'kRange_2G': <Range.kRange_2G: 0>, 'kRange_4G': <Range.kRange_4G: 1>, 'kRange_8G': <Range.kRange_8G: 2>, 'kRange_16G': <Range.kRange_16G: 3>}
        kRange_16G: typing.ClassVar[ADXL345_SPI.Range]  # value = <Range.kRange_16G: 3>
        kRange_2G: typing.ClassVar[ADXL345_SPI.Range]  # value = <Range.kRange_2G: 0>
        kRange_4G: typing.ClassVar[ADXL345_SPI.Range]  # value = <Range.kRange_4G: 1>
        kRange_8G: typing.ClassVar[ADXL345_SPI.Range]  # value = <Range.kRange_8G: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self, port: SPI.Port, range: ADXL345_SPI.Range = ...) -> None:
        """
        Constructor.
        
        :param port:  The SPI port the accelerometer is attached to
        :param range: The range (+ or -) that the accelerometer will measure
        """
    def getAcceleration(self, axis: ADXL345_SPI.Axes) -> float:
        """
        Get the acceleration of one axis in Gs.
        
        :param axis: The axis to read from.
        
        :returns: Acceleration of the ADXL345 in Gs.
        """
    def getAccelerations(self) -> ADXL345_SPI.AllAxes:
        """
        Get the acceleration of all axes in Gs.
        
        :returns: An object containing the acceleration measured on each axis of the
                  ADXL345 in Gs.
        """
    def getSpiPort(self) -> SPI.Port:
        ...
    def getX(self) -> float:
        """
        Returns the acceleration along the X axis in g-forces.
        
        :returns: The acceleration along the X axis in g-forces.
        """
    def getY(self) -> float:
        """
        Returns the acceleration along the Y axis in g-forces.
        
        :returns: The acceleration along the Y axis in g-forces.
        """
    def getZ(self) -> float:
        """
        Returns the acceleration along the Z axis in g-forces.
        
        :returns: The acceleration along the Z axis in g-forces.
        """
    def initSendable(self, builder: ntcore._ntcore.NTSendableBuilder) -> None:
        ...
    def setRange(self, range: ADXL345_SPI.Range) -> None:
        """
        Set the measuring range of the accelerometer.
        
        :param range: The maximum acceleration, positive or negative, that the
                      accelerometer will measure.
        """
class ADXL362(ntcore._ntcore.NTSendable):
    """
    ADXL362 SPI Accelerometer.
    
    This class allows access to an Analog Devices ADXL362 3-axis accelerometer.
    """
    class AllAxes:
        """
        Container type for accelerations from all axes.
        """
        def __init__(self) -> None:
            ...
        @property
        def XAxis(self) -> float:
            """
            Acceleration along the X axis in g-forces.
            """
        @XAxis.setter
        def XAxis(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def YAxis(self) -> float:
            """
            Acceleration along the Y axis in g-forces.
            """
        @YAxis.setter
        def YAxis(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def ZAxis(self) -> float:
            """
            Acceleration along the Z axis in g-forces.
            """
        @ZAxis.setter
        def ZAxis(self, arg0: typing.SupportsFloat) -> None:
            ...
    class Axes:
        """
        Accelerometer axes.
        
        Members:
        
          kAxis_X : X axis.
        
          kAxis_Y : Y axis.
        
          kAxis_Z : Z axis.
        """
        __members__: typing.ClassVar[dict[str, ADXL362.Axes]]  # value = {'kAxis_X': <Axes.kAxis_X: 0>, 'kAxis_Y': <Axes.kAxis_Y: 2>, 'kAxis_Z': <Axes.kAxis_Z: 4>}
        kAxis_X: typing.ClassVar[ADXL362.Axes]  # value = <Axes.kAxis_X: 0>
        kAxis_Y: typing.ClassVar[ADXL362.Axes]  # value = <Axes.kAxis_Y: 2>
        kAxis_Z: typing.ClassVar[ADXL362.Axes]  # value = <Axes.kAxis_Z: 4>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Range:
        """
        Accelerometer range.
        
        Members:
        
          kRange_2G : 2 Gs max.
        
          kRange_4G : 4 Gs max.
        
          kRange_8G : 8 Gs max.
        """
        __members__: typing.ClassVar[dict[str, ADXL362.Range]]  # value = {'kRange_2G': <Range.kRange_2G: 0>, 'kRange_4G': <Range.kRange_4G: 1>, 'kRange_8G': <Range.kRange_8G: 2>}
        kRange_2G: typing.ClassVar[ADXL362.Range]  # value = <Range.kRange_2G: 0>
        kRange_4G: typing.ClassVar[ADXL362.Range]  # value = <Range.kRange_4G: 1>
        kRange_8G: typing.ClassVar[ADXL362.Range]  # value = <Range.kRange_8G: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    @typing.overload
    def __init__(self, range: ADXL362.Range = ...) -> None:
        """
        Constructor.  Uses the onboard CS1.
        
        :param range: The range (+ or -) that the accelerometer will measure.
        """
    @typing.overload
    def __init__(self, port: SPI.Port, range: ADXL362.Range = ...) -> None:
        """
        Constructor.
        
        :param port:  The SPI port the accelerometer is attached to
        :param range: The range (+ or -) that the accelerometer will measure.
        """
    def getAcceleration(self, axis: ADXL362.Axes) -> float:
        """
        Get the acceleration of one axis in Gs.
        
        :param axis: The axis to read from.
        
        :returns: Acceleration of the ADXL362 in Gs.
        """
    def getAccelerations(self) -> ADXL362.AllAxes:
        """
        Get the acceleration of all axes in Gs.
        
        :returns: An object containing the acceleration measured on each axis of the
                  ADXL362 in Gs.
        """
    def getSpiPort(self) -> SPI.Port:
        ...
    def getX(self) -> float:
        """
        Returns the acceleration along the X axis in g-forces.
        
        :returns: The acceleration along the X axis in g-forces.
        """
    def getY(self) -> float:
        """
        Returns the acceleration along the Y axis in g-forces.
        
        :returns: The acceleration along the Y axis in g-forces.
        """
    def getZ(self) -> float:
        """
        Returns the acceleration along the Z axis in g-forces.
        
        :returns: The acceleration along the Z axis in g-forces.
        """
    def initSendable(self, builder: ntcore._ntcore.NTSendableBuilder) -> None:
        ...
    def setRange(self, range: ADXL362.Range) -> None:
        """
        Set the measuring range of the accelerometer.
        
        :param range: The maximum acceleration, positive or negative, that the
                      accelerometer will measure.
        """
class ADXRS450_Gyro(wpiutil._wpiutil.Sendable):
    """
    Use a rate gyro to return the robots heading relative to a starting position.
    
    The %Gyro class tracks the robots heading based on the starting position. As
    the robot rotates the new heading is computed by integrating the rate of
    rotation returned by the sensor. When the class is instantiated, it does a
    short calibration routine where it samples the gyro while at rest to
    determine the default offset. This is subtracted from each sample to
    determine the heading.
    
    This class is for the digital ADXRS450 gyro sensor that connects via SPI.
    Only one instance of an ADXRS %Gyro is supported.
    """
    @typing.overload
    def __init__(self) -> None:
        """
        %Gyro constructor on onboard CS0.
        """
    @typing.overload
    def __init__(self, port: SPI.Port) -> None:
        """
        %Gyro constructor on the specified SPI port.
        
        :param port: The SPI port the gyro is attached to.
        """
    def calibrate(self) -> None:
        """
        Calibrate the gyro by running for a number of samples and computing the
        center value. Then use the center value as the Accumulator center value for
        subsequent measurements.
        
        It's important to make sure that the robot is not moving while the
        centering calculations are in progress, this is typically done when the
        robot is first turned on while it's sitting at rest before the competition
        starts.
        """
    def getAngle(self) -> float:
        """
        Return the actual angle in degrees that the robot is currently facing.
        
        The angle is based on integration of the returned rate from the gyro.
        The angle is continuous, that is it will continue from 360->361 degrees.
        This allows algorithms that wouldn't want to see a discontinuity in the
        gyro output as it sweeps from 360 to 0 on the second time around.
        
        :returns: the current heading of the robot in degrees.
        """
    def getPort(self) -> int:
        """
        Get the SPI port number.
        
        :returns: The SPI port number.
        """
    def getRate(self) -> float:
        """
        Return the rate of rotation of the gyro
        
        The rate is based on the most recent reading of the gyro.
        
        :returns: the current rate in degrees per second
        """
    def getRotation2d(self) -> wpimath.geometry._geometry.Rotation2d:
        """
        Return the heading of the robot as a Rotation2d.
        
        The angle is continuous, that is it will continue from 360 to 361 degrees.
        This allows algorithms that wouldn't want to see a discontinuity in the
        gyro output as it sweeps past from 360 to 0 on the second time around.
        
        The angle is expected to increase as the gyro turns counterclockwise when
        looked at from the top. It needs to follow the NWU axis convention.
        
        :returns: the current heading of the robot as a Rotation2d. This heading is
                  based on integration of the returned rate from the gyro.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isConnected(self) -> bool:
        ...
    def reset(self) -> None:
        """
        Reset the gyro.
        
        Resets the gyro to a heading of zero. This can be used if there is
        significant drift in the gyro and it needs to be recalibrated after it has
        been running.
        """
class AddressableLED:
    """
    A class for driving addressable LEDs, such as WS2812B, WS2815, and NeoPixels.
    
    By default, the timing supports WS2812B and WS2815 LEDs, but is configurable
    using SetBitTiming()
    
    Some LEDs use a different color order than the default GRB. The color order
    is configurable using SetColorOrder().
    
    Only 1 LED driver is currently supported by the roboRIO. However,
    multiple LED strips can be connected in series and controlled from the
    single driver.
    """
    class ColorOrder:
        """
        Order that color data is sent over the wire.
        
        Members:
        
          kRGB : ///< RGB order
        
          kRBG : ///< RBG order
        
          kBGR : ///< BGR order
        
          kBRG : ///< BRG order
        
          kGBR : ///< GBR order
        
          kGRB : ///< GRB order. This is the default order.
        """
        __members__: typing.ClassVar[dict[str, AddressableLED.ColorOrder]]  # value = {'kRGB': <ColorOrder.kRGB: 0>, 'kRBG': <ColorOrder.kRBG: 1>, 'kBGR': <ColorOrder.kBGR: 2>, 'kBRG': <ColorOrder.kBRG: 3>, 'kGBR': <ColorOrder.kGBR: 4>, 'kGRB': <ColorOrder.kGRB: 5>}
        kBGR: typing.ClassVar[AddressableLED.ColorOrder]  # value = <ColorOrder.kBGR: 2>
        kBRG: typing.ClassVar[AddressableLED.ColorOrder]  # value = <ColorOrder.kBRG: 3>
        kGBR: typing.ClassVar[AddressableLED.ColorOrder]  # value = <ColorOrder.kGBR: 4>
        kGRB: typing.ClassVar[AddressableLED.ColorOrder]  # value = <ColorOrder.kGRB: 5>
        kRBG: typing.ClassVar[AddressableLED.ColorOrder]  # value = <ColorOrder.kRBG: 1>
        kRGB: typing.ClassVar[AddressableLED.ColorOrder]  # value = <ColorOrder.kRGB: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class LEDData:
        __hash__: typing.ClassVar[None] = None
        def __eq__(self, arg0: AddressableLED.LEDData) -> bool:
            ...
        @typing.overload
        def __init__(self) -> None:
            ...
        @typing.overload
        def __init__(self, r: typing.SupportsInt, g: typing.SupportsInt, b: typing.SupportsInt) -> None:
            ...
        def setHSV(self, h: typing.SupportsInt, s: typing.SupportsInt, v: typing.SupportsInt) -> None:
            """
            A helper method to set all values of the LED.
            
            :param h: the h value [0-180]
            :param s: the s value [0-255]
            :param v: the v value [0-255]
            """
        @typing.overload
        def setLED(self, color: Color) -> None:
            ...
        @typing.overload
        def setLED(self, color: Color8Bit) -> None:
            ...
        def setRGB(self, r: typing.SupportsInt, g: typing.SupportsInt, b: typing.SupportsInt) -> None:
            """
            A helper method to set all values of the LED.
            
            :param r: the r value [0-255]
            :param g: the g value [0-255]
            :param b: the b value [0-255]
            """
        @property
        def b(self) -> int:
            ...
        @b.setter
        def b(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def g(self) -> int:
            ...
        @g.setter
        def g(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def r(self) -> int:
            ...
        @r.setter
        def r(self, arg0: typing.SupportsInt) -> None:
            ...
    def __init__(self, port: typing.SupportsInt) -> None:
        """
        Constructs a new driver for a specific port.
        
        :param port: the output port to use (Must be a PWM header)
        """
    def setBitTiming(self, highTime0: wpimath.units.nanoseconds, lowTime0: wpimath.units.nanoseconds, highTime1: wpimath.units.nanoseconds, lowTime1: wpimath.units.nanoseconds) -> None:
        """
        Sets the bit timing.
        
        By default, the driver is set up to drive WS2812B and WS2815, so nothing
        needs to be set for those.
        
        :param highTime0: high time for 0 bit (default 400ns)
        :param lowTime0:  low time for 0 bit (default 900ns)
        :param highTime1: high time for 1 bit (default 900ns)
        :param lowTime1:  low time for 1 bit (default 600ns)
        """
    def setColorOrder(self, order: AddressableLED.ColorOrder) -> None:
        """
        Sets the color order for this AddressableLED. The default order is GRB.
        
        This will take effect on the next call to SetData().
        
        :param order: the color order
        """
    def setData(self, ledData: list[AddressableLED.LEDData]) -> None:
        """
        Sets the led output data.
        
        If the output is enabled, this will start writing the next data cycle.
        It is safe to call, even while output is enabled.
        
        :param ledData: the buffer to write
        """
    def setLength(self, length: typing.SupportsInt) -> None:
        """
        Sets the length of the LED strip.
        
        Calling this is an expensive call, so its best to call it once, then
        just update data.
        
        The max length is 5460 LEDs.
        
        :param length: the strip length
        """
    def setSyncTime(self, syncTime: wpimath.units.microseconds) -> None:
        """
        Sets the sync time.
        
        The sync time is the time to hold output so LEDs enable. Default set for
        WS2812B and WS2815.
        
        :param syncTime: the sync time (default 280us)
        """
    def start(self) -> None:
        """
        Starts the output.
        
        The output writes continuously.
        """
    def stop(self) -> None:
        """
        Stops the output.
        """
class Alert:
    """
    Persistent alert to be sent via NetworkTables. Alerts are tagged with a type
    of kError, kWarning, or kInfo to denote urgency. See Alert::AlertType for
    suggested usage of each type. Alerts can be displayed on supported
    dashboards, and are shown in a priority order based on type and recency of
    activation, with newly activated alerts first.
    
    Alerts should be created once and stored persistently, then updated to
    "active" or "inactive" as necessary. Set(bool) can be safely called
    periodically.
    
    This API is new for 2025, but is likely to change in future seasons to
    facilitate deeper integration with the robot control system.
    
    ::
    
      class Robot {
        frc::Alert alert{"Something went wrong", frc::Alert::AlertType::kWarning};
      }
      
      Robot::periodic() {
        alert.Set(...);
      }
    """
    class AlertType:
        """
        Represents an alert's level of urgency.
        
        Members:
        
          kError : High priority alert - displayed first on the dashboard with a red "X"
        symbol. Use this type for problems which will seriously affect the
        robot's functionality and thus require immediate attention.
        
          kWarning : Medium priority alert - displayed second on the dashboard with a yellow
        "!" symbol. Use this type for problems which could affect the robot's
        functionality but do not necessarily require immediate attention.
        
          kInfo : Low priority alert - displayed last on the dashboard with a green "i"
        symbol. Use this type for problems which are unlikely to affect the
        robot's functionality, or any other alerts which do not fall under the
        other categories.
        """
        __members__: typing.ClassVar[dict[str, Alert.AlertType]]  # value = {'kError': <AlertType.kError: 0>, 'kWarning': <AlertType.kWarning: 1>, 'kInfo': <AlertType.kInfo: 2>}
        kError: typing.ClassVar[Alert.AlertType]  # value = <AlertType.kError: 0>
        kInfo: typing.ClassVar[Alert.AlertType]  # value = <AlertType.kInfo: 2>
        kWarning: typing.ClassVar[Alert.AlertType]  # value = <AlertType.kWarning: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __enter__(self) -> Alert:
        ...
    def __exit__(self, *args) -> None:
        ...
    @typing.overload
    def __init__(self, text: str, type: Alert.AlertType) -> None:
        """
        Creates a new alert in the default group - "Alerts". If this is the first
        to be instantiated, the appropriate entries will be added to NetworkTables.
        
        :param text: Text to be displayed when the alert is active.
        :param type: Alert urgency level.
        """
    @typing.overload
    def __init__(self, group: str, text: str, type: Alert.AlertType) -> None:
        """
        Creates a new alert. If this is the first to be instantiated in its group,
        the appropriate entries will be added to NetworkTables.
        
        :param group: Group identifier, used as the entry name in NetworkTables.
        :param text:  Text to be displayed when the alert is active.
        :param type:  Alert urgency level.
        """
    def close(self) -> None:
        """
        Disables the alert
        """
    def get(self) -> bool:
        """
        Gets whether the alert is active.
        
        :returns: whether the alert is active.
        """
    def getText(self) -> str:
        """
        Gets the current alert text.
        
        :returns: the current text.
        """
    def getType(self) -> Alert.AlertType:
        """
        Get the type of this alert.
        
        :returns: the type
        """
    def set(self, active: bool) -> None:
        """
        Sets whether the alert should currently be displayed. This method can be
        safely called periodically.
        
        :param active: Whether to display the alert.
        """
    def setText(self, text: str) -> None:
        """
        Updates current alert text. Use this method to dynamically change the
        displayed alert, such as including more details about the detected problem.
        
        :param text: Text to be displayed when the alert is active.
        """
class AnalogAccelerometer(wpiutil._wpiutil.Sendable):
    """
    Handle operation of an analog accelerometer.
    
    The accelerometer reads acceleration directly through the sensor. Many
    sensors have multiple axis and can be treated as multiple devices. Each is
    calibrated by finding the center value over a period of time.
    """
    @typing.overload
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Create a new instance of an accelerometer.
        
        The constructor allocates desired analog input.
        
        :param channel: The channel number for the analog input the accelerometer is
                        connected to
        """
    @typing.overload
    def __init__(self, channel: AnalogInput) -> None:
        """
        Create a new instance of Accelerometer from an existing AnalogInput.
        
        Make a new instance of accelerometer given an AnalogInput. This is
        particularly useful if the port is going to be read as an analog channel as
        well as through the Accelerometer class.
        
        :param channel: The existing AnalogInput object for the analog input the
                        accelerometer is connected to
        """
    def getAcceleration(self) -> float:
        """
        Return the acceleration in Gs.
        
        The acceleration is returned units of Gs.
        
        :returns: The current acceleration of the sensor in Gs.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def setSensitivity(self, sensitivity: typing.SupportsFloat) -> None:
        """
        Set the accelerometer sensitivity.
        
        This sets the sensitivity of the accelerometer used for calculating the
        acceleration. The sensitivity varies by accelerometer model.
        
        :param sensitivity: The sensitivity of accelerometer in Volts per G.
        """
    def setZero(self, zero: typing.SupportsFloat) -> None:
        """
        Set the voltage that corresponds to 0 G.
        
        The zero G voltage varies by accelerometer model.
        
        :param zero: The zero G voltage.
        """
class AnalogEncoder(wpiutil._wpiutil.Sendable):
    """
    Class for supporting continuous analog encoders, such as the US Digital MA3.
    """
    @typing.overload
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Construct a new AnalogEncoder attached to a specific AnalogIn channel.
        
        This has a fullRange of 1 and an expectedZero of 0.
        
        :param channel: the analog input channel to attach to
        """
    @typing.overload
    def __init__(self, analogInput: AnalogInput) -> None:
        """
        Construct a new AnalogEncoder attached to a specific AnalogInput.
        
        This has a fullRange of 1 and an expectedZero of 0.
        
        :param analogInput: the analog input to attach to
        """
    @typing.overload
    def __init__(self, channel: typing.SupportsInt, fullRange: typing.SupportsFloat, expectedZero: typing.SupportsFloat) -> None:
        """
        Construct a new AnalogEncoder attached to a specific AnalogIn channel.
        
        :param channel:      the analog input channel to attach to
        :param fullRange:    the value to report at maximum travel
        :param expectedZero: the reading where you would expect a 0 from get()
        """
    @typing.overload
    def __init__(self, analogInput: AnalogInput, fullRange: typing.SupportsFloat, expectedZero: typing.SupportsFloat) -> None:
        """
        Construct a new AnalogEncoder attached to a specific AnalogInput.
        
        :param analogInput:  the analog input to attach to
        :param fullRange:    the value to report at maximum travel
        :param expectedZero: the reading where you would expect a 0 from get()
        """
    def get(self) -> float:
        """
        Get the encoder value.
        
        :returns: the encoder value scaled by the full range input
        """
    def getChannel(self) -> int:
        """
        Get the channel number.
        
        :returns: The channel number.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def setInverted(self, inverted: bool) -> None:
        """
        Set if this encoder is inverted.
        
        :param inverted: true to invert the encoder, false otherwise
        """
    def setVoltagePercentageRange(self, min: typing.SupportsFloat, max: typing.SupportsFloat) -> None:
        """
        Set the encoder voltage percentage range. Analog sensors are not always
        fully stable at the end of their travel ranges. Shrinking this range down
        can help mitigate issues with that.
        
        :param min: minimum voltage percentage (0-1 range)
        :param max: maximum voltage percentage (0-1 range)
        """
class AnalogGyro(wpiutil._wpiutil.Sendable):
    """
    Use a rate gyro to return the robots heading relative to a starting position.
    The Gyro class tracks the robots heading based on the starting position. As
    the robot rotates the new heading is computed by integrating the rate of
    rotation returned by the sensor. When the class is instantiated, it does a
    short calibration routine where it samples the gyro while at rest to
    determine the default offset. This is subtracted from each sample to
    determine the heading. This gyro class must be used with a channel that is
    assigned one of the Analog accumulators from the FPGA. See AnalogInput for
    the current accumulator assignments.
    
    This class is for gyro sensors that connect to an analog input.
    """
    kAverageBits: typing.ClassVar[int] = 0
    kCalibrationSampleTime: typing.ClassVar[float] = 5.0
    kDefaultVoltsPerDegreePerSecond: typing.ClassVar[float] = 0.007
    kOversampleBits: typing.ClassVar[int] = 10
    kSamplesPerSecond: typing.ClassVar[float] = 50.0
    @typing.overload
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        %Gyro constructor using the Analog Input channel number.
        
        :param channel: The analog channel the gyro is connected to. Gyros can only
                        be used on on-board Analog Inputs 0-1.
        """
    @typing.overload
    def __init__(self, channel: AnalogInput) -> None:
        """
        %Gyro constructor with a precreated AnalogInput object.
        
        Use this constructor when the analog channel needs to be shared.
        This object will not clean up the AnalogInput object when using this
        constructor.
        
        :param channel: A pointer to the AnalogInput object that the gyro is
                        connected to.
        """
    @typing.overload
    def __init__(self, channel: typing.SupportsInt, center: typing.SupportsInt, offset: typing.SupportsFloat) -> None:
        """
        %Gyro constructor using the Analog Input channel number with parameters for
        presetting the center and offset values. Bypasses calibration.
        
        :param channel: The analog channel the gyro is connected to. Gyros can only
                        be used on on-board Analog Inputs 0-1.
        :param center:  Preset uncalibrated value to use as the accumulator center
                        value.
        :param offset:  Preset uncalibrated value to use as the gyro offset.
        """
    @typing.overload
    def __init__(self, channel: AnalogInput, center: typing.SupportsInt, offset: typing.SupportsFloat) -> None:
        """
        %Gyro constructor with a precreated AnalogInput object and calibrated
        parameters.
        
        Use this constructor when the analog channel needs to be shared.
        This object will not clean up the AnalogInput object when using this
        constructor.
        
        :param channel: A pointer to the AnalogInput object that the gyro is
                        connected to.
        :param center:  Preset uncalibrated value to use as the accumulator center
                        value.
        :param offset:  Preset uncalibrated value to use as the gyro offset.
        """
    def calibrate(self) -> None:
        """
        Calibrate the gyro by running for a number of samples and computing the
        center value. Then use the center value as the Accumulator center value for
        subsequent measurements.
        
        It's important to make sure that the robot is not moving while the
        centering calculations are in progress, this is typically done when the
        robot is first turned on while it's sitting at rest before the competition
        starts.
        """
    def getAnalogInput(self) -> AnalogInput:
        """
        Gets the analog input for the gyro.
        
        :returns: AnalogInput
        """
    def getAngle(self) -> float:
        """
        Return the actual angle in degrees that the robot is currently facing.
        
        The angle is based on the current accumulator value corrected by the
        oversampling rate, the gyro type and the A/D calibration values. The angle
        is continuous, that is it will continue from 360->361 degrees. This allows
        algorithms that wouldn't want to see a discontinuity in the gyro output as
        it sweeps from 360 to 0 on the second time around.
        
        :returns: The current heading of the robot in degrees. This heading is based
                  on integration of the returned rate from the gyro.
        """
    def getCenter(self) -> int:
        """
        Return the gyro center value. If run after calibration,
        the center value can be used as a preset later.
        
        :returns: the current center value
        """
    def getOffset(self) -> float:
        """
        Return the gyro offset value. If run after calibration,
        the offset value can be used as a preset later.
        
        :returns: the current offset value
        """
    def getRate(self) -> float:
        """
        Return the rate of rotation of the gyro
        
        The rate is based on the most recent reading of the gyro analog value
        
        :returns: the current rate in degrees per second
        """
    def getRotation2d(self) -> wpimath.geometry._geometry.Rotation2d:
        """
        Return the heading of the robot as a Rotation2d.
        
        The angle is continuous, that is it will continue from 360 to 361 degrees.
        This allows algorithms that wouldn't want to see a discontinuity in the
        gyro output as it sweeps past from 360 to 0 on the second time around.
        
        The angle is expected to increase as the gyro turns counterclockwise when
        looked at from the top. It needs to follow the NWU axis convention.
        
        :returns: the current heading of the robot as a Rotation2d. This heading is
                  based on integration of the returned rate from the gyro.
        """
    def initGyro(self) -> None:
        """
        Initialize the gyro.
        
        Calibration is handled by Calibrate().
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def reset(self) -> None:
        """
        Reset the gyro.
        
        Resets the gyro to a heading of zero. This can be used if there is
        significant drift in the gyro and it needs to be recalibrated after it has
        been running.
        """
    def setDeadband(self, volts: typing.SupportsFloat) -> None:
        """
        Set the size of the neutral zone.
        
        Any voltage from the gyro less than this amount from the center is
        considered stationary.  Setting a deadband will decrease the amount of
        drift when the gyro isn't rotating, but will make it less accurate.
        
        :param volts: The size of the deadband in volts
        """
    def setSensitivity(self, voltsPerDegreePerSecond: typing.SupportsFloat) -> None:
        """
        Set the gyro sensitivity.
        
        This takes the number of volts/degree/second sensitivity of the gyro and
        uses it in subsequent calculations to allow the code to work with multiple
        gyros. This value is typically found in the gyro datasheet.
        
        :param voltsPerDegreePerSecond: The sensitivity in Volts/degree/second
        """
class AnalogInput(wpiutil._wpiutil.Sendable):
    """
    Analog input class.
    
    Connected to each analog channel is an averaging and oversampling engine.
    This engine accumulates the specified ( by SetAverageBits() and
    SetOversampleBits() ) number of samples before returning a new value. This is
    not a sliding window average. The only difference between the oversampled
    samples and the averaged samples is that the oversampled samples are simply
    accumulated effectively increasing the resolution, while the averaged samples
    are divided by the number of samples to retain the resolution, but get more
    stable values.
    """
    kAccumulatorModuleNumber: typing.ClassVar[int] = 1
    kAccumulatorNumChannels: typing.ClassVar[int] = 2
    @staticmethod
    def getSampleRate() -> float:
        """
        Get the current sample rate for all channels
        
        :returns: Sample rate.
        """
    @staticmethod
    def setSampleRate(samplesPerSecond: typing.SupportsFloat) -> None:
        """
        Set the sample rate per channel for all analog channels.
        
        The maximum rate is 500kS/s divided by the number of channels in use.
        This is 62500 samples/s per channel.
        
        :param samplesPerSecond: The number of samples per second.
        """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Construct an analog input.
        
        :param channel: The channel number on the roboRIO to represent. 0-3 are
                        on-board 4-7 are on the MXP port.
        """
    def __repr__(self) -> str:
        ...
    def getAccumulatorCount(self) -> int:
        """
        Read the number of accumulated values.
        
        Read the count of the accumulated values since the accumulator was last
        Reset().
        
        :returns: The number of times samples from the channel were accumulated.
        """
    def getAccumulatorOutput(self) -> tuple[int, int]:
        """
        Read the accumulated value and the number of accumulated values atomically.
        
        This function reads the value and count from the FPGA atomically.
        This can be used for averaging.
        
        :param value: Reference to the 64-bit accumulated output.
        :param count: Reference to the number of accumulation cycles.
        """
    def getAccumulatorValue(self) -> int:
        """
        Read the accumulated value.
        
        Read the value that has been accumulating.
        The accumulator is attached after the oversample and average engine.
        
        :returns: The 64-bit value accumulated since the last Reset().
        """
    def getAverageBits(self) -> int:
        """
        Get the number of averaging bits previously configured.
        
        This gets the number of averaging bits from the FPGA. The actual number of
        averaged samples is 2^bits. The averaging is done automatically in the
        FPGA.
        
        :returns: Number of bits of averaging previously configured.
        """
    def getAverageValue(self) -> int:
        """
        Get a sample from the output of the oversample and average engine for this
        channel.
        
        The sample is 12-bit + the bits configured in SetOversampleBits().
        The value configured in SetAverageBits() will cause this value to be
        averaged 2**bits number of samples.
        
        This is not a sliding window. The sample will not change until
        2**(OversampleBits + AverageBits) samples have been acquired from the
        module on this channel.
        
        Use GetAverageVoltage() to get the analog value in calibrated units.
        
        :returns: A sample from the oversample and average engine for this channel.
        """
    def getAverageVoltage(self) -> float:
        """
        Get a scaled sample from the output of the oversample and average engine
        for this channel.
        
        The value is scaled to units of Volts using the calibrated scaling data
        from GetLSBWeight() and GetOffset().
        
        Using oversampling will cause this value to be higher resolution, but it
        will update more slowly.
        
        Using averaging will cause this value to be more stable, but it will update
        more slowly.
        
        :returns: A scaled sample from the output of the oversample and average
                  engine for this channel.
        """
    def getChannel(self) -> int:
        """
        Get the channel number.
        
        :returns: The channel number.
        """
    def getLSBWeight(self) -> int:
        """
        Get the factory scaling least significant bit weight constant.
        
        Volts = ((LSB_Weight * 1e-9) * raw) - (Offset * 1e-9)
        
        :returns: Least significant bit weight.
        """
    def getOffset(self) -> int:
        """
        Get the factory scaling offset constant.
        
        Volts = ((LSB_Weight * 1e-9) * raw) - (Offset * 1e-9)
        
        :returns: Offset constant.
        """
    def getOversampleBits(self) -> int:
        """
        Get the number of oversample bits previously configured.
        
        This gets the number of oversample bits from the FPGA. The actual number of
        oversampled values is 2^bits. The oversampling is done automatically in the
        FPGA.
        
        :returns: Number of bits of oversampling previously configured.
        """
    def getValue(self) -> int:
        """
        Get a sample straight from this channel.
        
        The sample is a 12-bit value representing the 0V to 5V range of the A/D
        converter in the module.  The units are in A/D converter codes.  Use
        GetVoltage() to get the analog value in calibrated units.
        
        :returns: A sample straight from this channel.
        """
    def getVoltage(self) -> float:
        """
        Get a scaled sample straight from this channel.
        
        The value is scaled to units of Volts using the calibrated scaling data
        from GetLSBWeight() and GetOffset().
        
        :returns: A scaled sample straight from this channel.
        """
    def initAccumulator(self) -> None:
        """
        Initialize the accumulator.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isAccumulatorChannel(self) -> bool:
        """
        Is the channel attached to an accumulator.
        
        :returns: The analog input is attached to an accumulator.
        """
    def resetAccumulator(self) -> None:
        """
        Resets the accumulator to the initial value.
        """
    def setAccumulatorCenter(self, center: typing.SupportsInt) -> None:
        """
        Set the center value of the accumulator.
        
        The center value is subtracted from each A/D value before it is added to
        the accumulator. This is used for the center value of devices like gyros
        and accelerometers to take the device offset into account when integrating.
        
        This center value is based on the output of the oversampled and averaged
        source from the accumulator channel. Because of this, any non-zero
        oversample bits will affect the size of the value for this field.
        """
    def setAccumulatorDeadband(self, deadband: typing.SupportsInt) -> None:
        """
        Set the accumulator's deadband.
        """
    def setAccumulatorInitialValue(self, value: typing.SupportsInt) -> None:
        """
        Set an initial value for the accumulator.
        
        This will be added to all values returned to the user.
        
        :param value: The value that the accumulator should start from when reset.
        """
    def setAverageBits(self, bits: typing.SupportsInt) -> None:
        """
        Set the number of averaging bits.
        
        This sets the number of averaging bits. The actual number of averaged
        samples is 2^bits.
        
        Use averaging to improve the stability of your measurement at the expense
        of sampling rate. The averaging is done automatically in the FPGA.
        
        :param bits: Number of bits of averaging.
        """
    def setOversampleBits(self, bits: typing.SupportsInt) -> None:
        """
        Set the number of oversample bits.
        
        This sets the number of oversample bits. The actual number of oversampled
        values is 2^bits. Use oversampling to improve the resolution of your
        measurements at the expense of sampling rate. The oversampling is done
        automatically in the FPGA.
        
        :param bits: Number of bits of oversampling.
        """
    def setSimDevice(self, device: typing.SupportsInt) -> None:
        """
        Indicates this input is used by a simulated device.
        
        :param device: simulated device handle
        """
class AnalogOutput(wpiutil._wpiutil.Sendable):
    """
    MXP analog output class.
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Construct an analog output on the given channel.
        
        All analog outputs are located on the MXP port.
        
        :param channel: The channel number on the roboRIO to represent.
        """
    def __repr__(self) -> str:
        ...
    def getChannel(self) -> int:
        """
        Get the channel of this AnalogOutput.
        """
    def getVoltage(self) -> float:
        """
        Get the voltage of the analog output.
        
        :returns: The value in Volts, from 0.0 to +5.0.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def setVoltage(self, voltage: typing.SupportsFloat) -> None:
        """
        Set the value of the analog output.
        
        :param voltage: The output value in Volts, from 0.0 to +5.0.
        """
    @property
    def _m_channel(self) -> int:
        ...
    @_m_channel.setter
    def _m_channel(self, arg0: typing.SupportsInt) -> None:
        ...
class AnalogPotentiometer(wpiutil._wpiutil.Sendable):
    """
    Class for reading analog potentiometers. Analog potentiometers read in an
    analog voltage that corresponds to a position. The position is in whichever
    units you choose, by way of the scaling and offset constants passed to the
    constructor.
    """
    @typing.overload
    def __init__(self, channel: typing.SupportsInt, fullRange: typing.SupportsFloat = 1.0, offset: typing.SupportsFloat = 0.0) -> None:
        """
        Construct an Analog Potentiometer object from a channel number.
        
        Use the fullRange and offset values so that the output produces meaningful
        values. I.E: you have a 270 degree potentiometer and you want the output to
        be degrees with the halfway point as 0 degrees. The fullRange value is
        270.0 degrees and the offset is -135.0 since the halfway point after
        scaling is 135 degrees.
        
        This will calculate the result from the fullRange times the fraction of the
        supply voltage, plus the offset.
        
        :param channel:   The Analog Input channel number on the roboRIO the
                          potentiometer is plugged into. 0-3 are on-board and 4-7
                          are on the MXP port.
        :param fullRange: The value (in desired units) representing the full
                          0-5V range of the input.
        :param offset:    The value (in desired units) representing the
                          angular output at 0V.
        """
    @typing.overload
    def __init__(self, input: AnalogInput, fullRange: typing.SupportsFloat = 1.0, offset: typing.SupportsFloat = 0.0) -> None:
        """
        Construct an Analog Potentiometer object from an existing Analog Input
        pointer.
        
        Use the fullRange and offset values so that the output produces meaningful
        values. I.E: you have a 270 degree potentiometer and you want the output to
        be degrees with the halfway point as 0 degrees. The fullRange value is
        270.0 degrees and the offset is -135.0 since the halfway point after
        scaling is 135 degrees.
        
        This will calculate the result from the fullRange times the fraction of the
        supply voltage, plus the offset.
        
        :param input:     The existing Analog Input pointer
        :param fullRange: The value (in desired units) representing the full
                          0-5V range of the input.
        :param offset:    The value (in desired units) representing the
                          angular output at 0V.
        """
    def get(self) -> float:
        """
        Get the current reading of the potentiometer.
        
        :returns: The current position of the potentiometer (in the units used for
                  fullRange and offset).
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
class AnalogTrigger(wpiutil._wpiutil.Sendable):
    @typing.overload
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for an analog trigger given a channel number.
        
        :param channel: The channel number on the roboRIO to represent. 0-3 are
                        on-board 4-7 are on the MXP port.
        """
    @typing.overload
    def __init__(self, input: AnalogInput) -> None:
        """
        Construct an analog trigger using an existing analog input.
        
        This should be used in the case of sharing an analog channel between the
        trigger and an analog input object.
        
        :param input: A shared_ptr to the existing AnalogInput object
        """
    @typing.overload
    def __init__(self, dutyCycle: DutyCycle) -> None:
        """
        Construct an analog trigger using an existing duty cycle input.
        
        :param dutyCycle: A shared_ptr to the existing DutyCycle object
        """
    def createOutput(self, type: AnalogTriggerType) -> AnalogTriggerOutput:
        """
        Creates an AnalogTriggerOutput object.
        
        :param type: An enum of the type of output object to create.
        
        :returns: A pointer to a new AnalogTriggerOutput object.
        """
    def getInWindow(self) -> bool:
        """
        Return the InWindow output of the analog trigger.
        
        True if the analog input is between the upper and lower limits.
        
        :returns: True if the analog input is between the upper and lower limits.
        """
    def getIndex(self) -> int:
        """
        Return the index of the analog trigger.
        
        This is the FPGA index of this analog trigger instance.
        
        :returns: The index of the analog trigger.
        """
    def getTriggerState(self) -> bool:
        """
        Return the TriggerState output of the analog trigger.
        
        True if above upper limit.
        False if below lower limit.
        If in Hysteresis, maintain previous state.
        
        :returns: True if above upper limit. False if below lower limit. If in
                  Hysteresis, maintain previous state.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def setAveraged(self, useAveragedValue: bool) -> None:
        """
        Configure the analog trigger to use the averaged vs. raw values.
        
        If the value is true, then the averaged value is selected for the analog
        trigger, otherwise the immediate value is used.
        
        :param useAveragedValue: If true, use the Averaged value, otherwise use the
                                 instantaneous reading
        """
    def setFiltered(self, useFilteredValue: bool) -> None:
        """
        Configure the analog trigger to use a filtered value.
        
        The analog trigger will operate with a 3 point average rejection filter.
        This is designed to help with 360 degree pot applications for the period
        where the pot crosses through zero.
        
        :param useFilteredValue: If true, use the 3 point rejection filter,
                                 otherwise use the unfiltered value
        """
    def setLimitsDutyCycle(self, lower: typing.SupportsFloat, upper: typing.SupportsFloat) -> None:
        """
        Set the upper and lower duty cycle limits of the analog trigger.
        
        The limits are given as floating point values between 0 and 1.
        
        :param lower: The lower limit of the trigger in percentage.
        :param upper: The upper limit of the trigger in percentage.
        """
    def setLimitsRaw(self, lower: typing.SupportsInt, upper: typing.SupportsInt) -> None:
        """
        Set the upper and lower limits of the analog trigger.
        
        The limits are given in ADC codes.  If oversampling is used, the units must
        be scaled appropriately.
        
        :param lower: The lower limit of the trigger in ADC codes (12-bit values).
        :param upper: The upper limit of the trigger in ADC codes (12-bit values).
        """
    def setLimitsVoltage(self, lower: typing.SupportsFloat, upper: typing.SupportsFloat) -> None:
        """
        Set the upper and lower limits of the analog trigger.
        
        The limits are given as floating point voltage values.
        
        :param lower: The lower limit of the trigger in Volts.
        :param upper: The upper limit of the trigger in Volts.
        """
class AnalogTriggerOutput(DigitalSource, wpiutil._wpiutil.Sendable):
    """
    Class to represent a specific output from an analog trigger.
    
    This class is used to get the current output value and also as a
    DigitalSource to provide routing of an output to digital subsystems on the
    FPGA such as Counter, Encoder, and Interrupt.
    
    The TriggerState output indicates the primary output value of the trigger.
    If the analog signal is less than the lower limit, the output is false. If
    the analog value is greater than the upper limit, then the output is true.
    If the analog value is in between, then the trigger output state maintains
    its most recent value.
    
    The InWindow output indicates whether or not the analog signal is inside the
    range defined by the limits.
    
    The RisingPulse and FallingPulse outputs detect an instantaneous transition
    from above the upper limit to below the lower limit, and vice versa. These
    pulses represent a rollover condition of a sensor and can be routed to an up
    / down counter or to interrupts. Because the outputs generate a pulse, they
    cannot be read directly. To help ensure that a rollover condition is not
    missed, there is an average rejection filter available that operates on the
    upper 8 bits of a 12 bit number and selects the nearest outlier of 3 samples.
    This will reject a sample that is (due to averaging or sampling) errantly
    between the two limits. This filter will fail if more than one sample in a
    row is errantly in between the two limits. You may see this problem if
    attempting to use this feature with a mechanical rollover sensor, such as a
    360 degree no-stop potentiometer without signal conditioning, because the
    rollover transition is not sharp / clean enough. Using the averaging engine
    may help with this, but rotational speeds of the sensor will then be limited.
    """
    def __init__(self, trigger: AnalogTrigger, outputType: AnalogTriggerType) -> None:
        """
        Create an object that represents one of the four outputs from an analog
        trigger.
        
        Because this class derives from DigitalSource, it can be passed into
        routing functions for Counter, Encoder, etc.
        
        :param trigger:    A pointer to the trigger for which this is an output.
        :param outputType: An enum that specifies the output on the trigger to
                           represent.
        """
    def get(self) -> bool:
        """
        Get the state of the analog trigger output.
        
        :returns: The state of the analog trigger output.
        """
    def getAnalogTriggerTypeForRouting(self) -> AnalogTriggerType:
        """
        :returns: The type of analog trigger output to be used.
        """
    def getChannel(self) -> int:
        """
        :returns: The channel of the source.
        """
    def getPortHandleForRouting(self) -> int:
        """
        :returns: The HAL Handle to the specified source.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isAnalogTrigger(self) -> bool:
        """
        Is source an AnalogTrigger
        """
class AnalogTriggerType:
    """
    Defines the state in which the AnalogTrigger triggers.
    
    Members:
    
      kInWindow : In window.
    
      kState : State.
    
      kRisingPulse : Rising Pulse.
    
      kFallingPulse : Falling pulse.
    """
    __members__: typing.ClassVar[dict[str, AnalogTriggerType]]  # value = {'kInWindow': <AnalogTriggerType.kInWindow: 0>, 'kState': <AnalogTriggerType.kState: 1>, 'kRisingPulse': <AnalogTriggerType.kRisingPulse: 2>, 'kFallingPulse': <AnalogTriggerType.kFallingPulse: 3>}
    kFallingPulse: typing.ClassVar[AnalogTriggerType]  # value = <AnalogTriggerType.kFallingPulse: 3>
    kInWindow: typing.ClassVar[AnalogTriggerType]  # value = <AnalogTriggerType.kInWindow: 0>
    kRisingPulse: typing.ClassVar[AnalogTriggerType]  # value = <AnalogTriggerType.kRisingPulse: 2>
    kState: typing.ClassVar[AnalogTriggerType]  # value = <AnalogTriggerType.kState: 1>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class BuiltInAccelerometer(wpiutil._wpiutil.Sendable):
    """
    Built-in accelerometer.
    
    This class allows access to the roboRIO's internal accelerometer.
    """
    class Range:
        """
        Accelerometer range.
        
        Members:
        
          kRange_2G : 2 Gs max.
        
          kRange_4G : 4 Gs max.
        
          kRange_8G : 8 Gs max.
        """
        __members__: typing.ClassVar[dict[str, BuiltInAccelerometer.Range]]  # value = {'kRange_2G': <Range.kRange_2G: 0>, 'kRange_4G': <Range.kRange_4G: 1>, 'kRange_8G': <Range.kRange_8G: 2>}
        kRange_2G: typing.ClassVar[BuiltInAccelerometer.Range]  # value = <Range.kRange_2G: 0>
        kRange_4G: typing.ClassVar[BuiltInAccelerometer.Range]  # value = <Range.kRange_4G: 1>
        kRange_8G: typing.ClassVar[BuiltInAccelerometer.Range]  # value = <Range.kRange_8G: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self, range: BuiltInAccelerometer.Range = ...) -> None:
        """
        Constructor.
        
        :param range: The range the accelerometer will measure
        """
    def getX(self) -> float:
        """
        :returns: The acceleration of the roboRIO along the X axis in g-forces
        """
    def getY(self) -> float:
        """
        :returns: The acceleration of the roboRIO along the Y axis in g-forces
        """
    def getZ(self) -> float:
        """
        :returns: The acceleration of the roboRIO along the Z axis in g-forces
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def setRange(self, range: BuiltInAccelerometer.Range) -> None:
        """
        Set the measuring range of the accelerometer.
        
        :param range: The maximum acceleration, positive or negative, that the
                      accelerometer will measure.
        """
class CAN:
    """
    High level class for interfacing with CAN devices conforming to
    the standard CAN spec.
    
    No packets that can be sent gets blocked by the RoboRIO, so all methods
    work identically in all robot modes.
    
    All methods are thread save, however the buffer objects passed in
    by the user need to not be modified for the duration of their calls.
    """
    kTeamDeviceType: typing.ClassVar[hal._wpiHal.CANDeviceType]  # value = <CANDeviceType.kMiscellaneous: 10>
    kTeamManufacturer: typing.ClassVar[hal._wpiHal.CANManufacturer]  # value = <CANManufacturer.kTeamUse: 8>
    @staticmethod
    def getTimestampBaseTime() -> int:
        """
        Reads the current value of the millisecond-resolution timer that CANData
        timestamps are based on
        
        :returns: Current value of timer used as a base time for CANData timestamps
                  in milliseconds
        """
    @typing.overload
    def __init__(self, deviceId: typing.SupportsInt) -> None:
        """
        Create a new CAN communication interface with the specific device ID.
        This uses the team manufacturer and device types.
        The device ID is 6 bits (0-63)
        
        :param deviceId: The device id
        """
    @typing.overload
    def __init__(self, deviceId: typing.SupportsInt, deviceManufacturer: typing.SupportsInt, deviceType: typing.SupportsInt) -> None:
        """
        Create a new CAN communication interface with a specific device ID,
        manufacturer and device type. The device ID is 6 bits, the
        manufacturer is 8 bits, and the device type is 5 bits.
        
        :param deviceId:           The device ID
        :param deviceManufacturer: The device manufacturer
        :param deviceType:         The device type
        """
    def readPacketLatest(self, apiId: typing.SupportsInt, data: CANData) -> bool:
        """
        Read a CAN packet. The will continuously return the last packet received,
        without accounting for packet age.
        
        :param apiId: The API ID to read.
        :param data:  Storage for the received data.
        
        :returns: True if the data is valid, otherwise false.
        """
    def readPacketNew(self, apiId: typing.SupportsInt, data: CANData) -> bool:
        """
        Read a new CAN packet. This will only return properly once per packet
        received. Multiple calls without receiving another packet will return
        false.
        
        :param apiId: The API ID to read.
        :param data:  Storage for the received data.
        
        :returns: True if the data is valid, otherwise false.
        """
    def readPacketTimeout(self, apiId: typing.SupportsInt, timeoutMs: typing.SupportsInt, data: CANData) -> bool:
        """
        Read a CAN packet. The will return the last packet received until the
        packet is older then the requested timeout. Then it will return false.
        
        :param apiId:     The API ID to read.
        :param timeoutMs: The timeout time for the packet
        :param data:      Storage for the received data.
        
        :returns: True if the data is valid, otherwise false.
        """
    def stopPacketRepeating(self, apiId: typing.SupportsInt) -> None:
        """
        Stop a repeating packet with a specific ID. This ID is 10 bits.
        
        :param apiId: The API ID to stop repeating
        """
    def writePacket(self, data: typing_extensions.Buffer, apiId: typing.SupportsInt) -> None:
        """
        Write a packet to the CAN device with a specific ID. This ID is 10 bits.
        
        :param data:   The data to write (8 bytes max)
        :param length: The data length to write
        :param apiId:  The API ID to write.
        """
    def writePacketNoError(self, data: typing_extensions.Buffer, apiId: typing.SupportsInt) -> int:
        """
        Write a packet to the CAN device with a specific ID. This ID is 10 bits.
        
        :param data:   The data to write (8 bytes max)
        :param length: The data length to write
        :param apiId:  The API ID to write.
        """
    def writePacketRepeating(self, data: typing_extensions.Buffer, apiId: typing.SupportsInt, repeatMs: typing.SupportsInt) -> None:
        """
        Write a repeating packet to the CAN device with a specific ID. This ID is
        10 bits. The RoboRIO will automatically repeat the packet at the specified
        interval
        
        :param data:     The data to write (8 bytes max)
        :param length:   The data length to write
        :param apiId:    The API ID to write.
        :param repeatMs: The period to repeat the packet at.
        """
    def writePacketRepeatingNoError(self, data: typing_extensions.Buffer, apiId: typing.SupportsInt, repeatMs: typing.SupportsInt) -> int:
        """
        Write a repeating packet to the CAN device with a specific ID. This ID is
        10 bits. The RoboRIO will automatically repeat the packet at the specified
        interval
        
        :param data:     The data to write (8 bytes max)
        :param length:   The data length to write
        :param apiId:    The API ID to write.
        :param repeatMs: The period to repeat the packet at.
        """
    def writeRTRFrame(self, length: typing.SupportsInt, apiId: typing.SupportsInt) -> None:
        """
        Write an RTR frame to the CAN device with a specific ID. This ID is 10
        bits. The length by spec must match what is returned by the responding
        device
        
        :param length: The length to request (0 to 8)
        :param apiId:  The API ID to write.
        """
    def writeRTRFrameNoError(self, length: typing.SupportsInt, apiId: typing.SupportsInt) -> int:
        """
        Write an RTR frame to the CAN device with a specific ID. This ID is 10
        bits. The length by spec must match what is returned by the responding
        device
        
        :param length: The length to request (0 to 8)
        :param apiId:  The API ID to write.
        """
class CANData:
    def __init__(self) -> None:
        ...
    @property
    def data(self) -> memoryview:
        """
        Contents of the CAN packet.
        """
    @property
    def length(self) -> int:
        """
        Length of packet in bytes.
        """
    @length.setter
    def length(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def timestamp(self) -> int:
        """
        CAN frame timestamp in milliseconds.
        """
    @timestamp.setter
    def timestamp(self, arg0: typing.SupportsInt) -> None:
        ...
class CANStatus:
    def __init__(self) -> None:
        ...
    @property
    def busOffCount(self) -> int:
        ...
    @busOffCount.setter
    def busOffCount(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def percentBusUtilization(self) -> float:
        ...
    @percentBusUtilization.setter
    def percentBusUtilization(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def receiveErrorCount(self) -> int:
        ...
    @receiveErrorCount.setter
    def receiveErrorCount(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def transmitErrorCount(self) -> int:
        ...
    @transmitErrorCount.setter
    def transmitErrorCount(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def txFullCount(self) -> int:
        ...
    @txFullCount.setter
    def txFullCount(self, arg0: typing.SupportsInt) -> None:
        ...
class Color:
    """
    Represents colors that can be used with Addressable LEDs.
    
    Limited to 12 bits of precision.
    """
    kAliceBlue: typing.ClassVar[Color]  # value = Color(red=0.941406, green=0.972656, blue=1.000000)
    kAntiqueWhite: typing.ClassVar[Color]  # value = Color(red=0.980469, green=0.921631, blue=0.843262)
    kAqua: typing.ClassVar[Color]  # value = Color(red=0.000000, green=1.000000, blue=1.000000)
    kAquamarine: typing.ClassVar[Color]  # value = Color(red=0.498047, green=1.000000, blue=0.831543)
    kAzure: typing.ClassVar[Color]  # value = Color(red=0.941406, green=1.000000, blue=1.000000)
    kBeige: typing.ClassVar[Color]  # value = Color(red=0.960938, green=0.960938, blue=0.862793)
    kBisque: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.894287, blue=0.768799)
    kBlack: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.000000, blue=0.000000)
    kBlanchedAlmond: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.921631, blue=0.803955)
    kBlue: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.000000, blue=1.000000)
    kBlueViolet: typing.ClassVar[Color]  # value = Color(red=0.541260, green=0.168701, blue=0.886475)
    kBrown: typing.ClassVar[Color]  # value = Color(red=0.647217, green=0.164795, blue=0.164795)
    kBurlywood: typing.ClassVar[Color]  # value = Color(red=0.870605, green=0.721680, blue=0.529541)
    kCadetBlue: typing.ClassVar[Color]  # value = Color(red=0.372559, green=0.619629, blue=0.627686)
    kChartreuse: typing.ClassVar[Color]  # value = Color(red=0.498047, green=1.000000, blue=0.000000)
    kChocolate: typing.ClassVar[Color]  # value = Color(red=0.823730, green=0.411865, blue=0.117676)
    kCoral: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.498047, blue=0.313965)
    kCornflowerBlue: typing.ClassVar[Color]  # value = Color(red=0.392334, green=0.584473, blue=0.929443)
    kCornsilk: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.972656, blue=0.862793)
    kCrimson: typing.ClassVar[Color]  # value = Color(red=0.862793, green=0.078613, blue=0.235352)
    kCyan: typing.ClassVar[Color]  # value = Color(red=0.000000, green=1.000000, blue=1.000000)
    kDarkBlue: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.000000, blue=0.545166)
    kDarkCyan: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.545166, blue=0.545166)
    kDarkGoldenrod: typing.ClassVar[Color]  # value = Color(red=0.721680, green=0.525635, blue=0.043213)
    kDarkGray: typing.ClassVar[Color]  # value = Color(red=0.662842, green=0.662842, blue=0.662842)
    kDarkGreen: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.392334, blue=0.000000)
    kDarkKhaki: typing.ClassVar[Color]  # value = Color(red=0.741211, green=0.717773, blue=0.419678)
    kDarkMagenta: typing.ClassVar[Color]  # value = Color(red=0.545166, green=0.000000, blue=0.545166)
    kDarkOliveGreen: typing.ClassVar[Color]  # value = Color(red=0.333496, green=0.419678, blue=0.184326)
    kDarkOrange: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.549072, blue=0.000000)
    kDarkOrchid: typing.ClassVar[Color]  # value = Color(red=0.600098, green=0.196289, blue=0.800049)
    kDarkRed: typing.ClassVar[Color]  # value = Color(red=0.545166, green=0.000000, blue=0.000000)
    kDarkSalmon: typing.ClassVar[Color]  # value = Color(red=0.913818, green=0.588379, blue=0.478516)
    kDarkSeaGreen: typing.ClassVar[Color]  # value = Color(red=0.560791, green=0.737305, blue=0.560791)
    kDarkSlateBlue: typing.ClassVar[Color]  # value = Color(red=0.282471, green=0.239258, blue=0.545166)
    kDarkSlateGray: typing.ClassVar[Color]  # value = Color(red=0.184326, green=0.309814, blue=0.309814)
    kDarkTurquoise: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.807861, blue=0.819824)
    kDarkViolet: typing.ClassVar[Color]  # value = Color(red=0.580566, green=0.000000, blue=0.827637)
    kDeepPink: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.078613, blue=0.576660)
    kDeepSkyBlue: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.749023, blue=1.000000)
    kDenim: typing.ClassVar[Color]  # value = Color(red=0.082520, green=0.376709, blue=0.741211)
    kDimGray: typing.ClassVar[Color]  # value = Color(red=0.411865, green=0.411865, blue=0.411865)
    kDodgerBlue: typing.ClassVar[Color]  # value = Color(red=0.117676, green=0.564941, blue=1.000000)
    kFirebrick: typing.ClassVar[Color]  # value = Color(red=0.698242, green=0.133545, blue=0.133545)
    kFirstBlue: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.400146, blue=0.702148)
    kFirstRed: typing.ClassVar[Color]  # value = Color(red=0.929443, green=0.109863, blue=0.141357)
    kFloralWhite: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.980469, blue=0.941406)
    kForestGreen: typing.ClassVar[Color]  # value = Color(red=0.133545, green=0.545166, blue=0.133545)
    kFuchsia: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.000000, blue=1.000000)
    kGainsboro: typing.ClassVar[Color]  # value = Color(red=0.862793, green=0.862793, blue=0.862793)
    kGhostWhite: typing.ClassVar[Color]  # value = Color(red=0.972656, green=0.972656, blue=1.000000)
    kGold: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.843262, blue=0.000000)
    kGoldenrod: typing.ClassVar[Color]  # value = Color(red=0.854980, green=0.647217, blue=0.125732)
    kGray: typing.ClassVar[Color]  # value = Color(red=0.502197, green=0.502197, blue=0.502197)
    kGreen: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.502197, blue=0.000000)
    kGreenYellow: typing.ClassVar[Color]  # value = Color(red=0.678467, green=1.000000, blue=0.184326)
    kHoneydew: typing.ClassVar[Color]  # value = Color(red=0.941406, green=1.000000, blue=0.941406)
    kHotPink: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.411865, blue=0.706055)
    kIndianRed: typing.ClassVar[Color]  # value = Color(red=0.803955, green=0.360840, blue=0.360840)
    kIndigo: typing.ClassVar[Color]  # value = Color(red=0.294189, green=0.000000, blue=0.510010)
    kIvory: typing.ClassVar[Color]  # value = Color(red=1.000000, green=1.000000, blue=0.941406)
    kKhaki: typing.ClassVar[Color]  # value = Color(red=0.941406, green=0.902100, blue=0.549072)
    kLavender: typing.ClassVar[Color]  # value = Color(red=0.902100, green=0.902100, blue=0.980469)
    kLavenderBlush: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.941406, blue=0.960938)
    kLawnGreen: typing.ClassVar[Color]  # value = Color(red=0.486328, green=0.988281, blue=0.000000)
    kLemonChiffon: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.980469, blue=0.803955)
    kLightBlue: typing.ClassVar[Color]  # value = Color(red=0.678467, green=0.847168, blue=0.902100)
    kLightCoral: typing.ClassVar[Color]  # value = Color(red=0.941406, green=0.502197, blue=0.502197)
    kLightCyan: typing.ClassVar[Color]  # value = Color(red=0.878662, green=1.000000, blue=1.000000)
    kLightGoldenrodYellow: typing.ClassVar[Color]  # value = Color(red=0.980469, green=0.980469, blue=0.823730)
    kLightGray: typing.ClassVar[Color]  # value = Color(red=0.827637, green=0.827637, blue=0.827637)
    kLightGreen: typing.ClassVar[Color]  # value = Color(red=0.564941, green=0.933350, blue=0.564941)
    kLightPink: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.713867, blue=0.757080)
    kLightSalmon: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.627686, blue=0.478516)
    kLightSeaGreen: typing.ClassVar[Color]  # value = Color(red=0.125732, green=0.698242, blue=0.666748)
    kLightSkyBlue: typing.ClassVar[Color]  # value = Color(red=0.529541, green=0.807861, blue=0.980469)
    kLightSlateGray: typing.ClassVar[Color]  # value = Color(red=0.466797, green=0.533447, blue=0.600098)
    kLightSteelBlue: typing.ClassVar[Color]  # value = Color(red=0.690430, green=0.768799, blue=0.870605)
    kLightYellow: typing.ClassVar[Color]  # value = Color(red=1.000000, green=1.000000, blue=0.878662)
    kLime: typing.ClassVar[Color]  # value = Color(red=0.000000, green=1.000000, blue=0.000000)
    kLimeGreen: typing.ClassVar[Color]  # value = Color(red=0.196289, green=0.803955, blue=0.196289)
    kLinen: typing.ClassVar[Color]  # value = Color(red=0.980469, green=0.941406, blue=0.902100)
    kMagenta: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.000000, blue=1.000000)
    kMaroon: typing.ClassVar[Color]  # value = Color(red=0.502197, green=0.000000, blue=0.000000)
    kMediumAquamarine: typing.ClassVar[Color]  # value = Color(red=0.400146, green=0.803955, blue=0.666748)
    kMediumBlue: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.000000, blue=0.803955)
    kMediumOrchid: typing.ClassVar[Color]  # value = Color(red=0.729492, green=0.333496, blue=0.827637)
    kMediumPurple: typing.ClassVar[Color]  # value = Color(red=0.576660, green=0.439453, blue=0.858887)
    kMediumSeaGreen: typing.ClassVar[Color]  # value = Color(red=0.235352, green=0.702148, blue=0.443359)
    kMediumSlateBlue: typing.ClassVar[Color]  # value = Color(red=0.482422, green=0.407959, blue=0.933350)
    kMediumSpringGreen: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.980469, blue=0.604004)
    kMediumTurquoise: typing.ClassVar[Color]  # value = Color(red=0.282471, green=0.819824, blue=0.800049)
    kMediumVioletRed: typing.ClassVar[Color]  # value = Color(red=0.780518, green=0.082520, blue=0.521729)
    kMidnightBlue: typing.ClassVar[Color]  # value = Color(red=0.098145, green=0.098145, blue=0.439453)
    kMintcream: typing.ClassVar[Color]  # value = Color(red=0.960938, green=1.000000, blue=0.980469)
    kMistyRose: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.894287, blue=0.882568)
    kMoccasin: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.894287, blue=0.709961)
    kNavajoWhite: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.870605, blue=0.678467)
    kNavy: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.000000, blue=0.502197)
    kOldLace: typing.ClassVar[Color]  # value = Color(red=0.992188, green=0.960938, blue=0.902100)
    kOlive: typing.ClassVar[Color]  # value = Color(red=0.502197, green=0.502197, blue=0.000000)
    kOliveDrab: typing.ClassVar[Color]  # value = Color(red=0.419678, green=0.556885, blue=0.137451)
    kOrange: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.647217, blue=0.000000)
    kOrangeRed: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.270752, blue=0.000000)
    kOrchid: typing.ClassVar[Color]  # value = Color(red=0.854980, green=0.439453, blue=0.839355)
    kPaleGoldenrod: typing.ClassVar[Color]  # value = Color(red=0.933350, green=0.909912, blue=0.666748)
    kPaleGreen: typing.ClassVar[Color]  # value = Color(red=0.596191, green=0.984375, blue=0.596191)
    kPaleTurquoise: typing.ClassVar[Color]  # value = Color(red=0.686279, green=0.933350, blue=0.933350)
    kPaleVioletRed: typing.ClassVar[Color]  # value = Color(red=0.858887, green=0.439453, blue=0.576660)
    kPapayaWhip: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.937256, blue=0.835449)
    kPeachPuff: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.854980, blue=0.725586)
    kPeru: typing.ClassVar[Color]  # value = Color(red=0.803955, green=0.521729, blue=0.247070)
    kPink: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.753174, blue=0.796143)
    kPlum: typing.ClassVar[Color]  # value = Color(red=0.866699, green=0.627686, blue=0.866699)
    kPowderBlue: typing.ClassVar[Color]  # value = Color(red=0.690430, green=0.878662, blue=0.902100)
    kPurple: typing.ClassVar[Color]  # value = Color(red=0.502197, green=0.000000, blue=0.502197)
    kRed: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.000000, blue=0.000000)
    kRosyBrown: typing.ClassVar[Color]  # value = Color(red=0.737305, green=0.560791, blue=0.560791)
    kRoyalBlue: typing.ClassVar[Color]  # value = Color(red=0.255127, green=0.411865, blue=0.882568)
    kSaddleBrown: typing.ClassVar[Color]  # value = Color(red=0.545166, green=0.270752, blue=0.074707)
    kSalmon: typing.ClassVar[Color]  # value = Color(red=0.980469, green=0.502197, blue=0.447266)
    kSandyBrown: typing.ClassVar[Color]  # value = Color(red=0.957031, green=0.643311, blue=0.376709)
    kSeaGreen: typing.ClassVar[Color]  # value = Color(red=0.180420, green=0.545166, blue=0.341309)
    kSeashell: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.960938, blue=0.933350)
    kSienna: typing.ClassVar[Color]  # value = Color(red=0.627686, green=0.321777, blue=0.176514)
    kSilver: typing.ClassVar[Color]  # value = Color(red=0.753174, green=0.753174, blue=0.753174)
    kSkyBlue: typing.ClassVar[Color]  # value = Color(red=0.529541, green=0.807861, blue=0.921631)
    kSlateBlue: typing.ClassVar[Color]  # value = Color(red=0.415771, green=0.353027, blue=0.803955)
    kSlateGray: typing.ClassVar[Color]  # value = Color(red=0.439453, green=0.502197, blue=0.564941)
    kSnow: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.980469, blue=0.980469)
    kSpringGreen: typing.ClassVar[Color]  # value = Color(red=0.000000, green=1.000000, blue=0.498047)
    kSteelBlue: typing.ClassVar[Color]  # value = Color(red=0.274658, green=0.510010, blue=0.706055)
    kTan: typing.ClassVar[Color]  # value = Color(red=0.823730, green=0.706055, blue=0.549072)
    kTeal: typing.ClassVar[Color]  # value = Color(red=0.000000, green=0.502197, blue=0.502197)
    kThistle: typing.ClassVar[Color]  # value = Color(red=0.847168, green=0.749023, blue=0.847168)
    kTomato: typing.ClassVar[Color]  # value = Color(red=1.000000, green=0.388428, blue=0.278564)
    kTurquoise: typing.ClassVar[Color]  # value = Color(red=0.251221, green=0.878662, blue=0.815918)
    kViolet: typing.ClassVar[Color]  # value = Color(red=0.933350, green=0.510010, blue=0.933350)
    kWheat: typing.ClassVar[Color]  # value = Color(red=0.960938, green=0.870605, blue=0.702148)
    kWhite: typing.ClassVar[Color]  # value = Color(red=1.000000, green=1.000000, blue=1.000000)
    kWhiteSmoke: typing.ClassVar[Color]  # value = Color(red=0.960938, green=0.960938, blue=0.960938)
    kYellow: typing.ClassVar[Color]  # value = Color(red=1.000000, green=1.000000, blue=0.000000)
    kYellowGreen: typing.ClassVar[Color]  # value = Color(red=0.604004, green=0.803955, blue=0.196289)
    @staticmethod
    def fromHSV(h: typing.SupportsInt, s: typing.SupportsInt, v: typing.SupportsInt) -> Color:
        """
        Creates a Color from HSV values.
        
        :param h: The h value [0-180)
        :param s: The s value [0-255]
        :param v: The v value [0-255]
        
        :returns: The color
        """
    def __eq__(self, arg0: Color) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    @typing.overload
    def __init__(self) -> None:
        """
        Constructs a default color (black).
        """
    @typing.overload
    def __init__(self, red: typing.SupportsFloat, green: typing.SupportsFloat, blue: typing.SupportsFloat) -> None:
        """
        Constructs a Color from doubles (0-1).
        
        :param red:   Red value (0-1)
        :param green: Green value (0-1)
        :param blue:  Blue value (0-1)
        """
    @typing.overload
    def __init__(self, r: typing.SupportsInt, g: typing.SupportsInt, b: typing.SupportsInt) -> None:
        """
        Constructs a Color from ints (0-255).
        
        :param r: Red value (0-255)
        :param g: Green value (0-255)
        :param b: Blue value (0-255)
        """
    @typing.overload
    def __init__(self, hexString: str) -> None:
        """
        Constructs a Color from a hex string.
        
        :param hexString: a string of the format <tt>\\#RRGGBB</tt>
                          @throws std::invalid_argument if the hex string is invalid.
        """
    def __repr__(self) -> str:
        ...
    def hexString(self) -> str:
        """
        Return this color represented as a hex string.
        
        :returns: a string of the format <tt>\\#RRGGBB</tt>
        """
    @property
    def blue(self) -> float:
        """
        Blue component (0-1).
        """
    @property
    def green(self) -> float:
        """
        Green component (0-1).
        """
    @property
    def red(self) -> float:
        """
        Red component (0-1).
        """
class Color8Bit:
    """
    Represents colors that can be used with Addressable LEDs.
    """
    @staticmethod
    def fromHexString(hexString: str) -> Color8Bit:
        """
        Create a Color8Bit from a hex string.
        
        :param hexString: a string of the format <tt>\\#RRGGBB</tt>
        
        :returns: Color8Bit object from hex string.
                  @throws std::invalid_argument if the hex string is invalid.
        """
    def __eq__(self, arg0: Color8Bit) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    @typing.overload
    def __init__(self) -> None:
        """
        Constructs a default color (black).
        """
    @typing.overload
    def __init__(self, red: typing.SupportsInt, green: typing.SupportsInt, blue: typing.SupportsInt) -> None:
        """
        Constructs a Color8Bit.
        
        :param red:   Red value (0-255)
        :param green: Green value (0-255)
        :param blue:  Blue value (0-255)
        """
    @typing.overload
    def __init__(self, color: Color) -> None:
        """
        Constructs a Color8Bit from a Color.
        
        :param color: The color
        """
    @typing.overload
    def __init__(self, hexString: str) -> None:
        """
        Constructs a Color8Bit from a hex string.
        
        :param hexString: a string of the format <tt>\\#RRGGBB</tt>
                          @throws std::invalid_argument if the hex string is invalid.
        """
    def __repr__(self) -> str:
        ...
    def hexString(self) -> str:
        """
        Return this color represented as a hex string.
        
        :returns: a string of the format <tt>\\#RRGGBB</tt>
        """
    def toColor(self) -> Color:
        ...
    @property
    def blue(self) -> int:
        """
        Blue component (0-255).
        """
    @property
    def green(self) -> int:
        """
        Green component (0-255).
        """
    @property
    def red(self) -> int:
        """
        Red component (0-255).
        """
class Compressor(wpiutil._wpiutil.Sendable):
    """
    Class for operating a compressor connected to a pneumatics module.
    
    The module will automatically run in closed loop mode by default whenever a
    Solenoid object is created. For most cases, a Compressor object does not need
    to be instantiated or used in a robot program. This class is only required in
    cases where the robot program needs a more detailed status of the compressor
    or to enable/disable closed loop control.
    
    Note: you cannot operate the compressor directly from this class as doing so
    would circumvent the safety provided by using the pressure switch and closed
    loop control. You can only turn off closed loop control, thereby stopping
    the compressor from operating.
    """
    @typing.overload
    def __init__(self, module: typing.SupportsInt, moduleType: PneumaticsModuleType) -> None:
        """
        Constructs a compressor for a specified module and type.
        
        :param module:     The module ID to use.
        :param moduleType: The module type to use.
        """
    @typing.overload
    def __init__(self, moduleType: PneumaticsModuleType) -> None:
        """
        Constructs a compressor for a default module and specified type.
        
        :param moduleType: The module type to use.
        """
    def disable(self) -> None:
        """
        Disable the compressor.
        """
    def enableAnalog(self, minPressure: wpimath.units.pounds_per_square_inch, maxPressure: wpimath.units.pounds_per_square_inch) -> None:
        """
        If supported by the device, enables the compressor in analog mode. This
        mode uses an analog pressure sensor connected to analog channel 0 to cycle
        the compressor. The compressor will turn on when the pressure drops below
        ``minPressure`` and will turn off when the pressure reaches {@code
        maxPressure}. This mode is only supported by the REV PH with the REV Analog
        Pressure Sensor connected to analog channel 0.
        
        On CTRE PCM, this will enable digital control.
        
        :param minPressure: The minimum pressure. The compressor will turn on when
                            the pressure drops below this value.
        :param maxPressure: The maximum pressure. The compressor will turn off when
                            the pressure reaches this value.
        """
    def enableDigital(self) -> None:
        """
        Enables the compressor in digital mode using the digital pressure switch.
        The compressor will turn on when the pressure switch indicates that the
        system is not full, and will turn off when the pressure switch indicates
        that the system is full.
        """
    def enableHybrid(self, minPressure: wpimath.units.pounds_per_square_inch, maxPressure: wpimath.units.pounds_per_square_inch) -> None:
        """
        If supported by the device, enables the compressor in hybrid mode. This
        mode uses both a digital pressure switch and an analog pressure sensor
        connected to analog channel 0 to cycle the compressor. This mode is only
        supported by the REV PH with the REV Analog Pressure Sensor connected to
        analog channel 0.
        
        The compressor will turn on when \\a both:
        
        - The digital pressure switch indicates the system is not full AND
        - The analog pressure sensor indicates that the pressure in the system
        is below the specified minimum pressure.
        
        The compressor will turn off when \\a either:
        
        - The digital pressure switch is disconnected or indicates that the system
        is full OR
        - The pressure detected by the analog sensor is greater than the specified
        maximum pressure.
        
        On CTRE PCM, this will enable digital control.
        
        :param minPressure: The minimum pressure. The compressor will turn on
                            when the pressure drops below this value and the pressure switch indicates
                            that the system is not full.
        :param maxPressure: The maximum pressure. The compressor will turn
                            off when the pressure reaches this value or the pressure switch is
                            disconnected or indicates that the system is full.
        """
    def getAnalogVoltage(self) -> wpimath.units.volts:
        """
        If supported by the device, returns the analog input voltage (on channel
        0).
        
        This function is only supported by the REV PH. On CTRE PCM, this will
        return 0.
        
        :returns: The analog input voltage, in volts.
        """
    def getConfigType(self) -> CompressorConfigType:
        """
        Returns the active compressor configuration.
        
        :returns: The active compressor configuration.
        """
    def getCurrent(self) -> wpimath.units.amperes:
        """
        Get the current drawn by the compressor.
        
        :returns: Current drawn by the compressor.
        """
    def getPressure(self) -> wpimath.units.pounds_per_square_inch:
        """
        If supported by the device, returns the pressure read by the analog
        pressure sensor (on channel 0).
        
        This function is only supported by the REV PH with the REV Analog Pressure
        Sensor. On CTRE PCM, this will return 0.
        
        :returns: The pressure read by the analog pressure sensor.
        """
    def getPressureSwitchValue(self) -> bool:
        """
        Returns the state of the pressure switch.
        
        :returns: True if pressure switch indicates that the system is not full,
                  otherwise false.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isEnabled(self) -> bool:
        """
        Returns whether the compressor is active or not.
        
        :returns: true if the compressor is on - otherwise false.
        """
class CompressorConfigType:
    """
    Compressor config type.
    
    Members:
    
      Disabled : Disabled.
    
      Digital : Digital.
    
      Analog : Analog.
    
      Hybrid : Hybrid.
    """
    Analog: typing.ClassVar[CompressorConfigType]  # value = <CompressorConfigType.Analog: 2>
    Digital: typing.ClassVar[CompressorConfigType]  # value = <CompressorConfigType.Digital: 1>
    Disabled: typing.ClassVar[CompressorConfigType]  # value = <CompressorConfigType.Disabled: 0>
    Hybrid: typing.ClassVar[CompressorConfigType]  # value = <CompressorConfigType.Hybrid: 3>
    __members__: typing.ClassVar[dict[str, CompressorConfigType]]  # value = {'Disabled': <CompressorConfigType.Disabled: 0>, 'Digital': <CompressorConfigType.Digital: 1>, 'Analog': <CompressorConfigType.Analog: 2>, 'Hybrid': <CompressorConfigType.Hybrid: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Counter(wpilib.interfaces._interfaces.CounterBase, wpiutil._wpiutil.Sendable):
    """
    Class for counting the number of ticks on a digital input channel.
    
    This is a general purpose class for counting repetitive events. It can return
    the number of counts, the period of the most recent cycle, and detect when
    the signal being counted has stopped by supplying a maximum cycle time.
    
    All counters will immediately start counting - Reset() them if you need them
    to be zeroed before use.
    """
    class Mode:
        """
        Members:
        
          kTwoPulse
        
          kSemiperiod
        
          kPulseLength
        
          kExternalDirection
        """
        __members__: typing.ClassVar[dict[str, Counter.Mode]]  # value = {'kTwoPulse': <Mode.kTwoPulse: 0>, 'kSemiperiod': <Mode.kSemiperiod: 1>, 'kPulseLength': <Mode.kPulseLength: 2>, 'kExternalDirection': <Mode.kExternalDirection: 3>}
        kExternalDirection: typing.ClassVar[Counter.Mode]  # value = <Mode.kExternalDirection: 3>
        kPulseLength: typing.ClassVar[Counter.Mode]  # value = <Mode.kPulseLength: 2>
        kSemiperiod: typing.ClassVar[Counter.Mode]  # value = <Mode.kSemiperiod: 1>
        kTwoPulse: typing.ClassVar[Counter.Mode]  # value = <Mode.kTwoPulse: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    @typing.overload
    def __init__(self, mode: Counter.Mode = ...) -> None:
        """
        Create an instance of a counter where no sources are selected.
        
        They all must be selected by calling functions to specify the up source and
        the down source independently.
        
        This creates a ChipObject counter and initializes status variables
        appropriately.
        
        The counter will start counting immediately.
        
        :param mode: The counter mode
        """
    @typing.overload
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Create an instance of a Counter object.
        
        Create an up-Counter instance given a channel.
        
        The counter will start counting immediately.
        
        :param channel: The DIO channel to use as the up source. 0-9 are on-board,
                        10-25 are on the MXP
        """
    @typing.overload
    def __init__(self, source: DigitalSource) -> None:
        """
        Create an instance of a counter from a Digital Source (such as a Digital
        Input).
        
        This is used if an existing digital input is to be shared by multiple other
        objects such as encoders or if the Digital Source is not a Digital Input
        channel (such as an Analog %Trigger).
        
        The counter will start counting immediately.
        
        :param source: A pointer to the existing DigitalSource object. It will be
                       set as the Up Source.
        """
    @typing.overload
    def __init__(self, trigger: AnalogTrigger) -> None:
        """
        Create an instance of a Counter object.
        
        Create an instance of a simple up-Counter given an analog trigger.
        Use the trigger state output from the analog trigger.
        
        The counter will start counting immediately.
        
        :param trigger: The reference to the existing AnalogTrigger object.
        """
    @typing.overload
    def __init__(self, encodingType: wpilib.interfaces._interfaces.CounterBase.EncodingType, upSource: DigitalSource, downSource: DigitalSource, inverted: bool) -> None:
        """
        Create an instance of a Counter object.
        
        Creates a full up-down counter given two Digital Sources.
        
        :param encodingType: The quadrature decoding mode (1x or 2x)
        :param upSource:     The pointer to the DigitalSource to set as the up
                             source
        :param downSource:   The pointer to the DigitalSource to set as the down
                             source
        :param inverted:     True to invert the output (reverse the direction)
        """
    def clearDownSource(self) -> None:
        """
        Disable the down counting source to the counter.
        """
    def clearUpSource(self) -> None:
        """
        Disable the up counting source to the counter.
        """
    def get(self) -> int:
        """
        Read the current counter value.
        
        Read the value at this instant. It may still be running, so it reflects the
        current value. Next time it is read, it might have a different value.
        """
    def getDirection(self) -> bool:
        """
        The last direction the counter value changed.
        
        :returns: The last direction the counter value changed.
        """
    def getDistance(self) -> float:
        """
        Read the current scaled counter value. Read the value at this instant,
        scaled by the distance per pulse (defaults to 1).
        
        :returns: The distance since the last reset
        """
    def getFPGAIndex(self) -> int:
        ...
    def getPeriod(self) -> wpimath.units.seconds:
        """
        Get the Period of the most recent count.
        
        Returns the time interval of the most recent count. This can be used for
        velocity calculations to determine shaft speed.
        
        :returns: The period between the last two pulses in units of seconds.
        """
    def getRate(self) -> float:
        """
        Get the current rate of the Counter. Read the current rate of the counter
        accounting for the distance per pulse value. The default value for distance
        per pulse (1) yields units of pulses per second.
        
        :returns: The rate in units/sec
        """
    def getSamplesToAverage(self) -> int:
        """
        Get the Samples to Average which specifies the number of samples of the
        timer to average when calculating the period.
        
        Perform averaging to account for mechanical imperfections or as
        oversampling to increase resolution.
        
        :returns: The number of samples being averaged (from 1 to 127)
        """
    def getStopped(self) -> bool:
        """
        Determine if the clock is stopped.
        
        Determine if the clocked input is stopped based on the MaxPeriod value set
        using the SetMaxPeriod method. If the clock exceeds the MaxPeriod, then the
        device (and counter) are assumed to be stopped and it returns true.
        
        :returns: Returns true if the most recent counter period exceeds the
                  MaxPeriod value set by SetMaxPeriod.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def reset(self) -> None:
        """
        Reset the Counter to zero.
        
        Set the counter value to zero. This doesn't effect the running state of the
        counter, just sets the current value to zero.
        """
    def setDistancePerPulse(self, distancePerPulse: typing.SupportsFloat) -> None:
        """
        Set the distance per pulse for this counter. This sets the multiplier used
        to determine the distance driven based on the count value from the encoder.
        Set this value based on the Pulses per Revolution and factor in any gearing
        reductions. This distance can be in any units you like, linear or angular.
        
        :param distancePerPulse: The scale factor that will be used to convert
                                 pulses to useful units.
        """
    @typing.overload
    def setDownSource(self, channel: typing.SupportsInt) -> None:
        """
        Set the down counting source to be a digital input channel.
        
        :param channel: The DIO channel to use as the up source. 0-9 are on-board,
                        10-25 are on the MXP
        """
    @typing.overload
    def setDownSource(self, analogTrigger: AnalogTrigger, triggerType: AnalogTriggerType) -> None:
        """
        Set the down counting source to be an analog trigger.
        
        :param analogTrigger: The analog trigger object that is used for the Down
                              Source
        :param triggerType:   The analog trigger output that will trigger the
                              counter.
        """
    @typing.overload
    def setDownSource(self, source: DigitalSource) -> None:
        ...
    def setDownSourceEdge(self, risingEdge: bool, fallingEdge: bool) -> None:
        """
        Set the edge sensitivity on a down counting source.
        
        Set the down source to either detect rising edges or falling edges.
        
        :param risingEdge:  True to trigger on rising edges
        :param fallingEdge: True to trigger on falling edges
        """
    def setExternalDirectionMode(self) -> None:
        """
        Set external direction mode on this counter.
        
        Counts are sourced on the Up counter input.
        The Down counter input represents the direction to count.
        """
    def setMaxPeriod(self, maxPeriod: wpimath.units.seconds) -> None:
        """
        Set the maximum period where the device is still considered "moving".
        
        Sets the maximum period where the device is considered moving. This value
        is used to determine the "stopped" state of the counter using the
        GetStopped method.
        
        :param maxPeriod: The maximum period where the counted device is considered
                          moving in seconds.
        """
    def setPulseLengthMode(self, threshold: typing.SupportsFloat) -> None:
        """
        Configure the counter to count in up or down based on the length of the
        input pulse.
        
        This mode is most useful for direction sensitive gear tooth sensors.
        
        :param threshold: The pulse length beyond which the counter counts the
                          opposite direction. Units are seconds.
        """
    def setReverseDirection(self, reverseDirection: bool) -> None:
        """
        Set the Counter to return reversed sensing on the direction.
        
        This allows counters to change the direction they are counting in the case
        of 1X and 2X quadrature encoding only. Any other counter mode isn't
        supported.
        
        :param reverseDirection: true if the value counted should be negated.
        """
    def setSamplesToAverage(self, samplesToAverage: typing.SupportsInt) -> None:
        """
        Set the Samples to Average which specifies the number of samples of the
        timer to average when calculating the period. Perform averaging to account
        for mechanical imperfections or as oversampling to increase resolution.
        
        :param samplesToAverage: The number of samples to average from 1 to 127.
        """
    def setSemiPeriodMode(self, highSemiPeriod: bool) -> None:
        """
        Set Semi-period mode on this counter.
        
        Counts up on both rising and falling edges.
        """
    def setUpDownCounterMode(self) -> None:
        """
        Set standard up / down counting mode on this counter.
        
        Up and down counts are sourced independently from two inputs.
        """
    @typing.overload
    def setUpSource(self, channel: typing.SupportsInt) -> None:
        """
        Set the up source for the counter as a digital input channel.
        
        :param channel: The DIO channel to use as the up source. 0-9 are on-board,
                        10-25 are on the MXP
        """
    @typing.overload
    def setUpSource(self, analogTrigger: AnalogTrigger, triggerType: AnalogTriggerType) -> None:
        """
        Set the up counting source to be an analog trigger.
        
        :param analogTrigger: The analog trigger object that is used for the Up
                              Source
        :param triggerType:   The analog trigger output that will trigger the
                              counter.
        """
    @typing.overload
    def setUpSource(self, source: DigitalSource) -> None:
        """
        Set the source object that causes the counter to count up.
        
        Set the up counting DigitalSource.
        
        :param source: Pointer to the DigitalSource object to set as the up source
        """
    def setUpSourceEdge(self, risingEdge: bool, fallingEdge: bool) -> None:
        """
        Set the edge sensitivity on an up counting source.
        
        Set the up source to either detect rising edges or falling edges or both.
        
        :param risingEdge:  True to trigger on rising edges
        :param fallingEdge: True to trigger on falling edges
        """
    def setUpdateWhenEmpty(self, enabled: bool) -> None:
        """
        Select whether you want to continue updating the event timer output when
        there are no samples captured.
        
        The output of the event timer has a buffer of periods that are averaged and
        posted to a register on the FPGA.  When the timer detects that the event
        source has stopped (based on the MaxPeriod) the buffer of samples to be
        averaged is emptied.  If you enable the update when empty, you will be
        notified of the stopped source and the event time will report 0 samples.
        If you disable update when empty, the most recent average will remain on
        the output until a new sample is acquired.  You will never see 0 samples
        output (except when there have been no events since an FPGA reset) and you
        will likely not see the stopped bit become true (since it is updated at the
        end of an average and there are no samples to average).
        
        :param enabled: True to enable update when empty
        """
    @property
    def _m_downSource(self) -> DigitalSource:
        """
        Makes the counter count down.
        """
    @property
    def _m_upSource(self) -> DigitalSource:
        """
        Makes the counter count up.
        """
class DSControlWord:
    """
    A wrapper around Driver Station control word.
    """
    def __init__(self) -> None:
        """
        DSControlWord constructor.
        
        Upon construction, the current Driver Station control word is read and
        stored internally.
        """
    def isAutonomous(self) -> bool:
        """
        Check if the DS is commanding autonomous mode.
        
        :returns: True if the robot is being commanded to be in autonomous mode
        """
    def isAutonomousEnabled(self) -> bool:
        """
        Check if the DS is commanding autonomous mode and if it has enabled the
        robot.
        
        :returns: True if the robot is being commanded to be in autonomous mode and
                  enabled.
        """
    def isDSAttached(self) -> bool:
        """
        Check if the DS is attached.
        
        :returns: True if the DS is connected to the robot
        """
    def isDisabled(self) -> bool:
        """
        Check if the robot is disabled.
        
        :returns: True if the robot is explicitly disabled or the DS is not connected
        """
    def isEStopped(self) -> bool:
        """
        Check if the robot is e-stopped.
        
        :returns: True if the robot is e-stopped
        """
    def isEnabled(self) -> bool:
        """
        Check if the DS has enabled the robot.
        
        :returns: True if the robot is enabled and the DS is connected
        """
    def isFMSAttached(self) -> bool:
        """
        Is the driver station attached to a Field Management System?
        
        :returns: True if the robot is competing on a field being controlled by a
                  Field Management System
        """
    def isTeleop(self) -> bool:
        """
        Check if the DS is commanding teleop mode.
        
        :returns: True if the robot is being commanded to be in teleop mode
        """
    def isTeleopEnabled(self) -> bool:
        """
        Check if the DS is commanding teleop mode and if it has enabled the robot.
        
        :returns: True if the robot is being commanded to be in teleop mode and
                  enabled.
        """
    def isTest(self) -> bool:
        """
        Check if the DS is commanding test mode.
        
        :returns: True if the robot is being commanded to be in test mode
        """
class DataLogManager:
    """
    Centralized data log that provides automatic data log file management. It
    automatically cleans up old files when disk space is low and renames the file
    based either on current date/time or (if available) competition match number.
    The data file will be saved to a USB flash drive in a folder named "logs" if
    one is attached, or to /home/lvuser/logs otherwise.
    
    Log files are initially named "FRC_TBD\\_{random}.wpilog" until the DS
    connects. After the DS connects, the log file is renamed to
    "FRC_yyyyMMdd_HHmmss.wpilog" (where the date/time is UTC). If the FMS is
    connected and provides a match number, the log file is renamed to
    "FRC_yyyyMMdd_HHmmss\\_{event}_{match}.wpilog".
    
    On startup, all existing FRC_TBD log files are deleted. If there is less than
    50 MB of free space on the target storage, FRC\\_ log files are deleted (oldest
    to newest) until there is 50 MB free OR there are 10 files remaining.
    
    By default, all NetworkTables value changes are stored to the data log.
    """
    @staticmethod
    def getLog() -> wpiutil._wpiutil.log.DataLog:
        """
        Get the managed data log (for custom logging). Starts the data log manager
        if not already started.
        
        :returns: data log
        """
    @staticmethod
    def getLogDir() -> str:
        """
        Get the log directory.
        
        :returns: log directory
        """
    @staticmethod
    def log(message: str) -> None:
        """
        Log a message to the "messages" entry. The message is also printed to
        standard output (followed by a newline).
        
        :param message: message
        """
    @staticmethod
    def logConsoleOutput(enabled: bool) -> None:
        """
        Enable or disable logging of the console output. Defaults to enabled.
        
        :param enabled: true to enable, false to disable
        """
    @staticmethod
    def logNetworkTables(enabled: bool) -> None:
        """
        Enable or disable logging of NetworkTables data. Note that unlike the
        network interface for NetworkTables, this will capture every value change.
        Defaults to enabled.
        
        :param enabled: true to enable, false to disable
        """
    @staticmethod
    def start(dir: str = '', filename: str = '', period: typing.SupportsFloat = 0.25) -> None:
        """
        Start data log manager. The parameters have no effect if the data log
        manager was already started (e.g. by calling another static function).
        
        :param dir:      if not empty, directory to use for data log storage
        :param filename: filename to use; if none provided, the filename is
                         automatically generated
        :param period:   time between automatic flushes to disk, in seconds;
                         this is a time/storage tradeoff
        """
    @staticmethod
    def stop() -> None:
        """
        Stop data log manager.
        """
class DigitalGlitchFilter(wpiutil._wpiutil.Sendable):
    """
    Class to enable glitch filtering on a set of digital inputs.
    
    This class will manage adding and removing digital inputs from a FPGA glitch
    filter. The filter lets the user configure the time that an input must remain
    high or low before it is classified as high or low.
    """
    def __init__(self) -> None:
        ...
    @typing.overload
    def add(self, input: DigitalSource) -> None:
        """
        Assigns the DigitalSource to this glitch filter.
        
        :param input: The DigitalSource to add.
        """
    @typing.overload
    def add(self, input: Encoder) -> None:
        """
        Assigns the Encoder to this glitch filter.
        
        :param input: The Encoder to add.
        """
    @typing.overload
    def add(self, input: Counter) -> None:
        """
        Assigns the Counter to this glitch filter.
        
        :param input: The Counter to add.
        """
    def getPeriodCycles(self) -> int:
        """
        Gets the number of cycles that the input must not change state for.
        
        :returns: The number of cycles.
        """
    def getPeriodNanoSeconds(self) -> int:
        """
        Gets the number of nanoseconds that the input must not change state for.
        
        :returns: The number of nanoseconds.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    @typing.overload
    def remove(self, input: DigitalSource) -> None:
        """
        Removes a digital input from this filter.
        
        Removes the DigitalSource from this glitch filter and re-assigns it to
        the default filter.
        
        :param input: The DigitalSource to remove.
        """
    @typing.overload
    def remove(self, input: Encoder) -> None:
        """
        Removes an encoder from this filter.
        
        Removes the Encoder from this glitch filter and re-assigns it to
        the default filter.
        
        :param input: The Encoder to remove.
        """
    @typing.overload
    def remove(self, input: Counter) -> None:
        """
        Removes a counter from this filter.
        
        Removes the Counter from this glitch filter and re-assigns it to
        the default filter.
        
        :param input: The Counter to remove.
        """
    def setPeriodCycles(self, fpgaCycles: typing.SupportsInt) -> None:
        """
        Sets the number of cycles that the input must not change state for.
        
        :param fpgaCycles: The number of FPGA cycles.
        """
    def setPeriodNanoSeconds(self, nanoseconds: typing.SupportsInt) -> None:
        """
        Sets the number of nanoseconds that the input must not change state for.
        
        :param nanoseconds: The number of nanoseconds.
        """
class DigitalInput(DigitalSource, wpiutil._wpiutil.Sendable):
    """
    Class to read a digital input.
    
    This class will read digital inputs and return the current value on the
    channel. Other devices such as encoders, gear tooth sensors, etc. that are
    implemented elsewhere will automatically allocate digital inputs and outputs
    as required. This class is only for devices like switches etc. that aren't
    implemented anywhere else.
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Create an instance of a Digital Input class.
        
        Creates a digital input given a channel.
        
        :param channel: The DIO channel 0-9 are on-board, 10-25 are on the MXP port
        """
    def get(self) -> bool:
        """
        Get the value from a digital input channel.
        
        Retrieve the value of a single digital input channel from the FPGA.
        """
    def getAnalogTriggerTypeForRouting(self) -> AnalogTriggerType:
        """
        :returns: The type of analog trigger output to be used. 0 for Digitals
        """
    def getChannel(self) -> int:
        """
        :returns: The GPIO channel number that this object represents.
        """
    def getPortHandleForRouting(self) -> int:
        """
        :returns: The HAL Handle to the specified source.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isAnalogTrigger(self) -> bool:
        """
        Is source an AnalogTrigger
        """
    def setSimDevice(self, device: typing.SupportsInt) -> None:
        """
        Indicates this input is used by a simulated device.
        
        :param device: simulated device handle
        """
class DigitalOutput(DigitalSource, wpiutil._wpiutil.Sendable):
    """
    Class to write to digital outputs.
    
    Write values to the digital output channels. Other devices implemented
    elsewhere will allocate channels automatically so for those devices it
    shouldn't be done here.
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Create an instance of a digital output.
        
        Create a digital output given a channel.
        
        :param channel: The digital channel 0-9 are on-board, 10-25 are on the MXP
                        port
        """
    def disablePWM(self) -> None:
        """
        Change this line from a PWM output back to a static Digital Output line.
        
        Free up one of the 6 DO PWM generator resources that were in use.
        """
    def enablePPS(self, dutyCycle: typing.SupportsFloat) -> None:
        """
        Enable a PWM PPS (Pulse Per Second) Output on this line.
        
        Allocate one of the 6 DO PWM generator resources from this module.
        
        Supply the duty-cycle to output.
        
        The resolution of the duty cycle is 8-bit.
        
        :param dutyCycle: The duty-cycle to start generating. [0..1]
        """
    def enablePWM(self, initialDutyCycle: typing.SupportsFloat) -> None:
        """
        Enable a PWM Output on this line.
        
        Allocate one of the 6 DO PWM generator resources from this module.
        
        Supply the initial duty-cycle to output so as to avoid a glitch when first
        starting.
        
        The resolution of the duty cycle is 8-bit for low frequencies (1kHz or
        less) but is reduced the higher the frequency of the PWM signal is.
        
        :param initialDutyCycle: The duty-cycle to start generating. [0..1]
        """
    def get(self) -> bool:
        """
        Gets the value being output from the Digital Output.
        
        :returns: the state of the digital output.
        """
    def getAnalogTriggerTypeForRouting(self) -> AnalogTriggerType:
        """
        :returns: The type of analog trigger output to be used. 0 for Digitals
        """
    def getChannel(self) -> int:
        """
        :returns: The GPIO channel number that this object represents.
        """
    def getPortHandleForRouting(self) -> int:
        """
        :returns: The HAL Handle to the specified source.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isAnalogTrigger(self) -> bool:
        """
        Is source an AnalogTrigger
        """
    def isPulsing(self) -> bool:
        """
        Determine if the pulse is still going.
        
        Determine if a previously started pulse is still going.
        """
    def pulse(self, pulseLength: wpimath.units.seconds) -> None:
        """
        Output a single pulse on the digital output line.
        
        Send a single pulse on the digital output line where the pulse duration is
        specified in seconds. Maximum of 65535 microseconds.
        
        :param pulseLength: The pulse length in seconds
        """
    def set(self, value: bool) -> None:
        """
        Set the value of a digital output.
        
        Set the value of a digital output to either one (true) or zero (false).
        
        :param value: 1 (true) for high, 0 (false) for disabled
        """
    def setPWMRate(self, rate: typing.SupportsFloat) -> None:
        """
        Change the PWM frequency of the PWM output on a Digital Output line.
        
        The valid range is from 0.6 Hz to 19 kHz.  The frequency resolution is
        logarithmic.
        
        There is only one PWM frequency for all digital channels.
        
        :param rate: The frequency to output all digital output PWM signals.
        """
    def setSimDevice(self, device: typing.SupportsInt) -> None:
        """
        Indicates this output is used by a simulated device.
        
        :param device: simulated device handle
        """
    def updateDutyCycle(self, dutyCycle: typing.SupportsFloat) -> None:
        """
        Change the duty-cycle that is being generated on the line.
        
        The resolution of the duty cycle is 8-bit for low frequencies (1kHz or
        less) but is reduced the higher the frequency of the PWM signal is.
        
        :param dutyCycle: The duty-cycle to change to. [0..1]
        """
class DigitalSource:
    """
    DigitalSource Interface.
    
    The DigitalSource represents all the possible inputs for a counter or a
    quadrature encoder. The source may be either a digital input or an analog
    input. If the caller just provides a channel, then a digital input will be
    constructed and freed when finished for the source. The source can either be
    a digital input or analog trigger but not both.
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def getAnalogTriggerTypeForRouting(self) -> AnalogTriggerType:
        ...
    def getChannel(self) -> int:
        ...
    def getPortHandleForRouting(self) -> int:
        ...
    def isAnalogTrigger(self) -> bool:
        ...
class DoubleSolenoid(wpiutil._wpiutil.Sendable):
    """
    DoubleSolenoid class for running 2 channels of high voltage Digital Output
    on a pneumatics module.
    
    The DoubleSolenoid class is typically used for pneumatics solenoids that
    have two positions controlled by two separate channels.
    """
    class Value:
        """
        Possible values for a DoubleSolenoid.
        
        Members:
        
          kOff : Off position.
        
          kForward : Forward position.
        
          kReverse : Reverse position.
        """
        __members__: typing.ClassVar[dict[str, DoubleSolenoid.Value]]  # value = {'kOff': <Value.kOff: 0>, 'kForward': <Value.kForward: 1>, 'kReverse': <Value.kReverse: 2>}
        kForward: typing.ClassVar[DoubleSolenoid.Value]  # value = <Value.kForward: 1>
        kOff: typing.ClassVar[DoubleSolenoid.Value]  # value = <Value.kOff: 0>
        kReverse: typing.ClassVar[DoubleSolenoid.Value]  # value = <Value.kReverse: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    @typing.overload
    def __init__(self, module: typing.SupportsInt, moduleType: PneumaticsModuleType, forwardChannel: typing.SupportsInt, reverseChannel: typing.SupportsInt) -> None:
        """
        Constructs a double solenoid for a specified module of a specific module
        type.
        
        :param module:         The module of the solenoid module to use.
        :param moduleType:     The module type to use.
        :param forwardChannel: The forward channel on the module to control.
        :param reverseChannel: The reverse channel on the module to control.
        """
    @typing.overload
    def __init__(self, moduleType: PneumaticsModuleType, forwardChannel: typing.SupportsInt, reverseChannel: typing.SupportsInt) -> None:
        """
        Constructs a double solenoid for a default module of a specific module
        type.
        
        :param moduleType:     The module type to use.
        :param forwardChannel: The forward channel on the module to control.
        :param reverseChannel: The reverse channel on the module to control.
        """
    def get(self) -> DoubleSolenoid.Value:
        """
        Read the current value of the solenoid.
        
        :returns: The current value of the solenoid.
        """
    def getFwdChannel(self) -> int:
        """
        Get the forward channel.
        
        :returns: the forward channel.
        """
    def getRevChannel(self) -> int:
        """
        Get the reverse channel.
        
        :returns: the reverse channel.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isFwdSolenoidDisabled(self) -> bool:
        """
        Check if the forward solenoid is Disabled.
        
        If a solenoid is shorted, it is added to the DisabledList and disabled
        until power cycle, or until faults are cleared.
        
        @see ClearAllStickyFaults()
        
        :returns: If solenoid is disabled due to short.
        """
    def isRevSolenoidDisabled(self) -> bool:
        """
        Check if the reverse solenoid is Disabled.
        
        If a solenoid is shorted, it is added to the DisabledList and disabled
        until power cycle, or until faults are cleared.
        
        @see ClearAllStickyFaults()
        
        :returns: If solenoid is disabled due to short.
        """
    def set(self, value: DoubleSolenoid.Value) -> None:
        """
        Set the value of a solenoid.
        
        :param value: The value to set (Off, Forward or Reverse)
        """
    def toggle(self) -> None:
        """
        Toggle the value of the solenoid.
        
        If the solenoid is set to forward, it'll be set to reverse. If the solenoid
        is set to reverse, it'll be set to forward. If the solenoid is set to off,
        nothing happens.
        """
class DriverStation:
    """
    Provide access to the network communication data to / from the Driver
    Station.
    """
    class Alliance:
        """
        The robot alliance that the robot is a part of.
        
        Members:
        
          kRed : Red alliance.
        
          kBlue : Blue alliance.
        """
        __members__: typing.ClassVar[dict[str, DriverStation.Alliance]]  # value = {'kRed': <Alliance.kRed: 0>, 'kBlue': <Alliance.kBlue: 1>}
        kBlue: typing.ClassVar[DriverStation.Alliance]  # value = <Alliance.kBlue: 1>
        kRed: typing.ClassVar[DriverStation.Alliance]  # value = <Alliance.kRed: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class MatchType:
        """
        The type of robot match that the robot is part of.
        
        Members:
        
          kNone : None.
        
          kPractice : Practice.
        
          kQualification : Qualification.
        
          kElimination : Elimination.
        """
        __members__: typing.ClassVar[dict[str, DriverStation.MatchType]]  # value = {'kNone': <MatchType.kNone: 0>, 'kPractice': <MatchType.kPractice: 1>, 'kQualification': <MatchType.kQualification: 2>, 'kElimination': <MatchType.kElimination: 3>}
        kElimination: typing.ClassVar[DriverStation.MatchType]  # value = <MatchType.kElimination: 3>
        kNone: typing.ClassVar[DriverStation.MatchType]  # value = <MatchType.kNone: 0>
        kPractice: typing.ClassVar[DriverStation.MatchType]  # value = <MatchType.kPractice: 1>
        kQualification: typing.ClassVar[DriverStation.MatchType]  # value = <MatchType.kQualification: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    kJoystickPorts: typing.ClassVar[int] = 6
    @staticmethod
    def getAlliance() -> wpilib._wpilib.DriverStation.Alliance | None:
        """
        Get the current alliance from the FMS.
        
        If the FMS is not connected, it is set from the team alliance setting on
        the driver station.
        
        :returns: The alliance (red or blue) or an empty optional if the alliance is
                  invalid
        """
    @staticmethod
    def getBatteryVoltage() -> float:
        """
        Read the battery voltage.
        
        :returns: The battery voltage in Volts.
        """
    @staticmethod
    def getEventName() -> str:
        """
        Returns the name of the competition event provided by the FMS.
        
        :returns: A string containing the event name
        """
    @staticmethod
    def getGameSpecificMessage() -> str:
        """
        Returns the game specific message provided by the FMS.
        
        If the FMS is not connected, it is set from the game data setting on the
        driver station.
        
        :returns: A string containing the game specific message.
        """
    @staticmethod
    def getJoystickAxisType(stick: typing.SupportsInt, axis: typing.SupportsInt) -> int:
        """
        Returns the types of Axes on a given joystick port.
        
        :param stick: The joystick port number and the target axis
        :param axis:  The analog axis value to read from the joystick.
        
        :returns: What type of axis the axis is reporting to be
        """
    @staticmethod
    def getJoystickIsXbox(stick: typing.SupportsInt) -> bool:
        """
        Returns a boolean indicating if the controller is an xbox controller.
        
        :param stick: The joystick port number
        
        :returns: A boolean that is true if the controller is an xbox controller.
        """
    @staticmethod
    def getJoystickName(stick: typing.SupportsInt) -> str:
        """
        Returns the name of the joystick at the given port.
        
        :param stick: The joystick port number
        
        :returns: The name of the joystick at the given port
        """
    @staticmethod
    def getJoystickType(stick: typing.SupportsInt) -> int:
        """
        Returns the type of joystick at a given port.
        
        :param stick: The joystick port number
        
        :returns: The HID type of joystick at the given port
        """
    @staticmethod
    def getLocation() -> int | None:
        """
        Return the driver station location from the FMS.
        
        If the FMS is not connected, it is set from the team alliance setting on
        the driver station.
        
        This could return 1, 2, or 3.
        
        :returns: The location of the driver station (1-3, 0 for invalid)
        """
    @staticmethod
    def getMatchNumber() -> int:
        """
        Returns the match number provided by the FMS.
        
        :returns: The number of the match
        """
    @staticmethod
    def getMatchTime() -> wpimath.units.seconds:
        """
        Return the approximate match time. The FMS does not send an official match
        time to the robots, but does send an approximate match time. The value will
        count down the time remaining in the current period (auto or teleop).
        Warning: This is not an official time (so it cannot be used to dispute ref
        calls or guarantee that a function will trigger before the match ends).
        
        When connected to the real field, this number only changes in full
        integer increments, and always counts down.
        
        When the DS is in practice mode, this number is a floating point number,
        and counts down.
        
        When the DS is in teleop or autonomous mode, this number is a floating
        point number, and counts up.
        
        Simulation matches DS behavior without an FMS connected.
        
        :returns: Time remaining in current match period (auto or teleop) in seconds
        """
    @staticmethod
    def getMatchType() -> DriverStation.MatchType:
        """
        Returns the type of match being played provided by the FMS.
        
        :returns: The match type enum (kNone, kPractice, kQualification,
                  kElimination)
        """
    @staticmethod
    def getReplayNumber() -> int:
        """
        Returns the number of times the current match has been replayed from the
        FMS.
        
        :returns: The number of replays
        """
    @staticmethod
    def getStickAxis(stick: typing.SupportsInt, axis: typing.SupportsInt) -> float:
        """
        Get the value of the axis on a joystick.
        
        This depends on the mapping of the joystick connected to the specified
        port.
        
        :param stick: The joystick to read.
        :param axis:  The analog axis value to read from the joystick.
        
        :returns: The value of the axis on the joystick.
        """
    @staticmethod
    def getStickAxisCount(stick: typing.SupportsInt) -> int:
        """
        Returns the number of axes on a given joystick port.
        
        :param stick: The joystick port number
        
        :returns: The number of axes on the indicated joystick
        """
    @staticmethod
    def getStickButton(stick: typing.SupportsInt, button: typing.SupportsInt) -> bool:
        """
        The state of one joystick button. %Button indexes begin at 1.
        
        :param stick:  The joystick to read.
        :param button: The button index, beginning at 1.
        
        :returns: The state of the joystick button.
        """
    @staticmethod
    def getStickButtonCount(stick: typing.SupportsInt) -> int:
        """
        Returns the number of buttons on a given joystick port.
        
        :param stick: The joystick port number
        
        :returns: The number of buttons on the indicated joystick
        """
    @staticmethod
    def getStickButtonPressed(stick: typing.SupportsInt, button: typing.SupportsInt) -> bool:
        """
        Whether one joystick button was pressed since the last check. %Button
        indexes begin at 1.
        
        :param stick:  The joystick to read.
        :param button: The button index, beginning at 1.
        
        :returns: Whether the joystick button was pressed since the last check.
        """
    @staticmethod
    def getStickButtonReleased(stick: typing.SupportsInt, button: typing.SupportsInt) -> bool:
        """
        Whether one joystick button was released since the last check. %Button
        indexes begin at 1.
        
        :param stick:  The joystick to read.
        :param button: The button index, beginning at 1.
        
        :returns: Whether the joystick button was released since the last check.
        """
    @staticmethod
    def getStickButtons(stick: typing.SupportsInt) -> int:
        """
        The state of the buttons on the joystick.
        
        :param stick: The joystick to read.
        
        :returns: The state of the buttons on the joystick.
        """
    @staticmethod
    def getStickPOV(stick: typing.SupportsInt, pov: typing.SupportsInt) -> int:
        """
        Get the state of a POV on the joystick.
        
        :returns: the angle of the POV in degrees, or -1 if the POV is not pressed.
        """
    @staticmethod
    def getStickPOVCount(stick: typing.SupportsInt) -> int:
        """
        Returns the number of POVs on a given joystick port.
        
        :param stick: The joystick port number
        
        :returns: The number of POVs on the indicated joystick
        """
    @staticmethod
    def isAutonomous() -> bool:
        """
        Check if the DS is commanding autonomous mode.
        
        :returns: True if the robot is being commanded to be in autonomous mode
        """
    @staticmethod
    def isAutonomousEnabled() -> bool:
        """
        Check if the DS is commanding autonomous mode and if it has enabled the
        robot.
        
        :returns: True if the robot is being commanded to be in autonomous mode and
                  enabled.
        """
    @staticmethod
    def isDSAttached() -> bool:
        """
        Check if the DS is attached.
        
        :returns: True if the DS is connected to the robot
        """
    @staticmethod
    def isDisabled() -> bool:
        """
        Check if the robot is disabled.
        
        :returns: True if the robot is explicitly disabled or the DS is not connected
        """
    @staticmethod
    def isEStopped() -> bool:
        """
        Check if the robot is e-stopped.
        
        :returns: True if the robot is e-stopped
        """
    @staticmethod
    def isEnabled() -> bool:
        """
        Check if the DS has enabled the robot.
        
        :returns: True if the robot is enabled and the DS is connected
        """
    @staticmethod
    def isFMSAttached() -> bool:
        """
        Is the driver station attached to a Field Management System?
        
        :returns: True if the robot is competing on a field being controlled by a
                  Field Management System
        """
    @staticmethod
    def isJoystickConnected(stick: typing.SupportsInt) -> bool:
        """
        Returns if a joystick is connected to the Driver Station.
        
        This makes a best effort guess by looking at the reported number of axis,
        buttons, and POVs attached.
        
        :param stick: The joystick port number
        
        :returns: true if a joystick is connected
        """
    @staticmethod
    def isJoystickConnectionWarningSilenced() -> bool:
        """
        Returns whether joystick connection warnings are silenced. This will
        always return false when connected to the FMS.
        
        :returns: Whether joystick connection warnings are silenced.
        """
    @staticmethod
    def isTeleop() -> bool:
        """
        Check if the DS is commanding teleop mode.
        
        :returns: True if the robot is being commanded to be in teleop mode
        """
    @staticmethod
    def isTeleopEnabled() -> bool:
        """
        Check if the DS is commanding teleop mode and if it has enabled the robot.
        
        :returns: True if the robot is being commanded to be in teleop mode and
                  enabled.
        """
    @staticmethod
    def isTest() -> bool:
        """
        Check if the DS is commanding test mode.
        
        :returns: True if the robot is being commanded to be in test mode
        """
    @staticmethod
    def isTestEnabled() -> bool:
        """
        Check if the DS is commanding Test mode and if it has enabled the robot.
        
        :returns: True if the robot is being commanded to be in Test mode and
                  enabled.
        """
    @staticmethod
    def provideRefreshedDataEventHandle(handle: typing.SupportsInt) -> None:
        """
        Registers the given handle for DS data refresh notifications.
        
        :param handle: The event handle.
        """
    @staticmethod
    def refreshData() -> None:
        """
        Copy data from the DS task for the user. If no new data exists, it will
        just be returned, otherwise the data will be copied from the DS polling
        loop.
        """
    @staticmethod
    def removeRefreshedDataEventHandle(handle: typing.SupportsInt) -> None:
        """
        Unregisters the given handle from DS data refresh notifications.
        
        :param handle: The event handle.
        """
    @staticmethod
    def silenceJoystickConnectionWarning(silence: bool) -> None:
        """
        Allows the user to specify whether they want joystick connection warnings
        to be printed to the console. This setting is ignored when the FMS is
        connected -- warnings will always be on in that scenario.
        
        :param silence: Whether warning messages should be silenced.
        """
    @staticmethod
    def startDataLog(log: wpiutil._wpiutil.log.DataLog, logJoysticks: bool = True) -> None:
        """
        Starts logging DriverStation data to data log. Repeated calls are ignored.
        
        :param log:          data log
        :param logJoysticks: if true, log joystick data
        """
    @staticmethod
    def waitForDsConnection(timeout: wpimath.units.seconds) -> bool:
        """
        Wait for a DS connection.
        
        :param timeout: timeout in seconds. 0 for infinite.
        
        :returns: true if connected, false if timeout
        """
    def getControlState(self) -> tuple[bool, bool, bool]:
        """
        More efficient way to determine what state the robot is in.
        
        :returns: booleans representing enabled, isautonomous, istest
        
        .. versionadded:: 2019.2.1
        
        .. note:: This function only exists in RobotPy
        """
class DutyCycle(wpiutil._wpiutil.Sendable):
    """
    Class to read a duty cycle PWM input.
    
    PWM input signals are specified with a frequency and a ratio of high to
    low in that frequency. There are 8 of these in the roboRIO, and they can be
    attached to any DigitalSource.
    
    These can be combined as the input of an AnalogTrigger to a Counter in
    order to implement rollover checking.
    """
    def __init__(self, source: DigitalSource) -> None:
        """
        Constructs a DutyCycle input from a DigitalSource input.
        
        This class does not own the inputted source.
        
        :param source: The DigitalSource to use.
        """
    def __repr__(self) -> str:
        ...
    def _initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def getFPGAIndex(self) -> int:
        """
        Get the FPGA index for the DutyCycle.
        
        :returns: the FPGA index
        """
    def getFrequency(self) -> int:
        """
        Get the frequency of the duty cycle signal.
        
        :returns: frequency in Hertz
        """
    def getHighTime(self) -> wpimath.units.seconds:
        """
        Get the raw high time of the duty cycle signal.
        
        :returns: high time of last pulse
        """
    def getOutput(self) -> float:
        """
        Get the output ratio of the duty cycle signal.
        
        0 means always low, 1 means always high.
        
        :returns: output ratio between 0 and 1
        """
    def getSourceChannel(self) -> int:
        """
        Get the channel of the source.
        
        :returns: the source channel
        """
class DutyCycleEncoder(wpiutil._wpiutil.Sendable):
    """
    Class for supporting duty cycle/PWM encoders, such as the US Digital MA3 with
    PWM Output, the CTRE Mag Encoder, the Rev Hex Encoder, and the AM Mag
    Encoder.
    """
    @typing.overload
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Construct a new DutyCycleEncoder on a specific channel.
        
        This has a fullRange of 1 and an expectedZero of 0.
        
        :param channel: the channel to attach to
        """
    @typing.overload
    def __init__(self, dutyCycle: DutyCycle) -> None:
        """
        Construct a new DutyCycleEncoder attached to an existing DutyCycle object.
        
        This has a fullRange of 1 and an expectedZero of 0.
        
        :param dutyCycle: the duty cycle to attach to
        """
    @typing.overload
    def __init__(self, digitalSource: DigitalSource) -> None:
        """
        Construct a new DutyCycleEncoder attached to a DigitalSource object.
        
        This has a fullRange of 1 and an expectedZero of 0.
        
        :param digitalSource: the digital source to attach to
        """
    @typing.overload
    def __init__(self, channel: typing.SupportsInt, fullRange: typing.SupportsFloat, expectedZero: typing.SupportsFloat) -> None:
        """
        Construct a new DutyCycleEncoder on a specific channel.
        
        :param channel:      the channel to attach to
        :param fullRange:    the value to report at maximum travel
        :param expectedZero: the reading where you would expect a 0 from get()
        """
    @typing.overload
    def __init__(self, dutyCycle: DutyCycle, fullRange: typing.SupportsFloat, expectedZero: typing.SupportsFloat) -> None:
        """
        Construct a new DutyCycleEncoder attached to an existing DutyCycle object.
        
        :param dutyCycle:    the duty cycle to attach to
        :param fullRange:    the value to report at maximum travel
        :param expectedZero: the reading where you would expect a 0 from get()
        """
    @typing.overload
    def __init__(self, digitalSource: DigitalSource, fullRange: typing.SupportsFloat, expectedZero: typing.SupportsFloat) -> None:
        """
        Construct a new DutyCycleEncoder attached to a DigitalSource object.
        
        :param digitalSource: the digital source to attach to
        :param fullRange:     the value to report at maximum travel
        :param expectedZero:  the reading where you would expect a 0 from get()
        """
    def __repr__(self) -> str:
        ...
    def get(self) -> float:
        """
        Get the encoder value.
        
        :returns: the encoder value scaled by the full range input
        """
    def getFPGAIndex(self) -> int:
        """
        Get the FPGA index for the DutyCycleEncoder.
        
        :returns: the FPGA index
        """
    def getFrequency(self) -> int:
        """
        Get the frequency in Hz of the duty cycle signal from the encoder.
        
        :returns: duty cycle frequency in Hz
        """
    def getSourceChannel(self) -> int:
        """
        Get the channel of the source.
        
        :returns: the source channel
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isConnected(self) -> bool:
        """
        Get if the sensor is connected
        
        This uses the duty cycle frequency to determine if the sensor is connected.
        By default, a value of 100 Hz is used as the threshold, and this value can
        be changed with SetConnectedFrequencyThreshold.
        
        :returns: true if the sensor is connected
        """
    def setAssumedFrequency(self, frequency: wpimath.units.hertz) -> None:
        """
        Sets the assumed frequency of the connected device.
        
        By default, the DutyCycle engine has to compute the frequency of the
        input signal. This can result in both delayed readings and jumpy readings.
        To solve this, you can pass the expected frequency of the sensor to this
        function. This will use that frequency to compute the DutyCycle percentage,
        rather than the computed frequency.
        
        :param frequency: the assumed frequency of the sensor
        """
    def setConnectedFrequencyThreshold(self, frequency: typing.SupportsInt) -> None:
        """
        Change the frequency threshold for detecting connection used by
        IsConnected.
        
        :param frequency: the minimum frequency in Hz.
        """
    def setDutyCycleRange(self, min: typing.SupportsFloat, max: typing.SupportsFloat) -> None:
        """
        Set the encoder duty cycle range. As the encoder needs to maintain a duty
        cycle, the duty cycle cannot go all the way to 0% or all the way to 100%.
        For example, an encoder with a 4096 us period might have a minimum duty
        cycle of 1 us / 4096 us and a maximum duty cycle of 4095 / 4096 us. Setting
        the range will result in an encoder duty cycle less than or equal to the
        minimum being output as 0 rotation, the duty cycle greater than or equal to
        the maximum being output as 1 rotation, and values in between linearly
        scaled from 0 to 1.
        
        :param min: minimum duty cycle (0-1 range)
        :param max: maximum duty cycle (0-1 range)
        """
    def setInverted(self, inverted: bool) -> None:
        """
        Set if this encoder is inverted.
        
        :param inverted: true to invert the encoder, false otherwise
        """
class Encoder(wpilib.interfaces._interfaces.CounterBase, wpiutil._wpiutil.Sendable):
    """
    Class to read quad encoders.
    
    Quadrature encoders are devices that count shaft rotation and can sense
    direction. The output of the QuadEncoder class is an integer that can count
    either up or down, and can go negative for reverse direction counting. When
    creating QuadEncoders, a direction is supplied that changes the sense of the
    output to make code more readable if the encoder is mounted such that forward
    movement generates negative values. Quadrature encoders have two digital
    outputs, an A Channel and a B Channel that are out of phase with each other
    to allow the FPGA to do direction sensing.
    
    All encoders will immediately start counting - Reset() them if you need them
    to be zeroed before use.
    """
    class IndexingType:
        """
        Encoder indexing types.
        
        Members:
        
          kResetWhileHigh : Reset while the signal is high.
        
          kResetWhileLow : Reset while the signal is low.
        
          kResetOnFallingEdge : Reset on falling edge of the signal.
        
          kResetOnRisingEdge : Reset on rising edge of the signal.
        """
        __members__: typing.ClassVar[dict[str, Encoder.IndexingType]]  # value = {'kResetWhileHigh': <IndexingType.kResetWhileHigh: 0>, 'kResetWhileLow': <IndexingType.kResetWhileLow: 1>, 'kResetOnFallingEdge': <IndexingType.kResetOnFallingEdge: 2>, 'kResetOnRisingEdge': <IndexingType.kResetOnRisingEdge: 3>}
        kResetOnFallingEdge: typing.ClassVar[Encoder.IndexingType]  # value = <IndexingType.kResetOnFallingEdge: 2>
        kResetOnRisingEdge: typing.ClassVar[Encoder.IndexingType]  # value = <IndexingType.kResetOnRisingEdge: 3>
        kResetWhileHigh: typing.ClassVar[Encoder.IndexingType]  # value = <IndexingType.kResetWhileHigh: 0>
        kResetWhileLow: typing.ClassVar[Encoder.IndexingType]  # value = <IndexingType.kResetWhileLow: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    @typing.overload
    def __init__(self, aChannel: typing.SupportsInt, bChannel: typing.SupportsInt, reverseDirection: bool = False, encodingType: wpilib.interfaces._interfaces.CounterBase.EncodingType = ...) -> None:
        """
        Encoder constructor.
        
        Construct a Encoder given a and b channels.
        
        The counter will start counting immediately.
        
        :param aChannel:         The a channel DIO channel. 0-9 are on-board, 10-25
                                 are on the MXP port
        :param bChannel:         The b channel DIO channel. 0-9 are on-board, 10-25
                                 are on the MXP port
        :param reverseDirection: represents the orientation of the encoder and
                                 inverts the output values if necessary so forward
                                 represents positive values.
        :param encodingType:     either k1X, k2X, or k4X to indicate 1X, 2X or 4X
                                 decoding. If 4X is selected, then an encoder FPGA
                                 object is used and the returned counts will be 4x
                                 the encoder spec'd value since all rising and
                                 falling edges are counted. If 1X or 2X are selected
                                 then a counter object will be used and the returned
                                 value will either exactly match the spec'd count or
                                 be double (2x) the spec'd count.
        """
    @typing.overload
    def __init__(self, aSource: DigitalSource, bSource: DigitalSource, reverseDirection: bool = False, encodingType: wpilib.interfaces._interfaces.CounterBase.EncodingType = ...) -> None:
        ...
    def get(self) -> int:
        """
        Gets the current count.
        
        Returns the current count on the Encoder. This method compensates for the
        decoding type.
        
        :returns: Current count from the Encoder adjusted for the 1x, 2x, or 4x scale
                  factor.
        """
    def getDirection(self) -> bool:
        """
        The last direction the encoder value changed.
        
        :returns: The last direction the encoder value changed.
        """
    def getDistance(self) -> float:
        """
        Get the distance the robot has driven since the last reset.
        
        :returns: The distance driven since the last reset as scaled by the value
                  from SetDistancePerPulse().
        """
    def getDistancePerPulse(self) -> float:
        """
        Get the distance per pulse for this encoder.
        
        :returns: The scale factor that will be used to convert pulses to useful
                  units.
        """
    def getEncodingScale(self) -> int:
        """
        The encoding scale factor 1x, 2x, or 4x, per the requested encodingType.
        
        Used to divide raw edge counts down to spec'd counts.
        """
    def getFPGAIndex(self) -> int:
        ...
    def getPeriod(self) -> wpimath.units.seconds:
        """
        Returns the period of the most recent pulse.
        
        Returns the period of the most recent Encoder pulse in seconds. This method
        compensates for the decoding type.
        
        Warning: This returns unscaled periods. Use GetRate() for rates that are
        scaled using the value from SetDistancePerPulse().
        
        :deprecated: Use getRate() in favor of this method.
        
        :returns: Period in seconds of the most recent pulse.
        """
    def getRate(self) -> float:
        """
        Get the current rate of the encoder.
        
        Units are distance per second as scaled by the value from
        SetDistancePerPulse().
        
        :returns: The current rate of the encoder.
        """
    def getRaw(self) -> int:
        """
        Gets the raw value from the encoder.
        
        The raw value is the actual count unscaled by the 1x, 2x, or 4x scale
        factor.
        
        :returns: Current raw count from the encoder
        """
    def getSamplesToAverage(self) -> int:
        """
        Get the Samples to Average which specifies the number of samples of the
        timer to average when calculating the period.
        
        Perform averaging to account for mechanical imperfections or as
        oversampling to increase resolution.
        
        :returns: The number of samples being averaged (from 1 to 127)
        """
    def getStopped(self) -> bool:
        """
        Determine if the encoder is stopped.
        
        Using the MaxPeriod value, a boolean is returned that is true if the
        encoder is considered stopped and false if it is still moving. A stopped
        encoder is one where the most recent pulse width exceeds the MaxPeriod.
        
        :returns: True if the encoder is considered stopped.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def reset(self) -> None:
        """
        Reset the Encoder distance to zero.
        
        Resets the current count to zero on the encoder.
        """
    def setDistancePerPulse(self, distancePerPulse: typing.SupportsFloat) -> None:
        """
        Set the distance per pulse for this encoder.
        
        This sets the multiplier used to determine the distance driven based on the
        count value from the encoder.
        
        Do not include the decoding type in this scale.  The library already
        compensates for the decoding type.
        
        Set this value based on the encoder's rated Pulses per Revolution and
        factor in gearing reductions following the encoder shaft.
        
        This distance can be in any units you like, linear or angular.
        
        :param distancePerPulse: The scale factor that will be used to convert
                                 pulses to useful units.
        """
    @typing.overload
    def setIndexSource(self, channel: typing.SupportsInt, type: Encoder.IndexingType = ...) -> None:
        """
        Set the index source for the encoder.
        
        When this source is activated, the encoder count automatically resets.
        
        :param channel: A DIO channel to set as the encoder index
        :param type:    The state that will cause the encoder to reset
        """
    @typing.overload
    def setIndexSource(self, source: DigitalSource, type: Encoder.IndexingType = ...) -> None:
        """
        Set the index source for the encoder.
        
        When this source is activated, the encoder count automatically resets.
        
        :param source: A digital source to set as the encoder index
        :param type:   The state that will cause the encoder to reset
        """
    def setMaxPeriod(self, maxPeriod: wpimath.units.seconds) -> None:
        """
        Sets the maximum period for stopped detection.
        
        Sets the value that represents the maximum period of the Encoder before it
        will assume that the attached device is stopped. This timeout allows users
        to determine if the wheels or other shaft has stopped rotating.
        This method compensates for the decoding type.
        
        :deprecated: Use SetMinRate() in favor of this method.  This takes unscaled
                     periods and SetMinRate() scales using value from
                     SetDistancePerPulse().
        
        :param maxPeriod: The maximum time between rising and falling edges before
                          the FPGA will report the device stopped. This is expressed
                          in seconds.
        """
    def setMinRate(self, minRate: typing.SupportsFloat) -> None:
        """
        Set the minimum rate of the device before the hardware reports it stopped.
        
        :param minRate: The minimum rate.  The units are in distance per second as
                        scaled by the value from SetDistancePerPulse().
        """
    def setReverseDirection(self, reverseDirection: bool) -> None:
        """
        Set the direction sensing for this encoder.
        
        This sets the direction sensing on the encoder so that it could count in
        the correct software direction regardless of the mounting.
        
        :param reverseDirection: true if the encoder direction should be reversed
        """
    def setSamplesToAverage(self, samplesToAverage: typing.SupportsInt) -> None:
        """
        Set the Samples to Average which specifies the number of samples of the
        timer to average when calculating the period.
        
        Perform averaging to account for mechanical imperfections or as
        oversampling to increase resolution.
        
        :param samplesToAverage: The number of samples to average from 1 to 127.
        """
    def setSimDevice(self, device: typing.SupportsInt) -> None:
        """
        Indicates this encoder is used by a simulated device.
        
        :param device: simulated device handle
        """
class Field2d(ntcore._ntcore.NTSendable):
    """
    2D representation of game field for dashboards.
    
    An object's pose is the location shown on the dashboard view.  Note that
    for the robot, this may or may not match the internal odometry.  For example,
    if the robot is shown at a particular starting location, the pose in this
    class would represent the actual location on the field, but the robot's
    internal state might have a 0,0,0 pose (unless it's initialized to
    something different).
    
    As the user is able to edit the pose, code performing updates should get
    the robot pose, transform it as appropriate (e.g. based on wheel odometry),
    and set the new pose.
    
    This class provides methods to set the robot pose, but other objects can
    also be shown by using the GetObject() function.  Other objects can
    also have multiple poses (which will show the object at multiple locations).
    """
    def __init__(self) -> None:
        ...
    def getObject(self, name: str) -> FieldObject2d:
        """
        Get or create a field object.
        
        :returns: Field object
        """
    def getRobotObject(self) -> FieldObject2d:
        """
        Get the robot object.
        
        :returns: Field object for robot
        """
    def getRobotPose(self) -> wpimath.geometry._geometry.Pose2d:
        """
        Get the robot pose.
        
        :returns: 2D pose
        """
    def initSendable(self, builder: ntcore._ntcore.NTSendableBuilder) -> None:
        ...
    @typing.overload
    def setRobotPose(self, pose: wpimath.geometry._geometry.Pose2d) -> None:
        """
        Set the robot pose from a Pose object.
        
        :param pose: 2D pose
        """
    @typing.overload
    def setRobotPose(self, x: wpimath.units.meters, y: wpimath.units.meters, rotation: wpimath.geometry._geometry.Rotation2d) -> None:
        """
        Set the robot pose from x, y, and rotation.
        
        :param x:        X location
        :param y:        Y location
        :param rotation: rotation
        """
class FieldObject2d:
    """
    Game field object on a Field2d.
    """
    def getPose(self) -> wpimath.geometry._geometry.Pose2d:
        """
        Get the pose.
        
        :returns: 2D pose, or 0,0,0 if unknown / does not exist
        """
    def getPoses(self) -> list[wpimath.geometry._geometry.Pose2d]:
        """
        Get multiple poses.
        
        :returns: vector of 2D poses
        """
    @typing.overload
    def setPose(self, pose: wpimath.geometry._geometry.Pose2d) -> None:
        """
        Set the pose from a Pose object.
        
        :param pose: 2D pose
        """
    @typing.overload
    def setPose(self, x: wpimath.units.meters, y: wpimath.units.meters, rotation: wpimath.geometry._geometry.Rotation2d) -> None:
        """
        Set the pose from x, y, and rotation.
        
        :param x:        X location
        :param y:        Y location
        :param rotation: rotation
        """
    def setPoses(self, poses: list[wpimath.geometry._geometry.Pose2d]) -> None:
        """
        Set multiple poses from an array of Pose objects.
        The total number of poses is limited to 85.
        
        :param poses: array of 2D poses
        """
    def setTrajectory(self, trajectory: wpimath._controls._controls.trajectory.Trajectory) -> None:
        """
        Sets poses from a trajectory.
        
        :param trajectory: The trajectory from which poses should be added.
        """
class I2C:
    """
    I2C bus interface class.
    
    This class is intended to be used by sensor (and other I2C device) drivers.
    It probably should not be used directly.
    
    The Onboard I2C port is subject to system lockups. See <a
    href="https://docs.wpilib.org/en/stable/docs/yearly-overview/known-issues.html#onboard-i2c-causing-system-lockups">
    WPILib Known Issues</a> page for details.
    """
    class Port:
        """
        I2C connection ports.
        
        Members:
        
          kOnboard : Onboard I2C port.
        
          kMXP : MXP (roboRIO MXP) I2C port.
        """
        __members__: typing.ClassVar[dict[str, I2C.Port]]  # value = {'kOnboard': <Port.kOnboard: 0>, 'kMXP': <Port.kMXP: 1>}
        kMXP: typing.ClassVar[I2C.Port]  # value = <Port.kMXP: 1>
        kOnboard: typing.ClassVar[I2C.Port]  # value = <Port.kOnboard: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self, port: I2C.Port, deviceAddress: typing.SupportsInt) -> None:
        """
        Constructor.
        
        :param port:          The I2C port to which the device is connected.
        :param deviceAddress: The address of the device on the I2C bus.
        """
    def addressOnly(self) -> bool:
        """
        Attempt to address a device on the I2C bus.
        
        This allows you to figure out if there is a device on the I2C bus that
        responds to the address specified in the constructor.
        
        :returns: Transfer Aborted... false for success, true for aborted.
        """
    def getDeviceAddress(self) -> int:
        """
        Returns I2C device address.
        
        :returns: I2C device address.
        """
    def getPort(self) -> I2C.Port:
        """
        Returns I2C port.
        
        :returns: I2C port.
        """
    def read(self, registerAddress: typing.SupportsInt, data: typing_extensions.Buffer) -> bool:
        """
        Execute a read transaction with the device.
        
        Read bytes from a device.
        Most I2C devices will auto-increment the register pointer internally
        allowing you to read consecutive registers on a device in a single
        transaction.
        
        :param registerAddress: The register to read first in the transaction.
        :param count:           The number of bytes to read in the transaction.
        :param data:            A pointer to the array of bytes to store the data
                                read from the device.
        
        :returns: Transfer Aborted... false for success, true for aborted.
        """
    def readOnly(self, buffer: typing_extensions.Buffer) -> bool:
        """
        Execute a read only transaction with the device.
        
        Read bytes from a device. This method does not write any data to prompt the
        device.
        
        :param buffer: A pointer to the array of bytes to store the data read from
                       the device.
        :param count:  The number of bytes to read in the transaction.
        
        :returns: Transfer Aborted... false for success, true for aborted.
        """
    def transaction(self, dataToSend: typing_extensions.Buffer, dataReceived: typing_extensions.Buffer) -> bool:
        """
        Generic transaction.
        
        This is a lower-level interface to the I2C hardware giving you more control
        over each transaction. If you intend to write multiple bytes in the same
        transaction and do not plan to receive anything back, use writeBulk()
        instead. Calling this with a receiveSize of 0 will result in an error.
        
        :param dataToSend:   Buffer of data to send as part of the transaction.
        :param sendSize:     Number of bytes to send as part of the transaction.
        :param dataReceived: Buffer to read data into.
        :param receiveSize:  Number of bytes to read from the device.
        
        :returns: Transfer Aborted... false for success, true for aborted.
        """
    def verifySensor(self, registerAddress: typing.SupportsInt, expected: typing_extensions.Buffer) -> bool:
        """
        Verify that a device's registers contain expected values.
        
        Most devices will have a set of registers that contain a known value that
        can be used to identify them.  This allows an I2C device driver to easily
        verify that the device contains the expected value.
        
        @pre The device must support and be configured to use register
        auto-increment.
        
        :param registerAddress: The base register to start reading from the device.
        :param count:           The size of the field to be verified.
        :param expected:        A buffer containing the values expected from the
                                device.
        """
    def write(self, registerAddress: typing.SupportsInt, data: typing.SupportsInt) -> bool:
        """
        Execute a write transaction with the device.
        
        Write a single byte to a register on a device and wait until the
        transaction is complete.
        
        :param registerAddress: The address of the register on the device to be
                                written.
        :param data:            The byte to write to the register on the device.
        
        :returns: Transfer Aborted... false for success, true for aborted.
        """
    def writeBulk(self, data: typing_extensions.Buffer) -> bool:
        """
        Execute a bulk write transaction with the device.
        
        Write multiple bytes to a device and wait until the
        transaction is complete.
        
        :param data:  The data to write to the register on the device.
        :param count: The number of bytes to be written.
        
        :returns: Transfer Aborted... false for success, true for aborted.
        """
class IterativeRobotBase(RobotBase):
    """
    IterativeRobotBase implements a specific type of robot program framework,
    extending the RobotBase class.
    
    The IterativeRobotBase class does not implement StartCompetition(), so it
    should not be used by teams directly.
    
    This class provides the following functions which are called by the main
    loop, StartCompetition(), at the appropriate times:
    
    RobotInit() -- provide for initialization at robot power-on
    
    Init() functions -- each of the following functions is called once when the
    appropriate mode is entered:
    
    - DisabledInit() -- called each and every time disabled is entered from another mode
    - AutonomousInit() -- called each and every time autonomous is entered from another mode
    - TeleopInit() -- called each and every time teleop is entered from another mode
    - TestInit() -- called each and every time test is entered from another mode
    
    Periodic() functions -- each of these functions is called on an interval:
    
    - RobotPeriodic()
    - DisabledPeriodic()
    - AutonomousPeriodic()
    - TeleopPeriodic()
    - TestPeriodic()
    
    Exit() functions -- each of the following functions is called once when the
    appropriate mode is exited:
    
    - DisabledExit() -- called each and every time disabled is exited
    - AutonomousExit() -- called each and every time autonomous is exited
    - TeleopExit() -- called each and every time teleop is exited
    - TestExit() -- called each and every time test is exited
    """
    def __init__(self, period: wpimath.units.seconds) -> None:
        """
        Constructor for IterativeRobotBase.
        
        :param period: Period.
        """
    def _loopFunc(self) -> None:
        """
        Loop function.
        """
    def _simulationInit(self) -> None:
        """
        Robot-wide simulation initialization code should go here.
        
        Users should override this method for default Robot-wide simulation
        related initialization which will be called when the robot is first
        started. It will be called exactly one time after RobotInit is called
        only when the robot is in simulation.
        """
    def _simulationPeriodic(self) -> None:
        """
        Periodic simulation code should go here.
        
        This function is called in a simulated robot after user code executes.
        """
    def autonomousExit(self) -> None:
        """
        Exit code for autonomous mode should go here.
        
        Users should override this method for code which will be called each time
        the robot exits autonomous mode.
        """
    def autonomousInit(self) -> None:
        """
        Initialization code for autonomous mode should go here.
        
        Users should override this method for initialization code which will be
        called each time the robot enters autonomous mode.
        """
    def autonomousPeriodic(self) -> None:
        """
        Periodic code for autonomous mode should go here.
        
        Users should override this method for code which will be called each time a
        new packet is received from the driver station and the robot is in
        autonomous mode.
        """
    def disabledExit(self) -> None:
        """
        Exit code for disabled mode should go here.
        
        Users should override this method for code which will be called each time
        the robot exits disabled mode.
        """
    def disabledInit(self) -> None:
        """
        Initialization code for disabled mode should go here.
        
        Users should override this method for initialization code which will be
        called each time
        the robot enters disabled mode.
        """
    def disabledPeriodic(self) -> None:
        """
        Periodic code for disabled mode should go here.
        
        Users should override this method for code which will be called each time a
        new packet is received from the driver station and the robot is in disabled
        mode.
        """
    def driverStationConnected(self) -> None:
        """
        Code that needs to know the DS state should go here.
        
        Users should override this method for initialization that needs to occur
        after the DS is connected, such as needing the alliance information.
        """
    def enableLiveWindowInTest(self, testLW: bool) -> None:
        """
        Sets whether LiveWindow operation is enabled during test mode.
        
        :param testLW: True to enable, false to disable. Defaults to false.
                       @throws if called in test mode.
        """
    def getPeriod(self) -> wpimath.units.seconds:
        """
        Gets time period between calls to Periodic() functions.
        """
    def isLiveWindowEnabledInTest(self) -> bool:
        """
        Whether LiveWindow operation is enabled during test mode.
        """
    def printWatchdogEpochs(self) -> None:
        """
        Prints list of epochs added so far and their times.
        """
    def robotInit(self) -> None:
        """
        Robot-wide initialization code should go here.
        
        Users should override this method for default Robot-wide initialization
        which will be called when the robot is first powered on. It will be called
        exactly one time.
        
        Note: This method is functionally identical to the class constructor so
        that should be used instead.
        """
    def robotPeriodic(self) -> None:
        """
        Periodic code for all modes should go here.
        
        This function is called each time a new packet is received from the driver
        station.
        """
    def setNetworkTablesFlushEnabled(self, enabled: bool) -> None:
        """
        Enables or disables flushing NetworkTables every loop iteration.
        By default, this is enabled.
        
        :deprecated: Deprecated without replacement.
        
        :param enabled: True to enable, false to disable
        """
    def teleopExit(self) -> None:
        """
        Exit code for teleop mode should go here.
        
        Users should override this method for code which will be called each time
        the robot exits teleop mode.
        """
    def teleopInit(self) -> None:
        """
        Initialization code for teleop mode should go here.
        
        Users should override this method for initialization code which will be
        called each time the robot enters teleop mode.
        """
    def teleopPeriodic(self) -> None:
        """
        Periodic code for teleop mode should go here.
        
        Users should override this method for code which will be called each time a
        new packet is received from the driver station and the robot is in teleop
        mode.
        """
    def testExit(self) -> None:
        """
        Exit code for test mode should go here.
        
        Users should override this method for code which will be called each time
        the robot exits test mode.
        """
    def testInit(self) -> None:
        """
        Initialization code for test mode should go here.
        
        Users should override this method for initialization code which will be
        called each time the robot enters test mode.
        """
    def testPeriodic(self) -> None:
        """
        Periodic code for test mode should go here.
        
        Users should override this method for code which will be called each time a
        new packet is received from the driver station and the robot is in test
        mode.
        """
class Joystick(wpilib.interfaces._interfaces.GenericHID):
    """
    Handle input from standard Joysticks connected to the Driver Station.
    
    This class handles standard input that comes from the Driver Station. Each
    time a value is requested the most recent value is returned. There is a
    single class instance for each joystick and the mapping of ports to hardware
    buttons depends on the code in the Driver Station.
    """
    class AxisType:
        """
        Represents an analog axis on a joystick.
        
        Members:
        
          kXAxis : X axis.
        
          kYAxis : Y axis.
        
          kZAxis : Z axis.
        
          kTwistAxis : Twist axis.
        
          kThrottleAxis : Throttle axis.
        """
        __members__: typing.ClassVar[dict[str, Joystick.AxisType]]  # value = {'kXAxis': <AxisType.kXAxis: 0>, 'kYAxis': <AxisType.kYAxis: 1>, 'kZAxis': <AxisType.kZAxis: 2>, 'kTwistAxis': <AxisType.kTwistAxis: 3>, 'kThrottleAxis': <AxisType.kThrottleAxis: 4>}
        kThrottleAxis: typing.ClassVar[Joystick.AxisType]  # value = <AxisType.kThrottleAxis: 4>
        kTwistAxis: typing.ClassVar[Joystick.AxisType]  # value = <AxisType.kTwistAxis: 3>
        kXAxis: typing.ClassVar[Joystick.AxisType]  # value = <AxisType.kXAxis: 0>
        kYAxis: typing.ClassVar[Joystick.AxisType]  # value = <AxisType.kYAxis: 1>
        kZAxis: typing.ClassVar[Joystick.AxisType]  # value = <AxisType.kZAxis: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class ButtonType:
        """
        Represents a digital button on a joystick.
        
        Members:
        
          kTriggerButton : kTrigger.
        
          kTopButton : kTop.
        """
        __members__: typing.ClassVar[dict[str, Joystick.ButtonType]]  # value = {'kTriggerButton': <ButtonType.kTriggerButton: 0>, 'kTopButton': <ButtonType.kTopButton: 1>}
        kTopButton: typing.ClassVar[Joystick.ButtonType]  # value = <ButtonType.kTopButton: 1>
        kTriggerButton: typing.ClassVar[Joystick.ButtonType]  # value = <ButtonType.kTriggerButton: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    kDefaultThrottleChannel: typing.ClassVar[int] = 3
    kDefaultTwistChannel: typing.ClassVar[int] = 2
    kDefaultXChannel: typing.ClassVar[int] = 0
    kDefaultYChannel: typing.ClassVar[int] = 1
    kDefaultZChannel: typing.ClassVar[int] = 2
    def __init__(self, port: typing.SupportsInt) -> None:
        """
        Construct an instance of a joystick.
        
        The joystick index is the USB port on the Driver Station.
        
        :param port: The port on the Driver Station that the joystick is plugged
                     into (0-5).
        """
    def getDirectionDegrees(self) -> wpimath.units.degrees:
        ...
    def getDirectionRadians(self) -> wpimath.units.radians:
        """
        Get the direction of the vector formed by the joystick and its origin. 0 is
        forward and clockwise is positive. (Straight right is π/2 radians or 90
        degrees.)
        
        :returns: The direction of the vector.
        """
    def getMagnitude(self) -> float:
        """
        Get the magnitude of the vector formed by the joystick's
        current position relative to its origin.
        
        :returns: The magnitude of the direction vector
        """
    def getThrottle(self) -> float:
        """
        Get the throttle value of the current joystick.
        
        This depends on the mapping of the joystick connected to the current port.
        """
    def getThrottleChannel(self) -> int:
        """
        Get the channel currently associated with the throttle axis.
        
        :returns: The channel for the axis.
        """
    def getTop(self) -> bool:
        """
        Read the state of the top button on the joystick.
        
        Look up which button has been assigned to the top and read its state.
        
        :returns: The state of the top button.
        """
    def getTopPressed(self) -> bool:
        """
        Whether the top button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getTopReleased(self) -> bool:
        """
        Whether the top button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getTrigger(self) -> bool:
        """
        Read the state of the trigger on the joystick.
        
        Look up which button has been assigned to the trigger and read its state.
        
        :returns: The state of the trigger.
        """
    def getTriggerPressed(self) -> bool:
        """
        Whether the trigger was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getTriggerReleased(self) -> bool:
        """
        Whether the trigger was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getTwist(self) -> float:
        """
        Get the twist value of the current joystick.
        
        This depends on the mapping of the joystick connected to the current port.
        """
    def getTwistChannel(self) -> int:
        """
        Get the channel currently associated with the twist axis.
        
        :returns: The channel for the axis.
        """
    def getX(self) -> float:
        """
        Get the X value of the current joystick.
        
        This depends on the mapping of the joystick connected to the current port.
        On most joysticks, positive is to the right.
        """
    def getXChannel(self) -> int:
        """
        Get the channel currently associated with the X axis.
        
        :returns: The channel for the axis.
        """
    def getY(self) -> float:
        """
        Get the Y value of the current joystick.
        
        This depends on the mapping of the joystick connected to the current port.
        On most joysticks, positive is to the back.
        """
    def getYChannel(self) -> int:
        """
        Get the channel currently associated with the Y axis.
        
        :returns: The channel for the axis.
        """
    def getZ(self) -> float:
        """
        Get the Z value of the current joystick.
        
        This depends on the mapping of the joystick connected to the current port.
        """
    def getZChannel(self) -> int:
        """
        Get the channel currently associated with the Z axis.
        
        :returns: The channel for the axis.
        """
    def setThrottleChannel(self, channel: typing.SupportsInt) -> None:
        """
        Set the channel associated with the throttle axis.
        
        :param channel: The channel to set the axis to.
        """
    def setTwistChannel(self, channel: typing.SupportsInt) -> None:
        """
        Set the channel associated with the twist axis.
        
        :param channel: The channel to set the axis to.
        """
    def setXChannel(self, channel: typing.SupportsInt) -> None:
        """
        Set the channel associated with the X axis.
        
        :param channel: The channel to set the axis to.
        """
    def setYChannel(self, channel: typing.SupportsInt) -> None:
        """
        Set the channel associated with the Y axis.
        
        :param channel: The channel to set the axis to.
        """
    def setZChannel(self, channel: typing.SupportsInt) -> None:
        """
        Set the channel associated with the Z axis.
        
        :param channel: The channel to set the axis to.
        """
    def top(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the top button's digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the top button's digital signal
                  attached to the given loop.
        """
    def trigger(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the trigger button's digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the trigger button's digital signal
                  attached to the given loop.
        """
class Koors40(PWMMotorController):
    """
    AndyMark Koors40 Motor Controller with PWM control.
    
    Note that the Koors40 uses the following bounds for PWM values. These
    values should work reasonably well for most controllers, but if users
    experience issues such as asymmetric behavior around the deadband or
    inability to saturate the controller in either direction, calibration is
    recommended. The calibration procedure can be found in the Koors40 User
    Manual available from AndyMark.
    
    - 2.004ms = full "forward"
    - 1.520ms = the "high end" of the deadband range
    - 1.500ms = center of the deadband range (off)
    - 1.480ms = the "low end" of the deadband range
    - 0.997ms = full "reverse"
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for a Koors40 connected via PWM.
        
        :param channel: The PWM channel that the Koors40 is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
class LEDPattern:
    class GradientType:
        """
        Types of gradients.
        
        Members:
        
          kContinuous : A continuous gradient, where the gradient wraps around to allow for
        seamless scrolling effects.
        
          kDiscontinuous : A discontinuous gradient, where the first pixel is set to the first color
        of the gradient and the final pixel is set to the last color of the
        gradient. There is no wrapping effect, so scrolling effects will display
        an obvious seam.
        """
        __members__: typing.ClassVar[dict[str, LEDPattern.GradientType]]  # value = {'kContinuous': <GradientType.kContinuous: 0>, 'kDiscontinuous': <GradientType.kDiscontinuous: 1>}
        kContinuous: typing.ClassVar[LEDPattern.GradientType]  # value = <GradientType.kContinuous: 0>
        kDiscontinuous: typing.ClassVar[LEDPattern.GradientType]  # value = <GradientType.kDiscontinuous: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class LEDReader:
        """
        A wrapper around a length and an arbitrary reader function that accepts an
        LED index and returns data for the LED at that index. This configuration
        allows us to abstract over different container types without templating.
        """
        def __init__(self, impl: collections.abc.Callable[[typing.SupportsInt], AddressableLED.LEDData], size: typing.SupportsInt) -> None:
            ...
        def size(self) -> int:
            ...
    @staticmethod
    def gradient(type: LEDPattern.GradientType, colors: list[Color]) -> LEDPattern:
        """
        Creates a pattern that displays a non-animated gradient of colors across
        the entire length of the LED strip. Colors are evenly distributed along the
        full length of the LED strip. The gradient type is configured with the
        ``type`` parameter, allowing the gradient to be either continuous (no
        seams, good for scrolling effects) or discontinuous (a clear seam is
        visible, but the gradient applies to the full length of the LED strip
        without needing to use some space for wrapping).
        
        :param type:   the type of gradient (continuous or discontinuous)
        :param colors: the colors to display in the gradient
        
        :returns: a motionless gradient pattern
        """
    @staticmethod
    def off() -> LEDPattern:
        """
        A pattern that turns off all LEDs.
        """
    @staticmethod
    def progressMaskLayer(progressFunction: collections.abc.Callable[[], float]) -> LEDPattern:
        """
        Creates a pattern that works as a mask layer for {@link
        LEDPattern::Mask(const LEDPattern&)} that illuminates only the portion of
        the LED strip corresponding with some progress. The mask pattern will start
        from the base and set LEDs to white at a proportion equal to the progress
        returned by the function. Some usages for this could be for displaying
        progress of a flywheel to its target velocity, progress of a complex
        autonomous sequence, or the height of an elevator.
        
        For example, creating a mask for displaying a red-to-blue gradient,
        starting from the red end, based on where an elevator is in its range of
        travel.
        
        ::
        
          frc::LEDPattern basePattern =
            frc::LEDPattern::Gradient(frc::Color::kRed, frc::Color::kBlue);
          frc::LEDPattern progressPattern =
            basePattern.Mask(frc::LEDPattern::ProgressMaskLayer([&]() {
              return elevator.GetHeight() / elevator.MaxHeight();
            });
        
        :param progressFunction: the function to call to determine the progress.
                                 This should return values in the range [0, 1]; any values outside that
                                 range will be clamped.
        
        :returns: the mask pattern
        """
    @staticmethod
    def rainbow(saturation: typing.SupportsInt, value: typing.SupportsInt) -> LEDPattern:
        """
        Creates an LED pattern that displays a rainbow across the color wheel. The
        rainbow pattern will stretch across the entire length of the LED strip.
        
        :param saturation: the saturation of the HSV colors, in [0, 255]
        :param value:      the value of the HSV colors, in [0, 255]
        
        :returns: the rainbow pattern
        """
    @staticmethod
    def solid(color: Color) -> LEDPattern:
        """
        Creates a pattern that displays a single static color along the entire
        length of the LED strip.
        
        :param color: the color to display
        
        :returns: the pattern
        """
    @staticmethod
    def steps(steps: list[tuple[typing.SupportsFloat, Color]]) -> LEDPattern:
        """
        Display a set of colors in steps across the length of the LED strip. No
        interpolation is done between colors. Colors are specified by the first LED
        on the strip to show that color. The last color in the map will be
        displayed all the way to the end of the strip. LEDs positioned before the
        first specified step will be turned off (you can think of this as if
        there's a 0 -> black step by default).
        
        :param steps: a map of progress to the color to start displaying at that
                      position along the LED strip
        
        :returns: a motionless step pattern
        """
    def __init__(self, impl: collections.abc.Callable[[LEDPattern.LEDReader, collections.abc.Callable[[typing.SupportsInt, Color], None]], None]) -> None:
        ...
    @typing.overload
    def applyTo(self, reader: LEDPattern.LEDReader, writer: collections.abc.Callable[[typing.SupportsInt, Color], None]) -> None:
        ...
    @typing.overload
    def applyTo(self, data: list[AddressableLED.LEDData], writer: collections.abc.Callable[[typing.SupportsInt, Color], None]) -> None:
        """
        Writes the pattern to an LED buffer. Dynamic animations should be called
        periodically (such as with a command or with a periodic method) to refresh
        the buffer over time.
        
        This method is intentionally designed to use separate objects for reading
        and writing data. By splitting them up, we can easily modify the behavior
        of some base pattern to make it scroll, blink, or breathe by intercepting
        the data writes to transform their behavior to whatever we like.
        
        :param data:   the current data of the LED strip
        :param writer: data writer for setting new LED colors on the LED strip
        """
    @typing.overload
    def applyTo(self, data: list[AddressableLED.LEDData]) -> None:
        """
        Writes the pattern to an LED buffer. Dynamic animations should be called
        periodically (such as with a command or with a periodic method) to refresh
        the buffer over time.
        
        This method is intentionally designed to use separate objects for reading
        and writing data. By splitting them up, we can easily modify the behavior
        of some base pattern to make it scroll, blink, or breathe by intercepting
        the data writes to transform their behavior to whatever we like.
        
        :param data: the current data of the LED strip
        """
    def atBrightness(self, relativeBrightness: typing.SupportsFloat) -> LEDPattern:
        """
        Creates a pattern that plays this one, but at a different brightness.
        Brightness multipliers are applied per-channel in the RGB space; no HSL or
        HSV conversions are applied. Multipliers are also uncapped, which may
        result in the original colors washing out and appearing less saturated or
        even just a bright white.
        
        This method is predominantly intended for dimming LEDs to avoid
        painfully bright or distracting patterns from playing (apologies to the
        2024 NE Greater Boston field staff).
        
        For example, dimming can be done simply by adding a call to
        `atBrightness` at the end of a pattern:
        
        ::
        
            // Solid red, but at 50% brightness
            frc::LEDPattern::Solid(frc::Color::kRed).AtBrightness(0.5);
          
            // Solid white, but at only 10% (i.e. ~0.5V)
            frc::LEDPattern::Solid(frc:Color::kWhite).AtBrightness(0.1);
        
        :param relativeBrightness: the multiplier to apply to all channels to modify
                                   brightness
        
        :returns: the input pattern, displayed at
        """
    def blend(self, other: LEDPattern) -> LEDPattern:
        """
        Creates a pattern that displays outputs as a combination of this pattern
        and another. Color values are calculated as the average color of both
        patterns; if both patterns set the same LED to the same color, then it is
        set to that color, but if one pattern sets to one color and the other
        pattern sets it to off, then it will show the color of the first pattern
        but at approximately half brightness. This is different from {@link
        LEDPattern::OverlayOn(const LEDPattern&)}, which will show the base pattern
        at full brightness if the overlay is set to off at that position.
        
        :param other: the pattern to blend with
        
        :returns: the blended pattern
        """
    @typing.overload
    def blink(self, onTime: wpimath.units.seconds, offTime: wpimath.units.seconds) -> LEDPattern:
        """
        Creates a pattern that switches between playing this pattern and turning
        the entire LED strip off.
        
        :param onTime:  how long the pattern should play for, per cycle
        :param offTime: how long the pattern should be turned off for, per cycle
        
        :returns: the blinking pattern
        """
    @typing.overload
    def blink(self, onTime: wpimath.units.seconds) -> LEDPattern:
        """
        Like {@link LEDPattern::Blink(units::second_t)}, but where the
        "off" time is exactly equal to the "on" time.
        
        :param onTime: how long the pattern should play for (and be turned off for),
                       per cycle
        
        :returns: the blinking pattern
        """
    def breathe(self, period: wpimath.units.seconds) -> LEDPattern:
        """
        Creates a pattern that brightens and dims this one over time. Brightness
        follows a sinusoidal pattern.
        
        :param period: how fast the breathing pattern should complete a single cycle
        
        :returns: the breathing pattern
        """
    def mapIndex(self, indexMapper: collections.abc.Callable[[typing.SupportsInt, typing.SupportsInt], int]) -> LEDPattern:
        """
        Creates a pattern with remapped indices.
        
        :param indexMapper: the index mapper
        
        :returns: the mapped pattern
        """
    def mask(self, mask: LEDPattern) -> LEDPattern:
        """
        Similar to {@link LEDPattern::Blend(const LEDPattern&)}, but performs a
        bitwise mask on each color channel rather than averaging the colors for
        each LED. This can be helpful for displaying only a portion of the base
        pattern by applying a mask that sets the desired area to white, and all
        other areas to black. However, it can also be used to display only certain
        color channels or hues; for example, masking with {@code
        LEDPattern.color(Color.kRed)} will turn off the green and blue channels on
        the output pattern, leaving only the red LEDs to be illuminated.
        
        :param mask: the mask to apply
        
        :returns: the masked pattern
        """
    def offsetBy(self, offset: typing.SupportsInt) -> LEDPattern:
        """
        Creates a pattern that displays this one, but offset by a certain number of
        LEDs. The offset pattern will wrap around, if necessary.
        
        :param offset: how many LEDs to offset by
        
        :returns: the offset pattern
        """
    def overlayOn(self, base: LEDPattern) -> LEDPattern:
        """
        Creates a pattern that plays this pattern overlaid on another. Anywhere
        this pattern sets an LED to off (or {@link frc::Color::kBlack}), the base
        pattern will be displayed instead.
        
        :param base: the base pattern to overlay on top of
        
        :returns: the combined overlay pattern
        """
    def reversed(self) -> LEDPattern:
        """
        Creates a pattern that displays this one in reverse. Scrolling patterns
        will scroll in the opposite direction (but at the same speed). It will
        treat the end of an LED strip as the start, and the start of the strip as
        the end. This can be useful for making ping-pong patterns that travel from
        one end of an LED strip to the other, then reverse direction and move back
        to the start. This can also be useful when working with LED strips
        connected in a serpentine pattern (where the start of one strip is
        connected to the end of the previous one).
        
        :returns: the reverse pattern
        """
    def scrollAtAbsoluteSpeed(self, velocity: wpimath.units.meters_per_second, ledSpacing: wpimath.units.meters) -> LEDPattern:
        """
        Creates a pattern that plays this one scrolling up an LED strip. A negative
        velocity makes the pattern play in reverse.
        
        For example, scrolling a pattern at 4 inches per second along an LED
        strip with 60 LEDs per meter:
        
        ::
        
            // LEDs per meter, a known value taken from the spec sheet of our
          particular LED strip units::meter_t LED_SPACING = units::meter_t{1 /60.0};
          
            frc::LEDPattern rainbow = frc::LEDPattern::Rainbow();
            frc::LEDPattern scrollingRainbow =
              rainbow.ScrollAtAbsoluteSpeed(units::feet_per_second_t{1 / 3.0},
          LED_SPACING);
        
        Note that this pattern will scroll *faster* if applied to a less
        dense LED strip (such as 30 LEDs per meter), or *slower* if applied to
        a denser LED strip (such as 120 or 144 LEDs per meter).
        
        :param velocity:   how fast the pattern should move along a physical LED strip
        :param ledSpacing: the distance between adjacent LEDs on the physical LED
                           strip
        
        :returns: the scrolling pattern
        """
    def scrollAtRelativeSpeed(self, velocity: wpimath.units.hertz) -> LEDPattern:
        """
        Creates a pattern that plays this one scrolling up the buffer. The velocity
        controls how fast the pattern returns back to its original position, and is
        in terms of the length of the LED strip; scrolling across a segment that is
        10 LEDs long will travel twice as fast as on a segment that's only 5 LEDs
        long (assuming equal LED density on both segments).
        """
    def synchronizedBlink(self, signal: collections.abc.Callable[[], bool]) -> LEDPattern:
        """
        Creates a pattern that blinks this one on and off in sync with a true/false
        signal. The pattern will play while the signal outputs ``true``, and
        will turn off while the signal outputs
        ``false``.
        
        :param signal: the signal to synchronize with
        
        :returns: the blinking pattern
        """
class LiveWindow:
    """
    The LiveWindow class is the public interface for putting sensors and
    actuators on the LiveWindow.
    """
    @staticmethod
    def disableAllTelemetry() -> None:
        """
        Disable ALL telemetry.
        """
    @staticmethod
    def disableTelemetry(component: wpiutil._wpiutil.Sendable) -> None:
        """
        Disable telemetry for a single component.
        
        :param component: sendable
        """
    @staticmethod
    def enableAllTelemetry() -> None:
        """
        Enable ALL telemetry.
        """
    @staticmethod
    def enableTelemetry(component: wpiutil._wpiutil.Sendable) -> None:
        """
        Enable telemetry for a single component.
        
        :param component: sendable
        """
    @staticmethod
    def isEnabled() -> bool:
        """
        Returns true if LiveWindow is enabled.
        
        :returns: True if LiveWindow is enabled.
        """
    @staticmethod
    def setDisabledCallback(func: collections.abc.Callable[[], None]) -> None:
        """
        Sets function to be called when LiveWindow is disabled.
        
        :param func: function (or nullptr for none)
        """
    @staticmethod
    def setEnabled(enabled: bool) -> None:
        """
        Change the enabled status of LiveWindow.
        
        If it changes to enabled, start livewindow running otherwise stop it
        """
    @staticmethod
    def setEnabledCallback(func: collections.abc.Callable[[], None]) -> None:
        """
        Sets function to be called when LiveWindow is enabled.
        
        :param func: function (or nullptr for none)
        """
    @staticmethod
    def updateValues() -> None:
        """
        Tell all the sensors to update (send) their values.
        
        Actuators are handled through callbacks on their value changing from the
        SmartDashboard widgets.
        """
class Mechanism2d(ntcore._ntcore.NTSendable):
    """
    Visual 2D representation of arms, elevators, and general mechanisms through
    a node-based API.
    
    A Mechanism2d object is published and contains at least one root node. A root
    is the anchor point of other nodes (such as ligaments). Other nodes are
    recursively appended based on other nodes.
    
    Except for the Mechanism2d container object, none of the objects should be
    passed or interacted with by value! Obtain pointers from factory methods such
    as Mechanism2d.GetRoot() and MechanismObject2d.Append<>(). The Mechanism2d
    container object owns the root nodes, and each node internally owns the nodes
    based on it. Beware not to let the Mechanism2d object out of scope - all
    nodes will be recursively destructed!
    
    @see MechanismObject2d
    @see MechanismLigament2d
    @see MechanismRoot2d
    """
    def __init__(self, width: typing.SupportsFloat, height: typing.SupportsFloat, backgroundColor: Color8Bit = ...) -> None:
        """
        Create a new Mechanism2d with the given dimensions and background color.
        
        The dimensions represent the canvas that all the nodes are drawn on. The
        default color is dark blue.
        
        :param width:           the width
        :param height:          the height
        :param backgroundColor: the background color
        """
    def getRoot(self, name: str, x: typing.SupportsFloat, y: typing.SupportsFloat) -> MechanismRoot2d:
        """
        Get or create a root in this Mechanism2d with the given name and
        position.
        
        If a root with the given name already exists, the given x and y
        coordinates are not used.
        
        :param name: the root name
        :param x:    the root x coordinate
        :param y:    the root y coordinate
        
        :returns: a new root object, or the existing one with the given name.
        """
    def initSendable(self, builder: ntcore._ntcore.NTSendableBuilder) -> None:
        ...
    def setBackgroundColor(self, color: Color8Bit) -> None:
        """
        Set the Mechanism2d background color.
        
        :param color: the new background color
        """
class MechanismLigament2d(MechanismObject2d):
    """
    Ligament node on a Mechanism2d.
    
    A ligament can have its length changed (like an elevator) or angle changed,
    like an arm.
    
    @see Mechanism2d
    """
    def _updateEntries(self, table: ntcore._ntcore.NetworkTable) -> None:
        ...
    def getAngle(self) -> float:
        """
        Get the ligament's angle relative to its parent.
        
        :returns: the angle
        """
    def getColor(self) -> Color8Bit:
        """
        Get the ligament color.
        
        :returns: the color of the line
        """
    def getLength(self) -> float:
        """
        Get the ligament length.
        
        :returns: the line length
        """
    def getLineWeight(self) -> float:
        """
        Get the line thickness.
        
        :returns: the line thickness
        """
    def setAngle(self, angle: wpimath.units.degrees) -> None:
        """
        Set the ligament's angle relative to its parent.
        
        :param angle: the angle
        """
    def setColor(self, color: Color8Bit) -> None:
        """
        Set the ligament color.
        
        :param color: the color of the line
        """
    def setLength(self, length: typing.SupportsFloat) -> None:
        """
        Set the ligament's length.
        
        :param length: the line length
        """
    def setLineWeight(self, lineWidth: typing.SupportsFloat) -> None:
        """
        Set the line thickness.
        
        :param lineWidth: the line thickness
        """
class MechanismObject2d:
    """
    Common base class for all Mechanism2d node types.
    
    To append another node, call Append with the type of node and its
    construction parameters. None of the node types are designed to be
    constructed directly, and are owned by their parent node/container - obtain
    pointers from the Append function or similar factory methods.
    
    @see Mechanism2d.
    """
    def _updateEntries(self, table: ntcore._ntcore.NetworkTable) -> None:
        """
        Update all entries with new ones from a new table.
        
        :param table: the new table.
        """
    def appendLigament(self, name: str, length: typing.SupportsFloat, angle: wpimath.units.degrees, lineWidth: typing.SupportsFloat = 6, color: Color8Bit = ...) -> MechanismLigament2d:
        """
        Append a ligament node
        """
    def getName(self) -> str:
        """
        Retrieve the object's name.
        
        :returns: the object's name relative to its parent.
        """
class MechanismRoot2d:
    """
    Root Mechanism2d node.
    
    A root is the anchor point of other nodes (such as ligaments).
    
    Do not create objects of this class directly! Obtain pointers from the
    Mechanism2d.GetRoot() factory method.
    
    Append other nodes by using Append().
    """
    def appendLigament(self, name: str, length: typing.SupportsFloat, angle: wpimath.units.degrees, lineWidth: typing.SupportsFloat = 6, color: Color8Bit = ...) -> MechanismLigament2d:
        """
        Append a ligament node
        """
    def getName(self) -> str:
        ...
    def setPosition(self, x: typing.SupportsFloat, y: typing.SupportsFloat) -> None:
        """
        Set the root's position.
        
        :param x: new x coordinate
        :param y: new y coordinate
        """
class MotorControllerGroup(wpiutil._wpiutil.Sendable, wpilib.interfaces._interfaces.MotorController):
    def __init__(self, *args) -> None:
        ...
    def disable(self) -> None:
        ...
    def get(self) -> float:
        ...
    def getInverted(self) -> bool:
        ...
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def set(self, speed: typing.SupportsFloat) -> None:
        ...
    def setInverted(self, isInverted: bool) -> None:
        ...
    def setVoltage(self, output: wpimath.units.volts) -> None:
        ...
    def stopMotor(self) -> None:
        ...
class MotorSafety:
    """
    The Motor Safety feature acts as a watchdog timer for an individual motor. It
    operates by maintaining a timer that tracks how long it has been since the
    feed() method has been called for that actuator. Code in the Driver Station
    class initiates a comparison of these timers to the timeout values for any
    actuator with safety enabled every 5 received packets (100ms nominal).
    
    The subclass should call Feed() whenever the motor value is updated.
    """
    @staticmethod
    def checkMotors() -> None:
        """
        Check the motors to see if any have timed out.
        
        This static method is called periodically to poll all the motors and stop
        any that have timed out.
        """
    def __init__(self) -> None:
        ...
    def check(self) -> None:
        """
        Check if this motor has exceeded its timeout.
        
        This method is called periodically to determine if this motor has exceeded
        its timeout value. If it has, the stop method is called, and the motor is
        shut down until its value is updated again.
        """
    def feed(self) -> None:
        """
        Feed the motor safety object.
        
        Resets the timer on this object that is used to do the timeouts.
        """
    def getDescription(self) -> str:
        """
        Returns a description to print when an error occurs.
        
        :returns: Description to print when an error occurs.
        """
    def getExpiration(self) -> wpimath.units.seconds:
        """
        Retrieve the timeout value for the corresponding motor safety object.
        
        :returns: the timeout value.
        """
    def isAlive(self) -> bool:
        """
        Determine if the motor is still operating or has timed out.
        
        :returns: true if the motor is still operating normally and hasn't timed out.
        """
    def isSafetyEnabled(self) -> bool:
        """
        Return the state of the motor safety enabled flag.
        
        Return if the motor safety is currently enabled for this device.
        
        :returns: True if motor safety is enforced for this device.
        """
    def setExpiration(self, expirationTime: wpimath.units.seconds) -> None:
        """
        Set the expiration time for the corresponding motor safety object.
        
        :param expirationTime: The timeout value.
        """
    def setSafetyEnabled(self, enabled: bool) -> None:
        """
        Enable/disable motor safety for this device.
        
        Turn on and off the motor safety option for this PWM object.
        
        :param enabled: True if motor safety is enforced for this object.
        """
    def stopMotor(self) -> None:
        """
        Called to stop the motor when the timeout expires.
        """
class Notifier:
    @staticmethod
    def setHALThreadPriority(realTime: bool, priority: typing.SupportsInt) -> bool:
        """
        Sets the HAL notifier thread priority.
        
        The HAL notifier thread is responsible for managing the FPGA's notifier
        interrupt and waking up user's Notifiers when it's their time to run.
        Giving the HAL notifier thread real-time priority helps ensure the user's
        real-time Notifiers, if any, are notified to run in a timely manner.
        
        :param realTime: Set to true to set a real-time priority, false for standard
                         priority.
        :param priority: Priority to set the thread to. For real-time, this is 1-99
                         with 99 being highest. For non-real-time, this is forced to
                         0. See "man 7 sched" for more details.
        
        :returns: True on success.
        """
    def __init__(self, handler: collections.abc.Callable[[], None]) -> None:
        """
        Create a Notifier for timer event notification.
        
        :param handler: The handler is called at the notification time which is set
                        using StartSingle or StartPeriodic.
        """
    def setCallback(self, handler: collections.abc.Callable[[], None]) -> None:
        """
        Change the handler function.
        
        :param handler: Handler
        """
    def setName(self, name: str) -> None:
        """
        Sets the name of the notifier.  Used for debugging purposes only.
        
        :param name: Name
        """
    def startPeriodic(self, period: wpimath.units.seconds) -> None:
        """
        Register for periodic event notification.
        
        A timer event is queued for periodic event notification. Each time the
        interrupt occurs, the event will be immediately requeued for the same time
        interval.
        
        :param period: Period to call the handler starting one period
                       after the call to this method.
        """
    def startSingle(self, delay: wpimath.units.seconds) -> None:
        """
        Register for single event notification.
        
        A timer event is queued for a single event after the specified delay.
        
        :param delay: Amount of time to wait before the handler is called.
        """
    def stop(self) -> None:
        """
        Stop timer events from occurring.
        
        Stop any repeating timer events from occurring. This will also remove any
        single notification events from the queue.
        
        If a timer-based call to the registered handler is in progress, this
        function will block until the handler call is complete.
        """
class PS4Controller(wpilib.interfaces._interfaces.GenericHID, wpiutil._wpiutil.Sendable):
    """
    Handle input from PS4 controllers connected to the Driver Station.
    
    This class handles PS4 input that comes from the Driver Station. Each
    time a value is requested the most recent value is returned. There is a
    single class instance for each controller and the mapping of ports to
    hardware buttons depends on the code in the Driver Station.
    
    Only first party controllers from Sony are guaranteed to have the
    correct mapping, and only through the official NI DS. Sim is not guaranteed
    to have the same mapping, as well as any 3rd party controllers.
    """
    class Axis:
        """
        Represents an axis on an PS4Controller.
        """
        kL2: typing.ClassVar[int] = 3
        kLeftX: typing.ClassVar[int] = 0
        kLeftY: typing.ClassVar[int] = 1
        kR2: typing.ClassVar[int] = 4
        kRightX: typing.ClassVar[int] = 2
        kRightY: typing.ClassVar[int] = 5
        def __init__(self) -> None:
            ...
    class Button:
        """
        Represents a digital button on an PS4Controller.
        """
        kCircle: typing.ClassVar[int] = 3
        kCross: typing.ClassVar[int] = 2
        kL1: typing.ClassVar[int] = 5
        kL2: typing.ClassVar[int] = 7
        kL3: typing.ClassVar[int] = 11
        kOptions: typing.ClassVar[int] = 10
        kPS: typing.ClassVar[int] = 13
        kR1: typing.ClassVar[int] = 6
        kR2: typing.ClassVar[int] = 8
        kR3: typing.ClassVar[int] = 12
        kShare: typing.ClassVar[int] = 9
        kSquare: typing.ClassVar[int] = 1
        kTouchpad: typing.ClassVar[int] = 14
        kTriangle: typing.ClassVar[int] = 4
        def __init__(self) -> None:
            ...
    def L1(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the left trigger 1 button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the left trigger 1 button's
                  digital signal attached to the given loop.
        """
    def L2(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the left trigger 2 button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the left trigger 2 button's
                  digital signal attached to the given loop.
        """
    def L3(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the L3 (left stick) button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the L3 (left stick) button's
                  digital signal attached to the given loop.
        """
    def PS(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the PlayStation button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the PlayStation button's
                  digital signal attached to the given loop.
        """
    def R1(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the right trigger 1 button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the right trigger 1 button's
                  digital signal attached to the given loop.
        """
    def R2(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the right trigger 2 button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the right trigger 2 button's
                  digital signal attached to the given loop.
        """
    def R3(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the R3 (right stick) button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the R3 (right stick) button's
                  digital signal attached to the given loop.
        """
    def __init__(self, port: typing.SupportsInt) -> None:
        """
        Construct an instance of a controller.
        
        The controller index is the USB port on the Driver Station.
        
        :param port: The port on the Driver Station that the controller is plugged
                     into (0-5).
        """
    def circle(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the circle button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the circle button's
                  digital signal attached to the given loop.
        """
    def cross(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the cross button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the cross button's
                  digital signal attached to the given loop.
        """
    def getCircleButton(self) -> bool:
        """
        Read the value of the circle button on the controller.
        
        :returns: The state of the button.
        """
    def getCircleButtonPressed(self) -> bool:
        """
        Whether the circle button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getCircleButtonReleased(self) -> bool:
        """
        Whether the circle button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getCrossButton(self) -> bool:
        """
        Read the value of the cross button on the controller.
        
        :returns: The state of the button.
        """
    def getCrossButtonPressed(self) -> bool:
        """
        Whether the cross button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getCrossButtonReleased(self) -> bool:
        """
        Whether the cross button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getL1Button(self) -> bool:
        """
        Read the value of the left trigger 1 button on the controller.
        
        :returns: The state of the button.
        """
    def getL1ButtonPressed(self) -> bool:
        """
        Whether the left trigger 1 button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getL1ButtonReleased(self) -> bool:
        """
        Whether the left trigger 1 button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getL2Axis(self) -> float:
        """
        Get the left trigger 2 axis value of the controller. Note that this axis
        is bound to the range of [0, 1] as opposed to the usual [-1, 1].
        
        :returns: the axis value.
        """
    def getL2Button(self) -> bool:
        """
        Read the value of the left trigger 2 button on the controller.
        
        :returns: The state of the button.
        """
    def getL2ButtonPressed(self) -> bool:
        """
        Whether the left trigger 2 button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getL2ButtonReleased(self) -> bool:
        """
        Whether the left trigger 2 button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getL3Button(self) -> bool:
        """
        Read the value of the L3 (left stick) button on the controller.
        
        :returns: The state of the button.
        """
    def getL3ButtonPressed(self) -> bool:
        """
        Whether the L3 (left stick) button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getL3ButtonReleased(self) -> bool:
        """
        Whether the L3 (left stick) button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftX(self) -> float:
        """
        Get the X axis value of left side of the controller. Right is positive.
        
        :returns: the axis value.
        """
    def getLeftY(self) -> float:
        """
        Get the Y axis value of left side of the controller. Back is positive.
        
        :returns: the axis value.
        """
    def getOptionsButton(self) -> bool:
        """
        Read the value of the options button on the controller.
        
        :returns: The state of the button.
        """
    def getOptionsButtonPressed(self) -> bool:
        """
        Whether the options button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getOptionsButtonReleased(self) -> bool:
        """
        Whether the options button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getPSButton(self) -> bool:
        """
        Read the value of the PlayStation button on the controller.
        
        :returns: The state of the button.
        """
    def getPSButtonPressed(self) -> bool:
        """
        Whether the PlayStation button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getPSButtonReleased(self) -> bool:
        """
        Whether the PlayStation button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getR1Button(self) -> bool:
        """
        Read the value of the right trigger 1 button on the controller.
        
        :returns: The state of the button.
        """
    def getR1ButtonPressed(self) -> bool:
        """
        Whether the right trigger 1 button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getR1ButtonReleased(self) -> bool:
        """
        Whether the right trigger 1 button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getR2Axis(self) -> float:
        """
        Get the right trigger 2 axis value of the controller. Note that this axis
        is bound to the range of [0, 1] as opposed to the usual [-1, 1].
        
        :returns: the axis value.
        """
    def getR2Button(self) -> bool:
        """
        Read the value of the right trigger 2 button on the controller.
        
        :returns: The state of the button.
        """
    def getR2ButtonPressed(self) -> bool:
        """
        Whether the right trigger 2 button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getR2ButtonReleased(self) -> bool:
        """
        Whether the right trigger 2 button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getR3Button(self) -> bool:
        """
        Read the value of the R3 (right stick) button on the controller.
        
        :returns: The state of the button.
        """
    def getR3ButtonPressed(self) -> bool:
        """
        Whether the R3 (right stick) button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getR3ButtonReleased(self) -> bool:
        """
        Whether the R3 (right stick) button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getRightX(self) -> float:
        """
        Get the X axis value of right side of the controller. Right is positive.
        
        :returns: the axis value.
        """
    def getRightY(self) -> float:
        """
        Get the Y axis value of right side of the controller. Back is positive.
        
        :returns: the axis value.
        """
    def getShareButton(self) -> bool:
        """
        Read the value of the share button on the controller.
        
        :returns: The state of the button.
        """
    def getShareButtonPressed(self) -> bool:
        """
        Whether the share button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getShareButtonReleased(self) -> bool:
        """
        Whether the share button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getSquareButton(self) -> bool:
        """
        Read the value of the square button on the controller.
        
        :returns: The state of the button.
        """
    def getSquareButtonPressed(self) -> bool:
        """
        Whether the square button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getSquareButtonReleased(self) -> bool:
        """
        Whether the square button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getTouchpad(self) -> bool:
        """
        Read the value of the touchpad button on the controller.
        
        :deprecated: Use GetTouchpadButton instead. This function is deprecated for
                     removal to make function names consistent to allow the HID classes to be
                     automatically generated.
        
        :returns: The state of the button.
        """
    def getTouchpadButton(self) -> bool:
        """
        Read the value of the touchpad button on the controller.
        
        :returns: The state of the button.
        """
    def getTouchpadButtonPressed(self) -> bool:
        """
        Whether the touchpad button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getTouchpadButtonReleased(self) -> bool:
        """
        Whether the touchpad button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getTouchpadPressed(self) -> bool:
        """
        Whether the touchpad was pressed since the last check.
        
        :deprecated: Use GetTouchpadButtonPressed instead. This function is
                     deprecated for removal to make function names consistent to allow the HID
                     classes to be automatically generated.
        
        :returns: Whether the touchpad was pressed since the last check.
        """
    def getTouchpadReleased(self) -> bool:
        """
        Whether the touchpad was released since the last check.
        
        :deprecated: Use GetLeftBumperButton instead. This function is deprecated
                     for removal to make function names consistent to allow the HID classes to
                     be automatically generated.
        
        :returns: Whether the touchpad was released since the last check.
        """
    def getTriangleButton(self) -> bool:
        """
        Read the value of the triangle button on the controller.
        
        :returns: The state of the button.
        """
    def getTriangleButtonPressed(self) -> bool:
        """
        Whether the triangle button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getTriangleButtonReleased(self) -> bool:
        """
        Whether the triangle button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def options(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the options button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the options button's
                  digital signal attached to the given loop.
        """
    def share(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the share button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the share button's
                  digital signal attached to the given loop.
        """
    def square(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the square button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the square button's
                  digital signal attached to the given loop.
        """
    def touchpad(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the touchpad button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the touchpad button's
                  digital signal attached to the given loop.
        """
    def triangle(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the triangle button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the triangle button's
                  digital signal attached to the given loop.
        """
class PS5Controller(wpilib.interfaces._interfaces.GenericHID, wpiutil._wpiutil.Sendable):
    """
    Handle input from PS5 controllers connected to the Driver Station.
    
    This class handles PS5 input that comes from the Driver Station. Each
    time a value is requested the most recent value is returned. There is a
    single class instance for each controller and the mapping of ports to
    hardware buttons depends on the code in the Driver Station.
    
    Only first party controllers from Sony are guaranteed to have the
    correct mapping, and only through the official NI DS. Sim is not guaranteed
    to have the same mapping, as well as any 3rd party controllers.
    """
    class Axis:
        """
        Represents an axis on an PS5Controller.
        """
        kL2: typing.ClassVar[int] = 3
        kLeftX: typing.ClassVar[int] = 0
        kLeftY: typing.ClassVar[int] = 1
        kR2: typing.ClassVar[int] = 4
        kRightX: typing.ClassVar[int] = 2
        kRightY: typing.ClassVar[int] = 5
        def __init__(self) -> None:
            ...
    class Button:
        """
        Represents a digital button on an PS5Controller.
        """
        kCircle: typing.ClassVar[int] = 3
        kCreate: typing.ClassVar[int] = 9
        kCross: typing.ClassVar[int] = 2
        kL1: typing.ClassVar[int] = 5
        kL2: typing.ClassVar[int] = 7
        kL3: typing.ClassVar[int] = 11
        kOptions: typing.ClassVar[int] = 10
        kPS: typing.ClassVar[int] = 13
        kR1: typing.ClassVar[int] = 6
        kR2: typing.ClassVar[int] = 8
        kR3: typing.ClassVar[int] = 12
        kSquare: typing.ClassVar[int] = 1
        kTouchpad: typing.ClassVar[int] = 14
        kTriangle: typing.ClassVar[int] = 4
        def __init__(self) -> None:
            ...
    def L1(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the left trigger 1 button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the left trigger 1 button's
                  digital signal attached to the given loop.
        """
    def L2(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the left trigger 2 button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the left trigger 2 button's
                  digital signal attached to the given loop.
        """
    def L3(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the L3 (left stick) button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the L3 (left stick) button's
                  digital signal attached to the given loop.
        """
    def PS(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the PlayStation button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the PlayStation button's
                  digital signal attached to the given loop.
        """
    def R1(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the right trigger 1 button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the right trigger 1 button's
                  digital signal attached to the given loop.
        """
    def R2(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the right trigger 2 button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the right trigger 2 button's
                  digital signal attached to the given loop.
        """
    def R3(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the R3 (right stick) button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the R3 (right stick) button's
                  digital signal attached to the given loop.
        """
    def __init__(self, port: typing.SupportsInt) -> None:
        """
        Construct an instance of a controller.
        
        The controller index is the USB port on the Driver Station.
        
        :param port: The port on the Driver Station that the controller is plugged
                     into (0-5).
        """
    def circle(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the circle button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the circle button's
                  digital signal attached to the given loop.
        """
    def create(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the create button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the create button's
                  digital signal attached to the given loop.
        """
    def cross(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the cross button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the cross button's
                  digital signal attached to the given loop.
        """
    def getCircleButton(self) -> bool:
        """
        Read the value of the circle button on the controller.
        
        :returns: The state of the button.
        """
    def getCircleButtonPressed(self) -> bool:
        """
        Whether the circle button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getCircleButtonReleased(self) -> bool:
        """
        Whether the circle button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getCreateButton(self) -> bool:
        """
        Read the value of the create button on the controller.
        
        :returns: The state of the button.
        """
    def getCreateButtonPressed(self) -> bool:
        """
        Whether the create button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getCreateButtonReleased(self) -> bool:
        """
        Whether the create button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getCrossButton(self) -> bool:
        """
        Read the value of the cross button on the controller.
        
        :returns: The state of the button.
        """
    def getCrossButtonPressed(self) -> bool:
        """
        Whether the cross button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getCrossButtonReleased(self) -> bool:
        """
        Whether the cross button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getL1Button(self) -> bool:
        """
        Read the value of the left trigger 1 button on the controller.
        
        :returns: The state of the button.
        """
    def getL1ButtonPressed(self) -> bool:
        """
        Whether the left trigger 1 button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getL1ButtonReleased(self) -> bool:
        """
        Whether the left trigger 1 button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getL2Axis(self) -> float:
        """
        Get the left trigger 2 axis value of the controller. Note that this axis
        is bound to the range of [0, 1] as opposed to the usual [-1, 1].
        
        :returns: the axis value.
        """
    def getL2Button(self) -> bool:
        """
        Read the value of the left trigger 2 button on the controller.
        
        :returns: The state of the button.
        """
    def getL2ButtonPressed(self) -> bool:
        """
        Whether the left trigger 2 button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getL2ButtonReleased(self) -> bool:
        """
        Whether the left trigger 2 button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getL3Button(self) -> bool:
        """
        Read the value of the L3 (left stick) button on the controller.
        
        :returns: The state of the button.
        """
    def getL3ButtonPressed(self) -> bool:
        """
        Whether the L3 (left stick) button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getL3ButtonReleased(self) -> bool:
        """
        Whether the L3 (left stick) button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftX(self) -> float:
        """
        Get the X axis value of left side of the controller. Right is positive.
        
        :returns: the axis value.
        """
    def getLeftY(self) -> float:
        """
        Get the Y axis value of left side of the controller. Back is positive.
        
        :returns: the axis value.
        """
    def getOptionsButton(self) -> bool:
        """
        Read the value of the options button on the controller.
        
        :returns: The state of the button.
        """
    def getOptionsButtonPressed(self) -> bool:
        """
        Whether the options button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getOptionsButtonReleased(self) -> bool:
        """
        Whether the options button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getPSButton(self) -> bool:
        """
        Read the value of the PlayStation button on the controller.
        
        :returns: The state of the button.
        """
    def getPSButtonPressed(self) -> bool:
        """
        Whether the PlayStation button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getPSButtonReleased(self) -> bool:
        """
        Whether the PlayStation button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getR1Button(self) -> bool:
        """
        Read the value of the right trigger 1 button on the controller.
        
        :returns: The state of the button.
        """
    def getR1ButtonPressed(self) -> bool:
        """
        Whether the right trigger 1 button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getR1ButtonReleased(self) -> bool:
        """
        Whether the right trigger 1 button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getR2Axis(self) -> float:
        """
        Get the right trigger 2 axis value of the controller. Note that this axis
        is bound to the range of [0, 1] as opposed to the usual [-1, 1].
        
        :returns: the axis value.
        """
    def getR2Button(self) -> bool:
        """
        Read the value of the right trigger 2 button on the controller.
        
        :returns: The state of the button.
        """
    def getR2ButtonPressed(self) -> bool:
        """
        Whether the right trigger 2 button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getR2ButtonReleased(self) -> bool:
        """
        Whether the right trigger 2 button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getR3Button(self) -> bool:
        """
        Read the value of the R3 (right stick) button on the controller.
        
        :returns: The state of the button.
        """
    def getR3ButtonPressed(self) -> bool:
        """
        Whether the R3 (right stick) button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getR3ButtonReleased(self) -> bool:
        """
        Whether the R3 (right stick) button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getRightX(self) -> float:
        """
        Get the X axis value of right side of the controller. Right is positive.
        
        :returns: the axis value.
        """
    def getRightY(self) -> float:
        """
        Get the Y axis value of right side of the controller. Back is positive.
        
        :returns: the axis value.
        """
    def getSquareButton(self) -> bool:
        """
        Read the value of the square button on the controller.
        
        :returns: The state of the button.
        """
    def getSquareButtonPressed(self) -> bool:
        """
        Whether the square button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getSquareButtonReleased(self) -> bool:
        """
        Whether the square button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getTouchpad(self) -> bool:
        """
        Read the value of the touchpad button on the controller.
        
        :deprecated: Use GetTouchpadButton instead. This function is deprecated for
                     removal to make function names consistent to allow the HID classes to be
                     automatically generated.
        
        :returns: The state of the button.
        """
    def getTouchpadButton(self) -> bool:
        """
        Read the value of the touchpad button on the controller.
        
        :returns: The state of the button.
        """
    def getTouchpadButtonPressed(self) -> bool:
        """
        Whether the touchpad button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getTouchpadButtonReleased(self) -> bool:
        """
        Whether the touchpad button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getTouchpadPressed(self) -> bool:
        """
        Whether the touchpad was pressed since the last check.
        
        :deprecated: Use GetTouchpadButtonPressed instead. This function is
                     deprecated for removal to make function names consistent to allow the HID
                     classes to be automatically generated.
        
        :returns: Whether the touchpad was pressed since the last check.
        """
    def getTouchpadReleased(self) -> bool:
        """
        Whether the touchpad was released since the last check.
        
        :deprecated: Use GetLeftBumperButton instead. This function is deprecated
                     for removal to make function names consistent to allow the HID classes to
                     be automatically generated.
        
        :returns: Whether the touchpad was released since the last check.
        """
    def getTriangleButton(self) -> bool:
        """
        Read the value of the triangle button on the controller.
        
        :returns: The state of the button.
        """
    def getTriangleButtonPressed(self) -> bool:
        """
        Whether the triangle button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getTriangleButtonReleased(self) -> bool:
        """
        Whether the triangle button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def options(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the options button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the options button's
                  digital signal attached to the given loop.
        """
    def square(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the square button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the square button's
                  digital signal attached to the given loop.
        """
    def touchpad(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the touchpad button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the touchpad button's
                  digital signal attached to the given loop.
        """
    def triangle(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the triangle button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the triangle button's
                  digital signal attached to the given loop.
        """
class PWM(wpiutil._wpiutil.Sendable):
    """
    Class implements the PWM generation in the FPGA.
    
    The values supplied as arguments for PWM outputs range from -1.0 to 1.0. They
    are mapped to the microseconds to keep the pulse high, with a range of 0
    (off) to 4096. Changes are immediately sent to the FPGA, and the update
    occurs at the next FPGA cycle (5.05ms). There is no delay.
    """
    class PeriodMultiplier:
        """
        Represents the amount to multiply the minimum servo-pulse pwm period by.
        
        Members:
        
          kPeriodMultiplier_1X : Don't skip pulses. PWM pulses occur every 5.05 ms
        
          kPeriodMultiplier_2X : Skip every other pulse. PWM pulses occur every 10.10 ms
        
          kPeriodMultiplier_4X : Skip three out of four pulses. PWM pulses occur every 20.20 ms
        """
        __members__: typing.ClassVar[dict[str, PWM.PeriodMultiplier]]  # value = {'kPeriodMultiplier_1X': <PeriodMultiplier.kPeriodMultiplier_1X: 1>, 'kPeriodMultiplier_2X': <PeriodMultiplier.kPeriodMultiplier_2X: 2>, 'kPeriodMultiplier_4X': <PeriodMultiplier.kPeriodMultiplier_4X: 4>}
        kPeriodMultiplier_1X: typing.ClassVar[PWM.PeriodMultiplier]  # value = <PeriodMultiplier.kPeriodMultiplier_1X: 1>
        kPeriodMultiplier_2X: typing.ClassVar[PWM.PeriodMultiplier]  # value = <PeriodMultiplier.kPeriodMultiplier_2X: 2>
        kPeriodMultiplier_4X: typing.ClassVar[PWM.PeriodMultiplier]  # value = <PeriodMultiplier.kPeriodMultiplier_4X: 4>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self, channel: typing.SupportsInt, registerSendable: bool = True) -> None:
        """
        Allocate a PWM given a channel number.
        
        Checks channel value range and allocates the appropriate channel.
        The allocation is only done to help users ensure that they don't double
        assign channels.
        
        :param channel:          The PWM channel number. 0-9 are on-board, 10-19 are on the
                                 MXP port
        :param registerSendable: If true, adds this instance to SendableRegistry
                                 and LiveWindow
        """
    def __repr__(self) -> str:
        ...
    def _initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def enableDeadbandElimination(self, eliminateDeadband: bool) -> None:
        """
        Optionally eliminate the deadband from a motor controller.
        
        :param eliminateDeadband: If true, set the motor curve on the motor
                                  controller to eliminate the deadband in the middle
                                  of the range. Otherwise, keep the full range
                                  without modifying any values.
        """
    def getBounds(self, max: wpimath.units.microseconds, deadbandMax: wpimath.units.microseconds, center: wpimath.units.microseconds, deadbandMin: wpimath.units.microseconds, min: wpimath.units.microseconds) -> None:
        """
        Get the bounds on the PWM values.
        
        This gets the bounds on the PWM values for a particular each type of
        controller. The values determine the upper and lower speeds as well as the
        deadband bracket.
        
        :param max:         The maximum pwm value
        :param deadbandMax: The high end of the deadband range
        :param center:      The center speed (off)
        :param deadbandMin: The low end of the deadband range
        :param min:         The minimum pwm value
        """
    def getChannel(self) -> int:
        ...
    def getPosition(self) -> float:
        """
        Get the PWM value in terms of a position.
        
        This is intended to be used by servos.
        
        @pre SetBounds() called.
        
        :returns: The position the servo is set to between 0.0 and 1.0.
        """
    def getPulseTime(self) -> wpimath.units.microseconds:
        """
        Get the PWM pulse time directly from the hardware.
        
        Read a microsecond value from a PWM channel.
        
        :returns: Microsecond PWM control value.
        """
    def getSpeed(self) -> float:
        """
        Get the PWM value in terms of speed.
        
        This is intended to be used by motor controllers.
        
        @pre SetBounds() called.
        
        :returns: The most recently set speed between -1.0 and 1.0.
        """
    def setAlwaysHighMode(self) -> None:
        """
        Sets the PWM output to be a continuous high signal while enabled.
        """
    def setBounds(self, max: wpimath.units.microseconds, deadbandMax: wpimath.units.microseconds, center: wpimath.units.microseconds, deadbandMin: wpimath.units.microseconds, min: wpimath.units.microseconds) -> None:
        """
        Set the bounds on the PWM pulse widths.
        
        This sets the bounds on the PWM values for a particular type of controller.
        The values determine the upper and lower speeds as well as the deadband
        bracket.
        
        :param max:         The max PWM pulse width in us
        :param deadbandMax: The high end of the deadband range pulse width in us
        :param center:      The center (off) pulse width in us
        :param deadbandMin: The low end of the deadband pulse width in us
        :param min:         The minimum pulse width in us
        """
    def setDisabled(self) -> None:
        """
        Temporarily disables the PWM output. The next set call will re-enable
        the output.
        """
    def setPeriodMultiplier(self, mult: PWM.PeriodMultiplier) -> None:
        """
        Slow down the PWM signal for old devices.
        
        :param mult: The period multiplier to apply to this channel
        """
    def setPosition(self, pos: typing.SupportsFloat) -> None:
        """
        Set the PWM value based on a position.
        
        This is intended to be used by servos.
        
        @pre SetBounds() called.
        
        :param pos: The position to set the servo between 0.0 and 1.0.
        """
    def setPulseTime(self, time: wpimath.units.microseconds) -> None:
        """
        Set the PWM pulse time directly to the hardware.
        
        Write a microsecond value to a PWM channel.
        
        :param time: Microsecond PWM value.
        """
    def setSpeed(self, speed: typing.SupportsFloat) -> None:
        """
        Set the PWM value based on a speed.
        
        This is intended to be used by motor controllers.
        
        @pre SetBounds() called.
        
        :param speed: The speed to set the motor controller between -1.0 and 1.0.
        """
    def setZeroLatch(self) -> None:
        """
        Latches PWM to zero.
        """
class PWMMotorController(wpilib.interfaces._interfaces.MotorController, MotorSafety, wpiutil._wpiutil.Sendable):
    """
    Common base class for all PWM Motor Controllers.
    """
    def __init__(self, name: str, channel: typing.SupportsInt) -> None:
        """
        Constructor for a PWM Motor %Controller connected via PWM.
        
        :param name:    Name to use for SendableRegistry
        :param channel: The PWM channel that the controller is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
    def _initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def addFollower(self, follower: PWMMotorController) -> None:
        """
        Make the given PWM motor controller follow the output of this one.
        
        :param follower: The motor controller follower.
        """
    def disable(self) -> None:
        ...
    def enableDeadbandElimination(self, eliminateDeadband: bool) -> None:
        """
        Optionally eliminate the deadband from a motor controller.
        
        :param eliminateDeadband: If true, set the motor curve on the motor
                                  controller to eliminate the deadband in the middle
                                  of the range. Otherwise, keep the full range
                                  without modifying any values.
        """
    def get(self) -> float:
        """
        Get the recently set value of the PWM. This value is affected by the
        inversion property. If you want the value that is sent directly to the
        MotorController, use PWM::GetSpeed() instead.
        
        :returns: The most recently set value for the PWM between -1.0 and 1.0.
        """
    def getChannel(self) -> int:
        ...
    def getDescription(self) -> str:
        ...
    def getInverted(self) -> bool:
        ...
    def getVoltage(self) -> wpimath.units.volts:
        """
        Gets the voltage output of the motor controller, nominally between -12 V
        and 12 V.
        
        :returns: The voltage of the motor controller, nominally between -12 V and 12
                  V.
        """
    def set(self, value: typing.SupportsFloat) -> None:
        """
        Set the PWM value.
        
        The PWM value is set using a range of -1.0 to 1.0, appropriately scaling
        the value for the FPGA.
        
        :param value: The speed value between -1.0 and 1.0 to set.
        """
    def setInverted(self, isInverted: bool) -> None:
        ...
    def setVoltage(self, output: wpimath.units.volts) -> None:
        """
        Sets the voltage output of the PWMMotorController. Compensates for
        the current bus voltage to ensure that the desired voltage is output even
        if the battery voltage is below 12V - highly useful when the voltage
        outputs are "meaningful" (e.g. they come from a feedforward calculation).
        
        NOTE: This function *must* be called regularly in order for voltage
        compensation to work properly - unlike the ordinary set function, it is not
        "set it and forget it."
        
        :param output: The voltage to output.
        """
    def stopMotor(self) -> None:
        ...
    @property
    def _m_pwm(self) -> PWM:
        """
        PWM instances for motor controller.
        """
class PWMSparkFlex(PWMMotorController):
    """
    REV Robotics SPARK Flex Motor Controller with PWM control.
    
    Note that the SPARK Flex uses the following bounds for PWM values. These
    values should work reasonably well for most controllers, but if users
    experience issues such as asymmetric behavior around the deadband or
    inability to saturate the controller in either direction, calibration is
    recommended. The calibration procedure can be found in the SPARK Flex User
    Manual available from REV Robotics.
    
    - 2.003ms = full "forward"
    - 1.550ms = the "high end" of the deadband range
    - 1.500ms = center of the deadband range (off)
    - 1.460ms = the "low end" of the deadband range
    - 0.999ms = full "reverse"
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for a SPARK Flex connected via PWM.
        
        :param channel: The PWM channel that the SPARK Flex is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
class PWMSparkMax(PWMMotorController):
    """
    REV Robotics SPARK MAX Motor Controller with PWM control.
    
    Note that the SPARK MAX uses the following bounds for PWM values. These
    values should work reasonably well for most controllers, but if users
    experience issues such as asymmetric behavior around the deadband or
    inability to saturate the controller in either direction, calibration is
    recommended. The calibration procedure can be found in the SPARK MAX User
    Manual available from REV Robotics.
    
    - 2.003ms = full "forward"
    - 1.550ms = the "high end" of the deadband range
    - 1.500ms = center of the deadband range (off)
    - 1.460ms = the "low end" of the deadband range
    - 0.999ms = full "reverse"
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for a SPARK MAX connected via PWM.
        
        :param channel: The PWM channel that the SPARK MAX is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
class PWMTalonFX(PWMMotorController):
    """
    Cross the Road Electronics (CTRE) Talon FX Motor Controller with PWM control.
    
    Note that the Talon FX uses the following bounds for PWM values. These
    values should work reasonably well for most controllers, but if users
    experience issues such as asymmetric behavior around the deadband or
    inability to saturate the controller in either direction, calibration is
    recommended. The calibration procedure can be found in the Talon FX User
    Manual available from Cross the Road Electronics (CTRE).
    
    - 2.004ms = full "forward"
    - 1.520ms = the "high end" of the deadband range
    - 1.500ms = center of the deadband range (off)
    - 1.480ms = the "low end" of the deadband range
    - 0.997ms = full "reverse"
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for a Talon FX connected via PWM.
        
        :param channel: The PWM channel that the Talon FX is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
class PWMTalonSRX(PWMMotorController):
    """
    Cross the Road Electronics (CTRE) Talon SRX Motor Controller with PWM control.
    
    Note that the Talon SRX uses the following bounds for PWM values. These
    values should work reasonably well for most controllers, but if users
    experience issues such as asymmetric behavior around the deadband or
    inability to saturate the controller in either direction, calibration is
    recommended. The calibration procedure can be found in the Talon SRX User
    Manual available from Cross the Road Electronics (CTRE).
    
    - 2.004ms = full "forward"
    - 1.520ms = the "high end" of the deadband range
    - 1.500ms = center of the deadband range (off)
    - 1.480ms = the "low end" of the deadband range
    - 0.997ms = full "reverse"
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for a Talon SRX connected via PWM.
        
        :param channel: The PWM channel that the Talon SRX is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
class PWMVenom(PWMMotorController):
    """
    Playing with Fusion Venom Motor Controller with PWM control.
    
    Note that the Venom uses the following bounds for PWM values. These
    values should work reasonably well for most controllers, but if users
    experience issues such as asymmetric behavior around the deadband or
    inability to saturate the controller in either direction, calibration is
    recommended. The calibration procedure can be found in the Venom User
    Manual available from Playing with Fusion.
    
    - 2.004ms = full "forward"
    - 1.520ms = the "high end" of the deadband range
    - 1.500ms = center of the deadband range (off)
    - 1.480ms = the "low end" of the deadband range
    - 0.997ms = full "reverse"
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for a Venom connected via PWM.
        
        :param channel: The PWM channel that the Venom is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
class PWMVictorSPX(PWMMotorController):
    """
    Cross the Road Electronics (CTRE) Victor SPX Motor Controller with PWM control.
    
    Note that the Victor SPX uses the following bounds for PWM values. These
    values should work reasonably well for most controllers, but if users
    experience issues such as asymmetric behavior around the deadband or
    inability to saturate the controller in either direction, calibration is
    recommended. The calibration procedure can be found in the Victor SPX User
    Manual available from Cross the Road Electronics (CTRE).
    
    - 2.004ms = full "forward"
    - 1.520ms = the "high end" of the deadband range
    - 1.500ms = center of the deadband range (off)
    - 1.480ms = the "low end" of the deadband range
    - 0.997ms = full "reverse"
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for a Victor SPX connected via PWM.
        
        :param channel: The PWM channel that the Victor SPX is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
class PneumaticHub(PneumaticsBase):
    """
    Module class for controlling a REV Robotics Pneumatic Hub.
    """
    class Faults:
        """
        Faults for a REV PH. These faults are only active while the condition is
        active.
        """
        def __init__(self) -> None:
            ...
        def getChannelFault(self, channel: typing.SupportsInt) -> bool:
            """
            Gets whether there is a fault at the specified channel.
            
            :param channel: Channel to check for faults.
            
            :returns: True if a a fault exists at the channel, otherwise false.
                      @throws A ChannelIndexOutOfRange error if the provided channel is outside
                      of the range supported by the hardware.
            """
        @property
        def Brownout(self) -> int:
            """
            The input voltage is below the minimum voltage.
            """
        @Brownout.setter
        def Brownout(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def CanWarning(self) -> int:
            """
            A warning was raised by the device's CAN controller.
            """
        @CanWarning.setter
        def CanWarning(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel0Fault(self) -> int:
            """
            Fault on channel 0.
            """
        @Channel0Fault.setter
        def Channel0Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel10Fault(self) -> int:
            """
            Fault on channel 10.
            """
        @Channel10Fault.setter
        def Channel10Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel11Fault(self) -> int:
            """
            Fault on channel 11.
            """
        @Channel11Fault.setter
        def Channel11Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel12Fault(self) -> int:
            """
            Fault on channel 12.
            """
        @Channel12Fault.setter
        def Channel12Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel13Fault(self) -> int:
            """
            Fault on channel 13.
            """
        @Channel13Fault.setter
        def Channel13Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel14Fault(self) -> int:
            """
            Fault on channel 14.
            """
        @Channel14Fault.setter
        def Channel14Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel15Fault(self) -> int:
            """
            Fault on channel 15.
            """
        @Channel15Fault.setter
        def Channel15Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel1Fault(self) -> int:
            """
            Fault on channel 1.
            """
        @Channel1Fault.setter
        def Channel1Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel2Fault(self) -> int:
            """
            Fault on channel 2.
            """
        @Channel2Fault.setter
        def Channel2Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel3Fault(self) -> int:
            """
            Fault on channel 3.
            """
        @Channel3Fault.setter
        def Channel3Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel4Fault(self) -> int:
            """
            Fault on channel 4.
            """
        @Channel4Fault.setter
        def Channel4Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel5Fault(self) -> int:
            """
            Fault on channel 5.
            """
        @Channel5Fault.setter
        def Channel5Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel6Fault(self) -> int:
            """
            Fault on channel 6.
            """
        @Channel6Fault.setter
        def Channel6Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel7Fault(self) -> int:
            """
            Fault on channel 7.
            """
        @Channel7Fault.setter
        def Channel7Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel8Fault(self) -> int:
            """
            Fault on channel 8.
            """
        @Channel8Fault.setter
        def Channel8Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel9Fault(self) -> int:
            """
            Fault on channel 9.
            """
        @Channel9Fault.setter
        def Channel9Fault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def CompressorOpen(self) -> int:
            """
            The compressor output has an open circuit.
            """
        @CompressorOpen.setter
        def CompressorOpen(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def CompressorOverCurrent(self) -> int:
            """
            An overcurrent event occurred on the compressor output.
            """
        @CompressorOverCurrent.setter
        def CompressorOverCurrent(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def HardwareFault(self) -> int:
            """
            The hardware on the device has malfunctioned.
            """
        @HardwareFault.setter
        def HardwareFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def SolenoidOverCurrent(self) -> int:
            """
            An overcurrent event occurred on a solenoid output.
            """
        @SolenoidOverCurrent.setter
        def SolenoidOverCurrent(self, arg1: typing.SupportsInt) -> None:
            ...
    class StickyFaults:
        """
        Sticky faults for a REV PH. These faults will remain active until they
        are reset by the user.
        """
        def __init__(self) -> None:
            ...
        @property
        def Brownout(self) -> int:
            """
            The input voltage is below the minimum voltage.
            """
        @Brownout.setter
        def Brownout(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def CanBusOff(self) -> int:
            """
            The device's CAN controller experienced a "Bus Off" event.
            """
        @CanBusOff.setter
        def CanBusOff(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def CanWarning(self) -> int:
            """
            A warning was raised by the device's CAN controller.
            """
        @CanWarning.setter
        def CanWarning(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def CompressorOpen(self) -> int:
            """
            The compressor output has an open circuit.
            """
        @CompressorOpen.setter
        def CompressorOpen(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def CompressorOverCurrent(self) -> int:
            """
            An overcurrent event occurred on the compressor output.
            """
        @CompressorOverCurrent.setter
        def CompressorOverCurrent(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def FirmwareFault(self) -> int:
            """
            The firmware on the device has malfunctioned.
            """
        @FirmwareFault.setter
        def FirmwareFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def HardwareFault(self) -> int:
            """
            The hardware on the device has malfunctioned.
            """
        @HardwareFault.setter
        def HardwareFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def HasReset(self) -> int:
            """
            The device has rebooted.
            """
        @HasReset.setter
        def HasReset(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def SolenoidOverCurrent(self) -> int:
            """
            An overcurrent event occurred on a solenoid output.
            """
        @SolenoidOverCurrent.setter
        def SolenoidOverCurrent(self, arg1: typing.SupportsInt) -> None:
            ...
    class Version:
        """
        Version and device data received from a REV PH.
        """
        def __init__(self) -> None:
            ...
        @property
        def FirmwareFix(self) -> int:
            """
            The firmware fix version.
            """
        @FirmwareFix.setter
        def FirmwareFix(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def FirmwareMajor(self) -> int:
            """
            The firmware major version.
            """
        @FirmwareMajor.setter
        def FirmwareMajor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def FirmwareMinor(self) -> int:
            """
            The firmware minor version.
            """
        @FirmwareMinor.setter
        def FirmwareMinor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def HardwareMajor(self) -> int:
            """
            The hardware major version.
            """
        @HardwareMajor.setter
        def HardwareMajor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def HardwareMinor(self) -> int:
            """
            The hardware minor version.
            """
        @HardwareMinor.setter
        def HardwareMinor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def UniqueId(self) -> int:
            """
            The device's unique ID.
            """
        @UniqueId.setter
        def UniqueId(self, arg0: typing.SupportsInt) -> None:
            ...
    @typing.overload
    def __init__(self) -> None:
        """
        Constructs a PneumaticHub with the default ID (1).
        """
    @typing.overload
    def __init__(self, module: typing.SupportsInt) -> None:
        """
        Constructs a PneumaticHub.
        
        :param module: module number to construct
        """
    def checkAndReserveSolenoids(self, mask: typing.SupportsInt) -> int:
        ...
    def checkSolenoidChannel(self, channel: typing.SupportsInt) -> bool:
        ...
    def clearStickyFaults(self) -> None:
        """
        Clears the sticky faults.
        """
    def disableCompressor(self) -> None:
        """
        Disables the compressor. The compressor will not turn on until
        EnableCompressorDigital(), EnableCompressorAnalog(), or
        EnableCompressorHybrid() are called.
        """
    def enableCompressorAnalog(self, minPressure: wpimath.units.pounds_per_square_inch, maxPressure: wpimath.units.pounds_per_square_inch) -> None:
        """
        Enables the compressor in analog mode. This mode uses an analog pressure
        sensor connected to analog channel 0 to cycle the compressor. The
        compressor will turn on when the pressure drops below ``minPressure``
        and will turn off when the pressure reaches ``maxPressure``.
        
        :param minPressure: The minimum pressure. The compressor will turn on when
                            the pressure drops below this value. Range 0 - 120 PSI.
        :param maxPressure: The maximum pressure. The compressor will turn off when
                            the pressure reaches this value. Range 0 - 120 PSI. Must be larger then
                            minPressure.
        """
    def enableCompressorDigital(self) -> None:
        ...
    def enableCompressorHybrid(self, minPressure: wpimath.units.pounds_per_square_inch, maxPressure: wpimath.units.pounds_per_square_inch) -> None:
        """
        Enables the compressor in hybrid mode. This mode uses both a digital
        pressure switch and an analog pressure sensor connected to analog channel 0
        to cycle the compressor.
        
        The compressor will turn on when \\a both:
        
        - The digital pressure switch indicates the system is not full AND
        - The analog pressure sensor indicates that the pressure in the system is
        below the specified minimum pressure.
        
        The compressor will turn off when \\a either:
        
        - The digital pressure switch is disconnected or indicates that the system
        is full OR
        - The pressure detected by the analog sensor is greater than the specified
        maximum pressure.
        
        :param minPressure: The minimum pressure. The compressor will turn on when
                            the pressure drops below this value and the pressure switch indicates that
                            the system is not full.  Range 0 - 120 PSI.
        :param maxPressure: The maximum pressure. The compressor will turn off when
                            the pressure reaches this value or the pressure switch is disconnected or
                            indicates that the system is full. Range 0 - 120 PSI. Must be larger then
                            minPressure.
        """
    def fireOneShot(self, index: typing.SupportsInt) -> None:
        ...
    def get5VRegulatedVoltage(self) -> wpimath.units.volts:
        """
        Returns the current voltage of the regulated 5v supply.
        
        :returns: The current voltage of the 5v supply.
        """
    def getAnalogVoltage(self, channel: typing.SupportsInt) -> wpimath.units.volts:
        """
        Returns the raw voltage of the specified analog input channel.
        
        :param channel: The analog input channel to read voltage from.
        
        :returns: The voltage of the specified analog input channel.
        """
    def getCompressor(self) -> bool:
        ...
    def getCompressorConfigType(self) -> CompressorConfigType:
        ...
    def getCompressorCurrent(self) -> wpimath.units.amperes:
        ...
    def getFaults(self) -> PneumaticHub.Faults:
        """
        Returns the faults currently active on this device.
        
        :returns: The faults.
        """
    def getInputVoltage(self) -> wpimath.units.volts:
        """
        Returns the current input voltage for this device.
        
        :returns: The input voltage.
        """
    def getModuleNumber(self) -> int:
        ...
    def getPressure(self, channel: typing.SupportsInt) -> wpimath.units.pounds_per_square_inch:
        """
        Returns the pressure read by an analog pressure sensor on the specified
        analog input channel.
        
        :param channel: The analog input channel to read pressure from.
        
        :returns: The pressure read by an analog pressure sensor on the specified
                  analog input channel.
        """
    def getPressureSwitch(self) -> bool:
        ...
    def getSolenoidDisabledList(self) -> int:
        ...
    def getSolenoids(self) -> int:
        ...
    def getSolenoidsTotalCurrent(self) -> wpimath.units.amperes:
        """
        Returns the total current drawn by all solenoids.
        
        :returns: Total current drawn by all solenoids.
        """
    def getSolenoidsVoltage(self) -> wpimath.units.volts:
        """
        Returns the current voltage of the solenoid power supply.
        
        :returns: The current voltage of the solenoid power supply.
        """
    def getStickyFaults(self) -> PneumaticHub.StickyFaults:
        """
        Returns the sticky faults currently active on this device.
        
        :returns: The sticky faults.
        """
    def getVersion(self) -> PneumaticHub.Version:
        """
        Returns the hardware and firmware versions of this device.
        
        :returns: The hardware and firmware versions.
        """
    def makeCompressor(self) -> Compressor:
        ...
    def makeDoubleSolenoid(self, forwardChannel: typing.SupportsInt, reverseChannel: typing.SupportsInt) -> DoubleSolenoid:
        ...
    def makeSolenoid(self, channel: typing.SupportsInt) -> Solenoid:
        ...
    def reserveCompressor(self) -> bool:
        ...
    def setOneShotDuration(self, index: typing.SupportsInt, duration: wpimath.units.seconds) -> None:
        ...
    def setSolenoids(self, mask: typing.SupportsInt, values: typing.SupportsInt) -> None:
        ...
    def unreserveCompressor(self) -> None:
        ...
    def unreserveSolenoids(self, mask: typing.SupportsInt) -> None:
        ...
class PneumaticsBase:
    """
    Base class for pneumatics devices.
    """
    @staticmethod
    def getDefaultForType(moduleType: PneumaticsModuleType) -> int:
        """
        For internal use to get the default for a specific type.
        
        :param moduleType: module type
        
        :returns: module default
        """
    @staticmethod
    def getForType(module: typing.SupportsInt, moduleType: PneumaticsModuleType) -> PneumaticsBase:
        """
        For internal use to get a module for a specific type.
        
        :param module:     module number
        :param moduleType: module type
        
        :returns: module
        """
    def __init__(self) -> None:
        ...
    def checkAndReserveSolenoids(self, mask: typing.SupportsInt) -> int:
        """
        Check to see if the solenoids marked in the bitmask can be reserved, and if
        so, reserve them.
        
        :param mask: The bitmask of solenoids to reserve. The LSB represents
                     solenoid 0.
        
        :returns: 0 if successful; mask of solenoids that couldn't be allocated
                  otherwise
        """
    def checkSolenoidChannel(self, channel: typing.SupportsInt) -> bool:
        """
        Check if a solenoid channel is valid.
        
        :param channel: Channel to check
        
        :returns: True if channel exists
        """
    def disableCompressor(self) -> None:
        """
        Disables the compressor.
        """
    def enableCompressorAnalog(self, minPressure: wpimath.units.pounds_per_square_inch, maxPressure: wpimath.units.pounds_per_square_inch) -> None:
        """
        If supported by the device, enables the compressor in analog mode. This
        mode uses an analog pressure sensor connected to analog channel 0 to cycle
        the compressor. The compressor will turn on when the pressure drops below
        ``minPressure`` and will turn off when the pressure reaches {@code
        maxPressure}. This mode is only supported by the REV PH with the REV Analog
        Pressure Sensor connected to analog channel 0.
        
        On CTRE PCM, this will enable digital control.
        
        :param minPressure: The minimum pressure. The compressor will turn on
                            when the pressure drops below this value.
        :param maxPressure: The maximum pressure. The compressor will turn
                            off when the pressure reaches this value.
        """
    def enableCompressorDigital(self) -> None:
        """
        Enables the compressor in digital mode using the digital pressure switch.
        The compressor will turn on when the pressure switch indicates that the
        system is not full, and will turn off when the pressure switch indicates
        that the system is full.
        """
    def enableCompressorHybrid(self, minPressure: wpimath.units.pounds_per_square_inch, maxPressure: wpimath.units.pounds_per_square_inch) -> None:
        """
        If supported by the device, enables the compressor in hybrid mode. This
        mode uses both a digital pressure switch and an analog pressure sensor
        connected to analog channel 0 to cycle the compressor. This mode is only
        supported by the REV PH with the REV Analog Pressure Sensor connected to
        analog channel 0.
        
        The compressor will turn on when \\a both:
        
        - The digital pressure switch indicates the system is not full AND
        - The analog pressure sensor indicates that the pressure in the system
        is below the specified minimum pressure.
        
        The compressor will turn off when \\a either:
        
        - The digital pressure switch is disconnected or indicates that the system
        is full OR
        - The pressure detected by the analog sensor is greater than the specified
        maximum pressure.
        
        On CTRE PCM, this will enable digital control.
        
        :param minPressure: The minimum pressure. The compressor will turn on
                            when the pressure drops below this value and the pressure switch indicates
                            that the system is not full.
        :param maxPressure: The maximum pressure. The compressor will turn
                            off when the pressure reaches this value or the pressure switch is
                            disconnected or indicates that the system is full.
        """
    def fireOneShot(self, index: typing.SupportsInt) -> None:
        """
        Fire a single solenoid shot.
        
        :param index: solenoid index
        """
    def getAnalogVoltage(self, channel: typing.SupportsInt) -> wpimath.units.volts:
        """
        If supported by the device, returns the raw voltage of the specified analog
        input channel.
        
        This function is only supported by the REV PH. On CTRE PCM, this will
        return 0.
        
        :param channel: The analog input channel to read voltage from.
        
        :returns: The voltage of the specified analog input channel.
        """
    def getCompressor(self) -> bool:
        """
        Returns whether the compressor is active or not.
        
        :returns: True if the compressor is on - otherwise false.
        """
    def getCompressorConfigType(self) -> CompressorConfigType:
        """
        Returns the active compressor configuration.
        
        :returns: The active compressor configuration.
        """
    def getCompressorCurrent(self) -> wpimath.units.amperes:
        """
        Returns the current drawn by the compressor.
        
        :returns: The current drawn by the compressor.
        """
    def getModuleNumber(self) -> int:
        """
        Get module number for this module.
        
        :returns: module number
        """
    def getPressure(self, channel: typing.SupportsInt) -> wpimath.units.pounds_per_square_inch:
        """
        If supported by the device, returns the pressure read by an analog
        pressure sensor on the specified analog input channel.
        
        This function is only supported by the REV PH. On CTRE PCM, this will
        return 0.
        
        :param channel: The analog input channel to read pressure from.
        
        :returns: The pressure read by an analog pressure sensor on the
                  specified analog input channel.
        """
    def getPressureSwitch(self) -> bool:
        """
        Returns the state of the pressure switch.
        
        :returns: True if pressure switch indicates that the system is full,
                  otherwise false.
        """
    def getSolenoidDisabledList(self) -> int:
        """
        Get a bitmask of disabled solenoids.
        
        :returns: Bitmask indicating disabled solenoids. The LSB represents solenoid
                  0.
        """
    def getSolenoids(self) -> int:
        """
        Gets a bitmask of solenoid values.
        
        :returns: Bitmask containing the state of the solenoids. The LSB represents
                  solenoid 0.
        """
    def makeCompressor(self) -> Compressor:
        """
        Create a compressor object.
        
        :returns: Compressor object
        """
    def makeDoubleSolenoid(self, forwardChannel: typing.SupportsInt, reverseChannel: typing.SupportsInt) -> DoubleSolenoid:
        """
        Create a double solenoid object for the specified channels.
        
        :param forwardChannel: solenoid channel for forward
        :param reverseChannel: solenoid channel for reverse
        
        :returns: DoubleSolenoid object
        """
    def makeSolenoid(self, channel: typing.SupportsInt) -> Solenoid:
        """
        Create a solenoid object for the specified channel.
        
        :param channel: solenoid channel
        
        :returns: Solenoid object
        """
    def reserveCompressor(self) -> bool:
        """
        Reserve the compressor.
        
        :returns: true if successful; false if compressor already reserved
        """
    def setOneShotDuration(self, index: typing.SupportsInt, duration: wpimath.units.seconds) -> None:
        """
        Set the duration for a single solenoid shot.
        
        :param index:    solenoid index
        :param duration: shot duration
        """
    def setSolenoids(self, mask: typing.SupportsInt, values: typing.SupportsInt) -> None:
        """
        Sets solenoids on a pneumatics module.
        
        :param mask:   Bitmask indicating which solenoids to set. The LSB represents
                       solenoid 0.
        :param values: Bitmask indicating the desired states of the solenoids. The
                       LSB represents solenoid 0.
        """
    def unreserveCompressor(self) -> None:
        """
        Unreserve the compressor.
        """
    def unreserveSolenoids(self, mask: typing.SupportsInt) -> None:
        """
        Unreserve the solenoids marked in the bitmask.
        
        :param mask: The bitmask of solenoids to unreserve. The LSB represents
                     solenoid 0.
        """
class PneumaticsControlModule(PneumaticsBase):
    """
    Module class for controlling a Cross The Road Electronics Pneumatics Control
    Module.
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Constructs a PneumaticsControlModule with the default ID (0).
        """
    @typing.overload
    def __init__(self, module: typing.SupportsInt) -> None:
        """
        Constructs a PneumaticsControlModule.
        
        :param module: module number to construct
        """
    def checkAndReserveSolenoids(self, mask: typing.SupportsInt) -> int:
        ...
    def checkSolenoidChannel(self, channel: typing.SupportsInt) -> bool:
        ...
    def clearAllStickyFaults(self) -> None:
        """
        Clears all sticky faults on this device.
        """
    def disableCompressor(self) -> None:
        """
        Disables the compressor. The compressor will not turn on until
        EnableCompressorDigital() is called.
        """
    def enableCompressorAnalog(self, minPressure: wpimath.units.pounds_per_square_inch, maxPressure: wpimath.units.pounds_per_square_inch) -> None:
        """
        Enables the compressor in digital mode. Analog mode is unsupported by the
        CTRE PCM.
        
        :param minPressure: Unsupported.
        :param maxPressure: Unsupported.
                            @see EnableCompressorDigital()
        """
    def enableCompressorDigital(self) -> None:
        ...
    def enableCompressorHybrid(self, minPressure: wpimath.units.pounds_per_square_inch, maxPressure: wpimath.units.pounds_per_square_inch) -> None:
        """
        Enables the compressor in digital mode. Hybrid mode is unsupported by the
        CTRE PCM.
        
        :param minPressure: Unsupported.
        :param maxPressure: Unsupported.
                            @see EnableCompressorDigital()
        """
    def fireOneShot(self, index: typing.SupportsInt) -> None:
        ...
    def getAnalogVoltage(self, channel: typing.SupportsInt) -> wpimath.units.volts:
        """
        Unsupported by the CTRE PCM.
        
        :param channel: Unsupported.
        
        :returns: 0
        """
    def getCompressor(self) -> bool:
        ...
    def getCompressorConfigType(self) -> CompressorConfigType:
        ...
    def getCompressorCurrent(self) -> wpimath.units.amperes:
        ...
    def getCompressorCurrentTooHighFault(self) -> bool:
        """
        Return whether the compressor current is currently too high.
        
        :returns: True if the compressor current is too high, otherwise false.
                  @see GetCompressorCurrentTooHighStickyFault()
        """
    def getCompressorCurrentTooHighStickyFault(self) -> bool:
        """
        Returns whether the compressor current has been too high since sticky
        faults were last cleared. This fault is persistent and can be cleared by
        ClearAllStickyFaults()
        
        :returns: True if the compressor current has been too high since sticky
                  faults were last cleared.
                  @see GetCompressorCurrentTooHighFault()
        """
    def getCompressorNotConnectedFault(self) -> bool:
        """
        Returns whether the compressor is currently disconnected.
        
        :returns: True if compressor is currently disconnected, otherwise false.
                  @see GetCompressorNotConnectedStickyFault()
        """
    def getCompressorNotConnectedStickyFault(self) -> bool:
        """
        Returns whether the compressor has been disconnected since sticky faults
        were last cleared. This fault is persistent and can be cleared by
        ClearAllStickyFaults()
        
        :returns: True if the compressor has been disconnected since sticky faults
                  were last cleared, otherwise false.
                  @see GetCompressorNotConnectedFault()
        """
    def getCompressorShortedFault(self) -> bool:
        """
        Returns whether the compressor is currently shorted.
        
        :returns: True if the compressor is currently shorted, otherwise false.
                  @see GetCompressorShortedStickyFault()
        """
    def getCompressorShortedStickyFault(self) -> bool:
        """
        Returns whether the compressor has been shorted since sticky faults were
        last cleared. This fault is persistent and can be cleared by
        ClearAllStickyFaults()
        
        :returns: True if the compressor has been shorted since sticky faults were
                  last cleared, otherwise false.
                  @see GetCompressorShortedFault()
        """
    def getModuleNumber(self) -> int:
        ...
    def getPressure(self, channel: typing.SupportsInt) -> wpimath.units.pounds_per_square_inch:
        """
        Unsupported by the CTRE PCM.
        
        :param channel: Unsupported.
        
        :returns: 0
        """
    def getPressureSwitch(self) -> bool:
        ...
    def getSolenoidDisabledList(self) -> int:
        ...
    def getSolenoidVoltageFault(self) -> bool:
        """
        Returns whether the solenoid is currently reporting a voltage fault.
        
        :returns: True if solenoid is reporting a fault, otherwise false.
                  @see GetSolenoidVoltageStickyFault()
        """
    def getSolenoidVoltageStickyFault(self) -> bool:
        """
        Returns whether the solenoid has reported a voltage fault since sticky
        faults were last cleared. This fault is persistent and can be cleared by
        ClearAllStickyFaults()
        
        :returns: True if solenoid is reporting a fault, otherwise false.
                  @see GetSolenoidVoltageFault()
        """
    def getSolenoids(self) -> int:
        ...
    def makeCompressor(self) -> Compressor:
        ...
    def makeDoubleSolenoid(self, forwardChannel: typing.SupportsInt, reverseChannel: typing.SupportsInt) -> DoubleSolenoid:
        ...
    def makeSolenoid(self, channel: typing.SupportsInt) -> Solenoid:
        ...
    def reserveCompressor(self) -> bool:
        ...
    def setOneShotDuration(self, index: typing.SupportsInt, duration: wpimath.units.seconds) -> None:
        ...
    def setSolenoids(self, mask: typing.SupportsInt, values: typing.SupportsInt) -> None:
        ...
    def unreserveCompressor(self) -> None:
        ...
    def unreserveSolenoids(self, mask: typing.SupportsInt) -> None:
        ...
class PneumaticsModuleType:
    """
    Pneumatics module type.
    
    Members:
    
      CTREPCM : CTRE PCM.
    
      REVPH : REV PH.
    """
    CTREPCM: typing.ClassVar[PneumaticsModuleType]  # value = <PneumaticsModuleType.CTREPCM: 0>
    REVPH: typing.ClassVar[PneumaticsModuleType]  # value = <PneumaticsModuleType.REVPH: 1>
    __members__: typing.ClassVar[dict[str, PneumaticsModuleType]]  # value = {'CTREPCM': <PneumaticsModuleType.CTREPCM: 0>, 'REVPH': <PneumaticsModuleType.REVPH: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class PowerDistribution(wpiutil._wpiutil.Sendable):
    """
    Class for getting voltage, current, temperature, power and energy from the
    CTRE Power Distribution Panel (PDP) or REV Power Distribution Hub (PDH).
    """
    class Faults:
        """
        Faults for a PowerDistribution device. These faults are only active while
        the condition is active.
        """
        def __init__(self) -> None:
            ...
        def getBreakerFault(self, channel: typing.SupportsInt) -> bool:
            """
            Gets whether there is a breaker fault at a specified channel.
            
            :param channel: Channel to check for faults.
            
            :returns: If there is a breaker fault.
                      @throws A ChannelIndexOutOfRange error if the given int is outside of the
                      range supported by the hardware.
            """
        @property
        def Brownout(self) -> int:
            """
            The input voltage is below the minimum voltage.
            """
        @Brownout.setter
        def Brownout(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def CanWarning(self) -> int:
            """
            A warning was raised by the device's CAN controller.
            """
        @CanWarning.setter
        def CanWarning(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel0BreakerFault(self) -> int:
            """
            Breaker fault on channel 0.
            """
        @Channel0BreakerFault.setter
        def Channel0BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel10BreakerFault(self) -> int:
            """
            Breaker fault on channel 10.
            """
        @Channel10BreakerFault.setter
        def Channel10BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel11BreakerFault(self) -> int:
            """
            Breaker fault on channel 12.
            """
        @Channel11BreakerFault.setter
        def Channel11BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel12BreakerFault(self) -> int:
            """
            Breaker fault on channel 13.
            """
        @Channel12BreakerFault.setter
        def Channel12BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel13BreakerFault(self) -> int:
            """
            Breaker fault on channel 14.
            """
        @Channel13BreakerFault.setter
        def Channel13BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel14BreakerFault(self) -> int:
            """
            Breaker fault on channel 15.
            """
        @Channel14BreakerFault.setter
        def Channel14BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel15BreakerFault(self) -> int:
            """
            Breaker fault on channel 16.
            """
        @Channel15BreakerFault.setter
        def Channel15BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel16BreakerFault(self) -> int:
            """
            Breaker fault on channel 17.
            """
        @Channel16BreakerFault.setter
        def Channel16BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel17BreakerFault(self) -> int:
            """
            Breaker fault on channel 18.
            """
        @Channel17BreakerFault.setter
        def Channel17BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel18BreakerFault(self) -> int:
            """
            Breaker fault on channel 19.
            """
        @Channel18BreakerFault.setter
        def Channel18BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel19BreakerFault(self) -> int:
            """
            Breaker fault on channel 20.
            """
        @Channel19BreakerFault.setter
        def Channel19BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel1BreakerFault(self) -> int:
            """
            Breaker fault on channel 1.
            """
        @Channel1BreakerFault.setter
        def Channel1BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel20BreakerFault(self) -> int:
            """
            Breaker fault on channel 21.
            """
        @Channel20BreakerFault.setter
        def Channel20BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel21BreakerFault(self) -> int:
            """
            Breaker fault on channel 22.
            """
        @Channel21BreakerFault.setter
        def Channel21BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel22BreakerFault(self) -> int:
            """
            Breaker fault on channel 23.
            """
        @Channel22BreakerFault.setter
        def Channel22BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel23BreakerFault(self) -> int:
            """
            Breaker fault on channel 24.
            """
        @Channel23BreakerFault.setter
        def Channel23BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel2BreakerFault(self) -> int:
            """
            Breaker fault on channel 2.
            """
        @Channel2BreakerFault.setter
        def Channel2BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel3BreakerFault(self) -> int:
            """
            Breaker fault on channel 3.
            """
        @Channel3BreakerFault.setter
        def Channel3BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel4BreakerFault(self) -> int:
            """
            Breaker fault on channel 4.
            """
        @Channel4BreakerFault.setter
        def Channel4BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel5BreakerFault(self) -> int:
            """
            Breaker fault on channel 5.
            """
        @Channel5BreakerFault.setter
        def Channel5BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel6BreakerFault(self) -> int:
            """
            Breaker fault on channel 6.
            """
        @Channel6BreakerFault.setter
        def Channel6BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel7BreakerFault(self) -> int:
            """
            Breaker fault on channel 7.
            """
        @Channel7BreakerFault.setter
        def Channel7BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel8BreakerFault(self) -> int:
            """
            Breaker fault on channel 8.
            """
        @Channel8BreakerFault.setter
        def Channel8BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel9BreakerFault(self) -> int:
            """
            Breaker fault on channel 9.
            """
        @Channel9BreakerFault.setter
        def Channel9BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def HardwareFault(self) -> int:
            """
            The hardware on the device has malfunctioned.
            """
        @HardwareFault.setter
        def HardwareFault(self, arg1: typing.SupportsInt) -> None:
            ...
    class ModuleType:
        """
        Power distribution module type.
        
        Members:
        
          kCTRE : CTRE (Cross The Road Electronics) CTRE Power Distribution Panel (PDP).
        
          kRev : REV Power Distribution Hub (PDH).
        """
        __members__: typing.ClassVar[dict[str, PowerDistribution.ModuleType]]  # value = {'kCTRE': <ModuleType.kCTRE: 1>, 'kRev': <ModuleType.kRev: 2>}
        kCTRE: typing.ClassVar[PowerDistribution.ModuleType]  # value = <ModuleType.kCTRE: 1>
        kRev: typing.ClassVar[PowerDistribution.ModuleType]  # value = <ModuleType.kRev: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class StickyFaults:
        """
        Sticky faults for a PowerDistribution device. These faults will remain
        active until they are reset by the user.
        """
        def __init__(self) -> None:
            ...
        def getBreakerFault(self, channel: typing.SupportsInt) -> bool:
            """
            Gets whether there is a sticky breaker fault at the specified channel.
            
            :param channel: Index to check for sticky faults.
            
            :returns: True if there is a sticky breaker fault at the channel, otherwise
                      false.
                      @throws A ChannelIndexOutOfRange error if the provided channel is outside
                      of the range supported by the hardware.
            """
        @property
        def Brownout(self) -> int:
            """
            The input voltage is below the minimum voltage.
            """
        @Brownout.setter
        def Brownout(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def CanBusOff(self) -> int:
            """
            The device's CAN controller experienced a "Bus Off" event.
            """
        @CanBusOff.setter
        def CanBusOff(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def CanWarning(self) -> int:
            """
            A warning was raised by the device's CAN controller.
            """
        @CanWarning.setter
        def CanWarning(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel0BreakerFault(self) -> int:
            """
            Breaker fault on channel 0.
            """
        @Channel0BreakerFault.setter
        def Channel0BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel10BreakerFault(self) -> int:
            """
            Breaker fault on channel 10.
            """
        @Channel10BreakerFault.setter
        def Channel10BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel11BreakerFault(self) -> int:
            """
            Breaker fault on channel 12.
            """
        @Channel11BreakerFault.setter
        def Channel11BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel12BreakerFault(self) -> int:
            """
            Breaker fault on channel 13.
            """
        @Channel12BreakerFault.setter
        def Channel12BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel13BreakerFault(self) -> int:
            """
            Breaker fault on channel 14.
            """
        @Channel13BreakerFault.setter
        def Channel13BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel14BreakerFault(self) -> int:
            """
            Breaker fault on channel 15.
            """
        @Channel14BreakerFault.setter
        def Channel14BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel15BreakerFault(self) -> int:
            """
            Breaker fault on channel 16.
            """
        @Channel15BreakerFault.setter
        def Channel15BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel16BreakerFault(self) -> int:
            """
            Breaker fault on channel 17.
            """
        @Channel16BreakerFault.setter
        def Channel16BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel17BreakerFault(self) -> int:
            """
            Breaker fault on channel 18.
            """
        @Channel17BreakerFault.setter
        def Channel17BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel18BreakerFault(self) -> int:
            """
            Breaker fault on channel 19.
            """
        @Channel18BreakerFault.setter
        def Channel18BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel19BreakerFault(self) -> int:
            """
            Breaker fault on channel 20.
            """
        @Channel19BreakerFault.setter
        def Channel19BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel1BreakerFault(self) -> int:
            """
            Breaker fault on channel 1.
            """
        @Channel1BreakerFault.setter
        def Channel1BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel20BreakerFault(self) -> int:
            """
            Breaker fault on channel 21.
            """
        @Channel20BreakerFault.setter
        def Channel20BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel21BreakerFault(self) -> int:
            """
            Breaker fault on channel 22.
            """
        @Channel21BreakerFault.setter
        def Channel21BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel22BreakerFault(self) -> int:
            """
            Breaker fault on channel 23.
            """
        @Channel22BreakerFault.setter
        def Channel22BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel23BreakerFault(self) -> int:
            """
            Breaker fault on channel 24.
            """
        @Channel23BreakerFault.setter
        def Channel23BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel2BreakerFault(self) -> int:
            """
            Breaker fault on channel 2.
            """
        @Channel2BreakerFault.setter
        def Channel2BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel3BreakerFault(self) -> int:
            """
            Breaker fault on channel 3.
            """
        @Channel3BreakerFault.setter
        def Channel3BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel4BreakerFault(self) -> int:
            """
            Breaker fault on channel 4.
            """
        @Channel4BreakerFault.setter
        def Channel4BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel5BreakerFault(self) -> int:
            """
            Breaker fault on channel 5.
            """
        @Channel5BreakerFault.setter
        def Channel5BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel6BreakerFault(self) -> int:
            """
            Breaker fault on channel 6.
            """
        @Channel6BreakerFault.setter
        def Channel6BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel7BreakerFault(self) -> int:
            """
            Breaker fault on channel 7.
            """
        @Channel7BreakerFault.setter
        def Channel7BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel8BreakerFault(self) -> int:
            """
            Breaker fault on channel 8.
            """
        @Channel8BreakerFault.setter
        def Channel8BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def Channel9BreakerFault(self) -> int:
            """
            Breaker fault on channel 9.
            """
        @Channel9BreakerFault.setter
        def Channel9BreakerFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def FirmwareFault(self) -> int:
            """
            The firmware on the device has malfunctioned.
            """
        @FirmwareFault.setter
        def FirmwareFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def HardwareFault(self) -> int:
            """
            The hardware on the device has malfunctioned.
            """
        @HardwareFault.setter
        def HardwareFault(self, arg1: typing.SupportsInt) -> None:
            ...
        @property
        def HasReset(self) -> int:
            """
            The device has rebooted.
            """
        @HasReset.setter
        def HasReset(self, arg1: typing.SupportsInt) -> None:
            ...
    class Version:
        """
        Version and device data received from a PowerDistribution device
        """
        def __init__(self) -> None:
            ...
        @property
        def FirmwareFix(self) -> int:
            """
            Firmware fix version number.
            """
        @FirmwareFix.setter
        def FirmwareFix(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def FirmwareMajor(self) -> int:
            """
            Firmware major version number.
            """
        @FirmwareMajor.setter
        def FirmwareMajor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def FirmwareMinor(self) -> int:
            """
            Firmware minor version number.
            """
        @FirmwareMinor.setter
        def FirmwareMinor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def HardwareMajor(self) -> int:
            """
            Hardware major version number.
            """
        @HardwareMajor.setter
        def HardwareMajor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def HardwareMinor(self) -> int:
            """
            Hardware minor version number.
            """
        @HardwareMinor.setter
        def HardwareMinor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def UniqueId(self) -> int:
            """
            Unique ID.
            """
        @UniqueId.setter
        def UniqueId(self, arg0: typing.SupportsInt) -> None:
            ...
    kDefaultModule: typing.ClassVar[int] = -1
    @typing.overload
    def __init__(self) -> None:
        """
        Constructs a PowerDistribution object.
        
        Detects the connected PDP/PDH using the default CAN ID (0 for CTRE and 1
        for REV).
        """
    @typing.overload
    def __init__(self, module: typing.SupportsInt, moduleType: PowerDistribution.ModuleType) -> None:
        """
        Constructs a PowerDistribution object.
        
        :param module:     The CAN ID of the PDP/PDH
        :param moduleType: The type of module
        """
    def clearStickyFaults(self) -> None:
        """
        Remove all of the fault flags on the PDP/PDH.
        """
    def getAllCurrents(self) -> list[float]:
        """
        Query all currents of the PDP.
        
        :returns: The current of each channel in Amperes
        """
    def getCurrent(self, channel: typing.SupportsInt) -> float:
        """
        Query the current of a single channel of the PDP/PDH.
        
        :param channel: the channel to query (0-15 for PDP, 0-23 for PDH)
        
        :returns: The current of the channel in Amperes
        """
    def getFaults(self) -> PowerDistribution.Faults:
        """
        Returns the power distribution faults.
        
        On a CTRE PDP, this will return an object with no faults active.
        
        :returns: The power distribution faults.
        """
    def getModule(self) -> int:
        """
        Gets module number (CAN ID).
        """
    def getNumChannels(self) -> int:
        """
        Gets the number of channels for this power distribution object.
        
        :returns: Number of output channels (16 for PDP, 24 for PDH).
        """
    def getStickyFaults(self) -> PowerDistribution.StickyFaults:
        """
        Returns the power distribution sticky faults.
        
        On a CTRE PDP, this will return an object with no faults active.
        
        :returns: The power distribution sticky faults.
        """
    def getSwitchableChannel(self) -> bool:
        """
        Gets whether the PDH switchable channel is turned on or off. Returns false
        with the CTRE PDP.
        
        :returns: The output state of the PDH switchable channel
        """
    def getTemperature(self) -> float:
        """
        Query the temperature of the PDP.
        
        Not supported on the Rev PDH and returns 0.
        
        :returns: The temperature in degrees Celsius
        """
    def getTotalCurrent(self) -> float:
        """
        Query the total current of all monitored PDP/PDH channels.
        
        :returns: The total current drawn from all channels in Amperes
        """
    def getTotalEnergy(self) -> float:
        """
        Query the total energy drawn from the monitored PDP channels.
        
        Not supported on the Rev PDH and returns 0.
        
        :returns: The total energy drawn in Joules
        """
    def getTotalPower(self) -> float:
        """
        Query the total power drawn from all monitored PDP channels.
        
        Not supported on the Rev PDH and returns 0.
        
        :returns: The total power drawn in Watts
        """
    def getType(self) -> PowerDistribution.ModuleType:
        """
        Gets module type.
        """
    def getVersion(self) -> PowerDistribution.Version:
        ...
    def getVoltage(self) -> float:
        """
        Query the input voltage of the PDP/PDH.
        
        :returns: The input voltage in volts
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def resetTotalEnergy(self) -> None:
        """
        Reset the total energy drawn from the PDP.
        
        Not supported on the Rev PDH and does nothing.
        
        @see PowerDistribution#GetTotalEnergy
        """
    def setSwitchableChannel(self, enabled: bool) -> None:
        """
        Sets the PDH switchable channel on or off. Does nothing with the CTRE PDP.
        
        :param enabled: Whether to turn the PDH switchable channel on or off
        """
class Preferences:
    """
    The preferences class provides a relatively simple way to save important
    values to the roboRIO to access the next time the roboRIO is booted.
    
    This class loads and saves from a file inside the roboRIO.  The user cannot
    access the file directly, but may modify values at specific fields which will
    then be automatically periodically saved to the file by the NetworkTable
    server.
    
    This class is thread safe.
    
    This will also interact with NetworkTable by creating a table called
    "Preferences" with all the key-value pairs.
    """
    @staticmethod
    def containsKey(key: str) -> bool:
        """
        Returns whether or not there is a key with the given name.
        
        :param key: the key
        
        :returns: if there is a value at the given key
        """
    @staticmethod
    def getBoolean(key: str, defaultValue: bool = False) -> bool:
        """
        Returns the boolean at the given key.  If this table does not have a value
        for that position, then the given defaultValue value will be returned.
        
        :param key:          the key
        :param defaultValue: the value to return if none exists in the table
        
        :returns: either the value in the table, or the defaultValue
        """
    @staticmethod
    def getDouble(key: str, defaultValue: typing.SupportsFloat = 0.0) -> float:
        """
        Returns the double at the given key.  If this table does not have a value
        for that position, then the given defaultValue value will be returned.
        
        :param key:          the key
        :param defaultValue: the value to return if none exists in the table
        
        :returns: either the value in the table, or the defaultValue
        """
    @staticmethod
    def getFloat(key: str, defaultValue: typing.SupportsFloat = 0.0) -> float:
        """
        Returns the float at the given key.  If this table does not have a value
        for that position, then the given defaultValue value will be returned.
        
        :param key:          the key
        :param defaultValue: the value to return if none exists in the table
        
        :returns: either the value in the table, or the defaultValue
        """
    @staticmethod
    def getInt(key: str, defaultValue: typing.SupportsInt = 0) -> int:
        """
        Returns the int at the given key.  If this table does not have a value for
        that position, then the given defaultValue value will be returned.
        
        :param key:          the key
        :param defaultValue: the value to return if none exists in the table
        
        :returns: either the value in the table, or the defaultValue
        """
    @staticmethod
    def getKeys() -> list[str]:
        """
        Returns a vector of all the keys.
        
        :returns: a vector of the keys
        """
    @staticmethod
    def getLong(key: str, defaultValue: typing.SupportsInt = 0) -> int:
        """
        Returns the long (int64_t) at the given key.  If this table does not have a
        value for that position, then the given defaultValue value will be
        returned.
        
        :param key:          the key
        :param defaultValue: the value to return if none exists in the table
        
        :returns: either the value in the table, or the defaultValue
        """
    @staticmethod
    def getString(key: str, defaultValue: str = '') -> str:
        """
        Returns the string at the given key.  If this table does not have a value
        for that position, then the given defaultValue will be returned.
        
        :param key:          the key
        :param defaultValue: the value to return if none exists in the table
        
        :returns: either the value in the table, or the defaultValue
        """
    @staticmethod
    def initBoolean(key: str, value: bool) -> None:
        """
        Puts the given boolean into the preferences table if it doesn't
        already exist.
        """
    @staticmethod
    def initDouble(key: str, value: typing.SupportsFloat) -> None:
        """
        Puts the given double into the preferences table if it doesn't
        already exist.
        """
    @staticmethod
    def initFloat(key: str, value: typing.SupportsFloat) -> None:
        """
        Puts the given float into the preferences table if it doesn't
        already exist.
        """
    @staticmethod
    def initInt(key: str, value: typing.SupportsInt) -> None:
        """
        Puts the given int into the preferences table if it doesn't
        already exist.
        """
    @staticmethod
    def initLong(key: str, value: typing.SupportsInt) -> None:
        """
        Puts the given long into the preferences table if it doesn't
        already exist.
        """
    @staticmethod
    def initString(key: str, value: str) -> None:
        """
        Puts the given string into the preferences table if it doesn't
        already exist.
        """
    @staticmethod
    def remove(key: str) -> None:
        """
        Remove a preference.
        
        :param key: the key
        """
    @staticmethod
    def removeAll() -> None:
        """
        Remove all preferences.
        """
    @staticmethod
    def setBoolean(key: str, value: bool) -> None:
        """
        Puts the given boolean into the preferences table.
        
        The key may not have any whitespace nor an equals sign.
        
        :param key:   the key
        :param value: the value
        """
    @staticmethod
    def setDouble(key: str, value: typing.SupportsFloat) -> None:
        """
        Puts the given double into the preferences table.
        
        The key may not have any whitespace nor an equals sign.
        
        :param key:   the key
        :param value: the value
        """
    @staticmethod
    def setFloat(key: str, value: typing.SupportsFloat) -> None:
        """
        Puts the given float into the preferences table.
        
        The key may not have any whitespace nor an equals sign.
        
        :param key:   the key
        :param value: the value
        """
    @staticmethod
    def setInt(key: str, value: typing.SupportsInt) -> None:
        """
        Puts the given int into the preferences table.
        
        The key may not have any whitespace nor an equals sign.
        
        :param key:   the key
        :param value: the value
        """
    @staticmethod
    def setLong(key: str, value: typing.SupportsInt) -> None:
        """
        Puts the given long (int64_t) into the preferences table.
        
        The key may not have any whitespace nor an equals sign.
        
        :param key:   the key
        :param value: the value
        """
    @staticmethod
    def setString(key: str, value: str) -> None:
        """
        Puts the given string into the preferences table.
        
        The value may not have quotation marks, nor may the key have any whitespace
        nor an equals sign.
        
        :param key:   the key
        :param value: the value
        """
class RadioLEDState:
    """
    State for the radio led.
    
    Members:
    
      kOff : ///< Off.
    
      kGreen : ///< Green.
    
      kRed : ///< Red.
    
      kOrange : ///< Orange.
    """
    __members__: typing.ClassVar[dict[str, RadioLEDState]]  # value = {'kOff': <RadioLEDState.kOff: 0>, 'kGreen': <RadioLEDState.kGreen: 1>, 'kRed': <RadioLEDState.kRed: 2>, 'kOrange': <RadioLEDState.kOrange: 3>}
    kGreen: typing.ClassVar[RadioLEDState]  # value = <RadioLEDState.kGreen: 1>
    kOff: typing.ClassVar[RadioLEDState]  # value = <RadioLEDState.kOff: 0>
    kOrange: typing.ClassVar[RadioLEDState]  # value = <RadioLEDState.kOrange: 3>
    kRed: typing.ClassVar[RadioLEDState]  # value = <RadioLEDState.kRed: 2>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Relay(MotorSafety, wpiutil._wpiutil.Sendable):
    """
    Class for Spike style relay outputs.
    
    Relays are intended to be connected to spikes or similar relays. The relay
    channels controls a pair of pins that are either both off, one on, the other
    on, or both on. This translates into two spike outputs at 0v, one at 12v and
    one at 0v, one at 0v and the other at 12v, or two spike outputs at 12V. This
    allows off, full forward, or full reverse control of motors without variable
    speed. It also allows the two channels (forward and reverse) to be used
    independently for something that does not care about voltage polarity (like
    a solenoid).
    """
    class Direction:
        """
        The Direction(s) that a relay is configured to operate in.
        
        Members:
        
          kBothDirections : Both directions are valid.
        
          kForwardOnly : Only forward is valid.
        
          kReverseOnly : Only reverse is valid.
        """
        __members__: typing.ClassVar[dict[str, Relay.Direction]]  # value = {'kBothDirections': <Direction.kBothDirections: 0>, 'kForwardOnly': <Direction.kForwardOnly: 1>, 'kReverseOnly': <Direction.kReverseOnly: 2>}
        kBothDirections: typing.ClassVar[Relay.Direction]  # value = <Direction.kBothDirections: 0>
        kForwardOnly: typing.ClassVar[Relay.Direction]  # value = <Direction.kForwardOnly: 1>
        kReverseOnly: typing.ClassVar[Relay.Direction]  # value = <Direction.kReverseOnly: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Value:
        """
        The state to drive a Relay to.
        
        Members:
        
          kOff : Off.
        
          kOn : On.
        
          kForward : Forward.
        
          kReverse : Reverse.
        """
        __members__: typing.ClassVar[dict[str, Relay.Value]]  # value = {'kOff': <Value.kOff: 0>, 'kOn': <Value.kOn: 1>, 'kForward': <Value.kForward: 2>, 'kReverse': <Value.kReverse: 3>}
        kForward: typing.ClassVar[Relay.Value]  # value = <Value.kForward: 2>
        kOff: typing.ClassVar[Relay.Value]  # value = <Value.kOff: 0>
        kOn: typing.ClassVar[Relay.Value]  # value = <Value.kOn: 1>
        kReverse: typing.ClassVar[Relay.Value]  # value = <Value.kReverse: 3>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self, channel: typing.SupportsInt, direction: Relay.Direction = ...) -> None:
        """
        Relay constructor given a channel.
        
        This code initializes the relay and reserves all resources that need to be
        locked. Initially the relay is set to both lines at 0v.
        
        :param channel:   The channel number (0-3).
        :param direction: The direction that the Relay object will control.
        """
    def __repr__(self) -> str:
        ...
    def get(self) -> Relay.Value:
        """
        Get the Relay State
        
        Gets the current state of the relay.
        
        When set to kForwardOnly or kReverseOnly, value is returned as kOn/kOff not
        kForward/kReverse (per the recommendation in Set).
        
        :returns: The current state of the relay as a Relay::Value
        """
    def getChannel(self) -> int:
        ...
    def getDescription(self) -> str:
        ...
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def set(self, value: Relay.Value) -> None:
        """
        Set the relay state.
        
        Valid values depend on which directions of the relay are controlled by the
        object.
        
        When set to kBothDirections, the relay can be any of the four states:
        0v-0v, 0v-12v, 12v-0v, 12v-12v
        
        When set to kForwardOnly or kReverseOnly, you can specify the constant for
        the direction or you can simply specify kOff and kOn.  Using only kOff and
        kOn is recommended.
        
        :param value: The state to set the relay.
        """
    def stopMotor(self) -> None:
        ...
class RobotBase:
    """
    Implement a Robot Program framework. The RobotBase class is intended to be
    subclassed to create a robot program. The user must implement
    StartCompetition() which will be called once and is not expected to exit. The
    user must also implement EndCompetition(), which signals to the code in
    StartCompetition() that it should exit.
    
    It is not recommended to subclass this class directly - instead subclass
    IterativeRobotBase or TimedRobot.
    """
    logger: typing.ClassVar[logging.Logger]  # value = <Logger robot (INFO)>
    _m_dashboardDetected: bool
    @staticmethod
    def getRuntimeType() -> RuntimeType:
        """
        Get the current runtime type.
        
        :returns: Current runtime type.
        """
    @staticmethod
    def isReal() -> bool:
        """
        Get if the robot is real.
        
        :returns: If the robot is running in the real world.
        """
    @staticmethod
    def isSimulation() -> bool:
        """
        Get if the robot is a simulation.
        
        :returns: If the robot is running in simulation.
        """
    @staticmethod
    def main(robot_cls: typing.Any) -> typing.Any:
        """
        Starting point for the application
        """
    def __init__(self) -> None:
        """
        Constructor for a generic robot program.
        
        User code can be placed in the constructor that runs before the
        Autonomous or Operator Control period starts. The constructor will run to
        completion before Autonomous is entered.
        
        This must be used to ensure that the communications code starts. In the
        future it would be nice to put this code into it's own task that loads on
        boot so ensure that it runs.
        """
    def endCompetition(self) -> None:
        """
        Ends the main loop in StartCompetition().
        """
    def getControlState(self) -> tuple[bool, bool, bool]:
        """
        More efficient way to determine what state the robot is in.
        
        :returns: booleans representing enabled, isautonomous, istest
        
        .. versionadded:: 2019.2.1
        
        .. note:: This function only exists in RobotPy
        """
    def isAutonomous(self) -> bool:
        """
        Determine if the robot is currently in Autonomous mode.
        
        :returns: True if the robot is currently operating Autonomously as determined
                  by the Driver Station.
        """
    def isAutonomousEnabled(self) -> bool:
        """
        Determine if the robot is currently in Autonomous mode and enabled.
        
        :returns: True if the robot us currently operating Autonomously while enabled
                  as determined by the Driver Station.
        """
    def isDisabled(self) -> bool:
        """
        Determine if the Robot is currently disabled.
        
        :returns: True if the Robot is currently disabled by the Driver Station.
        """
    def isEnabled(self) -> bool:
        """
        Determine if the Robot is currently enabled.
        
        :returns: True if the Robot is currently enabled by the Driver Station.
        """
    def isTeleop(self) -> bool:
        """
        Determine if the robot is currently in Operator Control mode.
        
        :returns: True if the robot is currently operating in Tele-Op mode as
                  determined by the Driver Station.
        """
    def isTeleopEnabled(self) -> bool:
        """
        Determine if the robot is current in Operator Control mode and enabled.
        
        :returns: True if the robot is currently operating in Tele-Op mode while
                  enabled as determined by the Driver Station.
        """
    def isTest(self) -> bool:
        """
        Determine if the robot is currently in Test mode.
        
        :returns: True if the robot is currently running in Test mode as determined
                  by the Driver Station.
        """
    def isTestEnabled(self) -> bool:
        """
        Determine if the robot is current in Test mode and enabled.
        
        :returns: True if the robot is currently operating in Test mode while
                  enabled as determined by the Driver Station.
        """
    def startCompetition(self) -> None:
        """
        Start the main robot code. This function will be called once and should not
        exit until signalled by EndCompetition()
        """
class RobotController:
    @staticmethod
    def getBatteryVoltage() -> wpimath.units.volts:
        """
        Read the battery voltage.
        
        :returns: The battery voltage in Volts.
        """
    @staticmethod
    def getBrownoutVoltage() -> wpimath.units.volts:
        """
        Get the current brownout voltage setting.
        
        :returns: The brownout voltage
        """
    @staticmethod
    def getCANStatus() -> CANStatus:
        """
        Get the current status of the CAN bus.
        
        :returns: The status of the CAN bus
        """
    @staticmethod
    def getCPUTemp() -> wpimath.units.celsius:
        """
        Get the current CPU temperature.
        
        :returns: current CPU temperature
        """
    @staticmethod
    def getComments() -> str:
        """
        Return the comments from the roboRIO web interface.
        
        The comments string is cached after the first call to this function on the
        RoboRIO - restart the robot code to reload the comments string after
        changing it in the web interface.
        
        :returns: The comments from the roboRIO web interface.
        """
    @staticmethod
    def getCommsDisableCount() -> int:
        """
        Gets the number of times the system has been disabled due to communication
        errors with the Driver Station.
        
        :returns: number of disables due to communication errors.
        """
    @staticmethod
    def getCurrent3V3() -> float:
        """
        Get the current output of the 3.3V rail.
        
        :returns: The controller 3.3V rail output current value in Amps
        """
    @staticmethod
    def getCurrent5V() -> float:
        """
        Get the current output of the 5V rail.
        
        :returns: The controller 5V rail output current value in Amps
        """
    @staticmethod
    def getCurrent6V() -> float:
        """
        Get the current output of the 6V rail.
        
        :returns: The controller 6V rail output current value in Amps
        """
    @staticmethod
    def getEnabled3V3() -> bool:
        """
        Get the enabled state of the 3.3V rail. The rail may be disabled due to
        calling SetEnabled3V3(), a controller brownout, a short circuit on the
        rail, or controller over-voltage.
        
        :returns: The controller 3.3V rail enabled value. True for enabled.
        """
    @staticmethod
    def getEnabled5V() -> bool:
        """
        Get the enabled state of the 5V rail. The rail may be disabled due to
        calling SetEnabled5V(), a controller brownout, a short circuit on the rail,
        or controller over-voltage.
        
        :returns: The controller 5V rail enabled value. True for enabled.
        """
    @staticmethod
    def getEnabled6V() -> bool:
        """
        Get the enabled state of the 6V rail. The rail may be disabled due to
        calling SetEnabled6V(), a controller brownout, a short circuit on the rail,
        or controller over-voltage.
        
        :returns: The controller 6V rail enabled value. True for enabled.
        """
    @staticmethod
    def getFPGARevision() -> int:
        """
        Return the FPGA Revision number.
        
        The format of the revision is 3 numbers. The 12 most significant bits are
        the Major Revision. The next 8 bits are the Minor Revision. The 12 least
        significant bits are the Build Number.
        
        :returns: FPGA Revision number.
        """
    @staticmethod
    def getFPGATime() -> int:
        """
        Read the microsecond-resolution timer on the FPGA.
        
        :returns: The current time in microseconds according to the FPGA (since FPGA
                  reset).
        """
    @staticmethod
    def getFPGAVersion() -> int:
        """
        Return the FPGA Version number.
        
        For now, expect this to be competition year.
        
        :returns: FPGA Version number.
        """
    @staticmethod
    def getFaultCount3V3() -> int:
        """
        Get the count of the total current faults on the 3.3V rail since the
        code started.
        
        :returns: The number of faults
        """
    @staticmethod
    def getFaultCount5V() -> int:
        """
        Get the count of the total current faults on the 5V rail since the
        code started.
        
        :returns: The number of faults
        """
    @staticmethod
    def getFaultCount6V() -> int:
        """
        Get the count of the total current faults on the 6V rail since the
        code started.
        
        :returns: The number of faults.
        """
    @staticmethod
    def getInputCurrent() -> float:
        """
        Get the input current to the robot controller.
        
        :returns: The controller input current value in Amps
        """
    @staticmethod
    def getInputVoltage() -> float:
        """
        Get the input voltage to the robot controller.
        
        :returns: The controller input voltage value in Volts
        """
    @staticmethod
    def getRSLState() -> bool:
        """
        Gets the current state of the Robot Signal Light (RSL)
        
        :returns: The current state of the RSL- true if on, false if off
        """
    @staticmethod
    def getRadioLEDState() -> RadioLEDState:
        """
        Get the state of the "Radio" LED. On the RoboRIO, this reads from sysfs, so
        this function should not be called multiple times per loop cycle to avoid
        overruns.
        
        :returns: The state of the LED.
        """
    @staticmethod
    def getSerialNumber() -> str:
        """
        Return the serial number of the roboRIO.
        
        :returns: The serial number of the roboRIO.
        """
    @staticmethod
    def getTeamNumber() -> int:
        """
        Returns the team number configured for the robot controller.
        
        :returns: team number, or 0 if not found.
        """
    @staticmethod
    def getTime() -> int:
        """
        Read the microsecond timestamp. By default, the time is based on the FPGA
        hardware clock in microseconds since the FPGA started. However, the return
        value of this method may be modified to use any time base, including
        non-monotonic and non-continuous time bases.
        
        :returns: The current time in microseconds.
        """
    @staticmethod
    def getUserButton() -> bool:
        """
        Get the state of the "USER" button on the roboRIO.
        
        @warning the User Button is used to stop user programs from automatically
        loading if it is held for more then 5 seconds. Because of this, it's not
        recommended to be used by teams for any other purpose.
        
        :returns: True if the button is currently pressed down
        """
    @staticmethod
    def getVoltage3V3() -> float:
        """
        Get the voltage of the 3.3V rail.
        
        :returns: The controller 3.3V rail voltage value in Volts
        """
    @staticmethod
    def getVoltage5V() -> float:
        """
        Get the voltage of the 5V rail.
        
        :returns: The controller 5V rail voltage value in Volts
        """
    @staticmethod
    def getVoltage6V() -> float:
        """
        Get the voltage of the 6V rail.
        
        :returns: The controller 6V rail voltage value in Volts
        """
    @staticmethod
    def isBrownedOut() -> bool:
        """
        Check if the system is browned out.
        
        :returns: True if the system is browned out
        """
    @staticmethod
    def isSysActive() -> bool:
        """
        Check if the FPGA outputs are enabled.
        
        The outputs may be disabled if the robot is disabled or e-stopped, the
        watchdog has expired, or if the roboRIO browns out.
        
        :returns: True if the FPGA outputs are enabled.
        """
    @staticmethod
    def isSystemTimeValid() -> bool:
        """
        Gets if the system time is valid.
        
        :returns: True if the system time is valid, false otherwise
        """
    @staticmethod
    def resetRailFaultCounts() -> None:
        """
        Reset the overcurrent fault counters for all user rails to 0.
        """
    @staticmethod
    def setBrownoutVoltage(brownoutVoltage: wpimath.units.volts) -> None:
        """
        Set the voltage the roboRIO will brownout and disable all outputs.
        
        Note that this only does anything on the roboRIO 2.
        On the roboRIO it is a no-op.
        
        :param brownoutVoltage: The brownout voltage
        """
    @staticmethod
    def setEnabled3V3(enabled: bool) -> None:
        """
        Enables or disables the 3.3V rail.
        
        :param enabled: whether to enable the 3.3V rail.
        """
    @staticmethod
    def setEnabled5V(enabled: bool) -> None:
        """
        Enables or disables the 5V rail.
        
        :param enabled: whether to enable the 5V rail.
        """
    @staticmethod
    def setEnabled6V(enabled: bool) -> None:
        """
        Enables or disables the 6V rail.
        
        :param enabled: whether to enable the 6V rail.
        """
    @staticmethod
    def setRadioLEDState(state: RadioLEDState) -> None:
        """
        Set the state of the "Radio" LED. On the RoboRIO, this writes to sysfs, so
        this function should not be called multiple times per loop cycle to avoid
        overruns.
        
        :param state: The state to set the LED to.
        """
    @staticmethod
    def setTimeSource(supplier: collections.abc.Callable[[], int]) -> None:
        """
        Sets a new source to provide the clock time in microseconds. Changing this
        affects the return value of ``GetTime``.
        
        :param supplier: Function to return the time in microseconds.
        """
class RobotState:
    """
    Robot state utility functions.
    """
    @staticmethod
    def isAutonomous() -> bool:
        """
        Returns true if the robot is in autonomous mode.
        
        :returns: True if the robot is in autonomous mode.
        """
    @staticmethod
    def isDisabled() -> bool:
        """
        Returns true if the robot is disabled.
        
        :returns: True if the robot is disabled.
        """
    @staticmethod
    def isEStopped() -> bool:
        """
        Returns true if the robot is E-stopped.
        
        :returns: True if the robot is E-stopped.
        """
    @staticmethod
    def isEnabled() -> bool:
        """
        Returns true if the robot is enabled.
        
        :returns: True if the robot is enabled.
        """
    @staticmethod
    def isTeleop() -> bool:
        """
        Returns true if the robot is in teleop mode.
        
        :returns: True if the robot is in teleop mode.
        """
    @staticmethod
    def isTest() -> bool:
        """
        Returns true if the robot is in test mode.
        
        :returns: True if the robot is in test mode.
        """
class RuntimeType:
    """
    Runtime type.
    
    Members:
    
      kRoboRIO : roboRIO 1.0.
    
      kRoboRIO2 : roboRIO 2.0.
    
      kSimulation : Simulation runtime.
    """
    __members__: typing.ClassVar[dict[str, RuntimeType]]  # value = {'kRoboRIO': <RuntimeType.kRoboRIO: 0>, 'kRoboRIO2': <RuntimeType.kRoboRIO2: 1>, 'kSimulation': <RuntimeType.kSimulation: 2>}
    kRoboRIO: typing.ClassVar[RuntimeType]  # value = <RuntimeType.kRoboRIO: 0>
    kRoboRIO2: typing.ClassVar[RuntimeType]  # value = <RuntimeType.kRoboRIO2: 1>
    kSimulation: typing.ClassVar[RuntimeType]  # value = <RuntimeType.kSimulation: 2>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SPI:
    """
    SPI bus interface class.
    
    This class is intended to be used by sensor (and other SPI device) drivers.
    It probably should not be used directly.
    """
    class Mode:
        """
        SPI mode.
        
        Members:
        
          kMode0 : Clock idle low, data sampled on rising edge.
        
          kMode1 : Clock idle low, data sampled on falling edge.
        
          kMode2 : Clock idle high, data sampled on falling edge.
        
          kMode3 : Clock idle high, data sampled on rising edge.
        """
        __members__: typing.ClassVar[dict[str, SPI.Mode]]  # value = {'kMode0': <Mode.kMode0: 0>, 'kMode1': <Mode.kMode1: 1>, 'kMode2': <Mode.kMode2: 2>, 'kMode3': <Mode.kMode3: 3>}
        kMode0: typing.ClassVar[SPI.Mode]  # value = <Mode.kMode0: 0>
        kMode1: typing.ClassVar[SPI.Mode]  # value = <Mode.kMode1: 1>
        kMode2: typing.ClassVar[SPI.Mode]  # value = <Mode.kMode2: 2>
        kMode3: typing.ClassVar[SPI.Mode]  # value = <Mode.kMode3: 3>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Port:
        """
        SPI port.
        
        Members:
        
          kOnboardCS0 : Onboard SPI bus port CS0.
        
          kOnboardCS1 : Onboard SPI bus port CS1.
        
          kOnboardCS2 : Onboard SPI bus port CS2.
        
          kOnboardCS3 : Onboard SPI bus port CS3.
        
          kMXP : MXP (roboRIO MXP) SPI bus port.
        """
        __members__: typing.ClassVar[dict[str, SPI.Port]]  # value = {'kOnboardCS0': <Port.kOnboardCS0: 0>, 'kOnboardCS1': <Port.kOnboardCS1: 1>, 'kOnboardCS2': <Port.kOnboardCS2: 2>, 'kOnboardCS3': <Port.kOnboardCS3: 3>, 'kMXP': <Port.kMXP: 4>}
        kMXP: typing.ClassVar[SPI.Port]  # value = <Port.kMXP: 4>
        kOnboardCS0: typing.ClassVar[SPI.Port]  # value = <Port.kOnboardCS0: 0>
        kOnboardCS1: typing.ClassVar[SPI.Port]  # value = <Port.kOnboardCS1: 1>
        kOnboardCS2: typing.ClassVar[SPI.Port]  # value = <Port.kOnboardCS2: 2>
        kOnboardCS3: typing.ClassVar[SPI.Port]  # value = <Port.kOnboardCS3: 3>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self, port: SPI.Port) -> None:
        """
        Constructor
        
        :param port: the physical SPI port
        """
    def configureAutoStall(self, port: hal._wpiHal.SPIPort, csToSclkTicks: typing.SupportsInt, stallTicks: typing.SupportsInt, pow2BytesPerRead: typing.SupportsInt) -> None:
        """
        Configure the Auto SPI Stall time between reads.
        
        :param port:             The number of the port to use. 0-3 for Onboard CS0-CS2, 4 for
                                 MXP.
        :param csToSclkTicks:    the number of ticks to wait before asserting the cs
                                 pin
        :param stallTicks:       the number of ticks to stall for
        :param pow2BytesPerRead: the number of bytes to read before stalling
        """
    def forceAutoRead(self) -> None:
        """
        Force the engine to make a single transfer.
        """
    def freeAccumulator(self) -> None:
        """
        Frees the accumulator.
        """
    def freeAuto(self) -> None:
        """
        Frees the automatic SPI transfer engine.
        """
    def getAccumulatorAverage(self) -> float:
        """
        Read the average of the accumulated value.
        
        :returns: The accumulated average value (value / count).
        """
    def getAccumulatorCount(self) -> int:
        """
        Read the number of accumulated values.
        
        Read the count of the accumulated values since the accumulator was last
        Reset().
        
        :returns: The number of times samples from the channel were accumulated.
        """
    def getAccumulatorIntegratedAverage(self) -> float:
        """
        Read the average of the integrated value.  This is the sum of (each value
        times the time between values), divided by the count.
        
        :returns: The average of the integrated value accumulated since the last
                  Reset().
        """
    def getAccumulatorIntegratedValue(self) -> float:
        """
        Read the integrated value.  This is the sum of (each value * time between
        values).
        
        :returns: The integrated value accumulated since the last Reset().
        """
    def getAccumulatorLastValue(self) -> int:
        """
        Read the last value read by the accumulator engine.
        """
    def getAccumulatorOutput(self) -> tuple[int, int]:
        """
        Read the accumulated value and the number of accumulated values atomically.
        
        This function reads the value and count atomically.
        This can be used for averaging.
        
        :param value: Pointer to the 64-bit accumulated output.
        :param count: Pointer to the number of accumulation cycles.
        """
    def getAccumulatorValue(self) -> int:
        """
        Read the accumulated value.
        
        :returns: The 64-bit value accumulated since the last Reset().
        """
    def getAutoDroppedCount(self) -> int:
        """
        Get the number of bytes dropped by the automatic SPI transfer engine due
        to the receive buffer being full.
        
        :returns: Number of bytes dropped
        """
    def getPort(self) -> SPI.Port:
        """
        Returns the SPI port.
        
        :returns: The SPI port.
        """
    def initAccumulator(self, period: wpimath.units.seconds, cmd: typing.SupportsInt, xferSize: typing.SupportsInt, validMask: typing.SupportsInt, validValue: typing.SupportsInt, dataShift: typing.SupportsInt, dataSize: typing.SupportsInt, isSigned: bool, bigEndian: bool) -> None:
        """
        Initialize the accumulator.
        
        :param period:     Time between reads
        :param cmd:        SPI command to send to request data
        :param xferSize:   SPI transfer size, in bytes
        :param validMask:  Mask to apply to received data for validity checking
        :param validValue: After valid_mask is applied, required matching value for
                           validity checking
        :param dataShift:  Bit shift to apply to received data to get actual data
                           value
        :param dataSize:   Size (in bits) of data field
        :param isSigned:   Is data field signed?
        :param bigEndian:  Is device big endian?
        """
    def initAuto(self, bufferSize: typing.SupportsInt) -> None:
        """
        Initialize automatic SPI transfer engine.
        
        Only a single engine is available, and use of it blocks use of all other
        chip select usage on the same physical SPI port while it is running.
        
        :param bufferSize: buffer size in bytes
        """
    def read(self, initiate: bool, dataReceived: typing_extensions.Buffer) -> int:
        """
        Read a word from the receive FIFO.
        
        Waits for the current transfer to complete if the receive FIFO is empty.
        
        If the receive FIFO is empty, there is no active transfer, and initiate
        is false, errors.
        
        :param initiate:     If true, this function pushes "0" into the transmit
                             buffer and initiates a transfer. If false, this
                             function assumes that data is already in the receive
                             FIFO from a previous write.
        :param dataReceived: Buffer to receive data from the device
        :param size:         The length of the transaction, in bytes
        """
    def readAutoReceivedData(self, buffer: typing_extensions.Buffer, timeout: wpimath.units.seconds) -> int:
        """
        Read data that has been transferred by the automatic SPI transfer engine.
        
        Transfers may be made a byte at a time, so it's necessary for the caller
        to handle cases where an entire transfer has not been completed.
        
        Each received data sequence consists of a timestamp followed by the
        received data bytes, one byte per word (in the least significant byte).
        The length of each received data sequence is the same as the combined
        size of the data and zeroSize set in SetAutoTransmitData().
        
        Blocks until numToRead words have been read or timeout expires.
        May be called with numToRead=0 to retrieve how many words are available.
        
        :param buffer:    buffer where read words are stored
        :param numToRead: number of words to read
        :param timeout:   timeout (ms resolution)
        
        :returns: Number of words remaining to be read
        """
    def resetAccumulator(self) -> None:
        """
        Resets the accumulator to zero.
        """
    def setAccumulatorCenter(self, center: typing.SupportsInt) -> None:
        """
        Set the center value of the accumulator.
        
        The center value is subtracted from each value before it is added to the
        accumulator. This is used for the center value of devices like gyros and
        accelerometers to make integration work and to take the device offset into
        account when integrating.
        """
    def setAccumulatorDeadband(self, deadband: typing.SupportsInt) -> None:
        """
        Set the accumulator's deadband.
        """
    def setAccumulatorIntegratedCenter(self, center: typing.SupportsFloat) -> None:
        """
        Set the center value of the accumulator integrator.
        
        The center value is subtracted from each value*dt before it is added to the
        integrated value. This is used for the center value of devices like gyros
        and accelerometers to take the device offset into account when integrating.
        """
    def setAutoTransmitData(self, dataToSend: typing_extensions.Buffer, zeroSize: typing.SupportsInt) -> None:
        """
        Set the data to be transmitted by the engine.
        
        Up to 16 bytes are configurable, and may be followed by up to 127 zero
        bytes.
        
        :param dataToSend: data to send (maximum 16 bytes)
        :param zeroSize:   number of zeros to send after the data
        """
    def setChipSelectActiveHigh(self) -> None:
        """
        Configure the chip select line to be active high.
        """
    def setChipSelectActiveLow(self) -> None:
        """
        Configure the chip select line to be active low.
        """
    def setClockRate(self, hz: typing.SupportsInt) -> None:
        """
        Configure the rate of the generated clock signal.
        
        The default value is 500,000Hz.
        The maximum value is 4,000,000Hz.
        
        :param hz: The clock rate in Hertz.
        """
    def setMode(self, mode: SPI.Mode) -> None:
        """
        Sets the mode for the SPI device.
        
        Mode 0 is Clock idle low, data sampled on rising edge
        
        Mode 1 is Clock idle low, data sampled on falling edge
        
        Mode 2 is Clock idle high, data sampled on falling edge
        
        Mode 3 is Clock idle high, data sampled on rising edge
        
        :param mode: The mode to set.
        """
    def startAutoRate(self, period: wpimath.units.seconds) -> None:
        """
        Start running the automatic SPI transfer engine at a periodic rate.
        
        InitAuto() and SetAutoTransmitData() must be called before calling this
        function.
        
        :param period: period between transfers (us resolution)
        """
    def startAutoTrigger(self, source: DigitalSource, rising: bool, falling: bool) -> None:
        """
        Start running the automatic SPI transfer engine when a trigger occurs.
        
        InitAuto() and SetAutoTransmitData() must be called before calling this
        function.
        
        :param source:  digital source for the trigger (may be an analog trigger)
        :param rising:  trigger on the rising edge
        :param falling: trigger on the falling edge
        """
    def stopAuto(self) -> None:
        """
        Stop running the automatic SPI transfer engine.
        """
    def transaction(self, dataToSend: typing_extensions.Buffer, dataReceived: typing_extensions.Buffer) -> int:
        """
        Perform a simultaneous read/write transaction with the device
        
        :param dataToSend:   The data to be written out to the device
        :param dataReceived: Buffer to receive data from the device
        :param size:         The length of the transaction, in bytes
        """
    def write(self, data: typing_extensions.Buffer) -> int:
        """
        Write data to the peripheral device.  Blocks until there is space in the
        output FIFO.
        
        If not running in output only mode, also saves the data received
        on the CIPO input during the transfer into the receive FIFO.
        """
class SendableBuilderImpl(ntcore._ntcore.NTSendableBuilder):
    """
    Implementation detail for SendableBuilder.
    """
    def __init__(self) -> None:
        ...
    def addBooleanArrayProperty(self, key: str, getter: collections.abc.Callable[[], list[int]], setter: collections.abc.Callable[[list[typing.SupportsInt]], None]) -> None:
        ...
    def addBooleanProperty(self, key: str, getter: collections.abc.Callable[[], bool], setter: collections.abc.Callable[[bool], None]) -> None:
        ...
    def addDoubleArrayProperty(self, key: str, getter: collections.abc.Callable[[], list[float]], setter: collections.abc.Callable[[list[typing.SupportsFloat]], None]) -> None:
        ...
    def addDoubleProperty(self, key: str, getter: collections.abc.Callable[[], float], setter: collections.abc.Callable[[typing.SupportsFloat], None]) -> None:
        ...
    def addFloatArrayProperty(self, key: str, getter: collections.abc.Callable[[], list[float]], setter: collections.abc.Callable[[list[typing.SupportsFloat]], None]) -> None:
        ...
    def addFloatProperty(self, key: str, getter: collections.abc.Callable[[], float], setter: collections.abc.Callable[[typing.SupportsFloat], None]) -> None:
        ...
    def addIntegerArrayProperty(self, key: str, getter: collections.abc.Callable[[], list[int]], setter: collections.abc.Callable[[list[typing.SupportsInt]], None]) -> None:
        ...
    def addIntegerProperty(self, key: str, getter: collections.abc.Callable[[], int], setter: collections.abc.Callable[[typing.SupportsInt], None]) -> None:
        ...
    def addRawProperty(self, key: str, typeString: str, getter: collections.abc.Callable[[], list[int]], setter: collections.abc.Callable[[typing_extensions.Buffer], None]) -> None:
        ...
    def addSmallBooleanArrayProperty(self, key: str, getter: collections.abc.Callable[[list[typing.SupportsInt]], list[int]], setter: collections.abc.Callable[[list[typing.SupportsInt]], None]) -> None:
        ...
    def addSmallDoubleArrayProperty(self, key: str, getter: collections.abc.Callable[[list[typing.SupportsFloat]], list[float]], setter: collections.abc.Callable[[list[typing.SupportsFloat]], None]) -> None:
        ...
    def addSmallFloatArrayProperty(self, key: str, getter: collections.abc.Callable[[list[typing.SupportsFloat]], list[float]], setter: collections.abc.Callable[[list[typing.SupportsFloat]], None]) -> None:
        ...
    def addSmallIntegerArrayProperty(self, key: str, getter: collections.abc.Callable[[list[typing.SupportsInt]], list[int]], setter: collections.abc.Callable[[list[typing.SupportsInt]], None]) -> None:
        ...
    def addSmallRawProperty(self, key: str, typeString: str, getter: collections.abc.Callable[[list[typing.SupportsInt]], typing_extensions.Buffer], setter: collections.abc.Callable[[typing_extensions.Buffer], None]) -> None:
        ...
    def addSmallStringArrayProperty(self, key: str, getter: collections.abc.Callable[[list[str]], list[str]], setter: collections.abc.Callable[[list[str]], None]) -> None:
        ...
    def addSmallStringProperty(self, key: str, getter: collections.abc.Callable[[list[str]], str], setter: collections.abc.Callable[[str], None]) -> None:
        ...
    def addStringArrayProperty(self, key: str, getter: collections.abc.Callable[[], list[str]], setter: collections.abc.Callable[[list[str]], None]) -> None:
        ...
    def addStringProperty(self, key: str, getter: collections.abc.Callable[[], str], setter: collections.abc.Callable[[str], None]) -> None:
        ...
    def clearProperties(self) -> None:
        """
        Clear properties.
        """
    def getTable(self) -> ntcore._ntcore.NetworkTable:
        """
        Get the network table.
        
        :returns: The network table
        """
    def getTopic(self, key: str) -> ntcore._ntcore.Topic:
        ...
    def isActuator(self) -> bool:
        """
        Return whether this sendable should be treated as an actuator.
        
        :returns: True if actuator, false if not.
        """
    def isPublished(self) -> bool:
        """
        Return whether this sendable has an associated table.
        
        :returns: True if it has a table, false if not.
        """
    def publishConstBoolean(self, key: str, value: bool) -> None:
        ...
    def publishConstBooleanArray(self, key: str, value: list[typing.SupportsInt]) -> None:
        ...
    def publishConstDouble(self, key: str, value: typing.SupportsFloat) -> None:
        ...
    def publishConstDoubleArray(self, key: str, value: list[typing.SupportsFloat]) -> None:
        ...
    def publishConstFloat(self, key: str, value: typing.SupportsFloat) -> None:
        ...
    def publishConstFloatArray(self, key: str, value: list[typing.SupportsFloat]) -> None:
        ...
    def publishConstInteger(self, key: str, value: typing.SupportsInt) -> None:
        ...
    def publishConstIntegerArray(self, key: str, value: list[typing.SupportsInt]) -> None:
        ...
    def publishConstRaw(self, key: str, typeString: str, value: typing_extensions.Buffer) -> None:
        ...
    def publishConstString(self, key: str, value: str) -> None:
        ...
    def publishConstStringArray(self, key: str, value: list[str]) -> None:
        ...
    def setActuator(self, value: bool) -> None:
        ...
    def setSafeState(self, func: collections.abc.Callable[[], None]) -> None:
        ...
    def setSmartDashboardType(self, type: str) -> None:
        ...
    def setTable(self, table: ntcore._ntcore.NetworkTable) -> None:
        """
        Set the network table.  Must be called prior to any Add* functions being
        called.
        
        :param table: Network table
        """
    def setUpdateTable(self, func: collections.abc.Callable[[], None]) -> None:
        ...
    def startListeners(self) -> None:
        """
        Hook setters for all properties.
        """
    def startLiveWindowMode(self) -> None:
        """
        Start LiveWindow mode by hooking the setters for all properties.  Also
        calls the SafeState function if one was provided.
        """
    def stopListeners(self) -> None:
        """
        Unhook setters for all properties.
        """
    def stopLiveWindowMode(self) -> None:
        """
        Stop LiveWindow mode by unhooking the setters for all properties.  Also
        calls the SafeState function if one was provided.
        """
    def update(self) -> None:
        """
        Synchronize with network table values by calling the getters for all
        properties and setters when the network table value has changed.
        """
class SendableChooser(SendableChooserBase):
    """
    The SendableChooser class is a useful tool for presenting a selection of
    options to the SmartDashboard.
    
    For instance, you may wish to be able to select between multiple autonomous
    modes. You can do this by putting every possible Command you want to run as
    an autonomous into a SendableChooser and then put it into the SmartDashboard
    to have a list of options appear on the laptop. Once autonomous starts,
    simply ask the SendableChooser what the selected value is.
    
    @tparam T The type of values to be stored
    @see SmartDashboard
    """
    def __init__(self) -> None:
        ...
    def addOption(self, name: str, object: typing.Any) -> None:
        """
        Adds the given object to the list of options.
        
        On the SmartDashboard on the desktop, the object will appear as the given
        name.
        
        :param name:   the name of the option
        :param object: the option
        """
    def getSelected(self) -> typing.Any:
        """
        Returns a copy of the selected option (a std::weak_ptr<U> if T =
        std::shared_ptr<U>).
        
        If there is none selected, it will return the default. If there is none
        selected and no default, then it will return a value-initialized instance.
        For integer types, this is 0. For container types like std::string, this is
        an empty string.
        
        :returns: The option selected
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def onChange(self, listener: collections.abc.Callable[[typing.Any], None]) -> None:
        """
        Bind a listener that's called when the selected value changes.
        Only one listener can be bound. Calling this function will replace the
        previous listener.
        
        :param listener: The function to call that accepts the new value
        """
    def setDefaultOption(self, name: str, object: typing.Any) -> None:
        """
        Add the given object to the list of options and marks it as the default.
        
        Functionally, this is very close to AddOption() except that it will use
        this as the default option if none other is explicitly selected.
        
        :param name:   the name of the option
        :param object: the option
        """
class SendableChooserBase(wpiutil._wpiutil.Sendable):
    """
    This class is a non-template base class for SendableChooser.
    
    It contains static, non-templated variables to avoid their duplication in the
    template class.
    """
    _kActive: typing.ClassVar[str] = 'active'
    _kDefault: typing.ClassVar[str] = 'default'
    _kInstance: typing.ClassVar[str] = '.instance'
    _kOptions: typing.ClassVar[str] = 'options'
    _kSelected: typing.ClassVar[str] = 'selected'
    _m_haveSelected: bool
    @property
    def _m_defaultChoice(self) -> str:
        ...
    @property
    def _m_instance(self) -> int:
        ...
    @_m_instance.setter
    def _m_instance(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def _m_previousVal(self) -> str:
        ...
    @property
    def _m_selected(self) -> str:
        ...
class SensorUtil:
    """
    Stores most recent status information as well as containing utility functions
    for checking channels and error processing.
    """
    @staticmethod
    def checkAnalogInputChannel(channel: typing.SupportsInt) -> bool:
        """
        Check that the analog input number is value.
        
        Verify that the analog input number is one of the legal channel numbers.
        Channel numbers are 0-based.
        
        :returns: Analog channel is valid
        """
    @staticmethod
    def checkAnalogOutputChannel(channel: typing.SupportsInt) -> bool:
        """
        Check that the analog output number is valid.
        
        Verify that the analog output number is one of the legal channel numbers.
        Channel numbers are 0-based.
        
        :returns: Analog channel is valid
        """
    @staticmethod
    def checkDigitalChannel(channel: typing.SupportsInt) -> bool:
        """
        Check that the digital channel number is valid.
        
        Verify that the channel number is one of the legal channel numbers. Channel
        numbers are 0-based.
        
        :returns: Digital channel is valid
        """
    @staticmethod
    def checkPWMChannel(channel: typing.SupportsInt) -> bool:
        """
        Check that the digital channel number is valid.
        
        Verify that the channel number is one of the legal channel numbers. Channel
        numbers are 0-based.
        
        :returns: PWM channel is valid
        """
    @staticmethod
    def checkRelayChannel(channel: typing.SupportsInt) -> bool:
        """
        Check that the relay channel number is valid.
        
        Verify that the channel number is one of the legal channel numbers. Channel
        numbers are 0-based.
        
        :returns: Relay channel is valid
        """
    @staticmethod
    def getDefaultCTREPCMModule() -> int:
        """
        Get the number of the default solenoid module.
        
        :returns: The number of the default solenoid module.
        """
    @staticmethod
    def getDefaultREVPHModule() -> int:
        """
        Get the number of the default solenoid module.
        
        :returns: The number of the default solenoid module.
        """
    @staticmethod
    def getNumAnalogInputs() -> int:
        ...
    @staticmethod
    def getNumAnalogOuputs() -> int:
        ...
    @staticmethod
    def getNumDigitalChannels() -> int:
        ...
    @staticmethod
    def getNumPwmChannels() -> int:
        ...
    @staticmethod
    def getNumRelayChannels() -> int:
        ...
class SerialPort:
    """
    Driver for the RS-232 serial port on the roboRIO.
    
    The current implementation uses the VISA formatted I/O mode.  This means that
    all traffic goes through the formatted buffers.  This allows the intermingled
    use of Printf(), Scanf(), and the raw buffer accessors Read() and Write().
    
    More information can be found in the NI-VISA User Manual here:
    http://www.ni.com/pdf/manuals/370423a.pdf
    and the NI-VISA Programmer's Reference Manual here:
    http://www.ni.com/pdf/manuals/370132c.pdf
    """
    class FlowControl:
        """
        Represents what type of flow control to use for serial communication.
        
        Members:
        
          kFlowControl_None : No flow control.
        
          kFlowControl_XonXoff : XON/XOFF flow control.
        
          kFlowControl_RtsCts : RTS/CTS flow control.
        
          kFlowControl_DtrDsr : DTS/DSR flow control.
        """
        __members__: typing.ClassVar[dict[str, SerialPort.FlowControl]]  # value = {'kFlowControl_None': <FlowControl.kFlowControl_None: 0>, 'kFlowControl_XonXoff': <FlowControl.kFlowControl_XonXoff: 1>, 'kFlowControl_RtsCts': <FlowControl.kFlowControl_RtsCts: 2>, 'kFlowControl_DtrDsr': <FlowControl.kFlowControl_DtrDsr: 4>}
        kFlowControl_DtrDsr: typing.ClassVar[SerialPort.FlowControl]  # value = <FlowControl.kFlowControl_DtrDsr: 4>
        kFlowControl_None: typing.ClassVar[SerialPort.FlowControl]  # value = <FlowControl.kFlowControl_None: 0>
        kFlowControl_RtsCts: typing.ClassVar[SerialPort.FlowControl]  # value = <FlowControl.kFlowControl_RtsCts: 2>
        kFlowControl_XonXoff: typing.ClassVar[SerialPort.FlowControl]  # value = <FlowControl.kFlowControl_XonXoff: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Parity:
        """
        Represents the parity to use for serial communications.
        
        Members:
        
          kParity_None : No parity.
        
          kParity_Odd : Odd parity.
        
          kParity_Even : Even parity.
        
          kParity_Mark : Parity bit always on.
        
          kParity_Space : Parity bit always off.
        """
        __members__: typing.ClassVar[dict[str, SerialPort.Parity]]  # value = {'kParity_None': <Parity.kParity_None: 0>, 'kParity_Odd': <Parity.kParity_Odd: 1>, 'kParity_Even': <Parity.kParity_Even: 2>, 'kParity_Mark': <Parity.kParity_Mark: 3>, 'kParity_Space': <Parity.kParity_Space: 4>}
        kParity_Even: typing.ClassVar[SerialPort.Parity]  # value = <Parity.kParity_Even: 2>
        kParity_Mark: typing.ClassVar[SerialPort.Parity]  # value = <Parity.kParity_Mark: 3>
        kParity_None: typing.ClassVar[SerialPort.Parity]  # value = <Parity.kParity_None: 0>
        kParity_Odd: typing.ClassVar[SerialPort.Parity]  # value = <Parity.kParity_Odd: 1>
        kParity_Space: typing.ClassVar[SerialPort.Parity]  # value = <Parity.kParity_Space: 4>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Port:
        """
        Serial port.
        
        Members:
        
          kOnboard : Onboard serial port on the roboRIO.
        
          kMXP : MXP (roboRIO MXP) serial port.
        
          kUSB : USB serial port (same as kUSB1).
        
          kUSB1 : USB serial port 1.
        
          kUSB2 : USB serial port 2.
        """
        __members__: typing.ClassVar[dict[str, SerialPort.Port]]  # value = {'kOnboard': <Port.kOnboard: 0>, 'kMXP': <Port.kMXP: 1>, 'kUSB': <Port.kUSB: 2>, 'kUSB1': <Port.kUSB: 2>, 'kUSB2': <Port.kUSB2: 3>}
        kMXP: typing.ClassVar[SerialPort.Port]  # value = <Port.kMXP: 1>
        kOnboard: typing.ClassVar[SerialPort.Port]  # value = <Port.kOnboard: 0>
        kUSB: typing.ClassVar[SerialPort.Port]  # value = <Port.kUSB: 2>
        kUSB1: typing.ClassVar[SerialPort.Port]  # value = <Port.kUSB: 2>
        kUSB2: typing.ClassVar[SerialPort.Port]  # value = <Port.kUSB2: 3>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class StopBits:
        """
        Represents the number of stop bits to use for Serial Communication.
        
        Members:
        
          kStopBits_One : One stop bit.
        
          kStopBits_OnePointFive : One and a half stop bits.
        
          kStopBits_Two : Two stop bits.
        """
        __members__: typing.ClassVar[dict[str, SerialPort.StopBits]]  # value = {'kStopBits_One': <StopBits.kStopBits_One: 10>, 'kStopBits_OnePointFive': <StopBits.kStopBits_OnePointFive: 15>, 'kStopBits_Two': <StopBits.kStopBits_Two: 20>}
        kStopBits_One: typing.ClassVar[SerialPort.StopBits]  # value = <StopBits.kStopBits_One: 10>
        kStopBits_OnePointFive: typing.ClassVar[SerialPort.StopBits]  # value = <StopBits.kStopBits_OnePointFive: 15>
        kStopBits_Two: typing.ClassVar[SerialPort.StopBits]  # value = <StopBits.kStopBits_Two: 20>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class WriteBufferMode:
        """
        Represents which type of buffer mode to use when writing to a serial port.
        
        Members:
        
          kFlushOnAccess : Flush the buffer on each access.
        
          kFlushWhenFull : Flush the buffer when it is full.
        """
        __members__: typing.ClassVar[dict[str, SerialPort.WriteBufferMode]]  # value = {'kFlushOnAccess': <WriteBufferMode.kFlushOnAccess: 1>, 'kFlushWhenFull': <WriteBufferMode.kFlushWhenFull: 2>}
        kFlushOnAccess: typing.ClassVar[SerialPort.WriteBufferMode]  # value = <WriteBufferMode.kFlushOnAccess: 1>
        kFlushWhenFull: typing.ClassVar[SerialPort.WriteBufferMode]  # value = <WriteBufferMode.kFlushWhenFull: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    @typing.overload
    def __init__(self, baudRate: typing.SupportsInt, port: SerialPort.Port = ..., dataBits: typing.SupportsInt = 8, parity: SerialPort.Parity = ..., stopBits: SerialPort.StopBits = ...) -> None:
        """
        Create an instance of a Serial Port class.
        
        :param baudRate: The baud rate to configure the serial port.
        :param port:     The physical port to use
        :param dataBits: The number of data bits per transfer.  Valid values are
                         between 5 and 8 bits.
        :param parity:   Select the type of parity checking to use.
        :param stopBits: The number of stop bits to use as defined by the enum
                         StopBits.
        """
    @typing.overload
    def __init__(self, baudRate: typing.SupportsInt, portName: str, port: SerialPort.Port = ..., dataBits: typing.SupportsInt = 8, parity: SerialPort.Parity = ..., stopBits: SerialPort.StopBits = ...) -> None:
        """
        Create an instance of a Serial Port class.
        
        Prefer to use the constructor that doesn't take a port name, but in some
        cases the automatic detection might not work correctly.
        
        :param baudRate: The baud rate to configure the serial port.
        :param port:     The physical port to use
        :param portName: The direct port name to use
        :param dataBits: The number of data bits per transfer.  Valid values are
                         between 5 and 8 bits.
        :param parity:   Select the type of parity checking to use.
        :param stopBits: The number of stop bits to use as defined by the enum
                         StopBits.
        """
    def disableTermination(self) -> None:
        """
        Disable termination behavior.
        """
    def enableTermination(self, terminator: str = '\n') -> None:
        """
        Enable termination and specify the termination character.
        
        Termination is currently only implemented for receive.
        When the the terminator is received, the Read() or Scanf() will return
        fewer bytes than requested, stopping after the terminator.
        
        :param terminator: The character to use for termination.
        """
    def flush(self) -> None:
        """
        Force the output buffer to be written to the port.
        
        This is used when SetWriteBufferMode() is set to kFlushWhenFull to force a
        flush before the buffer is full.
        """
    def getBytesReceived(self) -> int:
        """
        Get the number of bytes currently available to read from the serial port.
        
        :returns: The number of bytes available to read
        """
    def read(self, buffer: typing_extensions.Buffer) -> int:
        """
        Read raw bytes out of the buffer.
        
        :param buffer: Pointer to the buffer to store the bytes in.
        :param count:  The maximum number of bytes to read.
        
        :returns: The number of bytes actually read into the buffer.
        """
    def reset(self) -> None:
        """
        Reset the serial port driver to a known state.
        
        Empty the transmit and receive buffers in the device and formatted I/O.
        """
    def setFlowControl(self, flowControl: SerialPort.FlowControl) -> None:
        """
        Set the type of flow control to enable on this port.
        
        By default, flow control is disabled.
        """
    def setReadBufferSize(self, size: typing.SupportsInt) -> None:
        """
        Specify the size of the input buffer.
        
        Specify the amount of data that can be stored before data
        from the device is returned to Read or Scanf.  If you want
        data that is received to be returned immediately, set this to 1.
        
        It the buffer is not filled before the read timeout expires, all
        data that has been received so far will be returned.
        
        :param size: The read buffer size.
        """
    def setTimeout(self, timeout: wpimath.units.seconds) -> None:
        """
        Configure the timeout of the serial port.
        
        This defines the timeout for transactions with the hardware.
        It will affect reads and very large writes.
        
        :param timeout: The time to wait for I/O.
        """
    def setWriteBufferMode(self, mode: SerialPort.WriteBufferMode) -> None:
        """
        Specify the flushing behavior of the output buffer.
        
        When set to kFlushOnAccess, data is synchronously written to the serial
        port after each call to either Printf() or Write().
        
        When set to kFlushWhenFull, data will only be written to the serial port
        when the buffer is full or when Flush() is called.
        
        :param mode: The write buffer mode.
        """
    def setWriteBufferSize(self, size: typing.SupportsInt) -> None:
        """
        Specify the size of the output buffer.
        
        Specify the amount of data that can be stored before being
        transmitted to the device.
        
        :param size: The write buffer size.
        """
    def write(self, buffer: typing_extensions.Buffer) -> int:
        """
        Write raw bytes to the buffer.
        
        :param buffer: Pointer to the buffer to read the bytes from.
        :param count:  The maximum number of bytes to write.
        
        :returns: The number of bytes actually written into the port.
        """
class Servo(PWM):
    """
    Standard hobby style servo.
    
    The range parameters default to the appropriate values for the Hitec HS-322HD
    servo provided in the FIRST Kit of Parts in 2008.
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor.
        
        By default, 2.4 ms is used as the max PWM value and 0.6 ms is used as the
        min PWM value.
        
        :param channel: The PWM channel to which the servo is attached. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
    def get(self) -> float:
        """
        Get the servo position.
        
        Servo values range from 0.0 to 1.0 corresponding to the range of full left
        to full right. This returns the commanded position, not the position that
        the servo is actually at, as the servo does not report its own position.
        
        :returns: Position from 0.0 to 1.0.
        """
    def getAngle(self) -> float:
        """
        Get the servo angle.
        
        This returns the commanded angle, not the angle that the servo is actually
        at, as the servo does not report its own angle.
        
        :returns: The angle in degrees to which the servo is set.
        """
    def getMaxAngle(self) -> float:
        """
        Get the maximum angle of the servo.
        
        :returns: The maximum angle of the servo in degrees.
        """
    def getMinAngle(self) -> float:
        """
        Get the minimum angle of the servo.
        
        :returns: The minimum angle of the servo in degrees.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def set(self, value: typing.SupportsFloat) -> None:
        """
        Set the servo position.
        
        Servo values range from 0.0 to 1.0 corresponding to the range of full left
        to full right.
        
        :param value: Position from 0.0 to 1.0.
        """
    def setAngle(self, angle: typing.SupportsFloat) -> None:
        """
        Set the servo angle.
        
        The angles are based on the HS-322HD Servo, and have a range of 0 to 180
        degrees.
        
        Servo angles that are out of the supported range of the servo simply
        "saturate" in that direction. In other words, if the servo has a range of
        (X degrees to Y degrees) than angles of less than X result in an angle of
        X being set and angles of more than Y degrees result in an angle of Y being
        set.
        
        :param angle: The angle in degrees to set the servo.
        """
    def setOffline(self) -> None:
        """
        Set the servo to offline.
        
        Set the servo raw value to 0 (undriven)
        """
class SharpIR(wpiutil._wpiutil.Sendable):
    @staticmethod
    def GP2Y0A02YK0F(channel: typing.SupportsInt) -> SharpIR:
        """
        Sharp GP2Y0A02YK0F is an analog IR sensor capable of measuring
        distances from 20cm to 150cm.
        
        :param channel: Analog input channel the sensor is connected to
        
        :returns: sensor object
        """
    @staticmethod
    def GP2Y0A21YK0F(channel: typing.SupportsInt) -> SharpIR:
        """
        Sharp GP2Y0A21YK0F is an analog IR sensor capable of measuring
        distances from 10cm to 80cm.
        
        :param channel: Analog input channel the sensor is connected to
        
        :returns: sensor object
        """
    @staticmethod
    def GP2Y0A41SK0F(channel: typing.SupportsInt) -> SharpIR:
        """
        Sharp GP2Y0A41SK0F is an analog IR sensor capable of measuring
        distances from 4cm to 30cm.
        
        :param channel: Analog input channel the sensor is connected to
        
        :returns: sensor object
        """
    @staticmethod
    def GP2Y0A51SK0F(channel: typing.SupportsInt) -> SharpIR:
        """
        Sharp GP2Y0A51SK0F is an analog IR sensor capable of measuring
        distances from 2cm to 15cm.
        
        :param channel: Analog input channel the sensor is connected to
        
        :returns: sensor object
        """
    def __init__(self, channel: typing.SupportsInt, a: typing.SupportsFloat, b: typing.SupportsFloat, minCM: typing.SupportsFloat, maxCM: typing.SupportsFloat) -> None:
        """
        Manually construct a SharpIR object. The distance is computed using this
        formula: A*v ^ B. Prefer to use one of the static factories to create this
        device instead.
        
        :param channel: Analog input channel the sensor is connected to
        :param a:       Constant A
        :param b:       Constant B
        :param minCM:   Minimum distance to report in centimeters
        :param maxCM:   Maximum distance to report in centimeters
        """
    def getChannel(self) -> int:
        """
        Get the analog input channel number.
        
        :returns: analog input channel
        """
    def getRange(self) -> wpimath.units.centimeters:
        """
        Get the range from the distance sensor.
        
        :returns: range of the target returned by the sensor
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
class SmartDashboard:
    @staticmethod
    def clearPersistent(key: str) -> None:
        """
        Stop making a key's value persistent through program restarts.
        The key cannot be null.
        
        :param key: the key name
        """
    @staticmethod
    def containsKey(key: str) -> bool:
        """
        Determines whether the given key is in this table.
        
        :param key: the key to search for
        
        :returns: true if the table as a value assigned to the given key
        """
    @staticmethod
    def getBoolean(keyName: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the value at the specified key.
        
        If the key is not found, returns the default value.
        
        :param keyName:      the key
        :param defaultValue: the default value to return if key doesn't exist
        
        :returns: the value
        """
    @staticmethod
    def getBooleanArray(key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the boolean array the key maps to.
        
        If the key does not exist or is of different type, it will return the
        default value.
        
        :param key:          The key to look up.
        :param defaultValue: The value to be returned if no value is found.
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
                  
                  .. note:: This makes a copy of the array. If the overhead of this is a concern,
                     use GetValue() instead.
                  
                  .. note:: The returned array is std::vector<int> instead of std::vector<bool>
                     because std::vector<bool> is special-cased in C++. 0 is false, any
                     non-zero value is true.
        """
    @staticmethod
    def getData(keyName: str) -> wpiutil._wpiutil.Sendable:
        """
        Returns the value at the specified key.
        
        :param keyName: the key
        
        :returns: the value
        """
    @staticmethod
    def getEntry(key: str) -> ntcore._ntcore.NetworkTableEntry:
        """
        Returns an NT Entry mapping to the specified key
        
        This is useful if an entry is used often, or is read and then modified.
        
        :param key: the key
        
        :returns: the entry for the key
        """
    @staticmethod
    def getKeys(types: typing.SupportsInt = 0) -> list[str]:
        """
        :param types: bitmask of types; 0 is treated as a "don't care".
        
        :returns: keys currently in the table
        """
    @staticmethod
    def getNumber(keyName: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the value at the specified key.
        
        If the key is not found, returns the default value.
        
        :param keyName:      the key
        :param defaultValue: the default value to return if the key doesn't exist
        
        :returns: the value
        """
    @staticmethod
    def getNumberArray(key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the number array the key maps to.
        
        If the key does not exist or is of different type, it will return the
        default value.
        
        :param key:          The key to look up.
        :param defaultValue: The value to be returned if no value is found.
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
                  
                  .. note:: This makes a copy of the array. If the overhead of this is a concern,
                     use GetValue() instead.
        """
    @staticmethod
    def getRaw(key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the raw value (byte array) the key maps to.
        
        If the key does not exist or is of different type, it will return the
        default value.
        
        :param key:          The key to look up.
        :param defaultValue: The value to be returned if no value is found.
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
                  
                  .. note:: This makes a copy of the raw contents. If the overhead of this is a
                     concern, use GetValue() instead.
        """
    @staticmethod
    def getString(keyName: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the value at the specified key.
        
        If the key is not found, returns the default value.
        
        :param keyName:      the key
        :param defaultValue: the default value to return if the key doesn't exist
        
        :returns: the value
        """
    @staticmethod
    def getStringArray(key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the string array the key maps to.
        
        If the key does not exist or is of different type, it will return the
        default value.
        
        :param key:          The key to look up.
        :param defaultValue: The value to be returned if no value is found.
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
                  
                  .. note:: This makes a copy of the array. If the overhead of this is a concern,
                     use GetValue() instead.
        """
    @staticmethod
    def getValue(keyName: str) -> ntcore._ntcore.Value:
        """
        Retrieves the complex value (such as an array) in this table into the
        complex data object.
        
        :param keyName: the key
        """
    @staticmethod
    def init() -> None:
        ...
    @staticmethod
    def isPersistent(key: str) -> bool:
        """
        Returns whether the value is persistent through program restarts.
        The key cannot be null.
        
        :param key: the key name
        """
    @staticmethod
    def postListenerTask(task: collections.abc.Callable[[], None]) -> None:
        """
        Posts a task from a listener to the ListenerExecutor, so that it can be run
        synchronously from the main loop on the next call to updateValues().
        
        :param task: The task to run synchronously from the main thread.
        """
    @staticmethod
    def putBoolean(keyName: str, value: bool) -> bool:
        """
        Maps the specified key to the specified value in this table.
        
        The value can be retrieved by calling the get method with a key that is
        equal to the original key.
        
        :param keyName: the key
        :param value:   the value
        
        :returns: False if the table key already exists with a different type
        """
    @staticmethod
    def putBooleanArray(key: str, value: list[typing.SupportsInt]) -> bool:
        """
        Put a boolean array in the table.
        
        :param key:   the key to be assigned to
        :param value: the value that will be assigned
        
        :returns: False if the table key already exists with a different type
                  
                  .. note:: The array must be of int's rather than of bool's because
                     std::vector<bool> is special-cased in C++. 0 is false, any
                     non-zero value is true.
        """
    @staticmethod
    @typing.overload
    def putData(key: str, data: wpiutil._wpiutil.Sendable) -> None:
        """
        Maps the specified key to the specified value in this table.
        
        The value can be retrieved by calling the get method with a key that is
        equal to the original key.
        
        In order for the value to appear in the dashboard, it must be registered
        with SendableRegistry.  WPILib components do this automatically.
        
        :param key:  the key
        :param data: the value
        """
    @staticmethod
    @typing.overload
    def putData(value: wpiutil._wpiutil.Sendable) -> None:
        """
        Maps the specified key (where the key is the name of the Sendable)
        to the specified value in this table.
        
        The value can be retrieved by calling the get method with a key that is
        equal to the original key.
        
        In order for the value to appear in the dashboard, it must be registered
        with SendableRegistry.  WPILib components do this automatically.
        
        :param value: the value
        """
    @staticmethod
    def putNumber(keyName: str, value: typing.SupportsFloat) -> bool:
        """
        Maps the specified key to the specified value in this table.
        
        The value can be retrieved by calling the get method with a key that is
        equal to the original key.
        
        :param keyName: the key
        :param value:   the value
        
        :returns: False if the table key already exists with a different type
        """
    @staticmethod
    def putNumberArray(key: str, value: list[typing.SupportsFloat]) -> bool:
        """
        Put a number array in the table.
        
        :param key:   The key to be assigned to.
        :param value: The value that will be assigned.
        
        :returns: False if the table key already exists with a different type
        """
    @staticmethod
    def putRaw(key: str, value: typing_extensions.Buffer) -> bool:
        """
        Put a raw value (byte array) in the table.
        
        :param key:   The key to be assigned to.
        :param value: The value that will be assigned.
        
        :returns: False if the table key already exists with a different type
        """
    @staticmethod
    def putString(keyName: str, value: str) -> bool:
        """
        Maps the specified key to the specified value in this table.
        
        The value can be retrieved by calling the get method with a key that is
        equal to the original key.
        
        :param keyName: the key
        :param value:   the value
        
        :returns: False if the table key already exists with a different type
        """
    @staticmethod
    def putStringArray(key: str, value: list[str]) -> bool:
        """
        Put a string array in the table.
        
        :param key:   The key to be assigned to.
        :param value: The value that will be assigned.
        
        :returns: False if the table key already exists with a different type
        """
    @staticmethod
    def putValue(keyName: str, value: ntcore._ntcore.Value) -> bool:
        """
        Maps the specified key to the specified complex value (such as an array) in
        this table.
        
        The value can be retrieved by calling the RetrieveValue method with a key
        that is equal to the original key.
        
        :param keyName: the key
        :param value:   the value
        
        :returns: False if the table key already exists with a different type
        """
    @staticmethod
    def setDefaultBoolean(key: str, defaultValue: bool) -> bool:
        """
        Set the value in the table if key does not exist
        
        :param key:          the key
        :param defaultValue: the value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    @staticmethod
    def setDefaultBooleanArray(key: str, defaultValue: list[typing.SupportsInt]) -> bool:
        """
        Set the value in the table if key does not exist.
        
        :param key:          the key
        :param defaultValue: the value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    @staticmethod
    def setDefaultNumber(key: str, defaultValue: typing.SupportsFloat) -> bool:
        """
        Set the value in the table if key does not exist.
        
        :param key:          The key.
        :param defaultValue: The value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    @staticmethod
    def setDefaultNumberArray(key: str, defaultValue: list[typing.SupportsFloat]) -> bool:
        """
        Set the value in the table if key does not exist.
        
        :param key:          The key.
        :param defaultValue: The value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    @staticmethod
    def setDefaultRaw(key: str, defaultValue: typing_extensions.Buffer) -> bool:
        """
        Set the value in the table if key does not exist.
        
        :param key:          The key.
        :param defaultValue: The value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    @staticmethod
    def setDefaultString(key: str, defaultValue: str) -> bool:
        """
        Set the value in the table if key does not exist.
        
        :param key:          the key
        :param defaultValue: the value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    @staticmethod
    def setDefaultStringArray(key: str, defaultValue: list[str]) -> bool:
        """
        Set the value in the table if key does not exist.
        
        :param key:          The key.
        :param defaultValue: The value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    @staticmethod
    def setDefaultValue(key: str, defaultValue: ntcore._ntcore.Value) -> bool:
        """
        Set the value in the table if key does not exist.
        
        :param key:          the key
        :param defaultValue: The value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    @staticmethod
    def setPersistent(key: str) -> None:
        """
        Makes a key's value persistent through program restarts.
        
        :param key: the key to make persistent
        """
    @staticmethod
    def updateValues() -> None:
        """
        Puts all sendable data to the dashboard.
        """
class Solenoid(wpiutil._wpiutil.Sendable):
    """
    Solenoid class for running high voltage Digital Output on a pneumatics
    module.
    
    The Solenoid class is typically used for pneumatics solenoids, but could be
    used for any device within the current spec of the module.
    """
    @typing.overload
    def __init__(self, module: typing.SupportsInt, moduleType: PneumaticsModuleType, channel: typing.SupportsInt) -> None:
        """
        Constructs a solenoid for a specified module and type.
        
        :param module:     The module ID to use.
        :param moduleType: The module type to use.
        :param channel:    The channel the solenoid is on.
        """
    @typing.overload
    def __init__(self, moduleType: PneumaticsModuleType, channel: typing.SupportsInt) -> None:
        """
        Constructs a solenoid for a default module and specified type.
        
        :param moduleType: The module type to use.
        :param channel:    The channel the solenoid is on.
        """
    def get(self) -> bool:
        """
        Read the current value of the solenoid.
        
        :returns: The current value of the solenoid.
        """
    def getChannel(self) -> int:
        """
        Get the channel this solenoid is connected to.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isDisabled(self) -> bool:
        """
        Check if solenoid is Disabled.
        
        If a solenoid is shorted, it is added to the DisabledList and
        disabled until power cycle, or until faults are cleared.
        
        @see ClearAllPCMStickyFaults()
        
        :returns: If solenoid is disabled due to short.
        """
    def set(self, on: bool) -> None:
        """
        Set the value of a solenoid.
        
        :param on: Turn the solenoid output off or on.
        """
    def setPulseDuration(self, duration: wpimath.units.seconds) -> None:
        """
        Set the pulse duration in the pneumatics module. This is used in
        conjunction with the startPulse method to allow the pneumatics module to
        control the timing of a pulse.
        
        On the PCM, the timing can be controlled in 0.01 second increments, with a
        maximum of 2.55 seconds. On the PH, the timing can be controlled in 0.001
        second increments, with a maximum of 65.534 seconds.
        
        @see startPulse()
        
        :param duration: The duration of the pulse.
        """
    def startPulse(self) -> None:
        """
        %Trigger the pneumatics module to generate a pulse of the duration set in
        setPulseDuration.
        
        @see setPulseDuration()
        """
    def toggle(self) -> None:
        """
        Toggle the value of the solenoid.
        
        If the solenoid is set to on, it'll be turned off. If the solenoid is set
        to off, it'll be turned on.
        """
class Spark(PWMMotorController):
    """
    REV Robotics SPARK Motor Controller with PWM control.
    
    Note that the SPARK uses the following bounds for PWM values. These
    values should work reasonably well for most controllers, but if users
    experience issues such as asymmetric behavior around the deadband or
    inability to saturate the controller in either direction, calibration is
    recommended. The calibration procedure can be found in the SPARK User
    Manual available from REV Robotics.
    
    - 2.003ms = full "forward"
    - 1.550ms = the "high end" of the deadband range
    - 1.500ms = center of the deadband range (off)
    - 1.460ms = the "low end" of the deadband range
    - 0.999ms = full "reverse"
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for a SPARK connected via PWM.
        
        :param channel: The PWM channel that the SPARK is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
class StadiaController(wpilib.interfaces._interfaces.GenericHID, wpiutil._wpiutil.Sendable):
    """
    Handle input from Stadia controllers connected to the Driver Station.
    
    This class handles Stadia input that comes from the Driver Station. Each
    time a value is requested the most recent value is returned. There is a
    single class instance for each controller and the mapping of ports to
    hardware buttons depends on the code in the Driver Station.
    
    Only first party controllers from Google are guaranteed to have the
    correct mapping, and only through the official NI DS. Sim is not guaranteed
    to have the same mapping, as well as any 3rd party controllers.
    """
    class Axis:
        """
        Represents an axis on an StadiaController.
        """
        kLeftX: typing.ClassVar[int] = 0
        kLeftY: typing.ClassVar[int] = 1
        kRightX: typing.ClassVar[int] = 3
        kRightY: typing.ClassVar[int] = 4
        def __init__(self) -> None:
            ...
    class Button:
        """
        Represents a digital button on an StadiaController.
        """
        kA: typing.ClassVar[int] = 1
        kB: typing.ClassVar[int] = 2
        kEllipses: typing.ClassVar[int] = 9
        kFrame: typing.ClassVar[int] = 15
        kGoogle: typing.ClassVar[int] = 14
        kHamburger: typing.ClassVar[int] = 10
        kLeftBumper: typing.ClassVar[int] = 5
        kLeftStick: typing.ClassVar[int] = 7
        kLeftTrigger: typing.ClassVar[int] = 13
        kRightBumper: typing.ClassVar[int] = 6
        kRightStick: typing.ClassVar[int] = 8
        kRightTrigger: typing.ClassVar[int] = 12
        kStadia: typing.ClassVar[int] = 11
        kX: typing.ClassVar[int] = 3
        kY: typing.ClassVar[int] = 4
        def __init__(self) -> None:
            ...
    def A(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the A button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the A button's
                  digital signal attached to the given loop.
        """
    def B(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the B button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the B button's
                  digital signal attached to the given loop.
        """
    def X(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the X button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the X button's
                  digital signal attached to the given loop.
        """
    def Y(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the Y button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the Y button's
                  digital signal attached to the given loop.
        """
    def __init__(self, port: typing.SupportsInt) -> None:
        """
        Construct an instance of a controller.
        
        The controller index is the USB port on the Driver Station.
        
        :param port: The port on the Driver Station that the controller is plugged
                     into (0-5).
        """
    def ellipses(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the ellipses button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the ellipses button's
                  digital signal attached to the given loop.
        """
    def frame(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the frame button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the frame button's
                  digital signal attached to the given loop.
        """
    def getAButton(self) -> bool:
        """
        Read the value of the A button on the controller.
        
        :returns: The state of the button.
        """
    def getAButtonPressed(self) -> bool:
        """
        Whether the A button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getAButtonReleased(self) -> bool:
        """
        Whether the A button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getBButton(self) -> bool:
        """
        Read the value of the B button on the controller.
        
        :returns: The state of the button.
        """
    def getBButtonPressed(self) -> bool:
        """
        Whether the B button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getBButtonReleased(self) -> bool:
        """
        Whether the B button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getEllipsesButton(self) -> bool:
        """
        Read the value of the ellipses button on the controller.
        
        :returns: The state of the button.
        """
    def getEllipsesButtonPressed(self) -> bool:
        """
        Whether the ellipses button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getEllipsesButtonReleased(self) -> bool:
        """
        Whether the ellipses button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getFrameButton(self) -> bool:
        """
        Read the value of the frame button on the controller.
        
        :returns: The state of the button.
        """
    def getFrameButtonPressed(self) -> bool:
        """
        Whether the frame button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getFrameButtonReleased(self) -> bool:
        """
        Whether the frame button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getGoogleButton(self) -> bool:
        """
        Read the value of the google button on the controller.
        
        :returns: The state of the button.
        """
    def getGoogleButtonPressed(self) -> bool:
        """
        Whether the google button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getGoogleButtonReleased(self) -> bool:
        """
        Whether the google button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getHamburgerButton(self) -> bool:
        """
        Read the value of the hamburger button on the controller.
        
        :returns: The state of the button.
        """
    def getHamburgerButtonPressed(self) -> bool:
        """
        Whether the hamburger button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getHamburgerButtonReleased(self) -> bool:
        """
        Whether the hamburger button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftBumper(self) -> bool:
        """
        Read the value of the left bumper (LB) button on the controller.
        
        :deprecated: Use GetLeftBumperButton instead. This function is deprecated
                     for removal to make function names consistent to allow the HID classes to
                     be automatically generated.
        
        :returns: the state of the button
        """
    def getLeftBumperButton(self) -> bool:
        """
        Read the value of the left bumper button on the controller.
        
        :returns: The state of the button.
        """
    def getLeftBumperButtonPressed(self) -> bool:
        """
        Whether the left bumper button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getLeftBumperButtonReleased(self) -> bool:
        """
        Whether the left bumper button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftBumperPressed(self) -> bool:
        """
        Whether the left bumper (LB) was pressed since the last check.
        
        :deprecated: Use GetLeftBumperButtonPressed instead. This function is
                     deprecated for removal to make function names consistent to allow the HID
                     classes to be automatically generated.
        
        :returns: Whether the button was pressed since the last check
        """
    def getLeftBumperReleased(self) -> bool:
        """
        Whether the left bumper (LB) was released since the last check.
        
        :deprecated: Use GetLeftBumperButtonReleased instead. This function is
                     deprecated for removal to make function names consistent to allow the HID
                     classes to be automatically generated.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftStickButton(self) -> bool:
        """
        Read the value of the left stick button on the controller.
        
        :returns: The state of the button.
        """
    def getLeftStickButtonPressed(self) -> bool:
        """
        Whether the left stick button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getLeftStickButtonReleased(self) -> bool:
        """
        Whether the left stick button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftTriggerButton(self) -> bool:
        """
        Read the value of the left trigger button on the controller.
        
        :returns: The state of the button.
        """
    def getLeftTriggerButtonPressed(self) -> bool:
        """
        Whether the left trigger button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getLeftTriggerButtonReleased(self) -> bool:
        """
        Whether the left trigger button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftX(self) -> float:
        """
        Get the X axis value of left side of the controller. Right is positive.
        
        :returns: the axis value.
        """
    def getLeftY(self) -> float:
        """
        Get the Y axis value of left side of the controller. Back is positive.
        
        :returns: the axis value.
        """
    def getRightBumper(self) -> bool:
        """
        Read the value of the right bumper (RB) button on the controller.
        
        :deprecated: Use GetRightBumperButton instead. This function is deprecated
                     for removal to make function names consistent to allow the HID classes to
                     be automatically generated.
        
        :returns: the state of the button
        """
    def getRightBumperButton(self) -> bool:
        """
        Read the value of the right bumper button on the controller.
        
        :returns: The state of the button.
        """
    def getRightBumperButtonPressed(self) -> bool:
        """
        Whether the right bumper button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getRightBumperButtonReleased(self) -> bool:
        """
        Whether the right bumper button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getRightBumperPressed(self) -> bool:
        """
        Whether the right bumper (RB) was pressed since the last check.
        
        :deprecated: Use GetRightBumperButtonPressed instead. This function is
                     deprecated for removal to make function names consistent to allow the HID
                     classes to be automatically generated.
        
        :returns: Whether the button was pressed since the last check
        """
    def getRightBumperReleased(self) -> bool:
        """
        Whether the right bumper (RB) was released since the last check.
        
        :deprecated: Use GetRightBumperButtonReleased instead. This function is
                     deprecated for removal to make function names consistent to allow the HID
                     classes to be automatically generated.
        
        :returns: Whether the button was released since the last check.
        """
    def getRightStickButton(self) -> bool:
        """
        Read the value of the right stick button on the controller.
        
        :returns: The state of the button.
        """
    def getRightStickButtonPressed(self) -> bool:
        """
        Whether the right stick button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getRightStickButtonReleased(self) -> bool:
        """
        Whether the right stick button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getRightTriggerButton(self) -> bool:
        """
        Read the value of the right trigger button on the controller.
        
        :returns: The state of the button.
        """
    def getRightTriggerButtonPressed(self) -> bool:
        """
        Whether the right trigger button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getRightTriggerButtonReleased(self) -> bool:
        """
        Whether the right trigger button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getRightX(self) -> float:
        """
        Get the X axis value of right side of the controller. Right is positive.
        
        :returns: the axis value.
        """
    def getRightY(self) -> float:
        """
        Get the Y axis value of right side of the controller. Back is positive.
        
        :returns: the axis value.
        """
    def getStadiaButton(self) -> bool:
        """
        Read the value of the stadia button on the controller.
        
        :returns: The state of the button.
        """
    def getStadiaButtonPressed(self) -> bool:
        """
        Whether the stadia button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getStadiaButtonReleased(self) -> bool:
        """
        Whether the stadia button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getXButton(self) -> bool:
        """
        Read the value of the X button on the controller.
        
        :returns: The state of the button.
        """
    def getXButtonPressed(self) -> bool:
        """
        Whether the X button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getXButtonReleased(self) -> bool:
        """
        Whether the X button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getYButton(self) -> bool:
        """
        Read the value of the Y button on the controller.
        
        :returns: The state of the button.
        """
    def getYButtonPressed(self) -> bool:
        """
        Whether the Y button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getYButtonReleased(self) -> bool:
        """
        Whether the Y button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def google(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the google button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the google button's
                  digital signal attached to the given loop.
        """
    def hamburger(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the hamburger button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the hamburger button's
                  digital signal attached to the given loop.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def leftBumper(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the left bumper button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the left bumper button's
                  digital signal attached to the given loop.
        """
    def leftStick(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the left stick button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the left stick button's
                  digital signal attached to the given loop.
        """
    def leftTrigger(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the left trigger button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the left trigger button's
                  digital signal attached to the given loop.
        """
    def rightBumper(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the right bumper button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the right bumper button's
                  digital signal attached to the given loop.
        """
    def rightStick(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the right stick button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the right stick button's
                  digital signal attached to the given loop.
        """
    def rightTrigger(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the right trigger button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the right trigger button's
                  digital signal attached to the given loop.
        """
    def stadia(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the stadia button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the stadia button's
                  digital signal attached to the given loop.
        """
class SynchronousInterrupt:
    """
    Class for handling synchronous (blocking) interrupts.
    
    By default, interrupts will occur on rising edge.
    
    Asynchronous interrupts are handled by the AsynchronousInterrupt class.
    """
    class WaitResult:
        """
        Event trigger combinations for a synchronous interrupt.
        
        Members:
        
          kTimeout : Timeout event.
        
          kRisingEdge : Rising edge event.
        
          kFallingEdge : Falling edge event.
        
          kBoth : Both rising and falling edge events.
        """
        __members__: typing.ClassVar[dict[str, SynchronousInterrupt.WaitResult]]  # value = {'kTimeout': <WaitResult.kTimeout: 0>, 'kRisingEdge': <WaitResult.kRisingEdge: 1>, 'kFallingEdge': <WaitResult.kFallingEdge: 256>, 'kBoth': <WaitResult.kBoth: 257>}
        kBoth: typing.ClassVar[SynchronousInterrupt.WaitResult]  # value = <WaitResult.kBoth: 257>
        kFallingEdge: typing.ClassVar[SynchronousInterrupt.WaitResult]  # value = <WaitResult.kFallingEdge: 256>
        kRisingEdge: typing.ClassVar[SynchronousInterrupt.WaitResult]  # value = <WaitResult.kRisingEdge: 1>
        kTimeout: typing.ClassVar[SynchronousInterrupt.WaitResult]  # value = <WaitResult.kTimeout: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    @typing.overload
    def __init__(self, source: DigitalSource) -> None:
        """
        Construct a Synchronous Interrupt from a Digital Source.
        
        :param source: the DigitalSource the interrupts are triggered from
        """
    @typing.overload
    def __init__(self, source: DigitalSource) -> None:
        """
        Construct a Synchronous Interrupt from a Digital Source.
        
        :param source: the DigitalSource the interrupts are triggered from
        """
    @typing.overload
    def __init__(self, source: DigitalSource) -> None:
        """
        Construct a Synchronous Interrupt from a Digital Source.
        
        :param source: the DigitalSource the interrupts are triggered from
        """
    def getFallingTimestamp(self) -> wpimath.units.seconds:
        """
        Get the timestamp of the last falling edge.
        
        This function does not require the interrupt to be enabled to work.
        
        This only works if falling edge was configured using setInterruptEdges.
        
        :returns: the timestamp in seconds relative to getFPGATime
        """
    def getRisingTimestamp(self) -> wpimath.units.seconds:
        """
        Get the timestamp (relative to FPGA Time) of the last rising edge.
        
        :returns: the timestamp in seconds relative to getFPGATime
        """
    def setInterruptEdges(self, risingEdge: bool, fallingEdge: bool) -> None:
        """
        Set which edges cause an interrupt to occur.
        
        :param risingEdge:  true to trigger on rising edge, false otherwise.
        :param fallingEdge: true to trigger on falling edge, false otherwise
        """
    def waitForInterrupt(self, timeout: wpimath.units.seconds, ignorePrevious: bool = True) -> SynchronousInterrupt.WaitResult:
        """
        Wait for an interrupt to occur.
        
        Both rising and falling edge can be returned if both a rising and
        falling happened between calls, and ignorePrevious is false.
        
        :param timeout:        The timeout to wait for. 0s or less will return immediately.
        :param ignorePrevious: True to ignore any previous interrupts, false to
                               return interrupt value if an interrupt has occurred since last call.
        
        :returns: The edge(s) that were triggered, or timeout.
        """
    def wakeupWaitingInterrupt(self) -> None:
        """
        Wake up an existing wait call. Can be called from any thread.
        """
class Talon(PWMMotorController):
    """
    Cross the Road Electronics (CTRE) Talon Motor Controller with PWM control.
    
    Note that the Talon uses the following bounds for PWM values. These
    values should work reasonably well for most controllers, but if users
    experience issues such as asymmetric behavior around the deadband or
    inability to saturate the controller in either direction, calibration is
    recommended. The calibration procedure can be found in the Talon User
    Manual available from Cross the Road Electronics (CTRE).
    
    - 2.037ms = full "forward"
    - 1.539ms = the "high end" of the deadband range
    - 1.513ms = center of the deadband range (off)
    - 1.487ms = the "low end" of the deadband range
    - 0.989ms = full "reverse"
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for a Talon connected via PWM.
        
        :param channel: The PWM channel that the Talon is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
class TimedRobot(IterativeRobotBase):
    """
    TimedRobot implements the IterativeRobotBase robot program framework.
    
    The TimedRobot class is intended to be subclassed by a user creating a
    robot program.
    
    Periodic() functions from the base class are called on an interval by a
    Notifier instance.
    """
    kDefaultPeriod: typing.ClassVar[float] = 20.0
    def __init__(self, period: wpimath.units.seconds = 0.02) -> None:
        """
        Constructor for TimedRobot.
        
        :param period: The period of the robot loop function.
        """
    def addPeriodic(self, callback: collections.abc.Callable[[], None], period: wpimath.units.seconds, offset: wpimath.units.seconds = 0.0) -> None:
        """
        Add a callback to run at a specific period with a starting time offset.
        
        This is scheduled on TimedRobot's Notifier, so TimedRobot and the callback
        run synchronously. Interactions between them are thread-safe.
        
        :param callback: The callback to run.
        :param period:   The period at which to run the callback.
        :param offset:   The offset from the common starting time. This is useful
                         for scheduling a callback in a different timeslot relative
                         to TimedRobot.
        """
    def endCompetition(self) -> None:
        """
        Ends the main loop in StartCompetition().
        """
    def getLoopStartTime(self) -> int:
        """
        Return the system clock time in micrseconds for the start of the current
        periodic loop. This is in the same time base as Timer.GetFPGATimestamp(),
        but is stable through a loop. It is updated at the beginning of every
        periodic callback (including the normal periodic loop).
        
        :returns: Robot running time in microseconds, as of the start of the current
                  periodic function.
        """
    def startCompetition(self) -> None:
        """
        Provide an alternate "main loop" via StartCompetition().
        """
class Timer:
    """
    A timer class.
    
    Note that if the user calls frc::sim::RestartTiming(), they should also reset
    the timer so Get() won't return a negative duration.
    """
    @staticmethod
    def getFPGATimestamp() -> wpimath.units.seconds:
        """
        Return the FPGA system clock time in seconds.
        
        Return the time from the FPGA hardware clock in seconds since the FPGA
        started. Rolls over after 71 minutes.
        
        :returns: Robot running time in seconds.
        """
    @staticmethod
    def getMatchTime() -> wpimath.units.seconds:
        """
        Return the approximate match time.
        
        The FMS does not send an official match time to the robots, but does send
        an approximate match time. The value will count down the time remaining in
        the current period (auto or teleop).
        
        Warning: This is not an official time (so it cannot be used to dispute ref
        calls or guarantee that a function will trigger before the match ends).
        
        The Practice Match function of the DS approximates the behavior seen on the
        field.
        
        :returns: Time remaining in current match period (auto or teleop)
        """
    @staticmethod
    def getTimestamp() -> wpimath.units.seconds:
        """
        Return the clock time in seconds. By default, the time is based on the FPGA
        hardware clock in seconds since the FPGA started. However, the return value
        of this method may be modified to use any time base, including
        non-monotonic time bases.
        
        :returns: Robot running time in seconds.
        """
    def __init__(self) -> None:
        """
        Create a new timer object.
        
        Create a new timer object and reset the time to zero. The timer is
        initially not running and must be started.
        """
    def advanceIfElapsed(self, period: wpimath.units.seconds) -> bool:
        """
        Check if the period specified has passed and if it has, advance the start
        time by that period. This is useful to decide if it's time to do periodic
        work without drifting later by the time it took to get around to checking.
        
        :param period: The period to check for.
        
        :returns: True if the period has passed.
        """
    def get(self) -> wpimath.units.seconds:
        """
        Get the current time from the timer. If the clock is running it is derived
        from the current system clock the start time stored in the timer class. If
        the clock is not running, then return the time when it was last stopped.
        
        :returns: Current time value for this timer in seconds
        """
    def hasElapsed(self, period: wpimath.units.seconds) -> bool:
        """
        Check if the period specified has passed.
        
        :param period: The period to check.
        
        :returns: True if the period has passed.
        """
    def isRunning(self) -> bool:
        """
        Whether the timer is currently running.
        
        :returns: true if running.
        """
    def reset(self) -> None:
        """
        Reset the timer by setting the time to 0.
        
        Make the timer startTime the current time so new requests will be relative
        to now.
        """
    def restart(self) -> None:
        """
        Restart the timer by stopping the timer, if it is not already stopped,
        resetting the accumulated time, then starting the timer again. If you
        want an event to periodically reoccur at some time interval from the
        start time, consider using AdvanceIfElapsed() instead.
        """
    def start(self) -> None:
        """
        Start the timer running.
        
        Just set the running flag to true indicating that all time requests should
        be relative to the system clock. Note that this method is a no-op if the
        timer is already running.
        """
    def stop(self) -> None:
        """
        Stop the timer.
        
        This computes the time as of now and clears the running flag, causing all
        subsequent time requests to be read from the accumulated time rather than
        looking at the system clock.
        """
class TimesliceRobot(TimedRobot):
    """
    TimesliceRobot extends the TimedRobot robot program framework to provide
    timeslice scheduling of periodic functions.
    
    The TimesliceRobot class is intended to be subclassed by a user creating a
    robot program.
    
    This class schedules robot operations serially in a timeslice format.
    TimedRobot's periodic functions are the first in the timeslice table with 0
    ms offset and 20 ms period. You can schedule additional controller periodic
    functions at a shorter period (5 ms by default). You give each one a
    timeslice duration, then they're run sequentially. The main benefit of this
    approach is consistent starting times for each controller periodic, which can
    make odometry and estimators more accurate and controller outputs change more
    consistently.
    
    Here's an example of measured subsystem durations and their timeslice
    allocations:
    
    <table>
    <tr>
    <td>**Subsystem**</td>
    <td>**Duration (ms)**</td>
    <td>**Allocation (ms)**</td>
    </tr>
    <tr>
    <td>**Total**</td>
    <td>5.0</td>
    <td>5.0</td>
    </tr>
    <tr>
    <td>TimedRobot</td>
    <td>?</td>
    <td>2.0</td>
    </tr>
    <tr>
    <td>Drivetrain</td>
    <td>1.32</td>
    <td>1.5</td>
    </tr>
    <tr>
    <td>Flywheel</td>
    <td>0.6</td>
    <td>0.7</td>
    </tr>
    <tr>
    <td>Turret</td>
    <td>0.6</td>
    <td>0.8</td>
    </tr>
    <tr>
    <td>**Free**</td>
    <td>0.0</td>
    <td>N/A</td>
    </tr>
    </table>
    
    Since TimedRobot periodic functions only run every 20ms, that leaves a 2 ms
    empty spot in the allocation table for three of the four 5 ms cycles
    comprising 20 ms. That's OK because the OS needs time to do other things.
    
    If the robot periodic functions and the controller periodic functions have a
    lot of scheduling jitter that cause them to occasionally overlap with later
    timeslices, consider giving the main robot thread a real-time priority using
    frc::SetCurrentThreadPriority(). An RT priority of 15 is a reasonable choice.
    
    If you do enable RT though, :emphasis:`make sure your periodic functions do not
    block`. If they do, the operating system will lock up, and you'll have to
    boot the roboRIO into safe mode and delete the robot program to recover.
    """
    def __init__(self, robotPeriodicAllocation: wpimath.units.seconds, controllerPeriod: wpimath.units.seconds) -> None:
        """
        Constructor for TimesliceRobot.
        
        :param robotPeriodicAllocation: The allocation to give the TimesliceRobot
                                        periodic functions.
        :param controllerPeriod:        The controller period. The sum of all scheduler
                                        allocations should be less than or equal to this
                                        value.
        """
    def schedule(self, func: collections.abc.Callable[[], None], allocation: wpimath.units.seconds) -> None:
        """
        Schedule a periodic function with the constructor's controller period and
        the given allocation. The function's runtime allocation will be placed
        after the end of the previous one's.
        
        If a call to this function makes the allocations exceed the controller
        period, an exception will be thrown since that means the TimesliceRobot
        periodic functions and the given function will have conflicting
        timeslices.
        
        :param func:       Function to schedule.
        :param allocation: The function's runtime allocation out of the controller
                           period.
        """
class Tracer:
    """
    A class for keeping track of how much time it takes for different parts of
    code to execute. This is done with epochs, that are added to calls to
    AddEpoch() and can be printed with a call to PrintEpochs().
    
    Epochs are a way to partition the time elapsed so that when overruns occur,
    one can determine which parts of an operation consumed the most time.
    """
    def __init__(self) -> None:
        """
        Constructs a Tracer instance.
        """
    def addEpoch(self, epochName: str) -> None:
        """
        Adds time since last epoch to the list printed by PrintEpochs().
        
        Epochs are a way to partition the time elapsed so that when overruns occur,
        one can determine which parts of an operation consumed the most time.
        
        :param epochName: The name to associate with the epoch.
        """
    def clearEpochs(self) -> None:
        """
        Clears all epochs.
        """
    def getEpochs(self) -> str:
        """
        Retreives list of epochs added so far as a string
        
        .. versionadded:: 2021.1.2
        
        .. note:: This function only exists in RobotPy
        """
    def printEpochs(self) -> None:
        """
        Prints list of epochs added so far and their times to the DriverStation.
        """
    def resetTimer(self) -> None:
        """
        Restarts the epoch timer.
        """
class Ultrasonic(wpiutil._wpiutil.Sendable):
    """
    Ultrasonic rangefinder class.
    
    The Ultrasonic rangefinder measures absolute distance based on the round-trip
    time of a ping generated by the controller. These sensors use two
    transducers, a speaker and a microphone both tuned to the ultrasonic range. A
    common ultrasonic sensor, the Daventech SRF04 requires a short pulse to be
    generated on a digital channel. This causes the chirp to be emitted. A second
    line becomes high as the ping is transmitted and goes low when the echo is
    received. The time that the line is high determines the round trip distance
    (time of flight).
    """
    @staticmethod
    def setAutomaticMode(enabling: bool) -> None:
        """
        Turn Automatic mode on/off.
        
        When in Automatic mode, all sensors will fire in round robin, waiting a set
        time between each sensor.
        
        :param enabling: Set to true if round robin scheduling should start for all
                         the ultrasonic sensors. This scheduling method assures that
                         the sensors are non-interfering because no two sensors fire
                         at the same time. If another scheduling algorithm is
                         preferred, it can be implemented by pinging the sensors
                         manually and waiting for the results to come back.
        """
    @typing.overload
    def __init__(self, pingChannel: typing.SupportsInt, echoChannel: typing.SupportsInt) -> None:
        """
        Create an instance of the Ultrasonic Sensor.
        
        This is designed to support the Daventech SRF04 and Vex ultrasonic sensors.
        
        :param pingChannel: The digital output channel that sends the pulse to
                            initiate the sensor sending the ping.
        :param echoChannel: The digital input channel that receives the echo. The
                            length of time that the echo is high represents the
                            round trip time of the ping, and the distance.
        """
    @typing.overload
    def __init__(self, pingChannel: DigitalOutput, echoChannel: DigitalInput) -> None:
        """
        Create an instance of an Ultrasonic Sensor from a DigitalInput for the echo
        channel and a DigitalOutput for the ping channel.
        
        :param pingChannel: The digital output object that starts the sensor doing a
                            ping. Requires a 10uS pulse to start.
        :param echoChannel: The digital input object that times the return pulse to
                            determine the range.
        """
    def getEchoChannel(self) -> int:
        """
        Returns the echo channel.
        
        :returns: The echo channel.
        """
    def getRange(self) -> wpimath.units.meters:
        """
        Get the range from the ultrasonic sensor.
        
        :returns: Range of the target returned from the ultrasonic sensor. If there
                  is no valid value yet, i.e. at least one measurement hasn't
                  completed, then return 0.
        """
    def getRangeInches(self) -> wpimath.units.inches:
        ...
    def getRangeMM(self) -> wpimath.units.millimeters:
        ...
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def isEnabled(self) -> bool:
        ...
    def isRangeValid(self) -> bool:
        """
        Check if there is a valid range measurement.
        
        The ranges are accumulated in a counter that will increment on each edge of
        the echo (return) signal. If the count is not at least 2, then the range
        has not yet been measured, and is invalid.
        """
    def ping(self) -> None:
        """
        Single ping to ultrasonic sensor.
        
        Send out a single ping to the ultrasonic sensor. This only works if
        automatic (round robin) mode is disabled. A single ping is sent out, and
        the counter should count the semi-period when it comes in. The counter is
        reset to make the current value invalid.
        """
    def setEnabled(self, enable: bool) -> None:
        ...
class VictorSP(PWMMotorController):
    """
    Vex Robotics Victor SP Motor Controller with PWM control.
    
    Note that the Victor SP uses the following bounds for PWM values. These
    values should work reasonably well for most controllers, but if users
    experience issues such as asymmetric behavior around the deadband or
    inability to saturate the controller in either direction, calibration is
    recommended. The calibration procedure can be found in the Victor SP User
    Manual available from Vex Robotics.
    
    - 2.004ms = full "forward"
    - 1.520ms = the "high end" of the deadband range
    - 1.500ms = center of the deadband range (off)
    - 1.480ms = the "low end" of the deadband range
    - 0.997ms = full "reverse"
    """
    def __init__(self, channel: typing.SupportsInt) -> None:
        """
        Constructor for a Victor SP connected via PWM.
        
        :param channel: The PWM channel that the Victor SP is attached to. 0-9 are
                        on-board, 10-19 are on the MXP port
        """
class Watchdog:
    """
    A class that's a wrapper around a watchdog timer.
    
    When the timer expires, a message is printed to the console and an optional
    user-provided callback is invoked.
    
    The watchdog is initialized disabled, so the user needs to call Enable()
    before use.
    """
    def __init__(self, timeout: wpimath.units.seconds, callback: collections.abc.Callable[[], None]) -> None:
        """
        Watchdog constructor.
        
        :param timeout:  The watchdog's timeout in seconds with microsecond
                         resolution.
        :param callback: This function is called when the timeout expires.
        """
    def addEpoch(self, epochName: str) -> None:
        """
        Adds time since last epoch to the list printed by PrintEpochs().
        
        Epochs are a way to partition the time elapsed so that when overruns occur,
        one can determine which parts of an operation consumed the most time.
        
        :param epochName: The name to associate with the epoch.
        """
    def disable(self) -> None:
        """
        Disables the watchdog timer.
        """
    def enable(self) -> None:
        """
        Enables the watchdog timer.
        """
    def getTime(self) -> wpimath.units.seconds:
        """
        Returns the time since the watchdog was last fed.
        """
    def getTimeout(self) -> wpimath.units.seconds:
        """
        Returns the watchdog's timeout.
        """
    def isExpired(self) -> bool:
        """
        Returns true if the watchdog timer has expired.
        """
    def printEpochs(self) -> None:
        """
        Prints list of epochs added so far and their times.
        """
    def reset(self) -> None:
        """
        Resets the watchdog timer.
        
        This also enables the timer if it was previously disabled.
        """
    def setTimeout(self, timeout: wpimath.units.seconds) -> None:
        """
        Sets the watchdog's timeout.
        
        :param timeout: The watchdog's timeout in seconds with microsecond
                        resolution.
        """
    def suppressTimeoutMessage(self, suppress: bool) -> None:
        """
        Enable or disable suppression of the generic timeout message.
        
        This may be desirable if the user-provided callback already prints a more
        specific message.
        
        :param suppress: Whether to suppress generic timeout message.
        """
class XboxController(wpilib.interfaces._interfaces.GenericHID, wpiutil._wpiutil.Sendable):
    """
    Handle input from Xbox controllers connected to the Driver Station.
    
    This class handles Xbox input that comes from the Driver Station. Each
    time a value is requested the most recent value is returned. There is a
    single class instance for each controller and the mapping of ports to
    hardware buttons depends on the code in the Driver Station.
    
    Only first party controllers from Microsoft are guaranteed to have the
    correct mapping, and only through the official NI DS. Sim is not guaranteed
    to have the same mapping, as well as any 3rd party controllers.
    """
    class Axis:
        """
        Represents an axis on an XboxController.
        """
        kLeftTrigger: typing.ClassVar[int] = 2
        kLeftX: typing.ClassVar[int] = 0
        kLeftY: typing.ClassVar[int] = 1
        kRightTrigger: typing.ClassVar[int] = 3
        kRightX: typing.ClassVar[int] = 4
        kRightY: typing.ClassVar[int] = 5
        def __init__(self) -> None:
            ...
    class Button:
        """
        Represents a digital button on an XboxController.
        """
        kA: typing.ClassVar[int] = 1
        kB: typing.ClassVar[int] = 2
        kBack: typing.ClassVar[int] = 7
        kLeftBumper: typing.ClassVar[int] = 5
        kLeftStick: typing.ClassVar[int] = 9
        kRightBumper: typing.ClassVar[int] = 6
        kRightStick: typing.ClassVar[int] = 10
        kStart: typing.ClassVar[int] = 8
        kX: typing.ClassVar[int] = 3
        kY: typing.ClassVar[int] = 4
        def __init__(self) -> None:
            ...
    def A(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the A button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the A button's
                  digital signal attached to the given loop.
        """
    def B(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the B button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the B button's
                  digital signal attached to the given loop.
        """
    def X(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the X button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the X button's
                  digital signal attached to the given loop.
        """
    def Y(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the Y button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the Y button's
                  digital signal attached to the given loop.
        """
    def __init__(self, port: typing.SupportsInt) -> None:
        """
        Construct an instance of a controller.
        
        The controller index is the USB port on the Driver Station.
        
        :param port: The port on the Driver Station that the controller is plugged
                     into (0-5).
        """
    def back(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the back button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the back button's
                  digital signal attached to the given loop.
        """
    def getAButton(self) -> bool:
        """
        Read the value of the A button on the controller.
        
        :returns: The state of the button.
        """
    def getAButtonPressed(self) -> bool:
        """
        Whether the A button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getAButtonReleased(self) -> bool:
        """
        Whether the A button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getBButton(self) -> bool:
        """
        Read the value of the B button on the controller.
        
        :returns: The state of the button.
        """
    def getBButtonPressed(self) -> bool:
        """
        Whether the B button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getBButtonReleased(self) -> bool:
        """
        Whether the B button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getBackButton(self) -> bool:
        """
        Read the value of the back button on the controller.
        
        :returns: The state of the button.
        """
    def getBackButtonPressed(self) -> bool:
        """
        Whether the back button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getBackButtonReleased(self) -> bool:
        """
        Whether the back button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftBumper(self) -> bool:
        """
        Read the value of the left bumper (LB) button on the controller.
        
        :deprecated: Use GetLeftBumperButton instead. This function is deprecated
                     for removal to make function names consistent to allow the HID classes to
                     be automatically generated.
        
        :returns: the state of the button
        """
    def getLeftBumperButton(self) -> bool:
        """
        Read the value of the left bumper button on the controller.
        
        :returns: The state of the button.
        """
    def getLeftBumperButtonPressed(self) -> bool:
        """
        Whether the left bumper button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getLeftBumperButtonReleased(self) -> bool:
        """
        Whether the left bumper button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftBumperPressed(self) -> bool:
        """
        Whether the left bumper (LB) was pressed since the last check.
        
        :deprecated: Use GetLeftBumperButtonPressed instead. This function is
                     deprecated for removal to make function names consistent to allow the HID
                     classes to be automatically generated.
        
        :returns: Whether the button was pressed since the last check
        """
    def getLeftBumperReleased(self) -> bool:
        """
        Whether the left bumper (LB) was released since the last check.
        
        :deprecated: Use GetLeftBumperButtonReleased instead. This function is
                     deprecated for removal to make function names consistent to allow the HID
                     classes to be automatically generated.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftStickButton(self) -> bool:
        """
        Read the value of the left stick button on the controller.
        
        :returns: The state of the button.
        """
    def getLeftStickButtonPressed(self) -> bool:
        """
        Whether the left stick button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getLeftStickButtonReleased(self) -> bool:
        """
        Whether the left stick button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getLeftTriggerAxis(self) -> float:
        """
        Get the left trigger axis value of the controller. Note that this axis
        is bound to the range of [0, 1] as opposed to the usual [-1, 1].
        
        :returns: the axis value.
        """
    def getLeftX(self) -> float:
        """
        Get the X axis value of left side of the controller. Right is positive.
        
        :returns: the axis value.
        """
    def getLeftY(self) -> float:
        """
        Get the Y axis value of left side of the controller. Back is positive.
        
        :returns: the axis value.
        """
    def getRightBumper(self) -> bool:
        """
        Read the value of the right bumper (RB) button on the controller.
        
        :deprecated: Use GetRightBumperButton instead. This function is deprecated
                     for removal to make function names consistent to allow the HID classes to
                     be automatically generated.
        
        :returns: the state of the button
        """
    def getRightBumperButton(self) -> bool:
        """
        Read the value of the right bumper button on the controller.
        
        :returns: The state of the button.
        """
    def getRightBumperButtonPressed(self) -> bool:
        """
        Whether the right bumper button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getRightBumperButtonReleased(self) -> bool:
        """
        Whether the right bumper button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getRightBumperPressed(self) -> bool:
        """
        Whether the right bumper (RB) was pressed since the last check.
        
        :deprecated: Use GetRightBumperButtonPressed instead. This function is
                     deprecated for removal to make function names consistent to allow the HID
                     classes to be automatically generated.
        
        :returns: Whether the button was pressed since the last check
        """
    def getRightBumperReleased(self) -> bool:
        """
        Whether the right bumper (RB) was released since the last check.
        
        :deprecated: Use GetRightBumperButtonReleased instead. This function is
                     deprecated for removal to make function names consistent to allow the HID
                     classes to be automatically generated.
        
        :returns: Whether the button was released since the last check.
        """
    def getRightStickButton(self) -> bool:
        """
        Read the value of the right stick button on the controller.
        
        :returns: The state of the button.
        """
    def getRightStickButtonPressed(self) -> bool:
        """
        Whether the right stick button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getRightStickButtonReleased(self) -> bool:
        """
        Whether the right stick button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getRightTriggerAxis(self) -> float:
        """
        Get the right trigger axis value of the controller. Note that this axis
        is bound to the range of [0, 1] as opposed to the usual [-1, 1].
        
        :returns: the axis value.
        """
    def getRightX(self) -> float:
        """
        Get the X axis value of right side of the controller. Right is positive.
        
        :returns: the axis value.
        """
    def getRightY(self) -> float:
        """
        Get the Y axis value of right side of the controller. Back is positive.
        
        :returns: the axis value.
        """
    def getStartButton(self) -> bool:
        """
        Read the value of the start button on the controller.
        
        :returns: The state of the button.
        """
    def getStartButtonPressed(self) -> bool:
        """
        Whether the start button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getStartButtonReleased(self) -> bool:
        """
        Whether the start button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getXButton(self) -> bool:
        """
        Read the value of the X button on the controller.
        
        :returns: The state of the button.
        """
    def getXButtonPressed(self) -> bool:
        """
        Whether the X button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getXButtonReleased(self) -> bool:
        """
        Whether the X button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def getYButton(self) -> bool:
        """
        Read the value of the Y button on the controller.
        
        :returns: The state of the button.
        """
    def getYButtonPressed(self) -> bool:
        """
        Whether the Y button was pressed since the last check.
        
        :returns: Whether the button was pressed since the last check.
        """
    def getYButtonReleased(self) -> bool:
        """
        Whether the Y button was released since the last check.
        
        :returns: Whether the button was released since the last check.
        """
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
    def leftBumper(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the left bumper button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the left bumper button's
                  digital signal attached to the given loop.
        """
    def leftStick(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the left stick button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the left stick button's
                  digital signal attached to the given loop.
        """
    @typing.overload
    def leftTrigger(self, threshold: typing.SupportsFloat, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the axis value of the left trigger.
        The returned trigger will be true when the axis value is greater than
        ``threshold``.
        
        :param threshold: the minimum axis value for the returned event to be true.
                          This value should be in the range [0, 1] where 0 is the unpressed state of
                          the axis.
        :param loop:      the event loop instance to attach the event to.
        
        :returns: an event instance that is true when the left trigger's axis
                  exceeds the provided threshold, attached to the given event loop
        """
    @typing.overload
    def leftTrigger(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the axis value of the left trigger.
        The returned trigger will be true when the axis value is greater than 0.5.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance that is true when the left trigger's axis
                  exceeds 0.5, attached to the given event loop
        """
    def rightBumper(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the right bumper button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the right bumper button's
                  digital signal attached to the given loop.
        """
    def rightStick(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the right stick button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the right stick button's
                  digital signal attached to the given loop.
        """
    @typing.overload
    def rightTrigger(self, threshold: typing.SupportsFloat, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the axis value of the right trigger.
        The returned trigger will be true when the axis value is greater than
        ``threshold``.
        
        :param threshold: the minimum axis value for the returned event to be true.
                          This value should be in the range [0, 1] where 0 is the unpressed state of
                          the axis.
        :param loop:      the event loop instance to attach the event to.
        
        :returns: an event instance that is true when the right trigger's axis
                  exceeds the provided threshold, attached to the given event loop
        """
    @typing.overload
    def rightTrigger(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the axis value of the right trigger.
        The returned trigger will be true when the axis value is greater than 0.5.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance that is true when the right trigger's axis
                  exceeds 0.5, attached to the given event loop
        """
    def start(self, loop: wpilib.event._event.EventLoop) -> wpilib.event._event.BooleanEvent:
        """
        Constructs an event instance around the start button's
        digital signal.
        
        :param loop: the event loop instance to attach the event to.
        
        :returns: an event instance representing the start button's
                  digital signal attached to the given loop.
        """
class _DriverStationModeThread:
    """
    For internal use only.
    """
    def __init__(self) -> None:
        """
        For internal use only.
        """
    def inAutonomous(self, entering: bool) -> None:
        """
        Only to be used to tell the Driver Station what code you claim to be
        executing for diagnostic purposes only.
        
        :param entering: If true, starting autonomous code; if false, leaving
                         autonomous code
        """
    def inDisabled(self, entering: bool) -> None:
        """
        Only to be used to tell the Driver Station what code you claim to be
        executing for diagnostic purposes only.
        
        :param entering: If true, starting disabled code; if false, leaving disabled
                         code
        """
    def inTeleop(self, entering: bool) -> None:
        """
        Only to be used to tell the Driver Station what code you claim to be
        executing for diagnostic purposes only.
        
        :param entering: If true, starting teleop code; if false, leaving teleop
                         code
        """
    def inTest(self, entering: bool) -> None:
        """
        Only to be used to tell the Driver Station what code you claim to be
        executing for diagnostic purposes only.
        
        :param entering: If true, starting test code; if false, leaving test code
        """
def _clearSmartDashboardData() -> None:
    ...
def getCurrentThreadPriority() -> tuple[int, bool]:
    """
    Get the thread priority for the current thread.
    
    :param isRealTime: Set to true if thread is real-time, otherwise false.
    
    :returns: The current thread priority. For real-time, this is 1-99
              with 99 being highest. For non-real-time, this is 0. See
              "man 7 sched" for details.
    """
def getDeployDirectory() -> str:
    """
    Obtains the deploy directory of the program, which is the remote location
    the deploy directory is deployed to by default. On the roboRIO, this is
    /home/lvuser/py/deploy. In simulation, it is where the simulation was launched
    from, in the subdirectory "deploy" (`dirname(robot.py)`/deploy).
    
    :returns: The result of the operating directory lookup
    """
def getErrorMessage() -> tuple[str, int]:
    """
    Gets error message string for an error code.
    """
def getOperatingDirectory() -> str:
    """
    Obtains the operating directory of the program. On the roboRIO, this
    is /home/lvuser/py. In simulation, it is the location of robot.py
    
    :returns: The result of the operating directory lookup.
    """
def getTime() -> wpimath.units.seconds:
    """
    Gives real-time clock system time with nanosecond resolution
    
    :returns: The time, just in case you want the robot to start autonomous at 8pm
              on Saturday.
    """
def setCurrentThreadPriority(realTime: bool, priority: typing.SupportsInt) -> bool:
    """
    Sets the thread priority for the current thread.
    
    :param realTime: Set to true to set a real-time priority, false for standard
                     priority.
    :param priority: Priority to set the thread to. For real-time, this is 1-99
                     with 99 being highest. For non-real-time, this is forced to
                     0. See "man 7 sched" for more details.
    
    :returns: True on success.
    """
def wait(seconds: wpimath.units.seconds) -> None:
    """
    Pause the task for a specified time.
    
    Pause the execution of the program for a specified period of time given in
    seconds. Motors will continue to run at their last assigned values, and
    sensors will continue to update. Only the task containing the wait will pause
    until the wait time is expired.
    
    :param seconds: Length of time to pause, in seconds.
    """
_lw_cleanup: typing.Any  # value = <capsule object>
_sd_cleanup: typing.Any  # value = <capsule object>
