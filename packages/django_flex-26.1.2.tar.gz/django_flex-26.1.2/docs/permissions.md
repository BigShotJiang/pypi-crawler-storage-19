# Permissions Guide

Django-Flex uses a **deny-by-default** security model. Users have no access unless explicitly granted.

## Django Auth Integration

Django-Flex integrates natively with Django's built-in auth system:

- **User.is_superuser** → bypasses all permission checks
- **User.is_staff** → gets `staff` role
- **User.groups** → first group name becomes the role
- **Authenticated (no group)** → gets `authenticated` role

### Role Resolution Order

```python
# How django-flex determines user role:
if user.is_superuser:
    role = "superuser"  # Bypasses ALL checks
elif user.is_staff:
    role = "staff"
elif user.groups.exists():
    role = user.groups.first().name.lower()
else:
    role = "authenticated"
```

## Permission Layers

Django-Flex enforces security at four levels:

1. **Row-Level** — Which database rows can the user see?
2. **Field-Level** — Which fields can the user access on those rows?
3. **Filter-Level** — Which fields can the user filter on?
4. **Operation-Level** — Which actions (get, query, create, update, delete) can the user perform?

## Configuration Structure

Using Django's official models: Blog, Author, Entry

```python
# settings.py
from django.db.models import Q

DJANGO_FLEX = {
    'PERMISSIONS': {
        'entry': {
            # Fields excluded from wildcard expansion
            'exclude': ['internal_notes'],

            'staff': {
                'rows': lambda user: Q(),  # All entries
                'fields': ['*', 'blog.*'],
                'filters': ['id', 'rating', 'rating.gte', 'blog.id'],
                'order_by': ['id', '-id', 'pub_date', '-pub_date'],
                'ops': ['get', 'query', 'create', 'update', 'delete'],
            },
            'authenticated': {
                'rows': lambda user: Q(pub_date__lte=date.today()),
                'fields': ['id', 'headline', 'body_text', 'blog.name'],
                'filters': ['id', 'headline.icontains'],
                'order_by': ['-pub_date'],
                'ops': ['get', 'query'],
            },
        },
    },
}
```

## Row-Level Security

The `rows` key is a callable that receives the user and returns a Django `Q` object.

```python
'entry': {
    'staff': {
        # Staff see all entries
        'rows': lambda user: Q(),
    },
    'authenticated': {
        # Users see only published entries
        'rows': lambda user: Q(pub_date__lte=date.today()),
    },
},

'blog': {
    'authenticated': {
        # Users see only active blogs
        'rows': lambda user: Q(is_active=True),
    },
},
```

## Field-Level Security

| Pattern | Matches | Example |
|---------|---------|---------|
| `*` | All direct fields | `id`, `headline`, `rating` |
| `<field>` | Exact field | `headline` |
| `<relation>.*` | All relation fields | `blog.id`, `blog.name` |
| `<relation>.<field>` | Specific relation field | `blog.name` |

```python
'staff': {
    'fields': ['*', 'blog.*'],  # All entry fields + all blog fields
},
'authenticated': {
    'fields': ['id', 'headline', 'pub_date', 'blog.name'],  # Limited
},
```

### Excluding Sensitive Fields

```python
'entry': {
    'exclude': ['internal_notes', 'draft_content'],

    'staff': {
        'fields': ['*'],  # Even with *, excluded fields won't be returned
    },
}
```

## Filter-Level Security

```python
'staff': {
    'filters': [
        'id',
        'rating', 'rating.gte', 'rating.lte',
        'pub_date', 'pub_date.gte', 'pub_date.lte',
        'headline.icontains',
        'blog.id', 'blog.name.icontains',
    ],
},
```

## Order-Level Security

```python
'authenticated': {
    'order_by': [
        'pub_date', '-pub_date',  # Both directions
        'rating', '-rating',
    ],
},
```

## Operation-Level Security

| Operation | Description |
|-----------|-------------|
| `get` | Retrieve single object by ID |
| `query` | Query multiple objects |
| `create` | Create new objects |
| `update` | Update existing objects |
| `delete` | Delete objects |

```python
'staff': {
    'ops': ['get', 'query', 'create', 'update', 'delete'],  # Full
},
'authenticated': {
    'ops': ['get', 'query'],  # Read-only
},
```

## Complete Example

```python
# settings.py
from datetime import date
from django.db.models import Q

DJANGO_FLEX = {
    'DEFAULT_LIMIT': 50,
    'MAX_LIMIT': 200,
    'MAX_RELATION_DEPTH': 2,

    'PERMISSIONS': {
        'blog': {
            'staff': {
                'rows': lambda user: Q(),
                'fields': ['*'],
                'filters': ['id', 'name.icontains'],
                'order_by': ['id', 'name', '-name'],
                'ops': ['get', 'query', 'create', 'update', 'delete'],
            },
            'authenticated': {
                'rows': lambda user: Q(),
                'fields': ['id', 'name', 'tagline'],
                'filters': ['id', 'name.icontains'],
                'order_by': ['name'],
                'ops': ['get', 'query'],
            },
        },

        'author': {
            'staff': {
                'rows': lambda user: Q(),
                'fields': ['*'],
                'filters': ['id', 'name.icontains', 'email.icontains'],
                'order_by': ['id', 'name', '-name'],
                'ops': ['get', 'query', 'create', 'update'],
            },
            'authenticated': {
                'rows': lambda user: Q(),
                'fields': ['id', 'name'],  # Hide email
                'filters': ['id', 'name.icontains'],
                'order_by': ['name'],
                'ops': ['get', 'query'],
            },
        },

        'entry': {
            'exclude': ['internal_notes'],

            'staff': {
                'rows': lambda user: Q(),
                'fields': ['*', 'blog.*'],
                'filters': [
                    'id', 'rating', 'rating.gte', 'rating.lte',
                    'pub_date', 'pub_date.gte', 'pub_date.lte',
                    'headline.icontains', 'body_text.icontains',
                    'blog.id', 'blog.name.icontains',
                    'number_of_comments.gte',
                ],
                'order_by': [
                    'id', '-id', 'pub_date', '-pub_date',
                    'rating', '-rating', 'number_of_comments', '-number_of_comments',
                ],
                'ops': ['get', 'query', 'create', 'update', 'delete'],
            },
            'authenticated': {
                'rows': lambda user: Q(pub_date__lte=date.today()),
                'fields': ['id', 'headline', 'body_text', 'pub_date', 'rating', 'blog.name'],
                'filters': [
                    'id', 'headline.icontains',
                    'rating.gte', 'blog.id',
                ],
                'order_by': ['-pub_date', 'rating', '-rating'],
                'ops': ['get', 'query'],
            },
        },
    },
}
```

## Setting Up Django Groups

```python
from django.contrib.auth.models import Group

# Create groups
Group.objects.get_or_create(name='Editor')
Group.objects.get_or_create(name='Viewer')

# Assign user to group
user.groups.add(Group.objects.get(name='Editor'))
```

Then configure permissions:

```python
'entry': {
    'editor': {...},    # Users in "Editor" group
    'viewer': {...},    # Users in "Viewer" group
    'authenticated': {...},  # Logged in, no group
},
```

## Security Best Practices

1. **Start Restrictive** — Begin with minimal permissions
2. **Use Exclude** — Always exclude sensitive fields
3. **Limit Relation Depth** — Set `MAX_RELATION_DEPTH`
4. **Use Django Groups** — Leverage built-in group system
5. **Test Permissions** — Write tests for permission denials
