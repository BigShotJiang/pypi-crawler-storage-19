# Filtering Examples

This guide provides comprehensive examples of filtering with django-flex.

All examples use Django's official documentation models: `Blog`, `Author`, `Entry`.

## Basic Filters

### Simple Equality

```javascript
// Filter by exact value
{
    filters: { rating: 5 }
}

// Multiple conditions (AND)
{
    filters: {
        rating: 5,
        'blog.id': 1
    }
}
```

### Comparison Operators

```javascript
// Less than
{ filters: { 'rating.lt': 3 } }

// Less than or equal
{ filters: { 'rating.lte': 3 } }

// Greater than
{ filters: { 'rating.gt': 3 } }

// Greater than or equal
{ filters: { 'rating.gte': 4 } }

// Range (between)
{ filters: { 'rating.gte': 3, 'rating.lte': 5 } }
```

### List Membership

```javascript
// IN operator
{
    filters: { 'rating.in': [4, 5] }
}
```

### Null Checks

```javascript
// Is null (e.g., entries with no mod_date)
{ filters: { 'mod_date.isnull': true } }

// Is not null
{ filters: { 'mod_date.isnull': false } }
```

---

## Text Search

### Case-Sensitive

```javascript
// Contains
{ filters: { 'headline.contains': 'Django' } }

// Starts with
{ filters: { 'headline.startswith': 'Getting' } }

// Ends with
{ filters: { 'headline.endswith': 'Tutorial' } }
```

### Case-Insensitive (Recommended)

```javascript
// Contains (case-insensitive)
{ filters: { 'headline.icontains': 'django' } }

// Starts with (case-insensitive)
{ filters: { 'headline.istartswith': 'getting' } }

// Exact match (case-insensitive)
{ filters: { 'blog.name.iexact': 'DJANGO NEWS' } }
```

### Regular Expressions

```javascript
// Regex match
{ filters: { 'headline.regex': '^Django.*Tutorial$' } }

// Regex match (case-insensitive)
{ filters: { 'headline.iregex': '^(getting|learning)' } }
```

---

## Date and Time Filters

### Date Comparisons

```javascript
// After a date
{ filters: { 'pub_date.gte': '2024-01-01' } }

// Before a date
{ filters: { 'pub_date.lte': '2024-12-31' } }

// Date range (this year)
{
    filters: {
        'pub_date.gte': '2024-01-01',
        'pub_date.lte': '2024-12-31'
    }
}
```

### Date Parts

```javascript
// Filter by year
{ filters: { 'pub_date.year': 2024 } }

// Filter by month (1-12)
{ filters: { 'pub_date.month': 1 } }

// Filter by day of month (1-31)
{ filters: { 'pub_date.day': 15 } }

// Filter by day of week (1=Sunday, 7=Saturday)
{ filters: { 'pub_date.week_day': 2 } }  // Monday
```

---

## Nested Relation Filters

### Single Level Nesting

```javascript
// Filter by related model field
{ filters: { 'blog.name.icontains': 'news' } }

// Filter by related model ID
{ filters: { 'blog.id': 1 } }
```

### Multiple Relation Filters

```javascript
{
    filters: {
        'blog.name.icontains': 'django',
        'rating.gte': 4
    }
}
```

---

## Composable Filters

### OR Conditions

```javascript
// Either condition
{
    filters: {
        or: {
            rating: 5,
            'number_of_comments.gte': 100
        }
    }
}

// Multiple OR groups (as list)
{
    filters: {
        or: [
            { rating: 5 },
            { 'number_of_comments.gte': 100, 'rating.gte': 4 }
        ]
    }
}
```

### AND Conditions (Explicit)

```javascript
// Explicit AND (same as default behavior)
{
    filters: {
        and: {
            'rating.gte': 4,
            'pub_date.gte': '2024-01-01'
        }
    }
}
```

### NOT Conditions

```javascript
// Exclude low-rated entries
{
    filters: {
        not: { 'rating.lt': 3 }
    }
}

// Exclude multiple ratings
{
    filters: {
        not: { 'rating.in': [1, 2] }
    }
}
```

### Complex Composition

```javascript
// (rating >= 4 AND pub_date >= this_year)
// OR
// (number_of_comments >= 50 AND NOT low_rating)
{
    filters: {
        or: [
            {
                'rating.gte': 4,
                'pub_date.gte': '2024-01-01'
            },
            {
                'number_of_comments.gte': 50,
                not: { 'rating.lt': 3 }
            }
        ]
    }
}
```

---

## Real-World Examples

### Search Blog Entries

```javascript
const searchEntries = async (searchTerm) => {
    const response = await fetch('/api/entries/', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            fields: 'id, headline, pub_date, blog.name',
            filters: {
                or: {
                    'headline.icontains': searchTerm,
                    'body_text.icontains': searchTerm
                }
            },
            order_by: '-pub_date',
            limit: 20
        })
    });
    return response.json();
};
```

### Recent High-Rated Entries

```javascript
const getTopEntries = async () => {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
        .toISOString().split('T')[0];

    const response = await fetch('/api/entries/', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            fields: 'id, headline, pub_date, rating, blog.name',
            filters: {
                'pub_date.gte': thirtyDaysAgo,
                'rating.gte': 4
            },
            order_by: '-rating',
            limit: 10
        })
    });
    return response.json();
};
```

### Entries by Blog

```javascript
const getEntriesByBlog = async (blogId) => {
    const response = await fetch('/api/entries/', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            fields: 'id, headline, pub_date, number_of_comments',
            filters: {
                'blog.id': blogId
            },
            order_by: '-pub_date',
            limit: 50
        })
    });
    return response.json();
};
```

### Popular Entries with Many Comments

```javascript
const getPopularEntries = async () => {
    const response = await fetch('/api/entries/', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            fields: 'id, headline, number_of_comments, number_of_pingbacks, rating',
            filters: {
                'number_of_comments.gte': 10,
                'rating.gte': 4
            },
            order_by: '-number_of_comments',
            limit: 20
        })
    });
    return response.json();
};
```

---

## Error Handling

### Permission Denied

If you try to filter on a field that's not allowed:

```javascript
// Request with disallowed filter
{
    filters: { 'body_text.icontains': 'secret' }
}

// Response
{
    "success": false,
    "code": "FLEX_PERMISSION_DENIED",
    "error": "Filter denied: 'body_text.icontains' not allowed for filtering"
}
```

### Relation Depth Exceeded

```javascript
// Too deep (if MAX_RELATION_DEPTH = 2)
{
    filters: { 'blog.owner.profile.settings.theme': 'dark' }  // 4 levels
}

// Response
{
    "success": false,
    "code": "FLEX_PERMISSION_DENIED",
    "error": "Filter denied: '...' exceeds max relation depth of 2"
}
```
