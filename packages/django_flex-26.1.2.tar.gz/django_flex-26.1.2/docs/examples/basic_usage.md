# Basic Usage Examples

This guide covers common usage patterns for django-flex.

All examples use Django's official documentation models: `Blog`, `Author`, `Entry`.

## Single Object Retrieval

### Get by ID

```javascript
// Fetch a specific entry
const response = await fetch('/api/entries/', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
        id: 1,
        fields: 'id, headline, blog.name'
    })
});

const data = await response.json();
// {
//     "success": true,
//     "code": "FLEX_OK",
//     "id": 1,
//     "headline": "Django 5.0 Released",
//     "blog": {"name": "Django News"}
// }
```

### Get with All Fields

```javascript
{
    id: 1,
    fields: '*'  // All fields on the model
}
```

### Get with Related Fields

```javascript
{
    id: 1,
    fields: 'id, headline, blog.*'
}
// Expands to all blog fields
```

---

## Query Retrieval

### Basic Query

```javascript
const response = await fetch('/api/entries/', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
        fields: 'id, headline, blog.name'
    })
});

// Returns first 50 results by default
```

### With Pagination

```javascript
{
    fields: 'id, headline',
    limit: 20,
    offset: 0
}

// Response includes pagination info:
// {
//     "pagination": {
//         "offset": 0,
//         "limit": 20,
//         "has_more": true,
//         "next": {...}
//     }
// }
```

### With Ordering

```javascript
// Ascending order
{
    fields: 'id, headline, pub_date',
    order_by: 'pub_date'
}

// Descending order
{
    fields: 'id, headline, pub_date',
    order_by: '-pub_date'
}

// Order by related field
{
    fields: 'id, blog.name',
    order_by: 'blog.name'
}
```

---

## Field Selection Patterns

### Minimal Fields (Performance)

```javascript
// Only fetch what you need
{
    fields: 'id, headline'
}
```

### Wildcard Expansion

```javascript
// All model fields
{
    fields: '*'
}

// All model fields + specific relation
{
    fields: '*, blog.name'
}

// All relation fields
{
    fields: 'id, blog.*'
}
```

### Deep Nesting

```javascript
// Two levels of relation
{
    fields: 'id, blog.name, blog.tagline'
}
```

---

## Pagination Patterns

### Manual Pagination

```javascript
let offset = 0;
const limit = 20;

const fetchPage = async () => {
    const response = await fetch('/api/entries/', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            fields: 'id, headline',
            limit,
            offset
        })
    });
    const data = await response.json();

    // Move to next page
    if (data.pagination.has_more) {
        offset += limit;
    }

    return data.results;
};
```

### Cursor-Based Pagination

```javascript
let currentQuery = {
    fields: 'id, headline',
    limit: 20
};

const fetchNextPage = async () => {
    const response = await fetch('/api/entries/', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(currentQuery)
    });
    const data = await response.json();

    // Use the next cursor for the following request
    if (data.pagination.has_more) {
        currentQuery = data.pagination.next;
    }

    return data.results;
};
```

### Fetch All (with batching)

```javascript
const fetchAll = async () => {
    let allResults = {};
    let query = {
        fields: 'id, headline',
        limit: 100
    };
    let hasMore = true;

    while (hasMore) {
        const response = await fetch('/api/entries/', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(query)
        });
        const data = await response.json();

        Object.assign(allResults, data.results);

        hasMore = data.pagination.has_more;
        if (hasMore) {
            query = data.pagination.next;
        }
    }

    return allResults;
};
```

---

## React/Vue Integration

### React Custom Hook

```javascript
import { useState, useCallback } from 'react';

const useFlexQuery = (endpoint) => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const query = useCallback(async (spec) => {
        setLoading(true);
        setError(null);

        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(spec)
            });
            const result = await response.json();

            if (result.success) {
                setData(result);
            } else {
                setError(result.error || result.code);
            }

            return result;
        } catch (err) {
            setError(err.message);
            throw err;
        } finally {
            setLoading(false);
        }
    }, [endpoint]);

    return { data, loading, error, query };
};

// Usage
function EntryList() {
    const { data, loading, error, query } = useFlexQuery('/api/entries/');

    useEffect(() => {
        query({
            fields: 'id, headline, blog.name',
            filters: { 'rating.gte': 4 },
            limit: 20
        });
    }, []);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;

    return (
        <ul>
            {Object.entries(data?.results || {}).map(([id, entry]) => (
                <li key={id}>{entry.headline} - {entry.blog.name}</li>
            ))}
        </ul>
    );
}
```

### Vue Composable

```javascript
import { ref } from 'vue';

export function useFlexQuery(endpoint) {
    const data = ref(null);
    const loading = ref(false);
    const error = ref(null);

    async function query(spec) {
        loading.value = true;
        error.value = null;

        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(spec)
            });
            const result = await response.json();

            if (result.success) {
                data.value = result;
            } else {
                error.value = result.error || result.code;
            }

            return result;
        } catch (err) {
            error.value = err.message;
            throw err;
        } finally {
            loading.value = false;
        }
    }

    return { data, loading, error, query };
}
```

---

## Error Handling

### Check Response Status

```javascript
const response = await fetch('/api/entries/', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({id: 999999, fields: 'id'})
});

const data = await response.json();

if (!data.success) {
    switch (data.code) {
        case 'FLEX_NOT_FOUND':
            console.error('Entry not found');
            break;
        case 'FLEX_PERMISSION_DENIED':
            console.error('Permission denied:', data.error);
            break;
        case 'FLEX_INVALID_FILTER':
            console.error('Invalid filter:', data.error);
            break;
        default:
            console.error('Error:', data.code, data.error);
    }
}
```

### Handle Limit Clamping Warning

```javascript
const data = await response.json();

if (data.warning && data.code === 'FLEX_LIMIT_CLAMPED') {
    console.warn(
        `Requested ${data.requested_limit} items, ` +
        `but server limit is ${data.pagination.limit}`
    );
}
```
