# Quick Start Guide

This guide walks you through creating your first flexible query endpoint.

## Prerequisites

- Django-Flex installed (see [Installation Guide](installation.md))
- An existing Django model to query

## Example Models

We'll use Django's official documentation models:

```python
# models.py
from datetime import date
from django.db import models


class Blog(models.Model):
    name = models.CharField(max_length=100)
    tagline = models.TextField()

    def __str__(self):
        return self.name


class Author(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField()

    def __str__(self):
        return self.name


class Entry(models.Model):
    blog = models.ForeignKey(Blog, on_delete=models.CASCADE)
    headline = models.CharField(max_length=255)
    body_text = models.TextField()
    pub_date = models.DateField()
    mod_date = models.DateField(default=date.today)
    authors = models.ManyToManyField(Author)
    number_of_comments = models.IntegerField(default=0)
    number_of_pingbacks = models.IntegerField(default=0)
    rating = models.IntegerField(default=5)

    def __str__(self):
        return self.headline
```

## Step 1: Create a FlexQueryView

```python
# views.py
from django.db.models import Q
from django_flex import FlexQueryView
from .models import Entry

class EntryQueryView(FlexQueryView):
    """API endpoint for querying blog entries."""

    model = Entry
    require_auth = True  # Require authentication

    flex_permissions = {
        'staff': {
            # Staff can see all entries
            'rows': lambda user: Q(),

            # Allowed fields
            'fields': [
                'id', 'headline', 'body_text', 'pub_date', 'mod_date',
                'rating', 'number_of_comments',
                'blog.name', 'blog.tagline',
            ],

            # Allowed filters
            'filters': [
                'id',
                'rating', 'rating.gte', 'rating.lte',
                'pub_date', 'pub_date.gte', 'pub_date.lte',
                'headline.icontains',
                'blog.id', 'blog.name.icontains',
            ],

            # Allowed ordering
            'order_by': [
                'id', '-id',
                'pub_date', '-pub_date',
                'rating', '-rating',
            ],

            # Allowed operations
            'ops': ['get', 'query'],
        },
        'authenticated': {
            # Regular users see only published entries (pub_date <= today)
            'rows': lambda user: Q(pub_date__lte=date.today()),

            'fields': ['id', 'headline', 'body_text', 'pub_date', 'blog.name'],

            'filters': [
                'id', 'headline.icontains', 'blog.name.icontains',
            ],

            'order_by': ['-pub_date', 'pub_date'],

            'ops': ['get', 'query'],
        },
    }
```

## Step 2: Add URL Route

```python
# urls.py
from django.urls import path
from .views import EntryQueryView

urlpatterns = [
    path('api/entries/', EntryQueryView.as_view(), name='entry-query'),
]
```

## Step 3: Query from Frontend

### Query Entries

```javascript
// Fetch recent blog entries with blog info
const response = await fetch('/api/entries/', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer your-token',  // If using token auth
    },
    body: JSON.stringify({
        fields: 'id, headline, pub_date, rating, blog.name',
        filters: {
            'rating.gte': 4
        },
        order_by: '-pub_date',
        limit: 10
    })
});

const data = await response.json();
console.log(data);
// {
//     "success": true,
//     "code": "FLEX_OK_QUERY",
//     "pagination": {
//         "offset": 0,
//         "limit": 10,
//         "has_more": false
//     },
//     "results": {
//         "1": {
//             "id": 1,
//             "headline": "Django 5.0 Released",
//             "pub_date": "2024-01-15",
//             "rating": 5,
//             "blog": {
//                 "name": "Django News"
//             }
//         },
//         "2": {
//             "id": 2,
//             "headline": "Getting Started with Django REST",
//             "pub_date": "2024-01-14",
//             "rating": 4,
//             "blog": {
//                 "name": "Tutorial Blog"
//             }
//         }
//     }
// }
```

### Get Single Entry

```javascript
// Fetch specific entry by ID
const response = await fetch('/api/entries/', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        id: 1,
        fields: 'id, headline, body_text, pub_date, blog.name, blog.tagline'
    })
});

const data = await response.json();
// {
//     "success": true,
//     "code": "FLEX_OK",
//     "id": 1,
//     "headline": "Django 5.0 Released",
//     "body_text": "We're excited to announce...",
//     "pub_date": "2024-01-15",
//     "blog": {
//         "name": "Django News",
//         "tagline": "All the latest Django updates"
//     }
// }
```

### Advanced Filtering

```javascript
// Complex query with date range and text search
const response = await fetch('/api/entries/', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
        fields: 'id, headline, pub_date, blog.name',
        filters: {
            'pub_date.gte': '2024-01-01',
            'pub_date.lte': '2024-01-31',
            'headline.icontains': 'django'
        },
        order_by: '-pub_date',
        limit: 50
    })
});
```

## Step 4: Handle Pagination

When there are more results, the response includes a `next` cursor:

```javascript
let allResults = {};
let hasMore = true;
let querySpec = {
    fields: 'id, headline, blog.name',
    limit: 20
};

while (hasMore) {
    const response = await fetch('/api/entries/', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(querySpec)
    });

    const data = await response.json();

    // Merge results
    Object.assign(allResults, data.results);

    // Check for more pages
    hasMore = data.pagination?.has_more || false;
    if (hasMore) {
        querySpec = data.pagination.next;
    }
}

console.log(`Fetched ${Object.keys(allResults).length} entries`);
```

## What's Next?

- [Permissions Guide](permissions.md) - Set up role-based access control
- [Filtering Guide](examples/filtering.md) - Advanced filtering examples
- [API Reference](api_reference.md) - Complete function and class documentation
