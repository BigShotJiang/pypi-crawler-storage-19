# API Reference

Complete reference for all django-flex classes and functions.

All examples use Django's official documentation models: Blog, Author, Entry.

---

## Core Classes

### FlexQuery

Main query execution class.

```python
from django_flex import FlexQuery

query = FlexQuery(Entry)
result = query.execute({
    'fields': 'id, headline, blog.name',
    'filters': {'rating.gte': 4},
    'order_by': '-pub_date',
    'limit': 20,
}, user=request.user)
```

#### Methods

| Method | Description |
|--------|-------------|
| `__init__(model)` | Initialize with model class or name |
| `set_user(user)` | Set user for permission checking |
| `set_permissions(permissions)` | Set custom permissions dict |
| `execute(query_spec, user=None, action=None)` | Execute query |

### FlexResponse

Response builder class.

```python
from django_flex import FlexResponse

# Success responses
response = FlexResponse.ok(id=1, headline='...')
response = FlexResponse.ok_query(results={...}, pagination={...})

# Error response
response = FlexResponse.error('NOT_FOUND', 'Entry not found')
```

#### Class Methods

| Method | Description |
|--------|-------------|
| `ok(**data)` | Create success response |
| `ok_query(results, pagination=None, **data)` | Create query response |
| `error(code, message=None)` | Create error response |
| `warning_response(code, **data)` | Create warning response |

---

## Views

### FlexQueryView

Class-based view for flexible queries.

```python
from django_flex import FlexQueryView

class EntryQueryView(FlexQueryView):
    model = Entry
    require_auth = True
    allowed_actions = ['get', 'query']

    flex_permissions = {
        'staff': {
            'rows': lambda user: Q(),
            'fields': ['*', 'blog.*'],
            'filters': ['id', 'rating.gte'],
            'order_by': ['-pub_date'],
            'ops': ['get', 'query'],
        },
    }
```

#### Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `model` | Model | Django model class |
| `flex_permissions` | dict | Permission configuration |
| `require_auth` | bool | Require authentication (default: True) |
| `allowed_actions` | list | Allowed actions (default: ['get', 'query']) |

---

## Decorators

### flex_query

Decorator for function-based views.

```python
from django_flex import flex_query

@flex_query(
    model=Entry,
    allowed_fields=['id', 'headline', 'blog.name'],
    allowed_filters=['id', 'rating.gte', 'headline.icontains'],
    allowed_ordering=['-pub_date', 'rating'],
    allowed_actions=['get', 'query'],
)
def entry_query(request, result, query_spec):
    # result is a FlexResponse
    return JsonResponse(result.to_dict())
```

#### Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `model` | Model | Django model class |
| `allowed_fields` | list | Allowed field patterns (default: ['*']) |
| `allowed_filters` | list | Allowed filter keys (default: []) |
| `allowed_ordering` | list | Allowed order_by values (default: []) |
| `require_auth` | bool | Require authentication (default: True) |
| `allowed_actions` | list | Allowed actions (default: ['get', 'query']) |

---

## Field Utilities

### parse_fields

Parse comma-separated field string into list.

```python
from django_flex import parse_fields

fields = parse_fields('id, headline, blog.name')
# ['id', 'headline', 'blog.name']

fields = parse_fields('*')
# ['*']
```

### expand_fields

Expand wildcards in field list.

```python
from django_flex import expand_fields

expanded = expand_fields(Entry, ['*', 'blog.*'])
# ['id', 'headline', 'body_text', 'pub_date', 'mod_date', 'rating',
#  'number_of_comments', 'number_of_pingbacks',
#  'blog.id', 'blog.name', 'blog.tagline']
```

### get_model_fields

Get list of concrete field names for a model.

```python
from django_flex import get_model_fields

fields = get_model_fields(Entry)
# ['id', 'blog', 'headline', 'body_text', 'pub_date', 'mod_date',
#  'number_of_comments', 'number_of_pingbacks', 'rating']
```

### extract_relations

Extract relation prefixes from field list for select_related.

```python
from django_flex import extract_relations

relations = extract_relations(['id', 'headline', 'blog.name', 'blog.tagline'])
# ['blog']
```

---

## Filter Utilities

### build_q_object

Build Django Q object from filter dict.

```python
from django_flex import build_q_object

q = build_q_object({
    'rating.gte': 4,
    'pub_date.lte': '2024-12-31',
})
# <Q: (AND: ('rating__gte', 4), ('pub_date__lte', '2024-12-31'))>

# With OR composition
q = build_q_object({
    'or': {'rating': 5, 'number_of_comments.gte': 100}
})
```

### parse_filter_key

Parse filter key into field and operator.

```python
from django_flex import parse_filter_key

field, op = parse_filter_key('rating.gte')
# ('rating', 'gte')

field, op = parse_filter_key('blog.name.icontains')
# ('blog.name', 'icontains')
```

---

## Permission Functions

### check_permission

Main permission check function.

```python
from django_flex import check_permission

row_filter, fields = check_permission(
    user=request.user,
    model_name='entry',
    action='query',
    requested_fields=['id', 'headline', 'blog.name'],
)
# row_filter: Q object for row filtering
# fields: validated field list
```

### check_filter_permission

Check if filter keys are allowed.

```python
from django_flex import check_filter_permission

check_filter_permission(
    user=request.user,
    model_name='entry',
    filter_keys=['rating.gte', 'blog.id'],
)
# Raises PermissionError if not allowed
```

### check_order_permission

Check if order_by is allowed.

```python
from django_flex import check_order_permission

check_order_permission(
    user=request.user,
    model_name='entry',
    order_by='-pub_date',
)
# Raises PermissionError if not allowed
```

---

## Settings

### flex_settings

Access django-flex settings.

```python
from django_flex import flex_settings

limit = flex_settings.DEFAULT_LIMIT  # 50
max_limit = flex_settings.MAX_LIMIT  # 200
```

### Available Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `DEFAULT_LIMIT` | 50 | Default pagination limit |
| `MAX_LIMIT` | 200 | Maximum pagination limit |
| `MAX_RELATION_DEPTH` | 2 | Maximum relation traversal depth |
| `REQUIRE_AUTHENTICATION` | True | Require auth for middleware |
| `AUDIT_QUERIES` | False | Log queries to django logger |
| `PERMISSIONS` | {} | Model permission configuration |

---

## Response Utilities

### build_nested_response

Build nested dict from object and fields.

```python
from django_flex import build_nested_response

data = build_nested_response(entry, ['id', 'headline', 'blog.name'])
# {'id': 1, 'headline': 'Django 5.0 Released', 'blog': {'name': 'Django News'}}
```

---

## Operators

Full list of supported filter operators.

```python
from django_flex import OPERATORS

# OPERATORS contains:
# 'lt', 'lte', 'gt', 'gte', 'exact', 'iexact',
# 'contains', 'icontains', 'startswith', 'istartswith',
# 'endswith', 'iendswith', 'in', 'isnull', 'range',
# 'date', 'year', 'month', 'day', 'hour', 'minute', 'second',
# 'regex', 'iregex'
```
