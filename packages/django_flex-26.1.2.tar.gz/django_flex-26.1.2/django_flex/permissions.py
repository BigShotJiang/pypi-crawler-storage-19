"""
Django-Flex Permission System

Provides row-level, field-level, and operation-level access control
following the Principle of Least Privilege (deny by default, explicitly grant).

Integrates with Django's built-in auth system:
- User.groups for role-based access
- User.is_superuser for admin bypass
- User.is_staff for staff-level access

Features:
- Row-level: Which rows can the user see (Q filters)
- Field-level: Which fields can the user access (including relations)
- Operation-level: Which actions can the user perform (get, query, create, update, delete)
- Filter-level: Which fields can the user filter on
- Order-level: Which fields can the user order by

Usage:
    from django_flex import check_permission

    row_filter, allowed_fields = check_permission(
        user, "entry", "query", requested_fields
    )
    queryset = Entry.objects.filter(row_filter)
"""

from django.db.models import Q

from django_flex.conf import flex_settings
from django_flex.filters import OPERATORS


class FlexPermission:
    """
    Base permission class for django-flex.

    Subclass this to create custom permission logic, similar to
    Django REST Framework's permission classes.

    Example:
        class IsOwnerPermission(FlexPermission):
            def has_permission(self, request, model_name, action):
                return request.user.is_authenticated

            def get_row_filter(self, request, model_name):
                return Q(owner=request.user)

            def get_allowed_fields(self, request, model_name):
                return ['*', 'owner.name']
    """

    def has_permission(self, request, model_name, action):
        """Check if request has permission for action on model."""
        return True

    def get_row_filter(self, request, model_name):
        """Return Q object to filter rows user can access."""
        return Q()

    def get_allowed_fields(self, request, model_name):
        """Return list of allowed field patterns."""
        return ["*"]

    def get_allowed_filters(self, request, model_name):
        """Return list of allowed filter keys."""
        return []

    def get_allowed_ordering(self, request, model_name):
        """Return list of allowed order_by values."""
        return []


def field_matches_pattern(field, pattern):
    """
    Check if a field matches an allowed pattern.

    Args:
        field: Field name to check
        pattern: Pattern to match against

    Returns:
        True if field matches pattern

    Examples:
        >>> field_matches_pattern("name", "*")
        True
        >>> field_matches_pattern("author.name", "author.*")
        True
        >>> field_matches_pattern("author.name", "author.name")
        True
        >>> field_matches_pattern("author.email", "author.name")
        False
    """
    if pattern == "*":
        # Wildcard only matches base fields, not relations
        return "." not in field

    if pattern.endswith(".*"):
        # Relation wildcard: author.* matches author.name, author.email
        prefix = pattern[:-2]
        return field.startswith(prefix + ".")

    # Exact match
    return field == pattern


def fields_allowed(requested_fields, allowed_patterns):
    """
    Check if all requested fields are allowed by the patterns.

    Args:
        requested_fields: List of field names to check
        allowed_patterns: List of allowed patterns

    Returns:
        Tuple of (is_allowed, denied_field)
    """
    for field in requested_fields:
        allowed = False
        for pattern in allowed_patterns:
            if field_matches_pattern(field, pattern):
                allowed = True
                break
        if not allowed:
            return False, field
    return True, None


def get_user_role(user, permissions=None):
    """
    Get the user's role using Django's built-in auth system.

    Role resolution order:
    1. superuser -> 'superuser' (bypasses all checks)
    2. staff -> 'staff'
    3. First matching group name (lowercase)
    4. 'authenticated' if logged in
    5. None if anonymous

    Args:
        user: Django User instance
        permissions: Optional permissions config (for custom role lookup)

    Returns:
        Role name (string) or None
    """
    if user is None:
        return None

    if not user.is_authenticated:
        return None

    if user.is_superuser:
        return "superuser"

    if user.is_staff:
        return "staff"

    # Use Django's built-in groups
    if hasattr(user, "groups"):
        # Get the first group name as the role
        group = user.groups.first()
        if group:
            return group.name.lower()

    # Fallback for authenticated users with no group
    return "authenticated"


def check_permission(user, model_name, action, requested_fields, permissions=None):
    """
    Check if user has permission to perform action on model with requested fields.

    This is the main permission check function. It validates:
    1. User is authenticated
    2. User has a valid role
    3. Model is configured in permissions
    4. Role has access to the model
    5. Action is allowed for the role
    6. All requested fields are allowed

    Args:
        user: Django User instance
        model_name: Model name (lowercase)
        action: Action name (get, query, create, update, delete)
        requested_fields: List of field paths to access
        permissions: Optional permissions dict (uses settings if not provided)

    Returns:
        Tuple of (row_filter, fields) - Q object for row filtering, validated fields list

    Raises:
        PermissionError: If permission denied
    """
    if permissions is None:
        permissions = flex_settings.PERMISSIONS

    model_name = model_name.lower()

    # Check if user is authenticated
    if user is None or not user.is_authenticated:
        raise PermissionError("Authentication required")

    # Superuser bypasses all checks
    if user.is_superuser:
        return Q(), requested_fields

    # Get user's role
    role = get_user_role(user, permissions)
    if not role:
        raise PermissionError("No role could be determined for user")

    # Check if model is accessible
    if model_name not in permissions:
        raise PermissionError(f"Access denied: model '{model_name}' not configured")

    model_perms = permissions[model_name]

    # Check if role has access to this model
    if role not in model_perms:
        raise PermissionError(f"Access denied: role '{role}' cannot access '{model_name}'")

    perm = model_perms[role]

    # Check if operation is allowed
    allowed_ops = perm.get("ops", perm.get("operations", []))
    if action not in allowed_ops:
        raise PermissionError(f"Access denied: operation '{action}' not allowed on '{model_name}'")

    # Check if all requested fields are allowed
    is_allowed, denied_field = fields_allowed(requested_fields, perm["fields"])
    if not is_allowed:
        raise PermissionError(f"Access denied: field '{denied_field}' not accessible")

    # Return row filter
    row_filter_fn = perm.get("rows")
    if row_filter_fn:
        row_filter = row_filter_fn(user)
    else:
        row_filter = Q()

    return row_filter, requested_fields


def check_filter_permission(user, model_name, filter_keys, permissions=None):
    """
    Check if user can filter on the given filter keys.

    Args:
        user: Django User instance
        model_name: Model name (lowercase)
        filter_keys: List of filter keys (e.g., ["name", "status.in", "owner.name.icontains"])
        permissions: Optional permissions dict

    Raises:
        PermissionError: If filter key not allowed
    """
    if not filter_keys:
        return

    if permissions is None:
        permissions = flex_settings.PERMISSIONS

    model_name = model_name.lower()

    # Check if user is authenticated
    if user is None or not user.is_authenticated:
        raise PermissionError("Authentication required")

    # Superuser bypasses all checks
    if user.is_superuser:
        return

    # Get user's role
    role = get_user_role(user, permissions)
    if not role:
        raise PermissionError("No role could be determined for user")

    # Check if model is accessible
    if model_name not in permissions:
        raise PermissionError(f"Access denied: model '{model_name}' not configured")

    model_perms = permissions[model_name]

    # Check if role has access to this model
    if role not in model_perms:
        raise PermissionError(f"Access denied: role '{role}' cannot access '{model_name}'")

    perm = model_perms[role]

    # Get allowed filters (default to empty = no filtering allowed)
    allowed_filters = perm.get("filters", [])

    max_depth = flex_settings.MAX_RELATION_DEPTH

    for key in filter_keys:
        # Skip composite operators (or, and, not) - they're handled recursively
        if key in ("or", "and", "not"):
            continue

        # Check relation depth
        parts = key.split(".")
        # Remove operator suffix if present
        if parts[-1] in OPERATORS:
            parts = parts[:-1]
        if len(parts) > max_depth:
            raise PermissionError(f"Filter denied: '{key}' exceeds max relation depth of {max_depth}")

        # Check if filter key is allowed
        if key not in allowed_filters:
            raise PermissionError(f"Filter denied: '{key}' not allowed for filtering")


def check_order_permission(user, model_name, order_by, permissions=None):
    """
    Check if user can order by the given field.

    Args:
        user: Django User instance
        model_name: Model name (lowercase)
        order_by: Order by field (e.g., "name", "-created_at", "owner.name")
        permissions: Optional permissions dict

    Raises:
        PermissionError: If order_by not allowed
    """
    if not order_by:
        return

    if permissions is None:
        permissions = flex_settings.PERMISSIONS

    model_name = model_name.lower()

    # Check if user is authenticated
    if user is None or not user.is_authenticated:
        raise PermissionError("Authentication required")

    # Superuser bypasses all checks
    if user.is_superuser:
        return

    # Get user's role
    role = get_user_role(user, permissions)
    if not role:
        raise PermissionError("No role could be determined for user")

    # Check if model is accessible
    if model_name not in permissions:
        raise PermissionError(f"Access denied: model '{model_name}' not configured")

    model_perms = permissions[model_name]

    # Check if role has access to this model
    if role not in model_perms:
        raise PermissionError(f"Access denied: role '{role}' cannot access '{model_name}'")

    perm = model_perms[role]

    # Get allowed order_by fields (default to empty = no ordering allowed)
    allowed_order = perm.get("order_by", [])

    if order_by not in allowed_order:
        raise PermissionError(f"Order denied: '{order_by}' not allowed for ordering")
