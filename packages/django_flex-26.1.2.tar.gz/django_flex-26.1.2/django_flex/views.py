"""
Django-Flex Views

Provides Django class-based views for handling flexible queries.

Features:
- FlexQueryView for easy integration
- Automatic permission handling
- Configurable per-view settings
"""

from django.http import JsonResponse
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

import json

from django_flex.query import FlexQuery
from django_flex.response import FlexResponse


@method_decorator(csrf_exempt, name="dispatch")
class FlexQueryView(View):
    """
    Generic view for handling flexible queries.

    Subclass this view and configure the model and permissions
    to create an endpoint for flexible queries.

    Example:
        # views.py
        from django_flex.views import FlexQueryView
        from myapp.models import Entry

        class EntryQueryView(FlexQueryView):
            model = Entry

            # Optional: custom permissions
            flex_permissions = {
                'staff': {
                    'rows': lambda user: Q(),
                    'fields': ['*', 'blog.*'],
                    'filters': ['rating', 'rating.gte', 'blog.name.icontains'],
                    'order_by': ['pub_date', '-pub_date'],
                    'ops': ['get', 'query'],
                },
            }

        # urls.py
        from django.urls import path
        from myapp.views import EntryQueryView

        urlpatterns = [
            path('api/entries/', EntryQueryView.as_view(), name='entry-query'),
        ]
    """

    # Required: the model to query
    model = None

    # Optional: custom permissions (uses settings.DJANGO_FLEX.PERMISSIONS if not set)
    flex_permissions = None

    # Optional: require authentication
    require_auth = True

    # Optional: allowed actions
    allowed_actions = ["get", "query"]

    def get_model(self):
        """Get the model to query. Override for dynamic model selection."""
        return self.model

    def get_permissions(self):
        """Get permissions configuration. Override for dynamic permissions."""
        return self.flex_permissions

    def get_user(self, request):
        """Get the user for permission checking. Override for custom auth."""
        return request.user if hasattr(request, "user") else None

    def check_auth(self, request):
        """Check authentication. Override for custom auth logic."""
        if not self.require_auth:
            return True

        user = self.get_user(request)
        return user and user.is_authenticated

    def get_query_spec(self, request):
        """
        Extract query specification from request.

        Override to customize how queries are parsed from requests.
        Default: parse JSON body for POST, query params for GET.
        """
        if request.method == "POST":
            try:
                return json.loads(request.body)
            except json.JSONDecodeError:
                return None
        else:
            # Parse from query params
            spec = {}
            if "fields" in request.GET:
                spec["fields"] = request.GET["fields"]
            if "filters" in request.GET:
                try:
                    spec["filters"] = json.loads(request.GET["filters"])
                except json.JSONDecodeError:
                    spec["filters"] = {}
            if "limit" in request.GET:
                try:
                    spec["limit"] = int(request.GET["limit"])
                except ValueError:
                    pass
            if "offset" in request.GET:
                try:
                    spec["offset"] = int(request.GET["offset"])
                except ValueError:
                    pass
            if "order_by" in request.GET:
                spec["order_by"] = request.GET["order_by"]
            if "id" in request.GET:
                try:
                    spec["id"] = int(request.GET["id"])
                except ValueError:
                    spec["id"] = request.GET["id"]
            return spec

    def post(self, request, *args, **kwargs):
        """Handle POST request for queries."""
        return self.handle_query(request)

    def get(self, request, *args, **kwargs):
        """Handle GET request for queries."""
        return self.handle_query(request)

    def handle_query(self, request):
        """
        Main query handler.

        Validates authentication, parses query spec, and executes query.
        """
        # Check authentication
        if not self.check_auth(request):
            return JsonResponse(
                FlexResponse.error("PERMISSION_DENIED", "Authentication required").to_dict(),
                status=401,
            )

        # Get model
        model = self.get_model()
        if model is None:
            return JsonResponse(
                FlexResponse.error("MODEL_NOT_FOUND", "Model not configured").to_dict(),
                status=500,
            )

        # Get query spec
        query_spec = self.get_query_spec(request)
        if query_spec is None:
            return JsonResponse(
                FlexResponse.error("INVALID_FILTER", "Invalid query specification").to_dict(),
                status=400,
            )

        # Determine action
        action = "get" if "id" in query_spec else "query"
        if action not in self.allowed_actions:
            return JsonResponse(
                FlexResponse.error("PERMISSION_DENIED", f"Action '{action}' not allowed").to_dict(),
                status=403,
            )

        # Execute query
        user = self.get_user(request)
        permissions = self.get_permissions()

        query = FlexQuery(model)
        if permissions:
            query.set_permissions(self._build_permissions_dict(permissions))

        result = query.execute(query_spec, user=user, action=action)

        # Determine HTTP status
        if result.success:
            status = 200
        elif result.code == "NOT_FOUND":
            status = 404
        elif result.code == "PERMISSION_DENIED":
            status = 403
        else:
            status = 400

        return JsonResponse(result.to_dict(), status=status)

    def _build_permissions_dict(self, flex_permissions):
        """Build a permissions dict compatible with the permission system."""
        model_name = self.get_model().__name__.lower()
        return {model_name: flex_permissions}


class FlexModelView(FlexQueryView):
    """
    Model-specific view with URL-based model selection.

    Allows querying multiple models from a single endpoint based on
    the URL parameter.

    Example:
        # urls.py
        urlpatterns = [
            path('api/<str:model_name>/', FlexModelView.as_view(), name='flex-query'),
        ]

        # Requests:
        # POST /api/entry/ -> query Entry model
        # POST /api/author/ -> query Author model
    """

    # List of allowed model names (security measure)
    allowed_models = []

    def get_model(self):
        """Get model from URL."""
        model_name = self.kwargs.get("model_name", "")

        # Security check: only allow configured models
        if self.allowed_models and model_name.lower() not in [m.lower() for m in self.allowed_models]:
            return None

        from django_flex.query import get_model_by_name

        return get_model_by_name(model_name)
