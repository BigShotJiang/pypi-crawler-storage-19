"""
Django-Flex Response Utilities

Handles response building and serialization for flexible queries.

Features:
- Nested response construction from field paths
- Automatic serialization of common types
- Response code management
"""

from django_flex.conf import flex_settings


def get_field_value(obj, field_path):
    """
    Get value from object following dot notation path.

    Safely traverses nested objects and returns None if any
    part of the path is missing.

    Args:
        obj: Model instance
        field_path: Dot-notation path (e.g., "author.name")

    Returns:
        Value at the path, or None if not found

    Examples:
        >>> get_field_value(entry, "status")
        "confirmed"
        >>> get_field_value(entry, "author.name")
        "Aisha Khan"
        >>> get_field_value(entry, "author.blog.city")
        "Sydney"
    """
    parts = field_path.split(".")
    value = obj

    for part in parts:
        if value is None:
            return None
        value = getattr(value, part, None)

    return value


def serialize_value(value):
    """
    Serialize a value for JSON response.

    Handles common Django types:
    - DateField, DateTimeField -> ISO format string
    - ForeignKey -> primary key string
    - UUID -> string

    Args:
        value: Value to serialize

    Returns:
        JSON-serializable value
    """
    if value is None:
        return None

    # DateTime/Date
    if hasattr(value, "isoformat"):
        return value.isoformat()

    # UUID
    if hasattr(value, "hex"):
        return str(value)

    # Related object not in fields list - just use pk
    if hasattr(value, "pk"):
        return str(value.pk)

    return value


def build_nested_response(obj, field_paths):
    """
    Build nested dict response from object and field paths.

    Constructs a nested dictionary structure from a flat list of
    dot-notation field paths.

    Args:
        obj: Model instance
        field_paths: List of field paths (e.g., ["id", "author.name"])

    Returns:
        Nested dictionary with field values

    Example:
        >>> build_nested_response(entry, ["id", "status", "author.name", "author.email"])
        {
            "id": "1",
            "status": "confirmed",
            "author": {
                "name": "Aisha Khan",
                "email": "aisha@example.com"
            }
        }
    """
    if obj is None:
        return None

    result = {}

    for field_path in field_paths:
        parts = field_path.split(".")
        value = get_field_value(obj, field_path)
        value = serialize_value(value)

        # Build nested structure
        current = result
        for i, part in enumerate(parts[:-1]):
            if part not in current:
                current[part] = {}
            current = current[part]

        current[parts[-1]] = value

    return result


class FlexResponse:
    """
    Response builder for django-flex queries.

    Provides a consistent response format with success status,
    response code, and data.

    Example:
        >>> response = FlexResponse(code="OK", data={"id": 1, "name": "Test"})
        >>> response.to_dict()
        {"success": True, "code": "FLEX_OK", "id": 1, "name": "Test"}

        >>> response = FlexResponse.error("NOT_FOUND")
        >>> response.to_dict()
        {"success": False, "code": "FLEX_NOT_FOUND"}
    """

    def __init__(self, code="OK", warning=False, error_message=None, **data):
        """
        Initialize a FlexResponse.

        Args:
            code: Response code key (e.g., "OK", "NOT_FOUND")
            warning: Whether this is a warning response
            error_message: Optional error message for error responses
            **data: Additional data to include in response
        """
        self.code = code
        self.warning = warning
        self.error_message = error_message
        self.data = data

    @property
    def success(self):
        """Whether the response indicates success."""
        return self.code in ("OK", "OK_QUERY", "LIMIT_CLAMPED")

    @classmethod
    def ok(cls, **data):
        """Create a successful response."""
        return cls(code="OK", **data)

    @classmethod
    def ok_query(cls, results, pagination=None, **data):
        """Create a successful query response."""
        response_data = {"results": results}
        if pagination:
            response_data["pagination"] = pagination
        response_data.update(data)
        return cls(code="OK_QUERY", **response_data)

    @classmethod
    def error(cls, code, message=None):
        """Create an error response."""
        return cls(code=code, error_message=message)

    @classmethod
    def warning_response(cls, code, **data):
        """Create a warning response (success with warning flag)."""
        return cls(code=code, warning=True, **data)

    def to_dict(self):
        """Convert response to dictionary for JSON serialization."""
        codes = flex_settings.RESPONSE_CODES

        result = {
            "success": self.success,
            "code": codes.get(self.code, self.code),
        }

        if self.warning:
            result["warning"] = True

        if self.error_message:
            result["error"] = self.error_message

        result.update(self.data)

        return result

    def to_json_response(self):
        """Convert to Django JsonResponse."""
        from django.http import JsonResponse

        return JsonResponse(self.to_dict())
