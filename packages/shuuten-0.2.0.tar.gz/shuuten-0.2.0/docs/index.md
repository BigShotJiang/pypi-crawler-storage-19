![Shuuten logo](https://raw.githubusercontent.com/rnag/shuuten/main/img/logo.png){ width="160" style="display:block;margin:auto;" }

<div style="text-align:center" markdown>

#### Shuuten Signal — last-stop signals for automation failures

[![PyPI version](https://img.shields.io/pypi/v/shuuten.svg)](https://pypi.org/project/shuuten)
[![PyPI license](https://img.shields.io/pypi/l/shuuten.svg)](https://pypi.org/project/shuuten)
[![PyPI Python versions](https://img.shields.io/pypi/pyversions/shuuten.svg)](https://pypi.org/project/shuuten)
[![GitHub Actions](https://github.com/rnag/shuuten/actions/workflows/release.yml/badge.svg)](https://github.com/rnag/shuuten/actions/workflows/release.yml)
[![Documentation Status](https://github.com/rnag/shuuten/actions/workflows/gh-pages.yml/badge.svg)](https://shuuten.ritviknag.com)

</div>

<!-- include README.md content -->
{%
    include-markdown "../README.md"
    start="<!--intro-start-->"
    end="<!--intro-end-->"
%}

## Contents
[//]: # (- [Modules]&#40;modules.md&#41;)

- [Readme]("../README.md")
- [Installation](installation.md)
- [Usage](usage.md)
- [Contributing](contributing.md)
- [History](history.md)

## Indices and tables

- [Index](genindex)
- [Module Index](modindex)
- [Search](search)
