"""Init roche_datachapter_team_lib module"""
