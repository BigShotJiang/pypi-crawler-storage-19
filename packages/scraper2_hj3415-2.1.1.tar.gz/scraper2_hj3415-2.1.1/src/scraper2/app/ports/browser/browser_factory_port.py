# scraper2/app/ports/browser/browser_factory_port.py
from __future__ import annotations
from typing import AsyncIterator, Protocol
from contextlib import asynccontextmanager

from scraper2.app.ports.browser.browser_port import BrowserPort

class BrowserFactoryPort(Protocol):
    @asynccontextmanager
    async def lease(self) -> AsyncIterator[BrowserPort]: ...
    async def aclose(self) -> None: ...