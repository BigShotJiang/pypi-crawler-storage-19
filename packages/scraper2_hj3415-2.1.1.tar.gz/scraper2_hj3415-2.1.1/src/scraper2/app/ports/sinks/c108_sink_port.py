# scraper2/app/ports/sinks/c108_sink_port.py
from __future__ import annotations
from typing import Protocol
from scraper2.app.ports.sinks.base_sink_port import SinkPort
from contracts.nfs.c108 import C108DTO

class C108SinkPort(SinkPort[C108DTO], Protocol):
    """C108DTO 저장 싱크"""
    ...