# scraper2/app/ports/sinks/c106_sink_port.py
from __future__ import annotations
from typing import Protocol
from scraper2.app.ports.sinks.base_sink_port import SinkPort
from contracts.nfs.c106 import C106DTO

class C106SinkPort(SinkPort[C106DTO], Protocol):
    """C106DTO 저장 싱크"""
    ...