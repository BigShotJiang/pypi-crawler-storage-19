# scraper2/app/ports/sinks/c101_sink_port.py
from __future__ import annotations
from typing import Protocol
from scraper2.app.ports.sinks.base_sink_port import SinkPort
from contracts.nfs.c101 import C101DTO

class C101SinkPort(SinkPort[C101DTO], Protocol):
    """C101DTO 저장 싱크"""
    ...