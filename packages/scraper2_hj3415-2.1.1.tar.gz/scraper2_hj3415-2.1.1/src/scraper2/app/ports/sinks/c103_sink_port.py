# scraper2/app/ports/sinks/c103_sink_port.py
from __future__ import annotations
from typing import Protocol
from scraper2.app.ports.sinks.base_sink_port import SinkPort
from contracts.nfs.c103 import C103DTO

class C103SinkPort(SinkPort[C103DTO], Protocol):
    """C103DTO 저장 싱크"""
    ...