# scraper2/app/ports/sinks/c104_sink_port.py
from __future__ import annotations
from typing import Protocol
from scraper2.app.ports.sinks.base_sink_port import SinkPort
from contracts.nfs.c104 import C104DTO

class C104SinkPort(SinkPort[C104DTO], Protocol):
    """C104DTO 저장 싱크"""
    ...