# scraper2/app/ports/sinks/base_sink_port.py
from __future__ import annotations

from datetime import datetime
from typing import Protocol, TypeVar, Iterable, Optional

T = TypeVar("T")

class SinkPort(Protocol[T]):
    async def write(self, dto: T, *, asof: Optional[datetime] = None) -> None:
        ...

    async def write_many(self, dtos: Iterable[T], *, asof: Optional[datetime] = None) -> None:
        ...