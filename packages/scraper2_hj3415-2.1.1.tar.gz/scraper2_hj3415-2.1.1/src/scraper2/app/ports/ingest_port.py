# scraper2/app/ports/ingest_port.py
from typing import Protocol, Iterable
from datetime import datetime

class IngestPort(Protocol):
    async def execute_many(
        self,
        codes: list[str],
        *,
        sleep_sec: float = ...,
        asof: datetime | None = None,
    ) -> list[object]:
        ...