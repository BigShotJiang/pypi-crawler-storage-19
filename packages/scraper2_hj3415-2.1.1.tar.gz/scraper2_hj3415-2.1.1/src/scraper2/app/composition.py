# scraper2/app/composition.py
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Literal

from pymongo.asynchronous.database import AsyncDatabase

from scraper2.app.ports.browser.browser_factory_port import BrowserFactoryPort
from scraper2.adapters.out.playwright.browser_factory import PlaywrightBrowserFactory

from scraper2.app.usecases.fetch.fetch_c101 import FetchC101
from scraper2.app.usecases.fetch.fetch_c103 import FetchC103
from scraper2.app.usecases.fetch.fetch_c104 import FetchC104
from scraper2.app.usecases.fetch.fetch_c106 import FetchC106
from scraper2.app.usecases.fetch.fetch_c108 import FetchC108

from scraper2.app.ports.ingest_port import IngestPort
from scraper2.app.usecases.ingest.ingest_c101 import IngestC101
from scraper2.app.usecases.ingest.ingest_c103 import IngestC103
from scraper2.app.usecases.ingest.ingest_c104 import IngestC104
from scraper2.app.usecases.ingest.ingest_c106 import IngestC106
from scraper2.app.usecases.ingest.ingest_c108 import IngestC108

from scraper2.adapters.out.sinks.memory.store import InMemoryStore
from scraper2.adapters.out.sinks.memory.c101_memory_sink import MemoryC101Sink
from scraper2.adapters.out.sinks.memory.c103_memory_sink import MemoryC103Sink
from scraper2.adapters.out.sinks.memory.c104_memory_sink import MemoryC104Sink
from scraper2.adapters.out.sinks.memory.c106_memory_sink import MemoryC106Sink
from scraper2.adapters.out.sinks.memory.c108_memory_sink import MemoryC108Sink

from scraper2.adapters.out.sinks.mongo.c101_mongo_sink import MongoC101Sink
from scraper2.adapters.out.sinks.mongo.c103_mongo_sink import MongoC103Sink
from scraper2.adapters.out.sinks.mongo.c104_mongo_sink import MongoC104Sink
from scraper2.adapters.out.sinks.mongo.c106_mongo_sink import MongoC106Sink
from scraper2.adapters.out.sinks.mongo.c108_mongo_sink import MongoC108Sink

from scraper2.app.ports.sinks.c101_sink_port import C101SinkPort
from scraper2.app.ports.sinks.c103_sink_port import C103SinkPort
from scraper2.app.ports.sinks.c104_sink_port import C104SinkPort
from scraper2.app.ports.sinks.c106_sink_port import C106SinkPort
from scraper2.app.ports.sinks.c108_sink_port import C108SinkPort

from db2.mongo import Mongo

SinkKind = Literal["memory", "mongo"]


def _env_bool(key: str, default: bool) -> bool:
    v = os.getenv(key)
    return default if v is None else v.strip().lower() in {"1", "true", "yes", "y", "on"}


def _env_int(key: str, default: int) -> int:
    v = os.getenv(key)
    if v is None:
        return default
    try:
        return int(v)
    except ValueError:
        return default


def build_browser_factory() -> BrowserFactoryPort:
    return PlaywrightBrowserFactory(
        headless=_env_bool("SCRAPER_HEADLESS", True),
        timeout_ms=_env_int("SCRAPER_TIMEOUT_MS", 20_000),
        max_concurrency=_env_int("SCRAPER_MAX_CONCURRENCY", 2),
    )


# -------------------------
# Bundles
# -------------------------

@dataclass(frozen=True)
class FetchUsecases:
    c101: FetchC101
    c103: FetchC103
    c104: FetchC104
    c106: FetchC106
    c108: FetchC108


@dataclass(frozen=True)
class Sinks:
    c101: C101SinkPort
    c103: C103SinkPort
    c104: C104SinkPort
    c106: C106SinkPort
    c108: C108SinkPort


@dataclass(frozen=True)
class IngestUsecases:
    c101: IngestPort
    c103: IngestPort
    c104: IngestPort
    c106: IngestPort
    c108: IngestPort


@dataclass(frozen=True)
class Usecases:
    fetch: FetchUsecases
    ingest: IngestUsecases
    sinks: Sinks
    store: InMemoryStore | None = None      # ✅ memory일 때만
    mongo: Mongo | None = None              # ✅ mongo일 때만
    db: AsyncDatabase | None = None         # ✅ mongo일 때만


# -------------------------
# builders
# -------------------------

def build_fetch_usecases(*, factory: BrowserFactoryPort) -> FetchUsecases:
    return FetchUsecases(
        c101=FetchC101(factory=factory),
        c103=FetchC103(factory=factory),
        c104=FetchC104(factory=factory),
        c106=FetchC106(factory=factory),
        c108=FetchC108(factory=factory),
    )


@dataclass(frozen=True)
class MemoryBundle:
    store: InMemoryStore
    sinks: Sinks


def build_memory_bundle() -> MemoryBundle:
    store = InMemoryStore()
    sinks = Sinks(
        c101=MemoryC101Sink(store),
        c103=MemoryC103Sink(store),
        c104=MemoryC104Sink(store),
        c106=MemoryC106Sink(store),
        c108=MemoryC108Sink(store),
    )
    return MemoryBundle(store=store, sinks=sinks)

# ---- mongo bundle ----

@dataclass(frozen=True)
class MongoBundle:
    mongo: Mongo
    db: AsyncDatabase
    sinks: Sinks


def build_mongo_bundle() -> MongoBundle:
    mongo = Mongo()        # settings는 db2가 env로 읽음 (DB2_MONGO_URI 등)
    db = mongo.get_db()
    sinks = Sinks(
        c101=MongoC101Sink(db),
        c103=MongoC103Sink(db),
        c104=MongoC104Sink(db),
        c106=MongoC106Sink(db),
        c108=MongoC108Sink(db),
    )
    return MongoBundle(mongo=mongo, db=db, sinks=sinks)


def build_ingest_usecases(*, fetch: FetchUsecases, sinks: Sinks) -> IngestUsecases:
    return IngestUsecases(
        c101=IngestC101(fetch=fetch.c101, sink=sinks.c101),
        c103=IngestC103(fetch=fetch.c103, sink=sinks.c103),
        c104=IngestC104(fetch=fetch.c104, sink=sinks.c104),
        c106=IngestC106(fetch=fetch.c106, sink=sinks.c106),
        c108=IngestC108(fetch=fetch.c108, sink=sinks.c108),
    )


def build_usecases(
    *,
    factory: BrowserFactoryPort | None = None,
    sink_kind: SinkKind = "memory",
) -> Usecases:
    factory = factory or build_browser_factory()
    fetch = build_fetch_usecases(factory=factory)

    if sink_kind == "memory":
        bundle = build_memory_bundle()
        ingest = build_ingest_usecases(fetch=fetch, sinks=bundle.sinks)
        return Usecases(fetch=fetch, ingest=ingest, sinks=bundle.sinks, store=bundle.store)

    if sink_kind == "mongo":
        bundle = build_mongo_bundle()
        ingest = build_ingest_usecases(fetch=fetch, sinks=bundle.sinks)
        return Usecases(fetch=fetch, ingest=ingest, sinks=bundle.sinks, mongo=bundle.mongo, db=bundle.db)

    raise ValueError(f"Unknown sink_kind: {sink_kind}")