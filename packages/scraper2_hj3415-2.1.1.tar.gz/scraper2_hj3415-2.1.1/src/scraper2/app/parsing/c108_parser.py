# scraper2/app/parsing/c108_parser.py
from __future__ import annotations

from typing import Any

import pandas as pd
from scraper2.app.ports.browser.browser_port import BrowserPort


def extract_bullets(text: str | None) -> list[str]:
    if not text:
        return []
    return [
        line.replace("▶", "").strip()
        for line in text.splitlines()
        if line.strip().startswith("▶")
    ]


async def parse_c108_to_dicts(browser: BrowserPort) -> list[dict[str, Any]]:
    title = await browser.title()
    url = await browser.current_url()

    if "접속장애" in title:
        print(
            "[C108][ACCESS_ERROR] "
            f"title={title!r} url={url}"
        )
        return []

    # table → records (adapter가 처리)
    try:
        records = await browser.table_records("#tableCmpDetail", header=0)
    except Exception as e:
        print("table_records failed:", type(e).__name__, e)
        return []

    # 날짜 변환(파서에서 처리)
    # records의 key가 '일자'일 가능성이 있으니 통일
    for r in records:
        if "일자" in r and "날짜" not in r:
            r["날짜"] = r.pop("일자")

        # "%y/%m/%d" -> "%Y.%m.%d"
        if r.get("날짜"):
            dt = pd.to_datetime(r["날짜"], format="%y/%m/%d", errors="coerce")
            r["날짜"] = None if pd.isna(dt) else dt.strftime("%Y.%m.%d")

    # 내용 추출
    contents: list[list[str]] = []
    row_count = len(records)

    for i in range(row_count):
        try:
            await browser.click(f"#a{i}")
            await browser.wait(f"#c{i} > div > div.comment-body")
            text = await browser.inner_text(f"#c{i} > div > div.comment-body")
            contents.append(extract_bullets(text))
        except Exception:
            contents.append([])

    # records에 내용/코드 주입
    for r, content in zip(records, contents, strict=False):
        r["내용"] = content
    return records