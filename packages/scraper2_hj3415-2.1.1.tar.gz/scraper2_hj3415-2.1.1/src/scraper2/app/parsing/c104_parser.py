# scraper2/app/parsing/c104_parser.py
from __future__ import annotations

import asyncio
from io import StringIO
from typing import Any

import pandas as pd

from scraper2.app.ports.browser.browser_port import BrowserPort
from scraper2.app.parsing._normalize import normalize_c1034_df


# ---- constants ----

TABLE_SELECTOR = 'xpath=//table[@class="gHead01 all-width data-list"]'

BTN_SETS: dict[str, list[tuple[str, str]]] = {
    "수익성y": [
        ("수익성", 'xpath=//*[ @id="val_tab1"]'),
        ("연간", 'xpath=//*[@id="frqTyp0"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "성장성y": [
        ("성장성", 'xpath=//*[ @id="val_tab2"]'),
        ("연간", 'xpath=//*[@id="frqTyp0"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "안정성y": [
        ("안정성", 'xpath=//*[ @id="val_tab3"]'),
        ("연간", 'xpath=//*[@id="frqTyp0"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "활동성y": [
        ("활동성", 'xpath=//*[ @id="val_tab4"]'),
        ("연간", 'xpath=//*[@id="frqTyp0"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "가치분석y": [
        ("가치분석연간", 'xpath=//*[@id="frqTyp0_2"]'),
        ("가치분석검색", 'xpath=//*[@id="hfinGubun2"]'),
    ],
    "수익성q": [
        ("수익성", 'xpath=//*[ @id="val_tab1"]'),
        ("분기", 'xpath=//*[@id="frqTyp1"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "성장성q": [
        ("성장성", 'xpath=//*[ @id="val_tab2"]'),
        ("분기", 'xpath=//*[@id="frqTyp1"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "안정성q": [
        ("안정성", 'xpath=//*[ @id="val_tab3"]'),
        ("분기", 'xpath=//*[@id="frqTyp1"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "활동성q": [
        ("활동성", 'xpath=//*[ @id="val_tab4"]'),
        ("분기", 'xpath=//*[@id="frqTyp1"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "가치분석q": [
        ("가치분석분기", 'xpath=//*[@id="frqTyp1_2"]'),
        ("가치분석검색", 'xpath=//*[@id="hfinGubun2"]'),
    ],
}


# ---- small helpers ----

async def _click_steps(
    browser: BrowserPort,
    steps: list[tuple[str, str]],
    *,
    jitter_sec: float = 0.6,
) -> None:
    """
    (goto 없음) 현재 페이지에서 탭/라디오/검색 버튼 클릭만 수행.
    """
    for _name, selector in steps:
        await browser.wait(selector)
        await browser.click(selector)
        await asyncio.sleep(0.2 + (jitter_sec * 0.5))


def _html_table_to_df(html: str) -> pd.DataFrame:
    dfs = pd.read_html(StringIO(html), header=0)
    if not dfs:
        raise ValueError("pd.read_html() 테이블 파싱 실패")
    return dfs[0]


async def _table_outer_html(browser: BrowserPort, *, is_value_analysis: bool) -> str:
    """
    c104 원본 로직 유지:
      - 가치분석*: 두 번째 테이블(nth=1)
      - 그 외: 첫 번째 테이블(nth=0)
    """
    idx = 1 if is_value_analysis else 0
    return await browser.outer_html_nth(TABLE_SELECTOR, idx)


def df_to_c104_records(df: pd.DataFrame) -> list[dict[str, Any]]:
    """
    C104 테이블 DataFrame -> records(list[dict])
    - NaN -> None
    - (원하면 normalize_c104_df(df) 추가)
    """
    df = normalize_c1034_df(df)
    if df is None or df.empty:
        return []

    df = df.where(pd.notnull(df), None)

    return df.to_dict(orient="records")


# ---- public parser ----

async def parse_c104_to_dict(browser: BrowserPort) -> dict[str, list[dict[str, Any]]]:
    """
    C104 파서: dict만 반환
    {
      "수익성y": [ {...}, ... ],
      "가치분석q": [ {...}, ... ],
      ...
    }
    """
    out: dict[str, list[dict[str, Any]]] = {}

    for key, steps in BTN_SETS.items():
        await _click_steps(browser, steps)
        await browser.wait(TABLE_SELECTOR)

        try:
            html = await _table_outer_html(browser, is_value_analysis=key.startswith("가치분석"))
            df = _html_table_to_df(html)
            out[key] = df_to_c104_records(df)
        except Exception:
            out[key] = []

    return out