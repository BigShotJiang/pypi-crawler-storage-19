from __future__ import annotations
import re
from typing import Iterable


_EMPTY_VALUES = {"", "-", "N/A", "NA", "null", "None"}


def normalize(s: str | None) -> str:
    if s is None:
        return ""
    return s.strip()


def _is_empty(s: str) -> bool:
    return s in _EMPTY_VALUES


def to_int(s: str | None) -> int | None:
    """
    C101 파서용 정수 변환기

    처리 규칙:
    - None / '' / '-' / 'N/A' → None
    - ',', '주', '원', '주식' 제거
    - '1,234' → 1234
    """
    s = normalize(s)
    if _is_empty(s):
        return None

    for ch in (",", "원", "주", "주식"):
        s = s.replace(ch, "")

    try:
        return int(s)
    except ValueError:
        return None


def to_float(s: str | None) -> float | None:
    """
    C101 파서용 실수 변환기

    처리 규칙:
    - None / '' / '-' / 'N/A' → None
    - ',', '%', '원' 제거
    - '12.34%' → 12.34
    """
    s = normalize(s)
    if _is_empty(s):
        return None

    for ch in (",", "%", "원"):
        s = s.replace(ch, "")

    try:
        return float(s)
    except ValueError:
        return None


def parse_won(text: str) -> int:
    """
    한국 화폐 표현 문자열을 숫자로 변환 (조원, 억원, 만원, 원, 억 등 처리)
    """
    units = {
        "조원": 1_000_000_000_000,
        "억원": 100_000_000,
        "억":   100_000_000,
        "만원": 10_000,
        "원": 1,
    }

    text = text.replace(",", "").strip()
    match = re.match(r"([-+]?[0-9]*\.?[0-9]+)([가-힣]+)", text)

    if not match:
        raise ValueError(f"형식이 잘못된 금액 문자열: {text}")

    number, unit = match.groups()
    if unit not in units:
        raise ValueError(f"알 수 없는 단위: {unit}")

    return int(float(number) * units[unit])
