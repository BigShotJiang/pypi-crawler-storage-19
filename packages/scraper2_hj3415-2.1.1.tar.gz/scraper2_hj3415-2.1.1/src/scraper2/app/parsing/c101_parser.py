# scraper2/app/parsing/c101_parser.py
from __future__ import annotations

from scraper2.app.parsing._converters import to_int, to_float, normalize, parse_won
from scraper2.app.ports.browser.browser_port import BrowserPort
from typing import Any


class C101ParseError(RuntimeError):
    pass


def _after_colon(s: str) -> str:
    # "업종: XXX" 같은 케이스
    parts = s.split(":")
    return parts[1].strip() if len(parts) > 1 else s.strip()


async def parse_c101_to_dict(browser: BrowserPort) -> dict[str, Any] | None:
    """
    - BrowserPort만 사용
    - dict만 반환
    - 실패 시 None (기존 동작 유지)
    """

    # 날짜 파싱: 텍스트 검색 기반
    raw_date_str = await browser.text_first_by_text("[기준:")
    if not raw_date_str:
        return None
    날짜 = raw_date_str.replace("[기준:", "").replace("]", "").strip()

    # 1) 재무정보 (1st table)
    # 여기선 "tbody 존재"만 기다리면 됨
    await browser.wait("#pArea > div.wrapper-table > div > table > tbody")

    종목명 = normalize(await browser.text(
        "#pArea > div.wrapper-table > div > table > tbody "
        "tr:nth-child(1) > td > dl > dt:nth-child(1) > span"
    ))
    코드 = normalize(await browser.text(
        "#pArea > div.wrapper-table > div > table > tbody "
        "tr:nth-child(1) > td > dl > dt:nth-child(1) > b"
    ))
    업종_raw = await browser.text(
        "#pArea > div.wrapper-table > div > table > tbody "
        "tr:nth-child(1) > td > dl > dt:nth-child(4)"
    )
    업종 = _after_colon(업종_raw)

    eps = to_int(await browser.text(
        "#pArea > div.wrapper-table > div > table > tbody "
        "tr:nth-child(3) > td > dl > dt:nth-child(1) > b"
    ))
    bps = to_int(await browser.text(
        "#pArea > div.wrapper-table > div > table > tbody "
        "tr:nth-child(3) > td > dl > dt:nth-child(2) > b"
    ))
    per = to_float(await browser.text(
        "#pArea > div.wrapper-table > div > table > tbody "
        "tr:nth-child(3) > td > dl > dt:nth-child(3) > b"
    ))
    업종per = to_float(await browser.text(
        "#pArea > div.wrapper-table > div > table > tbody "
        "tr:nth-child(3) > td > dl > dt:nth-child(4) > b"
    ))
    pbr = to_float(await browser.text(
        "#pArea > div.wrapper-table > div > table > tbody "
        "tr:nth-child(3) > td > dl > dt:nth-child(5) > b"
    ))
    배당수익률 = to_float(await browser.text(
        "#pArea > div.wrapper-table > div > table > tbody "
        "tr:nth-child(3) > td > dl > dt:nth-child(6) > b"
    ))

    # 2) 주가 정보 (2nd table)
    await browser.wait("#cTB11 > tbody")

    주가 = to_int(await browser.text("#cTB11 > tbody tr:nth-child(1) > td > strong"))

    전일대비_raw = await browser.text("#cTB11 > tbody tr:nth-child(1) > td > span:nth-child(2)")
    전일대비 = to_int(전일대비_raw.replace("원", ""))

    수익률_raw = await browser.text("#cTB11 > tbody tr:nth-child(1) > td > span:nth-child(3)")
    수익률 = to_float(수익률_raw.replace("%", ""))

    최고최저52 = await browser.text("#cTB11 > tbody tr:nth-child(2) > td")
    최고52, 최저52 = (to_int(x.strip().replace("원", "")) for x in 최고최저52.split("/"))

    거래량거래대금 = await browser.text("#cTB11 > tbody tr:nth-child(4) > td")
    거래량_str, 거래대금_str = (x.strip() for x in 거래량거래대금.split("/"))
    거래량 = to_int(거래량_str.replace("주", ""))
    거래대금 = parse_won(거래대금_str)

    시가총액 = parse_won(await browser.text("#cTB11 > tbody tr:nth-child(5) > td"))
    베타52주 = to_float(await browser.text("#cTB11 > tbody tr:nth-child(6) > td"))

    발행주식유동비율 = await browser.text("#cTB11 > tbody tr:nth-child(7) > td")
    발행주식_str, 유동비율_str = (x.strip() for x in 발행주식유동비율.split("/"))
    발행주식 = to_int(발행주식_str.replace("주", ""))
    유동비율 = to_float(유동비율_str.replace("%", ""))

    외국인지분율 = to_float((await browser.text("#cTB11 > tbody tr:nth-child(8) > td")).replace("%", ""))

    수익률1M3M6M1Y = await browser.text("#cTB11 > tbody tr:nth-child(9) > td")
    수익률1M, 수익률3M, 수익률6M, 수익률1Y = (
        to_float(x.strip().replace("%", "")) for x in 수익률1M3M6M1Y.split("/")
    )

    # 3) 개요
    # ul 아래 li들을 전부 읽어서 합치기
    await browser.wait("#wrapper > div:nth-child(6) > div.cmp_comment > ul")
    li_texts = await browser.texts("#wrapper > div:nth-child(6) > div.cmp_comment > ul li")
    개요 = "".join(t.strip() for t in li_texts if t and t.strip())

    return {
        "종목명": 종목명,
        "코드": 코드,
        "날짜": 날짜,
        "업종": 업종,
        "eps": eps,
        "bps": bps,
        "per": per,
        "업종per": 업종per,
        "pbr": pbr,
        "배당수익률": 배당수익률,
        "주가": 주가,
        "전일대비": 전일대비,
        "수익률": 수익률,
        "최고52": 최고52,
        "최저52": 최저52,
        "거래량": 거래량,
        "거래대금": 거래대금,
        "시가총액": 시가총액,
        "베타52주": 베타52주,
        "발행주식": 발행주식,
        "유동비율": 유동비율,
        "외국인지분율": 외국인지분율,
        "수익률1M": 수익률1M,
        "수익률3M": 수익률3M,
        "수익률6M": 수익률6M,
        "수익률1Y": 수익률1Y,
        "개요": 개요,
    }