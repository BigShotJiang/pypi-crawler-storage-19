# scraper2/app/parsing/_normalize.py
from __future__ import annotations

import re
from collections import Counter
from typing import Any

import numpy as np
import pandas as pd


# -----------------------------
# 1) 항목(행의 "항목" 값) 정규화
# -----------------------------
_IFRS_PATTERN = re.compile(r"\(IFRS[^)]*\)")
_ETC_PAREN_PATTERN = re.compile(r"\((E|YoY|QoQ)[^)]*\)")
_BRACKET_PATTERN = re.compile(r"\[[^\]]*\]")  # [구K-IFRS] 등
_EXTRA_WORDS_PATTERN = re.compile(r"(펼치기|연간컨센서스보기|연간컨센서스닫기)")
_ALL_PAREN_PATTERN = re.compile(r"\([^)]*\)")  # ★ 모든 괄호 제거

def normalize_c1034_item(text: str | None) -> str:
    """
    C103 항목명(행 값) 정규화
    - 펼치기/컨센서스 제거
    - 모든 괄호 내용 제거 (발표기준, 연결, 개별 등 포함)
    - [구K-IFRS] 제거
    - '*' 제거
    - 공백 정리
    """
    if not text:
        return ""

    s = str(text)

    # 1) 불필요한 키워드
    s = _EXTRA_WORDS_PATTERN.sub("", s)

    # 2) 대괄호 제거
    s = _BRACKET_PATTERN.sub("", s)

    # 3) 모든 괄호 제거 (중요)
    s = _ALL_PAREN_PATTERN.sub("", s)

    # 4) 별표 제거
    s = s.replace("*", "")

    # 5) 공백 정리
    s = re.sub(r"\s+", " ", s).strip()

    return s


# -----------------------------
# 2) 컬럼명 정규화
# -----------------------------
_COL_PAREN_PATTERN = re.compile(r"\((IFRS[^)]*|E|YoY|QoQ)[^)]*\)")
_COL_EXTRA_WORDS = re.compile(r"(연간컨센서스보기|연간컨센서스닫기)")
_COL_DOTNUM = re.compile(r"\.\d+$")  # pandas 중복 컬럼 suffix 제거용 (.1, .2 ...)
_COL_MULTI_SPACE = re.compile(r"\s+")

def normalize_c1034_col(col: str | None) -> str:
    """
    C103 컬럼명 정규화
    예)
      "2024/12 (IFRS연결)  연간컨센서스보기" -> "2024/12"
      "2025/12(E) (IFRS연결)  연간컨센서스닫기" -> "2025/12"
      "전년대비 (YoY)" -> "전년대비"
      "전년대비 (YoY).1" -> "전년대비"  (중복은 후처리에서 _2/_3로 자동 분리)
    """
    if col is None:
        return ""

    s = str(col)

    # 1) pandas가 붙인 .1 같은 suffix 제거 (정규화 충돌은 후단에서 처리)
    s = _COL_DOTNUM.sub("", s)

    # 2) 컨센서스 문구 제거
    s = _COL_EXTRA_WORDS.sub("", s)

    # 3) 괄호 주석 제거: (IFRS...), (E), (YoY), (QoQ)
    s = _COL_PAREN_PATTERN.sub("", s)

    # 4) 공백 정리
    s = _COL_MULTI_SPACE.sub(" ", s).strip()

    return s


def _dedupe_columns(cols: list[str]) -> list[str]:
    """
    정규화 후 중복 컬럼명이 생기면 자동으로 _2, _3 ... 붙여서 유니크하게 만든다.
    예) ["전년대비", "전년대비"] -> ["전년대비", "전년대비_2"]
    """
    seen: Counter[str] = Counter()
    out: list[str] = []
    for c in cols:
        c = c or ""
        seen[c] += 1
        if seen[c] == 1:
            out.append(c)
        else:
            out.append(f"{c}_{seen[c]}")
    return out


# -----------------------------
# 3) DataFrame 전체 정규화 + records 변환
# -----------------------------
def normalize_c1034_df(df: pd.DataFrame) -> pd.DataFrame:
    """
    - 컬럼명 전체 정규화
    - '항목' 값 정규화
    - NaN -> None
    - 중복 컬럼명 자동 분리(_2/_3)
    """
    if df is None or df.empty:
        return df

    df = df.copy()

    # 컬럼명 정규화 + 중복 방지
    norm_cols = [normalize_c1034_col(c) for c in df.columns.astype(str).tolist()]
    df.columns = _dedupe_columns(norm_cols)

    # 항목 값 정규화
    if "항목" in df.columns:
        df["항목"] = df["항목"].map(normalize_c1034_item)

    # NaN -> None
    df = df.replace({np.nan: None})
    return df


