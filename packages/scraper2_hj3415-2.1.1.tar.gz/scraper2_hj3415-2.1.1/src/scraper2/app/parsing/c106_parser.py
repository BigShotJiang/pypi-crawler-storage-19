# scraper2/app/parsing/c106_parser.py
from __future__ import annotations

from io import StringIO
from typing import Dict

import numpy as np
import pandas as pd

from scraper2.app.ports.browser.browser_port import BrowserPort


# ---------- pure helpers (sync) ----------

def df_to_metrics(df: pd.DataFrame) -> dict[str, dict[str, float | None]]:
    """
    DataFrame ->
      { "<항목2>": { "<회사명>": float|None, ... }, ... }
    """
    out: dict[str, dict[str, float | None]] = {}
    if df is None or df.empty:
        return out

    rows = df.replace({np.nan: None}).to_dict(orient="records")
    for r in rows:
        metric = r.get("항목2")
        if not metric:
            continue

        bucket = out.setdefault(str(metric).strip(), {})
        for k, v in r.items():
            if k in ("항목", "항목2"):
                continue
            bucket[str(k)] = None if v is None else float(v)

    return out


def df_from_comparison_html(html: str, company_names: list[str]) -> pd.DataFrame:
    """
    #cTB611 테이블 HTML -> 정제된 DataFrame
    """
    df = pd.read_html(StringIO(html), header=None)[0]

    # 첫 번째 열은 '항목', 두 번째 열은 '항목2', 나머지는 회사명
    df.columns = ["항목", "항목2"] + company_names

    # 대분류(항목) NaN은 이전 값으로 채움
    df["항목"] = df["항목"].ffill()

    # 첫 두 줄만 '주가데이터' 삽입(기존 로직 유지)
    for i in range(min(2, len(df))):
        row = df.loc[i].tolist()
        new_row = ["주가데이터"] + row
        df.loc[i] = new_row[: len(df.columns)]

    # 항목2 없는 행 제거
    df = df[df["항목2"].notna()].reset_index(drop=True)

    # 특정 항목은 대분류 수동 지정
    df.loc[df["항목2"].isin(["투자의견", "목표주가(원)"]), "항목"] = "기타지표"

    # 필요없는 행 제거
    df = df[df["항목2"] != "재무연월"].reset_index(drop=True)

    # 숫자 정리 (회사 컬럼만)
    for col in df.columns[2:]:
        df[col] = df[col].replace("-", "0")
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # 문자열 정리
    df["항목"] = df["항목"].astype(str).str.replace("펼치기", "").str.strip()
    df["항목2"] = df["항목2"].astype(str).str.strip()

    return df


# ---------- parsers (async, BrowserPort only) ----------

async def parse_c106_header(browser: BrowserPort) -> list[str]:
    """
    현재 페이지에서 '기업간비교자료' 헤더(회사명들)만 뽑는다.
    (goto/sleep 없음)
    """
    await browser.wait("#cTB611_h")

    selector = (
        'xpath=//caption[contains(text(), "기업간비교자료")]/following-sibling::thead//th[not(@colspan)]'
    )
    th_texts = await browser.all_texts(selector)

    names: list[str] = []
    for t in th_texts:
        name = t.strip().split("\n")[0]
        if name:
            names.append(name)
    return names


async def parse_c106_table_to_metrics(
    browser: BrowserPort,
    company_names: list[str],
) -> dict[str, dict[str, float | None]]:
    """
    현재 페이지에서 #cTB611 테이블을 읽어 metrics dict로 변환한다.
    """
    await browser.wait("#cTB611")
    html = await browser.outer_html("#cTB611")

    df = df_from_comparison_html(html, company_names)
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"c106 df invalid: type={type(df)}")
    return df_to_metrics(df)


METRIC_NAME_MAP = {
    "전일종가(원)": "전일종가",
    "시가총액(억원)": "시가총액",

    "자산총계(억원)": "자산총계",
    "부채총계(억원)": "부채총계",

    "매출액(억원)": "매출액",
    "영업이익(억원)": "영업이익",
    "당기순이익(억원)": "당기순이익",
    "당기순이익(지배)(억원)": "당기순이익_지배",

    "영업이익률(%)": "영업이익률",
    "순이익률(%)": "순이익률",
    "ROE(%)": "ROE",
    "부채비율(%)": "부채비율",

    "PER": "PER",
    "PBR": "PBR",

    "투자의견": "투자의견",
    "목표주가(원)": "목표주가",
}

def normalize_c106_metrics(
    raw: Dict[str, Dict[str, float | None]],
) -> Dict[str, Dict[str, float | None]]:
    out: Dict[str, Dict[str, float | None]] = {}

    for raw_name, company_map in raw.items():
        field = METRIC_NAME_MAP.get(raw_name)
        if not field:
            # 모르는 항목은 버리거나 로그만 남김
            continue

        out[field] = company_map

    return out