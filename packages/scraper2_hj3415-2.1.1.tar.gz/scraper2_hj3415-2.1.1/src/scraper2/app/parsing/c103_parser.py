# scraper2/app/parsing/c103_parser.py
from __future__ import annotations

import asyncio
from io import StringIO
from typing import Any

import pandas as pd

from scraper2.app.ports.browser.browser_port import BrowserPort
from scraper2.app.parsing._normalize import normalize_c1034_df

# ---- constants ----

TABLE_XPATH = "xpath=//div[@id='wrapper']//div//table"   # 기존 selector 의도 유지
TABLE_INDEX = 2  # 너 코드의 nth(2)


BTN_SETS: dict[str, list[tuple[str, str]]] = {
    "손익계산서y": [
        ("손익계산서", 'xpath=//*[@id="rpt_tab1"]'),
        ("연간", 'xpath=//*[@id="frqTyp0"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "재무상태표y": [
        ("재무상태표", 'xpath=//*[@id="rpt_tab2"]'),
        ("연간", 'xpath=//*[@id="frqTyp0"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "현금흐름표y": [
        ("현금흐름표", 'xpath=//*[@id="rpt_tab3"]'),
        ("연간", 'xpath=//*[@id="frqTyp0"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "손익계산서q": [
        ("손익계산서", 'xpath=//*[@id="rpt_tab1"]'),
        ("분기", 'xpath=//*[@id="frqTyp1"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "재무상태표q": [
        ("재무상태표", 'xpath=//*[@id="rpt_tab2"]'),
        ("분기", 'xpath=//*[@id="frqTyp1"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "현금흐름표q": [
        ("현금흐름표", 'xpath=//*[@id="rpt_tab3"]'),
        ("분기", 'xpath=//*[@id="frqTyp1"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
}


# ---- small helpers ----

async def _click_steps(
    browser: BrowserPort,
    steps: list[tuple[str, str]],
    *,
    jitter_sec: float = 0.6,
) -> None:
    """
    (goto 없음) 현재 페이지에서 탭/라디오/검색 버튼 클릭만 수행.
    """
    for _name, selector in steps:
        await browser.wait(selector)
        await browser.click(selector)
        # 서버/클라이언트 부담 줄이기: 작은 지터
        await asyncio.sleep(0.2 + (jitter_sec * 0.5))


def _html_table_to_df(html: str) -> pd.DataFrame:
    """
    table outerHTML -> DataFrame
    """
    dfs = pd.read_html(StringIO(html), header=0)
    if not dfs:
        raise ValueError("pd.read_html() 테이블 파싱 실패")
    return dfs[0]


async def _nth_table_outer_html(browser: BrowserPort, nth: int) -> str:
    return await browser.outer_html_nth(TABLE_XPATH, nth)

def df_to_c103_records(df: pd.DataFrame) -> list[dict[str, Any]]:
    """
    C103 테이블 DataFrame -> 정규화된 records(list[dict])
    - 항목이 비면 제거
    """
    df = normalize_c1034_df(df)
    if df is None or df.empty:
        return []

    records: list[dict[str, Any]] = []
    for r in df.to_dict(orient="records"):
        item = r.get("항목")
        if not item:
            continue
        records.append(r)
    return records

# ---- public parser ----

async def parse_c103_to_dict(browser: BrowserPort) -> dict[str, list[dict[str, Any]]]:
    """
    C103 파서: dict만 반환
    {
      "손익계산서y": [ {...}, ... ],
      "손익계산서q": [ {...}, ... ],
      ...
    }
    """
    out: dict[str, list[dict[str, Any]]] = {}

    for key, steps in BTN_SETS.items():
        # 클릭 → 테이블 로딩 → nth table outerHTML → df → records
        await _click_steps(browser, steps)
        await browser.wait(TABLE_XPATH)

        try:
            html = await _nth_table_outer_html(browser, TABLE_INDEX)
            df = _html_table_to_df(html)
            out[key] = df_to_c103_records(df)
        except Exception:
            out[key] = []  # 실패는 빈 리스트

    return out


