# scraper2/app/usecases/fetch/fetch_c103.py
from __future__ import annotations

import math
import asyncio
import random
from typing import Iterable, Any
from contracts.nfs.c103 import C103DTO, ItemsMap
from scraper2.app.ports.browser.browser_factory_port import BrowserFactoryPort
from scraper2.app.parsing.c103_parser import parse_c103_to_dict
from collections import defaultdict


BLOCK_KEYS = (
    "손익계산서y", "손익계산서q",
    "재무상태표y", "재무상태표q",
    "현금흐름표y", "현금흐름표q",
)

def _clean(v: Any) -> Any:
    if isinstance(v, float) and math.isnan(v):
        return None
    return v

def _is_all_none(row: dict[str, Any]) -> bool:
    # row는 '항목'을 제외한 값들만 들어있다고 가정
    return all(v is None for v in row.values())


def records_to_items_map(records: list[dict[str, Any]]) -> ItemsMap:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)

    # 1) 항목별로 row를 먼저 모은다
    for r in records:
        item = r.get("항목")
        if not item:
            continue
        item = str(item).strip()

        row = {k: _clean(v) for k, v in r.items() if k != "항목"}
        grouped[item].append(row)

    # 2) 규칙 적용해서 out 구성
    out: ItemsMap = {}

    for item, rows in grouped.items():
        if len(rows) == 1:
            # ✅ 규칙 1: 중복이 아니면 전부 None이어도 추가
            out[item] = rows[0]
            continue

        # ✅ 규칙 2: 중복이면 all-None row는 제거
        kept = [row for row in rows if not _is_all_none(row)]
        if not kept:
            continue  # 중복 전부 None이면 그룹 자체 제거

        # 남은 것들만 suffix 부여 (첫 번째는 suffix 없음)
        for idx, row in enumerate(kept, start=1):
            key = item if idx == 1 else f"{item}_{idx}"
            out[key] = row

    return out


class FetchC103:
    def __init__(self, factory: BrowserFactoryPort):
        self.factory = factory

    async def _fetch_one(self, code: str, *, sleep_sec: float) -> C103DTO | None:
        async with self.factory.lease() as browser:
            url = f"https://navercomp.wisereport.co.kr/v2/company/c1030001.aspx?cn=&cmp_cd={code}"
            await browser.goto(url, timeout_ms=10_000)

            jitter_sec = 1.0
            if sleep_sec > 0:
                delay = sleep_sec + random.uniform(0, jitter_sec)
                await asyncio.sleep(delay)

            parsed = await parse_c103_to_dict(browser)

            if not parsed or all(not parsed.get(k) for k in BLOCK_KEYS):
                return None

            data: dict[str, Any] = {"코드": code}
            for k in BLOCK_KEYS:
                data[k] = records_to_items_map(parsed.get(k, []))

            return C103DTO(**data)

    async def execute(self, code: str, *, sleep_sec: float = 2.0) -> C103DTO | None:
        return await self._fetch_one(code, sleep_sec=sleep_sec)

    async def execute_many(
        self,
        codes: Iterable[str],
        *,
        sleep_sec: float = 2.0,
    ) -> list[C103DTO]:
        results = await asyncio.gather(
            *(self._fetch_one(c, sleep_sec=sleep_sec) for c in codes),
            return_exceptions=False,
        )
        return [r for r in results if r is not None]