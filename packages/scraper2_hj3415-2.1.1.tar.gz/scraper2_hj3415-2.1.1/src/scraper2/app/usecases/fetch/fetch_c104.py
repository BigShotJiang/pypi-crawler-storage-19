# scraper2/app/usecases/fetch/fetch_c104.py
from __future__ import annotations

import math
import asyncio
import random
from typing import Iterable, Any
from collections import Counter

from contracts.nfs.c104 import C104DTO, ItemsMap
from scraper2.app.ports.browser.browser_factory_port import BrowserFactoryPort
from scraper2.app.parsing.c104_parser import parse_c104_to_dict


BLOCK_KEYS = (
    "수익성y", "성장성y", "안정성y", "활동성y", "가치분석y",
    "수익성q", "성장성q", "안정성q", "활동성q", "가치분석q",
)

def _clean(v: Any) -> Any:
    if isinstance(v, float) and math.isnan(v):
        return None
    return v

def records_to_items_map(records: list[dict[str, Any]]) -> ItemsMap:
    """
    records(list[dict]) -> ItemsMap(dict[item -> row])
    - item(항목) 중복이면 _2, _3...
    """
    out: ItemsMap = {}
    seen: Counter[str] = Counter()

    for r in records:
        item = r.get("항목")
        if not item:
            continue

        item = str(item).strip()
        seen[item] += 1
        key = item if seen[item] == 1 else f"{item}_{seen[item]}"

        out[key] = {k: _clean(v) for k, v in r.items() if k != "항목"}

    return out

class FetchC104:
    def __init__(self, factory: BrowserFactoryPort):
        self.factory = factory

    async def _fetch_one(self, code: str, *, sleep_sec: float) -> C104DTO | None:
        async with self.factory.lease() as browser:
            url = f"https://navercomp.wisereport.co.kr/v2/company/c1040001.aspx?cn=&cmp_cd={code}"
            await browser.goto(url, timeout_ms=10_000)

            jitter_sec = 1.0
            if sleep_sec > 0:
                delay = sleep_sec + random.uniform(0, jitter_sec)
                await asyncio.sleep(delay)

            parsed = await parse_c104_to_dict(browser)

            if not parsed or all(not parsed.get(k) for k in BLOCK_KEYS):
                return None

            data: dict[str, Any] = {"코드": code}
            for k in BLOCK_KEYS:
                data[k] = records_to_items_map(parsed.get(k, []))

            return C104DTO(**data)

    async def execute(self, code: str, *, sleep_sec: float = 2.0) -> C104DTO | None:
        return await self._fetch_one(code, sleep_sec=sleep_sec)

    async def execute_many(self, codes: Iterable[str], *, sleep_sec: float = 2.0) -> list[C104DTO]:
        results = await asyncio.gather(*(self._fetch_one(c, sleep_sec=sleep_sec) for c in codes))
        return [r for r in results if r is not None]