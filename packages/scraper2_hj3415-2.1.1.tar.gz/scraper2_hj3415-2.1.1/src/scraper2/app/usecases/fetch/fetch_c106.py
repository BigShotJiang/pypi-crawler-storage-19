# scraper2/app/usecases/fetch/fetch_c106.py
from __future__ import annotations

import asyncio
import random
from typing import Iterable

from contracts.nfs.c106 import C106DTO, C106Block
from scraper2.app.ports.browser.browser_factory_port import BrowserFactoryPort
from scraper2.app.parsing.c106_parser import parse_c106_header, parse_c106_table_to_metrics, normalize_c106_metrics

from logging_hj3415 import logger

class FetchC106:
    def __init__(self, factory: BrowserFactoryPort):
        self.factory = factory

    async def _fetch_one(self, code: str, *, sleep_sec: float) -> C106DTO | None:
        async with self.factory.lease() as browser:
            url = f"https://navercomp.wisereport.co.kr/v2/company/c1060001.aspx?cn=&cmp_cd={code}"
            await browser.goto(url, timeout_ms=10_000)

            jitter_sec = 1.0
            if sleep_sec > 0:
                delay = sleep_sec + random.uniform(0, jitter_sec)
                await asyncio.sleep(delay)

            company_names = await parse_c106_header(browser)

            table_url = (
                f"https://navercomp.wisereport.co.kr/v2/company/cF6002.aspx"
                f"?cmp_cd={code}&finGubun=MAIN&sec_cd=FG000&frq="
            )

            stage = "init"
            try:
                stage = "goto_q"
                await browser.goto(table_url+'q', timeout_ms=10_000)
                await asyncio.sleep(1)

                stage = "parse_q"
                q = await parse_c106_table_to_metrics(browser, company_names)

                stage = "goto_y"
                await browser.goto(table_url+'y', timeout_ms=10_000)
                await asyncio.sleep(1)

                stage = "parse_y"
                y = await parse_c106_table_to_metrics(browser, company_names)

                q_norm = normalize_c106_metrics(q)
                y_norm = normalize_c106_metrics(y)

                return C106DTO(
                    코드=code,
                    q=C106Block(**q_norm),
                    y=C106Block(**y_norm),
                )
            except Exception as e:
                title = ""
                try:
                    title = await browser.title()
                except Exception:
                    pass

                logger.bind(
                    endpoint="c106",
                    code=code,
                    stage=stage,
                    page_title=title,
                    url_q=table_url + "q",
                ).warning("c106 skipped (unstable page/table)")
                return None



    async def execute(self, code: str, *, sleep_sec: float = 2.0) -> C106DTO | None:
        return await self._fetch_one(code, sleep_sec=sleep_sec)

    async def execute_many(
        self,
        codes: Iterable[str],
        *,
        sleep_sec: float = 2.0,
    ) -> list[C106DTO]:
        results = await asyncio.gather(
            *(self._fetch_one(c, sleep_sec=sleep_sec) for c in codes),
            return_exceptions=False,
        )
        return [r for r in results if r is not None]