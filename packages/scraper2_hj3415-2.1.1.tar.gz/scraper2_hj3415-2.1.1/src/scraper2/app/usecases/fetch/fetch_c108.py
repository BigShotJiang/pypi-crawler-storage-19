# scraper2/app/usecases/fetch/fetch_c108.py
from __future__ import annotations

import asyncio
import random
from typing import Iterable

from contracts.nfs.c108 import C108DTO
from scraper2.app.ports.browser.browser_factory_port import BrowserFactoryPort
from scraper2.app.parsing.c108_parser import parse_c108_to_dicts


class FetchC108:
    def __init__(self, factory: BrowserFactoryPort):
        self.factory = factory

    async def _fetch_one(self, code: str, *, sleep_sec: float) -> list[C108DTO]:
        async with self.factory.lease() as browser:
            url = f"https://navercomp.wisereport.co.kr/v2/company/c1080001.aspx?cn=&cmp_cd={code}"
            await browser.goto(url, timeout_ms=10_000)

            # (C101과 동일한 형태로) sleep + jitter
            jitter_sec = 1.0
            if sleep_sec > 0:
                delay = sleep_sec + random.uniform(0, jitter_sec)
                await asyncio.sleep(delay)

            c108_dicts = await parse_c108_to_dicts(browser)

            return [C108DTO(**{**x, "코드": code}) for x in c108_dicts]

    async def execute(self, code: str, *, sleep_sec: float = 2.0) -> list[C108DTO]:
        return await self._fetch_one(code, sleep_sec=sleep_sec)

    async def execute_many(
        self,
        codes: Iterable[str],
        *,
        sleep_sec: float = 2.0,
    ) -> list[C108DTO]:
        results = await asyncio.gather(
            *(self._fetch_one(c, sleep_sec=sleep_sec) for c in codes),
            return_exceptions=False,
        )
        # list[list[C108DTO]] -> flat list[C108DTO]
        out: list[C108DTO] = []
        for chunk in results:
            out.extend(chunk)
        return out