# scraper2/app/usecases/fetch/fetch_c101.py
from __future__ import annotations

import asyncio
import random
from typing import Iterable
from contracts.nfs.c101 import C101DTO
from scraper2.app.ports.browser.browser_factory_port import BrowserFactoryPort
from scraper2.app.parsing.c101_parser import parse_c101_to_dict


class FetchC101:
    def __init__(self, factory: BrowserFactoryPort):
        self.factory = factory

    async def _fetch_one(self, code: str, *, sleep_sec: float) -> C101DTO | None:
        async with self.factory.lease() as browser:
            url = f"https://navercomp.wisereport.co.kr/v2/company/c1010001.aspx?cmp_cd={code}"
            await browser.goto(url, timeout_ms=10_000)

            jitter_sec = 1.0
            if sleep_sec > 0:
                delay = sleep_sec + random.uniform(0, jitter_sec)
                await asyncio.sleep(delay)

            d = await parse_c101_to_dict(browser)
            return None if not d else C101DTO(**d)

    async def execute(self, code: str, *, sleep_sec: float = 2.0) -> C101DTO | None:
        return await self._fetch_one(code, sleep_sec=sleep_sec)

    async def execute_many(
        self,
        codes: Iterable[str],
        *,
        sleep_sec: float = 2.0,
    ) -> list[C101DTO]:
        results = await asyncio.gather(
            *(self._fetch_one(c, sleep_sec=sleep_sec) for c in codes),
            return_exceptions=False,
        )
        return [r for r in results if r is not None]

