# scraper2/app/usecases/ingest/ingest_c103.py
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional, Iterable

from contracts.nfs.c103 import C103DTO
from scraper2.app.usecases.fetch.fetch_c103 import FetchC103
from scraper2.app.ports.sinks.c103_sink_port import C103SinkPort
from scraper2.app.ports.ingest_port import IngestPort


def _utcnow():
    return datetime.now(timezone.utc)

class IngestC103(IngestPort):
    def __init__(self, fetch: FetchC103, sink: C103SinkPort):
        self.fetch = fetch
        self.sink = sink

    async def execute(self, code: str, *, sleep_sec: float = 2.0) -> C103DTO:
        dto = await self.fetch.execute(code, sleep_sec=sleep_sec)
        await self.sink.write(dto)
        return dto

    async def execute_many(
        self,
        codes: Iterable[str],
        *,
        sleep_sec: float = 2.0,
        asof: Optional[datetime] = None,
    ) -> list[C103DTO]:
        batch_asof = asof or _utcnow()

        dtos = await self.fetch.execute_many(codes, sleep_sec=sleep_sec)
        await self.sink.write_many(dtos, asof=batch_asof)
        return dtos