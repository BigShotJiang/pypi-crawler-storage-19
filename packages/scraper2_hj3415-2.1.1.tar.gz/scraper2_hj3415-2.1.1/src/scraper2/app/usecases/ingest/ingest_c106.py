# scraper2/app/usecases/ingest/ingest_c106.py
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional, Iterable

from contracts.nfs.c106 import C106DTO
from scraper2.app.usecases.fetch.fetch_c106 import FetchC106
from scraper2.app.ports.sinks.c106_sink_port import C106SinkPort
from scraper2.app.ports.ingest_port import IngestPort


def _utcnow():
    return datetime.now(timezone.utc)

class IngestC106(IngestPort):
    def __init__(self, fetch: FetchC106, sink: C106SinkPort):
        self.fetch = fetch
        self.sink = sink

    async def execute(self, code: str, *, sleep_sec: float = 2.0) -> C106DTO | None:
        dto = await self.fetch.execute(code, sleep_sec=sleep_sec)
        if dto is not None:
            await self.sink.write(dto)
        return dto

    async def execute_many(
        self,
        codes: Iterable[str],
        *,
        sleep_sec: float = 2.0,
        asof: Optional[datetime] = None,
    ) -> list[C106DTO]:
        batch_asof = asof or _utcnow()

        dtos = await self.fetch.execute_many(codes, sleep_sec=sleep_sec)
        await self.sink.write_many(dtos, asof=batch_asof)
        return dtos
