# assimilation module

::: cropengine.assimilation
