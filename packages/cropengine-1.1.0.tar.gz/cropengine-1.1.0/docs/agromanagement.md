# agromanagement module

::: cropengine.agromanagement