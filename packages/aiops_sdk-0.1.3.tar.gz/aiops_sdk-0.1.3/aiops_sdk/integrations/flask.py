from flask import got_request_exception
from ..exceptions import capture_exception

def init_flask(app):
    @got_request_exception.connect_via(app)
    def _handle_exception(sender, exception, **extra):
        capture_exception(exception)
