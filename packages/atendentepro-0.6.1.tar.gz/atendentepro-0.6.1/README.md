# AtendentePro

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![PyPI version](https://badge.fury.io/py/atendentepro.svg)](https://pypi.org/project/atendentepro/)
[![License: Proprietary](https://img.shields.io/badge/License-Proprietary-red.svg)](LICENSE)

**Framework de orquestração de agentes IA para interações complexas**

Plataforma que unifica múltiplos agentes especializados para resolver demandas que envolvem diferentes fontes de dados, sistemas e fluxos de decisão — tudo orquestrado em um único lugar. Baseado no [OpenAI Agents SDK](https://github.com/openai/openai-agents-python).

### Principais Capacidades

| Capacidade | Descrição |
|------------|-----------|
| **Classificação Inteligente** | Identifica a intenção e direciona para o agente especializado |
| **Integração de Dados** | Conecta documentos (RAG), CSVs, bancos de dados SQL e APIs externas |
| **Orquestração de Fluxos** | Handoffs automáticos entre agentes conforme a complexidade da demanda |
| **Tom e Estilo Customizáveis** | AgentStyle para personalizar linguagem, tom e formato de respostas |
| **Escalonamento Controlado** | Transferência para atendimento humano com contexto preservado |
| **Gestão de Feedbacks** | Sistema de tickets para reclamações, sugestões e acompanhamento |
| **Configuração Declarativa** | Personalização completa via arquivos YAML |

---

## 📋 Índice

- [Instalação](#-instalação)
- [Ativação (Licença)](#-ativação-licença)
- [Configurar API Key](#-configurar-api-key)
- [Início Rápido](#-início-rápido)
- [Arquitetura](#-arquitetura)
- [Agentes Disponíveis](#-agentes-disponíveis)
- [Criar Templates Customizados](#-criar-templates-customizados)
- [Configurações YAML](#-configurações-yaml)
- [Escalation Agent](#-escalation-agent)
- [Feedback Agent](#-feedback-agent)
- [Fluxo de Handoffs](#-fluxo-de-handoffs)
- [Estilo de Comunicação](#-estilo-de-comunicação-agentstyle)
- [Tracing e Monitoramento](#-tracing-e-monitoramento)
- [Suporte](#-suporte)

---

## 📦 Instalação

```bash
# Via PyPI
pip install atendentepro

# Com monitoramento (recomendado)
pip install atendentepro[tracing]
```

---

## 🔑 Ativação (Licença)

A biblioteca **requer um token de licença** para funcionar.

### Opção 1: Variável de Ambiente (Recomendado)

```bash
export ATENDENTEPRO_LICENSE_KEY="ATP_seu-token-aqui"
```

### Opção 2: Via Código

```python
from atendentepro import activate

activate("ATP_seu-token-aqui")
```

### Opção 3: Arquivo .env

```env
ATENDENTEPRO_LICENSE_KEY=ATP_seu-token-aqui
OPENAI_API_KEY=sk-sua-chave-openai
```

### Obter um Token

Entre em contato para obter seu token:
- 📧 **Email:** contato@monkai.com.br
- 🌐 **Site:** https://www.monkai.com.br

---

## 🔐 Configurar API Key

### OpenAI

```bash
# .env
OPENAI_API_KEY=sk-sua-chave-openai
```

### Azure OpenAI

```bash
# .env
OPENAI_PROVIDER=azure
AZURE_API_KEY=sua-chave-azure
AZURE_API_ENDPOINT=https://seu-recurso.openai.azure.com
AZURE_API_VERSION=2024-02-15-preview
AZURE_DEPLOYMENT_NAME=gpt-4o
```

### Via Código

```python
from atendentepro import activate, configure

activate("ATP_seu-token")

configure(
    openai_api_key="sk-sua-chave-openai",
    default_model="gpt-4o-mini"
)
```

---

## ⚡ Início Rápido

```python
import asyncio
from pathlib import Path
from atendentepro import activate, create_standard_network
from agents import Runner

# 1. Ativar
activate("ATP_seu-token")

async def main():
    # 2. Criar rede de agentes
    network = create_standard_network(
        templates_root=Path("./meu_cliente"),
        client="config"
    )
    
    # 3. Executar conversa
    result = await Runner.run(
        network.triage,
        [{"role": "user", "content": "Olá, preciso de ajuda"}]
    )
    
    print(result.final_output)

asyncio.run(main())
```

---

## 🏗️ Arquitetura

```
┌────────────────────────────────────────────────────────────────────────────┐
│                              ATENDENTEPRO                                  │
├────────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│   👤 Usuário                                                               │
│       │                                                                    │
│       ▼                                                                    │
│   ┌─────────────┐                                                         │
│   │   Triage    │──► Classifica intenção do usuário                       │
│   └─────────────┘                                                         │
│         │                                                                  │
│    ┌────┴────┬─────────┬─────────┬─────────┬─────────┬─────────┐          │
│    ▼         ▼         ▼         ▼         ▼         ▼         ▼          │
│ ┌──────┐ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐     │
│ │ Flow │ │Knowl. │ │Confirm│ │ Usage │ │Onboard│ │Escala.│ │Feedbk.│     │
│ └──────┘ └───────┘ └───────┘ └───────┘ └───────┘ └───────┘ └───────┘     │
│    │                                                                       │
│    ▼                                                                       │
│ ┌─────────────┐                                                           │
│ │  Interview  │──► Coleta informações estruturadas                        │
│ └─────────────┘                                                           │
│       │                                                                    │
│       ▼                                                                    │
│ ┌─────────────┐                                                           │
│ │   Answer    │──► Sintetiza resposta final                               │
│ └─────────────┘                                                           │
│                                                                            │
│ ══════════════════════════════════════════════════════════════════════    │
│  📞 Escalation → Transfere para atendimento humano IMEDIATO               │
│  📝 Feedback   → Registra tickets para resposta POSTERIOR                 │
│                                                                            │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## 🤖 Agentes Disponíveis

| Agente | Descrição | Quando Usar |
|--------|-----------|-------------|
| **Triage** | Classifica intenção e direciona | Sempre (ponto de entrada) |
| **Flow** | Apresenta opções/menu ao usuário | Múltiplas opções disponíveis |
| **Interview** | Coleta informações através de perguntas | Precisa de dados do usuário |
| **Answer** | Sintetiza resposta final | Após coletar informações |
| **Knowledge** | Consulta RAG e dados estruturados | Perguntas sobre documentos/dados |
| **Confirmation** | Valida com respostas sim/não | Confirmar ações |
| **Usage** | Responde dúvidas sobre o sistema | "Como funciona?" |
| **Onboarding** | Cadastro de novos usuários | Novos usuários |
| **Escalation** | Transfere para humano | Urgente/não resolvido |
| **Feedback** | Registra tickets | Dúvidas/reclamações/sugestões |

---

## 📁 Criar Templates Customizados

### Estrutura de Pastas

```
meu_cliente/
├── triage_config.yaml       # ✅ Obrigatório
├── flow_config.yaml         # Recomendado
├── interview_config.yaml    # Recomendado
├── answer_config.yaml       # Opcional
├── knowledge_config.yaml    # Opcional
├── escalation_config.yaml   # Recomendado
├── feedback_config.yaml     # Recomendado
├── guardrails_config.yaml   # Recomendado
├── style_config.yaml        # Opcional - Tom e estilo
└── data/                    # Dados estruturados (CSV, etc.)
```

### Usar o Template

```python
from pathlib import Path
from atendentepro import create_standard_network

network = create_standard_network(
    templates_root=Path("./"),
    client="meu_cliente",
    include_escalation=True,
    include_feedback=True,
)
```

---

## ⚙️ Configurações YAML

### triage_config.yaml (Obrigatório)

Define palavras-chave para classificação:

```yaml
agent_name: "Triage Agent"

keywords:
  - agent: "Flow Agent"
    keywords:
      - "produto"
      - "serviço"
      - "preço"
  
  - agent: "Knowledge Agent"
    keywords:
      - "documentação"
      - "manual"
      - "como funciona"
  
  - agent: "Escalation Agent"
    keywords:
      - "falar com humano"
      - "atendente"
```

### flow_config.yaml

Define opções/menu:

```yaml
agent_name: "Flow Agent"

topics:
  - id: 1
    label: "Vendas"
    keywords: ["comprar", "preço", "orçamento"]
    
  - id: 2
    label: "Suporte"
    keywords: ["problema", "erro", "ajuda"]
    
  - id: 3
    label: "Financeiro"
    keywords: ["pagamento", "boleto", "fatura"]
```

### interview_config.yaml

Define perguntas para coleta:

```yaml
agent_name: "Interview Agent"

interview_questions: |
  Para cada tópico, faça as seguintes perguntas:
  
  ## Vendas
  1. Qual produto você tem interesse?
  2. Qual quantidade desejada?
  3. Qual seu email para contato?
  
  ## Suporte
  1. Descreva o problema
  2. Quando começou?
  3. Já tentou alguma solução?
```

### guardrails_config.yaml

Define escopo e restrições:

```yaml
scope: |
  Este assistente pode ajudar com:
  - Informações sobre produtos
  - Suporte técnico
  - Dúvidas sobre serviços

forbidden_topics:
  - "política"
  - "religião"
  - "conteúdo adulto"

out_of_scope_message: |
  Desculpe, não posso ajudar com esse assunto.
  Posso ajudar com produtos, suporte ou serviços.
```

---

## 📞 Escalation Agent

Transfere para atendimento humano quando:
- Usuário solicita explicitamente
- Tópico não coberto pelo sistema
- Usuário demonstra frustração
- Agente não consegue resolver

### escalation_config.yaml

```yaml
name: "Escalation Agent"

triggers:
  explicit_request:
    - "quero falar com um humano"
    - "atendente humano"
    - "falar com uma pessoa"
  
  frustration:
    - "você não está me ajudando"
    - "isso não resolve"

channels:
  phone:
    enabled: true
    number: "0800-123-4567"
    hours: "Seg-Sex 8h-18h"
  
  email:
    enabled: true
    address: "atendimento@empresa.com"
    sla: "Resposta em até 24h"
  
  whatsapp:
    enabled: true
    number: "(11) 99999-9999"

business_hours:
  start: 8
  end: 18
  days: [monday, tuesday, wednesday, thursday, friday]

messages:
  greeting: "Entendo que você precisa de um atendimento especializado."
  out_of_hours: "Nosso atendimento funciona de Seg-Sex, 8h-18h."
```

### Usar Escalation

```python
network = create_standard_network(
    templates_root=Path("./meu_cliente"),
    client="config",
    include_escalation=True,
    escalation_channels="""
📞 Telefone: 0800-123-4567 (Seg-Sex 8h-18h)
📧 Email: atendimento@empresa.com
💬 WhatsApp: (11) 99999-9999
""",
)
```

---

## 📝 Feedback Agent

Registra tickets para:
- ❓ **Dúvidas** - Perguntas que precisam de pesquisa
- 💬 **Feedback** - Opinião sobre produto/serviço
- 📢 **Reclamação** - Insatisfação formal (prioridade alta)
- 💡 **Sugestão** - Ideia de melhoria
- ⭐ **Elogio** - Agradecimento
- ⚠️ **Problema** - Bug/erro técnico (prioridade alta)

### feedback_config.yaml

```yaml
name: "Feedback Agent"

protocol_prefix: "SAC"  # Formato: SAC-20240106-ABC123

ticket_types:
  - name: "duvida"
    label: "Dúvida"
    default_priority: "normal"
    
  - name: "reclamacao"
    label: "Reclamação"
    default_priority: "alta"
    
  - name: "sugestao"
    label: "Sugestão"
    default_priority: "baixa"

email:
  enabled: true
  brand_color: "#660099"
  brand_name: "Minha Empresa"
  sla_message: "Retornaremos em até 24h úteis."

priorities:
  - name: "baixa"
    sla_hours: 72
  - name: "normal"
    sla_hours: 24
  - name: "alta"
    sla_hours: 8
  - name: "urgente"
    sla_hours: 2
```

### Usar Feedback

```python
network = create_standard_network(
    templates_root=Path("./meu_cliente"),
    client="config",
    include_feedback=True,
    feedback_protocol_prefix="SAC",
    feedback_brand_color="#660099",
    feedback_brand_name="Minha Empresa",
)
```

### Diferença: Escalation vs Feedback

| Aspecto | Escalation | Feedback |
|---------|------------|----------|
| **Propósito** | Atendimento IMEDIATO | Registro para DEPOIS |
| **Urgência** | Alta | Pode aguardar |
| **Canal** | Telefone, chat | Email, ticket |
| **Protocolo** | ESC-XXXXXX | SAC-XXXXXX |
| **Quando usar** | "Quero falar com alguém" | "Tenho uma sugestão" |

---

## 🔄 Fluxo de Handoffs

```
Triage ──► Flow, Knowledge, Confirmation, Usage, Onboarding, Escalation, Feedback
Flow ────► Interview, Triage, Escalation, Feedback
Interview► Answer, Escalation, Feedback
Answer ──► Triage, Escalation, Feedback
Knowledge► Triage, Escalation, Feedback
Escalation► Triage, Feedback
Feedback ► Triage, Escalation
```

### Configuração de Agentes

Você pode escolher exatamente quais agentes incluir na sua rede:

```python
from pathlib import Path
from atendentepro import create_standard_network

# Todos os agentes habilitados (padrão)
network = create_standard_network(
    templates_root=Path("./meu_cliente"),
    client="config",
)

# Sem Knowledge Agent (para clientes sem base de conhecimento)
network = create_standard_network(
    templates_root=Path("./meu_cliente"),
    client="config",
    include_knowledge=False,
)

# Rede mínima (apenas fluxo principal)
network = create_standard_network(
    templates_root=Path("./meu_cliente"),
    client="config",
    include_knowledge=False,
    include_confirmation=False,
    include_usage=False,
    include_escalation=False,
    include_feedback=False,
)

# Apenas captura de leads (sem Knowledge nem Usage)
network = create_standard_network(
    templates_root=Path("./meu_cliente"),
    client="config",
    include_knowledge=False,
    include_usage=False,
)
```

### Parâmetros Disponíveis

| Parâmetro | Padrão | Descrição |
|-----------|--------|-----------|
| `include_flow` | `True` | Agente de fluxo conversacional |
| `include_interview` | `True` | Agente de entrevista/coleta |
| `include_answer` | `True` | Agente de resposta final |
| `include_knowledge` | `True` | Agente de base de conhecimento |
| `include_confirmation` | `True` | Agente de confirmação |
| `include_usage` | `True` | Agente de instruções de uso |
| `include_onboarding` | `False` | Agente de boas-vindas |
| `include_escalation` | `True` | Agente de escalonamento humano |
| `include_feedback` | `True` | Agente de tickets/feedback |

---

## 🎨 Estilo de Comunicação (AgentStyle)

Personalize o tom e estilo de resposta dos agentes:

### Via Código

```python
from pathlib import Path
from atendentepro import create_standard_network, AgentStyle

# Estilo global (aplicado a todos os agentes)
global_style = AgentStyle(
    tone="profissional e consultivo",
    language_style="formal",      # formal, informal, neutro
    response_length="moderado",   # conciso, moderado, detalhado
    custom_rules="Sempre cumprimente o usuário pelo nome.",
)

# Estilos específicos por agente
network = create_standard_network(
    templates_root=Path("./meu_cliente"),
    client="config",
    global_style=global_style,
    agent_styles={
        "escalation": AgentStyle(
            tone="empático e acolhedor",
            custom_rules="Demonstre compreensão pela situação.",
        ),
        "knowledge": AgentStyle(
            tone="didático e paciente",
            response_length="detalhado",
        ),
    },
)
```

### Via YAML (style_config.yaml)

```yaml
# Estilo Global
global:
  tone: "profissional e cordial"
  language_style: "formal"
  response_length: "moderado"
  custom_rules: |
    - Seja objetivo e claro nas respostas
    - Use linguagem inclusiva

# Estilos por Agente
agents:
  escalation:
    tone: "empático e tranquilizador"
    custom_rules: |
      - Demonstre compreensão pela situação
      - Assegure que o problema será resolvido

  knowledge:
    tone: "didático e paciente"
    response_length: "detalhado"
    custom_rules: |
      - Explique conceitos de forma acessível
      - Cite as fontes das informações

  feedback:
    tone: "solícito e atencioso"
    custom_rules: |
      - Agradeça o feedback recebido
      - Confirme o registro da solicitação
```

### Opções Disponíveis

| Parâmetro | Valores | Descrição |
|-----------|---------|-----------|
| `tone` | Texto livre | Tom da conversa (ex: "profissional", "empático") |
| `language_style` | `formal`, `informal`, `neutro` | Nível de formalidade |
| `response_length` | `conciso`, `moderado`, `detalhado` | Tamanho das respostas |
| `custom_rules` | Texto livre | Regras personalizadas |

---

## 🔧 Dependências

- Python 3.9+
- openai-agents >= 0.3.3
- openai >= 1.107.1
- pydantic >= 2.0.0
- PyYAML >= 6.0
- python-dotenv >= 1.0.0

---

## 📄 Variáveis de Ambiente

| Variável | Descrição | Obrigatório |
|----------|-----------|-------------|
| `ATENDENTEPRO_LICENSE_KEY` | Token de licença | ✅ Sim |
| `OPENAI_API_KEY` | Chave API OpenAI | ✅ (se OpenAI) |
| `OPENAI_PROVIDER` | `openai` ou `azure` | Não |
| `DEFAULT_MODEL` | Modelo padrão | Não |
| `AZURE_API_KEY` | Chave API Azure | ✅ (se Azure) |
| `AZURE_API_ENDPOINT` | Endpoint Azure | ✅ (se Azure) |
| `SMTP_HOST` | Servidor SMTP | Para emails |
| `SMTP_USER` | Usuário SMTP | Para emails |
| `SMTP_PASSWORD` | Senha SMTP | Para emails |

---

## 📊 Tracing e Monitoramento

### MonkAI Trace (Recomendado)

Integração com [MonkAI Trace](https://github.com/BeMonkAI/monkai-trace) para monitoramento completo de agentes:

```bash
pip install monkai-trace
```

```python
from atendentepro import (
    activate,
    create_standard_network,
    configure_monkai_trace,
    run_with_monkai_tracking,
)

# 1. Ativar biblioteca
activate("ATP_seu-token")

# 2. Configurar MonkAI Trace
configure_monkai_trace(
    tracer_token="tk_seu_token_monkai",  # ou env MONKAI_TRACER_TOKEN
    namespace="meu-projeto",
)

# 3. Criar rede
network = create_standard_network(...)

# 4. Executar com tracking
result = await run_with_monkai_tracking(
    agent=network.triage,
    user_input="Olá, preciso de ajuda",
    user_id="user123",  # Opcional: para sessões multi-usuário
)
```

**Recursos do MonkAI Trace:**
- ✅ Tracking automático de sessões
- ✅ Segmentação de tokens (input, output, process, memory)
- ✅ Rastreamento de handoffs entre agentes
- ✅ Captura de ferramentas internas (web_search, RAG)
- ✅ Suporte multi-usuário (WhatsApp, chat)

### Uso Avançado

```python
from atendentepro import (
    get_monkai_hooks,
    set_monkai_user,
    set_monkai_input,
)
from agents import Runner

# Para controle manual
hooks = get_monkai_hooks()
set_monkai_user("5511999999999")  # WhatsApp
set_monkai_input("Como cancelar?")

result = await Runner.run(network.triage, messages, hooks=hooks)
```

### Application Insights (Azure)

Para Azure, use Application Insights:

```python
from atendentepro import configure_application_insights

configure_application_insights(
    connection_string="InstrumentationKey=..."
)
```

---

## 🤝 Suporte

- 📧 **Email:** contato@monkai.com.br
- 🌐 **Site:** https://www.monkai.com.br

---

## 📝 Changelog

### v0.6.1 (Atual)
- Documentação PyPI atualizada com AgentStyle e changelog completo

### v0.6.0
- **AgentStyle**: Nova classe para personalizar tom e estilo de comunicação
  - `tone`, `language_style`, `response_length`, `custom_rules`
- `style_config.yaml`: Configuração de estilos via YAML
- Parâmetros `global_style` e `agent_styles` em `create_standard_network()`
- Todos os agentes aceitam `style_instructions`

### v0.5.9
- Descrição PyPI formal: "Framework de orquestração de agentes IA"
- README profissional com foco em capacidades corporativas

### v0.5.8
- Novos keywords: triage, handoff, escalation, feedback, knowledge-base
- Dependência `tracing` agora usa `monkai-trace`

### v0.5.7
- **MonkAI Trace**: Integração completa para monitoramento de agentes
- Novas funções: `configure_monkai_trace`, `run_with_monkai_tracking`
- Suporte multi-usuário para WhatsApp/chat

### v0.5.6
- **Agentes configuráveis**: `include_knowledge=False`, `include_flow=False`, etc.
- Permite criar redes sem agentes específicos

### v0.5.5
- Workflow PyPI apenas com tags de versão

### v0.5.4
- Documentação completa standalone no PyPI

### v0.5.3
- Links de documentação corrigidos para PyPI

### v0.5.2
- Contatos atualizados (monkai.com.br)

### v0.5.1
- Prompts modulares para Escalation e Feedback
- Remoção de handoff circular Answer→Interview

### v0.5.0
- **Novo**: Feedback Agent (tickets/SAC)
- Ferramentas: criar_ticket, consultar_ticket, listar_meus_tickets

### v0.4.0
- **Novo**: Escalation Agent (transferência humana)
- Verificação de horário, prioridade automática, webhooks

### v0.3.0
- Sistema de licenciamento com tokens
- Publicação inicial no PyPI

### v0.2.0
- Arquitetura modular completa
- 8 agentes especializados
- Sistema de templates YAML

---

**Made with ❤️ by [MonkAI](https://www.monkai.com.br)**
