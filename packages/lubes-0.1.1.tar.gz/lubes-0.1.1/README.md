# lubes

Official Python SDK for Lubes.

## Installation

```bash
pip install lubes
```

## Quick Start

```python
from lubes import Lubes

# Initialize with API key
client = Lubes(
    api_key="your-api-key",
    org="your-org",
    project="your-project",
)

# List tables
tables = client.list_tables()
for table in tables:
    print(table.name)

# Execute a query
result = client.execute_query("SELECT * FROM users LIMIT 10")
for row in result.rows:
    print(row)
```

## Authentication

### API Key Authentication

```python
client = Lubes(
    api_key="lb_your_api_key_here",
    org="my-org",
    project="my-project",
)
```

### Email/Password Authentication

```python
client = Lubes(api_url="https://api.lubes.dev")

# Login
user, tokens = client.login(
    email="user@example.com",
    password="password",
)

# Set org and project
client.set_org("my-org").set_project("my-project")
```

## Async Support

```python
import asyncio
from lubes import AsyncLubes

async def main():
    async with AsyncLubes(
        api_key="your-api-key",
        org="my-org",
        project="my-project",
    ) as client:
        # List tables
        tables = await client.list_tables()

        # Execute query
        result = await client.execute_query("SELECT * FROM users")
        print(result.rows)

asyncio.run(main())
```

## Database Operations

### List Tables

```python
tables = client.list_tables()
for table in tables:
    print(f"{table.name}: {table.row_count} rows")
```

### Get Table Schema

```python
schema = client.get_table_schema("users")
for column in schema.columns:
    print(f"{column.name}: {column.type}")
```

### Execute Queries

```python
# Simple query
result = client.execute_query("SELECT * FROM users WHERE active = true")

# Parameterized query
result = client.execute_query(
    "SELECT * FROM users WHERE email = $1",
    params=["user@example.com"]
)

print(f"Found {result.row_count} rows")
for row in result.rows:
    print(row)
```

### Database Branches

```python
# List branches
branches = client.list_branches()

# Create branch
branch = client.create_branch(name="feature-branch")

# Delete branch
client.delete_branch("feature-branch")
```

## Functions

### List Functions

```python
functions = client.list_functions()
for fn in functions:
    print(f"{fn.name} ({fn.runtime})")
```

### Invoke Function

```python
result = client.invoke_function("my-function", payload={"input": "data"})
print(result.result)
print(f"Execution time: {result.execution_time_ms}ms")
```

### Function Logs

```python
logs = client.get_function_logs("my-function", limit=50)
for log in logs:
    print(f"[{log.level}] {log.message}")
```

## Deployments

```python
# List deployments
deployments = client.list_deployments()

# Create deployment
deployment = client.create_deployment(description="New feature release")

# Rollback
client.rollback_deployment(deployment.id)
```

## Environment Variables

```python
# List env vars
env_vars = client.list_env_vars()

# Create env var
env_var = client.create_env_var(
    key="API_KEY",
    value="secret-value",
    is_secret=True,
)

# Reveal secret value
revealed = client.reveal_env_var(env_var.id)
print(revealed.value)
```

## Storage

### Buckets

```python
# List buckets
buckets = client.list_buckets()

# Create bucket
bucket = client.create_bucket(name="my-bucket", is_public=False)
```

### Objects

```python
# List objects
objects, total, has_more = client.list_objects(bucket.id, prefix="uploads/")

# Get signed URL for download
signed_url = client.get_signed_url(
    bucket.id,
    key="uploads/file.pdf",
    expires_in=3600,
)
print(signed_url.url)

# Delete object
client.delete_object(bucket.id, "uploads/file.pdf")
```

## Webhooks

```python
# Create webhook
webhook = client.create_webhook(
    name="My Webhook",
    url="https://example.com/webhook",
    events=["deployment.created", "deployment.completed"],
)

# Get deliveries
deliveries, total = client.get_webhook_deliveries(webhook.id)
```

## Organization Management

```python
# List organizations
orgs = client.list_organizations()

# Create organization
org = client.create_organization(name="My Org", slug="my-org")

# Invite member
member = client.invite_member(email="teammate@example.com", role="member")
```

## SSH Keys

```python
# List SSH keys
keys = client.list_ssh_keys()

# Add SSH key
key = client.add_ssh_key(
    name="My Laptop",
    public_key="ssh-ed25519 AAAA..."
)

# Delete SSH key
client.delete_ssh_key(key.id)
```

## Repositories

```python
# Get repository info
repo = client.get_repository()
print(f"Clone URL: {repo.ssh_url}")

# List branches
branches = client.list_repository_branches()

# List commits
commits = client.list_repository_commits(branch="main", limit=10)
```

## Error Handling

```python
from lubes import Lubes, LubesError

try:
    result = client.execute_query("INVALID SQL")
except LubesError as e:
    print(f"Error: {e.code} - {e.message}")
    if e.details:
        print(f"Details: {e.details}")
```

## Configuration Options

```python
client = Lubes(
    api_url="https://api.lubes.dev",  # API URL (default)
    api_key="your-api-key",           # API key authentication
    access_token="jwt-token",         # JWT token authentication
    org="your-org",                   # Organization slug
    project="your-project",           # Project slug
    timeout=30.0,                     # Request timeout in seconds (default: 30)
)
```

## Context Manager

```python
# Synchronous
with Lubes(api_key="key", org="org", project="project") as client:
    tables = client.list_tables()

# Asynchronous
async with AsyncLubes(api_key="key", org="org", project="project") as client:
    tables = await client.list_tables()
```

## Type Hints

Full type hints are provided via Pydantic models:

```python
from lubes import (
    User,
    Organization,
    Project,
    TableSchema,
    QueryResult,
    ServerlessFunction,
    Deployment,
    EnvVar,
    Bucket,
    StorageObject,
    Webhook,
    SshKey,
    RepositoryInfo,
)
```

## License

MIT
