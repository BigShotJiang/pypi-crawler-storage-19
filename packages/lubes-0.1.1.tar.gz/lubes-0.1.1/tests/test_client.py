"""Tests for Lubes client initialization and authentication."""

import pytest
import httpx

from lubes import Lubes, AsyncLubes, LubesError
from lubes.client import DEFAULT_API_URL, DEFAULT_TIMEOUT, BaseClient

from .conftest import (
    TEST_API_URL,
    TEST_API_KEY,
    TEST_ACCESS_TOKEN,
    TEST_ORG_SLUG,
    TEST_PROJECT_SLUG,
    MockTransport,
    MockAsyncTransport,
    make_user_data,
    make_auth_tokens_data,
    make_error_response,
)


# =============================================================================
# BaseClient Initialization Tests
# =============================================================================


class TestBaseClientInit:
    """Test BaseClient initialization."""

    def test_default_initialization(self) -> None:
        """Test client initializes with default values."""
        client = BaseClient()
        assert client.base_url == DEFAULT_API_URL
        assert client.api_key is None
        assert client.access_token is None
        assert client.org is None
        assert client.project is None
        assert client.timeout == DEFAULT_TIMEOUT

    def test_custom_api_url(self) -> None:
        """Test client initializes with custom API URL."""
        client = BaseClient(api_url="https://custom.api.com/")
        assert client.base_url == "https://custom.api.com"

    def test_api_url_trailing_slash_removed(self) -> None:
        """Test trailing slash is removed from API URL."""
        client = BaseClient(api_url="https://api.example.com/")
        assert client.base_url == "https://api.example.com"

    def test_api_key_initialization(self) -> None:
        """Test client initializes with API key."""
        client = BaseClient(api_key=TEST_API_KEY)
        assert client.api_key == TEST_API_KEY

    def test_access_token_initialization(self) -> None:
        """Test client initializes with access token."""
        client = BaseClient(access_token=TEST_ACCESS_TOKEN)
        assert client.access_token == TEST_ACCESS_TOKEN

    def test_org_and_project_initialization(self) -> None:
        """Test client initializes with org and project."""
        client = BaseClient(org=TEST_ORG_SLUG, project=TEST_PROJECT_SLUG)
        assert client.org == TEST_ORG_SLUG
        assert client.project == TEST_PROJECT_SLUG

    def test_custom_timeout(self) -> None:
        """Test client initializes with custom timeout."""
        client = BaseClient(timeout=60.0)
        assert client.timeout == 60.0


class TestBaseClientSetters:
    """Test BaseClient setter methods."""

    def test_set_org(self) -> None:
        """Test set_org method."""
        client = BaseClient()
        result = client.set_org("new-org")
        assert client.org == "new-org"
        assert result is client  # Returns self for chaining

    def test_set_project(self) -> None:
        """Test set_project method."""
        client = BaseClient()
        result = client.set_project("new-project")
        assert client.project == "new-project"
        assert result is client

    def test_set_access_token(self) -> None:
        """Test set_access_token method."""
        client = BaseClient()
        result = client.set_access_token("new_token")
        assert client.access_token == "new_token"
        assert result is client

    def test_method_chaining(self) -> None:
        """Test setter methods can be chained."""
        client = BaseClient()
        client.set_org("org").set_project("project").set_access_token("token")
        assert client.org == "org"
        assert client.project == "project"
        assert client.access_token == "token"


class TestBaseClientHeaders:
    """Test BaseClient header generation."""

    def test_headers_with_api_key(self) -> None:
        """Test headers include API key when set."""
        client = BaseClient(api_key=TEST_API_KEY)
        headers = client._get_headers()
        assert headers["Content-Type"] == "application/json"
        assert headers["X-API-Key"] == TEST_API_KEY
        assert "Authorization" not in headers

    def test_headers_with_access_token(self) -> None:
        """Test headers include Bearer token when access token is set."""
        client = BaseClient(access_token=TEST_ACCESS_TOKEN)
        headers = client._get_headers()
        assert headers["Content-Type"] == "application/json"
        assert headers["Authorization"] == f"Bearer {TEST_ACCESS_TOKEN}"
        assert "X-API-Key" not in headers

    def test_api_key_takes_precedence(self) -> None:
        """Test API key takes precedence over access token."""
        client = BaseClient(api_key=TEST_API_KEY, access_token=TEST_ACCESS_TOKEN)
        headers = client._get_headers()
        assert headers["X-API-Key"] == TEST_API_KEY
        assert "Authorization" not in headers

    def test_headers_without_auth(self) -> None:
        """Test headers without any auth credentials."""
        client = BaseClient()
        headers = client._get_headers()
        assert headers["Content-Type"] == "application/json"
        assert "X-API-Key" not in headers
        assert "Authorization" not in headers


class TestBaseClientPaths:
    """Test BaseClient path generation methods."""

    def test_org_path_success(self) -> None:
        """Test _org_path generates correct path."""
        client = BaseClient(org=TEST_ORG_SLUG)
        assert client._org_path() == f"/v1/organizations/{TEST_ORG_SLUG}"
        assert client._org_path("/members") == f"/v1/organizations/{TEST_ORG_SLUG}/members"

    def test_org_path_raises_without_org(self) -> None:
        """Test _org_path raises error when org not set."""
        client = BaseClient()
        with pytest.raises(LubesError) as exc_info:
            client._org_path()
        assert exc_info.value.code == "config_error"
        assert "Organization not set" in str(exc_info.value)

    def test_project_path_success(self) -> None:
        """Test _project_path generates correct path."""
        client = BaseClient(org=TEST_ORG_SLUG, project=TEST_PROJECT_SLUG)
        expected_base = f"/v1/organizations/{TEST_ORG_SLUG}/projects/{TEST_PROJECT_SLUG}"
        assert client._project_path() == expected_base
        assert client._project_path("/functions") == f"{expected_base}/functions"

    def test_project_path_raises_without_org(self) -> None:
        """Test _project_path raises error when org not set."""
        client = BaseClient(project=TEST_PROJECT_SLUG)
        with pytest.raises(LubesError) as exc_info:
            client._project_path()
        assert exc_info.value.code == "config_error"
        assert "Organization not set" in str(exc_info.value)

    def test_project_path_raises_without_project(self) -> None:
        """Test _project_path raises error when project not set."""
        client = BaseClient(org=TEST_ORG_SLUG)
        with pytest.raises(LubesError) as exc_info:
            client._project_path()
        assert exc_info.value.code == "config_error"
        assert "Project not set" in str(exc_info.value)


# =============================================================================
# Lubes Synchronous Client Tests
# =============================================================================


class TestLubesInit:
    """Test Lubes synchronous client initialization."""

    def test_client_creation(self) -> None:
        """Test client is created successfully."""
        client = Lubes(api_url=TEST_API_URL, api_key=TEST_API_KEY)
        assert client.base_url == TEST_API_URL
        assert client.api_key == TEST_API_KEY
        assert client._client is not None
        client.close()

    def test_context_manager(self) -> None:
        """Test client works as context manager."""
        with Lubes(api_key=TEST_API_KEY) as client:
            assert client._client is not None

    def test_close_method(self) -> None:
        """Test close method works."""
        client = Lubes(api_key=TEST_API_KEY)
        client.close()
        # Client should be closed (no easy way to verify, just ensure no error)


class TestLubesResponseHandling:
    """Test response handling in Lubes client."""

    def test_successful_response(self, client: Lubes, mock_transport: MockTransport) -> None:
        """Test successful response is parsed correctly."""
        mock_transport.add_response(200, {"data": "test"})
        result = client._request("GET", "/test")
        assert result == {"data": "test"}

    def test_204_no_content_response(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test 204 No Content response returns None."""
        mock_transport.add_response(204, None)
        result = client._request("DELETE", "/test")
        assert result is None

    def test_error_response_with_json(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test error response with JSON body raises LubesError."""
        mock_transport.add_response(400, make_error_response("bad_request", "Invalid input"))
        with pytest.raises(LubesError) as exc_info:
            client._request("POST", "/test", json={})
        assert exc_info.value.code == "bad_request"
        assert exc_info.value.message == "Invalid input"

    def test_error_response_with_details(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test error response includes details."""
        details = {"field": "email", "reason": "invalid format"}
        mock_transport.add_response(
            400, make_error_response("validation_error", "Validation failed", details)
        )
        with pytest.raises(LubesError) as exc_info:
            client._request("POST", "/test", json={})
        assert exc_info.value.details == details


# =============================================================================
# Authentication Tests
# =============================================================================


class TestAuthentication:
    """Test authentication methods."""

    def test_register(self, client: Lubes, mock_transport: MockTransport) -> None:
        """Test user registration."""
        mock_transport.add_response(
            200,
            {
                "user": make_user_data(),
                "tokens": make_auth_tokens_data(),
            },
        )
        user, tokens = client.register("test@example.com", "password123", "Test User")

        assert user.email == "test@example.com"
        assert user.name == "Test User"
        assert tokens.access_token == "access_token_abc"
        assert tokens.refresh_token == "refresh_token_xyz"

        # Verify request
        request = mock_transport.requests[0]
        assert request.method == "POST"
        assert "/v1/auth/register" in str(request.url)

    def test_login(self, client: Lubes, mock_transport: MockTransport) -> None:
        """Test user login."""
        mock_transport.add_response(
            200,
            {
                "user": make_user_data(),
                "tokens": make_auth_tokens_data("new_access_token"),
            },
        )
        user, tokens = client.login("test@example.com", "password123")

        assert user.email == "test@example.com"
        assert tokens.access_token == "new_access_token"
        # Verify access token is stored on client
        assert client.access_token == "new_access_token"

    def test_refresh_token(self, client: Lubes, mock_transport: MockTransport) -> None:
        """Test token refresh."""
        mock_transport.add_response(
            200,
            make_auth_tokens_data("refreshed_access_token", "new_refresh_token"),
        )
        tokens = client.refresh_token("old_refresh_token")

        assert tokens.access_token == "refreshed_access_token"
        assert tokens.refresh_token == "new_refresh_token"
        assert client.access_token == "refreshed_access_token"

    def test_forgot_password(self, client: Lubes, mock_transport: MockTransport) -> None:
        """Test forgot password."""
        mock_transport.add_response(204, None)
        # Should not raise
        client.forgot_password("test@example.com")

        request = mock_transport.requests[0]
        assert request.method == "POST"
        assert "/v1/auth/forgot-password" in str(request.url)

    def test_reset_password(self, client: Lubes, mock_transport: MockTransport) -> None:
        """Test reset password."""
        mock_transport.add_response(204, None)
        client.reset_password("reset_token_123", "new_password")

        request = mock_transport.requests[0]
        assert request.method == "POST"
        assert "/v1/auth/reset-password" in str(request.url)

    def test_verify_email(self, client: Lubes, mock_transport: MockTransport) -> None:
        """Test email verification."""
        mock_transport.add_response(204, None)
        client.verify_email("verify_token_123")

        request = mock_transport.requests[0]
        assert request.method == "POST"
        assert "/v1/auth/verify-email" in str(request.url)

    def test_resend_verification(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test resend verification email."""
        mock_transport.add_response(204, None)
        client.resend_verification("test@example.com")

        request = mock_transport.requests[0]
        assert request.method == "POST"
        assert "/v1/auth/resend-verification" in str(request.url)

    def test_get_oauth_providers(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test get OAuth providers."""
        mock_transport.add_response(
            200,
            {
                "providers": [
                    {"id": "github", "name": "GitHub", "enabled": True},
                    {"id": "google", "name": "Google", "enabled": True},
                ]
            },
        )
        providers = client.get_oauth_providers()

        assert len(providers) == 2
        assert providers[0].id == "github"
        assert providers[1].id == "google"


class TestUserMethods:
    """Test user-related methods."""

    def test_get_current_user(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test get current user."""
        mock_transport.add_response(200, make_user_data())
        user = client.get_current_user()

        assert user.id == "user_123"
        assert user.email == "test@example.com"
        assert user.name == "Test User"

    def test_update_current_user(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test update current user."""
        mock_transport.add_response(
            200, make_user_data(name="Updated Name")
        )
        user = client.update_current_user(name="Updated Name")

        assert user.name == "Updated Name"

    def test_change_password(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test change password."""
        mock_transport.add_response(204, None)
        client.change_password("current_pass", "new_pass")

        request = mock_transport.requests[0]
        assert request.method == "POST"
        assert "/v1/users/me/password" in str(request.url)

    def test_get_oauth_accounts(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test get OAuth accounts."""
        mock_transport.add_response(
            200,
            {
                "accounts": [
                    {
                        "id": "oauth_123",
                        "provider": "github",
                        "provider_user_id": "gh_user_456",
                        "email": "test@github.com",
                        "created_at": "2024-01-01T00:00:00Z",
                    }
                ]
            },
        )
        accounts = client.get_oauth_accounts()

        assert len(accounts) == 1
        assert accounts[0].provider == "github"

    def test_unlink_oauth_account(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test unlink OAuth account."""
        mock_transport.add_response(204, None)
        client.unlink_oauth_account("github")

        request = mock_transport.requests[0]
        assert request.method == "DELETE"
        assert "/v1/users/oauth-accounts/github" in str(request.url)


# =============================================================================
# LubesError Tests
# =============================================================================


class TestLubesError:
    """Test LubesError class."""

    def test_error_creation(self) -> None:
        """Test error can be created."""
        error = LubesError("test_error", "Test message")
        assert error.code == "test_error"
        assert error.message == "Test message"
        assert error.details is None

    def test_error_with_details(self) -> None:
        """Test error with details."""
        details = {"field": "email"}
        error = LubesError("validation_error", "Invalid email", details)
        assert error.details == details

    def test_error_str(self) -> None:
        """Test error string representation."""
        error = LubesError("test_error", "Test message")
        assert str(error) == "test_error: Test message"

    def test_error_inheritance(self) -> None:
        """Test error inherits from Exception."""
        error = LubesError("test", "message")
        assert isinstance(error, Exception)


# =============================================================================
# AsyncLubes Tests
# =============================================================================


class TestAsyncLubesInit:
    """Test AsyncLubes initialization."""

    @pytest.mark.asyncio
    async def test_async_client_creation(self) -> None:
        """Test async client is created successfully."""
        client = AsyncLubes(api_url=TEST_API_URL, api_key=TEST_API_KEY)
        assert client.base_url == TEST_API_URL
        assert client.api_key == TEST_API_KEY
        assert client._client is not None
        await client.close()

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        """Test async client works as context manager."""
        async with AsyncLubes(api_key=TEST_API_KEY) as client:
            assert client._client is not None


class TestAsyncAuthentication:
    """Test async authentication methods."""

    @pytest.mark.asyncio
    async def test_async_login(
        self, async_client: AsyncLubes, mock_async_transport: MockAsyncTransport
    ) -> None:
        """Test async user login."""
        mock_async_transport.add_response(
            200,
            {
                "user": make_user_data(),
                "tokens": make_auth_tokens_data("async_access_token"),
            },
        )
        user, tokens = await async_client.login("test@example.com", "password123")

        assert user.email == "test@example.com"
        assert tokens.access_token == "async_access_token"
        assert async_client.access_token == "async_access_token"

    @pytest.mark.asyncio
    async def test_async_get_current_user(
        self, async_client: AsyncLubes, mock_async_transport: MockAsyncTransport
    ) -> None:
        """Test async get current user."""
        mock_async_transport.add_response(200, make_user_data())
        user = await async_client.get_current_user()

        assert user.id == "user_123"
        assert user.email == "test@example.com"
