"""Tests for Lubes organization CRUD operations."""

import pytest
import httpx

from lubes import Lubes, AsyncLubes, LubesError

from .conftest import (
    TEST_API_URL,
    TEST_ORG_SLUG,
    MockTransport,
    MockAsyncTransport,
    make_organization_data,
    make_member_data,
    make_api_key_data,
    make_user_data,
    make_error_response,
)


# =============================================================================
# Organization CRUD Tests
# =============================================================================


class TestListOrganizations:
    """Test listing organizations."""

    def test_list_organizations_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test listing organizations returns list of organizations."""
        mock_transport.add_response(
            200,
            {
                "organizations": [
                    make_organization_data("org_1", "Org One", "org-one"),
                    make_organization_data("org_2", "Org Two", "org-two"),
                ]
            },
        )
        orgs = client.list_organizations()

        assert len(orgs) == 2
        assert orgs[0].id == "org_1"
        assert orgs[0].name == "Org One"
        assert orgs[0].slug == "org-one"
        assert orgs[1].id == "org_2"

    def test_list_organizations_empty(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test listing organizations returns empty list."""
        mock_transport.add_response(200, {"organizations": []})
        orgs = client.list_organizations()

        assert len(orgs) == 0
        assert orgs == []

    def test_list_organizations_request(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test list organizations makes correct request."""
        mock_transport.add_response(200, {"organizations": []})
        client.list_organizations()

        request = mock_transport.requests[0]
        assert request.method == "GET"
        assert "/v1/organizations" in str(request.url)


class TestCreateOrganization:
    """Test creating organizations."""

    def test_create_organization_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test creating an organization."""
        mock_transport.add_response(
            200,
            make_organization_data("org_new", "New Organization", "new-org"),
        )
        org = client.create_organization("New Organization", "new-org")

        assert org.id == "org_new"
        assert org.name == "New Organization"
        assert org.slug == "new-org"

    def test_create_organization_request_body(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test create organization sends correct request body."""
        mock_transport.add_response(200, make_organization_data())
        client.create_organization("Test Org", "test-org")

        request = mock_transport.requests[0]
        assert request.method == "POST"
        assert "/v1/organizations" in str(request.url)
        # Verify content type header is set
        assert request.headers["Content-Type"] == "application/json"

    def test_create_organization_duplicate_slug(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test creating organization with duplicate slug fails."""
        mock_transport.add_response(
            409,
            make_error_response("conflict", "Organization slug already exists"),
        )

        with pytest.raises(LubesError) as exc_info:
            client.create_organization("Test Org", "existing-slug")

        assert exc_info.value.code == "conflict"


class TestCheckOrgSlug:
    """Test checking organization slug availability."""

    def test_check_slug_available(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test slug is available."""
        mock_transport.add_response(200, {"available": True})
        result = client.check_org_slug("new-slug")

        assert result is True

    def test_check_slug_not_available(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test slug is not available."""
        mock_transport.add_response(200, {"available": False})
        result = client.check_org_slug("existing-slug")

        assert result is False

    def test_check_slug_request(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test check slug makes correct request."""
        mock_transport.add_response(200, {"available": True})
        client.check_org_slug("test-slug")

        request = mock_transport.requests[0]
        assert request.method == "GET"
        assert "/v1/organizations/check-slug" in str(request.url)
        assert "slug=test-slug" in str(request.url)


class TestGetOrganization:
    """Test getting organization details."""

    def test_get_organization_by_slug(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test getting organization by slug parameter."""
        mock_transport.add_response(
            200,
            make_organization_data("org_123", "My Org", "my-org"),
        )
        org = client.get_organization("my-org")

        assert org.id == "org_123"
        assert org.slug == "my-org"

        request = mock_transport.requests[0]
        assert "/v1/organizations/my-org" in str(request.url)

    def test_get_organization_uses_client_org(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test getting organization uses client's org when not specified."""
        mock_transport.add_response(200, make_organization_data())
        client.get_organization()

        request = mock_transport.requests[0]
        assert f"/v1/organizations/{TEST_ORG_SLUG}" in str(request.url)

    def test_get_organization_not_found(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test getting non-existent organization."""
        mock_transport.add_response(
            404,
            make_error_response("not_found", "Organization not found"),
        )

        with pytest.raises(LubesError) as exc_info:
            client.get_organization("nonexistent")

        assert exc_info.value.code == "not_found"


class TestUpdateOrganization:
    """Test updating organizations."""

    def test_update_organization_name(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test updating organization name."""
        mock_transport.add_response(
            200,
            make_organization_data(name="Updated Name"),
        )
        org = client.update_organization("Updated Name")

        assert org.name == "Updated Name"

    def test_update_organization_request(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test update organization makes correct request."""
        mock_transport.add_response(200, make_organization_data())
        client.update_organization("New Name")

        request = mock_transport.requests[0]
        assert request.method == "PATCH"
        assert f"/v1/organizations/{TEST_ORG_SLUG}" in str(request.url)

    def test_update_organization_requires_org(
        self, client_no_context: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test update organization requires org to be set."""
        with pytest.raises(LubesError) as exc_info:
            client_no_context.update_organization("New Name")

        assert exc_info.value.code == "config_error"
        assert "Organization not set" in str(exc_info.value)


class TestDeleteOrganization:
    """Test deleting organizations."""

    def test_delete_organization_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test deleting organization."""
        mock_transport.add_response(204, None)
        # Should not raise
        client.delete_organization()

        request = mock_transport.requests[0]
        assert request.method == "DELETE"
        assert f"/v1/organizations/{TEST_ORG_SLUG}" in str(request.url)

    def test_delete_organization_requires_org(
        self, client_no_context: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test delete organization requires org to be set."""
        with pytest.raises(LubesError) as exc_info:
            client_no_context.delete_organization()

        assert exc_info.value.code == "config_error"


# =============================================================================
# Organization Members Tests
# =============================================================================


class TestListMembers:
    """Test listing organization members."""

    def test_list_members_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test listing organization members."""
        mock_transport.add_response(
            200,
            {
                "members": [
                    make_member_data("member_1", "user_1", role="owner"),
                    make_member_data("member_2", "user_2", role="admin"),
                    make_member_data("member_3", "user_3", role="member"),
                ]
            },
        )
        members = client.list_members()

        assert len(members) == 3
        assert members[0].role == "owner"
        assert members[1].role == "admin"
        assert members[2].role == "member"

    def test_list_members_includes_user(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test list members includes user details."""
        mock_transport.add_response(
            200, {"members": [make_member_data()]}
        )
        members = client.list_members()

        assert members[0].user is not None
        assert members[0].user.email == "test@example.com"

    def test_list_members_request(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test list members makes correct request."""
        mock_transport.add_response(200, {"members": []})
        client.list_members()

        request = mock_transport.requests[0]
        assert request.method == "GET"
        assert f"/v1/organizations/{TEST_ORG_SLUG}/members" in str(request.url)


class TestInviteMember:
    """Test inviting members to organization."""

    def test_invite_member_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test inviting a member."""
        mock_transport.add_response(
            200,
            make_member_data("new_member", "new_user", role="member"),
        )
        member = client.invite_member("newuser@example.com", "member")

        assert member.role == "member"

    def test_invite_member_default_role(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test invite member uses default role."""
        mock_transport.add_response(200, make_member_data())
        client.invite_member("user@example.com")

        # Default role should be "member"
        request = mock_transport.requests[0]
        assert request.method == "POST"

    def test_invite_member_as_admin(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test inviting a member as admin."""
        mock_transport.add_response(
            200,
            make_member_data(role="admin"),
        )
        member = client.invite_member("admin@example.com", "admin")

        assert member.role == "admin"

    def test_invite_member_request(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test invite member makes correct request."""
        mock_transport.add_response(200, make_member_data())
        client.invite_member("user@example.com", "member")

        request = mock_transport.requests[0]
        assert request.method == "POST"
        assert f"/v1/organizations/{TEST_ORG_SLUG}/members" in str(request.url)


class TestUpdateMemberRole:
    """Test updating member roles."""

    def test_update_member_role_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test updating member role."""
        mock_transport.add_response(
            200,
            make_member_data(role="admin"),
        )
        member = client.update_member_role("member_123", "admin")

        assert member.role == "admin"

    def test_update_member_role_request(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test update member role makes correct request."""
        mock_transport.add_response(200, make_member_data())
        client.update_member_role("member_123", "admin")

        request = mock_transport.requests[0]
        assert request.method == "PATCH"
        assert f"/v1/organizations/{TEST_ORG_SLUG}/members/member_123" in str(
            request.url
        )


class TestRemoveMember:
    """Test removing members from organization."""

    def test_remove_member_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test removing a member."""
        mock_transport.add_response(204, None)
        client.remove_member("member_123")

        request = mock_transport.requests[0]
        assert request.method == "DELETE"
        assert f"/v1/organizations/{TEST_ORG_SLUG}/members/member_123" in str(
            request.url
        )

    def test_remove_member_not_found(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test removing non-existent member."""
        mock_transport.add_response(
            404, make_error_response("not_found", "Member not found")
        )

        with pytest.raises(LubesError) as exc_info:
            client.remove_member("nonexistent")

        assert exc_info.value.code == "not_found"


# =============================================================================
# API Keys Tests
# =============================================================================


class TestListApiKeys:
    """Test listing API keys."""

    def test_list_api_keys_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test listing API keys."""
        mock_transport.add_response(
            200,
            {
                "api_keys": [
                    make_api_key_data("key_1", name="Key 1"),
                    make_api_key_data("key_2", name="Key 2"),
                ]
            },
        )
        keys = client.list_api_keys()

        assert len(keys) == 2
        assert keys[0].name == "Key 1"
        assert keys[1].name == "Key 2"

    def test_list_api_keys_request(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test list API keys makes correct request."""
        mock_transport.add_response(200, {"api_keys": []})
        client.list_api_keys()

        request = mock_transport.requests[0]
        assert request.method == "GET"
        assert f"/v1/organizations/{TEST_ORG_SLUG}/api-keys" in str(request.url)


class TestCreateApiKey:
    """Test creating API keys."""

    def test_create_api_key_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test creating an API key."""
        response_data = make_api_key_data(name="New Key")
        response_data["key"] = "lb_test_full_key_value"  # Full key returned on create
        mock_transport.add_response(200, response_data)

        key = client.create_api_key("New Key")

        assert key.name == "New Key"
        assert key.key == "lb_test_full_key_value"

    def test_create_api_key_with_scopes(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test creating an API key with scopes."""
        mock_transport.add_response(200, make_api_key_data())
        client.create_api_key("Key", scopes=["read", "write"])

        request = mock_transport.requests[0]
        assert request.method == "POST"

    def test_create_api_key_with_expiry(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test creating an API key with expiry."""
        mock_transport.add_response(200, make_api_key_data())
        client.create_api_key("Key", expires_at="2025-12-31T23:59:59Z")

        request = mock_transport.requests[0]
        assert request.method == "POST"


class TestGetApiKey:
    """Test getting API key details."""

    def test_get_api_key_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test getting an API key."""
        mock_transport.add_response(200, make_api_key_data("key_123"))
        key = client.get_api_key("key_123")

        assert key.id == "key_123"

    def test_get_api_key_request(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test get API key makes correct request."""
        mock_transport.add_response(200, make_api_key_data())
        client.get_api_key("key_123")

        request = mock_transport.requests[0]
        assert request.method == "GET"
        assert f"/v1/organizations/{TEST_ORG_SLUG}/api-keys/key_123" in str(request.url)


class TestUpdateApiKey:
    """Test updating API keys."""

    def test_update_api_key_name(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test updating API key name."""
        mock_transport.add_response(
            200, make_api_key_data(name="Updated Name")
        )
        key = client.update_api_key("key_123", name="Updated Name")

        assert key.name == "Updated Name"

    def test_update_api_key_scopes(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test updating API key scopes."""
        mock_transport.add_response(200, make_api_key_data())
        client.update_api_key("key_123", scopes=["read"])

        request = mock_transport.requests[0]
        assert request.method == "PATCH"


class TestRevokeApiKey:
    """Test revoking API keys."""

    def test_revoke_api_key_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test revoking an API key."""
        mock_transport.add_response(204, None)
        client.revoke_api_key("key_123")

        request = mock_transport.requests[0]
        assert request.method == "DELETE"
        assert f"/v1/organizations/{TEST_ORG_SLUG}/api-keys/key_123" in str(request.url)


# =============================================================================
# Audit Logs Tests
# =============================================================================


class TestListAuditLogs:
    """Test listing audit logs."""

    def test_list_audit_logs_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test listing audit logs."""
        mock_transport.add_response(
            200,
            {
                "data": [
                    {
                        "id": "log_1",
                        "org_id": "org_123",
                        "actor_id": "user_123",
                        "actor_email": "user@example.com",
                        "action": "create",
                        "resource_type": "project",
                        "resource_id": "proj_123",
                        "details": {"name": "New Project"},
                        "ip_address": "192.168.1.1",
                        "user_agent": "Mozilla/5.0",
                        "created_at": "2024-01-01T00:00:00Z",
                    }
                ],
                "total": 1,
            },
        )
        logs, total = client.list_audit_logs()

        assert len(logs) == 1
        assert total == 1
        assert logs[0].action == "create"
        assert logs[0].resource_type == "project"

    def test_list_audit_logs_with_filters(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test listing audit logs with filters."""
        mock_transport.add_response(200, {"data": [], "total": 0})
        client.list_audit_logs(
            action="create",
            resource_type="project",
            actor_id="user_123",
            limit=10,
            offset=0,
        )

        request = mock_transport.requests[0]
        assert request.method == "GET"

    def test_list_audit_logs_request(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test list audit logs makes correct request."""
        mock_transport.add_response(200, {"data": [], "total": 0})
        client.list_audit_logs()

        request = mock_transport.requests[0]
        assert f"/v1/organizations/{TEST_ORG_SLUG}/audit-logs" in str(request.url)


class TestGetAuditLogActions:
    """Test getting audit log actions."""

    def test_get_audit_log_actions_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test getting audit log actions."""
        mock_transport.add_response(
            200,
            {"actions": ["create", "update", "delete", "login"]},
        )
        actions = client.get_audit_log_actions()

        assert len(actions) == 4
        assert "create" in actions
        assert "delete" in actions


class TestGetAuditLogResourceTypes:
    """Test getting audit log resource types."""

    def test_get_audit_log_resource_types_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test getting audit log resource types."""
        mock_transport.add_response(
            200,
            {"resource_types": ["project", "function", "user", "api_key"]},
        )
        types = client.get_audit_log_resource_types()

        assert len(types) == 4
        assert "project" in types


# =============================================================================
# Provisioning Config Tests
# =============================================================================


class TestGetProvisioningConfig:
    """Test getting provisioning config."""

    def test_get_provisioning_config_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test getting provisioning config."""
        mock_transport.add_response(
            200,
            {
                "id": "prov_123",
                "org_id": "org_123",
                "provider": "postgres",
                "host": "db.example.com",
                "port": 5432,
                "username": "admin",
                "database_prefix": "lb_",
                "ssl_mode": "require",
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z",
            },
        )
        config = client.get_provisioning_config()

        assert config.provider == "postgres"
        assert config.host == "db.example.com"
        assert config.port == 5432


class TestUpdateProvisioningConfig:
    """Test updating provisioning config."""

    def test_update_provisioning_config_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test updating provisioning config."""
        mock_transport.add_response(
            200,
            {
                "id": "prov_123",
                "org_id": "org_123",
                "provider": "postgres",
                "host": "new-db.example.com",
                "port": 5433,
                "username": "admin",
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-02T00:00:00Z",
            },
        )
        config = client.update_provisioning_config(host="new-db.example.com", port=5433)

        assert config.host == "new-db.example.com"
        assert config.port == 5433


class TestTestProvisioningConfig:
    """Test testing provisioning config."""

    def test_test_provisioning_config_success(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test testing provisioning config - success."""
        mock_transport.add_response(
            200,
            {"success": True, "message": "Connection successful"},
        )
        success, message = client.test_provisioning_config()

        assert success is True
        assert message == "Connection successful"

    def test_test_provisioning_config_failure(
        self, client: Lubes, mock_transport: MockTransport
    ) -> None:
        """Test testing provisioning config - failure."""
        mock_transport.add_response(
            200,
            {"success": False, "message": "Connection refused"},
        )
        success, message = client.test_provisioning_config()

        assert success is False
        assert message == "Connection refused"


# =============================================================================
# Async Organization Tests
# =============================================================================


class TestAsyncListOrganizations:
    """Test async listing organizations."""

    @pytest.mark.asyncio
    async def test_async_list_organizations(
        self, async_client: AsyncLubes, mock_async_transport: MockAsyncTransport
    ) -> None:
        """Test async listing organizations."""
        mock_async_transport.add_response(
            200,
            {
                "organizations": [
                    make_organization_data("org_1", "Org One", "org-one"),
                    make_organization_data("org_2", "Org Two", "org-two"),
                ]
            },
        )
        orgs = await async_client.list_organizations()

        assert len(orgs) == 2
        assert orgs[0].id == "org_1"
        assert orgs[1].id == "org_2"
