"""Common test fixtures for Lubes SDK tests."""

from datetime import datetime, timezone
from typing import Any, Generator
from unittest.mock import MagicMock, patch

import httpx
import pytest

from lubes import Lubes, AsyncLubes


# =============================================================================
# Constants
# =============================================================================

TEST_API_URL = "https://api.test.lubes.dev"
TEST_API_KEY = "test_api_key_12345"
TEST_ACCESS_TOKEN = "test_access_token_67890"
TEST_ORG_SLUG = "test-org"
TEST_PROJECT_SLUG = "test-project"


# =============================================================================
# Sample Response Data
# =============================================================================


def make_user_data(
    user_id: str = "user_123",
    email: str = "test@example.com",
    name: str = "Test User",
) -> dict[str, Any]:
    """Create sample user data."""
    return {
        "id": user_id,
        "email": email,
        "name": name,
        "avatar_url": None,
        "email_verified_at": "2024-01-01T00:00:00Z",
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
    }


def make_auth_tokens_data(
    access_token: str = "access_token_abc",
    refresh_token: str = "refresh_token_xyz",
) -> dict[str, Any]:
    """Create sample auth tokens data."""
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "Bearer",
        "expires_in": 3600,
    }


def make_organization_data(
    org_id: str = "org_123",
    name: str = "Test Organization",
    slug: str = TEST_ORG_SLUG,
    owner_id: str = "user_123",
) -> dict[str, Any]:
    """Create sample organization data."""
    return {
        "id": org_id,
        "name": name,
        "slug": slug,
        "owner_id": owner_id,
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
    }


def make_project_data(
    project_id: str = "proj_123",
    org_id: str = "org_123",
    name: str = "Test Project",
    slug: str = TEST_PROJECT_SLUG,
    description: str | None = "A test project",
    region: str = "us-east-1",
    status: str = "active",
) -> dict[str, Any]:
    """Create sample project data."""
    return {
        "id": project_id,
        "org_id": org_id,
        "name": name,
        "slug": slug,
        "description": description,
        "region": region,
        "status": status,
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
    }


def make_member_data(
    member_id: str = "member_123",
    user_id: str = "user_123",
    org_id: str = "org_123",
    role: str = "member",
) -> dict[str, Any]:
    """Create sample organization member data."""
    return {
        "id": member_id,
        "user_id": user_id,
        "org_id": org_id,
        "role": role,
        "user": make_user_data(user_id),
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
    }


def make_api_key_data(
    key_id: str = "key_123",
    org_id: str = "org_123",
    name: str = "Test API Key",
) -> dict[str, Any]:
    """Create sample API key data."""
    return {
        "id": key_id,
        "org_id": org_id,
        "name": name,
        "key_prefix": "lb_test",
        "key": None,
        "scopes": ["read", "write"],
        "expires_at": None,
        "last_used_at": None,
        "created_by": "user_123",
        "created_at": "2024-01-01T00:00:00Z",
    }


def make_error_response(
    error: str = "unknown_error",
    message: str = "An error occurred",
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create sample error response data."""
    return {
        "error": error,
        "message": message,
        "details": details,
    }


# =============================================================================
# Mock HTTP Transport
# =============================================================================


class MockTransport(httpx.BaseTransport):
    """Mock HTTP transport for testing."""

    def __init__(self) -> None:
        self.requests: list[httpx.Request] = []
        self.responses: list[tuple[int, dict[str, Any] | None]] = []
        self._response_index = 0

    def add_response(
        self, status_code: int = 200, json_data: dict[str, Any] | None = None
    ) -> None:
        """Add a response to the queue."""
        self.responses.append((status_code, json_data))

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        """Handle a request and return a mocked response."""
        self.requests.append(request)

        if self._response_index < len(self.responses):
            status_code, json_data = self.responses[self._response_index]
            self._response_index += 1
        else:
            status_code = 200
            json_data = {}

        return httpx.Response(
            status_code=status_code,
            json=json_data,
            request=request,
        )


class MockAsyncTransport(httpx.AsyncBaseTransport):
    """Mock async HTTP transport for testing."""

    def __init__(self) -> None:
        self.requests: list[httpx.Request] = []
        self.responses: list[tuple[int, dict[str, Any] | None]] = []
        self._response_index = 0

    def add_response(
        self, status_code: int = 200, json_data: dict[str, Any] | None = None
    ) -> None:
        """Add a response to the queue."""
        self.responses.append((status_code, json_data))

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        """Handle an async request and return a mocked response."""
        self.requests.append(request)

        if self._response_index < len(self.responses):
            status_code, json_data = self.responses[self._response_index]
            self._response_index += 1
        else:
            status_code = 200
            json_data = {}

        return httpx.Response(
            status_code=status_code,
            json=json_data,
            request=request,
        )


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_transport() -> MockTransport:
    """Create a mock transport for synchronous client tests."""
    return MockTransport()


@pytest.fixture
def mock_async_transport() -> MockAsyncTransport:
    """Create a mock transport for async client tests."""
    return MockAsyncTransport()


@pytest.fixture
def client(mock_transport: MockTransport) -> Generator[Lubes, None, None]:
    """Create a synchronous Lubes client with mocked transport."""
    client = Lubes(
        api_url=TEST_API_URL,
        api_key=TEST_API_KEY,
        org=TEST_ORG_SLUG,
        project=TEST_PROJECT_SLUG,
    )
    # Replace the internal httpx client with one using our mock transport
    client._client = httpx.Client(
        base_url=TEST_API_URL,
        transport=mock_transport,
    )
    yield client
    client.close()


@pytest.fixture
def client_no_context(mock_transport: MockTransport) -> Generator[Lubes, None, None]:
    """Create a synchronous Lubes client without org/project context."""
    client = Lubes(
        api_url=TEST_API_URL,
        api_key=TEST_API_KEY,
    )
    client._client = httpx.Client(
        base_url=TEST_API_URL,
        transport=mock_transport,
    )
    yield client
    client.close()


@pytest.fixture
def client_with_token(mock_transport: MockTransport) -> Generator[Lubes, None, None]:
    """Create a synchronous Lubes client with access token auth."""
    client = Lubes(
        api_url=TEST_API_URL,
        access_token=TEST_ACCESS_TOKEN,
        org=TEST_ORG_SLUG,
        project=TEST_PROJECT_SLUG,
    )
    client._client = httpx.Client(
        base_url=TEST_API_URL,
        transport=mock_transport,
    )
    yield client
    client.close()


@pytest.fixture
async def async_client(
    mock_async_transport: MockAsyncTransport,
) -> AsyncLubes:
    """Create an async Lubes client with mocked transport."""
    client = AsyncLubes(
        api_url=TEST_API_URL,
        api_key=TEST_API_KEY,
        org=TEST_ORG_SLUG,
        project=TEST_PROJECT_SLUG,
    )
    client._client = httpx.AsyncClient(
        base_url=TEST_API_URL,
        transport=mock_async_transport,
    )
    yield client
    await client.close()
