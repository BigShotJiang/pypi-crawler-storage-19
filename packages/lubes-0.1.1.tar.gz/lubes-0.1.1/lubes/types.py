"""Type definitions for AgentBase SDK"""

from datetime import datetime
from typing import Any, Literal, Optional
from pydantic import BaseModel, Field


# =============================================================================
# Core Types
# =============================================================================


class User(BaseModel):
    id: str
    email: str
    name: str
    avatar_url: Optional[str] = None
    email_verified_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime


class Organization(BaseModel):
    id: str
    name: str
    slug: str
    owner_id: str
    created_at: datetime
    updated_at: datetime


class Project(BaseModel):
    id: str
    org_id: str
    name: str
    slug: str
    description: Optional[str] = None
    region: str
    status: str
    created_at: datetime
    updated_at: datetime


# =============================================================================
# Authentication Types
# =============================================================================


class AuthTokens(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str
    expires_in: int


class OAuthProvider(BaseModel):
    id: str
    name: str
    enabled: bool


class OAuthAccount(BaseModel):
    id: str
    provider: str
    provider_user_id: str
    email: Optional[str] = None
    created_at: datetime


# =============================================================================
# Organization Types
# =============================================================================


class OrganizationMember(BaseModel):
    id: str
    user_id: str
    org_id: str
    role: Literal["owner", "admin", "member"]
    user: Optional[User] = None
    created_at: datetime
    updated_at: datetime


class ApiKey(BaseModel):
    id: str
    org_id: str
    name: str
    key_prefix: str
    key: Optional[str] = None
    scopes: list[str]
    expires_at: Optional[datetime] = None
    last_used_at: Optional[datetime] = None
    created_by: str
    created_at: datetime


class AuditLogEntry(BaseModel):
    id: str
    org_id: str
    actor_id: Optional[str] = None
    actor_email: Optional[str] = None
    action: str
    resource_type: str
    resource_id: Optional[str] = None
    details: Optional[dict[str, Any]] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    created_at: datetime


class ProvisioningConfig(BaseModel):
    id: str
    org_id: str
    provider: str
    host: str
    port: int
    username: str
    database_prefix: Optional[str] = None
    ssl_mode: Optional[str] = None
    created_at: datetime
    updated_at: datetime


# =============================================================================
# Database Types
# =============================================================================


class TableInfo(BaseModel):
    name: str
    schema_: str = Field(alias="schema")
    row_count: Optional[int] = None
    size_bytes: Optional[int] = None

    class Config:
        populate_by_name = True


class ColumnInfo(BaseModel):
    name: str
    type: str
    nullable: bool
    default_value: Optional[str] = None
    is_primary_key: bool


class ForeignKey(BaseModel):
    name: str
    columns: list[str]
    referenced_table: str
    referenced_columns: list[str]


class Index(BaseModel):
    name: str
    columns: list[str]
    unique: bool


class TableSchema(BaseModel):
    name: str
    columns: list[ColumnInfo]
    primary_key: Optional[list[str]] = None
    foreign_keys: Optional[list[ForeignKey]] = None
    indexes: Optional[list[Index]] = None


class QueryResult(BaseModel):
    columns: list[str]
    rows: list[dict[str, Any]]
    row_count: int
    affected_rows: int
    execution_ms: float


class Branch(BaseModel):
    id: str
    project_id: str
    name: str
    parent_id: Optional[str] = None
    parent_name: Optional[str] = None
    status: str
    is_default: bool
    is_protected: bool
    created_by: Optional[str] = None
    created_at: datetime


class DatabaseConfig(BaseModel):
    id: str
    project_id: str
    host: str
    port: int
    database: str
    username: str
    ssl_mode: Optional[str] = None
    pool_size: Optional[int] = None
    status: str
    created_at: datetime
    updated_at: datetime


# =============================================================================
# Function Types
# =============================================================================


class ServerlessFunction(BaseModel):
    id: str
    project_id: str
    name: str
    slug: str
    description: Optional[str] = None
    runtime: str
    entrypoint: Optional[str] = None
    timeout_ms: Optional[int] = None
    memory_mb: Optional[int] = None
    status: str
    created_at: datetime
    updated_at: datetime


class FunctionInvokeResult(BaseModel):
    result: Any
    execution_time_ms: float
    logs: Optional[list[str]] = None


class FunctionLogEntry(BaseModel):
    id: str
    function_id: str
    level: str
    message: str
    timestamp: datetime
    metadata: Optional[dict[str, Any]] = None


# =============================================================================
# Deployment Types
# =============================================================================


class Deployment(BaseModel):
    id: str
    project_id: str
    version: str
    description: Optional[str] = None
    status: Literal["pending", "building", "deploying", "active", "failed", "rolled_back"]
    deployed_by: Optional[str] = None
    deployed_at: Optional[datetime] = None
    created_at: datetime


class DeploymentLogs(BaseModel):
    logs: list[str]


# =============================================================================
# Environment Variable Types
# =============================================================================


class EnvVar(BaseModel):
    id: str
    project_id: str
    key: str
    value: Optional[str] = None
    description: Optional[str] = None
    is_secret: bool
    created_at: datetime
    updated_at: datetime


class RevealedEnvVar(BaseModel):
    id: str
    key: str
    value: str


# =============================================================================
# Storage Types
# =============================================================================


class Bucket(BaseModel):
    id: str
    project_id: str
    name: str
    is_public: bool
    size_bytes: Optional[int] = None
    object_count: Optional[int] = None
    created_at: datetime


class StorageObject(BaseModel):
    id: str
    bucket_id: str
    key: str
    size_bytes: int
    content_type: Optional[str] = None
    metadata: Optional[dict[str, Any]] = None
    created_at: datetime
    updated_at: datetime


class SignedUrl(BaseModel):
    url: str
    expires_at: datetime


# =============================================================================
# Webhook Types
# =============================================================================


class Webhook(BaseModel):
    id: str
    project_id: str
    name: str
    url: str
    secret: Optional[str] = None
    events: list[str]
    is_active: bool
    created_at: datetime
    updated_at: datetime


class WebhookDelivery(BaseModel):
    id: str
    webhook_id: str
    event: str
    payload: dict[str, Any]
    response_status: Optional[int] = None
    response_body: Optional[str] = None
    delivered_at: Optional[datetime] = None
    created_at: datetime


class WebhookEventType(BaseModel):
    name: str
    description: str
    category: str


# =============================================================================
# Log & Activity Types
# =============================================================================


class LogEntry(BaseModel):
    id: str
    project_id: str
    level: Literal["debug", "info", "warn", "error"]
    message: str
    source: Optional[str] = None
    metadata: Optional[dict[str, Any]] = None
    timestamp: datetime


class ActivityEntry(BaseModel):
    id: str
    project_id: str
    action: str
    resource_type: str
    resource_id: Optional[str] = None
    actor_id: Optional[str] = None
    actor_email: Optional[str] = None
    details: Optional[dict[str, Any]] = None
    created_at: datetime


# =============================================================================
# Analytics Types
# =============================================================================


class ProjectAnalytics(BaseModel):
    period: str
    requests: int
    database_queries: int
    function_invocations: int
    storage_bytes: int
    bandwidth_bytes: int
    errors: int


# =============================================================================
# Notification Types
# =============================================================================


class Notification(BaseModel):
    id: str
    user_id: str
    type: str
    title: str
    message: str
    data: Optional[dict[str, Any]] = None
    read_at: Optional[datetime] = None
    created_at: datetime


# =============================================================================
# Search Types
# =============================================================================


class SearchResult(BaseModel):
    type: Literal["project", "function", "table", "env_var"]
    id: str
    name: str
    description: Optional[str] = None
    org_slug: str
    project_slug: Optional[str] = None
    score: float


# =============================================================================
# API Response Types
# =============================================================================


class PaginatedResponse(BaseModel):
    data: list[Any]
    total: int
    page: Optional[int] = None
    per_page: Optional[int] = None
    has_more: Optional[bool] = None


class ApiError(BaseModel):
    error: str
    message: str
    details: Optional[dict[str, Any]] = None


# =============================================================================
# SSH Key Types
# =============================================================================


class SshKey(BaseModel):
    id: str
    user_id: str
    name: str
    fingerprint: str
    key_type: str
    public_key: Optional[str] = None
    last_used_at: Optional[datetime] = None
    created_at: datetime


# =============================================================================
# Repository Types
# =============================================================================


class RepositoryInfo(BaseModel):
    id: str
    project_id: str
    provider: str
    clone_url: Optional[str] = None
    ssh_url: Optional[str] = None
    default_branch: str
    status: str
    webhook_secret: Optional[str] = None
    last_synced_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime


class GitBranch(BaseModel):
    name: str
    commit_sha: str
    is_default: bool
    protected: bool


class GitCommit(BaseModel):
    sha: str
    message: str
    author: str
    email: str
    timestamp: datetime
