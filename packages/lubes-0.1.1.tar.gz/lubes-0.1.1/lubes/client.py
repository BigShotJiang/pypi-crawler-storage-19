"""Lubes API Client"""

from typing import Any, Optional, TypeVar
from urllib.parse import urlencode

import httpx

from .types import (
    User,
    Organization,
    Project,
    AuthTokens,
    OAuthProvider,
    OAuthAccount,
    OrganizationMember,
    ApiKey,
    AuditLogEntry,
    ProvisioningConfig,
    TableInfo,
    TableSchema,
    QueryResult,
    Branch,
    DatabaseConfig,
    ServerlessFunction,
    FunctionInvokeResult,
    FunctionLogEntry,
    Deployment,
    DeploymentLogs,
    EnvVar,
    RevealedEnvVar,
    Bucket,
    StorageObject,
    SignedUrl,
    Webhook,
    WebhookDelivery,
    WebhookEventType,
    LogEntry,
    ActivityEntry,
    ProjectAnalytics,
    Notification,
    SearchResult,
    SshKey,
    RepositoryInfo,
    GitBranch,
    GitCommit,
)

T = TypeVar("T")

DEFAULT_API_URL = "https://api.lubes.dev"
DEFAULT_TIMEOUT = 30.0


class LubesError(Exception):
    """Lubes API Error"""

    def __init__(
        self,
        code: str,
        message: str,
        details: Optional[dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details

    def __str__(self) -> str:
        return f"{self.code}: {self.message}"


class BaseClient:
    """Base client with common functionality"""

    def __init__(
        self,
        api_url: Optional[str] = None,
        api_key: Optional[str] = None,
        access_token: Optional[str] = None,
        org: Optional[str] = None,
        project: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self.base_url = (api_url or DEFAULT_API_URL).rstrip("/")
        self.api_key = api_key
        self.access_token = access_token
        self.org = org
        self.project = project
        self.timeout = timeout

    def set_org(self, org: str) -> "BaseClient":
        self.org = org
        return self

    def set_project(self, project: str) -> "BaseClient":
        self.project = project
        return self

    def set_access_token(self, token: str) -> "BaseClient":
        self.access_token = token
        return self

    def _get_headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        elif self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        return headers

    def _project_path(self, path: str = "") -> str:
        if not self.org:
            raise LubesError("config_error", "Organization not set")
        if not self.project:
            raise LubesError("config_error", "Project not set")
        return f"/v1/organizations/{self.org}/projects/{self.project}{path}"

    def _org_path(self, path: str = "") -> str:
        if not self.org:
            raise LubesError("config_error", "Organization not set")
        return f"/v1/organizations/{self.org}{path}"

    def _handle_response(self, response: httpx.Response) -> Any:
        if not response.is_success:
            try:
                error_data = response.json()
                raise LubesError(
                    error_data.get("error", "unknown_error"),
                    error_data.get("message", f"HTTP {response.status_code}"),
                    error_data.get("details"),
                )
            except (ValueError, KeyError):
                raise LubesError(
                    "unknown_error",
                    f"HTTP {response.status_code}: {response.reason_phrase}",
                )

        if response.status_code == 204:
            return None

        return response.json()


class Lubes(BaseClient):
    """Synchronous Lubes client"""

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=self.timeout,
        )

    def __enter__(self) -> "Lubes":
        return self

    def __exit__(self, *args: Any) -> None:
        self._client.close()

    def close(self) -> None:
        self._client.close()

    def _request(
        self,
        method: str,
        path: str,
        json: Optional[Any] = None,
        params: Optional[dict[str, Any]] = None,
    ) -> Any:
        response = self._client.request(
            method,
            path,
            headers=self._get_headers(),
            json=json,
            params=params,
        )
        return self._handle_response(response)

    # =========================================================================
    # Authentication
    # =========================================================================

    def register(
        self, email: str, password: str, name: str
    ) -> tuple[User, AuthTokens]:
        result = self._request(
            "POST",
            "/v1/auth/register",
            json={"email": email, "password": password, "name": name},
        )
        return User(**result["user"]), AuthTokens(**result["tokens"])

    def login(self, email: str, password: str) -> tuple[User, AuthTokens]:
        result = self._request(
            "POST",
            "/v1/auth/login",
            json={"email": email, "password": password},
        )
        tokens = AuthTokens(**result["tokens"])
        self.access_token = tokens.access_token
        return User(**result["user"]), tokens

    def refresh_token(self, refresh_token: str) -> AuthTokens:
        result = self._request(
            "POST",
            "/v1/auth/refresh",
            json={"refresh_token": refresh_token},
        )
        tokens = AuthTokens(**result)
        self.access_token = tokens.access_token
        return tokens

    def forgot_password(self, email: str) -> None:
        self._request("POST", "/v1/auth/forgot-password", json={"email": email})

    def reset_password(self, token: str, password: str) -> None:
        self._request(
            "POST",
            "/v1/auth/reset-password",
            json={"token": token, "password": password},
        )

    def verify_email(self, token: str) -> None:
        self._request("POST", "/v1/auth/verify-email", json={"token": token})

    def resend_verification(self, email: str) -> None:
        self._request("POST", "/v1/auth/resend-verification", json={"email": email})

    def get_oauth_providers(self) -> list[OAuthProvider]:
        result = self._request("GET", "/v1/auth/oauth/providers")
        return [OAuthProvider(**p) for p in result["providers"]]

    # =========================================================================
    # User
    # =========================================================================

    def get_current_user(self) -> User:
        return User(**self._request("GET", "/v1/users/me"))

    def update_current_user(
        self, name: Optional[str] = None, avatar_url: Optional[str] = None
    ) -> User:
        data = {}
        if name is not None:
            data["name"] = name
        if avatar_url is not None:
            data["avatar_url"] = avatar_url
        return User(**self._request("PATCH", "/v1/users/me", json=data))

    def change_password(self, current_password: str, new_password: str) -> None:
        self._request(
            "POST",
            "/v1/users/me/password",
            json={
                "current_password": current_password,
                "new_password": new_password,
            },
        )

    def get_oauth_accounts(self) -> list[OAuthAccount]:
        result = self._request("GET", "/v1/users/oauth-accounts")
        return [OAuthAccount(**a) for a in result["accounts"]]

    def unlink_oauth_account(self, provider: str) -> None:
        self._request("DELETE", f"/v1/users/oauth-accounts/{provider}")

    # =========================================================================
    # Notifications
    # =========================================================================

    def get_notifications(
        self, limit: Optional[int] = None, offset: Optional[int] = None
    ) -> tuple[list[Notification], int]:
        params = {}
        if limit:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        result = self._request("GET", "/v1/users/notifications", params=params)
        return [Notification(**n) for n in result["data"]], result["total"]

    def get_unread_notification_count(self) -> int:
        return self._request("GET", "/v1/users/notifications/unread-count")["count"]

    def mark_all_notifications_read(self) -> None:
        self._request("POST", "/v1/users/notifications/read-all")

    def mark_notification_read(self, notification_id: str) -> None:
        self._request("POST", f"/v1/users/notifications/{notification_id}/read")

    def delete_notification(self, notification_id: str) -> None:
        self._request("DELETE", f"/v1/users/notifications/{notification_id}")

    # =========================================================================
    # Organizations
    # =========================================================================

    def list_organizations(self) -> list[Organization]:
        result = self._request("GET", "/v1/organizations")
        return [Organization(**o) for o in result["organizations"]]

    def create_organization(self, name: str, slug: str) -> Organization:
        return Organization(
            **self._request(
                "POST", "/v1/organizations", json={"name": name, "slug": slug}
            )
        )

    def check_org_slug(self, slug: str) -> bool:
        result = self._request("GET", f"/v1/organizations/check-slug?slug={slug}")
        return result["available"]

    def get_organization(self, slug: Optional[str] = None) -> Organization:
        return Organization(
            **self._request("GET", f"/v1/organizations/{slug or self.org}")
        )

    def update_organization(self, name: str) -> Organization:
        return Organization(
            **self._request("PATCH", self._org_path(), json={"name": name})
        )

    def delete_organization(self) -> None:
        self._request("DELETE", self._org_path())

    # =========================================================================
    # Organization Members
    # =========================================================================

    def list_members(self) -> list[OrganizationMember]:
        result = self._request("GET", self._org_path("/members"))
        return [OrganizationMember(**m) for m in result["members"]]

    def invite_member(self, email: str, role: str = "member") -> OrganizationMember:
        return OrganizationMember(
            **self._request(
                "POST",
                self._org_path("/members"),
                json={"email": email, "role": role},
            )
        )

    def update_member_role(self, member_id: str, role: str) -> OrganizationMember:
        return OrganizationMember(
            **self._request(
                "PATCH",
                self._org_path(f"/members/{member_id}"),
                json={"role": role},
            )
        )

    def remove_member(self, member_id: str) -> None:
        self._request("DELETE", self._org_path(f"/members/{member_id}"))

    # =========================================================================
    # API Keys
    # =========================================================================

    def list_api_keys(self) -> list[ApiKey]:
        result = self._request("GET", self._org_path("/api-keys"))
        return [ApiKey(**k) for k in result["api_keys"]]

    def create_api_key(
        self,
        name: str,
        scopes: Optional[list[str]] = None,
        expires_at: Optional[str] = None,
    ) -> ApiKey:
        data: dict[str, Any] = {"name": name}
        if scopes:
            data["scopes"] = scopes
        if expires_at:
            data["expires_at"] = expires_at
        return ApiKey(**self._request("POST", self._org_path("/api-keys"), json=data))

    def get_api_key(self, key_id: str) -> ApiKey:
        return ApiKey(**self._request("GET", self._org_path(f"/api-keys/{key_id}")))

    def update_api_key(
        self,
        key_id: str,
        name: Optional[str] = None,
        scopes: Optional[list[str]] = None,
    ) -> ApiKey:
        data = {}
        if name:
            data["name"] = name
        if scopes:
            data["scopes"] = scopes
        return ApiKey(
            **self._request("PATCH", self._org_path(f"/api-keys/{key_id}"), json=data)
        )

    def revoke_api_key(self, key_id: str) -> None:
        self._request("DELETE", self._org_path(f"/api-keys/{key_id}"))

    # =========================================================================
    # Audit Logs
    # =========================================================================

    def list_audit_logs(
        self,
        action: Optional[str] = None,
        resource_type: Optional[str] = None,
        actor_id: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> tuple[list[AuditLogEntry], int]:
        params = {}
        if action:
            params["action"] = action
        if resource_type:
            params["resource_type"] = resource_type
        if actor_id:
            params["actor_id"] = actor_id
        if limit:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        result = self._request("GET", self._org_path("/audit-logs"), params=params)
        return [AuditLogEntry(**e) for e in result["data"]], result["total"]

    def get_audit_log_actions(self) -> list[str]:
        return self._request("GET", self._org_path("/audit-logs/actions"))["actions"]

    def get_audit_log_resource_types(self) -> list[str]:
        return self._request("GET", self._org_path("/audit-logs/resource-types"))[
            "resource_types"
        ]

    # =========================================================================
    # Provisioning Config
    # =========================================================================

    def get_provisioning_config(self) -> ProvisioningConfig:
        return ProvisioningConfig(
            **self._request("GET", self._org_path("/provisioning-config"))
        )

    def update_provisioning_config(self, **kwargs: Any) -> ProvisioningConfig:
        return ProvisioningConfig(
            **self._request("PUT", self._org_path("/provisioning-config"), json=kwargs)
        )

    def test_provisioning_config(self) -> tuple[bool, Optional[str]]:
        result = self._request("POST", self._org_path("/provisioning-config/test"))
        return result["success"], result.get("message")

    # =========================================================================
    # Projects
    # =========================================================================

    def list_projects(self) -> list[Project]:
        result = self._request("GET", self._org_path("/projects"))
        return [Project(**p) for p in result["projects"]]

    def create_project(
        self,
        name: str,
        slug: str,
        description: Optional[str] = None,
        region: Optional[str] = None,
    ) -> Project:
        data: dict[str, Any] = {"name": name, "slug": slug}
        if description:
            data["description"] = description
        if region:
            data["region"] = region
        return Project(
            **self._request("POST", self._org_path("/projects"), json=data)
        )

    def check_project_slug(self, slug: str) -> bool:
        result = self._request(
            "GET", self._org_path(f"/projects/check-slug?slug={slug}")
        )
        return result["available"]

    def get_project(self, project_slug: Optional[str] = None) -> Project:
        slug = project_slug or self.project
        if not slug:
            raise LubesError("config_error", "Project not set")
        return Project(**self._request("GET", self._org_path(f"/projects/{slug}")))

    def update_project(
        self, name: Optional[str] = None, description: Optional[str] = None
    ) -> Project:
        data = {}
        if name:
            data["name"] = name
        if description is not None:
            data["description"] = description
        return Project(**self._request("PATCH", self._project_path(), json=data))

    def delete_project(self) -> None:
        self._request("DELETE", self._project_path())

    # =========================================================================
    # Database Config
    # =========================================================================

    def get_database_config(self) -> DatabaseConfig:
        return DatabaseConfig(
            **self._request("GET", self._project_path("/database-config"))
        )

    def update_database_config(self, **kwargs: Any) -> DatabaseConfig:
        return DatabaseConfig(
            **self._request("PUT", self._project_path("/database-config"), json=kwargs)
        )

    def test_database_config(self) -> tuple[bool, Optional[str]]:
        result = self._request("POST", self._project_path("/database-config/test"))
        return result["success"], result.get("message")

    def provision_database(self) -> DatabaseConfig:
        return DatabaseConfig(
            **self._request("POST", self._project_path("/database-config/provision"))
        )

    # =========================================================================
    # Database Tables
    # =========================================================================

    def list_tables(self) -> list[TableInfo]:
        result = self._request("GET", self._project_path("/database/tables"))
        return [TableInfo(**t) for t in result["tables"]]

    def get_table_schema(self, table_name: str) -> TableSchema:
        return TableSchema(
            **self._request("GET", self._project_path(f"/database/tables/{table_name}"))
        )

    def execute_query(
        self, sql: str, params: Optional[list[Any]] = None
    ) -> QueryResult:
        data: dict[str, Any] = {"sql": sql}
        if params:
            data["params"] = params
        return QueryResult(
            **self._request("POST", self._project_path("/database/query"), json=data)
        )

    # =========================================================================
    # Database Branches
    # =========================================================================

    def list_branches(self) -> list[Branch]:
        result = self._request("GET", self._project_path("/database/branches"))
        return [Branch(**b) for b in result["branches"]]

    def create_branch(
        self, name: str, parent: Optional[str] = None
    ) -> Branch:
        data: dict[str, Any] = {"name": name}
        if parent:
            data["parent"] = parent
        return Branch(
            **self._request("POST", self._project_path("/database/branches"), json=data)
        )

    def delete_branch(self, name: str) -> None:
        self._request("DELETE", self._project_path(f"/database/branches/{name}"))

    # =========================================================================
    # Functions
    # =========================================================================

    def list_functions(self) -> list[ServerlessFunction]:
        result = self._request("GET", self._project_path("/functions"))
        return [ServerlessFunction(**f) for f in result["functions"]]

    def create_function(
        self,
        name: str,
        runtime: str,
        slug: Optional[str] = None,
        description: Optional[str] = None,
        entrypoint: Optional[str] = None,
        timeout_ms: Optional[int] = None,
        memory_mb: Optional[int] = None,
        code: Optional[str] = None,
    ) -> ServerlessFunction:
        data: dict[str, Any] = {"name": name, "runtime": runtime}
        if slug:
            data["slug"] = slug
        if description:
            data["description"] = description
        if entrypoint:
            data["entrypoint"] = entrypoint
        if timeout_ms:
            data["timeout_ms"] = timeout_ms
        if memory_mb:
            data["memory_mb"] = memory_mb
        if code:
            data["code"] = code
        return ServerlessFunction(
            **self._request("POST", self._project_path("/functions"), json=data)
        )

    def get_function(self, slug: str) -> ServerlessFunction:
        return ServerlessFunction(
            **self._request("GET", self._project_path(f"/functions/{slug}"))
        )

    def update_function(self, slug: str, **kwargs: Any) -> ServerlessFunction:
        return ServerlessFunction(
            **self._request(
                "PATCH", self._project_path(f"/functions/{slug}"), json=kwargs
            )
        )

    def delete_function(self, slug: str) -> None:
        self._request("DELETE", self._project_path(f"/functions/{slug}"))

    def invoke_function(
        self, slug: str, payload: Optional[Any] = None
    ) -> FunctionInvokeResult:
        data = {"payload": payload} if payload else None
        return FunctionInvokeResult(
            **self._request(
                "POST", self._project_path(f"/functions/{slug}/invoke"), json=data
            )
        )

    def get_function_logs(
        self, slug: str, limit: Optional[int] = None
    ) -> list[FunctionLogEntry]:
        params = {"limit": limit} if limit else None
        result = self._request(
            "GET", self._project_path(f"/functions/{slug}/logs"), params=params
        )
        return [FunctionLogEntry(**log) for log in result["logs"]]

    # =========================================================================
    # Deployments
    # =========================================================================

    def list_deployments(self) -> list[Deployment]:
        result = self._request("GET", self._project_path("/deployments"))
        return [Deployment(**d) for d in result["deployments"]]

    def create_deployment(self, description: Optional[str] = None) -> Deployment:
        data = {"description": description} if description else None
        return Deployment(
            **self._request("POST", self._project_path("/deployments"), json=data)
        )

    def get_deployment(self, deployment_id: str) -> Deployment:
        return Deployment(
            **self._request("GET", self._project_path(f"/deployments/{deployment_id}"))
        )

    def rollback_deployment(self, deployment_id: str) -> Deployment:
        return Deployment(
            **self._request(
                "POST", self._project_path(f"/deployments/{deployment_id}/rollback")
            )
        )

    def get_deployment_logs(self, deployment_id: str) -> DeploymentLogs:
        return DeploymentLogs(
            **self._request(
                "GET", self._project_path(f"/deployments/{deployment_id}/logs")
            )
        )

    # =========================================================================
    # Environment Variables
    # =========================================================================

    def list_env_vars(self) -> list[EnvVar]:
        result = self._request("GET", self._project_path("/env-vars"))
        return [EnvVar(**e) for e in result["env_vars"]]

    def create_env_var(
        self,
        key: str,
        value: str,
        description: Optional[str] = None,
        is_secret: bool = False,
    ) -> EnvVar:
        data: dict[str, Any] = {"key": key, "value": value, "is_secret": is_secret}
        if description:
            data["description"] = description
        return EnvVar(
            **self._request("POST", self._project_path("/env-vars"), json=data)
        )

    def get_env_var(self, env_var_id: str) -> EnvVar:
        return EnvVar(
            **self._request("GET", self._project_path(f"/env-vars/{env_var_id}"))
        )

    def update_env_var(
        self,
        env_var_id: str,
        value: Optional[str] = None,
        description: Optional[str] = None,
    ) -> EnvVar:
        data = {}
        if value is not None:
            data["value"] = value
        if description is not None:
            data["description"] = description
        return EnvVar(
            **self._request(
                "PATCH", self._project_path(f"/env-vars/{env_var_id}"), json=data
            )
        )

    def delete_env_var(self, env_var_id: str) -> None:
        self._request("DELETE", self._project_path(f"/env-vars/{env_var_id}"))

    def reveal_env_var(self, env_var_id: str) -> RevealedEnvVar:
        return RevealedEnvVar(
            **self._request(
                "POST", self._project_path(f"/env-vars/{env_var_id}/reveal")
            )
        )

    # =========================================================================
    # Storage Buckets
    # =========================================================================

    def list_buckets(self) -> list[Bucket]:
        result = self._request("GET", self._project_path("/storage/buckets"))
        return [Bucket(**b) for b in result["buckets"]]

    def create_bucket(self, name: str, is_public: bool = False) -> Bucket:
        return Bucket(
            **self._request(
                "POST",
                self._project_path("/storage/buckets"),
                json={"name": name, "is_public": is_public},
            )
        )

    def delete_bucket(self, bucket_id: str) -> None:
        self._request("DELETE", self._project_path(f"/storage/buckets/{bucket_id}"))

    # =========================================================================
    # Storage Objects
    # =========================================================================

    def list_objects(
        self,
        bucket_id: str,
        prefix: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> tuple[list[StorageObject], int, bool]:
        params = {}
        if prefix:
            params["prefix"] = prefix
        if limit:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        result = self._request(
            "GET",
            self._project_path(f"/storage/buckets/{bucket_id}/objects"),
            params=params,
        )
        return (
            [StorageObject(**o) for o in result["data"]],
            result["total"],
            result.get("has_more", False),
        )

    def delete_object(self, bucket_id: str, key: str) -> None:
        self._request(
            "DELETE",
            self._project_path(f"/storage/buckets/{bucket_id}/objects"),
            params={"key": key},
        )

    def get_signed_url(
        self,
        bucket_id: str,
        key: str,
        expires_in: int = 3600,
        operation: str = "download",
    ) -> SignedUrl:
        return SignedUrl(
            **self._request(
                "POST",
                self._project_path(f"/storage/buckets/{bucket_id}/signed-url"),
                json={"key": key, "expires_in": expires_in, "operation": operation},
            )
        )

    def get_download_url(self, bucket_id: str, key: str) -> str:
        return f"{self.base_url}{self._project_path(f'/storage/buckets/{bucket_id}/download')}?key={key}"

    # =========================================================================
    # Webhooks
    # =========================================================================

    def list_webhooks(self) -> list[Webhook]:
        result = self._request("GET", self._project_path("/webhooks"))
        return [Webhook(**w) for w in result["webhooks"]]

    def create_webhook(
        self,
        name: str,
        url: str,
        events: list[str],
        is_active: bool = True,
    ) -> Webhook:
        return Webhook(
            **self._request(
                "POST",
                self._project_path("/webhooks"),
                json={
                    "name": name,
                    "url": url,
                    "events": events,
                    "is_active": is_active,
                },
            )
        )

    def get_webhook(self, webhook_id: str) -> Webhook:
        return Webhook(
            **self._request("GET", self._project_path(f"/webhooks/{webhook_id}"))
        )

    def update_webhook(self, webhook_id: str, **kwargs: Any) -> Webhook:
        return Webhook(
            **self._request(
                "PATCH", self._project_path(f"/webhooks/{webhook_id}"), json=kwargs
            )
        )

    def delete_webhook(self, webhook_id: str) -> None:
        self._request("DELETE", self._project_path(f"/webhooks/{webhook_id}"))

    def get_webhook_deliveries(
        self, webhook_id: str, limit: Optional[int] = None, offset: Optional[int] = None
    ) -> tuple[list[WebhookDelivery], int]:
        params = {}
        if limit:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        result = self._request(
            "GET",
            self._project_path(f"/webhooks/{webhook_id}/deliveries"),
            params=params,
        )
        return [WebhookDelivery(**d) for d in result["data"]], result["total"]

    def regenerate_webhook_secret(self, webhook_id: str) -> str:
        return self._request(
            "POST", self._project_path(f"/webhooks/{webhook_id}/regenerate-secret")
        )["secret"]

    def get_webhook_event_types(self) -> list[WebhookEventType]:
        result = self._request("GET", "/v1/webhooks/events")
        return [WebhookEventType(**e) for e in result["events"]]

    # =========================================================================
    # Logs & Activity
    # =========================================================================

    def get_logs(
        self,
        level: Optional[str] = None,
        source: Optional[str] = None,
        since: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> tuple[list[LogEntry], int, bool]:
        params = {}
        if level:
            params["level"] = level
        if source:
            params["source"] = source
        if since:
            params["since"] = since
        if limit:
            params["limit"] = limit
        result = self._request("GET", self._project_path("/logs"), params=params)
        return (
            [LogEntry(**log) for log in result["data"]],
            result["total"],
            result.get("has_more", False),
        )

    def get_activity(
        self, limit: Optional[int] = None, offset: Optional[int] = None
    ) -> tuple[list[ActivityEntry], int]:
        params = {}
        if limit:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        result = self._request("GET", self._project_path("/activity"), params=params)
        return [ActivityEntry(**a) for a in result["data"]], result["total"]

    # =========================================================================
    # Analytics
    # =========================================================================

    def get_analytics(self, period: str = "24h") -> ProjectAnalytics:
        return ProjectAnalytics(
            **self._request(
                "GET", self._project_path("/analytics"), params={"period": period}
            )
        )

    # =========================================================================
    # Search
    # =========================================================================

    def search(
        self,
        query: str,
        type: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[SearchResult]:
        params: dict[str, Any] = {"q": query}
        if type:
            params["type"] = type
        if limit:
            params["limit"] = limit
        result = self._request("GET", "/v1/search", params=params)
        return [SearchResult(**r) for r in result["results"]]

    # =========================================================================
    # SSH Keys
    # =========================================================================

    def list_ssh_keys(self) -> list[SshKey]:
        result = self._request("GET", "/v1/users/ssh-keys")
        return [SshKey(**k) for k in result["keys"]]

    def create_ssh_key(self, name: str, public_key: str) -> SshKey:
        return SshKey(
            **self._request(
                "POST",
                "/v1/users/ssh-keys",
                json={"name": name, "public_key": public_key},
            )
        )

    def delete_ssh_key(self, key_id: str) -> None:
        self._request("DELETE", f"/v1/users/ssh-keys/{key_id}")

    # =========================================================================
    # Repository
    # =========================================================================

    def get_repository(self) -> Optional[RepositoryInfo]:
        try:
            result = self._request("GET", self._project_path("/repository"))
            return RepositoryInfo(**result)
        except LubesError as e:
            if e.code == "not_found":
                return None
            raise

    def list_repository_branches(self) -> list[GitBranch]:
        result = self._request("GET", self._project_path("/repository/branches"))
        return [GitBranch(**b) for b in result["branches"]]

    def list_repository_commits(
        self, branch: Optional[str] = None, limit: Optional[int] = None
    ) -> list[GitCommit]:
        params = {}
        if branch:
            params["branch"] = branch
        if limit:
            params["limit"] = limit
        result = self._request(
            "GET", self._project_path("/repository/commits"), params=params or None
        )
        return [GitCommit(**c) for c in result["commits"]]


class AsyncLubes(BaseClient):
    """Asynchronous Lubes client"""

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=self.timeout,
        )

    async def __aenter__(self) -> "AsyncLubes":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self._client.aclose()

    async def close(self) -> None:
        await self._client.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        json: Optional[Any] = None,
        params: Optional[dict[str, Any]] = None,
    ) -> Any:
        response = await self._client.request(
            method,
            path,
            headers=self._get_headers(),
            json=json,
            params=params,
        )
        return self._handle_response(response)

    # =========================================================================
    # Authentication
    # =========================================================================

    async def login(self, email: str, password: str) -> tuple[User, AuthTokens]:
        result = await self._request(
            "POST",
            "/v1/auth/login",
            json={"email": email, "password": password},
        )
        tokens = AuthTokens(**result["tokens"])
        self.access_token = tokens.access_token
        return User(**result["user"]), tokens

    # =========================================================================
    # User
    # =========================================================================

    async def get_current_user(self) -> User:
        return User(**await self._request("GET", "/v1/users/me"))

    # =========================================================================
    # Organizations
    # =========================================================================

    async def list_organizations(self) -> list[Organization]:
        result = await self._request("GET", "/v1/organizations")
        return [Organization(**o) for o in result["organizations"]]

    # =========================================================================
    # Projects
    # =========================================================================

    async def list_projects(self) -> list[Project]:
        result = await self._request("GET", self._org_path("/projects"))
        return [Project(**p) for p in result["projects"]]

    async def get_project(self, project_slug: Optional[str] = None) -> Project:
        slug = project_slug or self.project
        if not slug:
            raise LubesError("config_error", "Project not set")
        return Project(**await self._request("GET", self._org_path(f"/projects/{slug}")))

    # =========================================================================
    # Database
    # =========================================================================

    async def list_tables(self) -> list[TableInfo]:
        result = await self._request("GET", self._project_path("/database/tables"))
        return [TableInfo(**t) for t in result["tables"]]

    async def get_table_schema(self, table_name: str) -> TableSchema:
        return TableSchema(
            **await self._request(
                "GET", self._project_path(f"/database/tables/{table_name}")
            )
        )

    async def execute_query(
        self, sql: str, params: Optional[list[Any]] = None
    ) -> QueryResult:
        data: dict[str, Any] = {"sql": sql}
        if params:
            data["params"] = params
        return QueryResult(
            **await self._request(
                "POST", self._project_path("/database/query"), json=data
            )
        )

    async def list_branches(self) -> list[Branch]:
        result = await self._request("GET", self._project_path("/database/branches"))
        return [Branch(**b) for b in result["branches"]]

    # =========================================================================
    # Functions
    # =========================================================================

    async def list_functions(self) -> list[ServerlessFunction]:
        result = await self._request("GET", self._project_path("/functions"))
        return [ServerlessFunction(**f) for f in result["functions"]]

    async def invoke_function(
        self, slug: str, payload: Optional[Any] = None
    ) -> FunctionInvokeResult:
        data = {"payload": payload} if payload else None
        return FunctionInvokeResult(
            **await self._request(
                "POST", self._project_path(f"/functions/{slug}/invoke"), json=data
            )
        )

    # =========================================================================
    # Deployments
    # =========================================================================

    async def list_deployments(self) -> list[Deployment]:
        result = await self._request("GET", self._project_path("/deployments"))
        return [Deployment(**d) for d in result["deployments"]]

    async def create_deployment(self, description: Optional[str] = None) -> Deployment:
        data = {"description": description} if description else None
        return Deployment(
            **await self._request("POST", self._project_path("/deployments"), json=data)
        )

    # =========================================================================
    # Environment Variables
    # =========================================================================

    async def list_env_vars(self) -> list[EnvVar]:
        result = await self._request("GET", self._project_path("/env-vars"))
        return [EnvVar(**e) for e in result["env_vars"]]

    # =========================================================================
    # Storage
    # =========================================================================

    async def list_buckets(self) -> list[Bucket]:
        result = await self._request("GET", self._project_path("/storage/buckets"))
        return [Bucket(**b) for b in result["buckets"]]

    async def list_objects(
        self, bucket_id: str, prefix: Optional[str] = None
    ) -> tuple[list[StorageObject], int, bool]:
        params = {"prefix": prefix} if prefix else None
        result = await self._request(
            "GET",
            self._project_path(f"/storage/buckets/{bucket_id}/objects"),
            params=params,
        )
        return (
            [StorageObject(**o) for o in result["data"]],
            result["total"],
            result.get("has_more", False),
        )
