from importlib import resources as __resources_loader
from ctypes import CDLL as __CDLL
from pathlib import Path as __Path

with __resources_loader.path(__package__, 'resources', 'sqlite3.dll') as _dll:
    if __Path(_dll).exists(): __CDLL(_dll)

import sqlite3

__all__ = ['sqlite3']