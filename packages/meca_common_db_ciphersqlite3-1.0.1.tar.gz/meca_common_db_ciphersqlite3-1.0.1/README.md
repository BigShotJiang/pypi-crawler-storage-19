## 快速开始

1. 安装包

```bash
pip install meca-common-db-ciphersqlite3
```

2. 使用包

```python
from meca.common.db.ciphersqlite3 import sqlite3
conn = sqlite3.connect('test.db')
conn.execute('PRAGMA key=<key>')
row = conn.execute('select * from sqlite_master').fetchone()
conn.close()
print(row)
```
