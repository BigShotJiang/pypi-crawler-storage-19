Utility for randomizing songs
===
