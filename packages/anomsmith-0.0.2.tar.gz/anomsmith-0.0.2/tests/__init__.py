"""Tests for anomsmith."""

