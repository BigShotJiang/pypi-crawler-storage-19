import numpy as np
from Bio import SeqIO

CODONS = [
    a+b+c for a in "ACGT" for b in "ACGT" for c in "ACGT"
    if a+b+c not in ["TAA", "TAG", "TGA"]
]
CODON_TO_ID = {c: i for i, c in enumerate(CODONS)}

def encode_alignment(fasta_path):
    records = list(SeqIO.parse(fasta_path, "fasta"))
    ntaxa = len(records)
    seq_len = len(records[0].seq) // 3

    tensor = np.zeros((ntaxa, seq_len), dtype=np.int64)

    for i, rec in enumerate(records):
        seq = str(rec.seq)
        for j in range(seq_len):
            codon = seq[3*j:3*j+3]
            tensor[i, j] = CODON_TO_ID.get(codon, 0)

    return tensor, ntaxa, seq_len
