import argparse
from babappaomega.inference import run_inference

def main():
    parser = argparse.ArgumentParser(
        prog="babappaomega",
        description="BABAPPAΩ: episodic branch–site selection inference"
    )

    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("predict", help="Run inference on an alignment")
    p.add_argument("--alignment", required=True, help="Codon alignment (FASTA)")
    p.add_argument("--tree", required=True, help="Phylogenetic tree (Newick)")
    p.add_argument("--out", required=True, help="Output JSON file")
    p.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    p.add_argument("--model", default="frozen")

    args = parser.parse_args()

    if args.command == "predict":
        run_inference(
            alignment_path=args.alignment,
            tree_path=args.tree,
            out_path=args.out,
            device=args.device,
            model_tag=args.model,
        )

if __name__ == "__main__":
    main()
