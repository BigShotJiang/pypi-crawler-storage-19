import torch
import json
from importlib.resources import files

def resolve_device(requested="auto"):
    if requested == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but not available.")
        return torch.device("cuda")

    if requested == "cpu":
        return torch.device("cpu")

    if torch.cuda.is_available():
        return torch.device("cuda")

    return torch.device("cpu")

def get_model_path(filename):
    return files("babappaomega.assets.models") / filename

def load_metadata():
    path = files("babappaomega.assets") / "metadata.json"
    with open(path) as f:
        return json.load(f)
