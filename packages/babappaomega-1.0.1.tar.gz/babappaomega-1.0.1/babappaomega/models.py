import hashlib
from pathlib import Path
import urllib.request

from platformdirs import user_cache_dir

ZENODO_MODELS = {
    "frozen": {
        "url": "https://zenodo.org/record/18195869/files/BABAPPAomega_frozen.pt",
        "md5": "c99e75cb953ee95e933bfba65e751cb5",
        "doi": "10.5281/zenodo.18195869"
    }
}

def get_cache_dir():
    cache = Path(user_cache_dir("babappaomega"))
    cache.mkdir(parents=True, exist_ok=True)
    return cache

def md5sum(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(8192), b""):
            h.update(block)
    return h.hexdigest()

def ensure_model(model_tag="frozen"):
    if model_tag not in ZENODO_MODELS:
        raise ValueError(f"Unknown model tag: {model_tag}")

    entry = ZENODO_MODELS[model_tag]
    cache_dir = get_cache_dir()
    model_path = cache_dir / f"BABAPPAomega_{model_tag}.pt"

    if model_path.exists():
        if md5sum(model_path) == entry["md5"]:
            return model_path
        else:
            model_path.unlink()

    print(
        f"[BABAPPAΩ] Downloading model '{model_tag}' from Zenodo "
        f"(DOI: {entry['doi']})"
    )

    urllib.request.urlretrieve(entry["url"], model_path)

    if md5sum(model_path) != entry["md5"]:
        model_path.unlink()
        raise RuntimeError("Model download failed MD5 verification")

    return model_path
