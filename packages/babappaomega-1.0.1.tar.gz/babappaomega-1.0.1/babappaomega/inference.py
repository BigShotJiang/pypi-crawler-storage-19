import json
import csv
import os
import torch
import numpy as np
from datetime import datetime

from babappaomega.utils import resolve_device
from babappaomega.encoding import encode_alignment
from babappaomega.tree import load_tree, enumerate_branches
from babappaomega.models import ensure_model


def load_model(model_tag: str, device: torch.device):
    """
    Load TorchScript BABAPPAΩ model from Zenodo.
    """

    if model_tag != "frozen":
        raise ValueError(
            f"Model '{model_tag}' is not available. "
            "Only the frozen reference model is supported."
        )

    model_path = ensure_model(model_tag)

    model = torch.jit.load(model_path, map_location=device)
    model.eval()

    return model



@torch.no_grad()
def run_inference(
    alignment_path: str,
    tree_path: str,
    out_path: str,
    device: str = "auto",
    model_tag: str = "frozen",
):
    """
    Run BABAPPAΩ inference on a codon alignment and phylogenetic tree.
    """

    # -------------------------
    # Device resolution
    # -------------------------
    device = resolve_device(device)

    # -------------------------
    # Load model
    # -------------------------
    model = load_model(model_tag, device)

    # -------------------------
    # Encode inputs
    # -------------------------
    X, ntaxa, L = encode_alignment(alignment_path)
    tree = load_tree(tree_path)
    branches = enumerate_branches(tree)

    X = torch.tensor(X, dtype=torch.long, device=device).unsqueeze(0)

    if device.type == "cpu" and ntaxa > 120:
        print(
            "[BABAPPAΩ WARNING] Large number of taxa detected "
            f"(n={ntaxa}). GPU acceleration is strongly recommended."
        )

    # -------------------------
    # Forward pass (per-branch)
    # -------------------------
    n_branches = len(branches)

    # --- Run ONCE to determine n_regimes ---
    branch_mask = torch.zeros(
        (1, n_branches),
        dtype=torch.long,
        device=device,
    )
    branch_mask[0, 0] = 1

    outputs = model(X, branch_mask)

    det_example, regime_example, _ = outputs

    det_example = det_example.detach().cpu().numpy()[0]
    regime_example = regime_example.detach().cpu().numpy()[0]

    n_regimes = regime_example.shape[-1]

    # --- Allocate matrices ---
    det_matrix = np.zeros((n_branches, L), dtype=float)
    regime_matrix = np.zeros((n_branches, L, n_regimes), dtype=float)

    # --- Fill matrices ---
    for b in range(n_branches):
        branch_mask.zero_()
        branch_mask[0, b] = 1

        outputs = model(X, branch_mask)
        det, regime, _ = outputs

        det = torch.sigmoid(det).detach().cpu().numpy()[0]
        regime = regime.detach().cpu().numpy()[0]

        det_matrix[b] = det[b]
        regime_matrix[b] = regime[b]


    # -------------------------
    # Assemble results (FINAL)
    # -------------------------
    results = []
    for b, branch in enumerate(branches):
        for site in range(L):
            ep = det_matrix[b, site]
            regime_probs = regime_matrix[b, site]

            regime_idx = int(np.argmax(regime_probs))
            rp = float(np.max(regime_probs))

            results.append(
                {
                    "branch": branch,
                    "site": site + 1,
                    "episodic_probability": round(float(ep), 6),
                    "regime": regime_idx,
                    "regime_probability": round(rp, 6),
                }
            )


    # -------------------------
    # Metadata (LOCKED)
    # -------------------------
    metadata = {
        "engine": "BABAPPAΩ",
        "model": model_tag,
        "device": device.type,
        "ntaxa": ntaxa,
        "sites": L,
        "n_branches": len(branches),
        "timestamp_utc": datetime.utcnow().isoformat() + "Z",
        "model_source": "Zenodo",
        "model_doi": "10.5281/zenodo.18195868",
    }

    # -------------------------
    # Write output
    # -------------------------
    ext = os.path.splitext(out_path)[1].lower()

    if ext == ".json":
        with open(out_path, "w") as f:
            json.dump(
                {"metadata": metadata, "results": results},
                f,
                indent=2,
            )

    elif ext in {".csv", ".tsv"}:
        delimiter = "," if ext == ".csv" else "\t"
        with open(out_path, "w", newline="") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "branch",
                    "site",
                    "episodic_probability",
                    "regime",
                    "regime_probability",
                ],
                delimiter=delimiter,
            )
            writer.writeheader()
            writer.writerows(results)

    else:
        raise ValueError(
            f"Unsupported output format '{ext}'. "
            "Use .json, .csv, or .tsv"
        )
