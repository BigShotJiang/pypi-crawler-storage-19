def load_tree(tree_path):
    """
    Load a phylogenetic tree from Newick format.

    ete3 is imported lazily to avoid unnecessary dependencies
    during CLI startup.
    """
    try:
        from ete3 import Tree
    except ImportError as e:
        raise ImportError(
            "The 'ete3' package is required for tree handling. "
            "Install it via: pip install ete3"
        ) from e

    return Tree(tree_path, format=1)


def enumerate_branches(tree):
    """
    Enumerate non-root branches in a stable traversal order.
    """
    branches = []
    for node in tree.traverse():
        if not node.is_root():
            branches.append(node.name or f"node_{id(node)}")
    return branches
