# BABAPPAΩ

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.18197957.svg)](https://doi.org/10.5281/zenodo.18197957)

BABAPPAΩ is a mechanistically grounded inference engine for detecting episodic
positive selection under branch–site models using likelihood-free,
amortized neural inference.

The software provides a production-grade command-line interface for
branch–site scans on codon alignments, with GPU-accelerated inference,
deterministic output, and fully reproducible model distribution.

---

## Key Features

- Branch–site inference of episodic positive selection
- Likelihood-free neural inference without explicit likelihood optimization
- GPU-first execution with automatic CPU fallback
- Deterministic, machine-readable output
- Clean command-line interface suitable for large-scale scans
- Separation of inference software and trained model artifacts
- Reviewer-safe and reproducible distribution strategy

---

## Installation

Install BABAPPAΩ directly from PyPI:

pip install babappaomega

Python version 3.9 or later is required.

---

## Basic Usage

babappaomega predict \
  --alignment alignment.fasta \
  --tree tree.nwk \
  --out results.json

Supported output formats:
- .json
- .csv
- .tsv

Each run performs an exploratory branch–site scan, conditioning on each
branch as foreground in turn.

---

## Output

The output reports results at the branch–site level and includes:

- Posterior probability of episodic positive selection
- Most probable evolutionary regime
- Posterior probability of the inferred regime

Probabilities equal to 1 indicate numerical saturation corresponding to
near-unity posterior support, which may occur for small or low-noise
alignments.

All outputs follow a stable and documented schema to facilitate
downstream filtering, visualization, and statistical analysis.

---

## Model Weights and Reproducibility

The frozen reference model used by BABAPPAΩ is archived on Zenodo:

DOI: 10.5281/zenodo.18195868

The trained model is not bundled with the Python package. On first use:

1. The model is downloaded automatically from Zenodo
2. The archival checksum is verified
3. The model is cached locally
4. Subsequent runs reuse the cached artifact

This design ensures:
- Lightweight PyPI distribution
- Transparent model provenance
- Full reproducibility
- Drop-in replacement for future model versions without API changes

---

## Performance

Inference is GPU-accelerated when a compatible device is available and
automatically falls back to CPU execution otherwise.

The inference engine is designed for high-throughput exploratory scans
across branches and sites.

---

## License

This project is released under the MIT License.

---

## Development Status

The inference engine, command-line interface, packaging, and model
distribution pipeline are finalized and stable.

Ongoing and future work focuses on:
- Benchmarking against classical likelihood-based methods
- Expanded documentation and worked examples
- Large-scale empirical applications

---

## Citation

A manuscript describing BABAPPAΩ is in preparation.

Until publication, please cite the Zenodo record associated with the frozen
reference model.
