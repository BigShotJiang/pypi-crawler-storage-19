"""
Unified LLM Client - Works with any provider via LiteLLM.

Supports 17+ providers including free options (Groq, Cerebras, SambaNova).
Automatically detects available API keys and falls back gracefully.
"""
import os
from typing import List, Dict, Optional
from pathlib import Path

# Try to import LLMProvider (from build/lib during development)
try:
    from zdeps2.core.ai.lite_llm import LLMProvider, PROVIDERS
    LITELLM_AVAILABLE = True
except ImportError:
    try:
        # Fallback to legacy Claude client
        from zdeps2.core.ai.client import ClaudeClient
        LITELLM_AVAILABLE = False
    except ImportError:
        LITELLM_AVAILABLE = False


# Free providers that work without credit card (in priority order)
FREE_PROVIDERS = [
    "groq",       # 500K-1M tokens/day, blazing fast
    "cerebras",   # 1M tokens/day, 8K context on free tier
    "sambanova",  # Free + $5 credits
]

# Paid/premium providers (require credit card)
PAID_PROVIDERS = [
    "anthropic",   # Claude
    "openai",      # GPT-4o
    "xai",         # Grok
    "google",      # Gemini
]


class UnifiedLLMClient:
    """
    Unified LLM client that works with any provider.

    Features:
    - Auto-detects available API keys
    - Defaults to free providers (no credit card needed)
    - Falls back gracefully if LiteLLM not installed
    - Compatible with existing ClaudeClient interface
    """

    def __init__(
        self,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        api_key: Optional[str] = None
    ):
        """
        Initialize unified LLM client.

        Args:
            provider: Provider name ('groq', 'anthropic', 'openai', etc.)
                     If None, auto-detects from available API keys
            model: Model name (e.g., 'llama-3.1-70b-versatile')
                  If None, uses provider's default
            api_key: API key for provider. If None, reads from environment

        Raises:
            ImportError: If LiteLLM not installed
            ValueError: If no API key found for any provider
        """
        if not LITELLM_AVAILABLE:
            raise ImportError(
                "LiteLLM is required for multi-provider support. Install with:\n"
                "  pip install litellm\n\n"
                "Or use legacy ClaudeClient (requires ANTHROPIC_API_KEY)"
            )

        self.llm = LLMProvider()

        # Auto-detect provider if not specified
        if provider is None:
            provider, api_key = self._auto_detect_provider()

        if provider is None:
            raise ValueError(
                "No LLM provider configured. Set one of these environment variables:\n"
                + "\n".join([
                    f"  - {self._get_api_key_env_var(p)}"
                    for p in FREE_PROVIDERS + PAID_PROVIDERS
                ])
            )

        self.provider = provider
        self.api_key = api_key

        # Configure the provider if API key provided
        if api_key:
            self.llm.configure(provider, api_key=api_key)

        # Determine model
        if model is None:
            model = self._get_default_model(provider)

        self.model = self.llm.format_model(provider, model)

    def _auto_detect_provider(self) -> tuple[Optional[str], Optional[str]]:
        """
        Auto-detect which provider to use based on available API keys.

        Priority:
        1. Free providers (Groq, Cerebras, SambaNova)
        2. Paid providers (Claude, OpenAI, etc.)

        Returns:
            (provider_name, api_key) or (None, None) if none found
        """
        # Check free providers first
        for provider in FREE_PROVIDERS:
            api_key = self._get_api_key(provider)
            if api_key:
                return provider, api_key

        # Fall back to paid providers
        for provider in PAID_PROVIDERS:
            api_key = self._get_api_key(provider)
            if api_key:
                return provider, api_key

        return None, None

    def _get_api_key(self, provider: str) -> Optional[str]:
        """Get API key for a provider from environment."""
        env_var = self._get_api_key_env_var(provider)
        return os.getenv(env_var)

    def _get_api_key_env_var(self, provider: str) -> str:
        """Get the environment variable name for a provider's API key."""
        if provider not in PROVIDERS:
            return f"{provider.upper()}_API_KEY"

        info = self.llm.get_provider_info(provider)
        if info and info.credential_env_vars:
            return info.credential_env_vars[0]  # Primary API key

        return f"{provider.upper()}_API_KEY"

    def _get_default_model(self, provider: str) -> str:
        """Get the best default model for a provider."""
        defaults = {
            # Free providers - use fastest/best free model
            "groq": "llama-3.1-70b-versatile",
            "cerebras": "llama-3.3-70b",
            "sambanova": "Meta-Llama-3.1-70B-Instruct",

            # Paid providers - use latest/best model
            "anthropic": "claude-sonnet-4-5-20250514",
            "openai": "gpt-4o",
            "xai": "grok-4",
            "google": "gemini-2.0-flash-exp",
        }

        return defaults.get(provider, self.llm.get_models(provider)[0])

    def analyze(self, messages: List[Dict[str, str]], max_tokens: int = 4000) -> str:
        """
        Send messages to LLM and get response.

        Compatible with ClaudeClient.analyze() interface.

        Args:
            messages: List of message dicts with 'role' and 'content'
            max_tokens: Maximum tokens to generate

        Returns:
            LLM response text
        """
        # LiteLLM handles system messages automatically
        response = self.llm.complete(
            model=self.model,
            messages=messages,
            max_tokens=max_tokens
        )

        # Extract text from response
        return response.choices[0].message.content

    def get_provider_info(self) -> Dict[str, str]:
        """Get information about the current provider."""
        info = self.llm.get_provider_info(self.provider)
        if info:
            return {
                "provider": self.provider,
                "display_name": info.display_name,
                "model": self.model,
                "tags": info.tags,
            }
        return {
            "provider": self.provider,
            "model": self.model,
        }


def get_llm_client(
    provider: Optional[str] = None,
    model: Optional[str] = None,
    api_key: Optional[str] = None
) -> UnifiedLLMClient:
    """
    Factory function to get an LLM client.

    Convenience wrapper around UnifiedLLMClient.__init__().

    Args:
        provider: Provider name (auto-detects if None)
        model: Model name (uses default if None)
        api_key: API key (reads from env if None)

    Returns:
        UnifiedLLMClient instance

    Example:
        # Auto-detect (tries Groq first)
        client = get_llm_client()

        # Explicit provider
        client = get_llm_client(provider="cerebras")

        # Custom model
        client = get_llm_client(provider="groq", model="mixtral-8x7b-32768")
    """
    return UnifiedLLMClient(provider=provider, model=model, api_key=api_key)
