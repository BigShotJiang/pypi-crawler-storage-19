import threading
import requests
from .config import Config

def _post(path, payload):
    try:
        requests.post(
            f"{Config.platform_url}{path}",
            json=payload,
            headers={
                "Authorization": f"Bearer {Config.api_key}"
            },
            timeout=3
        )
    except Exception:
        pass  # Never break client app

def send_async(path, payload):
    threading.Thread(
        target=_post,
        args=(path, payload),
        daemon=True
    ).start()
