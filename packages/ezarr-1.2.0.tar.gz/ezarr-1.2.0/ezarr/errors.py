class InplaceCastingError(Exception):
    pass
