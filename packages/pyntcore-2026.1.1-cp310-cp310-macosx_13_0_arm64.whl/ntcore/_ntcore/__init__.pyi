from __future__ import annotations
import collections.abc
import typing
import typing_extensions
import wpiutil
import wpiutil._wpiutil
import wpiutil._wpiutil.log
from . import meta
__all__: list[str] = ['BooleanArrayEntry', 'BooleanArrayPublisher', 'BooleanArraySubscriber', 'BooleanArrayTopic', 'BooleanEntry', 'BooleanPublisher', 'BooleanSubscriber', 'BooleanTopic', 'ConnectionInfo', 'DoubleArrayEntry', 'DoubleArrayPublisher', 'DoubleArraySubscriber', 'DoubleArrayTopic', 'DoubleEntry', 'DoublePublisher', 'DoubleSubscriber', 'DoubleTopic', 'Event', 'EventFlags', 'FloatArrayEntry', 'FloatArrayPublisher', 'FloatArraySubscriber', 'FloatArrayTopic', 'FloatEntry', 'FloatPublisher', 'FloatSubscriber', 'FloatTopic', 'GenericEntry', 'GenericPublisher', 'GenericSubscriber', 'IntegerArrayEntry', 'IntegerArrayPublisher', 'IntegerArraySubscriber', 'IntegerArrayTopic', 'IntegerEntry', 'IntegerPublisher', 'IntegerSubscriber', 'IntegerTopic', 'LogMessage', 'MultiSubscriber', 'NTSendable', 'NTSendableBuilder', 'NetworkTable', 'NetworkTableEntry', 'NetworkTableInstance', 'NetworkTableListener', 'NetworkTableListenerPoller', 'NetworkTableType', 'PubSubOptions', 'Publisher', 'RawEntry', 'RawPublisher', 'RawSubscriber', 'RawTopic', 'StringArrayEntry', 'StringArrayPublisher', 'StringArraySubscriber', 'StringArrayTopic', 'StringEntry', 'StringPublisher', 'StringSubscriber', 'StringTopic', 'StructArrayEntry', 'StructArrayPublisher', 'StructArraySubscriber', 'StructArrayTopic', 'StructEntry', 'StructPublisher', 'StructSubscriber', 'StructTopic', 'Subscriber', 'TimeSyncEventData', 'TimestampedBoolean', 'TimestampedBooleanArray', 'TimestampedDouble', 'TimestampedDoubleArray', 'TimestampedFloat', 'TimestampedFloatArray', 'TimestampedInteger', 'TimestampedIntegerArray', 'TimestampedRaw', 'TimestampedString', 'TimestampedStringArray', 'TimestampedStruct', 'TimestampedStructArray', 'Topic', 'TopicInfo', 'Value', 'ValueEventData', 'meta']
class BooleanArrayEntry(BooleanArraySubscriber, BooleanArrayPublisher):
    """
    NetworkTables BooleanArray entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> BooleanArrayEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> BooleanArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class BooleanArrayPublisher(Publisher):
    """
    NetworkTables BooleanArray publisher.
    """
    def __enter__(self) -> BooleanArrayPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> BooleanArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: list[typing.SupportsInt], time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: list[typing.SupportsInt]) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class BooleanArraySubscriber(Subscriber):
    """
    NetworkTables BooleanArray subscriber.
    """
    def __enter__(self) -> BooleanArraySubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> list[int]:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: list[typing.SupportsInt]) -> list[int]:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedBooleanArray:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: list[typing.SupportsInt]) -> TimestampedBooleanArray:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> BooleanArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedBooleanArray]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class BooleanArrayTopic(Topic):
    """
    NetworkTables BooleanArray topic.
    """
    kTypeString: typing.ClassVar[str] = 'boolean[]'
    def __enter__(self) -> BooleanArrayTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: list[typing.SupportsInt], options: PubSubOptions = ...) -> BooleanArrayEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def getEntryEx(self, typeString: str, defaultValue: list[typing.SupportsInt], options: PubSubOptions = ...) -> BooleanArrayEntry:
        """
        Create a new entry for the topic, with specific type string.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> BooleanArrayPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> BooleanArrayPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: list[typing.SupportsInt], options: PubSubOptions = ...) -> BooleanArraySubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
    def subscribeEx(self, typeString: str, defaultValue: list[typing.SupportsInt], options: PubSubOptions = ...) -> BooleanArraySubscriber:
        """
        Create a new subscriber to the topic, with specific type string.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class BooleanEntry(BooleanSubscriber, BooleanPublisher):
    """
    NetworkTables Boolean entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> BooleanEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> BooleanTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class BooleanPublisher(Publisher):
    """
    NetworkTables Boolean publisher.
    """
    def __enter__(self) -> BooleanPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> BooleanTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: bool, time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: bool) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class BooleanSubscriber(Subscriber):
    """
    NetworkTables Boolean subscriber.
    """
    def __enter__(self) -> BooleanSubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> bool:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: bool) -> bool:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedBoolean:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: bool) -> TimestampedBoolean:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> BooleanTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedBoolean]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class BooleanTopic(Topic):
    """
    NetworkTables Boolean topic.
    """
    kTypeString: typing.ClassVar[str] = 'boolean'
    def __enter__(self) -> BooleanTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: bool, options: PubSubOptions = ...) -> BooleanEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def getEntryEx(self, typeString: str, defaultValue: bool, options: PubSubOptions = ...) -> BooleanEntry:
        """
        Create a new entry for the topic, with specific type string.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> BooleanPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> BooleanPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: bool, options: PubSubOptions = ...) -> BooleanSubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
    def subscribeEx(self, typeString: str, defaultValue: bool, options: PubSubOptions = ...) -> BooleanSubscriber:
        """
        Create a new subscriber to the topic, with specific type string.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class ConnectionInfo:
    """
    NetworkTables Connection Information
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def last_update(self) -> int:
        """
        The last time any update was received from the remote node (same scale as
        returned by nt::Now()).
        """
    @last_update.setter
    def last_update(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def protocol_version(self) -> int:
        """
        The protocol version being used for this connection.  This in protocol
        layer format, so 0x0200 = 2.0, 0x0300 = 3.0).
        """
    @protocol_version.setter
    def protocol_version(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def remote_id(self) -> str:
        """
        The remote identifier (as set on the remote node by
        NetworkTableInstance::StartClient4() or nt::StartClient4()).
        """
    @remote_id.setter
    def remote_id(self, arg0: str) -> None:
        ...
    @property
    def remote_ip(self) -> str:
        """
        The IP address of the remote node.
        """
    @remote_ip.setter
    def remote_ip(self, arg0: str) -> None:
        ...
    @property
    def remote_port(self) -> int:
        """
        The port number of the remote node.
        """
    @remote_port.setter
    def remote_port(self, arg0: typing.SupportsInt) -> None:
        ...
class DoubleArrayEntry(DoubleArraySubscriber, DoubleArrayPublisher):
    """
    NetworkTables DoubleArray entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> DoubleArrayEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> DoubleArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class DoubleArrayPublisher(Publisher):
    """
    NetworkTables DoubleArray publisher.
    """
    def __enter__(self) -> DoubleArrayPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> DoubleArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: list[typing.SupportsFloat], time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: list[typing.SupportsFloat]) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class DoubleArraySubscriber(Subscriber):
    """
    NetworkTables DoubleArray subscriber.
    """
    def __enter__(self) -> DoubleArraySubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> list[float]:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: list[typing.SupportsFloat]) -> list[float]:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedDoubleArray:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: list[typing.SupportsFloat]) -> TimestampedDoubleArray:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> DoubleArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedDoubleArray]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class DoubleArrayTopic(Topic):
    """
    NetworkTables DoubleArray topic.
    """
    kTypeString: typing.ClassVar[str] = 'double[]'
    def __enter__(self) -> DoubleArrayTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: list[typing.SupportsFloat], options: PubSubOptions = ...) -> DoubleArrayEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def getEntryEx(self, typeString: str, defaultValue: list[typing.SupportsFloat], options: PubSubOptions = ...) -> DoubleArrayEntry:
        """
        Create a new entry for the topic, with specific type string.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> DoubleArrayPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> DoubleArrayPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: list[typing.SupportsFloat], options: PubSubOptions = ...) -> DoubleArraySubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
    def subscribeEx(self, typeString: str, defaultValue: list[typing.SupportsFloat], options: PubSubOptions = ...) -> DoubleArraySubscriber:
        """
        Create a new subscriber to the topic, with specific type string.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class DoubleEntry(DoubleSubscriber, DoublePublisher):
    """
    NetworkTables Double entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> DoubleEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> DoubleTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class DoublePublisher(Publisher):
    """
    NetworkTables Double publisher.
    """
    def __enter__(self) -> DoublePublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> DoubleTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: typing.SupportsFloat, time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: typing.SupportsFloat) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class DoubleSubscriber(Subscriber):
    """
    NetworkTables Double subscriber.
    """
    def __enter__(self) -> DoubleSubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> float:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: typing.SupportsFloat) -> float:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedDouble:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: typing.SupportsFloat) -> TimestampedDouble:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> DoubleTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedDouble]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class DoubleTopic(Topic):
    """
    NetworkTables Double topic.
    """
    kTypeString: typing.ClassVar[str] = 'double'
    def __enter__(self) -> DoubleTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: typing.SupportsFloat, options: PubSubOptions = ...) -> DoubleEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def getEntryEx(self, typeString: str, defaultValue: typing.SupportsFloat, options: PubSubOptions = ...) -> DoubleEntry:
        """
        Create a new entry for the topic, with specific type string.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> DoublePublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> DoublePublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: typing.SupportsFloat, options: PubSubOptions = ...) -> DoubleSubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
    def subscribeEx(self, typeString: str, defaultValue: typing.SupportsFloat, options: PubSubOptions = ...) -> DoubleSubscriber:
        """
        Create a new subscriber to the topic, with specific type string.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class Event:
    """
    NetworkTables event
    """
    def __repr__(self) -> str:
        ...
    def is_(self, kind: typing.SupportsInt) -> bool:
        """
        Test event flags.
        
        :param kind: event flag(s) to test
        
        :returns: True if flags matches kind
        """
    @property
    def data(self) -> ntcore._ntcore.ConnectionInfo | ntcore._ntcore.TopicInfo | ntcore._ntcore.ValueEventData | ntcore._ntcore.LogMessage | ntcore._ntcore.TimeSyncEventData:
        ...
    @property
    def flags(self) -> int:
        """
        Event flags (NT_EventFlags). Also indicates the data included with the
        event:
        - NT_EVENT_CONNECTED or NT_EVENT_DISCONNECTED: GetConnectionInfo()
        - NT_EVENT_PUBLISH, NT_EVENT_UNPUBLISH, or NT_EVENT_PROPERTIES:
        GetTopicInfo()
        - NT_EVENT_VALUE, NT_EVENT_VALUE_LOCAL: GetValueData()
        - NT_EVENT_LOGMESSAGE: GetLogMessage()
        - NT_EVENT_TIMESYNC: GetTimeSyncEventData()
        """
    @flags.setter
    def flags(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def listener(self) -> int:
        """
        Listener that triggered this event.
        """
class EventFlags:
    """
    Event notification flags.
    
    The flags are a bitmask and must be OR'ed together to indicate the
    combination of events desired to be received.
    """
    kConnected: typing.ClassVar[int] = 2
    kConnection: typing.ClassVar[int] = 6
    kDisconnected: typing.ClassVar[int] = 4
    kImmediate: typing.ClassVar[int] = 1
    kLogMessage: typing.ClassVar[int] = 256
    kNone: typing.ClassVar[int] = 0
    kProperties: typing.ClassVar[int] = 32
    kPublish: typing.ClassVar[int] = 8
    kTimeSync: typing.ClassVar[int] = 512
    kTopic: typing.ClassVar[int] = 56
    kUnpublish: typing.ClassVar[int] = 16
    kValueAll: typing.ClassVar[int] = 192
    kValueLocal: typing.ClassVar[int] = 128
    kValueRemote: typing.ClassVar[int] = 64
class FloatArrayEntry(FloatArraySubscriber, FloatArrayPublisher):
    """
    NetworkTables FloatArray entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> FloatArrayEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> FloatArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class FloatArrayPublisher(Publisher):
    """
    NetworkTables FloatArray publisher.
    """
    def __enter__(self) -> FloatArrayPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> FloatArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: list[typing.SupportsFloat], time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: list[typing.SupportsFloat]) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class FloatArraySubscriber(Subscriber):
    """
    NetworkTables FloatArray subscriber.
    """
    def __enter__(self) -> FloatArraySubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> list[float]:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: list[typing.SupportsFloat]) -> list[float]:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedFloatArray:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: list[typing.SupportsFloat]) -> TimestampedFloatArray:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> FloatArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedFloatArray]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class FloatArrayTopic(Topic):
    """
    NetworkTables FloatArray topic.
    """
    kTypeString: typing.ClassVar[str] = 'float[]'
    def __enter__(self) -> FloatArrayTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: list[typing.SupportsFloat], options: PubSubOptions = ...) -> FloatArrayEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def getEntryEx(self, typeString: str, defaultValue: list[typing.SupportsFloat], options: PubSubOptions = ...) -> FloatArrayEntry:
        """
        Create a new entry for the topic, with specific type string.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> FloatArrayPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> FloatArrayPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: list[typing.SupportsFloat], options: PubSubOptions = ...) -> FloatArraySubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
    def subscribeEx(self, typeString: str, defaultValue: list[typing.SupportsFloat], options: PubSubOptions = ...) -> FloatArraySubscriber:
        """
        Create a new subscriber to the topic, with specific type string.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class FloatEntry(FloatSubscriber, FloatPublisher):
    """
    NetworkTables Float entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> FloatEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> FloatTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class FloatPublisher(Publisher):
    """
    NetworkTables Float publisher.
    """
    def __enter__(self) -> FloatPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> FloatTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: typing.SupportsFloat, time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: typing.SupportsFloat) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class FloatSubscriber(Subscriber):
    """
    NetworkTables Float subscriber.
    """
    def __enter__(self) -> FloatSubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> float:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: typing.SupportsFloat) -> float:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedFloat:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: typing.SupportsFloat) -> TimestampedFloat:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> FloatTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedFloat]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class FloatTopic(Topic):
    """
    NetworkTables Float topic.
    """
    kTypeString: typing.ClassVar[str] = 'float'
    def __enter__(self) -> FloatTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: typing.SupportsFloat, options: PubSubOptions = ...) -> FloatEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def getEntryEx(self, typeString: str, defaultValue: typing.SupportsFloat, options: PubSubOptions = ...) -> FloatEntry:
        """
        Create a new entry for the topic, with specific type string.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> FloatPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> FloatPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: typing.SupportsFloat, options: PubSubOptions = ...) -> FloatSubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
    def subscribeEx(self, typeString: str, defaultValue: typing.SupportsFloat, options: PubSubOptions = ...) -> FloatSubscriber:
        """
        Create a new subscriber to the topic, with specific type string.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class GenericEntry(GenericSubscriber, GenericPublisher):
    """
    NetworkTables generic entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> GenericEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> Topic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class GenericPublisher(Publisher):
    """
    NetworkTables generic publisher.
    """
    def getTopic(self) -> Topic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: Value) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        """
    def setBoolean(self, value: bool, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    @typing.overload
    def setBooleanArray(self, value: list[bool], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    @typing.overload
    def setBooleanArray(self, value: list[typing.SupportsInt], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setDefault(self, value: Value) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
    def setDefaultBoolean(self, defaultValue: bool) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultBooleanArray(self, defaultValue: list[typing.SupportsInt]) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultDouble(self, defaultValue: typing.SupportsFloat) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultDoubleArray(self, defaultValue: list[typing.SupportsFloat]) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultFloat(self, defaultValue: typing.SupportsFloat) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultFloatArray(self, defaultValue: list[typing.SupportsFloat]) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultInteger(self, defaultValue: typing.SupportsInt) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultIntegerArray(self, defaultValue: list[typing.SupportsInt]) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultRaw(self, defaultValue: typing_extensions.Buffer) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultString(self, defaultValue: str) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultStringArray(self, defaultValue: list[str]) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDouble(self, value: typing.SupportsFloat, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setDoubleArray(self, value: list[typing.SupportsFloat], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setFloat(self, value: typing.SupportsFloat, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setFloatArray(self, value: list[typing.SupportsFloat], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setInteger(self, value: typing.SupportsInt, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setIntegerArray(self, value: list[typing.SupportsInt], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setRaw(self, value: typing_extensions.Buffer, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setString(self, value: str, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setStringArray(self, value: list[str], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
class GenericSubscriber(Subscriber):
    """
    NetworkTables generic subscriber.
    """
    def get(self) -> Value:
        """
        Get the last published value.
        If no value has been published, returns a value with unassigned type.
        
        :returns: value
        """
    def getBoolean(self, defaultValue: bool) -> bool:
        """
        Gets the entry's value as a boolean. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getBooleanArray(self, defaultValue: list[typing.SupportsInt]) -> list[int]:
        """
        Gets the entry's value as a boolean array. If the entry does not exist
        or is of different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
                  
                  .. note:: The returned array is std::vector<int> instead of std::vector<bool>
                     because std::vector<bool> is special-cased in C++.  0 is false, any
                     non-zero value is true.
        """
    def getDouble(self, defaultValue: typing.SupportsFloat) -> float:
        """
        Gets the entry's value as a double. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getDoubleArray(self, defaultValue: list[typing.SupportsFloat]) -> list[float]:
        """
        Gets the entry's value as a double array. If the entry does not exist
        or is of different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getFloat(self, defaultValue: typing.SupportsFloat) -> float:
        """
        Gets the entry's value as a float. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getFloatArray(self, defaultValue: list[typing.SupportsFloat]) -> list[float]:
        """
        Gets the entry's value as a float array. If the entry does not exist
        or is of different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getInteger(self, defaultValue: typing.SupportsInt) -> int:
        """
        Gets the entry's value as a integer. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getIntegerArray(self, defaultValue: list[typing.SupportsInt]) -> list[int]:
        """
        Gets the entry's value as a integer array. If the entry does not exist
        or is of different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getRaw(self, defaultValue: typing_extensions.Buffer) -> bytes:
        """
        Gets the entry's value as a raw. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getString(self, defaultValue: str) -> str:
        """
        Gets the entry's value as a string. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getStringArray(self, defaultValue: list[str]) -> list[str]:
        """
        Gets the entry's value as a string array. If the entry does not exist
        or is of different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getTopic(self) -> Topic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[Value]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class IntegerArrayEntry(IntegerArraySubscriber, IntegerArrayPublisher):
    """
    NetworkTables IntegerArray entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> IntegerArrayEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> IntegerArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class IntegerArrayPublisher(Publisher):
    """
    NetworkTables IntegerArray publisher.
    """
    def __enter__(self) -> IntegerArrayPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> IntegerArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: list[typing.SupportsInt], time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: list[typing.SupportsInt]) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class IntegerArraySubscriber(Subscriber):
    """
    NetworkTables IntegerArray subscriber.
    """
    def __enter__(self) -> IntegerArraySubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> list[int]:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: list[typing.SupportsInt]) -> list[int]:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedIntegerArray:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: list[typing.SupportsInt]) -> TimestampedIntegerArray:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> IntegerArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedIntegerArray]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class IntegerArrayTopic(Topic):
    """
    NetworkTables IntegerArray topic.
    """
    kTypeString: typing.ClassVar[str] = 'int[]'
    def __enter__(self) -> IntegerArrayTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: list[typing.SupportsInt], options: PubSubOptions = ...) -> IntegerArrayEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def getEntryEx(self, typeString: str, defaultValue: list[typing.SupportsInt], options: PubSubOptions = ...) -> IntegerArrayEntry:
        """
        Create a new entry for the topic, with specific type string.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> IntegerArrayPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> IntegerArrayPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: list[typing.SupportsInt], options: PubSubOptions = ...) -> IntegerArraySubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
    def subscribeEx(self, typeString: str, defaultValue: list[typing.SupportsInt], options: PubSubOptions = ...) -> IntegerArraySubscriber:
        """
        Create a new subscriber to the topic, with specific type string.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class IntegerEntry(IntegerSubscriber, IntegerPublisher):
    """
    NetworkTables Integer entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> IntegerEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> IntegerTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class IntegerPublisher(Publisher):
    """
    NetworkTables Integer publisher.
    """
    def __enter__(self) -> IntegerPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> IntegerTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: typing.SupportsInt, time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: typing.SupportsInt) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class IntegerSubscriber(Subscriber):
    """
    NetworkTables Integer subscriber.
    """
    def __enter__(self) -> IntegerSubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> int:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: typing.SupportsInt) -> int:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedInteger:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: typing.SupportsInt) -> TimestampedInteger:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> IntegerTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedInteger]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class IntegerTopic(Topic):
    """
    NetworkTables Integer topic.
    """
    kTypeString: typing.ClassVar[str] = 'int'
    def __enter__(self) -> IntegerTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: typing.SupportsInt, options: PubSubOptions = ...) -> IntegerEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def getEntryEx(self, typeString: str, defaultValue: typing.SupportsInt, options: PubSubOptions = ...) -> IntegerEntry:
        """
        Create a new entry for the topic, with specific type string.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> IntegerPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> IntegerPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: typing.SupportsInt, options: PubSubOptions = ...) -> IntegerSubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
    def subscribeEx(self, typeString: str, defaultValue: typing.SupportsInt, options: PubSubOptions = ...) -> IntegerSubscriber:
        """
        Create a new subscriber to the topic, with specific type string.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class LogMessage:
    """
    NetworkTables log message.
    """
    @property
    def filename(self) -> str:
        """
        The filename of the source file that generated the message.
        """
    @property
    def level(self) -> int:
        """
        Log level of the message.  See NT_LogLevel.
        """
    @level.setter
    def level(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def line(self) -> int:
        """
        The line number in the source file that generated the message.
        """
    @line.setter
    def line(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def message(self) -> str:
        """
        The message.
        """
class MultiSubscriber:
    """
    Subscribe to multiple topics based on one or more topic name prefixes. Can be
    used in combination with NetworkTableListenerPoller to listen for value
    changes across all matching topics.
    """
    def __enter__(self) -> MultiSubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, inst: NetworkTableInstance, prefixes: list[str], options: PubSubOptions = ...) -> None:
        """
        Create a multiple subscriber.
        
        :param inst:     instance
        :param prefixes: topic name prefixes
        :param options:  subscriber options
        """
    def close(self) -> None:
        """
        Destroys the subscriber
        """
class NTSendable(wpiutil._wpiutil.Sendable):
    """
    Interface for NetworkTable Sendable objects.
    """
    def __init__(self) -> None:
        ...
    @typing.overload
    def initSendable(self, builder: NTSendableBuilder) -> None:
        """
        Initializes this Sendable object.
        
        :param builder: sendable builder
        """
    @typing.overload
    def initSendable(self, builder: wpiutil._wpiutil.SendableBuilder) -> None:
        ...
class NTSendableBuilder(wpiutil._wpiutil.SendableBuilder):
    """
    Helper class for building Sendable dashboard representations for
    NetworkTables.
    """
    def __init__(self) -> None:
        ...
    def getBackendKind(self) -> wpiutil._wpiutil.SendableBuilder.BackendKind:
        """
        Gets the kind of backend being used.
        
        :returns: Backend kind
        """
    def getTable(self) -> NetworkTable:
        """
        Get the network table.
        
        :returns: The network table
        """
    def getTopic(self, key: str) -> Topic:
        """
        Add a property without getters or setters.  This can be used to get
        entry handles for the function called by SetUpdateTable().
        
        :param key: property name
        
        :returns: Network table topic
        """
    def setUpdateTable(self, func: collections.abc.Callable[[], None]) -> None:
        """
        Set the function that should be called to update the network table
        for things other than properties.  Note this function is not passed
        the network table object; instead it should use the entry handles
        returned by GetEntry().
        
        :param func: function
        """
class NetworkTable:
    """
    A network table that knows its subtable path.
    @ingroup ntcore_cpp_api
    """
    PATH_SEPARATOR_CHAR: typing.ClassVar[str] = '/'
    @staticmethod
    def basenameKey(key: str) -> str:
        """
        Gets the "base name" of a key. For example, "/foo/bar" becomes "bar".
        If the key has a trailing slash, returns an empty string.
        
        :param key: key
        
        :returns: base name
        """
    @staticmethod
    def getHierarchy(key: str) -> list[str]:
        """
        Gets a list of the names of all the super tables of a given key. For
        example, the key "/foo/bar/baz" has a hierarchy of "/", "/foo",
        "/foo/bar", and "/foo/bar/baz".
        
        :param key: the key
        
        :returns: List of super tables
        """
    @staticmethod
    def normalizeKey(key: str, withLeadingSlash: bool = True) -> str:
        """
        Normalizes an network table key to contain no consecutive slashes and
        optionally start with a leading slash. For example:
        
        <pre><code>
        normalizeKey("/foo/bar", true)  == "/foo/bar"
        normalizeKey("foo/bar", true)   == "/foo/bar"
        normalizeKey("/foo/bar", false) == "foo/bar"
        normalizeKey("foo//bar", false) == "foo/bar"
        </code></pre>
        
        :param key:              the key to normalize
        :param withLeadingSlash: whether or not the normalized key should begin
                                 with a leading slash
        
        :returns: normalized key
        """
    def __contains__(self, arg0: str) -> bool:
        ...
    @typing.overload
    def addListener(self, eventMask: typing.SupportsInt, listener: collections.abc.Callable[[NetworkTable, str, Event], None]) -> int:
        """
        Listen to topics only within this table.
        
        :param eventMask: Bitmask of EventFlags values
        :param listener:  listener to add
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, key: str, eventMask: typing.SupportsInt, listener: collections.abc.Callable[[NetworkTable, str, Event], None]) -> int:
        """
        Listen to a single key.
        
        :param key:       the key name
        :param eventMask: Bitmask of EventFlags values
        :param listener:  listener to add
        
        :returns: Listener handle
        """
    def addSubTableListener(self, listener: collections.abc.Callable[[NetworkTable, str, NetworkTable], None]) -> int:
        """
        Listen for sub-table creation. This calls the listener once for each newly
        created sub-table. It immediately calls the listener for any existing
        sub-tables.
        
        :param listener: listener to add
        
        :returns: Listener handle
        """
    def clearPersistent(self, key: str) -> None:
        """
        Stop making a key's value persistent through program restarts.
        The key cannot be null.
        
        :param key: the key name
        """
    def containsKey(self, key: str) -> bool:
        """
        Determines whether the given key is in this table.
        
        :param key: the key to search for
        
        :returns: true if the table as a value assigned to the given key
        """
    def containsSubTable(self, key: str) -> bool:
        """
        Determines whether there exists a non-empty subtable for this key
        in this table.
        
        :param key: the key to search for
        
        :returns: true if there is a subtable with the key which contains at least
                  one key/subtable of its own
        """
    def getBoolean(self, key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the boolean associated with the given name. If the key does not
        exist or is of different type, it will return the default value.
        
        :param key:          the key to look up
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
        """
    def getBooleanArray(self, key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the boolean array the key maps to. If the key does not exist or is
        of different type, it will return the default value.
        
        :param key:          the key to look up
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
                  
                  .. note:: The returned array is std::vector<int> instead of std::vector<bool>
                     because std::vector<bool> is special-cased in C++.  0 is false, any
                     non-zero value is true.
        """
    def getBooleanArrayTopic(self, name: str) -> BooleanArrayTopic:
        """
        Get boolean[] topic.
        
        :param name: topic name
        
        :returns: BooleanArrayTopic
        """
    def getBooleanTopic(self, name: str) -> BooleanTopic:
        """
        Get boolean topic.
        
        :param name: topic name
        
        :returns: BooleanTopic
        """
    def getDoubleArrayTopic(self, name: str) -> DoubleArrayTopic:
        """
        Get double[] topic.
        
        :param name: topic name
        
        :returns: DoubleArrayTopic
        """
    def getDoubleTopic(self, name: str) -> DoubleTopic:
        """
        Get double topic.
        
        :param name: topic name
        
        :returns: DoubleTopic
        """
    def getEntry(self, key: str) -> NetworkTableEntry:
        """
        Gets the entry for a subkey.
        
        :param key: the key name
        
        :returns: Network table entry.
        """
    def getFloatArrayTopic(self, name: str) -> FloatArrayTopic:
        """
        Get float[] topic.
        
        :param name: topic name
        
        :returns: FloatArrayTopic
        """
    def getFloatTopic(self, name: str) -> FloatTopic:
        """
        Get float topic.
        
        :param name: topic name
        
        :returns: FloatTopic
        """
    def getInstance(self) -> NetworkTableInstance:
        """
        Gets the instance for the table.
        
        :returns: Instance
        """
    def getIntegerArrayTopic(self, name: str) -> IntegerArrayTopic:
        """
        Get integer[] topic.
        
        :param name: topic name
        
        :returns: IntegerArrayTopic
        """
    def getIntegerTopic(self, name: str) -> IntegerTopic:
        """
        Get integer topic.
        
        :param name: topic name
        
        :returns: IntegerTopic
        """
    def getKeys(self, types: typing.SupportsInt = 0) -> list[str]:
        """
        Gets all keys in the table (not including sub-tables).
        
        :param types: bitmask of types; 0 is treated as a "don't care".
        
        :returns: keys currently in the table
        """
    def getNumber(self, key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the number associated with the given name.
        
        :param key:          the key to look up
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
        """
    def getNumberArray(self, key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the number array the key maps to. If the key does not exist or is
        of different type, it will return the default value.
        
        :param key:          the key to look up
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getPath(self) -> str:
        """
        Gets the full path of this table.  Does not include the trailing "/".
        
        :returns: The path (e.g "", "/foo").
        """
    def getRaw(self, key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the raw value (byte array) the key maps to. If the key does not
        exist or is of different type, it will return the default value.
        
        :param key:          the key to look up
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
                  
                  .. note:: This makes a copy of the raw contents.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getRawTopic(self, name: str) -> RawTopic:
        """
        Get raw topic.
        
        :param name: topic name
        
        :returns: BooleanArrayTopic
        """
    def getString(self, key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the string associated with the given name. If the key does not
        exist or is of different type, it will return the default value.
        
        :param key:          the key to look up
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
        """
    def getStringArray(self, key: str, defaultValue: typing.Any) -> typing.Any:
        """
        Returns the string array the key maps to. If the key does not exist or is
        of different type, it will return the default value.
        
        :param key:          the key to look up
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the value associated with the given key or the given default value
                  if there is no value associated with the key
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getStringArrayTopic(self, name: str) -> StringArrayTopic:
        """
        Get String[] topic.
        
        :param name: topic name
        
        :returns: StringArrayTopic
        """
    def getStringTopic(self, name: str) -> StringTopic:
        """
        Get String topic.
        
        :param name: topic name
        
        :returns: StringTopic
        """
    def getStructArrayTopic(self, name: str, type: type) -> StructArrayTopic:
        """
        Gets a raw struct serialized array topic.
        
        :param name: topic name
        :param type: optional struct type info
        
        :returns: Topic
        """
    def getStructTopic(self, name: str, type: type) -> StructTopic:
        """
        Gets a raw struct serialized value topic.
        
        :param name: topic name
        :param type: optional struct type info
        
        :returns: Topic
        """
    def getSubTable(self, key: str) -> NetworkTable:
        """
        Returns the table at the specified key. If there is no table at the
        specified key, it will create a new table
        
        :param key: the key name
        
        :returns: the networktable to be returned
        """
    def getSubTables(self) -> list[str]:
        """
        Gets the names of all subtables in the table.
        
        :returns: subtables currently in the table
        """
    def getTopic(self, name: str) -> Topic:
        """
        Get (generic) topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getTopicInfo(self, types: typing.SupportsInt = 0) -> list[TopicInfo]:
        """
        Gets topic information for all keys in the table (not including
        sub-tables).
        
        :param types: bitmask of types; 0 is treated as a "don't care".
        
        :returns: topic information for keys currently in the table
        """
    def getTopics(self, types: typing.SupportsInt = 0) -> list[Topic]:
        """
        Gets all topics in the table (not including sub-tables).
        
        :param types: bitmask of types; 0 is treated as a "don't care".
        
        :returns: topic for keys currently in the table
        """
    def getValue(self, key: str, value: typing.Any) -> typing.Any:
        ...
    def isPersistent(self, key: str) -> bool:
        """
        Returns whether the value is persistent through program restarts.
        The key cannot be null.
        
        :param key: the key name
        """
    def putBoolean(self, key: str, value: bool) -> bool:
        """
        Put a boolean in the table
        
        :param key:   the key to be assigned to
        :param value: the value that will be assigned
        
        :returns: False if the table key already exists with a different type
        """
    def putBooleanArray(self, key: str, value: list[typing.SupportsInt]) -> bool:
        """
        Put a boolean array in the table
        
        :param key:   the key to be assigned to
        :param value: the value that will be assigned
        
        :returns: False if the table key already exists with a different type
                  
                  .. note:: The array must be of int's rather than of bool's because
                     std::vector<bool> is special-cased in C++.  0 is false, any
                     non-zero value is true.
        """
    def putNumber(self, key: str, value: typing.SupportsFloat) -> bool:
        """
        Put a number in the table
        
        :param key:   the key to be assigned to
        :param value: the value that will be assigned
        
        :returns: False if the table key already exists with a different type
        """
    def putNumberArray(self, key: str, value: list[typing.SupportsFloat]) -> bool:
        """
        Put a number array in the table
        
        :param key:   the key to be assigned to
        :param value: the value that will be assigned
        
        :returns: False if the table key already exists with a different type
        """
    def putRaw(self, key: str, value: typing_extensions.Buffer) -> bool:
        """
        Put a raw value (byte array) in the table
        
        :param key:   the key to be assigned to
        :param value: the value that will be assigned
        
        :returns: False if the table key already exists with a different type
        """
    def putString(self, key: str, value: str) -> bool:
        """
        Put a string in the table
        
        :param key:   the key to be assigned to
        :param value: the value that will be assigned
        
        :returns: False if the table key already exists with a different type
        """
    def putStringArray(self, key: str, value: list[str]) -> bool:
        """
        Put a string array in the table
        
        :param key:   the key to be assigned to
        :param value: the value that will be assigned
        
        :returns: False if the table key already exists with a different type
        """
    @typing.overload
    def putValue(self, key: str, value: typing.SupportsFloat) -> bool:
        ...
    @typing.overload
    def putValue(self, key: str, value: bool) -> bool:
        ...
    @typing.overload
    def putValue(self, key: str, value: bytes) -> bool:
        ...
    @typing.overload
    def putValue(self, key: str, value: str) -> bool:
        ...
    @typing.overload
    def putValue(self, key: str, value: collections.abc.Sequence) -> bool:
        ...
    def removeListener(self, listener: typing.SupportsInt) -> None:
        """
        Remove a listener.
        
        :param listener: listener handle
        """
    def setDefaultBoolean(self, key: str, defaultValue: bool) -> bool:
        """
        Set Default Entry Value
        
        :param key:          the key
        :param defaultValue: the default value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    def setDefaultBooleanArray(self, key: str, defaultValue: list[typing.SupportsInt]) -> bool:
        """
        Set Default Entry Value
        
        :param key:          the key
        :param defaultValue: the default value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    def setDefaultNumber(self, key: str, defaultValue: typing.SupportsFloat) -> bool:
        """
        Set Default Entry Value
        
        :param key:          the key
        :param defaultValue: the default value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    def setDefaultNumberArray(self, key: str, defaultValue: list[typing.SupportsFloat]) -> bool:
        """
        Set Default Entry Value
        
        :param key:          the key
        :param defaultValue: the default value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    def setDefaultRaw(self, key: str, defaultValue: typing_extensions.Buffer) -> bool:
        """
        Set Default Entry Value
        
        :param key:          the key
        :param defaultValue: the default value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    def setDefaultString(self, key: str, defaultValue: str) -> bool:
        """
        Set Default Entry Value
        
        :param key:          the key
        :param defaultValue: the default value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    def setDefaultStringArray(self, key: str, defaultValue: list[str]) -> bool:
        """
        Set Default Entry Value
        
        :param key:          the key
        :param defaultValue: the default value to set if key doesn't exist.
        
        :returns: True if the table key did not already exist, otherwise False
        """
    @typing.overload
    def setDefaultValue(self, key: str, value: typing.SupportsFloat) -> bool:
        ...
    @typing.overload
    def setDefaultValue(self, key: str, value: bool) -> bool:
        ...
    @typing.overload
    def setDefaultValue(self, key: str, value: bytes) -> bool:
        ...
    @typing.overload
    def setDefaultValue(self, key: str, value: str) -> bool:
        ...
    @typing.overload
    def setDefaultValue(self, key: str, value: collections.abc.Sequence) -> bool:
        ...
    def setPersistent(self, key: str) -> None:
        """
        Makes a key's value persistent through program restarts.
        
        :param key: the key to make persistent
        """
class NetworkTableEntry:
    """
    NetworkTables Entry
    
    .. note:: For backwards compatibility, the NetworkTableEntry destructor does not
       release the entry.
    
    @ingroup ntcore_cpp_api
    """
    __hash__: typing.ClassVar[None] = None
    def __eq__(self, arg0: NetworkTableEntry) -> bool:
        """
        Equality operator.  Returns true if both instances refer to the same
        native handle.
        """
    def __repr__(self) -> str:
        ...
    def clearPersistent(self) -> None:
        """
        Stop making value persistent through program restarts.
        """
    def exists(self) -> bool:
        """
        Determines if the entry currently exists.
        
        :returns: True if the entry exists, false otherwise.
        """
    def getBoolean(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a boolean. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getBooleanArray(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a boolean array. If the entry does not exist
        or is of different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
                  
                  .. note:: The returned array is std::vector<int> instead of std::vector<bool>
                     because std::vector<bool> is special-cased in C++.  0 is false, any
                     non-zero value is true.
        """
    def getDouble(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a double. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getDoubleArray(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a double array. If the entry does not exist
        or is of different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getFloat(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a float. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getFloatArray(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a float array. If the entry does not exist
        or is of different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getInstance(self) -> NetworkTableInstance:
        """
        Gets the instance for the entry.
        
        :returns: Instance
        """
    def getInteger(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a integer. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getIntegerArray(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a integer array. If the entry does not exist
        or is of different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getLastChange(self) -> int:
        """
        Gets the last time the entry's value was changed.
        
        :returns: Entry last change time
        """
    def getName(self) -> str:
        """
        Gets the name of the entry (the key).
        
        :returns: the entry's name
        """
    def getRaw(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a raw. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getString(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a string. If the entry does not exist or is of
        different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
        """
    def getStringArray(self, defaultValue: typing.Any) -> typing.Any:
        """
        Gets the entry's value as a string array. If the entry does not exist
        or is of different type, it will return the default value.
        
        :param defaultValue: the value to be returned if no value is found
        
        :returns: the entry's value or the given default value
                  
                  .. note:: This makes a copy of the array.  If the overhead of this is a
                     concern, use GetValue() instead.
        """
    def getTopic(self) -> Topic:
        """
        Gets the entry's topic.
        
        :returns: Topic
        """
    def getType(self) -> NetworkTableType:
        """
        Gets the type of the entry.
        
        :returns: the entry's type
        """
    def getValue(self) -> Value:
        """
        Gets the entry's value. If the entry does not exist, returns an empty
        value.
        
        :returns: the entry's value or an empty value if it does not exist.
        """
    def isPersistent(self) -> bool:
        """
        Returns whether the value is persistent through program restarts.
        
        :returns: True if the value is persistent.
        """
    def readQueue(self) -> list[Value]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        
        The "poll storage" subscribe option can be used to set the queue depth.
        
        :returns: Array of values; empty array if no new changes have been
                  published since the previous call.
        """
    def setBoolean(self, value: bool, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setBooleanArray(self, value: list[bool], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setDefaultBoolean(self, defaultValue: bool) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultBooleanArray(self, defaultValue: list[typing.SupportsInt]) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultDouble(self, defaultValue: typing.SupportsFloat) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultDoubleArray(self, defaultValue: list[typing.SupportsFloat]) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultFloat(self, defaultValue: typing.SupportsFloat) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultFloatArray(self, defaultValue: list[typing.SupportsFloat]) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultInteger(self, defaultValue: typing.SupportsInt) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultIntegerArray(self, defaultValue: list[typing.SupportsInt]) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultRaw(self, defaultValue: typing_extensions.Buffer) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultString(self, defaultValue: str) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    def setDefaultStringArray(self, defaultValue: list[str]) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    @typing.overload
    def setDefaultValue(self, defaultValue: Value) -> bool:
        """
        Sets the entry's value if it does not exist.
        
        :param defaultValue: the default value to set
        
        :returns: True if the entry did not already have a value, otherwise False
        """
    @typing.overload
    def setDefaultValue(self, value: typing.SupportsFloat) -> bool:
        ...
    @typing.overload
    def setDefaultValue(self, value: bool) -> bool:
        ...
    @typing.overload
    def setDefaultValue(self, value: bytes) -> bool:
        ...
    @typing.overload
    def setDefaultValue(self, value: str) -> bool:
        ...
    @typing.overload
    def setDefaultValue(self, value: collections.abc.Sequence) -> bool:
        ...
    def setDouble(self, value: typing.SupportsFloat, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setDoubleArray(self, value: list[typing.SupportsFloat], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setFloat(self, value: typing.SupportsFloat, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setFloatArray(self, value: list[typing.SupportsFloat], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setInteger(self, value: typing.SupportsInt, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setIntegerArray(self, value: list[typing.SupportsInt], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setPersistent(self) -> None:
        """
        Make value persistent through program restarts.
        """
    def setRaw(self, value: typing_extensions.Buffer, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setString(self, value: str, time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    def setStringArray(self, value: list[str], time: typing.SupportsInt = 0) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        :param time:  the timestamp to set (0 = nt::Now())
        
        :returns: False if the entry exists with a different type
        """
    @typing.overload
    def setValue(self, value: Value) -> bool:
        """
        Sets the entry's value.
        
        :param value: the value to set
        
        :returns: False if the entry exists with a different type
        """
    @typing.overload
    def setValue(self, value: typing.SupportsFloat) -> bool:
        ...
    @typing.overload
    def setValue(self, value: bool) -> bool:
        ...
    @typing.overload
    def setValue(self, value: bytes) -> bool:
        ...
    @typing.overload
    def setValue(self, value: str) -> bool:
        ...
    @typing.overload
    def setValue(self, value: collections.abc.Sequence) -> bool:
        ...
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's been published.
        """
    @property
    def value(self) -> typing.Any:
        ...
class NetworkTableInstance:
    """
    NetworkTables Instance.
    
    Instances are completely independent from each other.  Table operations on
    one instance will not be visible to other instances unless the instances are
    connected via the network.  The main limitation on instances is that you
    cannot have two servers on the same network port.  The main utility of
    instances is for unit testing, but they can also enable one program to
    connect to two different NetworkTables networks.
    
    The global "default" instance (as returned by GetDefault()) is
    always available, and is intended for the common case when there is only
    a single NetworkTables instance being used in the program.  The
    default instance cannot be destroyed.
    
    Additional instances can be created with the Create() function.
    Instances are not reference counted or RAII.  Instead, they must be
    explicitly destroyed (with Destroy()).
    
    @ingroup ntcore_cpp_api
    """
    class LogLevel:
        """
        Logging levels (as used by SetLogger()).
        
        Members:
        
          kLogCritical
        
          kLogError
        
          kLogWarning
        
          kLogInfo
        
          kLogDebug
        
          kLogDebug1
        
          kLogDebug2
        
          kLogDebug3
        
          kLogDebug4
        """
        __members__: typing.ClassVar[dict[str, NetworkTableInstance.LogLevel]]  # value = {'kLogCritical': <LogLevel.kLogCritical: 50>, 'kLogError': <LogLevel.kLogError: 40>, 'kLogWarning': <LogLevel.kLogWarning: 30>, 'kLogInfo': <LogLevel.kLogInfo: 20>, 'kLogDebug': <LogLevel.kLogDebug: 10>, 'kLogDebug1': <LogLevel.kLogDebug1: 9>, 'kLogDebug2': <LogLevel.kLogDebug2: 8>, 'kLogDebug3': <LogLevel.kLogDebug3: 7>, 'kLogDebug4': <LogLevel.kLogDebug4: 6>}
        kLogCritical: typing.ClassVar[NetworkTableInstance.LogLevel]  # value = <LogLevel.kLogCritical: 50>
        kLogDebug: typing.ClassVar[NetworkTableInstance.LogLevel]  # value = <LogLevel.kLogDebug: 10>
        kLogDebug1: typing.ClassVar[NetworkTableInstance.LogLevel]  # value = <LogLevel.kLogDebug1: 9>
        kLogDebug2: typing.ClassVar[NetworkTableInstance.LogLevel]  # value = <LogLevel.kLogDebug2: 8>
        kLogDebug3: typing.ClassVar[NetworkTableInstance.LogLevel]  # value = <LogLevel.kLogDebug3: 7>
        kLogDebug4: typing.ClassVar[NetworkTableInstance.LogLevel]  # value = <LogLevel.kLogDebug4: 6>
        kLogError: typing.ClassVar[NetworkTableInstance.LogLevel]  # value = <LogLevel.kLogError: 40>
        kLogInfo: typing.ClassVar[NetworkTableInstance.LogLevel]  # value = <LogLevel.kLogInfo: 20>
        kLogWarning: typing.ClassVar[NetworkTableInstance.LogLevel]  # value = <LogLevel.kLogWarning: 30>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class NetworkMode:
        """
        Client/server mode flag values (as returned by GetNetworkMode()).
        This is a bitmask.
        
        Members:
        
          kNetModeNone
        
          kNetModeServer
        
          kNetModeClient3
        
          kNetModeClient4
        
          kNetModeLocal
        
          kNetModeStarting
        """
        __members__: typing.ClassVar[dict[str, NetworkTableInstance.NetworkMode]]  # value = {'kNetModeNone': <NetworkMode.kNetModeNone: 0>, 'kNetModeServer': <NetworkMode.kNetModeServer: 1>, 'kNetModeClient3': <NetworkMode.kNetModeClient3: 2>, 'kNetModeClient4': <NetworkMode.kNetModeClient4: 4>, 'kNetModeLocal': <NetworkMode.kNetModeLocal: 16>, 'kNetModeStarting': <NetworkMode.kNetModeStarting: 8>}
        kNetModeClient3: typing.ClassVar[NetworkTableInstance.NetworkMode]  # value = <NetworkMode.kNetModeClient3: 2>
        kNetModeClient4: typing.ClassVar[NetworkTableInstance.NetworkMode]  # value = <NetworkMode.kNetModeClient4: 4>
        kNetModeLocal: typing.ClassVar[NetworkTableInstance.NetworkMode]  # value = <NetworkMode.kNetModeLocal: 16>
        kNetModeNone: typing.ClassVar[NetworkTableInstance.NetworkMode]  # value = <NetworkMode.kNetModeNone: 0>
        kNetModeServer: typing.ClassVar[NetworkTableInstance.NetworkMode]  # value = <NetworkMode.kNetModeServer: 1>
        kNetModeStarting: typing.ClassVar[NetworkTableInstance.NetworkMode]  # value = <NetworkMode.kNetModeStarting: 8>
        def __and__(self, other: typing.Any) -> typing.Any:
            ...
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __ge__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __gt__(self, other: typing.Any) -> bool:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __invert__(self) -> typing.Any:
            ...
        def __le__(self, other: typing.Any) -> bool:
            ...
        def __lt__(self, other: typing.Any) -> bool:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __or__(self, other: typing.Any) -> typing.Any:
            ...
        def __rand__(self, other: typing.Any) -> typing.Any:
            ...
        def __repr__(self) -> str:
            ...
        def __ror__(self, other: typing.Any) -> typing.Any:
            ...
        def __rxor__(self, other: typing.Any) -> typing.Any:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        def __xor__(self, other: typing.Any) -> typing.Any:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    __hash__: typing.ClassVar[None] = None
    kDefaultPort3: typing.ClassVar[int] = 1735
    kDefaultPort4: typing.ClassVar[int] = 5810
    @staticmethod
    def create() -> NetworkTableInstance:
        """
        Create an instance.
        
        :returns: Newly created instance
        """
    @staticmethod
    def destroy(inst: NetworkTableInstance) -> None:
        """
        Destroys an instance (note: this has global effect).
        
        :param inst: Instance
        """
    @staticmethod
    def getDefault() -> NetworkTableInstance:
        """
        Get global default instance.
        
        :returns: Global default instance
        """
    @staticmethod
    def removeListener(listener: typing.SupportsInt) -> None:
        """
        Remove a listener.
        
        :param listener: Listener handle to remove
        """
    @staticmethod
    def stopConnectionDataLog(logger: typing.SupportsInt) -> None:
        """
        Stops logging connection changes to a DataLog.
        
        :param logger: data logger handle
        """
    @staticmethod
    def stopEntryDataLog(logger: typing.SupportsInt) -> None:
        """
        Stops logging entry changes to a DataLog.
        
        :param logger: data logger handle
        """
    def __eq__(self, arg0: NetworkTableInstance) -> bool:
        """
        Equality operator.  Returns true if both instances refer to the same
        native handle.
        """
    def _getHandle(self) -> int:
        """
        Gets the native handle for the entry.
        
        :returns: Native handle
        """
    def _reset(self) -> None:
        ...
    def addConnectionListener(self, immediate_notify: bool, callback: collections.abc.Callable[[Event], None]) -> int:
        """
        Add a connection listener. The callback function is called asynchronously
        on a separate thread, so it's important to use synchronization or atomics
        when accessing any shared state from the callback function.
        
        :param immediate_notify: notify listener of all existing connections
        :param callback:         listener to add
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, topic: Topic, eventMask: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> int:
        """
        Add a listener for changes on a particular topic. The callback
        function is called asynchronously on a separate thread, so it's important
        to use synchronization or atomics when accessing any shared state from the
        callback function.
        
        This creates a corresponding internal subscriber with the lifetime of the
        listener.
        
        :param topic:     Topic
        :param eventMask: Bitmask of EventFlags values
        :param listener:  Listener function
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, subscriber: Subscriber, eventMask: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> int:
        """
        Add a listener for changes on a subscriber. The callback
        function is called asynchronously on a separate thread, so it's important
        to use synchronization or atomics when accessing any shared state from the
        callback function. This does NOT keep the subscriber active.
        
        :param subscriber: Subscriber
        :param eventMask:  Bitmask of EventFlags values
        :param listener:   Listener function
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, subscriber: MultiSubscriber, eventMask: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> int:
        """
        Add a listener for changes on a subscriber. The callback
        function is called asynchronously on a separate thread, so it's important
        to use synchronization or atomics when accessing any shared state from the
        callback function. This does NOT keep the subscriber active.
        
        :param subscriber: Subscriber
        :param eventMask:  Bitmask of EventFlags values
        :param listener:   Listener function
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, entry: NetworkTableEntry, eventMask: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> int:
        """
        Add a listener for changes on an entry. The callback function
        is called asynchronously on a separate thread, so it's important to use
        synchronization or atomics when accessing any shared state from the
        callback function.
        
        :param entry:     Entry
        :param eventMask: Bitmask of EventFlags values
        :param listener:  Listener function
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, prefixes: list[str], eventMask: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> int:
        """
        Add a listener for changes to topics with names that start with any
        of the given prefixes. The callback function is called asynchronously on a
        separate thread, so it's important to use synchronization or atomics when
        accessing any shared state from the callback function.
        
        This creates a corresponding internal subscriber with the lifetime of the
        listener.
        
        :param prefixes:  Topic name string prefixes
        :param eventMask: Bitmask of EventFlags values
        :param listener:  Listener function
        
        :returns: Listener handle
        """
    def addLogger(self, minLevel: typing.SupportsInt, maxLevel: typing.SupportsInt, func: collections.abc.Callable[[Event], None]) -> int:
        """
        Add logger callback function.  By default, log messages are sent to stderr;
        this function sends log messages with the specified levels to the provided
        callback function instead.  The callback function will only be called for
        log messages with level greater than or equal to minLevel and less than or
        equal to maxLevel; messages outside this range will be silently ignored.
        
        :param minLevel: minimum log level
        :param maxLevel: maximum log level
        :param func:     callback function
        
        :returns: Listener handle
        """
    @typing.overload
    def addSchema(self, name: str, type: str, schema: typing_extensions.Buffer) -> None:
        """
        Registers a data schema.  Data schemas provide information for how a
        certain data type string can be decoded.  The type string of a data schema
        indicates the type of the schema itself (e.g. "protobuf" for protobuf
        schemas, "struct" for struct schemas, etc). In NetworkTables, schemas are
        published just like normal topics, with the name being generated from the
        provided name: "/.schema/<name>".  Duplicate calls to this function with
        the same name are silently ignored.
        
        :param name:   Name (the string passed as the data type for topics using this
                       schema)
        :param type:   Type of schema (e.g. "protobuf", "struct", etc)
        :param schema: Schema data
        """
    @typing.overload
    def addSchema(self, name: str, type: str, schema: str) -> None:
        """
        Registers a data schema.  Data schemas provide information for how a
        certain data type string can be decoded.  The type string of a data schema
        indicates the type of the schema itself (e.g. "protobuf" for protobuf
        schemas, "struct" for struct schemas, etc). In NetworkTables, schemas are
        published just like normal topics, with the name being generated from the
        provided name: "/.schema/<name>".  Duplicate calls to this function with
        the same name are silently ignored.
        
        :param name:   Name (the string passed as the data type for topics using this
                       schema)
        :param type:   Type of schema (e.g. "protobuf", "struct", etc)
        :param schema: Schema data
        """
    def addTimeSyncListener(self, immediate_notify: bool, callback: collections.abc.Callable[[Event], None]) -> int:
        """
        Add a time synchronization listener. The callback function is called
        asynchronously on a separate thread, so it's important to use
        synchronization or atomics when accessing any shared state from the
        callback function.
        
        :param immediate_notify: notify listener of current time synchronization
                                 value
        :param callback:         listener to add
        
        :returns: Listener handle
        """
    def configPythonLogging(self, *, min: NetworkTableInstance.LogLevel = ..., max: NetworkTableInstance.LogLevel = ..., name: str = 'nt') -> None:
        """
        Configure python logging for this instance.
        
        :param min:  Minimum NT level to log
        :param max:  Maximum NT level to log
        :param name: Name of python logger
        
        .. note:: This must be called before the instance is started
        """
    def disconnect(self) -> None:
        """
        Disconnects the client if it's running and connected. This will
        automatically start reconnection attempts to the current server list.
        """
    def flush(self) -> None:
        """
        Flushes all updated values immediately to the network.
        .. note:: This is rate-limited to protect the network from flooding.
           This is primarily useful for synchronizing network updates with
           user code.
        """
    def flushLocal(self) -> None:
        """
        Flushes all updated values immediately to the local client/server. This
        does not flush to the network.
        """
    def getBooleanArrayTopic(self, name: str) -> BooleanArrayTopic:
        """
        Gets a boolean array topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getBooleanTopic(self, name: str) -> BooleanTopic:
        """
        Gets a boolean topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getConnections(self) -> list[ConnectionInfo]:
        """
        Get information on the currently established network connections.
        If operating as a client, this will return either zero or one values.
        
        :returns: array of connection information
        """
    def getDoubleArrayTopic(self, name: str) -> DoubleArrayTopic:
        """
        Gets a double array topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getDoubleTopic(self, name: str) -> DoubleTopic:
        """
        Gets a double topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getEntry(self, name: str) -> NetworkTableEntry:
        """
        Gets the entry for a key.
        
        :param name: Key
        
        :returns: Network table entry.
        """
    def getFloatArrayTopic(self, name: str) -> FloatArrayTopic:
        """
        Gets a float array topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getFloatTopic(self, name: str) -> FloatTopic:
        """
        Gets a float topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getIntegerArrayTopic(self, name: str) -> IntegerArrayTopic:
        """
        Gets an integer array topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getIntegerTopic(self, name: str) -> IntegerTopic:
        """
        Gets an integer topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getNetworkMode(self) -> int:
        """
        Get the current network mode.
        
        :returns: Bitmask of NetworkMode.
        """
    def getRawTopic(self, name: str) -> RawTopic:
        """
        Gets a raw topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getServerTimeOffset(self) -> int | None:
        """
        Get the time offset between server time and local time. Add this value to
        local time to get the estimated equivalent server time. In server mode,
        this always returns 0. In client mode, this returns the time offset only if
        the client and server are connected and have exchanged synchronization
        messages. Note the time offset may change over time as it is periodically
        updated; to receive updates as events, add a listener to the "time sync"
        event.
        
        :returns: Time offset in microseconds (optional)
        """
    def getStringArrayTopic(self, name: str) -> StringArrayTopic:
        """
        Gets a string array topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getStringTopic(self, name: str) -> StringTopic:
        """
        Gets a string topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    def getStructArrayTopic(self, name: str, type: type) -> StructArrayTopic:
        """
        Gets a raw struct serialized array topic.
        
        :param name: topic name
        :param type: optional struct type info
        
        :returns: Topic
        """
    def getStructTopic(self, name: str, type: type) -> StructTopic:
        """
        Gets a raw struct serialized value topic.
        
        :param name: topic name
        :param type: optional struct type info
        
        :returns: Topic
        """
    def getTable(self, key: str) -> NetworkTable:
        """
        Gets the table with the specified key.
        
        :param key: the key name
        
        :returns: The network table
        """
    def getTopic(self, name: str) -> Topic:
        """
        Gets a "generic" (untyped) topic.
        
        :param name: topic name
        
        :returns: Topic
        """
    @typing.overload
    def getTopicInfo(self) -> list[TopicInfo]:
        """
        Get Topic Information about multiple topics.
        
        Returns an array of topic information (handle, name, type, and properties).
        
        :returns: Array of topic information.
        """
    @typing.overload
    def getTopicInfo(self, prefix: str) -> list[TopicInfo]:
        """
        Get Topic Information about multiple topics.
        
        Returns an array of topic information (handle, name, type, and properties).
        The results are filtered by string prefix to only
        return a subset of all topics.
        
        :param prefix: name required prefix; only topics whose name
                       starts with this string are returned
        
        :returns: Array of topic information.
        """
    @typing.overload
    def getTopicInfo(self, prefix: str, types: typing.SupportsInt) -> list[TopicInfo]:
        """
        Get Topic Information about multiple topics.
        
        Returns an array of topic information (handle, name, type, and properties).
        The results are filtered by string prefix and type to only
        return a subset of all topics.
        
        :param prefix: name required prefix; only topics whose name
                       starts with this string are returned
        :param types:  bitmask of NT_Type values; 0 is treated specially
                       as a "don't care"
        
        :returns: Array of topic information.
        """
    @typing.overload
    def getTopicInfo(self, prefix: str, types: list[str]) -> list[TopicInfo]:
        """
        Get Topic Information about multiple topics.
        
        Returns an array of topic information (handle, name, type, and properties).
        The results are filtered by string prefix and type to only
        return a subset of all topics.
        
        :param prefix: name required prefix; only topics whose name
                       starts with this string are returned
        :param types:  array of type strings
        
        :returns: Array of topic information.
        """
    @typing.overload
    def getTopics(self) -> list[Topic]:
        """
        Get Published Topics.
        
        Returns an array of topics.
        
        :returns: Array of topics.
        """
    @typing.overload
    def getTopics(self, prefix: str) -> list[Topic]:
        """
        Get Published Topics.
        
        Returns an array of topics.  The results are filtered by
        string prefix to only return a subset of all topics.
        
        :param prefix: name required prefix; only topics whose name
                       starts with this string are returned
        
        :returns: Array of topics.
        """
    @typing.overload
    def getTopics(self, prefix: str, types: typing.SupportsInt) -> list[Topic]:
        """
        Get Published Topics.
        
        Returns an array of topics.  The results are filtered by
        string prefix and type to only return a subset of all topics.
        
        :param prefix: name required prefix; only topics whose name
                       starts with this string are returned
        :param types:  bitmask of NT_Type values; 0 is treated specially
                       as a "don't care"
        
        :returns: Array of topics.
        """
    @typing.overload
    def getTopics(self, prefix: str, types: list[str]) -> list[Topic]:
        """
        Get Published Topics.
        
        Returns an array of topics.  The results are filtered by
        string prefix and type to only return a subset of all topics.
        
        :param prefix: name required prefix; only topics whose name
                       starts with this string are returned
        :param types:  array of type strings
        
        :returns: Array of topic handles.
        """
    def hasSchema(self, name: str) -> bool:
        """
        Returns whether there is a data schema already registered with the given
        name. This does NOT perform a check as to whether the schema has already
        been published by another node on the network.
        
        :param name: Name (the string passed as the data type for topics using this
                     schema)
        
        :returns: True if schema already registered
        """
    def isConnected(self) -> bool:
        """
        Return whether or not the instance is connected to another node.
        
        :returns: True if connected.
        """
    @typing.overload
    def setServer(self, server_name: str, port: typing.SupportsInt = 0) -> None:
        """
        Sets server address and port for client (without restarting client).
        
        :param server_name: server name (UTF-8 string)
        :param port:        port to communicate over (0 = default)
        """
    @typing.overload
    def setServer(self, servers: list[tuple[str, typing.SupportsInt]]) -> None:
        """
        Sets server addresses and ports for client (without restarting client).
        The client will attempt to connect to each server in round robin fashion.
        
        :param servers: array of server address and port pairs
        """
    @typing.overload
    def setServer(self, servers: list[str], port: typing.SupportsInt = 0) -> None:
        """
        Sets server addresses and port for client (without restarting client).
        The client will attempt to connect to each server in round robin fashion.
        
        :param servers: array of server names
        :param port:    port to communicate over (0 = default)
        """
    def setServerTeam(self, team: typing.SupportsInt, port: typing.SupportsInt = 0) -> None:
        """
        Sets server addresses and port for client (without restarting client).
        Connects using commonly known robot addresses for the specified team.
        
        :param team: team number
        :param port: port to communicate over (0 = default)
        """
    def startClient3(self, identity: str) -> None:
        """
        Starts a NT3 client.  Use SetServer or SetServerTeam to set the server name
        and port.
        
        :param identity: network identity to advertise (cannot be empty string)
        """
    def startClient4(self, identity: str) -> None:
        """
        Starts a NT4 client.  Use SetServer or SetServerTeam to set the server name
        and port.
        
        :param identity: network identity to advertise (cannot be empty string)
        """
    def startConnectionDataLog(self, log: wpiutil._wpiutil.log.DataLog, name: str) -> int:
        """
        Starts logging connection changes to a DataLog.
        
        :param log:  data log object; lifetime must extend until
                     StopConnectionDataLog is called or the instance is destroyed
        :param name: data log entry name
        
        :returns: Data logger handle
        """
    def startDSClient(self, port: typing.SupportsInt = 0) -> None:
        """
        Starts requesting server address from Driver Station.
        This connects to the Driver Station running on localhost to obtain the
        server IP address.
        
        :param port: server port to use in combination with IP from DS (0 = default)
        """
    def startEntryDataLog(self, log: wpiutil._wpiutil.log.DataLog, prefix: str, logPrefix: str) -> int:
        """
        Starts logging entry changes to a DataLog.
        
        :param log:       data log object; lifetime must extend until StopEntryDataLog is
                          called or the instance is destroyed
        :param prefix:    only store entries with names that start with this prefix;
                          the prefix is not included in the data log entry name
        :param logPrefix: prefix to add to data log entry names
        
        :returns: Data logger handle
        """
    def startLocal(self) -> None:
        """
        Starts local-only operation.  Prevents calls to StartServer or StartClient
        from taking effect.  Has no effect if StartServer or StartClient
        has already been called.
        """
    def startServer(self, persist_filename: str = 'networktables.json', listen_address: str = '', port3: typing.SupportsInt = 1735, port4: typing.SupportsInt = 5810) -> None:
        """
        Starts a server using the specified filename, listening address, and port.
        
        :param persist_filename: the name of the persist file to use (UTF-8 string,
                                 null terminated)
        :param listen_address:   the address to listen on, or null to listen on any
                                 address (UTF-8 string, null terminated)
        :param port3:            port to communicate over (NT3)
        :param port4:            port to communicate over (NT4)
        """
    def stopClient(self) -> None:
        """
        Stops the client if it is running.
        """
    def stopDSClient(self) -> None:
        """
        Stops requesting server address from Driver Station.
        """
    def stopLocal(self) -> None:
        """
        Stops local-only operation.  StartServer or StartClient can be called after
        this call to start a server or client.
        """
    def stopServer(self) -> None:
        """
        Stops the server if it is running.
        """
    def waitForListenerQueue(self, timeout: typing.SupportsFloat) -> bool:
        """
        Wait for the listener queue to be empty. This is primarily
        useful for deterministic testing. This blocks until either the
        listener queue is empty (e.g. there are no more events that need to be
        passed along to callbacks or poll queues) or the timeout expires.
        
        :param timeout: timeout, in seconds. Set to 0 for non-blocking behavior, or
                        a negative value to block indefinitely
        
        :returns: False if timed out, otherwise true.
        """
class NetworkTableListener:
    """
    Event listener. This calls back to a callback function when an event
    matching the specified mask occurs. The callback function is called
    asynchronously on a separate thread, so it's important to use synchronization
    or atomics when accessing any shared state from the callback function.
    """
    @staticmethod
    def createConnectionListener(inst: NetworkTableInstance, immediate_notify: bool, listener: collections.abc.Callable[[Event], None]) -> NetworkTableListener:
        """
        Create a connection listener.
        
        :param inst:             instance
        :param immediate_notify: notify listener of all existing connections
        :param listener:         listener function
        
        :returns: Listener
        """
    @staticmethod
    @typing.overload
    def createListener(inst: NetworkTableInstance, prefixes: list[str], mask: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> NetworkTableListener:
        """
        Create a listener for changes to topics with names that start with any of
        the given prefixes. This creates a corresponding internal subscriber with
        the lifetime of the listener.
        
        :param inst:     Instance
        :param prefixes: Topic name string prefixes
        :param mask:     Bitmask of EventFlags values
        :param listener: Listener function
        
        :returns: Listener
        """
    @staticmethod
    @typing.overload
    def createListener(topic: Topic, mask: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> NetworkTableListener:
        """
        Create a listener for changes on a particular topic. This creates a
        corresponding internal subscriber with the lifetime of the listener.
        
        :param topic:    Topic
        :param mask:     Bitmask of EventFlags values
        :param listener: Listener function
        
        :returns: Listener
        """
    @staticmethod
    @typing.overload
    def createListener(subscriber: Subscriber, mask: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> NetworkTableListener:
        """
        Create a listener for topic changes on a subscriber. This does NOT keep the
        subscriber active.
        
        :param subscriber: Subscriber
        :param mask:       Bitmask of EventFlags values
        :param listener:   Listener function
        
        :returns: Listener
        """
    @staticmethod
    @typing.overload
    def createListener(subscriber: MultiSubscriber, mask: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> NetworkTableListener:
        """
        Create a listener for topic changes on a subscriber. This does NOT keep the
        subscriber active.
        
        :param subscriber: Subscriber
        :param mask:       Bitmask of EventFlags values
        :param listener:   Listener function
        
        :returns: Listener
        """
    @staticmethod
    @typing.overload
    def createListener(entry: NetworkTableEntry, mask: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> NetworkTableListener:
        """
        Create a listener for topic changes on an entry.
        
        :param entry:    Entry
        :param mask:     Bitmask of EventFlags values
        :param listener: Listener function
        
        :returns: Listener
        """
    @staticmethod
    def createLogger(inst: NetworkTableInstance, minLevel: typing.SupportsInt, maxLevel: typing.SupportsInt, listener: collections.abc.Callable[[Event], None]) -> NetworkTableListener:
        """
        Create a listener for log messages.  By default, log messages are sent to
        stderr; this function sends log messages with the specified levels to the
        provided callback function instead.  The callback function will only be
        called for log messages with level greater than or equal to minLevel and
        less than or equal to maxLevel; messages outside this range will be
        silently ignored.
        
        :param inst:     instance
        :param minLevel: minimum log level
        :param maxLevel: maximum log level
        :param listener: listener function
        
        :returns: Listener
        """
    @staticmethod
    def createTimeSyncListener(inst: NetworkTableInstance, immediate_notify: bool, listener: collections.abc.Callable[[Event], None]) -> NetworkTableListener:
        """
        Create a time synchronization listener.
        
        :param inst:             instance
        :param immediate_notify: notify listener of current time synchronization
                                 value
        :param listener:         listener function
        
        :returns: Listener
        """
    def __enter__(self) -> NetworkTableListener:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the listener
        """
    def getHandle(self) -> int:
        """
        Gets the native handle.
        
        :returns: Handle
        """
    def waitForQueue(self, timeout: typing.SupportsFloat) -> bool:
        """
        Wait for the listener queue to be empty. This is primarily useful for
        deterministic testing. This blocks until either the listener queue is
        empty (e.g. there are no more events that need to be passed along to
        callbacks or poll queues) or the timeout expires.
        
        :param timeout: timeout, in seconds. Set to 0 for non-blocking behavior, or
                        a negative value to block indefinitely
        
        :returns: False if timed out, otherwise true.
        """
class NetworkTableListenerPoller:
    """
    Event polled listener. This queues events matching the specified mask. Code
    using the listener must periodically call ReadQueue() to read the
    events.
    """
    def __enter__(self) -> NetworkTableListenerPoller:
        ...
    def __exit__(self, *args) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, inst: NetworkTableInstance) -> None:
        """
        Construct a listener poller.
        
        :param inst: Instance
        """
    def addConnectionListener(self, immediate_notify: bool) -> int:
        """
        Add a connection listener. The callback function is called asynchronously
        on a separate thread, so it's important to use synchronization or atomics
        when accessing any shared state from the callback function.
        
        :param immediate_notify: notify listener of all existing connections
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, prefixes: list[str], mask: typing.SupportsInt) -> int:
        """
        Start listening to topic changes for topics with names that start with any
        of the given prefixes. This creates a corresponding internal subscriber
        with the lifetime of the listener.
        
        :param prefixes: Topic name string prefixes
        :param mask:     Bitmask of EventFlags values
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, topic: Topic, mask: typing.SupportsInt) -> int:
        """
        Start listening to changes to a particular topic. This creates a
        corresponding internal subscriber with the lifetime of the listener.
        
        :param topic: Topic
        :param mask:  Bitmask of EventFlags values
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, subscriber: Subscriber, mask: typing.SupportsInt) -> int:
        """
        Start listening to topic changes on a subscriber. This does NOT keep the
        subscriber active.
        
        :param subscriber: Subscriber
        :param mask:       Bitmask of EventFlags values
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, subscriber: MultiSubscriber, mask: typing.SupportsInt) -> int:
        """
        Start listening to topic changes on a subscriber. This does NOT keep the
        subscriber active.
        
        :param subscriber: Subscriber
        :param mask:       Bitmask of EventFlags values
        
        :returns: Listener handle
        """
    @typing.overload
    def addListener(self, entry: NetworkTableEntry, mask: typing.SupportsInt) -> int:
        """
        Start listening to topic changes on an entry.
        
        :param entry: Entry
        :param mask:  Bitmask of EventFlags values
        
        :returns: Listener handle
        """
    def addLogger(self, minLevel: typing.SupportsInt, maxLevel: typing.SupportsInt) -> int:
        """
        Add logger callback function.  By default, log messages are sent to stderr;
        this function sends log messages with the specified levels to the provided
        callback function instead.  The callback function will only be called for
        log messages with level greater than or equal to minLevel and less than or
        equal to maxLevel; messages outside this range will be silently ignored.
        
        :param minLevel: minimum log level
        :param maxLevel: maximum log level
        
        :returns: Listener handle
        """
    def addTimeSyncListener(self, immediate_notify: bool) -> int:
        """
        Add a time synchronization listener. The callback function is called
        asynchronously on a separate thread, so it's important to use
        synchronization or atomics when accessing any shared state from the
        callback function.
        
        :param immediate_notify: notify listener of current time synchronization
                                 value
        
        :returns: Listener handle
        """
    def close(self) -> None:
        """
        Destroys the poller
        """
    def getHandle(self) -> int:
        """
        Gets the native handle.
        
        :returns: Handle
        """
    def readQueue(self) -> list[Event]:
        """
        Read events.
        
        :returns: Events since the previous call to ReadQueue()
        """
    def removeListener(self, listener: typing.SupportsInt) -> None:
        """
        Remove a listener.
        
        :param listener: Listener handle
        """
class NetworkTableType:
    """
    NetworkTable entry type.
    @ingroup ntcore_cpp_api
    
    Members:
    
      kUnassigned : Unassigned data type.
    
      kBoolean : Boolean data type.
    
      kDouble : Double precision floating-point data type.
    
      kString : String data type.
    
      kRaw : Raw data type.
    
      kBooleanArray : Boolean array data type.
    
      kDoubleArray : Double precision floating-point array data type.
    
      kStringArray : String array data type.
    
      kInteger : Integer data type.
    
      kFloat : Single precision floating-point data type.
    
      kIntegerArray : Integer array data type.
    
      kFloatArray : Single precision floating-point array data type.
    """
    __members__: typing.ClassVar[dict[str, NetworkTableType]]  # value = {'kUnassigned': <NetworkTableType.kUnassigned: 0>, 'kBoolean': <NetworkTableType.kBoolean: 1>, 'kDouble': <NetworkTableType.kDouble: 2>, 'kString': <NetworkTableType.kString: 4>, 'kRaw': <NetworkTableType.kRaw: 8>, 'kBooleanArray': <NetworkTableType.kBooleanArray: 16>, 'kDoubleArray': <NetworkTableType.kDoubleArray: 32>, 'kStringArray': <NetworkTableType.kStringArray: 64>, 'kInteger': <NetworkTableType.kInteger: 256>, 'kFloat': <NetworkTableType.kFloat: 512>, 'kIntegerArray': <NetworkTableType.kIntegerArray: 1024>, 'kFloatArray': <NetworkTableType.kFloatArray: 2048>}
    kBoolean: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kBoolean: 1>
    kBooleanArray: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kBooleanArray: 16>
    kDouble: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kDouble: 2>
    kDoubleArray: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kDoubleArray: 32>
    kFloat: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kFloat: 512>
    kFloatArray: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kFloatArray: 2048>
    kInteger: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kInteger: 256>
    kIntegerArray: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kIntegerArray: 1024>
    kRaw: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kRaw: 8>
    kString: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kString: 4>
    kStringArray: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kStringArray: 64>
    kUnassigned: typing.ClassVar[NetworkTableType]  # value = <NetworkTableType.kUnassigned: 0>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class PubSubOptions:
    """
    NetworkTables publish/subscribe options.
    """
    kDefaultPeriodic: typing.ClassVar[float] = 0.1
    def __init__(self, *, pollStorage: typing.SupportsInt = 0, periodic: typing.SupportsFloat = 0.1, excludePublisher: ntcore._ntcore.Publisher | None = None, sendAll: bool = False, topicsOnly: bool = False, keepDuplicates: bool = False, prefixMatch: bool = False, disableRemote: bool = False, disableLocal: bool = False, excludeSelf: bool = False, hidden: bool = False) -> None:
        """
                      :param pollStorage:      Polling storage size for a subscription. Specifies the maximum number of
                                               updates NetworkTables should store between calls to the subscriber's
                                               ReadQueue() function. If zero, defaults to 1 if sendAll is false, 20 if
                                               sendAll is true.
                      :param periodic:         How frequently changes will be sent over the network, in seconds.
                                               NetworkTables may send more frequently than this (e.g. use a combined
                                               minimum period for all values) or apply a restricted range to this value.
                                               The default is 100 ms.
                      :param excludePublisher: For subscriptions, if non-zero, value updates for ReadQueue() are not
                                               queued for this publisher.
                      :param sendAll:          Send all value changes over the network.
                      :param topicsOnly:       For subscriptions, don't ask for value changes (only topic announcements).
                      :param keepDuplicates:   Preserve duplicate value changes (rather than ignoring them).
                      :param prefixMatch:      Perform prefix match on subscriber topic names. Is ignored/overridden by
                                               Subscribe() functions; only present in struct for the purposes of getting
                                               information about subscriptions.
                      :param disableRemote:    For subscriptions, if remote value updates should not be queued for
                                               ReadQueue(). See also disableLocal.
                      :param disableLocal:     For subscriptions, if local value updates should not be queued for
                                               ReadQueue(). See also disableRemote.
                      :param excludeSelf:      For entries, don't queue (for ReadQueue) value updates for the entry's
                                               internal publisher.
                      :param hidden:           For subscriptions, don't share the existence of the subscription with the
                                               network. Note this means updates will not be received from the network
                                               unless another subscription overlaps with this one, and the subscription
                                               will not appear in metatopics.
        """
    @property
    def disableLocal(self) -> bool:
        """
        For subscriptions, if local value updates should not be queued for
        ReadQueue(). See also disableRemote.
        """
    @disableLocal.setter
    def disableLocal(self, arg0: bool) -> None:
        ...
    @property
    def disableRemote(self) -> bool:
        """
        For subscriptions, if remote value updates should not be queued for
        ReadQueue(). See also disableLocal.
        """
    @disableRemote.setter
    def disableRemote(self, arg0: bool) -> None:
        ...
    @property
    def excludePublisher(self) -> int:
        """
        For subscriptions, if non-zero, value updates for ReadQueue() are not
        queued for this publisher.
        """
    @excludePublisher.setter
    def excludePublisher(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def excludeSelf(self) -> bool:
        """
        For entries, don't queue (for ReadQueue) value updates for the entry's
        internal publisher.
        """
    @excludeSelf.setter
    def excludeSelf(self, arg0: bool) -> None:
        ...
    @property
    def hidden(self) -> bool:
        """
        For subscriptions, don't share the existence of the subscription with the
        network. Note this means updates will not be received from the network
        unless another subscription overlaps with this one, and the subscription
        will not appear in metatopics.
        """
    @hidden.setter
    def hidden(self, arg0: bool) -> None:
        ...
    @property
    def keepDuplicates(self) -> bool:
        """
        Preserve duplicate value changes (rather than ignoring them).
        """
    @keepDuplicates.setter
    def keepDuplicates(self, arg0: bool) -> None:
        ...
    @property
    def periodic(self) -> float:
        """
        How frequently changes will be sent over the network, in seconds.
        NetworkTables may send more frequently than this (e.g. use a combined
        minimum period for all values) or apply a restricted range to this value.
        The default is 100 ms.
        """
    @periodic.setter
    def periodic(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def pollStorage(self) -> int:
        """
        Polling storage size for a subscription. Specifies the maximum number of
        updates NetworkTables should store between calls to the subscriber's
        ReadQueue() function. If zero, defaults to 1 if sendAll is false, 20 if
        sendAll is true.
        """
    @pollStorage.setter
    def pollStorage(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def prefixMatch(self) -> bool:
        """
        Perform prefix match on subscriber topic names. Is ignored/overridden by
        Subscribe() functions; only present in struct for the purposes of getting
        information about subscriptions.
        """
    @prefixMatch.setter
    def prefixMatch(self, arg0: bool) -> None:
        ...
    @property
    def sendAll(self) -> bool:
        """
        Send all value changes over the network.
        """
    @sendAll.setter
    def sendAll(self, arg0: bool) -> None:
        ...
    @property
    def topicsOnly(self) -> bool:
        """
        For subscriptions, don't ask for value changes (only topic announcements).
        """
    @topicsOnly.setter
    def topicsOnly(self, arg0: bool) -> None:
        ...
class Publisher:
    """
    NetworkTables publisher.
    """
    def __repr__(self) -> str:
        ...
    def getTopic(self) -> Topic:
        """
        Gets the published-to topic.
        
        :returns: Topic
        """
    @property
    def _m_pubHandle(self) -> int:
        """
        NetworkTables handle.
        """
class RawEntry(RawSubscriber, RawPublisher):
    """
    NetworkTables Raw entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> RawEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> RawTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class RawPublisher(Publisher):
    """
    NetworkTables Raw publisher.
    """
    def __enter__(self) -> RawPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> RawTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: typing_extensions.Buffer, time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: typing_extensions.Buffer) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class RawSubscriber(Subscriber):
    """
    NetworkTables Raw subscriber.
    """
    def __enter__(self) -> RawSubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> bytes:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: typing_extensions.Buffer) -> bytes:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedRaw:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: typing_extensions.Buffer) -> TimestampedRaw:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> RawTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedRaw]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class RawTopic(Topic):
    """
    NetworkTables Raw topic.
    """
    def __enter__(self) -> RawTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, typeString: str, defaultValue: typing_extensions.Buffer, options: PubSubOptions = ...) -> RawEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, typeString: str, options: PubSubOptions = ...) -> RawPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param options:    publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> RawPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, typeString: str, defaultValue: typing_extensions.Buffer, options: PubSubOptions = ...) -> RawSubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class StringArrayEntry(StringArraySubscriber, StringArrayPublisher):
    """
    NetworkTables StringArray entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> StringArrayEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> StringArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class StringArrayPublisher(Publisher):
    """
    NetworkTables StringArray publisher.
    """
    def __enter__(self) -> StringArrayPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> StringArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: list[str], time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: list[str]) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class StringArraySubscriber(Subscriber):
    """
    NetworkTables StringArray subscriber.
    """
    def __enter__(self) -> StringArraySubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> list[str]:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: list[str]) -> list[str]:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedStringArray:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: list[str]) -> TimestampedStringArray:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> StringArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedStringArray]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class StringArrayTopic(Topic):
    """
    NetworkTables StringArray topic.
    """
    kTypeString: typing.ClassVar[str] = 'string[]'
    def __enter__(self) -> StringArrayTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: list[str], options: PubSubOptions = ...) -> StringArrayEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def getEntryEx(self, typeString: str, defaultValue: list[str], options: PubSubOptions = ...) -> StringArrayEntry:
        """
        Create a new entry for the topic, with specific type string.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> StringArrayPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> StringArrayPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: list[str], options: PubSubOptions = ...) -> StringArraySubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
    def subscribeEx(self, typeString: str, defaultValue: list[str], options: PubSubOptions = ...) -> StringArraySubscriber:
        """
        Create a new subscriber to the topic, with specific type string.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class StringEntry(StringSubscriber, StringPublisher):
    """
    NetworkTables String entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> StringEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> StringTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class StringPublisher(Publisher):
    """
    NetworkTables String publisher.
    """
    def __enter__(self) -> StringPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> StringTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: str, time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: str) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class StringSubscriber(Subscriber):
    """
    NetworkTables String subscriber.
    """
    def __enter__(self) -> StringSubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> str:
        """
        Get the last published value.
        If no value has been published, returns the stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: str) -> str:
        """
        Get the last published value.
        If no value has been published, returns the passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedString:
        """
        Get the last published value along with its timestamp
        If no value has been published, returns the stored default value and a
        timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: str) -> TimestampedString:
        """
        Get the last published value along with its timestamp.
        If no value has been published, returns the passed defaultValue and a
        timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> StringTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedString]:
        """
        Get an array of all value changes since the last call to ReadQueue.
        Also provides a timestamp for each value.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no new changes have
                  been published since the previous call.
        """
class StringTopic(Topic):
    """
    NetworkTables String topic.
    """
    kTypeString: typing.ClassVar[str] = 'string'
    def __enter__(self) -> StringTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: str, options: PubSubOptions = ...) -> StringEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def getEntryEx(self, typeString: str, defaultValue: str, options: PubSubOptions = ...) -> StringEntry:
        """
        Create a new entry for the topic, with specific type string.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> StringPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> StringPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: str, options: PubSubOptions = ...) -> StringSubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
    def subscribeEx(self, typeString: str, defaultValue: str, options: PubSubOptions = ...) -> StringSubscriber:
        """
        Create a new subscriber to the topic, with specific type string.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString:   type string
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class StructArrayEntry(StructArraySubscriber, StructArrayPublisher):
    """
    NetworkTables struct-encoded value array entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> StructArrayEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> StructArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class StructArrayPublisher(Publisher):
    """
    NetworkTables struct-encoded value array publisher.
    """
    def __enter__(self) -> StructArrayPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> StructArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: list[typing.Any], time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: list[typing.Any]) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class StructArraySubscriber(Subscriber):
    """
    NetworkTables struct-encoded value array subscriber.
    """
    def __enter__(self) -> StructArraySubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> list[typing.Any]:
        """
        Get the last published value.
        If no value has been published or the value cannot be unpacked, returns the
        stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: list[typing.Any]) -> list[typing.Any]:
        """
        Get the last published value.
        If no value has been published or the value cannot be unpacked, returns the
        passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedStructArray:
        """
        Get the last published value along with its timestamp
        If no value has been published or the value cannot be unpacked, returns the
        stored default value and a timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: list[typing.Any]) -> TimestampedStructArray:
        """
        Get the last published value along with its timestamp.
        If no value has been published or the value cannot be unpacked, returns the
        passed defaultValue and a timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> StructArrayTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedStructArray]:
        """
        Get an array of all valid value changes since the last call to ReadQueue.
        Also provides a timestamp for each value. Values that cannot be unpacked
        are dropped.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no valid new changes
                  have been published since the previous call.
        """
class StructArrayTopic(Topic):
    """
    NetworkTables struct-encoded value array topic.
    """
    def __enter__(self) -> StructArrayTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic, type: type) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        :param type:  optional struct type info
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: list[typing.Any], options: PubSubOptions = ...) -> StructArrayEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> StructArrayPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, properties: wpiutil.json, options: PubSubOptions = ...) -> StructArrayPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: list[typing.Any], options: PubSubOptions = ...) -> StructArraySubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class StructEntry(StructSubscriber, StructPublisher):
    """
    NetworkTables struct-encoded value entry.
    
    .. note:: Unlike NetworkTableEntry, the entry goes away when this is destroyed.
    """
    def __enter__(self) -> StructEntry:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the entry
        """
    def getTopic(self) -> StructTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def unpublish(self) -> None:
        """
        Stops publishing the entry if it's published.
        """
class StructPublisher(Publisher):
    """
    NetworkTables struct-encoded value publisher.
    """
    def __enter__(self) -> StructPublisher:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the publisher
        """
    def getTopic(self) -> StructTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def set(self, value: typing.Any, time: typing.SupportsInt = 0) -> None:
        """
        Publish a new value.
        
        :param value: value to publish
        :param time:  timestamp; 0 indicates current NT time should be used
        """
    def setDefault(self, value: typing.Any) -> None:
        """
        Publish a default value.
        On reconnect, a default value will never be used in preference to a
        published value.
        
        :param value: value
        """
class StructSubscriber(Subscriber):
    """
    NetworkTables struct-encoded value subscriber.
    """
    def __enter__(self) -> StructSubscriber:
        ...
    def __exit__(self, *args) -> None:
        ...
    def close(self) -> None:
        """
        Destroys the subscriber
        """
    @typing.overload
    def get(self) -> typing.Any:
        """
        Get the last published value.
        If no value has been published or the value cannot be unpacked, returns the
        stored default value.
        
        :returns: value
        """
    @typing.overload
    def get(self, defaultValue: typing.Any) -> typing.Any:
        """
        Get the last published value.
        If no value has been published or the value cannot be unpacked, returns the
        passed defaultValue.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: value
        """
    @typing.overload
    def getAtomic(self) -> TimestampedStruct:
        """
        Get the last published value along with its timestamp
        If no value has been published or the value cannot be unpacked, returns the
        stored default value and a timestamp of 0.
        
        :returns: timestamped value
        """
    @typing.overload
    def getAtomic(self, defaultValue: typing.Any) -> TimestampedStruct:
        """
        Get the last published value along with its timestamp.
        If no value has been published or the value cannot be unpacked, returns the
        passed defaultValue and a timestamp of 0.
        
        :param defaultValue: default value to return if no value has been published
        
        :returns: timestamped value
        """
    def getTopic(self) -> StructTopic:
        """
        Get the corresponding topic.
        
        :returns: Topic
        """
    def readQueue(self) -> list[TimestampedStruct]:
        """
        Get an array of all valid value changes since the last call to ReadQueue.
        Also provides a timestamp for each value. Values that cannot be unpacked
        are dropped.
        
        .. note:: The "poll storage" subscribe option can be used to set the queue
           depth.
        
        :returns: Array of timestamped values; empty array if no valid new changes
                  have been published since the previous call.
        """
class StructTopic(Topic):
    """
    NetworkTables struct-encoded value topic.
    """
    def __enter__(self) -> StructTopic:
        ...
    def __exit__(self, *args) -> None:
        ...
    def __init__(self, topic: Topic, type: type) -> None:
        """
        Construct from a generic topic.
        
        :param topic: Topic
        :param type:  optional struct type info
        """
    def close(self) -> None:
        """
        Destroys the topic
        """
    def getEntry(self, defaultValue: typing.Any, options: PubSubOptions = ...) -> StructEntry:
        """
        Create a new entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      publish and/or subscribe options
        
        :returns: entry
        """
    def publish(self, options: PubSubOptions = ...) -> StructPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish options
        
        :returns: publisher
        """
    def publishEx(self, properties: wpiutil.json, options: PubSubOptions = ...) -> StructPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    def subscribe(self, defaultValue: typing.Any, options: PubSubOptions = ...) -> StructSubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param defaultValue: default value used when a default is not provided to a
                             getter function
        :param options:      subscribe options
        
        :returns: subscriber
        """
class Subscriber:
    """
    NetworkTables subscriber.
    """
    def __repr__(self) -> str:
        ...
    def exists(self) -> bool:
        """
        Determines if the topic is currently being published.
        
        :returns: True if the topic exists, false otherwise.
        """
    def getLastChange(self) -> int:
        """
        Gets the last time the value was changed.
        Note: this is not atomic with Get(); use GetAtomic() to get
        both the value and last change as an atomic operation.
        
        :returns: Topic last change time
        """
    def getTopic(self) -> Topic:
        """
        Gets the subscribed-to topic.
        
        :returns: Topic
        """
    @property
    def _m_subHandle(self) -> int:
        ...
class TimeSyncEventData:
    """
    NetworkTables time sync event data.
    """
    def __init__(self, serverTimeOffset: typing.SupportsInt, rtt2: typing.SupportsInt, valid: bool) -> None:
        ...
    @property
    def rtt2(self) -> int:
        """
        Measured round trip time divided by 2, in microseconds.
        """
    @rtt2.setter
    def rtt2(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def serverTimeOffset(self) -> int:
        """
        Offset between local time and server time, in microseconds. Add this value
        to local time to get the estimated equivalent server time.
        """
    @serverTimeOffset.setter
    def serverTimeOffset(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def valid(self) -> bool:
        """
        If serverTimeOffset and RTT are valid. An event with this set to false is
        sent when the client disconnects.
        """
    @valid.setter
    def valid(self, arg0: bool) -> None:
        ...
class TimestampedBoolean:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: bool) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> bool:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: bool) -> None:
        ...
class TimestampedBooleanArray:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: collections.abc.Sequence[typing.SupportsInt]) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> list[int]:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: collections.abc.Sequence[typing.SupportsInt]) -> None:
        ...
class TimestampedDouble:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: typing.SupportsFloat) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> float:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: typing.SupportsFloat) -> None:
        ...
class TimestampedDoubleArray:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: collections.abc.Sequence[typing.SupportsFloat]) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> list[float]:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: collections.abc.Sequence[typing.SupportsFloat]) -> None:
        ...
class TimestampedFloat:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: typing.SupportsFloat) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> float:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: typing.SupportsFloat) -> None:
        ...
class TimestampedFloatArray:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: collections.abc.Sequence[typing.SupportsFloat]) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> list[float]:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: collections.abc.Sequence[typing.SupportsFloat]) -> None:
        ...
class TimestampedInteger:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: typing.SupportsInt) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> int:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: typing.SupportsInt) -> None:
        ...
class TimestampedIntegerArray:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: collections.abc.Sequence[typing.SupportsInt]) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> list[int]:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: collections.abc.Sequence[typing.SupportsInt]) -> None:
        ...
class TimestampedRaw:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: bytes) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> bytes:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: bytes) -> None:
        ...
class TimestampedString:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: str) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> str:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: str) -> None:
        ...
class TimestampedStringArray:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: collections.abc.Sequence[str]) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> list[str]:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: collections.abc.Sequence[str]) -> None:
        ...
class TimestampedStruct:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: typing.Any) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> typing.Any:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: typing.Any) -> None:
        ...
class TimestampedStructArray:
    """
    Timestamped value.
    @ingroup ntcore_cpp_handle_api
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, time: typing.SupportsInt, serverTime: typing.SupportsInt, value: collections.abc.Sequence[typing.Any]) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def serverTime(self) -> int:
        """
        Time in server time base.  May be 0 or 1 for locally set values.
        """
    @serverTime.setter
    def serverTime(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def time(self) -> int:
        """
        Time in local time base.
        """
    @time.setter
    def time(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def value(self) -> list[typing.Any]:
        """
        Value.
        """
    @value.setter
    def value(self, arg0: collections.abc.Sequence[typing.Any]) -> None:
        ...
class Topic:
    """
    NetworkTables Topic.
    """
    __hash__: typing.ClassVar[None] = None
    def __eq__(self, arg0: Topic) -> bool:
        """
        Equality operator.  Returns true if both instances refer to the same
        native handle.
        """
    def __repr__(self) -> str:
        ...
    def deleteProperty(self, name: str) -> None:
        """
        Deletes a property.  Has no effect if the property does not exist.
        
        :param name: property name
        """
    def exists(self) -> bool:
        """
        Determines if the topic is currently being published.
        
        :returns: True if the topic exists, false otherwise.
        """
    def genericPublish(self, typeString: str, options: PubSubOptions = ...) -> GenericPublisher:
        """
        Create a new publisher to the topic.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param options:    publish options
        
        :returns: publisher
        """
    def genericPublishEx(self, typeString: str, properties: wpiutil.json, options: PubSubOptions = ...) -> GenericPublisher:
        """
        Create a new publisher to the topic, with type string and initial
        properties.
        
        The publisher is only active as long as the returned object
        is not destroyed.
        
        .. note:: It is not possible to publish two different data types to the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored). To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param properties: JSON properties
        :param options:    publish options
        
        :returns: publisher
        """
    @typing.overload
    def genericSubscribe(self, options: PubSubOptions = ...) -> GenericSubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        :param options: subscribe options
        
        :returns: subscriber
        """
    @typing.overload
    def genericSubscribe(self, typeString: str, options: PubSubOptions = ...) -> GenericSubscriber:
        """
        Create a new subscriber to the topic.
        
        The subscriber is only active as long as the returned object
        is not destroyed.
        
        .. note:: Subscribers that do not match the published data type do not return
           any values. To determine if the data type matches, use the appropriate
           Topic functions.
        
        :param typeString: type string
        :param options:    subscribe options
        
        :returns: subscriber
        """
    @typing.overload
    def getGenericEntry(self, options: PubSubOptions = ...) -> GenericEntry:
        """
        Create a new generic entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param options: publish and/or subscribe options
        
        :returns: entry
        """
    @typing.overload
    def getGenericEntry(self, typeString: str, options: PubSubOptions = ...) -> GenericEntry:
        """
        Create a new generic entry for the topic.
        
        Entries act as a combination of a subscriber and a weak publisher. The
        subscriber is active as long as the entry is not destroyed. The publisher
        is created when the entry is first written to, and remains active until
        either Unpublish() is called or the entry is destroyed.
        
        .. note:: It is not possible to use two different data types with the same
           topic. Conflicts between publishers are typically resolved by the
           server on a first-come, first-served basis. Any published values that
           do not match the topic's data type are dropped (ignored), and the entry
           will show no new values if the data type does not match. To determine
           if the data type matches, use the appropriate Topic functions.
        
        :param typeString: type string
        :param options:    publish and/or subscribe options
        
        :returns: entry
        """
    def getInfo(self) -> TopicInfo:
        """
        Gets combined information about the topic.
        
        :returns: Topic information
        """
    def getInstance(self) -> NetworkTableInstance:
        """
        Gets the instance for the topic.
        
        :returns: Instance
        """
    def getName(self) -> str:
        """
        Gets the name of the topic.
        
        :returns: the topic's name
        """
    def getProperties(self) -> wpiutil.json:
        """
        Gets all topic properties as a JSON object.  Each key in the object
        is the property name, and the corresponding value is the property value.
        
        :returns: JSON object
        """
    def getProperty(self, name: str) -> wpiutil.json:
        """
        Gets the current value of a property (as a JSON object).
        
        :param name: property name
        
        :returns: JSON object; null object if the property does not exist.
        """
    def getType(self) -> NetworkTableType:
        """
        Gets the type of the topic.
        
        :returns: the topic's type
        """
    def getTypeString(self) -> str:
        """
        Gets the type string of the topic. This may have more information
        than the numeric type (especially for raw values).
        
        :returns: the topic's type
        """
    def isCached(self) -> bool:
        """
        Returns whether the topic's last value is stored.
        
        :returns: True if the topic is cached.
        """
    def isPersistent(self) -> bool:
        """
        Returns whether the value is persistent through server restarts.
        
        :returns: True if the value is persistent.
        """
    def isRetained(self) -> bool:
        """
        Returns whether the topic is retained by server when there are no
        publishers.
        
        :returns: True if the topic is retained.
        """
    def setCached(self, cached: bool) -> None:
        """
        Allow storage of the topic's last value, allowing the value to be read (and
        not just accessed through event queues and listeners).
        
        :param cached: True for cached, false for not cached.
        """
    def setPersistent(self, persistent: bool) -> None:
        """
        Make value persistent through server restarts.
        
        :param persistent: True for persistent, false for not persistent.
        """
    def setProperties(self, properties: wpiutil.json) -> bool:
        """
        Updates multiple topic properties.  Each key in the passed-in object is
        the name of the property to add/update, and the corresponding value is the
        property value to set for that property.  Null values result in deletion
        of the corresponding property.
        
        :param properties: JSON object with keys to add/update/delete
        
        :returns: False if properties is not an object
        """
    def setProperty(self, name: str, value: wpiutil.json) -> None:
        """
        Sets a property value.
        
        :param name:  property name
        :param value: property value
        """
    def setRetained(self, retained: bool) -> None:
        """
        Make the server retain the topic even when there are no publishers.
        
        :param retained: True for retained, false for not retained.
        """
class TopicInfo:
    """
    NetworkTables Topic Information
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def getProperties(self) -> wpiutil.json:
        """
        Get topic properties as a JSON object.
        """
    @property
    def name(self) -> str:
        """
        Topic name
        """
    @name.setter
    def name(self, arg0: str) -> None:
        ...
    @property
    def properties(self) -> str:
        """
        Topic properties JSON string
        """
    @properties.setter
    def properties(self, arg0: str) -> None:
        ...
    @property
    def topic(self) -> Topic:
        ...
    @property
    def type(self) -> NetworkTableType:
        ...
    @property
    def type_str(self) -> str:
        """
        Topic type string
        """
    @type_str.setter
    def type_str(self, arg0: str) -> None:
        ...
class Value:
    """
    A network table entry value.
    @ingroup ntcore_cpp_api
    """
    @staticmethod
    def getFactoryByType(type: NetworkTableType) -> collections.abc.Callable:
        ...
    @staticmethod
    def makeBoolean(value: bool, time: typing.SupportsInt = 0) -> Value:
        """
        Creates a boolean entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
        """
    @staticmethod
    def makeBooleanArray(value: list[bool], time: typing.SupportsInt = 0) -> Value:
        """
        Creates a boolean array entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
        """
    @staticmethod
    def makeDouble(value: typing.SupportsFloat, time: typing.SupportsInt = 0) -> Value:
        """
        Creates a double entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
        """
    @staticmethod
    def makeDoubleArray(value: collections.abc.Sequence[typing.SupportsFloat], time: typing.SupportsInt = 0) -> Value:
        """
        Creates a double array entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
                  
                  .. note:: This function moves the values out of the vector.
        """
    @staticmethod
    def makeFloat(value: typing.SupportsFloat, time: typing.SupportsInt = 0) -> Value:
        """
        Creates a float entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
        """
    @staticmethod
    def makeFloatArray(value: collections.abc.Sequence[typing.SupportsFloat], time: typing.SupportsInt = 0) -> Value:
        """
        Creates a float array entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
                  
                  .. note:: This function moves the values out of the vector.
        """
    @staticmethod
    def makeInteger(value: typing.SupportsInt, time: typing.SupportsInt = 0) -> Value:
        """
        Creates an integer entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
        """
    @staticmethod
    def makeIntegerArray(value: collections.abc.Sequence[typing.SupportsInt], time: typing.SupportsInt = 0) -> Value:
        """
        Creates an integer array entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
                  
                  .. note:: This function moves the values out of the vector.
        """
    @staticmethod
    def makeRaw(value: typing_extensions.Buffer, time: typing.SupportsInt = 0) -> Value:
        """
        Creates a raw entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
        """
    @staticmethod
    def makeString(value: str, time: typing.SupportsInt = 0) -> Value:
        """
        Creates a string entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
        """
    @staticmethod
    def makeStringArray(value: collections.abc.Sequence[str], time: typing.SupportsInt = 0) -> Value:
        """
        Creates a string array entry value.
        
        :param value: the value
        :param time:  if nonzero, the creation time to use (instead of the current
                      time)
        
        :returns: The entry value
                  
                  .. note:: This function moves the values out of the vector.
        """
    @staticmethod
    def makeValue(value: typing.Any) -> Value:
        ...
    def __repr__(self) -> str:
        ...
    def getBoolean(self) -> bool:
        """
        Get the entry's boolean value.
        
        :returns: The boolean value.
        """
    def getBooleanArray(self) -> typing.Any:
        """
        Get the entry's boolean array value.
        
        :returns: The boolean array value.
        """
    def getDouble(self) -> float:
        """
        Get the entry's double value.
        
        :returns: The double value.
        """
    def getDoubleArray(self) -> list[float]:
        """
        Get the entry's double array value.
        
        :returns: The double array value.
        """
    def getFloat(self) -> float:
        """
        Get the entry's float value.
        
        :returns: The float value.
        """
    def getFloatArray(self) -> list[float]:
        """
        Get the entry's float array value.
        
        :returns: The float array value.
        """
    def getInteger(self) -> int:
        """
        Get the entry's integer value.
        
        :returns: The integer value.
        """
    def getIntegerArray(self) -> list[int]:
        """
        Get the entry's integer array value.
        
        :returns: The integer array value.
        """
    def getRaw(self) -> typing_extensions.Buffer:
        """
        Get the entry's raw value.
        
        :returns: The raw value.
        """
    def getString(self) -> str:
        """
        Get the entry's string value.
        
        :returns: The string value.
        """
    def getStringArray(self) -> list[str]:
        """
        Get the entry's string array value.
        
        :returns: The string array value.
        """
    def isBoolean(self) -> bool:
        """
        Determine if entry value contains a boolean.
        
        :returns: True if the entry value is of boolean type.
        """
    def isBooleanArray(self) -> bool:
        """
        Determine if entry value contains a boolean array.
        
        :returns: True if the entry value is of boolean array type.
        """
    def isDouble(self) -> bool:
        """
        Determine if entry value contains a double.
        
        :returns: True if the entry value is of double type.
        """
    def isDoubleArray(self) -> bool:
        """
        Determine if entry value contains a double array.
        
        :returns: True if the entry value is of double array type.
        """
    def isFloat(self) -> bool:
        """
        Determine if entry value contains a float.
        
        :returns: True if the entry value is of float type.
        """
    def isFloatArray(self) -> bool:
        """
        Determine if entry value contains a float array.
        
        :returns: True if the entry value is of float array type.
        """
    def isInteger(self) -> bool:
        """
        Determine if entry value contains an integer.
        
        :returns: True if the entry value is of integer type.
        """
    def isIntegerArray(self) -> bool:
        """
        Determine if entry value contains an integer array.
        
        :returns: True if the entry value is of integer array type.
        """
    def isRaw(self) -> bool:
        """
        Determine if entry value contains a raw.
        
        :returns: True if the entry value is of raw type.
        """
    def isString(self) -> bool:
        """
        Determine if entry value contains a string.
        
        :returns: True if the entry value is of string type.
        """
    def isStringArray(self) -> bool:
        """
        Determine if entry value contains a string array.
        
        :returns: True if the entry value is of string array type.
        """
    def isValid(self) -> bool:
        """
        Determine if entry value contains a value or is unassigned.
        
        :returns: True if the entry value contains a value.
        """
    def last_change(self) -> int:
        """
        Get the creation time of the value, in local time.
        
        :returns: The time, in the units returned by nt::Now().
        """
    def server_time(self) -> int:
        """
        Get the creation time of the value, in server time.
        
        :returns: The server time.
        """
    def setServerTime(self, time: typing.SupportsInt) -> None:
        """
        Set the creation time of the value, in server time.
        
        :param time: The server time.
        """
    def setTime(self, time: typing.SupportsInt) -> None:
        """
        Set the local creation time of the value.
        
        :param time: The time.
        """
    def size(self) -> int:
        """
        Get the approximate in-memory size of the value in bytes. This is zero for
        values that do not require additional memory beyond the memory of the Value
        itself.
        
        :returns: The size in bytes.
        """
    def time(self) -> int:
        """
        Get the creation time of the value, in local time.
        
        :returns: The time, in the units returned by nt::Now().
        """
    def type(self) -> NetworkTableType:
        """
        Get the data type.
        
        :returns: The type.
        """
    def value(self) -> typing.Any:
        """
        Get the data value stored.
        
        :returns: The type.
        """
class ValueEventData:
    """
    NetworkTables Value Event Data
    """
    def __repr__(self) -> str:
        ...
    @property
    def topic(self) -> Topic:
        ...
    @property
    def value(self) -> Value:
        """
        The new value.
        """
def _addPolledLogger(poller: typing.SupportsInt, min_level: typing.SupportsInt, max_level: typing.SupportsInt) -> int:
    """
    Set the log level for a log poller.  Events will only be generated for
    log messages with level greater than or equal to min_level and less than or
    equal to max_level; messages outside this range will be silently ignored.
    
    :param poller:    poller handle
    :param min_level: minimum log level
    :param max_level: maximum log level
    
    :returns: Logger handle
    """
def _now() -> int:
    """
    Returns monotonic current time in 1 us increments.
    This is the same time base used for value and connection timestamps.
    This function by default simply wraps wpi::Now(), but if SetNow() is
    called, this function instead returns the value passed to SetNow();
    this can be used to reduce overhead.
    
    :returns: Timestamp
    """
def _removeListener(listener: typing.SupportsInt) -> None:
    """
    Removes a listener.
    
    :param listener: Listener handle to remove
    """
def _setNow(timestamp: typing.SupportsInt) -> None:
    """
    Sets the current timestamp used for timestamping values that do not
    provide a timestamp (e.g. a value of 0 is passed).  For consistency,
    it also results in Now() returning the set value.  This should generally
    be used only if the overhead of calling wpi::Now() is a concern.
    If used, it should be called periodically with the value of wpi::Now().
    
    :param timestamp: timestamp (1 us increments)
    """
_st_cleanup: typing.Any  # value = <capsule object>
