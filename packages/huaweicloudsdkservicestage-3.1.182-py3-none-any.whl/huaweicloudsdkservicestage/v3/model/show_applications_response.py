# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowApplicationsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'count': 'int',
        'applications': 'list[Application]'
    }

    attribute_map = {
        'count': 'count',
        'applications': 'applications'
    }

    def __init__(self, count=None, applications=None):
        r"""ShowApplicationsResponse

        The model defined in huaweicloud sdk

        :param count: 应用数量。
        :type count: int
        :param applications: 应用列表。
        :type applications: list[:class:`huaweicloudsdkservicestage.v3.Application`]
        """
        
        super().__init__()

        self._count = None
        self._applications = None
        self.discriminator = None

        if count is not None:
            self.count = count
        if applications is not None:
            self.applications = applications

    @property
    def count(self):
        r"""Gets the count of this ShowApplicationsResponse.

        应用数量。

        :return: The count of this ShowApplicationsResponse.
        :rtype: int
        """
        return self._count

    @count.setter
    def count(self, count):
        r"""Sets the count of this ShowApplicationsResponse.

        应用数量。

        :param count: The count of this ShowApplicationsResponse.
        :type count: int
        """
        self._count = count

    @property
    def applications(self):
        r"""Gets the applications of this ShowApplicationsResponse.

        应用列表。

        :return: The applications of this ShowApplicationsResponse.
        :rtype: list[:class:`huaweicloudsdkservicestage.v3.Application`]
        """
        return self._applications

    @applications.setter
    def applications(self, applications):
        r"""Sets the applications of this ShowApplicationsResponse.

        应用列表。

        :param applications: The applications of this ShowApplicationsResponse.
        :type applications: list[:class:`huaweicloudsdkservicestage.v3.Application`]
        """
        self._applications = applications

    def to_dict(self):
        import warnings
        warnings.warn("ShowApplicationsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowApplicationsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
