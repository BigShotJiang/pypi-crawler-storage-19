(token) => {
    window.cfCallback(token);
}