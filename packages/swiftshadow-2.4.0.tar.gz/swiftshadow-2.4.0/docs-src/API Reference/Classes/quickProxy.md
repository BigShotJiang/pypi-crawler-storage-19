# QuickProxy Class
::: swiftshadow.QuickProxy
