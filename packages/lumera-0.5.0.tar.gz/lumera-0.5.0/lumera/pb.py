"""
Record operations for Lumera collections.

This module provides a clean interface for working with Lumera collections,
using the `pb.` namespace convention familiar from automation contexts.

Available functions:
    search()          - Query records with filters, pagination, sorting
    get()             - Get single record by ID
    get_by_external_id() - Get record by external_id field
    create()          - Create new record
    update()          - Update existing record
    upsert()          - Create or update by external_id
    delete()          - Delete record
    iter_all()        - Iterate all matching records (auto-pagination)

Filter Syntax:
    Filters can be passed as dict or JSON string to search() and iter_all().

    Simple equality:
        {"status": "pending"}
        {"external_id": "dep-001"}

    Comparison operators (eq, gt, gte, lt, lte):
        {"amount": {"gt": 1000}}
        {"amount": {"gte": 100, "lte": 500}}

    OR logic:
        {"or": [{"status": "pending"}, {"status": "review"}]}

    AND logic (implicit - multiple fields at same level):
        {"status": "pending", "amount": {"gt": 1000}}

    Combined:
        {"status": "active", "or": [{"priority": "high"}, {"amount": {"gt": 5000}}]}

Example:
    >>> from lumera import pb
    >>> results = pb.search("deposits", filter={"status": "pending"})
    >>> deposit = pb.get("deposits", "rec_abc123")
"""

from typing import Any, Iterator, Mapping

__all__ = [
    "search",
    "get",
    "get_by_external_id",
    "create",
    "update",
    "upsert",
    "delete",
    "iter_all",
]

# Import underlying SDK functions (prefixed with _ to indicate internal use)
from .sdk import (
    create_record as _create_record,
)
from .sdk import (
    delete_record as _delete_record,
)
from .sdk import (
    get_record as _get_record,
)
from .sdk import (
    get_record_by_external_id as _get_record_by_external_id,
)
from .sdk import (
    list_records as _list_records,
)
from .sdk import (
    update_record as _update_record,
)
from .sdk import (
    upsert_record as _upsert_record,
)


def search(
    collection: str,
    *,
    filter: Mapping[str, Any] | str | None = None,
    per_page: int = 50,
    page: int = 1,
    sort: str | None = None,
    expand: str | None = None,
) -> dict[str, Any]:
    """Search records in a collection.

    Args:
        collection: Collection name or ID
        filter: Filter as dict or JSON string. See module docstring for syntax.
                Examples:
                - {"status": "pending"} - equality
                - {"amount": {"gt": 1000}} - comparison
                - {"or": [{"status": "a"}, {"status": "b"}]} - OR logic
        per_page: Results per page (max 500, default 50)
        page: Page number, 1-indexed (default 1)
        sort: Sort expression (e.g., "-created,name" for created DESC, name ASC)
        expand: Comma-separated relation fields to expand (e.g., "user_id,company_id")

    Returns:
        Paginated results with structure:
        {
            "items": [...],      # List of records
            "page": 1,
            "perPage": 50,
            "totalItems": 100,
            "totalPages": 2
        }

    Example:
        >>> results = pb.search("deposits",
        ...     filter={"status": "pending", "amount": {"gt": 1000}},
        ...     per_page=100,
        ...     sort="-created"
        ... )
        >>> for deposit in results["items"]:
        ...     print(deposit["id"], deposit["amount"])
    """
    # Note: _list_records handles both dict and str filters via JSON encoding
    return _list_records(
        collection,
        filter=filter,
        per_page=per_page,
        page=page,
        sort=sort,
        expand=expand,
    )


def get(collection: str, record_id: str) -> dict[str, Any]:
    """Get a single record by ID.

    Args:
        collection: Collection name or ID
        record_id: Record ID (15-character alphanumeric ID)

    Returns:
        Record data with all fields

    Raises:
        LumeraAPIError: If record doesn't exist (404)

    Example:
        >>> deposit = pb.get("deposits", "dep_abc123")
        >>> print(deposit["amount"])
    """
    return _get_record(collection, record_id)


def get_by_external_id(collection: str, external_id: str) -> dict[str, Any]:
    """Get a single record by external_id (unique field).

    Args:
        collection: Collection name or ID
        external_id: Value of the external_id field (your business identifier)

    Returns:
        Record data

    Raises:
        LumeraAPIError: If no record with that external_id (404)

    Example:
        >>> deposit = pb.get_by_external_id("deposits", "dep-2024-001")
    """
    return _get_record_by_external_id(collection, external_id)


def create(collection: str, data: dict[str, Any]) -> dict[str, Any]:
    """Create a new record.

    Args:
        collection: Collection name or ID
        data: Record data as dict mapping field names to values

    Returns:
        Created record with id, created, and updated timestamps

    Raises:
        LumeraAPIError: If validation fails or unique constraint violated

    Example:
        >>> deposit = pb.create("deposits", {
        ...     "external_id": "dep-001",
        ...     "amount": 1000,
        ...     "status": "pending"
        ... })
        >>> print(deposit["id"])
    """
    return _create_record(collection, data)


def update(collection: str, record_id: str, data: dict[str, Any]) -> dict[str, Any]:
    """Update an existing record (partial update).

    Args:
        collection: Collection name or ID
        record_id: Record ID to update
        data: Fields to update (only include fields you want to change)

    Returns:
        Updated record

    Raises:
        LumeraAPIError: If record doesn't exist or validation fails

    Example:
        >>> deposit = pb.update("deposits", "dep_abc123", {
        ...     "status": "processed",
        ...     "processed_at": datetime.utcnow().isoformat()
        ... })
    """
    return _update_record(collection, record_id, data)


def upsert(collection: str, data: dict[str, Any]) -> dict[str, Any]:
    """Create or update a record by external_id.

    If a record with the given external_id exists, updates it.
    Otherwise, creates a new record. This is useful for idempotent imports.

    Args:
        collection: Collection name or ID
        data: Record data (MUST include "external_id" field)

    Returns:
        Created or updated record

    Raises:
        ValueError: If data doesn't contain "external_id"
        LumeraAPIError: If validation fails

    Example:
        >>> deposit = pb.upsert("deposits", {
        ...     "external_id": "dep-001",
        ...     "amount": 1000,
        ...     "status": "pending"
        ... })
        >>> # Second call updates the existing record
        >>> deposit = pb.upsert("deposits", {
        ...     "external_id": "dep-001",
        ...     "amount": 2000
        ... })
    """
    return _upsert_record(collection, data)


def delete(collection: str, record_id: str) -> None:
    """Delete a record.

    Args:
        collection: Collection name or ID
        record_id: Record ID to delete

    Raises:
        LumeraAPIError: If record doesn't exist

    Example:
        >>> pb.delete("deposits", "dep_abc123")
    """
    _delete_record(collection, record_id)


def iter_all(
    collection: str,
    *,
    filter: Mapping[str, Any] | str | None = None,
    sort: str | None = None,
    expand: str | None = None,
    batch_size: int = 500,
) -> Iterator[dict[str, Any]]:
    """Iterate over all matching records, handling pagination automatically.

    This is a convenience function for processing large result sets without
    manually handling pagination. Use this instead of manual page loops.

    Args:
        collection: Collection name or ID
        filter: Optional filter as dict or JSON string (e.g., {"status": "pending"})
        sort: Optional sort expression (e.g., "-created" for newest first)
        expand: Optional comma-separated relation fields to expand
        batch_size: Records per API request (max 500, default 500)

    Yields:
        Individual records

    Example:
        >>> for deposit in pb.iter_all("deposits", filter={"status": "pending"}):
        ...     process(deposit)
    """
    page = 1
    while True:
        result = search(
            collection,
            filter=filter,
            per_page=batch_size,
            page=page,
            sort=sort,
            expand=expand,
        )

        items = result.get("items", [])
        if not items:
            break

        yield from items

        # Check if there are more pages
        total_pages = result.get("totalPages", 0)
        if page >= total_pages:
            break

        page += 1
