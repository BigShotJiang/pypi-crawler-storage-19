"""Domain-specific simulation modules."""
