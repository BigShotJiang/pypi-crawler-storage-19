from importlib.metadata import version as get_version

try:
    version = get_version("odcs")
except Exception:
    version = "unknown"
