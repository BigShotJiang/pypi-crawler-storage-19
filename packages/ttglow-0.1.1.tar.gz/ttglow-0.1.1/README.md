<p align="center">
  <img src="assets/ttglow_logo.png" alt="TTGlow Logo" width="400"/>
</p>

# TTGlow

A Tensor Train linear algebra package for efficient high-dimensional tensor operations in PyTorch.

## Overview

TTGlow provides an efficient implementation of the Tensor Train (TT) decomposition, a powerful technique for representing and manipulating high-dimensional tensors with reduced memory footprint and computational cost. This package is particularly useful for:

- High-dimensional data analysis
- Quantum many-body physics simulations
- Machine learning with tensor methods
- Efficient storage and computation of large-scale tensors

## Installation

### Using Pixi (Recommended)

```bash
# Clone the repository
git clone https://github.com/romanellerbrock/ttglow.git
cd ttglow

# Install dependencies with pixi
pixi install

# Activate the environment
pixi shell
```

### Using pip

```bash
pip install -e .
```

## Quick Start

```python
import torch
from ttglow import TensorTrain, dot, add, scale

# Create a random Tensor Train
dims = [10, 20, 15]  # Tensor dimensions
ranks = [3, 5]        # TT-ranks
tt = TensorTrain.random(dims, ranks)

# Convert to full tensor
full_tensor = tt.to_tensor()

# Create a constant tensor in TT format
tt_ones = TensorTrain.ones([10, 20, 15], value=3.14)

# Dot product (inner product)
tt1 = TensorTrain.random([4, 5, 6], [2, 3])
tt2 = TensorTrain.random([4, 5, 6], [2, 3])
matrices = dot(tt1, tt2)
inner_product = matrices[-1].item()  # Scalar result
norm_squared = dot(tt1, tt1)[-1].item()  # Self inner product

# Addition
tt_sum = add(tt1, tt2)  # Returns new TT with ranks = r1 + r2

# Scalar multiplication
tt_scaled = scale(tt1, 2.5)  # Multiply by scalar
```

## Features

- **Efficient TT representation**: Store high-dimensional tensors with minimal memory
- **Core operations**:
  - `dot`: Inner product of two TT tensors
  - `hadamard`: Element-wise multiplication
  - `add`: Summation of TT tensors
  - `scale`: Scalar multiplication
- **Flexible construction**: Create TT tensors from scratch or via decomposition
- **PyTorch backend**: Full GPU support and automatic differentiation

## Development

### Running Tests

```bash
pixi run test
```

### Code Formatting

```bash
pixi run format
```

### Linting

```bash
pixi run lint
```

### Test Coverage

```bash
pixi run test-cov
```

## Project Structure

```
ttglow/
├── src/ttglow/           # Main package code
│   ├── __init__.py
│   └── tensortrain.py    # TT implementation
├── tests/                # Test suite
│   └── test_tensortrain.py
├── examples/             # Usage examples
├── pixi.toml             # Pixi configuration
└── pyproject.toml        # Python package metadata
```

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## References

- Oseledets, I. V. (2011). "Tensor-train decomposition". SIAM J. Sci. Comput., 33(5), 2295-2317.
