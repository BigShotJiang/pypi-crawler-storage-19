from .url_jail import *

__doc__ = url_jail.__doc__
if hasattr(url_jail, "__all__"):
    __all__ = url_jail.__all__