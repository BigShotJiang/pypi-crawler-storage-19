import argparse
import sys
import os
import logging
from pathlib import Path
from primerlab.core.logger import setup_logger
from primerlab.core.config_loader import load_and_merge_config
from primerlab.core.exceptions import PrimerLabException

# Version definition
__version__ = "0.8.0"


def _run_health_check():
    """
    Check all dependencies and show system info.
    Per v0.1.3 quick patches - helps debugging installation issues.
    """
    import platform

    print(f"\n🔬 PrimerLab Health Check v{__version__}")
    print("=" * 45)

    # Python version
    py_version = platform.python_version()
    if py_version >= "3.10":
        print(f"✅ Python {py_version}")
    else:
        print(f"⚠️ Python {py_version} (recommend 3.10+)")

    # Primer3-py
    try:
        import primer3
        print(f"✅ primer3-py (installed)")
    except ImportError:
        print("❌ primer3-py NOT FOUND (required)")

    # ViennaRNA
    try:
        from primerlab.core.tools.vienna_wrapper import ViennaWrapper
        vienna = ViennaWrapper()
        if vienna.is_available:  # Property, not method
            print(f"✅ ViennaRNA (available)")
        else:
            print("⚠️ ViennaRNA not found (optional, install for secondary structure QC)")
    except Exception as e:
        print(f"⚠️ ViennaRNA check failed: {e}")

    # PyYAML
    try:
        import yaml
        print(f"✅ PyYAML (installed)")
    except ImportError:
        print("❌ PyYAML NOT FOUND (required)")

    # Rich
    try:
        import rich
        version = getattr(rich, "__version__", "installed")
        print(f"✅ Rich {version}")
    except ImportError:
        print("⚠️ Rich not found (optional, for colorized output)")

    # tqdm
    try:
        import tqdm
        version = getattr(tqdm, "__version__", "installed")
        print(f"✅ tqdm {version}")
    except ImportError:
        print("⚠️ tqdm not found (optional, for progress bars)")

    # Biopython (optional)
    try:
        import Bio
        print(f"✅ Biopython {Bio.__version__}")
    except ImportError:
        print("⚠️ Biopython not found (optional, for advanced sequence parsing)")

    # v0.1.6: Check for updates
    print("\n" + "-" * 45)
    print("📡 Checking for updates...")
    try:
        import urllib.request
        import json

        url = "https://api.github.com/repos/engkinandatama/primerlab-genomic/releases/latest"
        req = urllib.request.Request(url, headers={"User-Agent": "PrimerLab"})

        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode())
            latest_version = data.get("tag_name", "").lstrip("v")

            if latest_version and latest_version > __version__:
                print(f"🆕 New version available: v{latest_version}")
                print(f"   Current: v{__version__}")
                print(f"   Update: pip install git+https://github.com/engkinandatama/primerlab-genomic.git@v{latest_version}")
            else:
                print(f"✅ You are on the latest version (v{__version__})")
    except Exception as e:
        print(f"⚠️ Could not check for updates: {e}")

    print("\n" + "=" * 45)
    print("Health check complete.\n")

def main():
    parser = argparse.ArgumentParser(
        description="PrimerLab: Automated Primer Design Framework",
        formatter_class=argparse.RawTextHelpFormatter
    )

    parser.add_argument("--version", action="version", version=f"PrimerLab v{__version__}")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- VERSION Command ---
    subparsers.add_parser("version", help="Show version info")

    # --- RUN Command ---
    run_parser = subparsers.add_parser("run", help="Run a specific workflow")
    run_parser.add_argument("workflow", choices=["pcr", "qpcr", "crispr"], help="Workflow to run")
    run_parser.add_argument("--config", "-c", type=str, help="Path to user config YAML file")
    run_parser.add_argument("--out", "-o", type=str, help="Override output directory")
    run_parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    run_parser.add_argument("--export", "-e", type=str, 
                           help="Export formats: comma-separated (e.g., --export idt,sigma,thermo)")
    run_parser.add_argument("--mask", "-m", type=str, default=None,
                           choices=["auto", "lowercase", "n", "none"],
                           help="Region masking mode: auto (detect all), lowercase, n, none (default: none)")
    run_parser.add_argument("--quiet", "-q", action="store_true",
                           help="Suppress warnings and non-essential output (v0.1.6)")
    run_parser.add_argument("--validate", "-V", action="store_true",
                           help="Run in-silico PCR validation after primer design (v0.2.3)")
    run_parser.add_argument("--blast", action="store_true",
                           help="Run off-target check after primer design (v0.3.1)")
    run_parser.add_argument("--blast-db", type=str, default=None,
                           help="Path to BLAST database (FASTA or BLAST DB)")
    # v0.3.3 Report flags
    run_parser.add_argument("--report", "-R", action="store_true",
                           help="Generate combined report after design (v0.3.3)")
    run_parser.add_argument("--report-format", type=str, choices=["markdown", "html", "json"],
                           default="markdown", help="Report format (v0.3.3)")
    run_parser.add_argument("--report-output", type=str, default=None,
                           help="Report output path (v0.3.3)")
    # v0.4.0 Multiplex Integration
    run_parser.add_argument("--check-compat", action="store_true",
                           help="Run multiplex compatibility check on designed primers (v0.4.0)")
    # v0.4.1 Amplicon Analysis
    run_parser.add_argument("--amplicon-analysis", action="store_true",
                           help="Run amplicon quality analysis after primer design (v0.4.1)")
    # v0.6.1 Melt Curve Plot
    run_parser.add_argument("--plot-melt", action="store_true",
                           help="Generate melt curve plot for qPCR amplicons (v0.6.1)")
    run_parser.add_argument("--plot-format", type=str, choices=["svg", "png"],
                           default="svg", help="Melt curve plot format (v0.6.1)")
    # v0.7.3 CLI Improvements
    run_parser.add_argument("--dry-run", action="store_true",
                           help="Preview configuration without running workflow (v0.7.3)")
    run_parser.add_argument("--verbose", "-v", action="store_true",
                           help="Enable verbose output with progress info (v0.7.3)")

    # --- BATCH-GENERATE Command ---
    batch_parser = subparsers.add_parser("batch-generate", help="Generate multiple configs from CSV")
    batch_parser.add_argument("--input", "-i", type=str, required=True, help="Input CSV file")
    batch_parser.add_argument("--output", "-o", type=str, default="./configs", help="Output directory for configs")
    batch_parser.add_argument("--workflow", "-w", type=str, choices=["pcr", "qpcr"], default="pcr", help="Workflow type")

    # --- INIT Command (v0.1.3) ---
    init_parser = subparsers.add_parser("init", help="Generate a template configuration file")
    init_parser.add_argument("--workflow", "-w", type=str, choices=["pcr", "qpcr"], default="pcr", 
                            help="Workflow type (default: pcr)")
    init_parser.add_argument("--output", "-o", type=str, default="config.yaml", 
                            help="Output filename (default: config.yaml)")

    # --- HEALTH Command (v0.1.3) ---
    subparsers.add_parser("health", help="Check all dependencies and show system info")

    # --- VALIDATE Command (v0.1.5) ---
    validate_parser = subparsers.add_parser("validate", help="Validate a configuration file")
    validate_parser.add_argument("config", type=str, help="Path to config YAML file to validate")
    validate_parser.add_argument("--workflow", "-w", type=str, choices=["pcr", "qpcr"], default="pcr",
                                help="Workflow type (default: pcr)")

    # --- PRESET Command (v0.1.5) ---
    preset_parser = subparsers.add_parser("preset", help="Manage and view presets")
    preset_subparsers = preset_parser.add_subparsers(dest="preset_action", help="Preset actions")

    # preset list
    preset_subparsers.add_parser("list", help="List all available presets")

    # preset show <name>
    preset_show = preset_subparsers.add_parser("show", help="Show details of a specific preset")
    preset_show.add_argument("name", type=str, help="Name of preset to show")

    # --- COMPARE Command (v0.1.5) ---
    compare_parser = subparsers.add_parser("compare", help="Compare two primer design results")
    compare_parser.add_argument("result_a", type=str, help="Path to first result.json")
    compare_parser.add_argument("result_b", type=str, help="Path to second result.json")
    compare_parser.add_argument("--labels", "-l", type=str, default="A,B",
                               help="Labels for comparison (default: A,B)")

    # --- BATCH RUN Command (v0.1.5) ---
    batch_run_parser = subparsers.add_parser("batch-run", help="Run multiple configs and consolidate results")
    batch_run_parser.add_argument("--configs", "-c", type=str, default=None,
                                  help="Directory containing config files OR comma-separated list of config paths")
    batch_run_parser.add_argument("--fasta", "-f", type=str, default=None,
                                  help="Multi-FASTA file with multiple sequences (uses shared config)")
    batch_run_parser.add_argument("--config", type=str, default=None,
                                  help="Shared config file for multi-FASTA mode (required with --fasta)")
    batch_run_parser.add_argument("--output", "-o", type=str, default="./batch_output",
                                  help="Output directory for batch results (default: ./batch_output)")
    batch_run_parser.add_argument("--export", "-e", type=str, default="xlsx",
                                  help="Export formats for summary (default: xlsx)")
    batch_run_parser.add_argument("--continue-on-error", action="store_true",
                                  help="Continue processing even if some configs fail")

    # --- PLOT Command (v0.1.5) ---
    plot_parser = subparsers.add_parser("plot", help="Generate visualizations from results")
    plot_parser.add_argument("result", type=str, help="Path to result.json file")
    plot_parser.add_argument("--sequence", "-s", type=str, required=True,
                             help="Path to sequence file (FASTA or raw)")
    plot_parser.add_argument("--type", "-t", type=str, default="gc-profile",
                             choices=["gc-profile"],
                             help="Plot type (default: gc-profile)")
    plot_parser.add_argument("--theme", type=str, default="light",
                             choices=["light", "dark"],
                             help="Color theme (default: light)")
    plot_parser.add_argument("--output", "-o", type=str, default=None,
                             help="Output path for plot (PNG/SVG)")
    plot_parser.add_argument("--window", "-w", type=int, default=20,
                             help="Sliding window size for GC analysis (default: 20)")

    # --- HISTORY Command (v0.1.5) ---
    history_parser = subparsers.add_parser("history", help="View and manage primer design history")
    history_subparsers = history_parser.add_subparsers(dest="history_command", help="History subcommands")

    # history list
    history_list = history_subparsers.add_parser("list", help="List recent designs")
    history_list.add_argument("--limit", "-n", type=int, default=10,
                              help="Number of designs to show (default: 10)")
    history_list.add_argument("--gene", "-g", type=str, default=None,
                              help="Filter by gene name")
    history_list.add_argument("--workflow", "-w", type=str, choices=["pcr", "qpcr"],
                              help="Filter by workflow type")

    # history show
    history_show = history_subparsers.add_parser("show", help="Show details of a design")
    history_show.add_argument("id", type=int, help="Design ID to show")

    # history export
    history_export = history_subparsers.add_parser("export", help="Export history to CSV")
    history_export.add_argument("--output", "-o", type=str, default="primer_history.csv",
                                help="Output CSV path")

    # history stats
    history_subparsers.add_parser("stats", help="Show database statistics")

    # history delete
    history_delete = history_subparsers.add_parser("delete", help="Delete a design")
    history_delete.add_argument("id", type=int, help="Design ID to delete")

    # --- STATS Command (v0.1.6) ---
    stats_parser = subparsers.add_parser("stats", help="Show sequence statistics before design")
    stats_parser.add_argument("sequence", type=str, help="Path to sequence file (FASTA) or raw sequence")
    stats_parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")

    # --- INSILICO Command (v0.2.0) ---
    insilico_parser = subparsers.add_parser("insilico", help="In-silico PCR simulation")
    insilico_parser.add_argument("--primers", "-p", required=True,
                                 help="Path to primers JSON file or FASTA")
    insilico_parser.add_argument("--template", "-t", required=True,
                                 help="Path to template FASTA file")
    insilico_parser.add_argument("--output", "-o", type=str, default="insilico_output",
                                 help="Output directory (default: insilico_output)")
    insilico_parser.add_argument("--config", "-c", type=str,
                                 help="Optional config file for parameters")
    insilico_parser.add_argument("--json", action="store_true",
                                 help="Output results as JSON only")
    insilico_parser.add_argument("--circular", action="store_true",
                                 help="Treat template as circular (v0.2.4)")

    # --- BLAST Command (v0.3.0) ---
    blast_parser = subparsers.add_parser("blast", help="Off-target check for primers (v0.3.0)")
    blast_parser.add_argument("--primers", "-p", required=True,
                             help="Primer sequences (JSON file, FASTA, or comma-separated)")
    blast_parser.add_argument("--database", "-d", required=True,
                             help="Path to FASTA database or BLAST DB")
    blast_parser.add_argument("--target", "-t", type=str,
                             help="Expected target sequence ID")
    blast_parser.add_argument("--output", "-o", type=str, default="blast_output",
                             help="Output directory (default: blast_output)")
    blast_parser.add_argument("--json", action="store_true",
                             help="Output results as JSON only")
    blast_parser.add_argument("--mode", choices=["auto", "blast", "biopython"],
                             default="auto", help="Alignment mode (default: auto)")
    blast_parser.add_argument("--batch", action="store_true",
                             help="Batch mode: process multiple primers from file (v0.3.1)")
    blast_parser.add_argument("--db-info", action="store_true",
                             help="Show database info instead of running check (v0.3.1)")
    blast_parser.add_argument("--variants", type=str, default=None,
                             help="Path to VCF file for variant check (v0.3.1)")
    blast_parser.add_argument("--maf-threshold", type=float, default=None,
                             help="Minimum MAF for variant filtering (v0.3.1)")
    # v0.3.2 Phase 1 flags
    blast_parser.add_argument("--online", action="store_true",
                             help="Force NCBI web BLAST (v0.3.2)")
    blast_parser.add_argument("--verbose", "-v", action="store_true",
                             help="Verbose output with details (v0.3.2)")
    blast_parser.add_argument("--quiet", "-q", action="store_true",
                             help="Quiet mode - minimal output (v0.3.2)")
    # v0.3.2 Phase 2 flags
    blast_parser.add_argument("--no-cache", action="store_true",
                             help="Disable result caching (v0.3.2)")
    blast_parser.add_argument("--threads", type=int, default=4,
                             help="Number of parallel threads (v0.3.2)")
    blast_parser.add_argument("--timeout", type=int, default=300,
                             help="Timeout per query in seconds (v0.3.2)")

    # --- CHECK-COMPAT Command (v0.4.0) ---
    compat_parser = subparsers.add_parser("check-compat", help="Check primer set compatibility (v0.4.0)")
    compat_parser.add_argument("--primers", "-p", required=True,
                                 help="Path to input file (JSON list of pairs)")
    compat_parser.add_argument("--config", "-c", type=str,
                                 help="Path to config YAML")
    compat_parser.add_argument("--output", "-o", type=str, default="compat_check_output",
                                 help="Output directory (default: compat_check_output)")
    compat_parser.add_argument("--format", type=str, choices=["markdown", "json"], default="markdown",
                                 help="Report format (default: markdown)")
    compat_parser.add_argument("--template", "-t", type=str, default=None,
                                 help="Template sequence for overlap analysis (v0.4.1)")

    # --- SPECIES-CHECK Command (v0.4.2) ---
    species_parser = subparsers.add_parser("species-check", help="Check primer species specificity (v0.4.2)")
    species_parser.add_argument("--primers", "-p", type=str, default=None,
                                help="Path to primers JSON file")
    species_parser.add_argument("--primers-dir", type=str, default=None,
                                help="Directory containing multiple primer JSON files (v0.4.3 batch)")
    species_parser.add_argument("--target", "-t", required=True,
                                help="Path to target species FASTA template")
    species_parser.add_argument("--offtargets", type=str, default=None,
                                help="Comma-separated paths to off-target species FASTAs")
    species_parser.add_argument("--config", "-c", type=str, default=None,
                                help="Path to config YAML")
    species_parser.add_argument("--output", "-o", type=str, default="species_output",
                                help="Output directory (default: species_output)")
    species_parser.add_argument("--format", type=str, choices=["markdown", "json", "excel", "html"], 
                                default="markdown", help="Report format")
    species_parser.add_argument("--parallel", type=int, default=4,
                                help="Number of parallel threads for batch (v0.4.3, default: 4)")
    species_parser.add_argument("--no-cache", action="store_true",
                                help="Disable alignment cache (v0.4.3)")

    # --- TM-GRADIENT Command (v0.4.3) ---
    tm_parser = subparsers.add_parser("tm-gradient", help="Simulate Tm gradient for optimal annealing (v0.4.3)")
    tm_parser.add_argument("--primers", "-p", required=True,
                           help="Path to primers JSON file")
    tm_parser.add_argument("--template", "-t", type=str, default=None,
                           help="Optional template FASTA for context")
    tm_parser.add_argument("--min-temp", type=float, default=50.0,
                           help="Minimum temperature (°C, default: 50)")
    tm_parser.add_argument("--max-temp", type=float, default=72.0,
                           help="Maximum temperature (°C, default: 72)")
    tm_parser.add_argument("--step", type=float, default=0.5,
                           help="Temperature step (°C, default: 0.5)")
    tm_parser.add_argument("--output", "-o", type=str, default="tm_gradient_output",
                           help="Output directory (default: tm_gradient_output)")
    tm_parser.add_argument("--format", type=str, choices=["markdown", "json", "csv"],
                           default="markdown", help="Report format")

    # --- PROBE-CHECK Command (v0.6.0) ---
    probe_parser = subparsers.add_parser("probe-check", help="Check TaqMan probe binding (v0.6.0)")
    probe_parser.add_argument("--probe", "-p", required=True,
                             help="Probe sequence")
    probe_parser.add_argument("--amplicon", "-a", type=str, default=None,
                             help="Amplicon sequence (optional)")
    probe_parser.add_argument("--min-temp", type=float, default=55.0,
                             help="Minimum temperature (°C, default: 55)")
    probe_parser.add_argument("--max-temp", type=float, default=72.0,
                             help="Maximum temperature (°C, default: 72)")
    probe_parser.add_argument("--output", "-o", type=str, default=None,
                             help="Output file (default: stdout)")
    probe_parser.add_argument("--format", type=str, choices=["text", "json"],
                             default="text", help="Output format")

    # --- MELT-CURVE Command (v0.6.0) ---
    melt_parser = subparsers.add_parser("melt-curve", help="Predict SYBR melt curve (v0.6.0)")
    melt_parser.add_argument("--amplicon", "-a", required=True,
                            help="Amplicon sequence or FASTA file")
    melt_parser.add_argument("--output", "-o", type=str, default=None,
                            help="Output file for plot (SVG/PNG)")
    melt_parser.add_argument("--format", type=str, choices=["svg", "png", "json", "text"],
                            default="text", help="Output format")
    melt_parser.add_argument("--min-temp", type=float, default=65.0,
                            help="Minimum temperature (°C, default: 65)")
    melt_parser.add_argument("--max-temp", type=float, default=95.0,
                            help="Maximum temperature (°C, default: 95)")

    # --- AMPLICON-QC Command (v0.6.0) ---
    ampqc_parser = subparsers.add_parser("amplicon-qc", help="Validate qPCR amplicon (v0.6.0)")
    ampqc_parser.add_argument("--amplicon", "-a", required=True,
                             help="Amplicon sequence or FASTA file")
    ampqc_parser.add_argument("--min-length", type=int, default=70,
                             help="Minimum length (bp, default: 70)")
    ampqc_parser.add_argument("--max-length", type=int, default=150,
                             help="Maximum length (bp, default: 150)")
    ampqc_parser.add_argument("--output", "-o", type=str, default=None,
                             help="Output file (default: stdout)")
    ampqc_parser.add_argument("--format", type=str, choices=["text", "json"],
                             default="text", help="Output format")

    # --- NESTED-DESIGN Command (v0.7.0) ---
    nested_parser = subparsers.add_parser("nested-design", help="Design nested PCR primers (v0.7.0)")
    nested_parser.add_argument("--sequence", "-s", type=str, required=True,
                              help="Template sequence or FASTA file")
    nested_parser.add_argument("--outer-min", type=int, default=400,
                              help="Minimum outer amplicon size (bp, default: 400)")
    nested_parser.add_argument("--outer-max", type=int, default=600,
                              help="Maximum outer amplicon size (bp, default: 600)")
    nested_parser.add_argument("--inner-min", type=int, default=100,
                              help="Minimum inner amplicon size (bp, default: 100)")
    nested_parser.add_argument("--inner-max", type=int, default=200,
                              help="Maximum inner amplicon size (bp, default: 200)")
    nested_parser.add_argument("--outer-tm", type=float, default=58.0,
                              help="Optimal outer primer Tm (°C, default: 58)")
    nested_parser.add_argument("--inner-tm", type=float, default=60.0,
                              help="Optimal inner primer Tm (°C, default: 60)")
    nested_parser.add_argument("--output", "-o", type=str, default=None,
                              help="Output file (default: stdout)")
    nested_parser.add_argument("--format", type=str, choices=["text", "json", "markdown"],
                              default="text", help="Output format")

    # --- SEMINESTED-DESIGN Command (v0.7.0) ---
    seminested_parser = subparsers.add_parser("seminested-design", help="Design semi-nested PCR primers (v0.7.0)")
    seminested_parser.add_argument("--sequence", "-s", type=str, required=True,
                                  help="Template sequence or FASTA file")
    seminested_parser.add_argument("--outer-min", type=int, default=400,
                                  help="Minimum outer amplicon size (bp, default: 400)")
    seminested_parser.add_argument("--outer-max", type=int, default=600,
                                  help="Maximum outer amplicon size (bp, default: 600)")
    seminested_parser.add_argument("--inner-min", type=int, default=150,
                                  help="Minimum inner amplicon size (bp, default: 150)")
    seminested_parser.add_argument("--inner-max", type=int, default=300,
                                  help="Maximum inner amplicon size (bp, default: 300)")
    seminested_parser.add_argument("--shared", type=str, choices=["forward", "reverse"],
                                  default="forward", help="Which primer is shared (default: forward)")
    seminested_parser.add_argument("--tm", type=float, default=60.0,
                                  help="Optimal primer Tm (°C, default: 60)")
    seminested_parser.add_argument("--output", "-o", type=str, default=None,
                                  help="Output file (default: stdout)")
    seminested_parser.add_argument("--format", type=str, choices=["text", "json", "markdown"],
                                  default="text", help="Output format")

    # --- DIMER-MATRIX Command (v0.7.1) ---
    dimer_parser = subparsers.add_parser("dimer-matrix", help="Analyze primer dimer matrix (v0.7.1)")
    dimer_parser.add_argument("--primers", "-p", type=str, required=True,
                             help="JSON file with primers [{name, sequence}, ...]")
    dimer_parser.add_argument("--threshold", type=float, default=-6.0,
                             help="ΔG threshold for problematic dimers (default: -6.0)")
    dimer_parser.add_argument("--output", "-o", type=str, default=None,
                             help="Output file (default: stdout)")
    dimer_parser.add_argument("--format", type=str, choices=["text", "json", "svg"],
                             default="text", help="Output format")

    # --- COMPARE-BATCH Command (v0.7.1) ---
    compbatch_parser = subparsers.add_parser("compare-batch", help="Compare multiple design runs (v0.7.1)")
    compbatch_parser.add_argument("results", nargs="+", type=str,
                                 help="Paths to result.json files")
    compbatch_parser.add_argument("--output", "-o", type=str, default=None,
                                 help="Output file (default: stdout)")
    compbatch_parser.add_argument("--format", type=str, choices=["text", "json", "markdown"],
                                 default="text", help="Output format")

    # --- COVERAGE-MAP Command (v0.7.2) ---
    covmap_parser = subparsers.add_parser("coverage-map", help="Generate amplicon coverage map (v0.7.2)")
    covmap_parser.add_argument("--result", "-r", type=str, required=True,
                              help="Path to result.json file")
    covmap_parser.add_argument("--sequence-length", "-l", type=int, default=None,
                              help="Sequence length (auto-detected from result if not provided)")
    covmap_parser.add_argument("--output", "-o", type=str, default=None,
                              help="Output file (default: stdout)")
    covmap_parser.add_argument("--format", type=str, choices=["text", "json", "svg"],
                              default="svg", help="Output format (default: svg)")
    covmap_parser.add_argument("--width", type=int, default=800,
                              help="SVG width (default: 800)")
    covmap_parser.add_argument("--height", type=int, default=200,
                              help="SVG height (default: 200)")

    # --- QPCR-EFFICIENCY Command (v0.7.4) ---
    eff_parser = subparsers.add_parser("qpcr-efficiency", help="Calculate/predict qPCR efficiency (v0.7.4)")
    eff_subparsers = eff_parser.add_subparsers(dest="eff_action", help="Efficiency actions")

    # qpcr-efficiency calculate
    calc_parser = eff_subparsers.add_parser("calculate", help="Calculate efficiency from standard curve")
    calc_parser.add_argument("--data", "-d", type=str, required=True,
                            help="JSON file with {concentrations: [], ct_values: []}")
    calc_parser.add_argument("--output", "-o", type=str, default=None,
                            help="Output file (default: stdout)")
    calc_parser.add_argument("--format", type=str, choices=["text", "json"],
                            default="text", help="Output format")

    # qpcr-efficiency predict
    pred_parser = eff_subparsers.add_parser("predict", help="Predict efficiency from primer properties")
    pred_parser.add_argument("--forward", "-f", type=str, required=True,
                            help="Forward primer sequence")
    pred_parser.add_argument("--reverse", "-r", type=str, required=True,
                            help="Reverse primer sequence")
    pred_parser.add_argument("--amplicon-length", type=int, default=100,
                            help="Amplicon length (default: 100)")
    pred_parser.add_argument("--output", "-o", type=str, default=None,
                            help="Output file (default: stdout)")
    pred_parser.add_argument("--format", type=str, choices=["text", "json"],
                            default="text", help="Output format")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)  # Changed to 0 for better UX

    if args.command == "version":
        print(f"PrimerLab v{__version__}")
        sys.exit(0)

    # --- HEALTH Command Handler ---
    if args.command == "health":
        _run_health_check()
        sys.exit(0)

    # --- VALIDATE Command Handler (v0.1.5) ---
    if args.command == "validate":
        logger = setup_logger(level=logging.INFO)
        logger.info(f"🔍 Validating configuration: {args.config}")

        try:
            config = load_and_merge_config(
                workflow=args.workflow,
                user_config_path=args.config
            )
            print("\n✅ Configuration is valid!")
            print(f"   Workflow: {args.workflow.upper()}")
            print(f"   Output: {config['output']['directory']}")

            params = config.get('parameters', {})
            if params.get('tm'):
                print(f"   Tm Range: {params['tm'].get('min', '?')} - {params['tm'].get('max', '?')} °C")
            if params.get('product_size_range'):
                ranges = params['product_size_range']
                print(f"   Product Size: {ranges[0][0]} - {ranges[0][1]} bp")
            if params.get('primer_naming'):
                print(f"   Primer Naming: custom pattern configured")

            sys.exit(0)
        except PrimerLabException as e:
            print(f"\n❌ Configuration Error: {e.message}")
            print(f"   Error Code: {e.code}")
            sys.exit(1)
        except Exception as e:
            print(f"\n❌ Unexpected Error: {e}")
            sys.exit(1)

    # --- STATS Command Handler (v0.1.6) ---
    if args.command == "stats":
        import json
        from pathlib import Path

        seq_input = args.sequence

        try:
            # Load sequence from file or use as raw
            if Path(seq_input).exists():
                with open(seq_input, 'r') as f:
                    content = f.read()
                if content.startswith('>'):
                    # FASTA format
                    lines = content.strip().split('\n')
                    seq_name = lines[0][1:].split()[0]
                    sequence = ''.join(line for line in lines[1:] if not line.startswith('>'))
                else:
                    seq_name = Path(seq_input).stem
                    sequence = content.replace('\n', '').replace(' ', '')
            else:
                seq_name = "Input"
                sequence = seq_input

            # Calculate statistics
            seq_upper = sequence.upper()
            length = len(sequence)
            gc_count = seq_upper.count('G') + seq_upper.count('C')
            gc_percent = (gc_count / length * 100) if length > 0 else 0
            at_count = seq_upper.count('A') + seq_upper.count('T')
            n_count = seq_upper.count('N')

            # Check for IUPAC codes
            iupac_codes = set("RYSWKMBDHV")
            iupac_found = set(seq_upper) & iupac_codes
            iupac_count = sum(seq_upper.count(c) for c in iupac_found)

            # Check for RNA
            has_uracil = 'U' in sequence.upper()

            if args.json:
                stats = {
                    "name": seq_name,
                    "length": length,
                    "gc_percent": round(gc_percent, 2),
                    "gc_count": gc_count,
                    "at_count": at_count,
                    "n_count": n_count,
                    "iupac_codes": list(iupac_found),
                    "iupac_count": iupac_count,
                    "has_uracil": has_uracil,
                    "valid_for_design": length >= 50 and iupac_count == 0 and not has_uracil
                }
                print(json.dumps(stats, indent=2))
            else:
                print(f"\n📊 Sequence Statistics: {seq_name}")
                print("=" * 45)
                print(f"  Length:      {length:,} bp")
                print(f"  GC Content:  {gc_percent:.2f}% ({gc_count:,} bp)")
                print(f"  AT Content:  {(100-gc_percent-n_count/length*100):.2f}% ({at_count:,} bp)")

                if n_count > 0:
                    print(f"  N (masked):  {n_count:,} bp ({n_count/length*100:.2f}%)")

                if iupac_found:
                    print(f"  ⚠️  IUPAC codes: {sorted(iupac_found)} ({iupac_count} bp)")
                    print(f"      → Will be converted to N during design")

                if has_uracil:
                    print(f"  ⚠️  RNA detected (contains U)")
                    print(f"      → Will be converted to T during design")

                print("=" * 45)

                if length < 50:
                    print("❌ Too short for primer design (min 50 bp)")
                elif iupac_count > length * 0.1:
                    print("⚠️  High IUPAC content - may limit primer options")
                else:
                    print("✅ Ready for primer design")
                print()

            sys.exit(0)

        except Exception as e:
            print(f"\n❌ Error: {e}")
            sys.exit(1)

    # --- INSILICO Command Handler (v0.2.0) ---
    if args.command == "insilico":
        from pathlib import Path
        import json
        from primerlab.core.insilico import run_insilico_pcr
        from primerlab.core.sequence import SequenceLoader

        # Suppress logs when --json flag is used for clean output
        if args.json:
            logger = setup_logger(level=logging.ERROR)
        else:
            logger = setup_logger(level=logging.INFO)
            logger.info("🧬 Running In-silico PCR Simulation...")

        try:
            # Load template
            template_path = Path(args.template)
            if not template_path.exists():
                print(f"❌ Template file not found: {args.template}")
                sys.exit(1)

            template_seq = SequenceLoader.load(str(template_path))
            template_name = template_path.stem

            # Load primers from JSON or FASTA
            primers_path = Path(args.primers)
            if not primers_path.exists():
                print(f"❌ Primers file not found: {args.primers}")
                sys.exit(1)

            with open(primers_path, 'r') as f:
                content = f.read()

            if content.strip().startswith('{'):
                # JSON format
                primers_data = json.loads(content)
                fwd_primer = primers_data.get("forward", primers_data.get("fwd", ""))
                rev_primer = primers_data.get("reverse", primers_data.get("rev", ""))
            elif content.strip().startswith('>'):
                # FASTA format - expect 2 sequences
                lines = content.strip().split('\n')
                fwd_primer = ""
                rev_primer = ""
                current = None
                for line in lines:
                    if line.startswith('>'):
                        if 'forward' in line.lower() or 'fwd' in line.lower() or 'f1' in line.lower():
                            current = 'fwd'
                        elif 'reverse' in line.lower() or 'rev' in line.lower() or 'r1' in line.lower():
                            current = 'rev'
                        elif not fwd_primer:
                            current = 'fwd'
                        else:
                            current = 'rev'
                    else:
                        if current == 'fwd':
                            fwd_primer += line.strip()
                        elif current == 'rev':
                            rev_primer += line.strip()
            else:
                print("❌ Primers file must be JSON or FASTA format")
                sys.exit(1)

            if not fwd_primer or not rev_primer:
                print("❌ Could not parse forward and reverse primers from file")
                sys.exit(1)

            # Load params from config if provided
            params = {}
            if args.config:
                import yaml
                with open(args.config, 'r') as f:
                    config = yaml.safe_load(f)
                params = config.get("insilico", {})

            # v0.2.4: Add circular flag from CLI
            if args.circular:
                params["circular"] = True

            # Run in-silico PCR
            result = run_insilico_pcr(
                template=template_seq,
                forward_primer=fwd_primer,
                reverse_primer=rev_primer,
                template_name=template_name,
                params=params
            )

            # Create output directory
            output_dir = Path(args.output)
            output_dir.mkdir(parents=True, exist_ok=True)

            # Output as JSON
            result_dict = {
                "success": result.success,
                "template_name": result.template_name,
                "template_length": result.template_length,
                "forward_primer": result.forward_primer,
                "reverse_primer": result.reverse_primer,
                "products_count": len(result.products),
                "products": [
                    {
                        "size": p.product_size,
                        "start": p.start_position,
                        "end": p.end_position,
                        "likelihood": p.likelihood_score,
                        "is_primary": p.is_primary,
                        "sequence": p.product_sequence[:100] + "..." if len(p.product_sequence) > 100 else p.product_sequence
                    } for p in result.products
                ],
                "forward_bindings": len(result.all_forward_bindings),
                "reverse_bindings": len(result.all_reverse_bindings),
                "warnings": result.warnings,
                "errors": result.errors
            }

            # Save JSON
            json_path = output_dir / "insilico_result.json"
            with open(json_path, 'w') as f:
                json.dump(result_dict, f, indent=2)

            # v0.2.2: Use report module for outputs
            from primerlab.core.insilico.report import (
                generate_markdown_report,
                generate_amplicon_fasta,
                format_console_alignment
            )

            # Save Markdown Report (v0.2.2)
            generate_markdown_report(result, output_dir)

            # Save Amplicon FASTA (v0.2.2 - using report module)
            if result.products:
                generate_amplicon_fasta(result, output_dir)

            if args.json:
                print(json.dumps(result_dict, indent=2))
            else:
                # v0.2.2: Use formatted console output
                print(format_console_alignment(result))

                print("-" * 60)
                print(f"📁 Output directory: {output_dir}")
                print(f"   • insilico_result.json")
                print(f"   • insilico_report.md")
                if result.products:
                    print(f"   • predicted_amplicons.fasta ({len(result.products)} sequences)")
                print()

            sys.exit(0 if result.success else 1)

        except Exception as e:
            print(f"\n❌ Error: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    # --- BLAST Command Handler (v0.3.0) ---
    if args.command == "blast":
        try:
            from primerlab.core.offtarget.finder import OfftargetFinder
            from primerlab.core.offtarget.scorer import SpecificityScorer
            from primerlab.core.offtarget.report import generate_specificity_report

            # v0.3.1: Database info mode
            if getattr(args, 'db_info', False):
                db_path = Path(args.database)
                if not db_path.exists():
                    print(f"❌ Database not found: {db_path}")
                    sys.exit(1)

                # Count sequences in FASTA
                seq_count = 0
                total_bp = 0
                with open(db_path) as f:
                    for line in f:
                        if line.startswith('>'):
                            seq_count += 1
                        else:
                            total_bp += len(line.strip())

                print(f"📊 Database Info: {db_path.name}")
                print(f"   Sequences: {seq_count:,}")
                print(f"   Total size: {total_bp:,} bp")
                print(f"   File size: {db_path.stat().st_size:,} bytes")
                sys.exit(0)

            # Parse primers
            primers_input = args.primers
            forward_primer = None
            reverse_primer = None

            if os.path.exists(primers_input):
                if primers_input.endswith('.json'):
                    with open(primers_input) as f:
                        primer_data = json.load(f)
                    forward_primer = primer_data.get("forward") or primer_data.get("fwd")
                    reverse_primer = primer_data.get("reverse") or primer_data.get("rev")
                else:  # FASTA
                    seqs = []
                    with open(primers_input) as f:
                        current_seq = ""
                        for line in f:
                            line = line.strip()
                            if line.startswith(">"):
                                if current_seq:
                                    seqs.append(current_seq)
                                current_seq = ""
                            else:
                                current_seq += line
                        if current_seq:
                            seqs.append(current_seq)
                    if len(seqs) >= 2:
                        forward_primer, reverse_primer = seqs[0], seqs[1]
                    elif len(seqs) == 1:
                        forward_primer = seqs[0]
            else:
                # Comma-separated
                parts = primers_input.split(",")
                forward_primer = parts[0].strip()
                if len(parts) > 1:
                    reverse_primer = parts[1].strip()

            if not forward_primer:
                print("❌ No primers found in input")
                sys.exit(1)

            print(f"🔬 Off-target Check (v0.3.0)")
            print(f"   Database: {args.database}")
            print(f"   Forward:  {forward_primer[:30]}..." if len(forward_primer) > 30 else f"   Forward:  {forward_primer}")
            if reverse_primer:
                print(f"   Reverse:  {reverse_primer[:30]}..." if len(reverse_primer) > 30 else f"   Reverse:  {reverse_primer}")
            print()

            # Run off-target check
            finder = OfftargetFinder(
                database=args.database,
                target_id=args.target,
                mode=args.mode
            )

            if reverse_primer:
                result = finder.find_primer_pair_offtargets(
                    forward_primer=forward_primer,
                    reverse_primer=reverse_primer,
                    target_id=args.target
                )
                scorer = SpecificityScorer()
                fwd_score, rev_score, combined = scorer.score_primer_pair(result)
            else:
                result = finder.find_offtargets(
                    primer_seq=forward_primer,
                    primer_id="primer",
                    target_id=args.target
                )
                scorer = SpecificityScorer()
                combined = scorer.score_primer(result)

            # Output
            output_dir = Path(args.output)
            output_dir.mkdir(parents=True, exist_ok=True)

            # Generate report
            generate_specificity_report(result, combined, output_dir)

            # Result dict
            if hasattr(result, 'forward_result'):
                result_dict = {
                    "forward": {
                        "offtargets": result.forward_result.offtarget_count,
                        "score": result.forward_result.specificity_score
                    },
                    "reverse": {
                        "offtargets": result.reverse_result.offtarget_count,
                        "score": result.reverse_result.specificity_score
                    },
                    "combined_score": combined.overall_score,
                    "grade": combined.grade,
                    "is_specific": combined.is_acceptable
                }
            else:
                result_dict = {
                    "offtargets": result.offtarget_count,
                    "score": combined.overall_score,
                    "grade": combined.grade,
                    "is_specific": combined.is_acceptable
                }

            # Save JSON
            with open(output_dir / "blast_result.json", "w") as f:
                json.dump(result_dict, f, indent=2)

            if args.json:
                print(json.dumps(result_dict, indent=2))
            else:
                print(f"✅ Specificity Score: {combined.overall_score:.1f} (Grade: {combined.grade})")
                if hasattr(result, 'forward_result'):
                    print(f"   Forward: {result.forward_result.offtarget_count} off-targets")
                    print(f"   Reverse: {result.reverse_result.offtarget_count} off-targets")
                else:
                    print(f"   Off-targets: {result.offtarget_count}")

                if combined.is_acceptable:
                    print("\n✅ Primers are specific!")
                else:
                    print("\n⚠️  Low specificity - check off-targets")

                print(f"\n📁 Output: {output_dir}")
                print(f"   • blast_result.json")
                print(f"   • specificity_report.md")

            sys.exit(0 if combined.is_acceptable else 1)

        except Exception as e:
            print(f"\n❌ Error: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    # --- PRESET Command Handler (v0.1.5) ---
    if args.command == "preset":
        from pathlib import Path
        import yaml

        preset_dir = Path(__file__).parent.parent / "config"

        if args.preset_action == "list":
            print("\n📋 Available Presets:\n")
            preset_files = list(preset_dir.glob("*_default.yaml"))

            # Filter out workflow defaults, show only special presets
            presets = [p.stem.replace("_default", "") for p in preset_files 
                      if p.stem not in ["pcr_default", "qpcr_default"]]

            if presets:
                for preset in sorted(presets):
                    print(f"  • {preset}")
                print(f"\nUse 'primerlab preset show <name>' for details.")
            else:
                print("  No custom presets found.")
                print("  Built-in workflows: pcr, qpcr")

            sys.exit(0)

        elif args.preset_action == "show":
            preset_name = args.name
            preset_file = preset_dir / f"{preset_name}_default.yaml"

            if not preset_file.exists():
                print(f"\n❌ Preset '{preset_name}' not found.")
                print("   Use 'primerlab preset list' to see available presets.")
                sys.exit(1)

            print(f"\n📄 Preset: {preset_name}\n")
            print("-" * 40)

            with open(preset_file, 'r') as f:
                content = f.read()
                print(content)

            sys.exit(0)

        else:
            print("Usage: primerlab preset [list|show <name>]")

    # --- CHECK-COMPAT Command Handler (v0.4.0) ---
    if args.command == "check-compat":
        try:
            import json as json_lib
            from pathlib import Path as PathLib
            from primerlab.core.compat_check.models import MultiplexPair, MultiplexResult
            from primerlab.core.compat_check.dimer import DimerEngine
            from primerlab.core.compat_check.scoring import MultiplexScorer
            from primerlab.core.compat_check.validator import MultiplexValidator
            from primerlab.core.compat_check.report import generate_markdown_report, generate_json_report
            logger = setup_logger(level=logging.INFO)
            print(f"\n🧬 Multiplex Analysis (v{__version__})")
            print("=" * 45)

            # 1. Load Primers
            primers_path = PathLib(args.primers)
            if not primers_path.exists():
                print(f"❌ Input file not found: {primers_path}")
                sys.exit(1)

            print(f"📂 Loading primers from: {primers_path.name}")
            with open(primers_path, "r") as f:
                data = json_lib.load(f)

            # Convert JSON to models
            pairs = []
            if isinstance(data, list):
                for item in data:
                    # Support both flat structure and nested pair structure
                    pairs.append(MultiplexPair(
                        name=item.get("name", f"Pair_{len(pairs)+1}"),
                        forward=item.get("fwd", item.get("forward", "")),
                        reverse=item.get("rev", item.get("reverse", "")),
                        tm_forward=item.get("tm_fwd", item.get("tm", 0.0)),
                        tm_reverse=item.get("tm_rev", item.get("tm", 0.0)),
                        gc_forward=item.get("gc_fwd", item.get("gc", 0.0)), 
                        gc_reverse=item.get("gc_rev", item.get("gc", 0.0))
                    ))
            else:
                print("❌ Input JSON must be a list of objects")
                sys.exit(1)

            print(f"✅ Loaded {len(pairs)} primer pairs")

            # 2. Config
            config = load_and_merge_config("compat_check", user_config_path=args.config)
            mode = config.get("compat_check", {}).get("mode", "standard")
            print(f"⚙️  Mode: {mode.upper()}")

            # 3. Analyze
            print("⏳ Calculating dimer interactions...")
            engine = DimerEngine()
            matrix = engine.build_matrix(pairs)

            print("📊 Scoring and validating...")
            scorer = MultiplexScorer(config)
            score_res = scorer.calculate_score(matrix, pairs)

            validator = MultiplexValidator(config)
            validation = validator.get_validation_summary(matrix, pairs)

            # 4. Merge validation into result
            score_res.is_valid = validation["is_valid"]
            score_res.errors = validation["errors"]
            score_res.warnings.extend(validation["warnings"])

            # 5. Output
            out_dir = PathLib(args.output)
            out_dir.mkdir(parents=True, exist_ok=True)

            report_path = generate_markdown_report(score_res, out_dir)
            json_path = generate_json_report(score_res, out_dir)

            # 6. Overlap analysis if template provided (v0.4.1)
            overlap_result = None
            if args.template:
                print("🔬 Running overlap analysis...")
                try:
                    from primerlab.core.compat_check.overlap_detection import run_insilico_compat_simulation
                    from primerlab.core.sequence import SequenceLoader

                    # Load template
                    template_path = PathLib(args.template)
                    if template_path.exists():
                        template_seq = SequenceLoader.load(str(template_path))
                    else:
                        template_seq = args.template  # Assume raw sequence

                    # Convert pairs to dict format
                    primer_dicts = [
                        {"name": p.name, "forward": p.forward, "reverse": p.reverse}
                        for p in pairs
                    ]

                    overlap_result = run_insilico_compat_simulation(
                        template=template_seq,
                        primer_pairs=primer_dicts,
                        template_name="template"
                    )

                    # Save overlap report
                    import json as json_module
                    with open(out_dir / "overlap_analysis.json", "w") as f:
                        json_module.dump(overlap_result.to_dict(), f, indent=2)

                    if overlap_result.has_problems:
                        print(f"   ⚠️ {len([o for o in overlap_result.overlaps if o.is_problematic])} problematic overlap(s) detected")
                    else:
                        print("   ✅ No problematic overlaps")

                except Exception as e:
                    print(f"   ⚠️ Overlap analysis failed: {e}")

            print("\n" + "=" * 45)
            print(f"🏁 Score: {score_res.score:.1f}/100 (Grade {score_res.grade})")
            print(f"   Status: {'✅ COMPATIBLE' if score_res.is_valid else '❌ INCOMPATIBLE'}")
            print(f"📁 Reports saved to: {out_dir}")
            print(f"   • {report_path.name}")
            print(f"   • {json_path.name}")
            if args.template and overlap_result:
                print(f"   • overlap_analysis.json")
            print()

            sys.exit(0 if score_res.is_valid else 1)

        except Exception as e:
            print(f"\n❌ Error: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    # --- SPECIES-CHECK Command Handler (v0.4.2) ---
    if args.command == "species-check":
        try:
            import json as json_lib
            from pathlib import Path as PathLib
            from primerlab.core.species import (
                load_species_template,
                load_species_templates,
                check_species_specificity,
                generate_specificity_matrix_table,
                detect_offtarget_species,
            )
            from primerlab.core.species.report import (
                generate_species_json_report,
                generate_species_markdown_report,
                generate_species_excel_report,
                generate_species_html_report,
            )

            logger = setup_logger(level=logging.INFO)
            print(f"\n🧬 Species Specificity Check (v{__version__})")
            print("=" * 50)

            # 1. Load primers
            primers_path = PathLib(args.primers)
            if not primers_path.exists():
                print(f"❌ Primers file not found: {primers_path}")
                sys.exit(1)

            print(f"📂 Loading primers: {primers_path.name}")
            with open(primers_path, "r") as f:
                primers = json_lib.load(f)

            # Normalize primer format
            primer_list = []
            for p in primers:
                primer_list.append({
                    "name": p.get("name", f"Primer_{len(primer_list)+1}"),
                    "forward": p.get("forward", p.get("fwd", "")),
                    "reverse": p.get("reverse", p.get("rev", ""))
                })

            # 2. Load target template
            target_path = args.target
            print(f"🎯 Loading target: {PathLib(target_path).name}")
            target_template = load_species_template(target_path, PathLib(target_path).stem)

            # 3. Load off-target templates
            offtarget_templates = {}
            if args.offtargets:
                paths = [p.strip() for p in args.offtargets.split(",")]
                for path in paths:
                    if PathLib(path).exists():
                        template = load_species_template(path, PathLib(path).stem)
                        offtarget_templates[template.species_name] = template
                        print(f"🔬 Loaded off-target: {template.species_name}")

            # 4. Run analysis
            print("\n⏳ Analyzing species specificity...")
            result = check_species_specificity(
                primer_list,
                target_template,
                offtarget_templates
            )

            # 5. Generate reports
            out_dir = PathLib(args.output)
            out_dir.mkdir(parents=True, exist_ok=True)

            json_path = generate_species_json_report(result, str(out_dir))

            if args.format == "markdown" or args.format == "json":
                md_path = generate_species_markdown_report(result, str(out_dir))

            if args.format == "excel":
                excel_path = generate_species_excel_report(result, str(out_dir))

            if args.format == "html":
                html_path = generate_species_html_report(result, str(out_dir))

            # 6. Output summary
            print("\n" + "=" * 50)
            print(f"🏁 Specificity Score: {result.overall_score:.1f}/100 (Grade {result.grade})")
            print(f"   Status: {'✅ SPECIFIC' if result.is_specific else '⚠️ CROSS-REACTIVE'}")
            print(f"   Primers: {result.primers_checked} | Species: {result.species_checked}")

            if result.warnings:
                print(f"\n⚠️ Warnings ({len(result.warnings)}):")
                for w in result.warnings[:3]:
                    print(f"   • {w}")

            print(f"\n📁 Reports saved to: {out_dir}")
            print(f"   • species_analysis.json")
            if args.format == "markdown":
                print(f"   • species_report.md")
            if args.format == "excel":
                print(f"   • species_analysis.xlsx")
            print()

            sys.exit(0 if result.is_specific else 1)

        except Exception as e:
            print(f"\n❌ Error: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    # ===== TM-GRADIENT Command Handler (v0.4.3) =====
    if args.command == "tm-gradient":
        try:
            import json
            from pathlib import Path as PathLib
            from primerlab.core.tm_gradient import (
                TmGradientConfig,
                simulate_tm_gradient,
                predict_optimal_annealing,
                analyze_temperature_sensitivity,
            )

            logger = setup_logger(level=logging.INFO)

            print("\n🌡️ Tm Gradient Simulation (v0.4.3)")
            print("=" * 50)

            # 1. Load primers
            print(f"📂 Loading primers: {args.primers}")
            with open(args.primers, "r") as f:
                primers = json.load(f)

            # 2. Configure gradient
            config = TmGradientConfig(
                min_temp=args.min_temp,
                max_temp=args.max_temp,
                step_size=args.step
            )

            print(f"🔬 Temperature range: {config.min_temp}°C - {config.max_temp}°C (step {config.step_size}°C)")
            print(f"\n⏳ Simulating Tm gradient for {len(primers)} primers...")

            # 3. Run simulations
            results = []
            for primer in primers:
                name = primer.get("name", "Unknown")
                seq = primer.get("forward", primer.get("sequence", ""))

                if seq:
                    result = simulate_tm_gradient(seq, f"{name}_fwd", config=config)
                    results.append(result)

                rev = primer.get("reverse", "")
                if rev:
                    result = simulate_tm_gradient(rev, f"{name}_rev", config=config)
                    results.append(result)

            # 4. Predict optimal
            optimal = predict_optimal_annealing(primers, config)

            # 5. Output
            out_dir = PathLib(args.output)
            out_dir.mkdir(parents=True, exist_ok=True)

            # Save JSON
            json_output = {
                "config": {
                    "min_temp": config.min_temp,
                    "max_temp": config.max_temp,
                    "step_size": config.step_size
                },
                "optimal": optimal,
                "primers": [r.to_dict() for r in results]
            }

            json_path = out_dir / "tm_gradient.json"
            with open(json_path, "w") as f:
                json.dump(json_output, f, indent=2)

            # Generate additional reports based on format
            from primerlab.core.tm_gradient.report import (
                generate_tm_gradient_markdown,
                generate_tm_gradient_csv,
            )

            report_files = [str(json_path)]

            if args.format == "markdown":
                md_path = generate_tm_gradient_markdown(
                    json_output["primers"],
                    optimal,
                    json_output["config"],
                    str(out_dir / "tm_gradient_report.md")
                )
                report_files.append(md_path)

            if args.format == "csv":
                csv_path = generate_tm_gradient_csv(
                    json_output["primers"],
                    optimal,
                    json_output["config"],
                    str(out_dir / "tm_gradient.csv")
                )
                report_files.append(csv_path)

            # Summary
            print("\n" + "=" * 50)
            print(f"🎯 Optimal Annealing Temperature: {optimal['optimal']:.1f}°C")
            print(f"   Recommended Range: {optimal['range_min']:.1f}°C - {optimal['range_max']:.1f}°C")
            print(f"\n📊 Per-Primer Results:")

            for r in results[:6]:  # Show first 6
                print(f"   {r.primer_name}: Tm={r.calculated_tm:.1f}°C, Optimal={r.optimal_annealing_temp:.1f}°C (Grade {r.grade})")

            if len(results) > 6:
                print(f"   ... and {len(results) - 6} more")

            print(f"\n📁 Reports saved to: {out_dir}")
            for rf in report_files:
                print(f"   • {PathLib(rf).name}")
            sys.exit(0)

        except Exception as e:
            print(f"\n❌ Error: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    if args.command == "run":
        # 1. Setup Logging
        # v0.1.6: --quiet flag suppresses info/warning messages
        if hasattr(args, 'quiet') and args.quiet:
            log_level = logging.ERROR  # Only show errors
        elif args.debug:
            log_level = logging.DEBUG
        else:
            log_level = logging.INFO
        logger = setup_logger(level=log_level)

        if not (hasattr(args, 'quiet') and args.quiet):
            logger.info(f"Starting PrimerLab v{__version__}")
            logger.info(f"Workflow: {args.workflow.upper()}")

        # Early check for unimplemented workflows
        if args.workflow == "crispr":
            logger.error("CRISPR workflow is not yet implemented. Please use 'pcr' or 'qpcr'.")
            sys.exit(2)

        try:
            # 2. Prepare CLI Overrides
            overrides = {}
            if args.out:
                overrides["output"] = {"directory": args.out}
            if args.debug:
                overrides["advanced"] = {"debug": True}

            # 3. Load Configuration
            config = load_and_merge_config(
                workflow=args.workflow,
                user_config_path=args.config,
                cli_overrides=overrides
            )

            logger.info("Configuration loaded successfully.")
            logger.debug(f"Final Config: {config}")

            # Check for dry-run mode
            if args.dry_run:
                logger.info("✅ Dry-run complete. Configuration is valid.")
                logger.info(f"   Workflow: {args.workflow}")
                logger.info(f"   Output: {config['output']['directory']}")
                params = config.get('parameters', {})
                if params.get('tm'):
                    logger.info(f"   Tm Range: {params['tm'].get('min', '?')} - {params['tm'].get('max', '?')} °C")
                if params.get('product_size'):
                    logger.info(f"   Product Size: {params['product_size'].get('min', '?')} - {params['product_size'].get('max', '?')} bp")
                sys.exit(0)

            # 4. Region Masking (v0.1.5)
            if args.mask and args.mask != "none":
                from primerlab.core.masking import RegionMasker, apply_masks_to_config, format_mask_report
                from primerlab.core.sequence import SequenceLoader

                # Get raw sequence before workflow
                input_cfg = config.get("input", {})
                raw_seq = input_cfg.get("sequence") or ""
                seq_path = input_cfg.get("sequence_path")

                if seq_path:
                    # Read raw (unprocessed) sequence to detect lowercase
                    from pathlib import Path
                    raw_seq = Path(seq_path).read_text()

                masker = RegionMasker()

                # Determine detection mode
                detect_lower = args.mask in ["auto", "lowercase"]
                detect_n = args.mask in ["auto", "n"]

                masks = masker.analyze_sequence(raw_seq, detect_lowercase=detect_lower, detect_n=detect_n)

                if masks:
                    # Apply masks to config
                    config = apply_masks_to_config(config, masks)
                    print(format_mask_report(masks, len(raw_seq)))
                else:
                    logger.info("No masked regions detected")

            # 5. Run Workflow
            logger.info("Initializing workflow engine...")

            result = None
            if args.workflow == "pcr":
                from primerlab.workflows.pcr import run_pcr_workflow
                result = run_pcr_workflow(config)
            elif args.workflow == "qpcr":
                from primerlab.workflows.qpcr import run_qpcr_workflow
                result = run_qpcr_workflow(config)

            if result is not None:
                # 5. Save Output
                from primerlab.core.output import OutputManager

                out_dir = config["output"]["directory"]
                output_mgr = OutputManager(out_dir, args.workflow)

                output_mgr.save_json(result)
                output_mgr.save_csv(result)

                # Export vendor formats (v0.1.3)
                # Priority: CLI --export flag > config output.export_formats > default ["idt"]
                export_formats = ["idt"]  # Default

                # Check config for export_formats
                config_formats = config.get("output", {}).get("export_formats", [])
                if config_formats:
                    export_formats = [f.strip().lower() for f in config_formats]

                # CLI flag overrides config
                if args.export:
                    export_formats = [f.strip().lower() for f in args.export.split(",")]

                for fmt in export_formats:
                    if fmt in ["idt", "sigma", "thermo"]:
                        output_mgr.save_ordering_format(result, fmt)
                    elif fmt == "xlsx":
                        # v0.1.4: Excel export
                        output_mgr.save_excel(result)
                    elif fmt == "idt_bulk":
                        # v0.1.4: IDT bulk order with plate positions
                        output_mgr.save_idt_bulk_order(result)
                    elif fmt == "html":
                        # v0.1.4: HTML report
                        output_mgr.save_html(result)
                    elif fmt == "benchling":
                        # v0.1.5: Benchling CSV export
                        output_mgr.save_benchling_csv(result)
                    elif fmt in ["json", "csv"]:
                        # json and csv are saved by default, no extra action needed
                        pass
                    else:
                        logger.warning(f"Unknown export format: {fmt}")

                # 6. Generate Report
                if args.workflow == "qpcr":
                    from primerlab.workflows.qpcr.report import qPCRReportGenerator
                    report_gen = qPCRReportGenerator()
                else:
                    from primerlab.workflows.pcr.report import ReportGenerator
                    report_gen = ReportGenerator()

                report_content = report_gen.generate_report(result)

                # Save report
                report_path = output_mgr.run_dir / "report.md"
                with open(report_path, "w") as f:
                    f.write(report_content)
                logger.info(f"Report saved to: {report_path}")

                # v0.3.3: Enhanced report generation with --report flag
                if hasattr(args, 'report') and args.report:
                    try:
                        from primerlab.core.report import ReportGenerator as EnhancedReportGenerator
                        from primerlab.core.report import ReportExporter

                        # Build enhanced report from result
                        enhanced_gen = EnhancedReportGenerator()

                        # Extract primer info from result
                        if hasattr(result, 'primers') and result.primers:
                            fwd = result.primers.get('forward')
                            rev = result.primers.get('reverse')

                            fwd_seq = fwd.sequence if hasattr(fwd, 'sequence') else str(fwd) if fwd else ""
                            rev_seq = rev.sequence if hasattr(rev, 'sequence') else str(rev) if rev else ""
                            fwd_tm = fwd.tm if hasattr(fwd, 'tm') else 0.0
                            rev_tm = rev.tm if hasattr(rev, 'tm') else 0.0
                            fwd_gc = fwd.gc_percent if hasattr(fwd, 'gc_percent') else 0.0
                            rev_gc = rev.gc_percent if hasattr(rev, 'gc_percent') else 0.0
                            product_size = result.amplicons[0].length if result.amplicons else None

                            enhanced_gen.add_design(
                                forward_seq=fwd_seq,
                                reverse_seq=rev_seq,
                                forward_tm=fwd_tm,
                                reverse_tm=rev_tm,
                                forward_gc=fwd_gc,
                                reverse_gc=rev_gc,
                                product_size=product_size
                            )

                        # Add validation info if available
                        if hasattr(result, 'insilico_result') and result.insilico_result:
                            enhanced_gen.add_validation(
                                amplicons=len(result.insilico_result.amplicons) if hasattr(result.insilico_result, 'amplicons') else 1,
                                product_size=product_size
                            )

                        # Add off-target info if available
                        if hasattr(result, 'offtarget_check') and result.offtarget_check:
                            ot = result.offtarget_check
                            enhanced_gen.add_offtarget(
                                forward_hits=ot.get('forward_offtargets', 0) if isinstance(ot, dict) else 0,
                                reverse_hits=ot.get('reverse_offtargets', 0) if isinstance(ot, dict) else 0,
                                grade=ot.get('grade', '?') if isinstance(ot, dict) else '?',
                                score=ot.get('specificity_score', 0.0) if isinstance(ot, dict) else 0.0
                            )

                        # Generate report
                        enhanced_report = enhanced_gen.generate()

                        # Determine output path
                        report_format = getattr(args, 'report_format', 'markdown')
                        if hasattr(args, 'report_output') and args.report_output:
                            enhanced_report_path = Path(args.report_output)
                        else:
                            ext_map = {'markdown': 'md', 'html': 'html', 'json': 'json'}
                            ext = ext_map.get(report_format, 'md')
                            enhanced_report_path = output_mgr.run_dir / f"enhanced_report.{ext}"

                        # Export report
                        exporter = ReportExporter(enhanced_report)
                        exporter.export(str(enhanced_report_path), format=report_format)

                        logger.info(f"Enhanced report ({report_format}) saved to: {enhanced_report_path}")

                    except Exception as report_err:
                        logger.warning(f"Could not generate enhanced report: {report_err}")
                        if args.debug:
                            import traceback
                            traceback.print_exc()

                # v0.4.0: Multiplex compatibility check
                if hasattr(args, 'check_compat') and args.check_compat:
                    try:
                        from primerlab.core.compat_check.models import MultiplexPair
                        from primerlab.core.compat_check.dimer import DimerEngine
                        from primerlab.core.compat_check.scoring import MultiplexScorer
                        from primerlab.core.compat_check.validator import MultiplexValidator
                        from primerlab.core.compat_check.report import generate_markdown_report, generate_json_report

                        logger.info("🔬 Running multiplex compatibility check...")

                        # Convert result primers to MultiplexPair format
                        pairs = []
                        if hasattr(result, 'primers') and result.primers:
                            fwd = result.primers.get('forward')
                            rev = result.primers.get('reverse')

                            if fwd and rev:
                                fwd_seq = fwd.sequence if hasattr(fwd, 'sequence') else str(fwd)
                                rev_seq = rev.sequence if hasattr(rev, 'sequence') else str(rev)
                                fwd_tm = fwd.tm if hasattr(fwd, 'tm') else 60.0
                                rev_tm = rev.tm if hasattr(rev, 'tm') else 60.0
                                fwd_gc = fwd.gc_percent if hasattr(fwd, 'gc_percent') else 50.0
                                rev_gc = rev.gc_percent if hasattr(rev, 'gc_percent') else 50.0

                                pairs.append(MultiplexPair(
                                    name=config.get('output', {}).get('target_name', 'Primer_1'),
                                    forward=fwd_seq,
                                    reverse=rev_seq,
                                    tm_forward=fwd_tm,
                                    tm_reverse=rev_tm,
                                    gc_forward=fwd_gc,
                                    gc_reverse=rev_gc
                                ))

                        if len(pairs) >= 1:
                            # Run multiplex analysis
                            engine = DimerEngine()
                            matrix = engine.build_matrix(pairs)

                            scorer = MultiplexScorer(config)
                            score_res = scorer.calculate_score(matrix, pairs)

                            validator = MultiplexValidator(config)
                            validation = validator.get_validation_summary(matrix, pairs)

                            # Update result with validation info
                            score_res.is_valid = validation["is_valid"]
                            score_res.errors = validation["errors"]
                            score_res.warnings.extend(validation["warnings"])

                            # Save multiplex report
                            multiplex_dir = output_mgr.run_dir / "multiplex"
                            multiplex_dir.mkdir(parents=True, exist_ok=True)

                            generate_markdown_report(score_res, multiplex_dir)
                            generate_json_report(score_res, multiplex_dir)

                            # Print summary
                            status = "✅ COMPATIBLE" if score_res.is_valid else "⚠️ ISSUES FOUND"
                            logger.info(f"Multiplex Score: {score_res.score:.1f}/100 (Grade {score_res.grade}) - {status}")
                            logger.info(f"Multiplex reports saved to: {multiplex_dir}")
                        else:
                            logger.warning("No primer pairs found for multiplex check")

                    except Exception as mpx_err:
                        logger.warning(f"Could not run multiplex check: {mpx_err}")
                        if args.debug:
                            import traceback
                            traceback.print_exc()

                if config.get("advanced", {}).get("debug"):
                    output_mgr.save_debug_data(result.raw, "primer3_raw.json")
                    output_mgr.save_debug_data(config, "final_config.json")

                # 7. Print colorized summary (v0.1.3)
                try:
                    from primerlab.cli.console import print_primer_summary, print_qc_status, print_success
                    print_primer_summary(result)
                    print_qc_status(result)
                    print_success(f"Workflow finished! Output: {output_mgr.run_dir}")
                except ImportError:
                    # Fallback if rich not available
                    logger.info(f"Primers found: {list(result.primers.keys())}")
                    if result.amplicons:
                        logger.info(f"Amplicon size: {result.amplicons[0].length} bp")
                    logger.info("Workflow finished successfully.")

                # 8. Auto-save to database (v0.1.5)
                try:
                    from primerlab.core.database import PrimerDatabase
                    db = PrimerDatabase()
                    db.save_design(result.to_dict(), config)
                    db.close()
                    logger.debug("Design saved to primer history database")
                except Exception as db_err:
                    logger.debug(f"Could not save to history database: {db_err}")
            else:
                logger.warning("Workflow returned no results.")

        except PrimerLabException as e:
            logger.error(f"Error: {e}")

            # v0.1.5: Auto Parameter Suggestion for design failures
            if hasattr(e, 'error_code') and e.error_code == "ERR_TOOL_P3_NO_PRIMERS":
                try:
                    from primerlab.core.suggestion import suggest_relaxed_parameters, format_suggestions_for_cli
                    suggestion_result = suggest_relaxed_parameters(config, getattr(e, 'details', None))
                    print(format_suggestions_for_cli(suggestion_result))
                except Exception as suggestion_error:
                    logger.debug(f"Could not generate suggestions: {suggestion_error}")

            if args.debug:
                logger.exception("Traceback:")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Unexpected Error: {e}")
            logger.exception("Traceback:")
            sys.exit(1)

    # --- COMPARE Command Handler (v0.1.5) ---
    if args.command == "compare":
        logger = setup_logger(level=logging.INFO)
        logger.info(f"🔬 PrimerLab Primer Comparison v{__version__}")

        try:
            from primerlab.core.comparison import compare_primers, format_comparison_for_cli, load_result_json

            # Parse labels
            labels = tuple(args.labels.split(",")[:2])
            if len(labels) < 2:
                labels = ("A", "B")

            # Load results
            result_a = load_result_json(args.result_a)
            result_b = load_result_json(args.result_b)

            # Compare
            comparison = compare_primers(result_a, result_b, labels)

            # Display
            print(format_comparison_for_cli(comparison, labels))

            sys.exit(0)

        except FileNotFoundError as e:
            logger.error(f"Error: {e}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Unexpected Error: {e}")
            logger.exception("Traceback:")
            sys.exit(1)

    # --- BATCH RUN Command Handler (v0.1.5) ---
    if args.command == "batch-run":
        logger = setup_logger(level=logging.INFO)
        logger.info(f"🚀 PrimerLab Batch Run v{__version__}")

        try:
            from pathlib import Path
            import json
            from primerlab.core.batch_summary import (
                generate_batch_summary,
                format_batch_summary_cli,
                save_batch_excel,
                save_batch_summary_csv
            )
            from primerlab.core.sequence import SequenceLoader

            # Determine mode: configs OR fasta
            use_fasta_mode = args.fasta is not None
            use_configs_mode = args.configs is not None

            if not use_fasta_mode and not use_configs_mode:
                logger.error("Either --configs or --fasta is required")
                sys.exit(1)

            if use_fasta_mode and use_configs_mode:
                logger.error("Cannot use both --configs and --fasta. Choose one.")
                sys.exit(1)

            # 2. Create output directory
            output_dir = Path(args.output)
            output_dir.mkdir(parents=True, exist_ok=True)

            results = []
            sequences_to_process = []  # List of (name, sequence, config)

            # === FASTA MODE ===
            if use_fasta_mode:
                fasta_path = Path(args.fasta)
                if not fasta_path.exists():
                    logger.error(f"FASTA file not found: {fasta_path}")
                    sys.exit(1)

                # Load shared config
                if args.config:
                    shared_config = load_and_merge_config(args.config)
                else:
                    # Default config
                    shared_config = {"workflow": "pcr", "parameters": {}}
                    logger.warning("No --config provided, using defaults")

                # Parse multi-FASTA
                fasta_content = fasta_path.read_text()
                parsed_seqs = SequenceLoader._parse_fasta(fasta_content)

                logger.info(f"Found {len(parsed_seqs)} sequences in {fasta_path.name}")

                import copy
                for name, seq in parsed_seqs:
                    # Deep clone config to avoid shared state
                    seq_config = copy.deepcopy(shared_config)
                    if "input" not in seq_config:
                        seq_config["input"] = {}
                    seq_config["input"]["sequence"] = seq
                    sequences_to_process.append((name, seq, seq_config))

            # === CONFIGS MODE ===
            else:
                config_input = args.configs
                config_files = []

                if Path(config_input).is_dir():
                    config_dir = Path(config_input)
                    config_files = list(config_dir.glob("*.yaml")) + list(config_dir.glob("*.yml"))
                    logger.info(f"Found {len(config_files)} config files in {config_input}")
                else:
                    config_files = [Path(p.strip()) for p in config_input.split(",")]

                if not config_files:
                    logger.error("No config files found!")
                    sys.exit(1)

                for config_path in config_files:
                    sequence_name = config_path.stem.replace("_config", "")
                    config = load_and_merge_config(str(config_path))
                    sequences_to_process.append((sequence_name, None, config))

            # 3. Run each sequence
            for sequence_name, raw_seq, config in sequences_to_process:
                logger.info(f"📌 Processing: {sequence_name}")

                try:
                    workflow_type = config.get("workflow", "pcr").lower()

                    # Get workflow engine
                    if workflow_type == "qpcr":
                        from primerlab.workflows.qpcr.engine import qPCRWorkflowEngine
                        engine = qPCRWorkflowEngine()
                    else:
                        from primerlab.workflows.pcr.engine import PCRWorkflowEngine
                        engine = PCRWorkflowEngine()

                    # Run workflow
                    result = engine.run(config)

                    # Save individual result
                    result_dir = output_dir / sequence_name
                    result_dir.mkdir(exist_ok=True)

                    result_data = result.to_dict()
                    result_data["metadata"] = {"sequence_name": sequence_name}

                    with open(result_dir / "result.json", "w") as f:
                        json.dump(result_data, f, indent=2)

                    # Run amplicon analysis if amplicons available (v0.4.1)
                    amplicons = result_data.get("amplicons", [])
                    if amplicons:
                        try:
                            from primerlab.core.amplicon import analyze_amplicon
                            from primerlab.core.amplicon.report import (
                                generate_amplicon_json_report,
                                generate_amplicon_markdown_report
                            )

                            # Analyze first/primary amplicon
                            primary_amplicon = amplicons[0] if amplicons else None
                            if primary_amplicon and primary_amplicon.get("sequence"):
                                amplicon_result = analyze_amplicon(
                                    primary_amplicon["sequence"]
                                )

                                # Save amplicon analysis
                                generate_amplicon_json_report(amplicon_result, str(result_dir))

                                # Add to result
                                result_data["amplicon_analysis"] = amplicon_result.to_dict()

                                # Update result.json with amplicon data
                                with open(result_dir / "result.json", "w") as f:
                                    json.dump(result_data, f, indent=2)

                        except Exception as amp_err:
                            logger.debug(f"  Amplicon analysis skipped: {amp_err}")

                    results.append(result_data)
                    logger.info(f"  ✅ Success - Quality Score: {result.qc.quality_score if result.qc else 'N/A'}")

                except Exception as e:
                    logger.error(f"  ❌ Failed: {e}")
                    results.append({
                        "metadata": {"sequence_name": sequence_name},
                        "primers": {},
                        "amplicons": [],
                        "qc": {},
                        "error": str(e)
                    })

                    if not args.continue_on_error:
                        logger.error("Stopping batch run. Use --continue-on-error to continue.")
                        break

            # 4. Generate summary
            summary = generate_batch_summary(results)

            # 5. Display CLI summary
            print(format_batch_summary_cli(summary))

            # 6. Export summary
            export_formats = [f.strip().lower() for f in args.export.split(",")]

            if "xlsx" in export_formats:
                save_batch_excel(results, str(output_dir / "batch_summary.xlsx"))
            if "csv" in export_formats:
                save_batch_summary_csv(summary, str(output_dir / "batch_summary.csv"))

            # Save summary JSON
            with open(output_dir / "batch_summary.json", "w") as f:
                json.dump(summary, f, indent=2)

            # 7. Auto compat-check if ≥2 successful primer pairs
            successful_results = [r for r in results if "error" not in r and r.get("primers")]
            if len(successful_results) >= 2:
                try:
                    from primerlab.core.compat_check.models import MultiplexPair
                    from primerlab.core.compat_check.dimer import DimerEngine
                    from primerlab.core.compat_check.scoring import MultiplexScorer
                    from primerlab.core.compat_check.validator import MultiplexValidator
                    from primerlab.core.compat_check.report import generate_markdown_report, generate_json_report

                    logger.info(f"🔬 Running compatibility check on {len(successful_results)} primer pairs...")

                    # Extract primer pairs
                    pairs = []
                    for r in successful_results:
                        primers = r.get("primers", {})
                        name = r.get("metadata", {}).get("sequence_name", f"Pair_{len(pairs)+1}")

                        fwd = primers.get("forward", {})
                        rev = primers.get("reverse", {})

                        if fwd and rev:
                            pairs.append(MultiplexPair(
                                name=name,
                                forward=fwd.get("sequence", ""),
                                reverse=rev.get("sequence", ""),
                                tm_forward=fwd.get("tm", 0.0),
                                tm_reverse=rev.get("tm", 0.0),
                                gc_forward=fwd.get("gc_content", 0.0),
                                gc_reverse=rev.get("gc_content", 0.0)
                            ))

                    if len(pairs) >= 2:
                        # Run compat check
                        engine = DimerEngine()
                        matrix = engine.build_matrix(pairs)

                        scorer = MultiplexScorer()
                        result = scorer.calculate_score(matrix, pairs)

                        validator = MultiplexValidator()
                        is_valid, errors, warnings = validator.validate(result, matrix, pairs)
                        result.is_valid = is_valid
                        result.errors = errors
                        result.warnings = warnings

                        # Save compat reports
                        compat_dir = output_dir / "compat_check"
                        compat_dir.mkdir(exist_ok=True)
                        generate_json_report(result, compat_dir)
                        generate_markdown_report(result, compat_dir)

                        status = "✅ COMPATIBLE" if result.is_valid else "⚠️ ISSUES FOUND"
                        logger.info(f"  {status} - Score: {result.score:.1f}/100 (Grade: {result.grade})")

                except Exception as e:
                    logger.warning(f"Compat check skipped: {e}")

            logger.info(f"✅ Batch run complete. Results in: {output_dir}")
            sys.exit(0)

        except Exception as e:
            logger.error(f"Batch run failed: {e}")
            sys.exit(1)

    # --- PLOT Command Handler (v0.1.5) ---
    if args.command == "plot":
        logger = setup_logger(level=logging.INFO)
        logger.info(f"🎨 PrimerLab Visualization v{__version__}")

        try:
            from pathlib import Path
            import json
            from primerlab.core.visualization import plot_gc_profile
            from primerlab.core.sequence import SequenceLoader

            # Load result
            result_path = Path(args.result)
            if not result_path.exists():
                logger.error(f"Result file not found: {result_path}")
                sys.exit(1)

            with open(result_path) as f:
                result = json.load(f)

            # Load sequence
            sequence = SequenceLoader.load(args.sequence)

            # Determine output path
            output_path = args.output
            if not output_path:
                output_path = result_path.parent / f"gc_profile_{args.theme}.png"

            # Get primer info
            primers = result.get("primers", {})
            amplicons = result.get("amplicons", [])

            primer_fwd = None
            primer_rev = None
            probe = None
            amplicon_start = 0
            amplicon_end = len(sequence)

            if "forward" in primers:
                fwd = primers["forward"]
                primer_fwd = {"start": fwd.get("start", 0), "end": fwd.get("end", 0)}

            if "reverse" in primers:
                rev = primers["reverse"]
                primer_rev = {"start": rev.get("start", 0), "end": rev.get("end", 0)}

            if "probe" in primers:
                prb = primers["probe"]
                probe = {"start": prb.get("start", 0), "end": prb.get("end", 0)}

            if amplicons:
                amplicon_start = amplicons[0].get("start", 0)
                amplicon_end = amplicons[0].get("end", len(sequence))

            # Generate plot
            saved_path = plot_gc_profile(
                sequence=sequence,
                primer_fwd=primer_fwd,
                primer_rev=primer_rev,
                probe=probe,
                amplicon_start=amplicon_start,
                amplicon_end=amplicon_end,
                window_size=args.window,
                theme=args.theme,
                output_path=str(output_path),
                title=f"GC Content Profile - {result.get('workflow', 'PCR').upper()}"
            )

            if saved_path:
                logger.info(f"✅ Plot saved to: {saved_path}")
            else:
                logger.warning("Plot generation failed (matplotlib may not be installed)")

            sys.exit(0)

        except Exception as e:
            logger.error(f"Plot generation failed: {e}")
            sys.exit(1)

    # --- HISTORY Command Handler (v0.1.5) ---
    if args.command == "history":
        logger = setup_logger(level=logging.INFO)

        try:
            from primerlab.core.database import PrimerDatabase, format_history_table
            import json

            db = PrimerDatabase()

            if args.history_command == "list":
                designs = db.search(
                    gene=args.gene,
                    workflow=args.workflow,
                    limit=args.limit
                )
                print(format_history_table(designs))

            elif args.history_command == "show":
                design = db.get_by_id(args.id)
                if design:
                    print(f"\n{'='*60}")
                    print(f"Design #{design['id']} - {design['gene_name']}")
                    print(f"{'='*60}")
                    print(f"  Created: {design['created_at']}")
                    print(f"  Workflow: {design['workflow'].upper()}")
                    print(f"\n  Forward Primer:")
                    print(f"    Sequence: {design['fwd_sequence']}")
                    print(f"    Tm: {design['fwd_tm']:.1f}°C | GC: {design['fwd_gc']:.1f}%")
                    print(f"\n  Reverse Primer:")
                    print(f"    Sequence: {design['rev_sequence']}")
                    print(f"    Tm: {design['rev_tm']:.1f}°C | GC: {design['rev_gc']:.1f}%")
                    if design['probe_sequence']:
                        print(f"\n  Probe:")
                        print(f"    Sequence: {design['probe_sequence']}")
                    print(f"\n  Amplicon: {design['amplicon_length']} bp | GC: {design['amplicon_gc']:.1f}%")
                    print(f"  Quality: {design['quality_score']:.1f} ({design['quality_category']})")
                    print(f"{'='*60}\n")
                else:
                    logger.error(f"Design #{args.id} not found")

            elif args.history_command == "export":
                path = db.export_csv(args.output)
                logger.info(f"✅ History exported to: {path}")

            elif args.history_command == "stats":
                stats = db.get_stats()
                print(f"\n{'='*40}")
                print("📊 Primer Database Statistics")
                print(f"{'='*40}")
                print(f"  Total Designs: {stats['total_designs']}")
                print(f"  Avg Quality Score: {stats['avg_quality_score']}")
                print(f"\n  By Workflow:")
                for wf, count in stats['by_workflow'].items():
                    print(f"    {wf.upper()}: {count}")
                print(f"{'='*40}\n")

            elif args.history_command == "delete":
                if db.delete(args.id):
                    logger.info(f"✅ Deleted design #{args.id}")
                else:
                    logger.error(f"Design #{args.id} not found")

            else:
                # No subcommand - show recent
                designs = db.get_recent(10)
                print(format_history_table(designs))

            db.close()
            sys.exit(0)

        except Exception as e:
            logger.error(f"History command failed: {e}")
            sys.exit(1)

    if args.command == "batch-generate":
        logger = setup_logger(level=logging.INFO)
        logger.info(f"Starting PrimerLab Batch Generator v{__version__}")

        try:
            from primerlab.cli.batch_generator import generate_configs_from_csv

            generated = generate_configs_from_csv(
                csv_path=args.input,
                output_dir=args.output,
                workflow=args.workflow
            )

            logger.info(f"✅ Successfully generated {len(generated)} config files")
            for f in generated:
                print(f"  - {f}")

        except FileNotFoundError as e:
            logger.error(f"Error: {e}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Unexpected Error: {e}")
            sys.exit(1)

    if args.command == "init":
        # Generate template configuration file (v0.1.3)
        logger = setup_logger(level=logging.INFO)
        logger.info(f"Generating template config for {args.workflow.upper()} workflow...")

        templates = {
            "pcr": '''# PrimerLab Configuration - PCR Workflow
# Generated by: primerlab init

workflow: pcr

input:
  # Provide EITHER sequence directly OR a file path
  sequence: "YOUR_SEQUENCE_HERE"
  # sequence_path: "path/to/sequence.fasta"

parameters:
  # Primer constraints
  primer_size:
    min: 18
    opt: 20
    max: 27
  
  # Melting temperature (°C)
  tm:
    min: 57.0
    opt: 60.0
    max: 63.0
  
  # GC content (%)
  gc:
    min: 40.0
    max: 60.0
  
  # Amplicon size (bp)
  product_size_range: [[100, 300]]
  
  # Multi-candidate options (v0.1.3)
  # num_candidates: 50  # Number of primers to evaluate

output:
  directory: "./output_pcr"

# QC settings
qc:
  # mode: standard  # strict, standard, relaxed
  hairpin_dg_min: -3.0
  dimer_dg_min: -6.0
''',
            "qpcr": '''# PrimerLab Configuration - qPCR Workflow
# Generated by: primerlab init

workflow: qpcr

input:
  sequence: "YOUR_SEQUENCE_HERE"
  # sequence_path: "path/to/sequence.fasta"

parameters:
  primer_size:
    min: 18
    opt: 20
    max: 25
  
  tm:
    min: 57.0
    opt: 60.0
    max: 63.0
  
  gc:
    min: 40.0
    max: 60.0
  
  # qPCR-specific: smaller amplicon
  product_size_range: [[70, 150]]
  
  # Probe settings (for TaqMan)
  probe:
    size:
      min: 18
      opt: 20
      max: 25
    tm:
      min: 65.0
      opt: 68.0
      max: 72.0
  
  # Multi-candidate options
  # num_candidates: 30

output:
  directory: "./output_qpcr"

qc:
  hairpin_dg_min: -3.0
  dimer_dg_min: -6.0
'''
        }

        template = templates.get(args.workflow, templates["pcr"])
        output_file = Path(args.output)

        if output_file.exists():
            logger.warning(f"File {args.output} already exists. Overwrite? (y/n)")
            response = input().strip().lower()
            if response != 'y':
                logger.info("Aborted.")
                sys.exit(0)

        with open(output_file, "w") as f:
            f.write(template)

        logger.info(f"✅ Created config file: {output_file}")
        logger.info(f"   Edit the file to add your sequence, then run:")
        logger.info(f"   primerlab run {args.workflow} --config {output_file}")

    # --- PROBE-CHECK Command Handler (v0.6.0) ---
    if args.command == "probe-check":
        import json
        from primerlab.api import simulate_probe_binding_api

        probe = args.probe.upper()
        amplicon = args.amplicon.upper() if args.amplicon else None

        result = simulate_probe_binding_api(
            probe_sequence=probe,
            amplicon_sequence=amplicon,
            min_temp=getattr(args, 'min_temp', 55.0),
            max_temp=getattr(args, 'max_temp', 72.0),
        )

        if args.format == "json":
            output = json.dumps(result, indent=2)
        else:
            lines = [
                "═══════════════════════════════════════════════════════",
                "                   PROBE BINDING CHECK (v0.6.0)",
                "═══════════════════════════════════════════════════════",
                f"Probe:    {probe}",
                f"Length:   {len(probe)} bp",
                "",
                "Results:",
                f"  Binding Tm:     {result.get('tm', 'N/A')}°C",
                f"  Grade:          {result.get('grade', 'N/A')}",
                f"  Quality Score:  {result.get('quality_score', 'N/A')}/100",
            ]
            if result.get('position'):
                pos = result['position']
                lines.append(f"  Position:       {pos.get('amplicon_position', 'N/A')}")
            if result.get('warnings'):
                lines.append("\nWarnings:")
                for w in result['warnings']:
                    lines.append(f"  ⚠ {w}")
            output = "\n".join(lines)

        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"✅ Output saved to {args.output}")
        else:
            print(output)
        sys.exit(0)

    # --- MELT-CURVE Command Handler (v0.6.0) ---
    if args.command == "melt-curve":
        import json
        from pathlib import Path
        from primerlab.core.qpcr.melt_curve import predict_melt_curve
        from primerlab.core.qpcr.melt_plot import generate_melt_svg, generate_melt_png

        # Load amplicon from file or use as sequence
        amp_input = args.amplicon
        if Path(amp_input).exists():
            with open(amp_input, 'r') as f:
                content = f.read()
            if content.startswith('>'):
                amplicon = ''.join(content.strip().split('\n')[1:])
            else:
                amplicon = content.strip()
        else:
            amplicon = amp_input.upper()

        result = predict_melt_curve(
            amplicon_sequence=amplicon,
            min_temp=getattr(args, 'min_temp', 65.0),
            max_temp=getattr(args, 'max_temp', 95.0),
        )

        if args.format == "json":
            output = json.dumps(result.to_dict(), indent=2)
            if args.output:
                with open(args.output, 'w') as f:
                    f.write(output)
            else:
                print(output)
        elif args.format == "svg":
            svg = generate_melt_svg(
                melt_curve=result.melt_curve,
                peaks=[p.to_dict() for p in result.peaks],
                predicted_tm=result.predicted_tm,
                output_path=args.output,
            )
            if not args.output:
                print(svg)
            print(f"✅ SVG generated: Tm={result.predicted_tm:.1f}°C")
        elif args.format == "png":
            if not args.output:
                args.output = "melt_curve.png"
            success = generate_melt_png(
                melt_curve=result.melt_curve,
                peaks=[p.to_dict() for p in result.peaks],
                predicted_tm=result.predicted_tm,
                output_path=args.output,
            )
            if success:
                print(f"✅ PNG saved to {args.output}")
            else:
                print("❌ PNG generation failed (matplotlib required)")
                sys.exit(1)
        else:  # text
            lines = [
                "═══════════════════════════════════════════════════════",
                "                   MELT CURVE PREDICTION (v0.6.0)",
                "═══════════════════════════════════════════════════════",
                f"Amplicon Length:  {len(amplicon)} bp",
                f"Predicted Tm:     {result.predicted_tm:.1f}°C",
                f"Tm Range:         {result.tm_range[0]:.1f} - {result.tm_range[1]:.1f}°C",
                f"Single Peak:      {'✅ Yes' if result.is_single_peak else '⚠ No'}",
                f"Quality Score:    {result.quality_score:.0f}/100",
                f"Grade:            {result.grade}",
            ]
            if result.warnings:
                lines.append("\nWarnings:")
                for w in result.warnings:
                    lines.append(f"  ⚠ {w}")
            print("\n".join(lines))
        sys.exit(0)

    # --- AMPLICON-QC Command Handler (v0.6.0) ---
    if args.command == "amplicon-qc":
        import json
        from pathlib import Path
        from primerlab.api import validate_qpcr_amplicon_api

        # Load amplicon from file or use as sequence
        amp_input = args.amplicon
        if Path(amp_input).exists():
            with open(amp_input, 'r') as f:
                content = f.read()
            if content.startswith('>'):
                amplicon = ''.join(content.strip().split('\n')[1:])
            else:
                amplicon = content.strip()
        else:
            amplicon = amp_input.upper()

        result = validate_qpcr_amplicon_api(
            amplicon_sequence=amplicon,
            min_length=args.min_length,
            max_length=args.max_length,
        )

        if args.format == "json":
            output = json.dumps(result, indent=2)
        else:
            lines = [
                "═══════════════════════════════════════════════════════",
                "                   AMPLICON QC (v0.6.0)",
                "═══════════════════════════════════════════════════════",
                f"Length:           {result['amplicon_length']} bp",
                f"GC Content:       {result['gc_content']:.1f}%",
                f"Amplicon Tm:      {result.get('tm_amplicon', 'N/A')}°C",
                "",
                "Validation:",
                f"  Length OK:      {'✅' if result['length_ok'] else '❌'}",
                f"  GC OK:          {'✅' if result['gc_ok'] else '❌'}",
                f"  Structure OK:   {'✅' if result.get('secondary_structure_ok', True) else '❌'}",
                "",
                f"Quality Score:    {result['quality_score']:.0f}/100",
                f"Grade:            {result['grade']}",
            ]
            if result.get('warnings'):
                lines.append("\nWarnings:")
                for w in result['warnings']:
                    lines.append(f"  ⚠ {w}")
            if result.get('recommendations'):
                lines.append("\nRecommendations:")
                for r in result['recommendations']:
                    lines.append(f"  → {r}")
            output = "\n".join(lines)

        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"✅ Output saved to {args.output}")
        else:
            print(output)
        sys.exit(0)

    # --- NESTED-DESIGN Command Handler (v0.7.0) ---
    if args.command == "nested-design":
        from primerlab.core.sequence import SequenceLoader
        from primerlab.core.variants import design_nested_primers
        import json

        # Load sequence
        sequence = args.sequence
        if Path(sequence).exists():
            sequence = SequenceLoader.load(sequence)

        # Design nested primers
        result = design_nested_primers(
            sequence=sequence,
            outer_size_range=(args.outer_min, args.outer_max),
            inner_size_range=(args.inner_min, args.inner_max),
            outer_tm=args.outer_tm,
            inner_tm=args.inner_tm,
        )

        if args.format == "json":
            output = json.dumps(result.to_dict(), indent=2)
        elif args.format == "markdown":
            lines = [
                "# Nested PCR Design Result (v0.7.0)",
                "",
                f"**Status:** {'✅ Success' if result.success else '❌ Failed'}",
                f"**Sequence Length:** {result.sequence_length} bp",
                "",
            ]
            if result.primer_set:
                ps = result.primer_set
                lines.extend([
                    "## Outer Primers",
                    f"- **Forward:** `{ps.outer_forward}`",
                    f"  - Tm: {ps.outer_tm_forward:.1f}°C, GC: {ps.outer_gc_forward:.1f}%",
                    f"- **Reverse:** `{ps.outer_reverse}`",
                    f"  - Tm: {ps.outer_tm_reverse:.1f}°C, GC: {ps.outer_gc_reverse:.1f}%",
                    f"- **Product Size:** {ps.outer_product_size} bp",
                    "",
                    "## Inner Primers",
                    f"- **Forward:** `{ps.inner_forward}`",
                    f"  - Tm: {ps.inner_tm_forward:.1f}°C, GC: {ps.inner_gc_forward:.1f}%",
                    f"- **Reverse:** `{ps.inner_reverse}`",
                    f"  - Tm: {ps.inner_tm_reverse:.1f}°C, GC: {ps.inner_gc_reverse:.1f}%",
                    f"- **Product Size:** {ps.inner_product_size} bp",
                    "",
                    "## Quality",
                    f"- **Grade:** {ps.grade}",
                    f"- **Score:** {ps.combined_score:.1f}/100",
                    f"- **Tm Difference (inner-outer):** {ps.get_tm_difference():.1f}°C",
                ])
            if result.warnings:
                lines.append("\n## Warnings")
                for w in result.warnings:
                    lines.append(f"- ⚠ {w}")
            if result.recommendations:
                lines.append("\n## Recommendations")
                for r in result.recommendations:
                    lines.append(f"- → {r}")
            output = "\n".join(lines)
        else:
            # Text format
            lines = [
                "═══════════════════════════════════════════════════════",
                "              NESTED PCR DESIGN (v0.7.0)",
                "═══════════════════════════════════════════════════════",
                f"Status:          {'SUCCESS' if result.success else 'FAILED'}",
                f"Sequence Length: {result.sequence_length} bp",
                "",
            ]
            if result.primer_set:
                ps = result.primer_set
                lines.extend([
                    "OUTER PRIMERS",
                    "─────────────────────────────────────",
                    f"  Forward:     {ps.outer_forward}",
                    f"               Tm: {ps.outer_tm_forward:.1f}°C  GC: {ps.outer_gc_forward:.1f}%",
                    f"  Reverse:     {ps.outer_reverse}",
                    f"               Tm: {ps.outer_tm_reverse:.1f}°C  GC: {ps.outer_gc_reverse:.1f}%",
                    f"  Product:     {ps.outer_product_size} bp",
                    "",
                    "INNER PRIMERS",
                    "─────────────────────────────────────",
                    f"  Forward:     {ps.inner_forward}",
                    f"               Tm: {ps.inner_tm_forward:.1f}°C  GC: {ps.inner_gc_forward:.1f}%",
                    f"  Reverse:     {ps.inner_reverse}",
                    f"               Tm: {ps.inner_tm_reverse:.1f}°C  GC: {ps.inner_gc_reverse:.1f}%",
                    f"  Product:     {ps.inner_product_size} bp",
                    "",
                    "QUALITY",
                    "─────────────────────────────────────",
                    f"  Grade:       {ps.grade}",
                    f"  Score:       {ps.combined_score:.1f}/100",
                    f"  Tm Diff:     {ps.get_tm_difference():.1f}°C (inner - outer)",
                ])
            if result.warnings:
                lines.append("\nWARNINGS:")
                for w in result.warnings:
                    lines.append(f"  ⚠ {w}")
            if result.recommendations:
                lines.append("\nRECOMMENDATIONS:")
                for r in result.recommendations:
                    lines.append(f"  → {r}")
            lines.append("═══════════════════════════════════════════════════════")
            output = "\n".join(lines)

        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"✅ Output saved to {args.output}")
        else:
            print(output)
        sys.exit(0)

    # --- SEMINESTED-DESIGN Command Handler (v0.7.0) ---
    if args.command == "seminested-design":
        from primerlab.core.sequence import SequenceLoader
        from primerlab.core.variants import design_seminested_primers
        import json

        # Load sequence
        sequence = args.sequence
        if Path(sequence).exists():
            sequence = SequenceLoader.load(sequence)

        # Design semi-nested primers
        result = design_seminested_primers(
            sequence=sequence,
            outer_size_range=(args.outer_min, args.outer_max),
            inner_size_range=(args.inner_min, args.inner_max),
            shared_position=args.shared,
            tm_opt=args.tm,
        )

        if args.format == "json":
            output = json.dumps(result.to_dict(), indent=2)
        elif args.format == "markdown":
            lines = [
                "# Semi-Nested PCR Design Result (v0.7.0)",
                "",
                f"**Status:** {'✅ Success' if result.success else '❌ Failed'}",
                f"**Sequence Length:** {result.sequence_length} bp",
                f"**Shared Primer:** {args.shared.capitalize()}",
                "",
            ]
            if result.primer_set:
                ps = result.primer_set
                lines.extend([
                    "## Outer Primers",
                    f"- **Forward:** `{ps.outer_forward}`",
                    f"- **Reverse:** `{ps.outer_reverse}`",
                    f"- **Product Size:** {ps.outer_product_size} bp",
                    "",
                    "## Inner Primers",
                    f"- **Forward:** `{ps.inner_forward}` {'(SHARED)' if args.shared == 'forward' else ''}",
                    f"- **Reverse:** `{ps.inner_reverse}` {'(SHARED)' if args.shared == 'reverse' else ''}",
                    f"- **Product Size:** {ps.inner_product_size} bp",
                    "",
                    "## Quality",
                    f"- **Grade:** {ps.grade}",
                    f"- **Score:** {ps.combined_score:.1f}/100",
                ])
            if result.warnings:
                lines.append("\n## Warnings")
                for w in result.warnings:
                    lines.append(f"- ⚠ {w}")
            output = "\n".join(lines)
        else:
            # Text format
            lines = [
                "═══════════════════════════════════════════════════════",
                "           SEMI-NESTED PCR DESIGN (v0.7.0)",
                "═══════════════════════════════════════════════════════",
                f"Status:          {'SUCCESS' if result.success else 'FAILED'}",
                f"Sequence Length: {result.sequence_length} bp",
                f"Shared Primer:   {args.shared.capitalize()}",
                "",
            ]
            if result.primer_set:
                ps = result.primer_set
                shared_fwd = " (SHARED)" if args.shared == "forward" else ""
                shared_rev = " (SHARED)" if args.shared == "reverse" else ""
                lines.extend([
                    "OUTER PRIMERS",
                    "─────────────────────────────────────",
                    f"  Forward:     {ps.outer_forward}",
                    f"  Reverse:     {ps.outer_reverse}",
                    f"  Product:     {ps.outer_product_size} bp",
                    "",
                    "INNER PRIMERS",
                    "─────────────────────────────────────",
                    f"  Forward:     {ps.inner_forward}{shared_fwd}",
                    f"  Reverse:     {ps.inner_reverse}{shared_rev}",
                    f"  Product:     {ps.inner_product_size} bp",
                    "",
                    "QUALITY",
                    "─────────────────────────────────────",
                    f"  Grade:       {ps.grade}",
                    f"  Score:       {ps.combined_score:.1f}/100",
                ])
            if result.warnings:
                lines.append("\nWARNINGS:")
                for w in result.warnings:
                    lines.append(f"  ⚠ {w}")
            lines.append("═══════════════════════════════════════════════════════")
            output = "\n".join(lines)

        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"✅ Output saved to {args.output}")
        else:
            print(output)
        sys.exit(0)

    # --- DIMER-MATRIX Command Handler (v0.7.1) ---
    if args.command == "dimer-matrix":
        from primerlab.core.analysis.dimer_matrix import (
            DimerMatrixAnalyzer,
            analyze_dimer_matrix,
        )
        import json

        # Load primers from JSON
        with open(args.primers, 'r') as f:
            primers = json.load(f)

        # Analyze dimer matrix
        analyzer = DimerMatrixAnalyzer({"dg_threshold": args.threshold})
        result = analyzer.analyze(primers)

        if args.format == "json":
            output = json.dumps(result.to_dict(), indent=2)
        elif args.format == "svg":
            output = analyzer.generate_heatmap_svg(result)
        else:
            # Text format
            lines = [
                "═══════════════════════════════════════════════════════",
                "           PRIMER DIMER MATRIX (v0.7.1)",
                "═══════════════════════════════════════════════════════",
                f"Primers:         {len(result.primers)}",
                f"Worst ΔG:        {result.worst_dg:.1f} kcal/mol",
                f"Grade:           {result.grade}",
                "",
                "MATRIX (ΔG kcal/mol):",
                "─────────────────────────────────────",
            ]

            # Header row
            header = "        " + "  ".join([p["name"][:6].ljust(6) for p in result.primers])
            lines.append(header)

            # Matrix rows
            for i, primer in enumerate(result.primers):
                row_name = primer["name"][:6].ljust(6)
                row_values = "  ".join([f"{v:6.1f}" for v in result.matrix[i]])
                lines.append(f"{row_name}  {row_values}")

            if result.problematic_pairs:
                lines.append("")
                lines.append("PROBLEMATIC PAIRS:")
                for p1, p2 in result.problematic_pairs:
                    lines.append(f"  ⚠ {p1} ↔ {p2}")

            lines.append("═══════════════════════════════════════════════════════")
            output = "\n".join(lines)

        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"✅ Output saved to {args.output}")
        else:
            print(output)
        sys.exit(0)

    # --- COMPARE-BATCH Command Handler (v0.7.1) ---
    if args.command == "compare-batch":
        from primerlab.core.analysis.batch_compare import compare_batch
        import json

        # Compare results
        result = compare_batch(args.results)

        if args.format == "json":
            output = json.dumps(result.to_dict(), indent=2)
        elif args.format == "markdown":
            lines = [
                "# Batch Comparison Report (v0.7.1)",
                "",
                f"**Runs Compared:** {len(result.runs)}",
                f"**Success Rate:** {result.success_rate:.0f}%",
                f"**Avg Quality:** {result.avg_quality:.1f}",
                "",
                "## Summary",
                f"- **Best Run:** {result.best_run or 'N/A'}",
                f"- **Worst Run:** {result.worst_run or 'N/A'}",
                "",
                "## Runs",
            ]
            for run in result.runs:
                lines.append(f"- **{run.name}**: {run.quality_grade or 'N/A'} ({run.quality_score or 'N/A'})")

            if result.differences:
                lines.append("\n## Differences")
                for diff in result.differences:
                    lines.append(f"- [{diff['severity'].upper()}] {diff['description']}")
            output = "\n".join(lines)
        else:
            # Text format
            lines = [
                "═══════════════════════════════════════════════════════",
                "           BATCH COMPARISON REPORT (v0.7.1)",
                "═══════════════════════════════════════════════════════",
                f"Runs Compared:   {len(result.runs)}",
                f"Success Rate:    {result.success_rate:.0f}%",
                f"Avg Quality:     {result.avg_quality:.1f}",
                f"Best Run:        {result.best_run or 'N/A'}",
                f"Worst Run:       {result.worst_run or 'N/A'}",
                "",
                "RUNS:",
                "─────────────────────────────────────",
            ]
            for run in result.runs:
                status = "✅" if run.success else "❌"
                lines.append(f"  {status} {run.name}: {run.quality_grade or 'N/A'} ({run.quality_score or 'N/A'})")

            if result.differences:
                lines.append("")
                lines.append("DIFFERENCES:")
                lines.append("─────────────────────────────────────")
                for diff in result.differences:
                    sev = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(diff["severity"], "⚪")
                    lines.append(f"  {sev} {diff['description']}")

            lines.append("═══════════════════════════════════════════════════════")
            output = "\n".join(lines)

        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"✅ Output saved to {args.output}")
        else:
            print(output)
        sys.exit(0)

    # --- COVERAGE-MAP Command Handler (v0.7.2) ---
    if args.command == "coverage-map":
        from primerlab.core.visualization import CoverageMapGenerator, create_coverage_map
        import json

        # Load result file
        with open(args.result, 'r') as f:
            result_data = json.load(f)

        # Extract primer pairs from result
        primers = result_data.get("primers", {})
        amplicons = result_data.get("amplicons", [])

        primer_pairs = []
        if primers:
            fwd = primers.get("forward", {})
            rev = primers.get("reverse", {})
            if fwd and rev:
                primer_pairs.append({
                    "name": "Primary",
                    "forward": {"start": fwd.get("start", 0), "end": fwd.get("end", 0)},
                    "reverse": {"start": rev.get("start", 0), "end": rev.get("end", 0)},
                })

        # Get sequence length
        seq_len = args.sequence_length
        if seq_len is None and amplicons:
            seq_len = max(a.get("end", 0) for a in amplicons) + 100
        if seq_len is None:
            seq_len = 1000  # Default

        # Create coverage map
        generator = CoverageMapGenerator()
        result = generator.create_map(seq_len, primer_pairs)

        if args.format == "json":
            output = json.dumps(result.to_dict(), indent=2)
        elif args.format == "svg":
            output = generator.generate_svg(result, width=args.width, height=args.height)
        else:
            # Text format
            lines = [
                "═══════════════════════════════════════════════════════",
                "           AMPLICON COVERAGE MAP (v0.7.2)",
                "═══════════════════════════════════════════════════════",
                f"Sequence Length: {result.sequence_length} bp",
                f"Primer Count:    {len(result.primers)}",
                f"Amplicon Count:  {len(result.amplicons)}",
                f"Coverage:        {result.total_coverage:.1f}%",
                "",
                "AMPLICONS:",
                "─────────────────────────────────────",
            ]
            for amp in result.amplicons:
                lines.append(f"  {amp.name}: {amp.start}-{amp.end} ({amp.length} bp)")
            lines.append("═══════════════════════════════════════════════════════")
            output = "\n".join(lines)

        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"✅ Output saved to {args.output}")
        else:
            print(output)
        sys.exit(0)

    # --- QPCR-EFFICIENCY Command Handler (v0.7.4) ---
    if args.command == "qpcr-efficiency":
        from primerlab.core.qpcr.efficiency import (
            calculate_efficiency,
            predict_primer_efficiency,
        )
        import json
        import primer3

        if args.eff_action == "calculate":
            # Load data from JSON
            with open(args.data, 'r') as f:
                data = json.load(f)

            concentrations = data.get("concentrations", [])
            ct_values = data.get("ct_values", [])

            result = calculate_efficiency(concentrations, ct_values)

            if args.format == "json":
                output = json.dumps(result.to_dict(), indent=2)
            else:
                lines = [
                    "═══════════════════════════════════════════════════════",
                    "         QPCR EFFICIENCY ANALYSIS (v0.7.4)",
                    "═══════════════════════════════════════════════════════",
                    f"Data Points:     {len(concentrations)}",
                    f"Slope:           {result.slope:.3f}",
                    f"Intercept:       {result.intercept:.2f}",
                    f"R²:              {result.r_squared:.4f}",
                    "",
                    f"Efficiency:      {result.efficiency:.1f}%",
                    f"Grade:           {result.grade}",
                    f"Acceptable:      {'✅ Yes' if result.is_acceptable else '❌ No'}",
                    "",
                    f"Dynamic Range:   {result.dynamic_range:.1f} log10",
                    "═══════════════════════════════════════════════════════",
                ]
                output = "\n".join(lines)

        elif args.eff_action == "predict":
            # Calculate Tm and GC
            fwd_tm = primer3.calc_tm(args.forward)
            rev_tm = primer3.calc_tm(args.reverse)
            fwd_gc = sum(1 for c in args.forward.upper() if c in 'GC') / len(args.forward) * 100
            rev_gc = sum(1 for c in args.reverse.upper() if c in 'GC') / len(args.reverse) * 100

            result = predict_primer_efficiency(
                args.forward, args.reverse,
                fwd_tm, rev_tm, fwd_gc, rev_gc,
                args.amplicon_length,
            )

            if args.format == "json":
                output = json.dumps(result.to_dict(), indent=2)
            else:
                lines = [
                    "═══════════════════════════════════════════════════════",
                    "       EFFICIENCY PREDICTION (v0.7.4)",
                    "═══════════════════════════════════════════════════════",
                    f"Forward:         {args.forward}",
                    f"Reverse:         {args.reverse}",
                    f"Amplicon:        {args.amplicon_length} bp",
                    "",
                    f"Predicted Eff:   {result.predicted_efficiency:.1f}%",
                    f"Confidence:      {result.confidence:.0%}",
                    "",
                    "FACTORS:",
                ]
                for k, v in result.factors.items():
                    lines.append(f"  {k}: {v:+.1f}")
                if result.recommendations:
                    lines.append("")
                    lines.append("RECOMMENDATIONS:")
                    for r in result.recommendations:
                        lines.append(f"  → {r}")
                lines.append("═══════════════════════════════════════════════════════")
                output = "\n".join(lines)
        else:
            print("Usage: primerlab qpcr-efficiency [calculate|predict]")
            sys.exit(1)

        if hasattr(args, 'output') and args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"✅ Output saved to {args.output}")
        else:
            print(output)
        sys.exit(0)

if __name__ == "__main__":
    main()
